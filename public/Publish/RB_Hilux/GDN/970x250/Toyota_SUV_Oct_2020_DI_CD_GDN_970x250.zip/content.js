(function(cjs, an) {
 var p;
 var lib = {};
 var ss = {};
 var img = {};
 lib.ssMetadata = [];

 function mc_symbol_clone() {
  var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
  clone.gotoAndStop(this.currentFrame);
  clone.paused = this.paused;
  clone.framerate = this.framerate;
  return clone;
 }

 function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
  var prototype = cjs.extend(symbol, cjs.MovieClip);
  prototype.clone = mc_symbol_clone;
  prototype.nominalBounds = nominalBounds;
  prototype.frameBounds = frameBounds;
  return prototype;
 }
 (lib.t3_bottom_b_3 = function() {
  this.initialize(img.t3_bottom_b_3);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 415, 84);
 (lib.t3_bottom = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_b_3 = new lib.t3_bottom_b_3();
  this.cvr_b_3.name = "cvr_b_3";
  this.cvr_b_3.parent = this;
  this.cvr_b_3.setTransform(23, 138, 0.5, 0.5);
  this.timeline.addTween(cjs.Tween.get(this.cvr_b_3).wait(1));
  this.timeline.addTween(cjs.Tween.get(this.cvr_b_3).wait(1));
 }).prototype = getMCSymbolPrototype(lib.t3_bottom, new cjs.Rectangle(21, 136, 419, 97.30000000000001), null);
 (lib.t2_top_t_2 = function() {
  this.initialize(img.t2_top_t_2);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 344, 72);
 (lib.t2_top = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_t_2 = new lib.t2_top_t_2();
  this.cvr_t_2.name = "cvr_t_2";
  this.cvr_t_2.parent = this;
  this.cvr_t_2.setTransform(22, 10, 0.5, 0.5);
  this.timeline.addTween(cjs.Tween.get(this.cvr_t_2).wait(1));
  this.timeline.addTween(cjs.Tween.get(this.cvr_t_2).wait(1));
 }).prototype = getMCSymbolPrototype(lib.t2_top, new cjs.Rectangle(20, 8, 347.5, 93), null);
 (lib.t2_bottom_b_2 = function() {
  this.initialize(img.t2_bottom_b_2);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 415, 84);
 (lib.t2_bottom = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_b_2 = new lib.t2_bottom_b_2();
  this.cvr_b_2.name = "cvr_b_2";
  this.cvr_b_2.parent = this;
  this.cvr_b_2.setTransform(23, 138, 0.5, 0.5);
  this.timeline.addTween(cjs.Tween.get(this.cvr_b_2).wait(1));
  this.timeline.addTween(cjs.Tween.get(this.cvr_b_2).wait(1));
 }).prototype = getMCSymbolPrototype(lib.t2_bottom, new cjs.Rectangle(21, 136, 419, 97.30000000000001), null);
 (lib.t1_top_t_1 = function() {
  this.initialize(img.t1_top_t_1);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 331, 72);
 (lib.t1_top = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_t_1 = new lib.t1_top_t_1();
  this.cvr_t_1.name = "cvr_t_1";
  this.cvr_t_1.parent = this;
  this.cvr_t_1.setTransform(22, 10, 0.5, 0.5);
  this.timeline.addTween(cjs.Tween.get(this.cvr_t_1).wait(1));
  this.timeline.addTween(cjs.Tween.get(this.cvr_t_1).wait(1));
 }).prototype = getMCSymbolPrototype(lib.t1_top, new cjs.Rectangle(20, 8, 335, 133.5), null);
 (lib.t1_bottom_b_1 = function() {
  this.initialize(img.t1_bottom_b_1);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 415, 84);
 (lib.t1_bottom = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_b_1 = new lib.t1_bottom_b_1();
  this.cvr_b_1.name = "cvr_b_1";
  this.cvr_b_1.parent = this;
  this.cvr_b_1.setTransform(23, 138, 0.5, 0.5);
  this.timeline.addTween(cjs.Tween.get(this.cvr_b_1).wait(1));
  this.timeline.addTween(cjs.Tween.get(this.cvr_b_1).wait(1));
 }).prototype = getMCSymbolPrototype(lib.t1_bottom, new cjs.Rectangle(21, 136, 419, 97.30000000000001), null);
 (lib.t_4_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#FFFFFF").s().p("ABGB1IiKjCIAADCIgZAAIAAjpIAXAAICLDCIAAjCIAZAAIAADpg");
  this.shape.setTransform(232.45, 173.575);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#FFFFFF").s().p("AgLB1IAAheIhUiLIAcAAIBEB0IBFh0IAaAAIhUCLIAABeg");
  this.shape_1.setTransform(212.025, 173.575);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#FFFFFF").s().p("AhLB1IAAjpIBCAAQAgAAASAQQATAQAAAcQAAAPgHAOQgHANgSAJQAWAFANAOQAMAPABAXQgBATgJAPQgIAPgQAIQgQAIgXAAgAgyBfIAzAAQAYAAANgMQANgMgBgUQAAgUgMgLQgMgKgVAAIg3AAgAgygKIArAAQANgBAJgGQAKgGAGgJQAGgKAAgMQgBgTgMgKQgMgLgXAAIgnAAg");
  this.shape_2.setTransform(194.95, 173.575);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#FFFFFF").s().p("AhfDVQgjgggOg2QgPg3AAhHQAAhGAPg3QAPg4AigfQAkggA7gBQA9ABAjAgQAiAgAPA3QAPA3AABGQAABIgPA2QgPA3giAfQgjAfg9ABQg8gBgjgfgAg7ieQgUAYgHAqQgGAqABAzQgBAzAGApQAHAqAUAZQAUAYAnAAQAoAAAUgZQAVgZAGgpQAHgpgBgzQABgzgHgqQgHgqgUgYQgVgZgngBQgnABgUAZg");
  this.shape_3.setTransform(156.55, 186.925);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#FFFFFF").s().p("AhfDVQgjgggPg2QgOg3AAhHQAAhGAPg3QAPg4AjgfQAiggA8gBQA8ABAkAgQAiAgAPA3QAPA3AABGQAABIgPA2QgPA3giAfQgkAfg8ABQg8gBgjgfgAg7ieQgTAYgHAqQgHAqABAzQgBAzAHApQAHAqATAZQAUAYAnAAQAoAAAUgZQAVgZAGgpQAHgpgBgzQABgzgHgqQgHgqgUgYQgVgZgngBQgnABgUAZg");
  this.shape_4.setTransform(122.1, 186.925);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#FFFFFF").s().p("AhoDuIC9mfIjyAAIAAg8IE8AAIAAApIjAGyg");
  this.shape_5.setTransform(87.45, 186.925);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#FFFFFF").s().p("AhhDiQgmgSgXgcIAhg2QAXAbAeAQQAdAQAnAAQAtgBAagWQAagXABgnQgBgrgjgVQgjgVg+AAIAAg2QAoAAAZgMQAZgMALgSQAMgTAAgUQgBgdgTgSQgUgRgkgBQgiABgdAQQgcAPgWAWIgeg0QAQgPAWgPQAWgNAbgJQAcgJAhAAQAoAAAfAOQAfAPARAaQARAaAAAhQAAApgXAdQgXAdgsAOQA3ANAbAeQAcAfAAAuQAAApgUAgQgVAggkATQglARgwABQg4AAgmgTg");
  this.shape_6.setTransform(41.175, 186.95);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
 }).prototype = getMCSymbolPrototype(lib.t_4_1, new cjs.Rectangle(20, 130.5, 420.6, 99.6), null);
 (lib.t_4 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#000000").s().p("AAiA8IAAg2IhDAAIAAA2IgNAAIAAh3IANAAIAAA2IBDAAIAAg2IANAAIAAB3g");
  this.shape.setTransform(243.8, 138.825);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#000000").s().p("AAkA8IAAhkIhHBkIgMAAIAAh3IAMAAIAABjIBHhjIAMAAIAAB3g");
  this.shape_1.setTransform(231.25, 138.825);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#000000").s().p("AgcAFIAAgJIA5AAIAAAJg");
  this.shape_2.setTransform(221.375, 140.225);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#000000").s().p("AArBKIAAgcIhUAAIAAAcIgMAAIAAgnIAHAAQAEAAADgFQADgDACgHQACgGABgJIAJhOIA+AAIAABsIAOAAIAAAngAgTAHQgBALgCAHQgDAIgDACIA3AAIAAhhIgmAAg");
  this.shape_3.setTransform(212.125, 140.25);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#000000").s().p("AAkBMIAAhkIhHBkIgNAAIAAh4IANAAIAABkIBIhkIALAAIAAB4gAgSg8QgGgFgBgKIAKAAQAAAGAEADQAFACAHAAQAGAAAEgCQAFgDABgGIAJAAQgBAKgHAFQgGAEgMAAQgLAAgHgEg");
  this.shape_4.setTransform(200.45, 137.275);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#000000").s().p("AghA8IAAh3IBBAAIAAALIg0AAIAAArIAzAAIAAAKIgzAAIAAAsIA2AAIAAALg");
  this.shape_5.setTransform(189.625, 138.825);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#000000").s().p("AgkA8IAAh3IAiAAQAMAAAJAEQAJAFAFAIQAEAIAAAMQAAAKgEAJQgFAHgJAGQgJAFgMAAIgVAAIAAAtgAgXAEIATAAQAIAAAGgDQAHgCADgGQAEgHAAgIQAAgKgEgGQgDgFgHgDQgGgCgIAAIgTAAg");
  this.shape_6.setTransform(180.5, 138.825);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#000000").s().p("AgFA8IAAhsIgiAAIAAgLIBPAAIAAALIghAAIAABsg");
  this.shape_7.setTransform(171.15, 138.825);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#000000").s().p("AgfA2QgOgIgJgOQgHgOgBgSQABgRAHgOQAJgOAOgIQAOgIARAAQASAAAPAIQAOAIAHAOQAJAOAAARQAAASgJAOQgHAOgOAIQgPAIgSAAQgRAAgOgIgAgZgqQgLAGgHAMQgGALAAANQAAAOAGAMQAHALALAHQAMAGANAAQAPAAALgGQALgHAGgLQAHgMAAgOQAAgNgHgLQgGgMgLgGQgLgHgPAAQgNAAgMAHg");
  this.shape_8.setTransform(155.85, 138.8);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#000000").s().p("AAhA8IAAhsIhBAAIAABsIgNAAIAAh3IBbAAIAAB3g");
  this.shape_9.setTransform(142.55, 138.825);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.f("#000000").s().p("AAkBMIAAhkIhIBkIgLAAIAAh4IAMAAIAABkIBHhkIANAAIAAB4gAgSg8QgHgFAAgKIAJAAQABAGAFADQAEACAGAAQAIAAADgCQAFgDABgGIAJAAQgBAKgHAFQgGAEgMAAQgLAAgHgEg");
  this.shape_10.setTransform(126.15, 137.275);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.f("#000000").s().p("AgfA2QgOgIgJgOQgHgOgBgSQABgRAHgOQAJgOAOgIQAOgIARAAQASAAAPAIQAOAIAHAOQAJAOAAARQAAASgJAOQgHAOgOAIQgPAIgSAAQgRAAgOgIgAgZgqQgLAGgHAMQgGALAAANQAAAOAGAMQAHALALAHQAMAGANAAQAPAAALgGQALgHAGgLQAHgMAAgOQAAgNgHgLQgGgMgLgGQgLgHgPAAQgNAAgMAHg");
  this.shape_11.setTransform(112.65, 138.8);
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.f("#000000").s().p("AArBKIAAgcIhUAAIAAAcIgMAAIAAgnIAHAAQAEAAADgFQADgDACgHQACgGABgJIAJhOIA+AAIAABsIAOAAIAAAngAgTAHQgBALgCAHQgDAIgDACIA3AAIAAhhIgmAAg");
  this.shape_12.setTransform(99.775, 140.25);
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.f("#000000").s().p("AgfA2QgPgIgIgOQgHgOgBgSQABgRAHgOQAIgOAPgIQAOgIARAAQASAAAOAIQAOAIAJAOQAHAOABARQgBASgHAOQgJAOgOAIQgOAIgSAAQgRAAgOgIgAgYgqQgMAGgGAMQgHALAAANQAAAOAHAMQAGALAMAHQAKAGAOAAQAOAAAMgGQALgHAGgLQAHgMAAgOQAAgNgHgLQgGgMgLgGQgMgHgOAAQgOAAgKAHg");
  this.shape_13.setTransform(87.3, 138.8);
  this.shape_14 = new cjs.Shape();
  this.shape_14.graphics.f("#000000").s().p("AggA8IAAh3IBBAAIAAALIg0AAIAABsg");
  this.shape_14.setTransform(76.625, 138.825);
  this.shape_15 = new cjs.Shape();
  this.shape_15.graphics.f("#000000").s().p("AAuA8IAAh3IAMAAIAAB3gAg5A8IAAh3IANAAIAAAzIAaAAQATAAAKAIQAJAJAAAQQAAAKgEAIQgEAIgJAFQgHAEgOAAgAgsAxIAZAAQANAAAGgGQAHgGAAgMQAAgMgHgFQgGgGgNAAIgZAAg");
  this.shape_15.setTransform(64.425, 138.825);
  this.shape_16 = new cjs.Shape();
  this.shape_16.graphics.f("#000000").s().p("AgmA8IAAh3IAiAAQAQAAAJAIQAKAIAAAOQAAAIgEAHQgDAHgJAFQALACAGAHQAHAIAAALQAAALgFAHQgEAIgIAEQgJAEgLAAgAgZAxIAaAAQAMAAAHgGQAGgHAAgKQAAgKgGgGQgGgFgLAAIgcAAgAgZgFIAWAAQAGAAAFgDQAFgDADgFQADgGAAgGQAAgJgHgGQgGgFgLAAIgUAAg");
  this.shape_16.setTransform(52.475, 138.825);
  this.shape_17 = new cjs.Shape();
  this.shape_17.graphics.f("#000000").s().p("AgVA2QgOgIgIgOQgIgOAAgSQAAgRAIgOQAIgOAOgIQAOgIARAAQAMAAAKADQALAEAHAGIgEANQgHgHgJgDQgKgDgJgBQgOAAgLAHQgLAGgHAMQgGALAAANQAAAOAGAMQAHALALAHQALAGAOAAQALAAAJgEQAKgEAIgFIADALQgJAIgLADQgKADgMAAQgRAAgOgIg");
  this.shape_17.setTransform(37.35, 138.8);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_17
   }, {
    t: this.shape_16
   }, {
    t: this.shape_15
   }, {
    t: this.shape_14
   }, {
    t: this.shape_13
   }, {
    t: this.shape_12
   }, {
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
  this.shape_18 = new cjs.Shape();
  this.shape_18.graphics.f("#FFFFFF").s().p("Ax9CCIAAkDMAj7AAAIAAEDg");
  this.shape_18.setTransform(140, 139);
  this.timeline.addTween(cjs.Tween.get(this.shape_18).wait(1));
 }).prototype = getMCSymbolPrototype(lib.t_4, new cjs.Rectangle(25, 123, 230, 29), null);
 (lib.plate_red = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.rf(["#EC0A1F", "#6B151F", "#1E1C1F"], [0, 0.553, 1], 151.4, -162.7, 0, 152, -162.3, 175.6).s().p("EggfgtDMBA/AAAMhA/BaHg");
  this.shape.setTransform(208, 288.4);
  this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("rgba(108,110,111,0.247)").s().p("EgnIg2XMBORAAAMhORBsvg");
  this.shape_1.setTransform(250.5, 347.975);
  this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));
 }).prototype = getMCSymbolPrototype(lib.plate_red, new cjs.Rectangle(0, 0, 501, 696), null);
 (lib.pic3_1_1_i_3 = function() {
  this.initialize(img.pic3_1_1_i_3);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 2060, 500);
 (lib.pic3_1_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_i_3 = new lib.pic3_1_1_i_3();
  this.cvr_i_3.name = "cvr_i_3";
  this.cvr_i_3.parent = this;
  this.cvr_i_3.setTransform(0, 0, 0.5, 0.5);
  this.timeline.addTween(cjs.Tween.get(this.cvr_i_3).wait(1));
 }).prototype = getMCSymbolPrototype(lib.pic3_1_1, new cjs.Rectangle(0, 0, 1030, 250), null);
 (lib.pic2_1_1_i_2 = function() {
  this.initialize(img.pic2_1_1_i_2);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 2060, 500);
 (lib.pic2_1_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_i_2 = new lib.pic2_1_1_i_2();
  this.cvr_i_2.name = "cvr_i_2";
  this.cvr_i_2.parent = this;
  this.cvr_i_2.setTransform(0, 0, 0.5, 0.5);
  this.timeline.addTween(cjs.Tween.get(this.cvr_i_2).wait(1));
 }).prototype = getMCSymbolPrototype(lib.pic2_1_1, new cjs.Rectangle(0, 0, 1030, 250), null);
 (lib.pic1_1_1_i_1 = function() {
  this.initialize(img.pic1_1_1_i_1);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 1940, 500);
 (lib.pic1_1_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_i_1 = new lib.pic1_1_1_i_1();
  this.cvr_i_1.name = "cvr_i_1";
  this.cvr_i_1.parent = this;
  this.cvr_i_1.setTransform(0, 0, 0.75, 0.75);
  this.timeline.addTween(cjs.Tween.get(this.cvr_i_1).wait(1));
 }).prototype = getMCSymbolPrototype(lib.pic1_1_1, new cjs.Rectangle(0, 0, 1455, 375), null);
 (lib.logo_s = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#FFFFFF").s().p("AiNBcQg7gmAAg2QAAg1A7gmQA6gmBTAAQBUAAA6AmQA7AmAAA1QAAA2g7AmQg6AmhUAAQhTAAg6gmgACVg9QAAAagrATQgZALgfAFIAAAEQAAAxgPAhQgJAVgKAIQA7gEAugeQAZgRANgWQAOgWAAgYQAAgYgNgVQgEgIgHgHIAAADgAifgxQgNAVAAAYQAAAYAOAWQANAWAZARQAZAQAeAKQAYAGAaACQgLgIgIgVQgPghAAgxIAAgEQgegFgagLQgrgTAAgaIAAgCIgLAOgAgVAzQAJAXAMgBQANABAJgXQAIgVABgdQgPACgQgBQgPABgPgCQABAdAIAVgAgVg6QgFANgCAOIAcACIAdgCQgCgOgFgNQgJgWgNAAQgMAAgJAWgAAjhMQAIATAEAYQATgDAQgGQAigMAAgRQAAgRgigMQgNgEgPgDIgNgCIgmgDIgDAAIgDAAIgtAEIgJABIgYAHQgiAMAAARQAAARAiAMQAQAHATACQADgYAJgTQAOgiAUAAQAVAAAOAig");
  this.shape.setTransform(20.125, 13);
  this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
 }).prototype = getMCSymbolPrototype(lib.logo_s, new cjs.Rectangle(0, 0, 40.3, 26), null);
 (lib.line_red_large = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f().s("#FF0022").ss(2, 1, 1).p("AqdO1IU79p");
  this.shape.setTransform(67, -36);
  this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
 }).prototype = getMCSymbolPrototype(lib.line_red_large, new cjs.Rectangle(-1, -131.9, 136, 191.9), null);
 (lib.line_red = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f().s("#FF0022").ss(2, 1, 1).p("AjNEnIGbpN");
  this.shape.setTransform(20.55, 29.475);
  this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
 }).prototype = getMCSymbolPrototype(lib.line_red, new cjs.Rectangle(-1, -1, 43.1, 61), null);
 (lib.legal_01_d1 = function() {
  this.initialize(img.legal_01_d1);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 834, 84);
 (lib.legal_01 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_d1 = new lib.legal_01_d1();
  this.cvr_d1.name = "cvr_d1";
  this.cvr_d1.parent = this;
  this.cvr_d1.setTransform(25, 24, 0.5, 0.5);
  this.timeline.addTween(cjs.Tween.get(this.cvr_d1).wait(1));
  this.timeline.addTween(cjs.Tween.get(this.cvr_d1).wait(1));
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#1E1C1E").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
  this.shape.setTransform(485, 125);
  this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
 }).prototype = getMCSymbolPrototype(lib.legal_01, new cjs.Rectangle(0, 0, 970, 250), null);
 (lib.gray_plate = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.lf(["#BCBCBC", "#1A1F20"], [0, 1], -37.2, 19.8, 34.2, -51.6).s().p("An4K2IPx1rIAAVrg");
  this.shape.setTransform(922, 184.7);
  this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
 }).prototype = getMCSymbolPrototype(lib.gray_plate, new cjs.Rectangle(871.5, 115.3, 101, 138.8), null);
 (lib.btn1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#FFFFFF").s().p("AgoBHIAAiNIBQAAIAAASIg8AAIAAAsIA6AAIAAARIg6AAIAAAsIA9AAIAAASg");
  this.shape.setTransform(227.575, 25.2);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#FFFFFF").s().p("AhdBHIAAiNIAVAAIAAB7IA/AAIAAh7IATAAIAAB7IA/AAIAAh7IAVAAIAACNg");
  this.shape_1.setTransform(209.75, 25.2);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#FFFFFF").s().p("AgvBHIAAiNIAUAAIAAA7IAdAAQAPAAALAFQALAFAEAIQAFAJABAMQgBAMgFAKQgEAKgLAGQgLAFgPAAgAgbA1IAaAAQAOAAAHgFQAHgHAAgMQAAgMgIgGQgHgGgNAAIgaAAg");
  this.shape_2.setTransform(192.3, 25.2);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#FFFFFF").s().p("AgzBHIgHgCIADgSIAFACIAFABQAFAAADgEQACgFACgKIAKhqIBSAAIAACNIgUAAIAAh7IgsAAIgJBeQgCAQgGAHQgIAIgNAAIgIgBg");
  this.shape_3.setTransform(177.2, 25.275);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#FFFFFF").s().p("AglBAQgRgKgKgQQgJgQAAgWQAAgVAJgQQAKgQARgKQAQgJAVAAQAVAAARAJQARAKAJAQQAKAQAAAVQAAAVgKARQgJAQgRAKQgRAJgVAAQgVAAgQgJgAgbguQgMAIgGALQgHAMAAAPQAAAQAHAMQAGALAMAIQANAGAOAAQAPAAAMgGQAMgIAHgLQAHgMAAgQQAAgPgHgMQgHgLgMgIQgMgGgPAAQgOAAgNAGg");
  this.shape_4.setTransform(162.25, 25.2);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#FFFFFF").s().p("AgvBHIAAiNIBOAAIAAATIg6AAIAAAoIAdAAQAQAAAKAFQAKAFAGAIQAEAJAAAMQAAAMgEAKQgGAKgKAGQgKAFgQAAgAgbA1IAbAAQANAAAHgFQAHgHABgMQgBgMgIgGQgHgGgMAAIgbAAg");
  this.shape_5.setTransform(147.55, 25.2);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#FFFFFF").s().p("AgwBHIAAiNIAVAAIAAA7IAdAAQAPAAALAFQALAFAEAIQAGAJgBAMQABAMgGAKQgEAKgLAGQgLAFgPAAgAgbA1IAaAAQAOAAAHgFQAIgHAAgMQgBgMgHgGQgIgGgNAAIgaAAg");
  this.shape_6.setTransform(129.25, 25.2);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#FFFFFF").s().p("AgJBHIAAh7IgnAAIAAgSIBhAAIAAASIgmAAIAAB7g");
  this.shape_7.setTransform(116.65, 25.2);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#FFFFFF").s().p("AArBHIgQgrIg2AAIgQArIgVAAIA2iNIAVAAIA2CNgAAVALIgVg6IgVA6IAqAAg");
  this.shape_8.setTransform(103.975, 25.2);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#FFFFFF").s().p("AAkBHIAAg+IhHAAIAAA+IgVAAIAAiNIAVAAIAAA+IBHAAIAAg+IAVAAIAACNg");
  this.shape_9.setTransform(89.05, 25.2);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.f("#FFFFFF").s().p("AgfBEQgMgFgIgIIAKgQQAHAGAKAFQAKAFANAAQAOAAAJgGQAIgHABgMQAAgNgLgFQgLgHgYAAIAAgPQAQAAAJgEQAJgEADgEQAEgGAAgGQgBgKgGgFQgIgFgLgBQgLABgJAEQgJAEgGAGIgJgRQAIgGAMgEQALgFAOAAQAVAAAMAJQAMAKAAAQQAAAOgIAIQgHAJgNADQAQACAIAIQAJAJAAAQQAAALgFAKQgHAKgLAFQgMAFgQAAQgSAAgNgFg");
  this.shape_10.setTransform(74.9, 25.2);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.f("#FFFFFF").s().p("AgnBHIgMgDIAFgSIAIAEIAJABQAIAAAFgFQAFgDAFgKIg3hsIAWAAIAqBXIAlhXIAWAAIgvBrIgKATQgFAHgHAFQgIAFgNAAIgLgBg");
  this.shape_11.setTransform(62.475, 25.3);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).to({
   state: []
  }, 3).wait(1));
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.f("rgba(0,0,0,0.247)").s().p("A2aD6IFMnzMAnpAAAIlWHzg");
  this.shape_12.setTransform(143.5, 25.025);
  this.shape_12._off = true;
  this.timeline.addTween(cjs.Tween.get(this.shape_12).wait(1).to({
   _off: false
  }, 0).to({
   _off: true
  }, 2).wait(1));
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.lf(["#FF0022", "#B21423"], [0, 1], -143.7, -0.2, 143.2, -0.2).s().p("A2aD6IFMnzMAnpAAAIlWHzg");
  this.shape_13.setTransform(143.5, 25.025);
  this.timeline.addTween(cjs.Tween.get(this.shape_13).wait(4));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(0, 0, 287, 50.1);
 (lib.black_plate = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#000000").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
  this.shape.setTransform(485, 125);
  this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
 }).prototype = getMCSymbolPrototype(lib.black_plate, new cjs.Rectangle(0, 0, 970, 250), null);
 (lib.txt_4 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.t_4();
  this.instance.parent = this;
  this.instance.setTransform(66, 31.5, 1, 1, 0, 0, 0, 66, 11.5);
  this.instance.alpha = 0;
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   y: 11.5,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(6));
  this.instance_1 = new lib.t_4_1();
  this.instance_1.parent = this;
  this.instance_1.setTransform(129.2, 57.6, 1, 1, 0, 0, 0, 129.2, 37.6);
  this.instance_1.alpha = 0;
  this.instance_1._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(4).to({
   _off: false
  }, 0).to({
   y: 37.6,
   alpha: 1
  }, 15, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(20, 123, 420.6, 127.1);
 (lib.txt_3_bottom = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.t3_bottom();
  this.instance.parent = this;
  this.instance.setTransform(61.9, 55.5, 1, 1, 0, 0, 0, 101.9, 55.5);
  this.instance.alpha = 0;
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   x: 101.9,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(-19, 136, 459, 97.30000000000001);
 (lib.txt_2_top = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.t2_top();
  this.instance.parent = this;
  this.instance.setTransform(61.9, 55.5, 1, 1, 0, 0, 0, 101.9, 55.5);
  this.instance.alpha = 0;
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   x: 101.9,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(-20, 8, 387.5, 93);
 (lib.txt_2_bottom = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.t2_bottom();
  this.instance.parent = this;
  this.instance.setTransform(61.9, 55.5, 1, 1, 0, 0, 0, 101.9, 55.5);
  this.instance.alpha = 0;
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   x: 101.9,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(-19, 136, 459, 97.30000000000001);
 (lib.txt_1_top = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.t1_top();
  this.instance.parent = this;
  this.instance.setTransform(61.9, 55.5, 1, 1, 0, 0, 0, 101.9, 55.5);
  this.instance.alpha = 0;
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   x: 101.9,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(-20, 8, 375, 133.5);
 (lib.txt_1_bottom = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.t1_bottom();
  this.instance.parent = this;
  this.instance.setTransform(61.9, 55.5, 1, 1, 0, 0, 0, 101.9, 55.5);
  this.instance.alpha = 0;
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   x: 101.9,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(-19, 136, 459, 97.30000000000001);
 (lib.pic3_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_i_3 = new lib.pic3_1_1();
  this.cvr_i_3.name = "cvr_i_3";
  this.cvr_i_3.parent = this;
  this.cvr_i_3.setTransform(150, 200, 1, 1, 0, 0, 0, 150, 200);
  this.timeline.addTween(cjs.Tween.get(this.cvr_i_3).wait(1));
 }).prototype = getMCSymbolPrototype(lib.pic3_1, new cjs.Rectangle(0, 0, 1030, 250), null);
 (lib.pic3_2 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.pic3_1();
  this.instance.parent = this;
  this.instance.setTransform(180, 300, 1, 1, 0, 0, 0, 180, 300);
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   x: 130
  }, 34, cjs.Ease.get(0.5)).to({
   x: 120
  }, 35, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(-60, 0, 1090, 250.1);
 (lib.pic2_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_i_2 = new lib.pic2_1_1();
  this.cvr_i_2.name = "cvr_i_2";
  this.cvr_i_2.parent = this;
  this.cvr_i_2.setTransform(150, 200, 1, 1, 0, 0, 0, 150, 200);
  this.timeline.addTween(cjs.Tween.get(this.cvr_i_2).wait(1));
 }).prototype = getMCSymbolPrototype(lib.pic2_1, new cjs.Rectangle(0, 0, 1030, 250), null);
 (lib.pic2_2 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.pic2_1();
  this.instance.parent = this;
  this.instance.setTransform(180, 299.9, 0.9999, 1, 0, 0, 0, 180, 299.9);
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   x: 130
  }, 34, cjs.Ease.get(0.5)).to({
   x: 120
  }, 35, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(-60, 0, 1090, 250);
 (lib.pic1_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_i_1 = new lib.pic1_1_1();
  this.cvr_i_1.name = "cvr_i_1";
  this.cvr_i_1.parent = this;
  this.cvr_i_1.setTransform(180, 300, 1, 1, 0, 0, 0, 180, 300);
  this.timeline.addTween(cjs.Tween.get(this.cvr_i_1).wait(1));
 }).prototype = getMCSymbolPrototype(lib.pic1_1, new cjs.Rectangle(0, 0, 1455, 375), null);
 (lib.pic1_2 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.pic1_1();
  this.instance.parent = this;
  this.instance.setTransform(-62.1, 237.9, 1, 1, 0, 0, 0, 179.9, 299.9);
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   regX: 179.8,
   scaleX: 0.771,
   scaleY: 0.771,
   x: 62,
   y: 211.95
  }, 19, cjs.Ease.get(0.5)).to({
   regX: 180,
   regY: 300,
   scaleX: 0.6667,
   scaleY: 0.6667,
   x: 120,
   y: 200
  }, 75, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(-242, -62, 1455, 375);
 (lib.lines_red_bottom = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.line_red_large();
  this.instance.parent = this;
  this.instance.setTransform(746.55, 402.4, 1, 1, 0, 0, 0, 20.6, 29.4);
  this.instance.alpha = 0;
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   x: 860.55,
   y: 241.45,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(725, 80.1, 250, 352.9);
 (lib.lines_red = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.line_red();
  this.instance.parent = this;
  this.instance.setTransform(121.35, 246.3, 1, 1, 0, 0, 0, 20.6, 29.4);
  this.instance.alpha = 0;
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   x: 106.35,
   y: 267.3,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(1));
  this.instance_1 = new lib.line_red();
  this.instance_1.parent = this;
  this.instance_1.setTransform(282.55, 24.05, 1, 1, 0, 0, 0, 20.6, 29.4);
  this.instance_1.alpha = 0;
  this.timeline.addTween(cjs.Tween.get(this.instance_1).to({
   x: 294.7,
   y: 6.7,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(84.8, -23.7, 231.39999999999998, 321.59999999999997);
 (lib.pic4 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.pic1_1();
  this.instance.parent = this;
  this.instance.setTransform(-62.1, 237.9, 1, 1, 0, 0, 0, 179.9, 299.9);
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   regX: 179.8,
   scaleX: 0.771,
   scaleY: 0.771,
   x: 62,
   y: 211.95
  }, 19, cjs.Ease.get(0.5)).to({
   regX: 180,
   regY: 300,
   scaleX: 0.6667,
   scaleY: 0.6667,
   x: 120,
   y: 200
  }, 75, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(-242, -62, 1455, 375);
 (lib.content = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {
   cvr_frame1_3: 83,
   cvr_frame2_2: 143,
   cvr_frame3_1: 203,
   "cvr_frame#4_4": 290,
   cvr_stay: 301,
   cvr_frame5: 402
  });
  this.frame_301 = function() {
   if (!this.cycle) this.cycle = 0;
   this.cycle++;
   var frames = this.duration * this.cycle + this.currentFrame;
   if (frames / createjs.Ticker.getMeasuredFPS() > 30) {
    if (this.cycle > 1) {
     globalStop(this.stage);
    } else {
     var stopFrame = this.currentFrame;
     var tst = cjs.Tween.get(this);
     this.timeline.addTween(cjs.Tween.get(this).wait(this.duration - 1).call(function() {
      globalGotoAndStop(stopFrame);
     }));
    }
   }
  }
  this.timeline.addTween(cjs.Tween.get(this).wait(301).call(this.frame_301));
  this.instance = new lib.logo_s();
  this.instance.parent = this;
  this.instance.setTransform(883.85, 24.85, 1.4907, 1.4904, 0, 0, 0, -0.1, -0.1);
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(420));
  this.instance_1 = new lib.black_plate();
  this.instance_1.parent = this;
  this.timeline.addTween(cjs.Tween.get(this.instance_1).to({
   alpha: 0
  }, 14, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(389).to({
   _off: false
  }, 0).to({
   alpha: 1
  }, 15, cjs.Ease.get(-1)).wait(1));
  this.instance_2 = new lib.legal_01();
  this.instance_2.parent = this;
  this.instance_2.setTransform(120, 200, 1, 1, 0, 0, 0, 120, 200);
  this.instance_2.alpha = 0;
  this.instance_2._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(307).to({
   _off: false
  }, 0).to({
   alpha: 1
  }, 15).wait(98));
  this.cvr_link2_nocatch = new lib.btn1();
  window.cvrTrackButtons[2] = {
   cnvs: this.cvr_link2_nocatch
  };
  this.cvr_link2_nocatch.name = "cvr_link2_nocatch";
  this.cvr_link2_nocatch.parent = this;
  this.cvr_link2_nocatch.setTransform(712.85, 232.3, 0.8051, 0.8051);
  this.cvr_link2_nocatch.alpha = 0;
  this.cvr_link2_nocatch._off = true;
  new cjs.ButtonHelper(this.cvr_link2_nocatch, 0, 1, 2, false, new lib.btn1(), 3);
  this.timeline.addTween(cjs.Tween.get(this.cvr_link2_nocatch).wait(234).to({
   _off: false
  }, 0).to({
   y: 184,
   alpha: 1
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 73).wait(98));
  this.instance_3 = new lib.txt_2_top("synched", 0, false);
  this.instance_3.parent = this;
  this.instance_3._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(212).to({
   _off: false
  }, 0).to({
   _off: true
  }, 110).wait(98));
  this.instance_4 = new lib.txt_1_top("synched", 0, false);
  this.instance_4.parent = this;
  this.instance_4._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(34).to({
   _off: false
  }, 0).wait(170).to({
   startPosition: 14
  }, 0).to({
   alpha: 0
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(200));
  this.instance_5 = new lib.lines_red_bottom("synched", 0, false);
  this.instance_5.parent = this;
  this.instance_5.setTransform(66.5, 0, 1, 1, 0, 0, 0, 66.5, 0);
  this.instance_5._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(219).to({
   _off: false
  }, 0).to({
   _off: true
  }, 103).wait(98));
  this.instance_6 = new lib.lines_red("synched", 0, false);
  this.instance_6.parent = this;
  this.instance_6.setTransform(66.5, 0, 1, 1, 0, 0, 0, 66.5, 0);
  this.instance_6._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(219).to({
   _off: false
  }, 0).to({
   _off: true
  }, 103).wait(98));
  this.instance_7 = new lib.txt_4("synched", 0, false);
  this.instance_7.parent = this;
  this.instance_7.setTransform(66, -8.5, 1, 1, 0, 0, 0, 66, 11.5);
  this.instance_7._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(224).to({
   _off: false
  }, 0).to({
   _off: true
  }, 98).wait(98));
  this.instance_8 = new lib.gray_plate();
  this.instance_8.parent = this;
  this.instance_8.setTransform(68.2, 48.2, 1, 1, 0, 0, 0, 48.2, 48.2);
  this.instance_8.alpha = 0;
  this.instance_8._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(219).to({
   _off: false
  }, 0).to({
   x: 48.2,
   alpha: 1
  }, 10, cjs.Ease.get(1)).to({
   _off: true
  }, 93).wait(98));
  this.instance_9 = new lib.txt_3_bottom("synched", 0, false);
  this.instance_9.parent = this;
  this.instance_9._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(149).to({
   _off: false
  }, 0).wait(55).to({
   startPosition: 14
  }, 0).to({
   alpha: 0
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(200));
  this.instance_10 = new lib.txt_2_bottom("synched", 0, false);
  this.instance_10.parent = this;
  this.instance_10._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(89).to({
   _off: false
  }, 0).wait(55).to({
   startPosition: 14
  }, 0).to({
   alpha: 0
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(260));
  this.instance_11 = new lib.txt_1_bottom("synched", 0, false);
  this.instance_11.parent = this;
  this.instance_11._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(49).to({
   _off: false
  }, 0).wait(35).to({
   startPosition: 14
  }, 0).to({
   alpha: 0
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(320));
  this.instance_12 = new lib.plate_red();
  this.instance_12.parent = this;
  this.instance_12.setTransform(53.2, 129.2, 1, 1, 0, 0, 0, 93.2, 129.2);
  this.instance_12.alpha = 0;
  this.instance_12._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(27).to({
   _off: false
  }, 0).to({
   x: 93.2,
   alpha: 1
  }, 7, cjs.Ease.get(1)).to({
   _off: true
  }, 288).wait(98));
  this.instance_13 = new lib.pic4("synched", 0, false);
  this.instance_13.parent = this;
  this.instance_13.setTransform(180, 300, 1, 1, 0, 0, 0, 180, 300);
  this.instance_13.alpha = 0;
  this.instance_13._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(204).to({
   _off: false
  }, 0).to({
   alpha: 1,
   startPosition: 14
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 103).wait(98));
  this.instance_14 = new lib.pic3_2("synched", 0, false);
  this.instance_14.parent = this;
  this.instance_14.setTransform(180, 300, 1, 1, 0, 0, 0, 180, 300);
  this.instance_14.alpha = 0;
  this.instance_14._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(144).to({
   _off: false
  }, 0).to({
   alpha: 1,
   startPosition: 15
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 61).wait(200));
  this.instance_15 = new lib.pic2_2("synched", 0, false);
  this.instance_15.parent = this;
  this.instance_15.setTransform(180, 300, 1, 1, 0, 0, 0, 180, 300);
  this.instance_15.alpha = 0;
  this.instance_15._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(84).to({
   _off: false
  }, 0).to({
   alpha: 1,
   startPosition: 15
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 61).wait(260));
  this.instance_16 = new lib.pic1_2("synched", 0, false);
  this.instance_16.parent = this;
  this.instance_16.setTransform(180, 300, 1, 1, 0, 0, 0, 180, 300);
  this.timeline.addTween(cjs.Tween.get(this.instance_16).to({
   _off: true
  }, 100).wait(320));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(-242, -62, 1455, 758);
 (lib.toyota_970x250 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.content();
  this.instance.parent = this;
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));
  this.instance_1 = new lib.black_plate();
  this.instance_1.parent = this;
  this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(243, 63, 970, 250);
 lib.properties = {
  id: '1E4D562F91EE4B408F0AC49B20246D76',
  width: 970,
  height: 250,
  fps: 24,
  color: "#FFFFFF",
  opacity: 1.00,
  manifest: [{
   src: "t3_bottom_b_3.png",
   id: "t3_bottom_b_3"
  }, {
   src: "t2_top_t_2.png",
   id: "t2_top_t_2"
  }, {
   src: "t2_bottom_b_2.png",
   id: "t2_bottom_b_2"
  }, {
   src: "t1_top_t_1.png",
   id: "t1_top_t_1"
  }, {
   src: "t1_bottom_b_1.png",
   id: "t1_bottom_b_1"
  }, {
   src: "legal_01_d1.png",
   id: "legal_01_d1"
  }, {
   src: "pic3_1_1_i_3.jpg",
   id: "pic3_1_1_i_3"
  }, {
   src: "pic2_1_1_i_2.jpg",
   id: "pic2_1_1_i_2"
  }, {
   src: "pic1_1_1_i_1.jpg",
   id: "pic1_1_1_i_1"
  }, ],
  preloads: []
 };
 (lib.Stage = function(canvas) {
  createjs.Stage.call(this, canvas);
 }).prototype = p = new createjs.Stage();
 p.setAutoPlay = function(autoPlay) {
  this.tickEnabled = autoPlay;
 }
 p.play = function() {
  this.tickEnabled = true;
  this.getChildAt(0).gotoAndPlay(this.getTimelinePosition())
 }
 p.stop = function(ms) {
  if (ms) this.seek(ms);
  this.tickEnabled = false;
 }
 p.seek = function(ms) {
  this.tickEnabled = true;
  this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000);
 }
 p.getDuration = function() {
  return this.getChildAt(0).totalFrames / lib.properties.fps * 1000;
 }
 p.getTimelinePosition = function() {
  return this.getChildAt(0).currentFrame / lib.properties.fps * 1000;
 }
 an.bootcompsLoaded = an.bootcompsLoaded || [];
 if (!an.bootstrapListeners) {
  an.bootstrapListeners = [];
 }
 an.bootstrapCallback = function(fnCallback) {
  an.bootstrapListeners.push(fnCallback);
  if (an.bootcompsLoaded.length > 0) {
   for (var i = 0; i < an.bootcompsLoaded.length; ++i) {
    fnCallback(an.bootcompsLoaded[i]);
   }
  }
 };
 an.compositions = an.compositions || {};
 an.compositions['1E4D562F91EE4B408F0AC49B20246D76'] = {
  getStage: function() {
   return exportRoot.getStage();
  },
  getLibrary: function() {
   return lib;
  },
  getSpriteSheet: function() {
   return ss;
  },
  getImages: function() {
   return img;
  }
 };
 an.compositionLoaded = function(id) {
  an.bootcompsLoaded.push(id);
  for (var j = 0; j < an.bootstrapListeners.length; j++) {
   an.bootstrapListeners[j](id);
  }
 }
 an.getComposition = function(id) {
  return an.compositions[id];
 }
 an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {
  var lastW, lastH, lastS = 1;
  window.addEventListener('resize', resizeCanvas);
  resizeCanvas();

  function resizeCanvas() {
   var w = lib.properties.width,
    h = lib.properties.height;
   var iw = window.innerWidth,
    ih = window.innerHeight;
   var pRatio = window.devicePixelRatio || 1,
    xRatio = iw / w,
    yRatio = ih / h,
    sRatio = 1;
   if (isResp) {
    if ((respDim == 'width' && lastW == iw) || (respDim == 'height' && lastH == ih)) {
     sRatio = lastS;
    } else if (!isScale) {
     if (iw < w || ih < h) sRatio = Math.min(xRatio, yRatio);
    } else if (scaleType == 1) {
     sRatio = Math.min(xRatio, yRatio);
    } else if (scaleType == 2) {
     sRatio = Math.max(xRatio, yRatio);
    }
   }
   domContainers[0].width = w * pRatio * sRatio;
   domContainers[0].height = h * pRatio * sRatio;
   domContainers.forEach(function(container) {
    container.style.width = w * sRatio + 'px';
    container.style.height = h * sRatio + 'px';
   });
   stage.scaleX = pRatio * sRatio;
   stage.scaleY = pRatio * sRatio;
   lastW = iw;
   lastH = ih;
   lastS = sRatio;
   stage.tickOnUpdate = false;
   stage.update();
   stage.tickOnUpdate = true;
  }
 }
})(createjs = createjs || {}, AdobeAn = AdobeAn || {});
var createjs, AdobeAn;