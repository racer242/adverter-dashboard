(function(cjs, an) {
 var p;
 var lib = {};
 var ss = {};
 var img = {};
 lib.ssMetadata = [];

 function mc_symbol_clone() {
  var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
  clone.gotoAndStop(this.currentFrame);
  clone.paused = this.paused;
  clone.framerate = this.framerate;
  return clone;
 }

 function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
  var prototype = cjs.extend(symbol, cjs.MovieClip);
  prototype.clone = mc_symbol_clone;
  prototype.nominalBounds = nominalBounds;
  prototype.frameBounds = frameBounds;
  return prototype;
 }
 (lib.t3_bottom_b_3 = function() {
  this.initialize(img.t3_bottom_b_3);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 283, 100);
 (lib.t3_bottom = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_b_3 = new lib.t3_bottom_b_3();
  this.cvr_b_3.name = "cvr_b_3";
  this.cvr_b_3.parent = this;
  this.cvr_b_3.setTransform(14, 480, 0.5, 0.5);
  this.timeline.addTween(cjs.Tween.get(this.cvr_b_3).wait(1));
  this.timeline.addTween(cjs.Tween.get(this.cvr_b_3).wait(1));
 }).prototype = getMCSymbolPrototype(lib.t3_bottom, new cjs.Rectangle(12, 478, 287, 117.89999999999998), null);
 (lib.t2_top_t_2 = function() {
  this.initialize(img.t2_top_t_2);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 200, 60);
 (lib.t2_top = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_t_2 = new lib.t2_top_t_2();
  this.cvr_t_2.name = "cvr_t_2";
  this.cvr_t_2.parent = this;
  this.cvr_t_2.setTransform(13.5, 4, 0.5, 0.5);
  this.timeline.addTween(cjs.Tween.get(this.cvr_t_2).wait(1));
  this.timeline.addTween(cjs.Tween.get(this.cvr_t_2).wait(1));
 }).prototype = getMCSymbolPrototype(lib.t2_top, new cjs.Rectangle(11.5, 2, 203.9, 107.9), null);
 (lib.t2_bottom_b_2 = function() {
  this.initialize(img.t2_bottom_b_2);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 283, 100);
 (lib.t2_bottom = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_b_2 = new lib.t2_bottom_b_2();
  this.cvr_b_2.name = "cvr_b_2";
  this.cvr_b_2.parent = this;
  this.cvr_b_2.setTransform(14, 480, 0.5, 0.5);
  this.timeline.addTween(cjs.Tween.get(this.cvr_b_2).wait(1));
  this.timeline.addTween(cjs.Tween.get(this.cvr_b_2).wait(1));
 }).prototype = getMCSymbolPrototype(lib.t2_bottom, new cjs.Rectangle(12, 478, 287, 117.89999999999998), null);
 (lib.t1_top_t_1 = function() {
  this.initialize(img.t1_top_t_1);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 200, 90);
 (lib.t1_top = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_t_1 = new lib.t1_top_t_1();
  this.cvr_t_1.name = "cvr_t_1";
  this.cvr_t_1.parent = this;
  this.cvr_t_1.setTransform(13.5, 4, 0.5, 0.5);
  this.timeline.addTween(cjs.Tween.get(this.cvr_t_1).wait(1));
  this.timeline.addTween(cjs.Tween.get(this.cvr_t_1).wait(1));
 }).prototype = getMCSymbolPrototype(lib.t1_top, new cjs.Rectangle(11.5, 2, 203.9, 107.9), null);
 (lib.t1_bottom_b_1 = function() {
  this.initialize(img.t1_bottom_b_1);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 283, 100);
 (lib.t1_bottom = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_b_1 = new lib.t1_bottom_b_1();
  this.cvr_b_1.name = "cvr_b_1";
  this.cvr_b_1.parent = this;
  this.cvr_b_1.setTransform(14, 480, 0.5, 0.5);
  this.timeline.addTween(cjs.Tween.get(this.cvr_b_1).wait(1));
  this.timeline.addTween(cjs.Tween.get(this.cvr_b_1).wait(1));
 }).prototype = getMCSymbolPrototype(lib.t1_bottom, new cjs.Rectangle(12, 478, 287, 117.89999999999998), null);
 (lib.t_4_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#FFFFFF").s().p("ABABrIh/ixIAACxIgVAAIAAjVIAVAAIB+CxIAAixIAXAAIAADVg");
  this.shape.setTransform(205.7, 147.2);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#FFFFFF").s().p("AgKBrIAAhWIhMh/IAaAAIA9BqIA/hqIAXAAIhMB/IAABWg");
  this.shape_1.setTransform(187.3, 147.2);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#FFFFFF").s().p("AhEBrIAAjVIA8AAQAdABAQAPQARAOAAAYQAAAPgGAMQgHAMgPAJQATAEAMANQALANABAUQgBATgHANQgJANgOAIQgOAHgWABgAgtBXIAtAAQAWAAAMgMQAMgKAAgTQAAgSgLgKQgMgJgSAAIgyAAgAgtgJIAmAAQAMgBAJgFQAJgGAFgIQAFgKAAgLQAAgQgMgKQgKgKgUAAIgkAAg");
  this.shape_2.setTransform(171.95, 147.2);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#FFFFFF").s().p("AhYDFQgggdgOgzQgNgyAAhCQAAhBAOgzQANgzAggdQAhgeA3gBQA4ABAhAeQAgAdAOA0QANAyAABBQAABCgOAyQgNAzghAdQggAdg4ABQg3gBghgdgAg2iTQgTAXgGAnQgGAnABAuQgBAwAGAnQAGAmATAXQASAWAkAAQAlAAATgWQASgYAGgmQAHgmgBgwQABgugHgnQgGgngTgXQgSgWglgBQgkABgSAWg");
  this.shape_3.setTransform(136.375, 157.85);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#FFFFFF").s().p("AhYDFQgggdgOgzQgNgyAAhCQAAhBAOgzQANgzAggdQAhgeA3gBQA4ABAhAeQAgAdAOA0QANAyAABBQAABCgOAyQgNAzghAdQggAdg4ABQg3gBghgdgAg2iTQgTAXgGAnQgGAnABAuQgBAwAGAnQAGAmATAXQASAWAkAAQAlAAATgWQASgYAGgmQAHgmgBgwQABgugHgnQgGgngTgXQgSgWglgBQgkABgSAWg");
  this.shape_4.setTransform(105.025, 157.85);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#FFFFFF").s().p("AhgDcICvmAIjgAAIAAg3IEjAAIAAAlIiwGSg");
  this.shape_5.setTransform(73.5, 157.85);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#FFFFFF").s().p("AhaDRQgkgQgUgaIAegzQAWAZAbAPQAbAPAkAAQApgBAYgVQAZgVAAgkQAAgnghgUQgggTg5AAIAAgyQAkgBAYgKQAXgLAKgRQALgRAAgTQgBgbgSgQQgSgQghgBQggABgaAOQgaAPgVAUIgbgwQAPgPAUgMQAUgNAZgIQAagIAfgBQAlABAcANQAdANAPAYQAQAYABAfQgBAlgVAbQgVAbgpANQAzAMAZAcQAaAdAAArQAAAmgTAdQgTAegiAQQgiARgsABQgzgBgkgRg");
  this.shape_6.setTransform(31.775, 157.875);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
 }).prototype = getMCSymbolPrototype(lib.t_4_1, new cjs.Rectangle(12, 105.5, 406.6, 92.4), null);
 (lib.t_4 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#000000").s().p("AAgA5IAAg0Ig/AAIAAA0IgMAAIAAhxIAMAAIAAAzIA/AAIAAgzIAMAAIAABxg");
  this.shape.setTransform(216.125, 112.975);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#000000").s().p("AAiA5IAAheIhDBeIgMAAIAAhxIANAAIAABeIBCheIALAAIAABxg");
  this.shape_1.setTransform(204.55, 112.975);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#000000").s().p("AgaAFIAAgJIA2AAIAAAJg");
  this.shape_2.setTransform(195.5, 114.3);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#000000").s().p("AAoBGIAAgbIhPAAIAAAbIgLAAIAAgmIAHAAQADAAADgDQADgEACgFIADgPIAIhKIA7AAIAABlIANAAIAAAmgAgRAGQgBALgDAHQgCAGgDACIA0AAIAAhaIgkAAg");
  this.shape_3.setTransform(187.05, 114.3);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#000000").s().p("AAiBHIAAheIhDBeIgMAAIAAhwIANAAIAABeIBCheIALAAIAABwgAgRg5QgGgEAAgJIAJAAQAAAFAEADQAFACAFAAQAHAAAEgDQAEgCABgFIAIAAQgBAJgGAEQgHAFgKAAQgKAAgHgFg");
  this.shape_4.setTransform(176.3, 111.525);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#000000").s().p("AgfA5IAAhxIA+AAIAAALIgyAAIAAAoIAwAAIAAAKIgwAAIAAApIAzAAIAAALg");
  this.shape_5.setTransform(166.375, 112.975);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#000000").s().p("AgiA5IAAhxIAfAAQAMAAAJAFQAIAEAEAIQAFAHAAALQAAAKgFAIQgEAHgIAFQgJAFgMAAIgTAAIAAArgAgWAEIASAAQAHAAAGgDQAGgCAEgGQADgGAAgIQAAgJgDgFQgEgGgGgCQgGgCgHAAIgSAAg");
  this.shape_6.setTransform(158.05, 112.975);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#000000").s().p("AgFA5IAAhmIggAAIAAgLIBLAAIAAALIggAAIAABmg");
  this.shape_7.setTransform(149.425, 112.975);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#000000").s().p("AgdAzQgOgIgHgNQgIgNAAgRQAAgQAIgNQAHgNAOgIQANgHAQAAQARAAANAHQAOAIAHANQAIANAAAQQAAARgIANQgHANgOAIQgNAHgRAAQgQAAgNgHgAgXgoQgLAGgGALQgGAKAAANQAAAOAGAKQAGALALAGQAKAGANAAQAOAAAKgGQALgGAGgLQAGgKAAgOQAAgNgGgKQgGgLgLgGQgKgGgOAAQgNAAgKAGg");
  this.shape_8.setTransform(135.475, 112.975);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#000000").s().p("AAfA5IAAhmIg9AAIAABmIgMAAIAAhxIBVAAIAABxg");
  this.shape_9.setTransform(123.175, 112.975);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.f("#000000").s().p("AAiBHIAAheIhDBeIgLAAIAAhwIALAAIAABeIBEheIALAAIAABwgAgQg5QgHgEgBgJIAKAAQAAAFAFADQADACAHAAQAGAAAEgDQAEgCABgFIAIAAQAAAJgHAEQgGAFgKAAQgMAAgFgFg");
  this.shape_10.setTransform(108.2, 111.525);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.f("#000000").s().p("AgdAzQgOgIgHgNQgIgNAAgRQAAgQAIgNQAHgNAOgIQANgHAQAAQARAAANAHQAOAIAHANQAIANAAAQQAAARgIANQgHANgOAIQgNAHgRAAQgQAAgNgHgAgXgoQgLAGgGALQgGAKAAANQAAAOAGAKQAGALALAGQAKAGANAAQAOAAAKgGQALgGAGgLQAGgKAAgOQAAgNgGgKQgGgLgLgGQgKgGgOAAQgNAAgKAGg");
  this.shape_11.setTransform(95.725, 112.975);
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.f("#000000").s().p("AAoBGIAAgbIhPAAIAAAbIgLAAIAAgmIAHAAQADAAADgDQADgEACgFIADgPIAIhKIA6AAIAABlIAOAAIAAAmgAgSAGQgBALgCAHQgDAGgDACIA1AAIAAhaIgkAAg");
  this.shape_12.setTransform(83.85, 114.3);
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.f("#000000").s().p("AgdAzQgOgIgHgNQgIgNAAgRQAAgQAIgNQAHgNAOgIQANgHAQAAQARAAANAHQAOAIAHANQAIANAAAQQAAARgIANQgHANgOAIQgNAHgRAAQgQAAgNgHgAgXgoQgLAGgGALQgGAKAAANQAAAOAGAKQAGALALAGQAKAGANAAQAOAAAKgGQALgGAGgLQAGgKAAgOQAAgNgGgKQgGgLgLgGQgKgGgOAAQgNAAgKAGg");
  this.shape_13.setTransform(72.325, 112.975);
  this.shape_14 = new cjs.Shape();
  this.shape_14.graphics.f("#000000").s().p("AgeA5IAAhxIA9AAIAAALIgxAAIAABmg");
  this.shape_14.setTransform(62.525, 112.975);
  this.shape_15 = new cjs.Shape();
  this.shape_15.graphics.f("#000000").s().p("AAqA5IAAhxIANAAIAABxgAg2A5IAAhxIAMAAIAAAxIAaAAQARAAAJAHQAJAJAAAOQAAAKgEAIQgEAHgIAFQgHAEgMAAgAgqAuIAXAAQAOAAAFgGQAGgFAAgMQABgKgHgGQgGgFgNAAIgXAAg");
  this.shape_15.setTransform(51.3, 112.975);
  this.shape_16 = new cjs.Shape();
  this.shape_16.graphics.f("#000000").s().p("AgjA5IAAhxIAfAAQAPAAAJAIQAJAIAAANQAAAIgDAGQgEAHgJAEQAMACAFAHQAHAHAAALQAAAJgFAIQgEAHgIAEQgIAEgKAAgAgYAuIAZAAQALAAAHgGQAFgGAAgKQAAgJgFgFQgHgFgJAAIgbAAgAgYgFIAVAAQAFAAAGgDQAFgDACgEQADgFAAgGQgBgJgGgFQgFgFgLAAIgTAAg");
  this.shape_16.setTransform(40.25, 112.975);
  this.shape_17 = new cjs.Shape();
  this.shape_17.graphics.f("#000000").s().p("AgUAzQgNgIgIgNQgHgNAAgRQAAgQAIgOQAHgNANgHQAOgHAQAAQALAAAJADQAKADAIAGIgFAMQgGgGgJgEQgJgDgJAAQgNAAgKAGQgLAGgGALQgGAKAAANQAAANAGALQAGALALAGQAKAGANAAQALAAAJgEQAJgDAHgGIADALQgIAHgKADQgKADgMAAQgQAAgNgHg");
  this.shape_17.setTransform(26.475, 112.975);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_17
   }, {
    t: this.shape_16
   }, {
    t: this.shape_15
   }, {
    t: this.shape_14
   }, {
    t: this.shape_13
   }, {
    t: this.shape_12
   }, {
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
  this.shape_18 = new cjs.Shape();
  this.shape_18.graphics.f("#FFFFFF").s().p("AweB4IAAjvMAg9AAAIAADvg");
  this.shape_18.setTransform(122, 114);
  this.timeline.addTween(cjs.Tween.get(this.shape_18).wait(1));
 }).prototype = getMCSymbolPrototype(lib.t_4, new cjs.Rectangle(16.5, 98, 211, 28), null);
 (lib.plate_red = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.rf(["#EC0A1F", "#61141E", "#000000"], [0, 0.561, 1], 19.1, -7.5, 0, 19.7, -7.1, 162.9).s().p("AyK5LMAkVAAAMgkVAyXg");
  this.shape.setTransform(116.325, 161.225);
  this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("rgba(108,110,111,0.247)").s().p("EgbBgliMA2DAAAMg2DBLFg");
  this.shape_1.setTransform(172.975, 240.275);
  this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));
 }).prototype = getMCSymbolPrototype(lib.plate_red, new cjs.Rectangle(0, 0, 346, 480.6), null);
 (lib.pic3_1_1_i_3 = function() {
  this.initialize(img.pic3_1_1_i_3);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 720, 1200);
 (lib.pic3_1_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_i_3 = new lib.pic3_1_1_i_3();
  this.cvr_i_3.name = "cvr_i_3";
  this.cvr_i_3.parent = this;
  this.cvr_i_3.setTransform(0, 0, 0.5, 0.5);
  this.timeline.addTween(cjs.Tween.get(this.cvr_i_3).wait(1));
 }).prototype = getMCSymbolPrototype(lib.pic3_1_1, new cjs.Rectangle(0, 0, 360, 600), null);
 (lib.pic2_1_1_i_2 = function() {
  this.initialize(img.pic2_1_1_i_2);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 720, 1200);
 (lib.pic2_1_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_i_2 = new lib.pic2_1_1_i_2();
  this.cvr_i_2.name = "cvr_i_2";
  this.cvr_i_2.parent = this;
  this.cvr_i_2.setTransform(0, 0, 0.5, 0.5);
  this.timeline.addTween(cjs.Tween.get(this.cvr_i_2).wait(1));
 }).prototype = getMCSymbolPrototype(lib.pic2_1_1, new cjs.Rectangle(0, 0, 360, 600), null);
 (lib.pic1_1_1_i_1 = function() {
  this.initialize(img.pic1_1_1_i_1);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 600, 1200);
 (lib.pic1_1_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_i_1 = new lib.pic1_1_1_i_1();
  this.cvr_i_1.name = "cvr_i_1";
  this.cvr_i_1.parent = this;
  this.cvr_i_1.setTransform(0, 0, 0.75, 0.75);
  this.timeline.addTween(cjs.Tween.get(this.cvr_i_1).wait(1));
 }).prototype = getMCSymbolPrototype(lib.pic1_1_1, new cjs.Rectangle(0, 0, 450, 900), null);
 (lib.logo_s = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#FFFFFF").s().p("AiNBcQg7gmAAg2QAAg1A7gmQA6gmBTAAQBUAAA6AmQA7AmAAA1QAAA2g7AmQg6AmhUAAQhTAAg6gmgACVg9QAAAagrATQgZALgfAFIAAAEQAAAxgPAhQgJAVgKAIQA7gEAugeQAZgRANgWQAOgWAAgYQAAgYgNgVQgEgIgHgHIAAADgAifgxQgNAVAAAYQAAAYAOAWQANAWAZARQAZAQAeAKQAYAGAaACQgLgIgIgVQgPghAAgxIAAgEQgegFgagLQgrgTAAgaIAAgCIgLAOgAgVAzQAJAXAMgBQANABAJgXQAIgVABgdQgPACgQgBQgPABgPgCQABAdAIAVgAgVg6QgFANgCAOIAcACIAdgCQgCgOgFgNQgJgWgNAAQgMAAgJAWgAAjhMQAIATAEAYQATgDAQgGQAigMAAgRQAAgRgigMQgNgEgPgDIgNgCIgmgDIgDAAIgDAAIgtAEIgJABIgYAHQgiAMAAARQAAARAiAMQAQAHATACQADgYAJgTQAOgiAUAAQAVAAAOAig");
  this.shape.setTransform(20.125, 13);
  this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
 }).prototype = getMCSymbolPrototype(lib.logo_s, new cjs.Rectangle(0, 0, 40.3, 26), null);
 (lib.line_red_large = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f().s("#FF0022").ss(2, 1, 1).p("AqdO1IU79p");
  this.shape.setTransform(67, -36);
  this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
 }).prototype = getMCSymbolPrototype(lib.line_red_large, new cjs.Rectangle(-1, -131.9, 136, 191.9), null);
 (lib.line_red = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f().s("#FF0022").ss(2, 1, 1).p("AjNEnIGbpN");
  this.shape.setTransform(20.55, 29.475);
  this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
 }).prototype = getMCSymbolPrototype(lib.line_red, new cjs.Rectangle(-1, -1, 43.1, 61), null);
 (lib.legal_01_d1 = function() {
  this.initialize(img.legal_01_d1);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 269, 196);
 (lib.legal_01 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_d1 = new lib.legal_01_d1();
  this.cvr_d1.name = "cvr_d1";
  this.cvr_d1.parent = this;
  this.cvr_d1.setTransform(16, 68, 0.5, 0.5);
  this.timeline.addTween(cjs.Tween.get(this.cvr_d1).wait(1));
  this.timeline.addTween(cjs.Tween.get(this.cvr_d1).wait(1));
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#1E1C1E").s().p("AyvfQMAAAg+fMAlfAAAMAAAA+fg");
  this.shape.setTransform(150, 299.9969, 1.25, 1.5);
  this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
 }).prototype = getMCSymbolPrototype(lib.legal_01, new cjs.Rectangle(0, 0, 300, 600), null);
 (lib.gray_plate = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.lf(["#BCBCBC", "#1A1F20"], [0, 1], -36.4, 19.4, 33.6, -50.6).s().p("AnuKpIPd1RIAAVRg");
  this.shape.setTransform(251.5, 531.85);
  this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
 }).prototype = getMCSymbolPrototype(lib.gray_plate, new cjs.Rectangle(202, 463.8, 99, 136.09999999999997), null);
 (lib.btn1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#FFFFFF").s().p("AgoBHIAAiNIBQAAIAAASIg8AAIAAAsIA6AAIAAARIg6AAIAAAsIA9AAIAAASg");
  this.shape.setTransform(228.425, 25.2);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#FFFFFF").s().p("AhdBHIAAiNIAUAAIAAB7IBAAAIAAh7IATAAIAAB7IA/AAIAAh7IAVAAIAACNg");
  this.shape_1.setTransform(211.3, 25.2);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#FFFFFF").s().p("AgvBHIAAiNIAUAAIAAA7IAdAAQAPAAALAFQALAFAEAIQAFAJABAMQgBAMgFAKQgEAKgLAGQgLAFgPAAgAgbA1IAaAAQAOAAAHgFQAHgHAAgMQAAgMgIgGQgHgGgNAAIgaAAg");
  this.shape_2.setTransform(194.55, 25.2);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#FFFFFF").s().p("Ag0BHIgGgCIADgSIAEACIAGABQAFAAADgEQADgFAAgKIALhqIBSAAIAACNIgUAAIAAh7IgsAAIgJBeQgCAQgGAHQgIAIgNAAIgJgBg");
  this.shape_3.setTransform(180.15, 25.275);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#FFFFFF").s().p("AglBAQgRgKgJgQQgKgQAAgWQAAgVAKgQQAJgQARgKQARgJAUAAQAVAAARAJQAQAKAKAQQAKAQAAAVQAAAVgKARQgKAQgQAKQgRAJgVAAQgUAAgRgJgAgaguQgMAIgHALQgHAMAAAPQAAAQAHAMQAHALAMAIQAMAGAOAAQAPAAANgGQAMgIAGgLQAHgMAAgQQAAgPgHgMQgGgLgMgIQgNgGgPAAQgOAAgMAGg");
  this.shape_4.setTransform(165.9, 25.2);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#FFFFFF").s().p("AgvBHIAAiNIBOAAIAAATIg6AAIAAAoIAdAAQAPAAALAFQALAFAEAIQAFAJABAMQgBAMgFAKQgEAKgLAGQgLAFgPAAgAgbA1IAaAAQAOAAAHgFQAIgHgBgMQAAgMgIgGQgHgGgNAAIgaAAg");
  this.shape_5.setTransform(151.9, 25.2);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#FFFFFF").s().p("AgwBHIAAiNIAVAAIAAA7IAdAAQAPAAALAFQALAFAEAIQAGAJAAAMQAAAMgGAKQgEAKgLAGQgLAFgPAAgAgbA1IAaAAQAOAAAHgFQAIgHAAgMQgBgMgHgGQgIgGgNAAIgaAAg");
  this.shape_6.setTransform(135, 25.2);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#FFFFFF").s().p("AgJBHIAAh7IgnAAIAAgSIBhAAIAAASIgnAAIAAB7g");
  this.shape_7.setTransform(123.1, 25.2);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#FFFFFF").s().p("AArBHIgQgrIg2AAIgQArIgVAAIA2iNIAVAAIA2CNgAAVALIgVg6IgVA6IAqAAg");
  this.shape_8.setTransform(111.125, 25.2);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#FFFFFF").s().p("AAkBHIAAg+IhIAAIAAA+IgUAAIAAiNIAUAAIAAA+IBIAAIAAg+IAVAAIAACNg");
  this.shape_9.setTransform(96.9, 25.2);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.f("#FFFFFF").s().p("AgfBEQgMgFgIgIIAKgQQAHAGAKAFQAKAFANAAQAOAAAJgGQAIgHABgMQAAgNgLgFQgLgHgXAAIAAgPQAPAAAJgEQAJgEADgEQAEgGAAgGQgBgKgGgFQgHgFgMgBQgLABgJAEQgJAEgGAGIgJgRQAIgGAMgEQALgFAOAAQAVAAAMAJQAMAKAAAQQAAAOgIAIQgHAJgNADQAQACAIAIQAJAJAAAQQAAALgFAKQgHAKgLAFQgMAFgQAAQgSAAgNgFg");
  this.shape_10.setTransform(83.45, 25.2);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.f("#FFFFFF").s().p("AgnBHIgMgDIAFgSIAIAEIAJABQAIAAAFgFQAFgDAFgKIg3hsIAWAAIAqBXIAlhXIAWAAIgvBrIgKATQgFAHgHAFQgIAFgNAAIgLgBg");
  this.shape_11.setTransform(71.725, 25.3);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).to({
   state: []
  }, 3).wait(1));
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.f("rgba(0,0,0,0.247)").s().p("A23D1IFFnpMAoqAAAIlPHpg");
  this.shape_12.setTransform(146.375, 24.5);
  this.shape_12._off = true;
  this.timeline.addTween(cjs.Tween.get(this.shape_12).wait(1).to({
   _off: false
  }, 0).to({
   _off: true
  }, 2).wait(1));
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.lf(["#FF0022", "#B21423"], [0, 1], -146.5, -0.3, 134.1, -0.3).s().p("A23D1IFFnpMAoqAAAIlPHpg");
  this.shape_13.setTransform(146.375, 24.5);
  this.timeline.addTween(cjs.Tween.get(this.shape_13).wait(4));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(0, 0, 292.8, 49);
 (lib.black_plate = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#000000").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
  this.shape.setTransform(150, 300);
  this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
 }).prototype = getMCSymbolPrototype(lib.black_plate, new cjs.Rectangle(0, 0, 300, 600), null);
 (lib.txt_4 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.t_4();
  this.instance.parent = this;
  this.instance.setTransform(66, 31.5, 1, 1, 0, 0, 0, 66, 11.5);
  this.instance.alpha = 0;
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   y: 11.5,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(6));
  this.instance_1 = new lib.t_4_1();
  this.instance_1.parent = this;
  this.instance_1.setTransform(129.2, 57.6, 1, 1, 0, 0, 0, 129.2, 37.6);
  this.instance_1.alpha = 0;
  this.instance_1._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(4).to({
   _off: false
  }, 0).to({
   y: 37.6,
   alpha: 1
  }, 15, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(12, 98, 406.6, 119.9);
 (lib.txt_3_bottom = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.t3_bottom();
  this.instance.parent = this;
  this.instance.setTransform(61.9, 55.5, 1, 1, 0, 0, 0, 101.9, 55.5);
  this.instance.alpha = 0;
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   x: 101.9,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(-28, 478, 327, 117.89999999999998);
 (lib.txt_2_top = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.t2_top();
  this.instance.parent = this;
  this.instance.setTransform(61.9, 55.5, 1, 1, 0, 0, 0, 101.9, 55.5);
  this.instance.alpha = 0;
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   x: 101.9,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(-28.5, 2, 243.9, 107.9);
 (lib.txt_2_bottom = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.t2_bottom();
  this.instance.parent = this;
  this.instance.setTransform(61.9, 55.5, 1, 1, 0, 0, 0, 101.9, 55.5);
  this.instance.alpha = 0;
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   x: 101.9,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(-28, 478, 327, 117.89999999999998);
 (lib.txt_1_top = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.t1_top();
  this.instance.parent = this;
  this.instance.setTransform(61.9, 55.5, 1, 1, 0, 0, 0, 101.9, 55.5);
  this.instance.alpha = 0;
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   x: 101.9,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(-28.5, 2, 243.9, 107.9);
 (lib.txt_1_bottom = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.t1_bottom();
  this.instance.parent = this;
  this.instance.setTransform(61.9, 55.5, 1, 1, 0, 0, 0, 101.9, 55.5);
  this.instance.alpha = 0;
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   x: 101.9,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(-28, 478, 327, 117.89999999999998);
 (lib.pic3_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_i_3 = new lib.pic3_1_1();
  this.cvr_i_3.name = "cvr_i_3";
  this.cvr_i_3.parent = this;
  this.cvr_i_3.setTransform(150, 200, 1, 1, 0, 0, 0, 150, 200);
  this.timeline.addTween(cjs.Tween.get(this.cvr_i_3).wait(1));
 }).prototype = getMCSymbolPrototype(lib.pic3_1, new cjs.Rectangle(0, 0, 360, 600), null);
 (lib.pic3_2 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.pic3_1();
  this.instance.parent = this;
  this.instance.setTransform(180, 300, 1, 1, 0, 0, 0, 180, 300);
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   x: 130
  }, 34, cjs.Ease.get(0.5)).to({
   x: 120
  }, 35, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(-60, 0, 420, 600.1);
 (lib.pic2_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_i_2 = new lib.pic2_1_1();
  this.cvr_i_2.name = "cvr_i_2";
  this.cvr_i_2.parent = this;
  this.cvr_i_2.setTransform(150, 200, 1, 1, 0, 0, 0, 150, 200);
  this.timeline.addTween(cjs.Tween.get(this.cvr_i_2).wait(1));
 }).prototype = getMCSymbolPrototype(lib.pic2_1, new cjs.Rectangle(0, 0, 360, 600), null);
 (lib.pic2_2 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.pic2_1();
  this.instance.parent = this;
  this.instance.setTransform(180, 299.9, 0.9999, 1, 0, 0, 0, 180, 299.9);
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   x: 130
  }, 34, cjs.Ease.get(0.5)).to({
   x: 120
  }, 35, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(-60, 0, 420, 600.1);
 (lib.pic1_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_i_1 = new lib.pic1_1_1();
  this.cvr_i_1.name = "cvr_i_1";
  this.cvr_i_1.parent = this;
  this.cvr_i_1.setTransform(180, 300, 1, 1, 0, 0, 0, 180, 300);
  this.timeline.addTween(cjs.Tween.get(this.cvr_i_1).wait(1));
 }).prototype = getMCSymbolPrototype(lib.pic1_1, new cjs.Rectangle(0, 0, 450, 900), null);
 (lib.pic1_2 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.pic1_1();
  this.instance.parent = this;
  this.instance.setTransform(104.9, 149.9, 1, 1, 0, 0, 0, 179.9, 299.9);
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   regX: 179.8,
   scaleX: 0.771,
   scaleY: 0.771,
   x: 115,
   y: 184.95
  }, 19, cjs.Ease.get(0.5)).to({
   regX: 180,
   regY: 300,
   scaleX: 0.6667,
   scaleY: 0.6667,
   x: 120,
   y: 200
  }, 75, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(-75, -150, 450, 900);
 (lib.lines_red_bottom = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.line_red_large();
  this.instance.parent = this;
  this.instance.setTransform(76.55, 755.4, 1, 1, 0, 0, 0, 20.6, 29.4);
  this.instance.alpha = 0;
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   x: 190.55,
   y: 593.45,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(55, 432.1, 250, 353.9);
 (lib.lines_red = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.line_red();
  this.instance.parent = this;
  this.instance.setTransform(35.35, 182.3, 1, 1, 0, 0, 0, 20.6, 29.4);
  this.instance.alpha = 0;
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   x: 19.35,
   y: 203.3,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(1));
  this.instance_1 = new lib.line_red();
  this.instance_1.parent = this;
  this.instance_1.setTransform(182.55, 2.05, 1, 1, 0, 0, 0, 20.6, 29.4);
  this.instance_1.alpha = 0;
  this.timeline.addTween(cjs.Tween.get(this.instance_1).to({
   x: 194.7,
   y: -15.3,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(-2.2, -45.7, 218.39999999999998, 279.6);
 (lib.pic4 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.pic1_1();
  this.instance.parent = this;
  this.instance.setTransform(104.9, 149.9, 1, 1, 0, 0, 0, 179.9, 299.9);
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   regX: 179.8,
   scaleX: 0.771,
   scaleY: 0.771,
   x: 115,
   y: 184.95
  }, 19, cjs.Ease.get(0.5)).to({
   regX: 180,
   regY: 300,
   scaleX: 0.6667,
   scaleY: 0.6667,
   x: 120,
   y: 200
  }, 75, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(-75, -150, 450, 900);
 (lib.content = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {
   cvr_frame1_3: 83,
   cvr_frame2_2: 143,
   cvr_frame3_1: 203,
   "cvr_frame#4_4": 290,
   cvr_stay: 301,
   cvr_frame5: 402
  });
  this.instance = new lib.logo_s();
  this.instance.parent = this;
  this.instance.setTransform(233.65, 16.75, 1.2422, 1.2404);
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(420));
  this.instance_1 = new lib.black_plate();
  this.instance_1.parent = this;
  this.timeline.addTween(cjs.Tween.get(this.instance_1).to({
   alpha: 0
  }, 14, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(389).to({
   _off: false
  }, 0).to({
   alpha: 1
  }, 15, cjs.Ease.get(-1)).wait(1));
  this.instance_2 = new lib.legal_01();
  this.instance_2.parent = this;
  this.instance_2.setTransform(120, 200, 1, 1, 0, 0, 0, 120, 200);
  this.instance_2.alpha = 0;
  this.instance_2._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(307).to({
   _off: false
  }, 0).to({
   alpha: 1
  }, 15).wait(98));
  this.cvr_link2_nocatch = new lib.btn1();
  window.cvrTrackButtons[2] = {
   cnvs: this.cvr_link2_nocatch
  };
  this.cvr_link2_nocatch.name = "cvr_link2_nocatch";
  this.cvr_link2_nocatch.parent = this;
  this.cvr_link2_nocatch.setTransform(29.85, 576.3, 0.8051, 0.8051);
  this.cvr_link2_nocatch.alpha = 0;
  this.cvr_link2_nocatch._off = true;
  new cjs.ButtonHelper(this.cvr_link2_nocatch, 0, 1, 2, false, new lib.btn1(), 3);
  this.timeline.addTween(cjs.Tween.get(this.cvr_link2_nocatch).wait(234).to({
   _off: false
  }, 0).to({
   y: 528,
   alpha: 1
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 73).wait(98));
  this.instance_3 = new lib.txt_2_top("synched", 0, false);
  this.instance_3.parent = this;
  this.instance_3._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(212).to({
   _off: false
  }, 0).to({
   _off: true
  }, 110).wait(98));
  this.instance_4 = new lib.txt_1_top("synched", 0, false);
  this.instance_4.parent = this;
  this.instance_4._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(34).to({
   _off: false
  }, 0).wait(170).to({
   startPosition: 14
  }, 0).to({
   alpha: 0
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(200));
  this.instance_5 = new lib.lines_red_bottom("synched", 0, false);
  this.instance_5.parent = this;
  this.instance_5.setTransform(66.5, 0, 1, 1, 0, 0, 0, 66.5, 0);
  this.instance_5._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(219).to({
   _off: false
  }, 0).to({
   _off: true
  }, 103).wait(98));
  this.instance_6 = new lib.lines_red("synched", 0, false);
  this.instance_6.parent = this;
  this.instance_6.setTransform(66.5, 0, 1, 1, 0, 0, 0, 66.5, 0);
  this.instance_6._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(219).to({
   _off: false
  }, 0).to({
   _off: true
  }, 103).wait(98));
  this.instance_7 = new lib.txt_4("synched", 0, false);
  this.instance_7.parent = this;
  this.instance_7.setTransform(66, -8.5, 1, 1, 0, 0, 0, 66, 11.5);
  this.instance_7._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(224).to({
   _off: false
  }, 0).to({
   _off: true
  }, 98).wait(98));
  this.instance_8 = new lib.gray_plate();
  this.instance_8.parent = this;
  this.instance_8.setTransform(68.2, 48.2, 1, 1, 0, 0, 0, 48.2, 48.2);
  this.instance_8.alpha = 0;
  this.instance_8._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(219).to({
   _off: false
  }, 0).to({
   x: 48.2,
   alpha: 1
  }, 10, cjs.Ease.get(1)).to({
   _off: true
  }, 93).wait(98));
  this.instance_9 = new lib.plate_red();
  this.instance_9.parent = this;
  this.instance_9.setTransform(53.2, 129.2, 1, 1, 0, 0, 0, 93.2, 129.2);
  this.instance_9.alpha = 0;
  this.instance_9._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(27).to({
   _off: false
  }, 0).to({
   x: 93.2,
   alpha: 1
  }, 7, cjs.Ease.get(1)).to({
   _off: true
  }, 288).wait(98));
  this.instance_10 = new lib.pic4("synched", 0, false);
  this.instance_10.parent = this;
  this.instance_10.setTransform(180, 300, 1, 1, 0, 0, 0, 180, 300);
  this.instance_10.alpha = 0;
  this.instance_10._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(204).to({
   _off: false
  }, 0).to({
   alpha: 1,
   startPosition: 14
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 103).wait(98));
  this.instance_11 = new lib.txt_3_bottom("synched", 0, false);
  this.instance_11.parent = this;
  this.instance_11._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(149).to({
   _off: false
  }, 0).to({
   _off: true
  }, 71).wait(200));
  this.instance_12 = new lib.pic3_2("synched", 0, false);
  this.instance_12.parent = this;
  this.instance_12.setTransform(180, 300, 1, 1, 0, 0, 0, 180, 300);
  this.instance_12.alpha = 0;
  this.instance_12._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(144).to({
   _off: false
  }, 0).to({
   alpha: 1,
   startPosition: 15
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 61).wait(200));
  this.instance_13 = new lib.txt_2_bottom("synched", 0, false);
  this.instance_13.parent = this;
  this.instance_13._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(89).to({
   _off: false
  }, 0).to({
   _off: true
  }, 71).wait(260));
  this.instance_14 = new lib.pic2_2("synched", 0, false);
  this.instance_14.parent = this;
  this.instance_14.setTransform(180, 300, 1, 1, 0, 0, 0, 180, 300);
  this.instance_14.alpha = 0;
  this.instance_14._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(84).to({
   _off: false
  }, 0).to({
   alpha: 1,
   startPosition: 15
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 61).wait(260));
  this.instance_15 = new lib.txt_1_bottom("synched", 0, false);
  this.instance_15.parent = this;
  this.instance_15._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(49).to({
   _off: false
  }, 0).to({
   _off: true
  }, 51).wait(320));
  this.instance_16 = new lib.pic1_2("synched", 0, false);
  this.instance_16.parent = this;
  this.instance_16.setTransform(180, 300, 1, 1, 0, 0, 0, 180, 300);
  this.timeline.addTween(cjs.Tween.get(this.instance_16).to({
   _off: true
  }, 100).wait(320));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(-75, -150, 493.6, 936);
 (lib.toyota_300x600 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.content();
  this.instance.parent = this;
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));
  this.instance_1 = new lib.black_plate();
  this.instance_1.parent = this;
  this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(75, 150, 300, 600);
 lib.properties = {
  id: '1E4D562F91EE4B408F0AC49B20246D76',
  width: 300,
  height: 600,
  fps: 24,
  color: "#FFFFFF",
  opacity: 1.00,
  manifest: [{
   src: "t3_bottom_b_3.png",
   id: "t3_bottom_b_3"
  }, {
   src: "t2_top_t_2.png",
   id: "t2_top_t_2"
  }, {
   src: "t2_bottom_b_2.png",
   id: "t2_bottom_b_2"
  }, {
   src: "t1_top_t_1.png",
   id: "t1_top_t_1"
  }, {
   src: "t1_bottom_b_1.png",
   id: "t1_bottom_b_1"
  }, {
   src: "legal_01_d1.png",
   id: "legal_01_d1"
  }, {
   src: "pic3_1_1_i_3.jpg",
   id: "pic3_1_1_i_3"
  }, {
   src: "pic2_1_1_i_2.jpg",
   id: "pic2_1_1_i_2"
  }, {
   src: "pic1_1_1_i_1.jpg",
   id: "pic1_1_1_i_1"
  }, ],
  preloads: []
 };
 (lib.Stage = function(canvas) {
  createjs.Stage.call(this, canvas);
 }).prototype = p = new createjs.Stage();
 p.setAutoPlay = function(autoPlay) {
  this.tickEnabled = autoPlay;
 }
 p.play = function() {
  this.tickEnabled = true;
  this.getChildAt(0).gotoAndPlay(this.getTimelinePosition())
 }
 p.stop = function(ms) {
  if (ms) this.seek(ms);
  this.tickEnabled = false;
 }
 p.seek = function(ms) {
  this.tickEnabled = true;
  this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000);
 }
 p.getDuration = function() {
  return this.getChildAt(0).totalFrames / lib.properties.fps * 1000;
 }
 p.getTimelinePosition = function() {
  return this.getChildAt(0).currentFrame / lib.properties.fps * 1000;
 }
 an.bootcompsLoaded = an.bootcompsLoaded || [];
 if (!an.bootstrapListeners) {
  an.bootstrapListeners = [];
 }
 an.bootstrapCallback = function(fnCallback) {
  an.bootstrapListeners.push(fnCallback);
  if (an.bootcompsLoaded.length > 0) {
   for (var i = 0; i < an.bootcompsLoaded.length; ++i) {
    fnCallback(an.bootcompsLoaded[i]);
   }
  }
 };
 an.compositions = an.compositions || {};
 an.compositions['1E4D562F91EE4B408F0AC49B20246D76'] = {
  getStage: function() {
   return exportRoot.getStage();
  },
  getLibrary: function() {
   return lib;
  },
  getSpriteSheet: function() {
   return ss;
  },
  getImages: function() {
   return img;
  }
 };
 an.compositionLoaded = function(id) {
  an.bootcompsLoaded.push(id);
  for (var j = 0; j < an.bootstrapListeners.length; j++) {
   an.bootstrapListeners[j](id);
  }
 }
 an.getComposition = function(id) {
  return an.compositions[id];
 }
 an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {
  var lastW, lastH, lastS = 1;
  window.addEventListener('resize', resizeCanvas);
  resizeCanvas();

  function resizeCanvas() {
   var w = lib.properties.width,
    h = lib.properties.height;
   var iw = window.innerWidth,
    ih = window.innerHeight;
   var pRatio = window.devicePixelRatio || 1,
    xRatio = iw / w,
    yRatio = ih / h,
    sRatio = 1;
   if (isResp) {
    if ((respDim == 'width' && lastW == iw) || (respDim == 'height' && lastH == ih)) {
     sRatio = lastS;
    } else if (!isScale) {
     if (iw < w || ih < h) sRatio = Math.min(xRatio, yRatio);
    } else if (scaleType == 1) {
     sRatio = Math.min(xRatio, yRatio);
    } else if (scaleType == 2) {
     sRatio = Math.max(xRatio, yRatio);
    }
   }
   domContainers[0].width = w * pRatio * sRatio;
   domContainers[0].height = h * pRatio * sRatio;
   domContainers.forEach(function(container) {
    container.style.width = w * sRatio + 'px';
    container.style.height = h * sRatio + 'px';
   });
   stage.scaleX = pRatio * sRatio;
   stage.scaleY = pRatio * sRatio;
   lastW = iw;
   lastH = ih;
   lastS = sRatio;
   stage.tickOnUpdate = false;
   stage.update();
   stage.tickOnUpdate = true;
  }
 }
})(createjs = createjs || {}, AdobeAn = AdobeAn || {});
var createjs, AdobeAn;