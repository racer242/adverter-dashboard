(function(cjs, an) {
 var p;
 var lib = {};
 var ss = {};
 var img = {};
 lib.ssMetadata = [];
 (lib.bubble = function() {
  this.initialize(img.bubble);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 448, 448);
 (lib.fish1 = function() {
  this.initialize(img.fish1);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 342, 311);
 (lib.fish2 = function() {
  this.initialize(img.fish2);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 346, 266);
 (lib.icon2 = function() {
  this.initialize(img.icon2);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 170, 172);
 (lib.icon3 = function() {
  this.initialize(img.icon3);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 214, 214);
 (lib.packshot = function() {
  this.initialize(img.packshot);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 352, 170);

 function mc_symbol_clone() {
  var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
  clone.gotoAndStop(this.currentFrame);
  clone.paused = this.paused;
  clone.framerate = this.framerate;
  return clone;
 }

 function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
  var prototype = cjs.extend(symbol, cjs.MovieClip);
  prototype.clone = mc_symbol_clone;
  prototype.nominalBounds = nominalBounds;
  prototype.frameBounds = frameBounds;
  return prototype;
 }
 (lib.t4 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#0C593C").s().p("AAAAKIgKASIgHgGIAKgSIgQgGIACgKIARAHIAAgWIAJAAIAAAWIARgHIACAKIgQAGIAKASIgHAGg");
  this.shape.setTransform(117.375, 154.325);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#0C593C").s().p("AgcBgQgNgFgJgNQgIgLgDgMQgDgMAAgNIAgAAIAAAMQACAGACAFQAEAJAHAEQAGAEAGABIAHAAIAKgBQAFgBAEgDQAHgGACgIQACgGAAgGIgBgIIgCgJQgDgFgFgDQgEgDgFgBIgKAAIgQAAIAAgdIAOAAQAEABAEgBIAIgDQADgCAEgFQADgFAAgJQAAgJgDgFQgCgGgDgCQgGgFgFAAIgHgBIgKABQgFABgFAEQgGAFgDAHQgCAHAAAHIgfAAIABgMQAAgHADgIQADgHAFgHQAIgLANgFQAOgEAQAAIANAAIAPAFQAIADAGAFQAHAHAEAHQADAIABAHIAAALQABAHgCAJQgCAIgHAJIgHAEQgDADgFACIAAABQAGABAEACIAHAEQAHAFADAKQAFAKAAAOQgBARgFAKQgGAMgHAGQgGAFgLADQgLAEgSAAIgCAAQgPAAgLgEg");
  this.shape_1.setTransform(106.3, 161.5498);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#0C593C").s().p("AAnBeIgLgnIg3AAIgLAnIghAAIA5i8IAdAAIA5C8gAAVAaIgVhQIgUBQIApAAg");
  this.shape_2.setTransform(92.525, 161.55);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#0C593C").s().p("Ag8BfIAAi8IA9AAQAOgBAMAEQALADAJALQAJAKACALQADALAAAJQgBARgFALQgEALgGAGQgKAJgMADQgLADgLAAIgcAAIAABGgAgbgCIAYAAIAMgCQAHgBAEgGQADgCADgGQACgFAAgJQAAgIgCgGQgCgGgDgDQgGgGgGgBIgLgCIgZAAg");
  this.shape_3.setTransform(79.5, 161.5469);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#0C593C").s().p("AgcBHQgFgBgFgCQgHgEgFgJQgEgIgBgOQAAgGACgGQABgHAEgGQAEgEAEgEIALgEIANgEIATgDIAGgBQADgBACgDIABgDIABgHQAAgGgBgFQgCgGgEgDQgDgDgDAAIgFgBQgIAAgEAEQgFAEgBAEQgCACgBAFIAAAGIgdAAQAAgGACgHQACgIAEgGQAFgIAHgFQAIgFAIgBIAOgBIAPABQAJACAJAGQAJAIADAJQADAKAAANIAAA2IAAAKIABADQABABAAAAQAAABABAAQAAAAABABQAAAAABAAIAFAAIAAAWIgHABIgJAAIgHgBQgEAAgEgDQgDgCgBgEIgCgHIgBAAIgFAIIgFAFQgFADgGABQgGADgIAAIgLgCgAAOAFIgCABIgGACIgGABIgIADIgGADQgGADgCAFQgCAEAAAFIABAHQABAEADADIAFAEIAGABQAEAAAEgCQAEgDAEgFQAEgIACgIQACgJAAgIIAAgEIgCABg");
  this.shape_4.setTransform(60.625, 164.05);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#0C593C").s().p("AgPBJQgIgBgIgFQgIgGgGgLQgFgLgBgNIAcAAIACAJQABAFADAEQAEAFAFACIAIABIAFgBQAFAAADgDQADgCADgFQACgEAAgHQABgEgCgEQgBgFgFgDQgDgCgEgBIgHgBIgLAAIAAgVIAJAAIAFAAQADgBAEgCQAFgEABgEIABgIQAAgGgCgEQgBgEgDgCIgGgEIgFgBIgIACQgFACgDAFQgDAEAAAFIAAAHIgdAAQABgJADgJQADgJAFgGQAIgIAKgDQAKgDAIAAQAHAAALACQAKADAIAIQAFAFADAHQADAIAAAJQAAAGgCAGQgCAGgEAEQgDAEgDABIgFACIAAABQAEAAAEABQAEACAFAFQADAFACAFQACAFAAAHQgBAJgCAHQgCAHgEAFIgHAHQgIAGgKACQgKACgIAAIgPgBg");
  this.shape_5.setTransform(48.9, 164.1458);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#0C593C").s().p("AgcBHQgFgBgFgDQgHgDgFgIQgEgJgBgOQAAgHACgFQABgHAEgGQAEgFAEgDIALgEIANgDIATgEIAGgBQADgBACgCIABgEIABgHQAAgGgBgFQgCgGgEgDQgDgDgDAAIgFgBQgIABgEADQgFAEgBADQgCAEgBAEIAAAHIgdAAQAAgHACgIQACgGAEgHQAFgJAHgEQAIgFAIAAIAOgCIAPACQAJACAJAFQAJAIADAJQADAKAAANIAAA2IAAAJIABAEQABABAAAAQAAABABAAQAAAAABABQAAAAABAAIAFAAIAAAWIgHABIgJAAIgHgBQgEAAgEgDQgDgDgBgDIgCgHIgBAAIgFAIIgFAFQgFACgGACQgGADgIAAIgLgCgAAOAFIgCABIgGACIgGACIgIACIgGACQgGAEgCAEQgCAFAAAFIABAHQABAEADADIAFADIAGABQAEABAEgCQAEgDAEgGQAEgHACgIQACgJAAgIIAAgEIgCABg");
  this.shape_6.setTransform(118.875, 138.15);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#0C593C").s().p("AgxBFIgFgBIAAgWQAHACAFgDQAFgDACgEIAEgKQABgHABgMIAAghIAAgsIBUAAIAACIIgdAAIAAhyIgbAAIAAAaIAAAVIAAAPIgBAHQgCAOgEAJQgDAIgFAFQgFAFgHADQgHACgJAAIgFAAg");
  this.shape_7.setTransform(106.175, 138.3);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#0C593C").s().p("AgdBdIgIgBIAAgVIAEAAIAFABQAHAAAEgFQAEgEADgIIADgMIgyiIIAgAAIAeBjIABAAIAYhjIAcAAIgpCUIgEAOQgDAHgFAGQgFAIgGABQgGADgIAAIgJgBg");
  this.shape_8.setTransform(95.675, 140.8);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#0C593C").s().p("AgJBJQgHgBgHgEQgHgEgHgIQgHgJgFgNQgEgOAAgUQAAgFABgKQABgKADgLQAEgLAHgIQAIgLALgDQAKgEAJAAQAIAAAKADQAKADAKAJQAHAIAEAJQADAKABAJIgcAAIgCgJIgEgJQgDgFgEgDQgEgCgGgBQgGAAgEAEQgFADgDAHQgDAGgBAHIgCAOIgBAKIACATQABAJAEAJQAEAHAFAEQAFAEAFAAQAHAAAEgEQAEgDADgGIADgNIABgHIAcAAQAAAIgDAKQgDAKgGAIQgJAMgLAEQgKADgKAAIgLgBg");
  this.shape_9.setTransform(84.5938, 138.2464);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.f("#0C593C").s().p("AAWBEIAAhyIgrAAIAAByIgdAAIAAiIIBlAAIAACIg");
  this.shape_10.setTransform(72.35, 138.25);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.f("#0C593C").s().p("AgcBHQgFgBgFgDQgHgDgFgIQgEgJgBgOQAAgHACgFQABgHAEgGQAEgFAEgDIALgEIANgDIATgEIAGgBQADgBACgCIABgEIABgHQAAgGgBgFQgCgGgEgDQgDgDgDAAIgFgBQgIABgEADQgFAEgBADQgCAEgBAEIAAAHIgdAAQAAgHACgIQACgGAEgHQAFgJAHgEQAIgFAIAAIAOgCIAPACQAJACAJAFQAJAIADAJQADAKAAANIAAA2IAAAJIABAEQABABAAAAQAAABABAAQAAAAABABQAAAAABAAIAFAAIAAAWIgHABIgJAAIgHgBQgEAAgEgDQgDgDgBgDIgCgHIgBAAIgFAIIgFAFQgFACgGACQgGADgIAAIgLgCgAAOAFIgCABIgGACIgGACIgIACIgGACQgGAEgCAEQgCAFAAAFIABAHQABAEADADIAFADIAGABQAEABAEgCQAEgDAEgGQAEgHACgIQACgJAAgIIAAgEIgCABg");
  this.shape_11.setTransform(60.175, 138.15);
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.f("#0C593C").s().p("AASBEIgmhCIAABCIgeAAIAAiIIAeAAIAAA5IAjg5IAhAAIgtBAIAvBIg");
  this.shape_12.setTransform(49.6, 138.25);
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.f("#0C593C").s().p("AAnBeIgLgnIg3AAIgLAnIghAAIA5i8IAdAAIA5C8gAAVAaIgVhQIgUBQIApAAg");
  this.shape_13.setTransform(96.975, 109.75);
  this.shape_14 = new cjs.Shape();
  this.shape_14.graphics.f("#0C593C").s().p("AAeBeIAAhVIg7AAIAABVIggAAIAAi8IAgAAIAABMIA7AAIAAhMIAgAAIAAC8g");
  this.shape_14.setTransform(82.625, 109.75);
  this.shape_15 = new cjs.Shape();
  this.shape_15.graphics.f("#0C593C").s().p("AA0B0IAAgrIhoAAIAAArIgbAAIgChHIAOAAIAGgLIAIgTQAFgNADgPIACgUIACgWIABgTIAAgpIBkAAIAACgIAVAAIgBBHgAgLhAIgBAbIgDAZQgCAPgFAPQgFAPgGAMIA9AAIAAiDIgnAAg");
  this.shape_15.setTransform(67.2, 111.875);
  this.shape_16 = new cjs.Shape();
  this.shape_16.graphics.f("#0C593C").s().p("AAABkQgKABgMgDQgMgEgLgKQgQgOgHgXQgGgVAAgaQAAgZAGgWQAHgVAQgPQALgKAMgEQAMgDAKABQALgBAMADQAMAEALAKQAQAPAHAVQAGAWAAAZQAAAagGAVQgHAXgQAOQgLAKgMAEQgKACgKAAIgDAAgAANBFQAHgCAHgJQAFgGAEgLQADgKABgLIACgUIgCgTQgBgLgDgKQgEgKgFgIQgHgHgHgDQgHgDgGAAQgFAAgHADQgHADgHAHQgFAIgEAKQgDAKgBALIgCATIACAUQABALADAKQAEALAFAGQAHAJAHACQAHADAFAAQAGAAAHgDg");
  this.shape_16.setTransform(51.4982, 109.75);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_16
   }, {
    t: this.shape_15
   }, {
    t: this.shape_14
   }, {
    t: this.shape_13
   }, {
    t: this.shape_12
   }, {
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
 }).prototype = getMCSymbolPrototype(lib.t4, new cjs.Rectangle(41, 92, 340, 90.9), null);
 (lib.t3 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#0C593C").s().p("AgPBeIAAgkIAfAAIAAAkgAgIAkIgHhAIAAhCIAfAAIAABCIgHBAg");
  this.shape.setTransform(149.225, 110.65);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#0C593C").s().p("AgPBJQgIgBgHgFQgKgGgFgLQgGgLAAgNIAdAAIABAJQABAFACAEQAFAFAFACIAIABIAGgBQADAAAEgDQADgCADgFQACgEAAgHQAAgEgBgEQgBgFgEgDQgEgCgEgBIgHgBIgLAAIAAgVIAJAAIAFAAQADgBAEgCQAEgEACgEIABgIQAAgGgCgEQgCgEgCgCIgGgEIgGgBIgIACQgEACgDAFQgCAEgBAFIgBAHIgbAAQAAgJACgJQADgJAGgGQAIgIAKgDQAKgDAIAAQAHAAAKACQAKADAJAIQAFAFADAHQADAIAAAJQAAAGgCAGQgCAGgEAEQgDAEgDABIgFACIAAABQAEAAAEABQAEACAEAFQAFAFACAFQABAFAAAHQAAAJgDAHQgCAHgEAFIgHAHQgJAGgKACQgJACgIAAIgPgBg");
  this.shape_1.setTransform(139.75, 113.2458);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#0C593C").s().p("AgcBIQgFgCgFgDQgHgDgFgIQgEgJgBgOQAAgHACgGQABgGAEgFQAEgGAEgDIALgFIANgCIATgEIAGgCQADgBACgBIABgDIABgIQAAgGgBgFQgCgFgEgEQgDgCgDgBIgFgBQgIABgEADQgFAEgBADQgCAEgBADIAAAIIgdAAQAAgHACgIQACgGAEgHQAFgIAHgFQAIgEAIgBIAOgCIAPACQAJABAJAHQAJAGADALQADAJAAAMIAAA2IAAAKIABAEQABABAAAAQAAABABAAQAAAAABABQAAAAABAAIAFAAIAAAWIgHABIgJABIgHgCQgEAAgEgDQgDgDgBgDIgCgHIgBAAIgFAIIgFAEQgFADgGADQgGACgIAAIgLgBgAAOAFIgCABIgGACIgGACIgIACIgGACQgGAEgCAEQgCAFAAAFIABAGQABAEADAEIAFADIAGABQAEABAEgDQAEgCAEgGQAEgGACgJQACgJAAgHIAAgGIgCACg");
  this.shape_2.setTransform(128.175, 113.15);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#0C593C").s().p("AgoBEIAAiIIBRAAIAAAXIgzAAIAABxg");
  this.shape_3.setTransform(118.35, 113.25);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#0C593C").s().p("AgSBHQgKgDgKgKQgGgHgFgOQgGgNAAgWQAAgGABgKQABgKADgLQAEgKAHgJQAJgLALgEQALgEAJAAQALAAALAFQALAEAJANQAGAKADAPQADAOABAVIhQAAQAAAIACAJQADAJAEAHQAFAGAFACQAFACACAAQAEAAAFgCQAFgBAEgGIADgGIACgIIAdAAQgCAJgDAIQgEAIgFAGQgKAJgKADQgLACgIAAQgIAAgLgDgAgJgwQgEADgDAEQgEAGgCAIIgCAOIAwAAIAAgGIgBgKQgBgFgDgFQgEgGgFgDQgEgDgGAAQgFABgEACg");
  this.shape_4.setTransform(106.8688, 113.2472);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#0C593C").s().p("AgxBFIgFgBIAAgWQAHABAFgCQAFgDACgEIAEgKQABgHABgMIAAggIAAgtIBUAAIAACIIgdAAIAAhyIgbAAIAAAaIAAAWIAAANIgBAIQgCAPgEAIQgDAJgFAEQgFAFgHADQgHACgJAAIgFAAg");
  this.shape_5.setTransform(93.825, 113.3);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#0C593C").s().p("AAYBEIAAhgIgtBgIgfAAIAAiIIAdAAIAABhIAshhIAhAAIAACIg");
  this.shape_6.setTransform(82.1, 113.25);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#0C593C").s().p("AgOBEIAAhxIgkAAIAAgXIBlAAIAAAXIgkAAIAABxg");
  this.shape_7.setTransform(70.675, 113.25);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#0C593C").s().p("AgdBBQgMgHgHgRQgEgKgCgKQgCgLAAgKQAAgJACgLQACgLAEgKQAHgQAMgHQANgJAQAAQARAAAMAJQANAHAHAQQAEAKACALQACALAAAJQAAAKgCALQgCAKgEAKQgHARgNAHQgMAJgRAAQgQAAgNgJgAgLgvQgFAEgDAIIgEALIgCAOIAAAKIAAALIACAOIAEAMQADAHAFAEQAFAEAGAAQAHAAAFgEQAFgEADgHIAEgMIABgOIABgLIgBgKIgBgOQgCgGgCgFQgDgIgFgEQgFgEgHAAQgGAAgFAEg");
  this.shape_8.setTransform(59.475, 113.25);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#0C593C").s().p("AA0BeIAAh/IABgUIgBAAIgnCTIgZAAIgniTIgBAAIABAUIAAB/IggAAIAAi8IAuAAIAlCPIAniPIAtAAIAAC8g");
  this.shape_9.setTransform(43.2, 110.65);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.f("#0C593C").s().p("AgSBHQgKgDgKgKQgGgHgFgOQgGgNAAgWQAAgGABgKQABgKADgLQAEgKAHgJQAJgLALgEQALgEAJAAQALAAALAFQALAEAJANQAGAKADAPQADAOABAVIhQAAQAAAIACAJQADAJAEAHQAFAGAFACQAFACACAAQAEAAAFgCQAFgBAEgGIADgGIACgIIAdAAQgCAJgDAIQgEAIgFAGQgKAJgKADQgLACgIAAQgIAAgLgDgAgJgwQgEADgDAEQgEAGgCAIIgCAOIAwAAIAAgGIgBgKQgBgFgDgFQgEgGgFgDQgEgDgGAAQgFABgEACg");
  this.shape_10.setTransform(158.6688, 87.3472);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.f("#0C593C").s().p("AgOBFIAAhyIgkAAIAAgXIBlAAIAAAXIgkAAIAAByg");
  this.shape_11.setTransform(147.625, 87.35);
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.f("#0C593C").s().p("AAYBfIAAhhIgtBhIgfAAIAAiJIAdAAIAABhIAshhIAhAAIAACJgAgOg5QgFgCgEgCIgFgEQgEgEgEgHQgEgHgCgKIAYAAIACAGIACAGQAEAEAEACQAEABACAAQAEAAAEgBQADgCADgEQADgDABgDIABgGIAZAAQgCAKgFAHQgEAHgEAEIgFAEQgDACgGACQgGACgJAAQgIAAgGgCg");
  this.shape_12.setTransform(136.2, 84.75);
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.f("#0C593C").s().p("AgcBIQgFgBgFgEQgHgDgFgJQgEgIgBgOQAAgGACgHQABgGAEgFQAEgFAEgEIALgFIANgCIATgEIAGgCQADgBACgCIABgCIABgIQAAgGgBgFQgCgGgEgDQgDgCgDgBIgFgBQgIABgEADQgFAEgBAEQgCADgBADIAAAHIgdAAQAAgGACgHQACgIAEgGQAFgJAHgEQAIgEAIgCIAOgBIAPABQAJACAJAHQAJAGADALQADAJAAAMIAAA2IAAAKIABAEQABABAAAAQAAABABAAQAAAAABABQAAAAABAAIAFAAIAAAXIgHAAIgJABIgHgBQgEgBgEgDQgDgCgBgEIgCgHIgBAAIgFAIIgFAEQgFADgGADQgGACgIAAIgLgBgAAOAFIgCABIgGACIgGABIgIADIgGADQgGADgCAEQgCAFAAAFIABAGQABAFADADIAFADIAGACQAEAAAEgDQAEgCAEgGQAEgGACgJQACgJAAgHIAAgGIgCACg");
  this.shape_13.setTransform(123.625, 87.25);
  this.shape_14 = new cjs.Shape();
  this.shape_14.graphics.f("#0C593C").s().p("AApBFIAAhWIAAgPIAAAAIgdBlIgXAAIgdhlIAAAAIAAAPIAABWIgcAAIAAiJIAmAAIAeBmIAfhmIAmAAIAACJg");
  this.shape_14.setTransform(109.35, 87.35);
  this.shape_15 = new cjs.Shape();
  this.shape_15.graphics.f("#0C593C").s().p("AAYBFIAAhhIgsBhIghAAIAAiJIAeAAIAABhIAshhIAhAAIAACJg");
  this.shape_15.setTransform(94.55, 87.35);
  this.shape_16 = new cjs.Shape();
  this.shape_16.graphics.f("#0C593C").s().p("AAVBFIAAg9IgoAAIAAA9IgeAAIAAiJIAeAAIAAA2IAoAAIAAg2IAdAAIAACJg");
  this.shape_16.setTransform(81.625, 87.35);
  this.shape_17 = new cjs.Shape();
  this.shape_17.graphics.f("#0C593C").s().p("AAYBFIAAhhIgtBhIggAAIAAiJIAfAAIAABhIAshhIAfAAIAACJg");
  this.shape_17.setTransform(68.75, 87.35);
  this.shape_18 = new cjs.Shape();
  this.shape_18.graphics.f("#0C593C").s().p("Ag4BgIAAi6IAbAAIAAAOIABAAIAFgHIAGgFQAEgDAGgCQAGgCAGAAQAKAAAJAEQAJAEAHAJQAIAKAEAMQAEALAAAKIABANIgBAQIgDAQQgDAJgEAHQgDAHgGAFQgGAGgIAEQgIAEgKAAIgKgCQgFgBgEgDIgHgGIgFgGIAAAAIAAA+gAgMhGQgGAEgFALQgDAJgBAJIgCAQIABALIACANQACAHAEAHQAEAHAFADQAFADAFAAQADAAAFgDQAFgCAFgIQAEgFACgJQADgIAAgPIgBgRQgBgJgEgJQgEgLgGgDQgHgEgEAAQgFAAgGADg");
  this.shape_18.setTransform(55.775, 89.575);
  this.shape_19 = new cjs.Shape();
  this.shape_19.graphics.f("#0C593C").s().p("AAeBfIAAigIg7AAIAACgIggAAIAAi8IB7AAIAAC8g");
  this.shape_19.setTransform(41.05, 84.75);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_19
   }, {
    t: this.shape_18
   }, {
    t: this.shape_17
   }, {
    t: this.shape_16
   }, {
    t: this.shape_15
   }, {
    t: this.shape_14
   }, {
    t: this.shape_13
   }, {
    t: this.shape_12
   }, {
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
 }).prototype = getMCSymbolPrototype(lib.t3, new cjs.Rectangle(31, 67, 269, 62.80000000000001), null);
 (lib.t2_1_t2_lact = function() {
  this.initialize(img.t2_1_t2_lact);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 97, 52);
 (lib.t2_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_t2 = new lib.t2_1_t2_lact();
  this.cvr_t2.name = "cvr_t2";
  this.cvr_t2.parent = this;
  this.cvr_t2.setTransform(180, 103, 0.5, 0.5);
  this.timeline.addTween(cjs.Tween.get(this.cvr_t2).wait(1));
  this.timeline.addTween(cjs.Tween.get(this.cvr_t2).wait(1));
 }).prototype = getMCSymbolPrototype(lib.t2_1, new cjs.Rectangle(178, 101, 101, 82.69999999999999), null);
 (lib.t2 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#0C593C").s().p("AAAAKIgKARIgHgGIAKgSIgPgFIACgJIAQAGIAAgVIAJAAIAAAVIAQgGIACAJIgPAFIAKASIgIAGg");
  this.shape.setTransform(102.25, 129.55);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#0C593C").s().p("AAXBCIAAheIgrBeIgeAAIAAiDIAcAAIAABeIArheIAeAAIAACDg");
  this.shape_1.setTransform(91.25, 138.95);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#0C593C").s().p("AgvBCIgFgBIAAgVQAHACAFgCQAEgDADgFQACgDABgGQABgGABgMIAAggIAAgqIBRAAIAACCIgcAAIAAhtIgaAAIAAAZIAAAUIAAAOIgBAHQgCAOgDAJQgEAHgEAEQgFAFgHADQgHACgIAAIgFAAg");
  this.shape_2.setTransform(78.775, 139);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#0C593C").s().p("AgcA/QgMgIgGgPQgEgKgCgJQgCgLAAgKQAAgJACgLQACgKAEgJQAGgPAMgIQAMgIAQAAQAQAAAMAIQAMAIAHAPQAEAJACAKQACALAAAJQAAAKgCALQgCAJgEAKQgHAPgMAIQgMAIgQAAQgQAAgMgIgAgLgtQgEAEgDAGQgDAGgBAHIgCAMIAAAKIAAALIACANQABAGADAFQADAIAEADQAFAEAGAAQAHAAAEgEQAFgDADgIIAEgLIABgNIABgLIgBgKIgBgMIgEgNQgDgGgFgEQgEgEgHAAQgGAAgFAEg");
  this.shape_3.setTransform(68.125, 138.95);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#0C593C").s().p("AAABiQgJAAgIgCQgIgDgFgEIgJgJQgIgJgDgMQgEgMAAgMIgBgVQAAgUABgNQABgOACgIIAEgLQADgKAGgIQAHgHAKgEQAGgDAIgCIAQgCQAKgCADgCQADgDAAgDIAVAAIgBAJIgDAHQgEAKgHAEQgIAEgLABIgSAFQgIACgHAGQgHAGgDALIgCAJIgBAKIgBAHIACAAQABgFACgFIAGgJQAGgHAHgEQAIgEAJAAQAKAAAIAEQAIAEAGAGQAGAGAEAKQAEAJACAJQACALAAAKQAAANgDANQgDANgJALQgIALgLAFQgJAFgKAAIgDgBgAgIgQQgFADgFAJQgEAHgBAKIgCAQIABAQQACAJAEAJQAEAJAGACQAFADADAAQAFAAAFgDQAFgDAFgIQAEgJABgJIABgQIAAgKIgCgNIgEgLQgEgIgFgDQgFgDgFAAQgDAAgGADg");
  this.shape_4.setTransform(56.175, 136.2025);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#0C593C").s().p("AAXBCIAAheIgqBeIggAAIAAiDIAdAAIAABeIAqheIAgAAIAACDg");
  this.shape_5.setTransform(38.65, 138.95);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#0C593C").s().p("AAXBCIAAheIgrBeIgeAAIAAiDIAcAAIAABeIArheIAeAAIAACDg");
  this.shape_6.setTransform(197, 113.3);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#0C593C").s().p("AAXBCIAAheIgrBeIgeAAIAAiDIAcAAIAABeIArheIAeAAIAACDg");
  this.shape_7.setTransform(184.7, 113.3);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#0C593C").s().p("AAUBCIAAg7IgnAAIAAA7IgdAAIAAiDIAdAAIAAA0IAnAAIAAg0IAdAAIAACDg");
  this.shape_8.setTransform(172.7, 113.3);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#0C593C").s().p("AgaBFQgGgBgFgDQgGgDgFgIQgEgIgBgOQAAgGACgGQACgGADgFIAIgJQAEgCAGgCIANgDIASgDIAGgCQADgBACgCIABgCIABgIQAAgFgCgFQgBgFgEgEIgGgDIgFgBQgHABgFADQgEAEgBADQgCADgBAEIAAAHIgcAAQAAgHACgHQACgHADgGQAGgIAHgEQAHgEAHgCQAIgBAHAAQAFAAAJACQAJABAIAGQAIAHADAJQADAKAAAMIAAA0IABAJIABAEQAAAAABABQAAAAAAABQABAAAAAAQABAAAAABIAFAAIAAAVIgHABIgIAAIgHgBQgEAAgEgDIgEgGIgCgHIgBAAQgCAFgDADIgEAEQgFADgFACQgGACgIAAIgKgBgAAOAFIgDABIgFACIgFABIgJADIgGACQgFAEgCAEQgCAEAAAFIABAGQABAEADAEIAEADQADABADAAQAEAAAEgCQAEgCAEgGQAEgGACgJQACgIAAgIIAAgEIgCABg");
  this.shape_9.setTransform(161.325, 113.1938);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.f("#0C593C").s().p("AgvBCIAAiDIA5AAIANABQAHACAFAFQAGAFACAHQACAHgBAFQAAAHgBAFQgCAFgEAEQgEAFgDACIgGACIAAABIAIACIAHAFQAEADACAGQADAGAAALQAAAKgDAHQgDAGgEADQgEAEgHACQgHADgLAAgAgTAsIASAAIAGAAQAEAAADgDQADgBACgEQACgDAAgGQAAgFgCgEQgBgEgCgBQgEgDgFgBIgHgBIgRAAgAgTgMIAQAAIAGgBQAEgBADgCQADgDABgDIABgHIgBgHQgBgDgEgCIgEgCIgFgBIgTAAg");
  this.shape_10.setTransform(150.425, 113.3);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.f("#0C593C").s().p("AgcA/QgMgIgGgPQgEgKgCgJQgCgLAAgKQAAgJACgLQACgKAEgJQAGgPAMgIQAMgIAQAAQAQAAAMAIQAMAIAHAPQAEAJACAKQACALAAAJQAAAKgCALQgCAJgEAKQgHAPgMAIQgMAIgQAAQgQAAgMgIgAgLgtQgEAEgDAGQgDAGgBAHIgCAMIAAAKIAAALIACANQABAGADAFQADAIAEADQAFAEAGAAQAHAAAEgEQAFgDADgIIAEgLIABgNIABgLIgBgKIgBgMIgEgNQgDgGgFgEQgEgEgHAAQgGAAgFAEg");
  this.shape_11.setTransform(138.675, 113.3);
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.f("#0C593C").s().p("AgOBGQgIgCgHgEQgJgGgFgLQgGgKAAgNIAbAAIACAJQABAFACAEQAFAFAEABIAIACIAFgBQAEgBAEgCIAFgHQACgEAAgHQABgEgCgEQgBgEgEgDQgDgCgEgBIgHAAIgKAAIAAgVIAIAAIAFAAQADgBAEgCQAEgDABgFIABgHQAAgGgBgDQgCgEgCgDIgGgDIgFgBIgIABQgEACgDAFQgDAEAAAFIgBAGIgbAAQAAgIADgJQADgJAFgGQAIgHAKgDQAJgDAIABQAHgBAKADQAKACAIAHQAFAFACAIQADAHAAAJQAAAGgBAFQgCAGgEAEQgDAEgDABIgFACIAAABQAEAAAEABQAEACAEAEQAEAFABAFQACAFAAAGQAAAJgDAHQgCAHgDAFIgHAHQgIAFgKACQgJACgIAAIgDAAIgLgBg");
  this.shape_12.setTransform(127.325, 113.3021);
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.f("#0C593C").s().p("AgaBFQgGgBgFgDQgGgDgFgIQgEgIgBgOQAAgGACgGQACgGADgFIAIgJQAEgCAGgCIANgDIASgDIAGgCQADgBACgCIABgCIABgIQAAgFgCgFQgBgFgEgEIgGgDIgFgBQgHABgFADQgEAEgBADQgCADgBAEIAAAHIgcAAQAAgHACgHQACgHADgGQAGgIAHgEQAHgEAHgCQAIgBAHAAQAFAAAJACQAJABAIAGQAIAHADAJQADAKAAAMIAAA0IABAJIABAEQAAAAABABQAAAAAAABQABAAAAAAQABAAAAABIAFAAIAAAVIgHABIgIAAIgHgBQgEAAgEgDIgEgGIgCgHIgBAAQgCAFgDADIgEAEQgFADgFACQgGACgIAAIgKgBgAAOAFIgDABIgFACIgFABIgJADIgGACQgFAEgCAEQgCAEAAAFIABAGQABAEADAEIAEADQADABADAAQAEAAAEgCQAEgCAEgGQAEgGACgJQACgIAAgIIAAgEIgCABg");
  this.shape_13.setTransform(116.625, 113.1938);
  this.shape_14 = new cjs.Shape();
  this.shape_14.graphics.f("#0C593C").s().p("Ag2BdIAAizIAaAAIAAANIABAAIAFgGIAGgGIAJgEQAGgCAGAAQAKgBAIAEQAJAEAHAJQAIAKADALQAEALAAAJIABANIgBAPIgDAQQgCAIgFAHQgDAHgGAFQgFAGgHADQgIAEgKAAIgJgCQgGgBgDgDIgHgFIgFgGIgBAAIAAA8gAgLhDQgGAEgFAKQgDAIgCAJIgBAQIABALIACAMQACAHAEAGQAEAHAEADQAFADAFAAQADAAAFgCQAFgDAEgHQAEgFADgJQACgIAAgOIgBgQQgBgJgEgIQgEgLgGgEQgGgDgEAAQgFAAgFADg");
  this.shape_14.setTransform(105.1, 115.4472);
  this.shape_15 = new cjs.Shape();
  this.shape_15.graphics.f("#0C593C").s().p("AAABiQgJAAgIgCQgIgDgFgEIgJgJQgIgJgDgMQgEgMAAgMIgBgVQAAgUABgNQABgOACgIIAEgLQADgKAGgIQAHgHAKgEQAGgDAIgCIAQgCQAKgCADgCQADgDAAgDIAVAAIgBAJIgDAHQgEAKgHAEQgIAEgLABIgSAFQgIACgHAGQgHAGgDALIgCAJIgBAKIgBAHIACAAQABgFACgFIAGgJQAGgHAHgEQAIgEAJAAQAKAAAIAEQAIAEAGAGQAGAGAEAKQAEAJACAJQACALAAAKQAAANgDANQgDANgJALQgIALgLAFQgJAFgKAAIgDgBgAgIgQQgFADgFAJQgEAHgBAKIgCAQIABAQQACAJAEAJQAEAJAGACQAFADADAAQAFAAAFgDQAFgDAFgIQAEgJABgJIABgQIAAgKIgCgNIgEgLQgEgIgFgDQgFgDgFAAQgDAAgGADg");
  this.shape_15.setTransform(92.575, 110.5525);
  this.shape_16 = new cjs.Shape();
  this.shape_16.graphics.f("#0C593C").s().p("AgcA/QgMgIgGgPQgEgKgCgJQgCgLAAgKQAAgJACgLQACgKAEgJQAGgPAMgIQAMgIAQAAQAQAAAMAIQAMAIAHAPQAEAJACAKQACALAAAJQAAAKgCALQgCAJgEAKQgHAPgMAIQgMAIgQAAQgQAAgMgIgAgLgtQgEAEgDAGQgDAGgBAHIgCAMIAAAKIAAALIACANQABAGADAFQADAIAEADQAFAEAGAAQAHAAAEgEQAFgDADgIIAEgLIABgNIABgLIgBgKIgBgMIgEgNQgDgGgFgEQgEgEgHAAQgGAAgFAEg");
  this.shape_16.setTransform(80.325, 113.3);
  this.shape_17 = new cjs.Shape();
  this.shape_17.graphics.f("#0C593C").s().p("AgcA/QgMgIgGgPQgEgKgCgJQgCgLAAgKQAAgJACgLQACgKAEgJQAGgPAMgIQAMgIAQAAQAQAAAMAIQAMAIAHAPQAEAJACAKQACALAAAJQAAAKgCALQgCAJgEAKQgHAPgMAIQgMAIgQAAQgQAAgMgIgAgLgtQgEAEgDAGQgDAGgBAHIgCAMIAAAKIAAALIACANQABAGADAFQADAIAEADQAFAEAGAAQAHAAAEgEQAFgDADgIIAEgLIABgNIABgLIgBgKIgBgMIgEgNQgDgGgFgEQgEgEgHAAQgGAAgFAEg");
  this.shape_17.setTransform(68.475, 113.3);
  this.shape_18 = new cjs.Shape();
  this.shape_18.graphics.f("#0C593C").s().p("AgOBGQgIgCgHgEQgJgGgFgLQgGgKAAgNIAbAAIACAJQABAFACAEQAFAFAEABIAIACIAFgBQAEgBAEgCIAFgHQACgEAAgHQABgEgCgEQgBgEgEgDQgDgCgEgBIgHAAIgKAAIAAgVIAIAAIAFAAQADgBAEgCQAEgDABgFIABgHQAAgGgBgDQgCgEgCgDIgGgDIgFgBIgIABQgEACgDAFQgDAEAAAFIgBAGIgbAAQAAgIADgJQADgJAFgGQAIgHAKgDQAJgDAIABQAHgBAKADQAKACAIAHQAFAFACAIQADAHAAAJQAAAGgBAFQgCAGgEAEQgDAEgDABIgFACIAAABQAEAAAEABQAEACAEAEQAEAFABAFQACAFAAAGQAAAJgDAHQgCAHgDAFIgHAHQgIAFgKACQgJACgIAAIgDAAIgLgBg");
  this.shape_18.setTransform(57.125, 113.3021);
  this.shape_19 = new cjs.Shape();
  this.shape_19.graphics.f("#0C593C").s().p("AgaBFQgGgBgFgDQgGgDgFgIQgEgIgBgOQAAgGACgGQACgGADgFIAIgJQAEgCAGgCIANgDIASgDIAGgCQADgBACgCIABgCIABgIQAAgFgCgFQgBgFgEgEIgGgDIgFgBQgHABgFADQgEAEgBADQgCADgBAEIAAAHIgcAAQAAgHACgHQACgHADgGQAGgIAHgEQAHgEAHgCQAIgBAHAAQAFAAAJACQAJABAIAGQAIAHADAJQADAKAAAMIAAA0IABAJIABAEQAAAAABABQAAAAAAABQABAAAAAAQABAAAAABIAFAAIAAAVIgHABIgIAAIgHgBQgEAAgEgDIgEgGIgCgHIgBAAQgCAFgDADIgEAEQgFADgFACQgGACgIAAIgKgBgAAOAFIgDABIgFACIgFABIgJADIgGACQgFAEgCAEQgCAEAAAFIABAGQABAEADAEIAEADQADABADAAQAEAAAEgCQAEgCAEgGQAEgGACgJQACgIAAgIIAAgEIgCABg");
  this.shape_19.setTransform(46.425, 113.1938);
  this.shape_20 = new cjs.Shape();
  this.shape_20.graphics.f("#0C593C").s().p("AgmBCIAAiDIBNAAIAAAVIgwAAIAABug");
  this.shape_20.setTransform(37.4, 113.3);
  this.shape_21 = new cjs.Shape();
  this.shape_21.graphics.f("#0C593C").s().p("AgNAUIAFgBQADgCACgEQACgEABgJIAAgCIgNAAIAAgjIAbAAIAAAkIgCAQQgBAHgIAIIgHAFQgEADgFAAg");
  this.shape_21.setTransform(157.6, 94.55);
  this.shape_22 = new cjs.Shape();
  this.shape_22.graphics.f("#0C593C").s().p("AAXBCIAAheIgrBeIgeAAIAAiDIAcAAIAABeIArheIAeAAIAACDg");
  this.shape_22.setTransform(148.3, 87.65);
  this.shape_23 = new cjs.Shape();
  this.shape_23.graphics.f("#0C593C").s().p("AAXBCIAAheIgrBeIgeAAIAAiDIAcAAIAABeIArheIAeAAIAACDg");
  this.shape_23.setTransform(136, 87.65);
  this.shape_24 = new cjs.Shape();
  this.shape_24.graphics.f("#0C593C").s().p("AgOBCIAAhuIgjAAIAAgVIBiAAIAAAVIgjAAIAABug");
  this.shape_24.setTransform(125.4, 87.65);
  this.shape_25 = new cjs.Shape();
  this.shape_25.graphics.f("#0C593C").s().p("AgUBaIgIAAIgIgBIAAgVIAEAAIAFABQAHAAAEgEQAEgFACgHIADgMIgwiDIAfAAIAdBfIABAAIAXhfIAbAAIgoCPIgEANQgCAHgFAGQgFAHgGACQgFADgGAAIgDgBg");
  this.shape_25.setTransform(115.825, 90.1042);
  this.shape_26 = new cjs.Shape();
  this.shape_26.graphics.f("#0C593C").s().p("AAoBTIAAgiIhPAAIAAAiIgZAAIgCg4IAPAAIAFgLIAFgNQAEgRACgPIABgeIAAgXIBSAAIAABtIATAAIgCA4gAgIgtIgCASIgCAQIgEATQgDALgEAIIArAAIAAhYIgcAAg");
  this.shape_26.setTransform(104.5, 89.375);
  this.shape_27 = new cjs.Shape();
  this.shape_27.graphics.f("#0C593C").s().p("AgOBGQgIgCgHgEQgJgGgFgLQgGgKAAgNIAbAAIACAJQABAFACAEQAFAFAEABIAIACIAFgBQAEgBAEgCIAFgHQACgEAAgHQABgEgCgEQgBgEgEgDQgDgCgEgBIgHAAIgKAAIAAgVIAIAAIAFAAQADgBAEgCQAEgDABgFIABgHQAAgGgBgDQgCgEgCgDIgGgDIgFgBIgIABQgEACgDAFQgDAEAAAFIgBAGIgbAAQAAgIADgJQADgJAFgGQAIgHAKgDQAJgDAIABQAHgBAKADQAKACAIAHQAFAFACAIQADAHAAAJQAAAGgBAFQgCAGgEAEQgDAEgDABIgFACIAAABQAEAAAEABQAEACAEAEQAEAFABAFQACAFAAAGQAAAJgDAHQgCAHgDAFIgHAHQgIAFgKACQgJACgIAAIgDAAIgLgBg");
  this.shape_27.setTransform(93.025, 87.6521);
  this.shape_28 = new cjs.Shape();
  this.shape_28.graphics.f("#0C593C").s().p("AgvBCIAAiDIA5AAIANABQAHACAFAFQAGAFACAHQACAGgBAGQAAAHgBAFQgCAFgEAFQgEAEgDACIgGACIAAABIAIACIAHAFQAEADACAGQADAGAAALQAAAKgDAHQgDAGgEADQgEAEgHACQgHADgLAAgAgTAsIASAAIAGAAQAEAAADgDQADgBACgEQACgDAAgGQAAgFgCgEQgBgEgCgBQgEgDgFgBIgHgBIgRAAgAgTgMIAQAAIAGgBQAEgBADgCQADgDABgDIABgHIgBgHQgBgDgEgCIgEgCIgFgBIgTAAg");
  this.shape_28.setTransform(82.575, 87.65);
  this.shape_29 = new cjs.Shape();
  this.shape_29.graphics.f("#0C593C").s().p("AAXBCIAAheIgqBeIggAAIAAiDIAdAAIAABeIAqheIAgAAIAACDg");
  this.shape_29.setTransform(65.55, 87.65);
  this.shape_30 = new cjs.Shape();
  this.shape_30.graphics.f("#0C593C").s().p("Ag2BdIAAizIAbAAIAAANIABAAIAEgGIAGgGIAJgEQAGgCAGAAQAJgBAJAEQAJAEAHAJQAHAKAEALQADALACAJIAAANIgBAPIgDAQQgDAIgDAHQgEAHgFAFQgGAGgIADQgHAEgKAAIgKgCQgEgBgFgDIgGgFIgFgGIgBAAIAAA8gAgLhDQgGAEgFAKQgDAIgBAJIgBAQIAAALIACAMQACAHAEAGQAEAHAFADQAFADAEAAQACAAAGgCQAFgDAFgHQADgFACgJQADgIAAgOIgBgQQgBgJgEgIQgEgLgGgEQgGgDgDAAQgGAAgFADg");
  this.shape_30.setTransform(53.5, 89.7972);
  this.shape_31 = new cjs.Shape();
  this.shape_31.graphics.f("#0C593C").s().p("AAdBbIAAiZIg5AAIAACZIgeAAIAAi1IB2AAIAAC1g");
  this.shape_31.setTransform(39.75, 85.15);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_31
   }, {
    t: this.shape_30
   }, {
    t: this.shape_29
   }, {
    t: this.shape_28
   }, {
    t: this.shape_27
   }, {
    t: this.shape_26
   }, {
    t: this.shape_25
   }, {
    t: this.shape_24
   }, {
    t: this.shape_23
   }, {
    t: this.shape_22
   }, {
    t: this.shape_21
   }, {
    t: this.shape_20
   }, {
    t: this.shape_19
   }, {
    t: this.shape_18
   }, {
    t: this.shape_17
   }, {
    t: this.shape_16
   }, {
    t: this.shape_15
   }, {
    t: this.shape_14
   }, {
    t: this.shape_13
   }, {
    t: this.shape_12
   }, {
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
 }).prototype = getMCSymbolPrototype(lib.t2, new cjs.Rectangle(30, 68, 336, 89.19999999999999), null);
 (lib.t1_t1_lact = function() {
  this.initialize(img.t1_t1_lact);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 243, 60);
 (lib.t1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_t1 = new lib.t1_t1_lact();
  this.cvr_t1.name = "cvr_t1";
  this.cvr_t1.parent = this;
  this.cvr_t1.setTransform(32, 73, 0.5, 0.5);
  this.timeline.addTween(cjs.Tween.get(this.cvr_t1).wait(1));
  this.timeline.addTween(cjs.Tween.get(this.cvr_t1).wait(1));
 }).prototype = getMCSymbolPrototype(lib.t1, new cjs.Rectangle(30, 71, 247, 94), null);
 (lib.packshot_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.packshot();
  this.instance.parent = this;
  this.instance.setTransform(0, 0, 0.667, 0.667);
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));
 }).prototype = getMCSymbolPrototype(lib.packshot_1, new cjs.Rectangle(0, 0, 234.8, 113.4), null);
 (lib.orange = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#0C593C").s().p("AAAAJIgJAQIgHgGIAKgPIgOgFIABgJIAQAFIAAgTIAIAAIAAATIAOgFIADAJIgPAFIAJAPIgHAGg");
  this.shape.setTransform(106, 45.6);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#FFFFFF").s().p("AgNBUIAAghIAcAAIAAAhgAgHAfIgGg4IAAg6IAcAAIAAA6IgHA4g");
  this.shape_1.setTransform(98.8, 54);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#FFFFFF").s().p("AAjBUIgKgjIgxAAIgKAjIgdAAIAzinIAaAAIAyCngAATAXIgThHIgRBHIAkAAg");
  this.shape_2.setTransform(89.825, 54);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#FFFFFF").s().p("AAXBUIgyhUIAABUIgdAAIAAinIAdAAIAABIIAvhIIAgAAIg1BOIA6BZg");
  this.shape_3.setTransform(78.7, 54);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#FFFFFF").s().p("AAbBUIAAhMIg1AAIAABMIgcAAIAAinIAcAAIAABDIA1AAIAAhDIAcAAIAACng");
  this.shape_4.setTransform(64.975, 54);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#FFFFFF").s().p("AAcBUIAAh6Ig4B6IgcAAIAAinIAdAAIAAB6IA4h6IAcAAIAACng");
  this.shape_5.setTransform(51.25, 54);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#FFFFFF").s().p("Ag3BUIAAinIA/AAQAHAAAJACQAIACAHAIQAHAHACAIQACAIAAAHQAAAHgCAHQgCAHgGAHIgFAFIgIADIAAABIAJADIAIAFQAEAEAEAIQADAIAAANQABAIgDAJQgCAKgJAJQgGAFgGADQgHACgGABIgLAAgAgaA7IAaAAIALgBQAFgBAEgEQAEgEABgFIABgKIgBgJQgBgFgEgEQgEgEgFgBQgFgCgGABIgaAAgAgagOIAaAAIAHgBQAFgBAEgEIADgGQACgDAAgGIgBgIQgBgFgDgDQgDgEgFgBQgEgCgFAAIgZAAg");
  this.shape_6.setTransform(38.0042, 53.9958);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#FFFFFF").s().p("AAABZQgJAAgKgDQgLgDgKgIQgOgNgGgUQgGgTAAgXQAAgWAGgTQAGgUAOgNQAKgIALgDQAKgDAJAAQAKAAAKADQALADAKAIQAOANAGAUQAGATAAAWQAAAXgGATQgGAUgOANQgKAIgLADQgIADgJAAIgDAAgAAMA9QAGgCAGgHQAFgHADgIQADgJABgKIABgSIgBgRQgBgKgDgJQgDgIgFgHQgGgHgGgCQgGgDgGAAQgEAAgGADQgHACgGAHQgFAHgDAIQgDAJgBAKIgBARIABASQABAKADAJQADAIAFAHQAGAHAHACQAGADAEAAQAGAAAGgDg");
  this.shape_7.setTransform(24.075, 54);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#FFFFFF").s().p("AAbBUIAAhMIg1AAIAABMIgcAAIAAinIAcAAIAABDIA1AAIAAhDIAcAAIAACng");
  this.shape_8.setTransform(10.175, 54);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#E07E22").s().p("AlvFvQiYiXAAjYQAAjXCYiYQCZiYDWAAQDXAACZCYQCYCYAADXQAADYiYCXQiZCZjXAAQjWAAiZiZg");
  this.shape_9.setTransform(52, 52);
  this.timeline.addTween(cjs.Tween.get(this.shape_9).wait(1));
 }).prototype = getMCSymbolPrototype(lib.orange, new cjs.Rectangle(0, 0, 115.6, 104), null);
 (lib.logo = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#FFFFFF").s().p("AgjAxIAShhIA1AAIgCAPIgkAAIgFAZIAiAAIgDANIgiAAIgFAdIAmAAIgDAPg");
  this.shape.setTransform(238.7782, 36.1913, 0.65, 0.6494);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#FFFFFF").s().p("AgZAxIAQhSIgbAAIADgPIBGAAIgDAPIgbAAIgPBSg");
  this.shape_1.setTransform(234.1147, 36.1913, 0.65, 0.6494);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#FFFFFF").s().p("AglAxIAShfQAIgCAPAAQAQAAAJAGQAJAIAAAMQAAARgNAIQgLAJgSAAIgJAAIgHAlgAgFgiIgGAhIAJABQAKAAAGgGQAHgGAAgIQAAgPgRAAg");
  this.shape_2.setTransform(228.3138, 36.175, 0.65, 0.6494);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#FFFFFF").s().p("AgjAmQgJgLAAgRQAAgbARgSQAPgOATAAQATAAAKAMQAJAKAAASQAAAcgRARQgNAOgVAAQgSAAgLgMgAgRgUQgJAOAAAPQAAAbAWAAIABAAQAMAAAKgPQAJgOAAgPQAAgbgXAAQgNAAgJAPg");
  this.shape_3.setTransform(222.2041, 36.1913, 0.65, 0.6494);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#FFFFFF").s().p("AgRA1IABgJQgNgDgIgJQgLgKABgQQAAgYAQgOQAOgMARAAIACgIIAQAAIgCAJQAOACAJAJQAJAKABARQAAAXgQAOQgNAMgUAAIgBAJgAACAgQANgBAIgKQAJgLAAgQQAAgWgSgDgAgVgVQgJALAAAPQAAALAEAHQAGAHAHABIAMg/QgLABgJAKg");
  this.shape_4.setTransform(215.1033, 36.1913, 0.65, 0.6494);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#005942").s().p("AhzBhQgggkAOg9QAPg5AtglQAugkA6AAQA4AAAdAiQAgAlgOA7QgQA/gyAkQgtAfg2AAQg3AAgdghgAgkg2QgXAXgIAiQgKAoATAXQAOAQAXAAQAdAAAZgYQAagZAJgjQAEgRgCgQQgCgUgKgMQgMgNgXAAQgiAAgZAag");
  this.shape_5.setTransform(127.147, 20.4268, 0.65, 0.6494);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#80BC1E").s().p("AguA0QgPgRAIgjQACAZAOAJQAOAJASgIQAsgVALhLQAHAKAAATQAAAKgDAMIgCAIQgFAMgGAKQgLATgRAMQgPALgSAAQgRAAgJgKg");
  this.shape_6.setTransform(127.1216, 20.8164, 0.65, 0.6494);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#80BC1E").s().p("AhNBxQgZgVAAgnIAAgJIA3AAIAAAEQAAATAMAKQALALAUgBQASAAALgKQAMgLABgWQAAgHgEgGQgDgGgFgCIgMgEQgGgCgIAAIgSAAIAIgpIALAAIAPgDQAJgBAGgEQAGgEAEgHQAFgIAAgKQAAgZggAAQgPAAgMAIQgLAHgFAVIg3AAQAEgYAJgQQAJgQAOgJQAPgKASgEQASgFAVABQAWgBAPAGQAOAEAKAKQAKAJAEAMQAEAKAAAQQAAAKgDAJQgEALgFAHQgEAGgJAHQgIAGgHACQAPACAKAOQAKAOAAAVQAAAXgHARQgJARgOAMQgOALgUAHQgTAFgXAAQgtAAgYgVg");
  this.shape_7.setTransform(235.4796, 20.3618, 0.65, 0.6494);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#80BC1E").s().p("AhGCBQgNgFgJgKQgJgIgEgNQgEgKAAgPQAAgmAVgWQAWgUAngHIAkgEQAPgBALgEQALgDAEgGQAFgGAAgNQAAgKgEgFQgEgHgFgDQgGgDgGgBIgNgBQgPgBgMAKQgNAIgDAUIg4AAQADgZAKgPQAJgPAOgLQAQgLAQgDQAQgFASABQANAAASACQAOACAPAIQAOAHAIANQAJAOgBAVQAAARgEAaIgUBlIgCAjQAAAHACAIIg8AAIAAgZQgMAQgRAIQgRAHgTAAQgRABgOgGgAATAPIgZACIgRAEQgJADgFAEQgFADgEAJQgEAHAAAMQAAAPAKAGQAKAIAMAAQAOAAAJgFQAJgGAHgIQAEgFAGgNQAEgLACgKIAGgZQgMAJgMABg");
  this.shape_8.setTransform(220.42, 20.3618, 0.65, 0.6494);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#80BC1E").s().p("AhnCAIAvj/ICgAAIgKA1IhkAAIglDKg");
  this.shape_9.setTransform(207.255, 20.3781, 0.65, 0.6494);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.f("#005942").s().p("AgrB8QgUgIgPgTQgPgSgGgYQgIgZAAgdQAAgdAIgYQAHgZAPgRQAPgSAUgLQAUgLAYABQAagBAUAMQAUALANATQAOAVAGAXQAHAZAAAbIgBANIibAAQABAiANAQQAOAPAZAAQARAAANgLQAOgKADgMIA0AAQgNAugaATQgaAVglgBQgYAAgVgKgAgXhLQgJAHgFAHQgGAJgCAJQgCAGgBALIBgAAQgEgcgLgNQgLgOgWAAQgNAAgKAGg");
  this.shape_10.setTransform(192.1596, 20.3618, 0.65, 0.6494);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.f("#005942").s().p("AhXCBIgagEIAAg2IAJACIAKAAQAOAAAHgPIADgKIADgaQACgWAAggQABgYAAhJICyAAIAAD/Ig7AAIAAjKIg9AAIgBBDIgDAxQgCASgDASQgFAQgEAHQgHAOgNAIQgOAJgUAAg");
  this.shape_11.setTransform(174.8543, 20.5079, 0.65, 0.6494);
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.f("#005942").s().p("AAuCAIAAisIhRCsIhDAAIAAj/IA5AAIAACsIBRisIBDAAIAAD/g");
  this.shape_12.setTransform(158.4752, 20.3781, 0.65, 0.6494);
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.f("#005942").s().p("AgdCAIAAjKIhHAAIAAg1IDJAAIAAA1IhHAAIAADKg");
  this.shape_13.setTransform(142.8274, 20.3781, 0.65, 0.6494);
  this.shape_14 = new cjs.Shape();
  this.shape_14.graphics.f("#005942").s().p("ABkCwIAAj5IgBAAIhJD5IgzAAIhJj2IgBAAIAAD2Ig+AAIAAlgIBdAAIBFDyIABAAIBDjyIBdAAIAAFgg");
  this.shape_14.setTransform(106.3969, 17.2122, 0.65, 0.6494);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_14
   }, {
    t: this.shape_13
   }, {
    t: this.shape_12
   }, {
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
  this.shape_15 = new cjs.Shape();
  this.shape_15.graphics.lf(["#FFFFFF", "#F27E20"], [0.612, 0.765], -103.4, 10.5, 107.5, 10.5).s().p("A6UA2IAAhsMA0pAAAIAABsg");
  this.shape_15.setTransform(168, 36.5);
  this.shape_16 = new cjs.Shape();
  this.shape_16.graphics.f("#FFFFFF").s().p("A6UCdIAAk5MA0pAAAIAAE5g");
  this.shape_16.setTransform(168, 15.375);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_16
   }, {
    t: this.shape_15
   }]
  }).wait(1));
 }).prototype = getMCSymbolPrototype(lib.logo, new cjs.Rectangle(-0.5, -0.3, 337, 42.3), null);
 (lib.l4 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#0C593C").s().p("AgFAGIAAgLIALAAIAAALg");
  this.shape.setTransform(308.075, -8.325);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#0C593C").s().p("AAMAjIAAghIgXAAIAAAhIgKAAIAAhFIAKAAIAAAdIAXAAIAAgdIAKAAIAABFg");
  this.shape_1.setTransform(304.225, -11.175);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#0C593C").s().p("AgMAhQgGgDgDgIQgDgIAAgOQAAgRAGgJQAGgKAMAAQAZAAAAAkQAAAOgDAIQgDAIgGADQgFAEgIAAQgHAAgFgEgAgIgYQgDACgBAHQgCAGAAAKQAAAJACAGQABAGADADQADADAFAAQAGAAADgDQADgDABgGQACgGAAgJQAAgKgCgGQgBgHgEgCQgDgDgFAAQgEAAgEADg");
  this.shape_2.setTransform(298.825, -11.175);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#0C593C").s().p("AAMAjIgRgjIgHAKIAAAZIgKAAIAAhFIAKAAIAAAhIAXghIALAAIgVAbIAWAqg");
  this.shape_3.setTransform(294.175, -11.175);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#0C593C").s().p("AANAjIAAg0IABgIIgCAIIgWA0IgMAAIAAhFIAKAAIAAA0IgBAIIACgIIAWg0IAMAAIAABFg");
  this.shape_4.setTransform(288.65, -11.175);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#0C593C").s().p("AgEAjIAAg8IgSAAIAAgJIAtAAIAAAJIgSAAIAAA8g");
  this.shape_5.setTransform(284, -11.175);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#0C593C").s().p("AgLAhQgFgDgCgIQgDgIAAgOQAAgkAVAAQAKAAAEAGQAFAFABAIQACAHAAALIghAAIABAPQABAGADADQACADAFAAQALAAAAgQIAKAAQAAAHgCAFQgDAGgFADQgEAEgHAAQgHAAgFgEgAgIgVQgDAGAAAJIAWAAQAAgKgBgGQgDgFgHAAQgGAAgCAGg");
  this.shape_6.setTransform(279.65, -11.175);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#0C593C").s().p("AAVAjIAAg8IgSA8IgFAAIgSg8IAAA8IgJAAIAAhFIAPAAIANAtIABAOIACgOIANgtIAPAAIAABFg");
  this.shape_7.setTransform(273.825, -11.175);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#0C593C").s().p("AAOAjIAAg0IABgIIgDAIIgWA0IgMAAIAAhFIAKAAIAAA0IgBAIIACgIIAXg0IALAAIAABFg");
  this.shape_8.setTransform(267.55, -11.175);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#0C593C").s().p("AgMAgQgGgFgCgIQgBgIAAgKQAAglAWAAQAKAAAGAHQAGAHAAAKIgKAAQAAgPgMAAQgGAAgEAIQgCAIAAAMQgBAMADAIQACAHAIAAQAHAAACgEQACgFABgIIAKAAQgBALgFAHQgEAIgMAAQgIAAgFgFg");
  this.shape_9.setTransform(262.5, -11.175);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.f("#0C593C").s().p("AgeAEIAAgHIA9AAIAAAHg");
  this.shape_10.setTransform(255.175, -11.575);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.f("#0C593C").s().p("AgMAhQgGgDgDgIQgDgIAAgOQAAgRAGgJQAGgKAMAAQAZAAAAAkQAAAOgDAIQgDAIgGADQgFAEgIAAQgHAAgFgEgAgIgYQgDACgBAHQgCAGAAAKQAAAJACAGQABAGADADQADADAFAAQAGAAADgDQADgDABgGQACgGAAgJQAAgKgCgGQgBgHgEgCQgDgDgFAAQgEAAgEADg");
  this.shape_11.setTransform(247.525, -11.175);
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.f("#0C593C").s().p("AgUAjIAAhFIAVAAQAIAAAGAFQAFAEAAAIQAAAGgDAFQgDAEgFABIAAABQAGAAADAEQADAFAAAHQAAAGgCAEQgCAEgEADQgEACgFAAgAgLAbIALAAQAHAAACgDQACgDAAgHQAAgFgCgDQgDgDgFAAIgMAAgAgLgEIALAAQAFAAACgDQADgDAAgFQAAgLgKAAIgLAAg");
  this.shape_12.setTransform(242.575, -11.175);
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.f("#0C593C").s().p("AgEAjIAAg8IgSAAIAAgJIAtAAIAAAJIgSAAIAAA8g");
  this.shape_13.setTransform(238.05, -11.175);
  this.shape_14 = new cjs.Shape();
  this.shape_14.graphics.f("#0C593C").s().p("AgNAgQgFgFgCgIQgBgIgBgKQAAglAYAAQAKAAAFAHQAGAHgBAKIgJAAQAAgPgLAAQgIAAgCAIQgEAIAAAMQAAAMADAIQADAHAHAAQAHAAADgEQACgFAAgIIAJAAQAAALgEAHQgGAIgKAAQgJAAgGgFg");
  this.shape_14.setTransform(233.75, -11.175);
  this.shape_15 = new cjs.Shape();
  this.shape_15.graphics.f("#0C593C").s().p("AgLAhQgFgDgCgIQgDgIAAgOQAAgkAVAAQAJAAAGAGQAEAFABAIQACAHAAALIghAAIABAPQAAAGADADQADADAFAAQALAAAAgQIAKAAQAAAHgDAFQgBAGgGADQgEAEgHAAQgHAAgFgEgAgIgVQgDAGAAAJIAWAAQAAgKgCgGQgCgFgHAAQgGAAgCAGg");
  this.shape_15.setTransform(229, -11.175);
  this.shape_16 = new cjs.Shape();
  this.shape_16.graphics.f("#0C593C").s().p("AAgAsIAAgTIhIAAIAAhEIAKAAIAAA8IAXAAIAAg8IAJAAIAAA8IAWAAIAAg8IAKAAIAAA8IAHAAIAAAbg");
  this.shape_16.setTransform(222.775, -10.225);
  this.shape_17 = new cjs.Shape();
  this.shape_17.graphics.f("#0C593C").s().p("AgLAhQgFgDgDgIQgCgIAAgOQAAgkAVAAQAJAAAGAGQAEAFACAIQABAHAAALIghAAIABAPQABAGACADQADADAEAAQAMAAAAgQIAKAAQAAAHgDAFQgCAGgEADQgFAEgHAAQgHAAgFgEgAgJgVQgCAGAAAJIAXAAQgBgKgCgGQgCgFgHAAQgGAAgDAGg");
  this.shape_17.setTransform(215.8, -11.175);
  this.shape_18 = new cjs.Shape();
  this.shape_18.graphics.f("#0C593C").s().p("AgUAjIAAhFIAVAAQAIAAAGAFQAFAEAAAIQAAAGgDAFQgDAEgFABIAAABQAGAAADAEQADAFAAAHQAAAGgCAEQgCAEgEADQgEACgFAAgAgLAbIALAAQAHAAACgDQACgDAAgHQAAgFgCgDQgDgDgFAAIgMAAgAgLgEIALAAQAFAAACgDQADgDAAgFQAAgLgKAAIgLAAg");
  this.shape_18.setTransform(211.225, -11.175);
  this.shape_19 = new cjs.Shape();
  this.shape_19.graphics.f("#0C593C").s().p("AgLAhQgFgDgCgIQgDgIAAgOQAAgkAVAAQAJAAAGAGQAEAFABAIQACAHAAALIghAAIABAPQAAAGADADQADADAEAAQAMAAAAgQIAKAAQAAAHgDAFQgCAGgEADQgFAEgHAAQgHAAgFgEgAgJgVQgCAGAAAJIAWAAQAAgKgCgGQgCgFgHAAQgGAAgDAGg");
  this.shape_19.setTransform(204, -11.175);
  this.shape_20 = new cjs.Shape();
  this.shape_20.graphics.f("#0C593C").s().p("AgLAhQgFgDgCgIQgDgIAAgOQAAgkAVAAQAJAAAGAGQAEAFABAIQACAHAAALIghAAIABAPQAAAGADADQADADAEAAQAMAAAAgQIAKAAQAAAHgDAFQgBAGgGADQgEAEgHAAQgHAAgFgEgAgIgVQgDAGAAAJIAWAAQAAgKgCgGQgCgFgHAAQgGAAgCAGg");
  this.shape_20.setTransform(199.3, -11.175);
  this.shape_21 = new cjs.Shape();
  this.shape_21.graphics.f("#0C593C").s().p("AAgAsIAAgTIhIAAIAAhEIAKAAIAAA8IAXAAIAAg8IAJAAIAAA8IAWAAIAAg8IAKAAIAAA8IAHAAIAAAbg");
  this.shape_21.setTransform(193.075, -10.225);
  this.shape_22 = new cjs.Shape();
  this.shape_22.graphics.f("#0C593C").s().p("AgGAdQgHgIAAgTIgMAAIAAAhIgKAAIAAhFIAKAAIAAAdIAMAAQAAgOAHgIQAGgJALAAQANAAAFAJQAHAJAAARQAAANgDAJQgDAIgGAEQgFAEgIAAQgLAAgGgIgAACgYQgCADgBAGQgCAGAAAKQAAANADAHQADAHAIAAQAIAAADgHQADgHABgNQAAgPgEgHQgEgGgHAAQgFAAgEADg");
  this.shape_22.setTransform(184.7, -11.175);
  this.shape_23 = new cjs.Shape();
  this.shape_23.graphics.f("#0C593C").s().p("AgXAtIAAgIQAEACAEAAQAEAAADgFQADgDACgHIgWhGIAKAAIAPA3IABAAIAPg3IAKAAIgVBFIgFANQgBAEgEADQgEADgHABIgHgCg");
  this.shape_23.setTransform(178.175, -10);
  this.shape_24 = new cjs.Shape();
  this.shape_24.graphics.f("#0C593C").s().p("AgUAjIAAhFIAVAAQAIAAAGAFQAFAEAAAIQAAAGgDAFQgDAEgFABIAAABQAGAAADAEQADAFAAAHQAAAGgCAEQgCAEgEADQgEACgFAAgAgLAbIALAAQAHAAACgDQACgDAAgHQAAgFgCgDQgDgDgFAAIgMAAgAgLgEIALAAQAFAAACgDQADgDAAgFQAAgLgKAAIgLAAg");
  this.shape_24.setTransform(173.675, -11.175);
  this.shape_25 = new cjs.Shape();
  this.shape_25.graphics.f("#0C593C").s().p("AgEAjIAAg8IgSAAIAAgJIAtAAIAAAJIgSAAIAAA8g");
  this.shape_25.setTransform(169.15, -11.175);
  this.shape_26 = new cjs.Shape();
  this.shape_26.graphics.f("#0C593C").s().p("AgMAgQgGgFgCgIQgBgIAAgKQAAglAWAAQAKAAAGAHQAGAHAAAKIgKAAQAAgPgMAAQgGAAgEAIQgCAIAAAMQgBAMADAIQACAHAIAAQAHAAACgEQACgFABgIIAKAAQgBALgFAHQgEAIgMAAQgIAAgFgFg");
  this.shape_26.setTransform(164.85, -11.175);
  this.shape_27 = new cjs.Shape();
  this.shape_27.graphics.f("#0C593C").s().p("AANAuIAAg0IACgIIgDAIIgWA0IgMAAIAAhFIAKAAIAAA0IgBAIIACgIIAWg0IAMAAIAABFgAgJgiQgFgDAAgIIAFAAQABAJAJAAQAEAAADgCQACgCABgFIAGAAQgBAIgFAEQgEADgHAAQgFAAgEgEg");
  this.shape_27.setTransform(159.7, -12.3);
  this.shape_28 = new cjs.Shape();
  this.shape_28.graphics.f("#0C593C").s().p("AgLAhQgFgDgDgIQgCgIAAgOQAAgkAVAAQAJAAAGAGQAEAFACAIQABAHAAALIghAAIABAPQABAGACADQADADAEAAQAMAAAAgQIAKAAQAAAHgDAFQgCAGgEADQgFAEgHAAQgHAAgFgEgAgJgVQgCAGAAAJIAXAAQgBgKgCgGQgCgFgHAAQgGAAgDAGg");
  this.shape_28.setTransform(154.6, -11.175);
  this.shape_29 = new cjs.Shape();
  this.shape_29.graphics.f("#0C593C").s().p("AAbA6IAAgWIg1AAIAAAWIgKAAIAAggIAHAAQAEgHACgJQACgIABgJIABgaIAAgYIAwAAIAABTIAIAAIAAAggAgJgXQAAALgBAJIgDAQIgFANIAlAAIAAhJIgcAAg");
  this.shape_29.setTransform(148.775, -11.275);
  this.shape_30 = new cjs.Shape();
  this.shape_30.graphics.f("#0C593C").s().p("AgFAGIAAgLIALAAIAAALg");
  this.shape_30.setTransform(139.675, -8.325);
  this.shape_31 = new cjs.Shape();
  this.shape_31.graphics.f("#0C593C").s().p("AgZAiIAAgHIAEAAQADAAABgDQACgCABgFIAAgRIAAgiIAoAAIAABEIgKAAIAAg7IgUAAIAAAaQAAAQgDAKQgEAIgIAAIgGgBg");
  this.shape_31.setTransform(135.475, -11.15);
  this.shape_32 = new cjs.Shape();
  this.shape_32.graphics.f("#0C593C").s().p("AgXAtIAAgIQAEACAEAAQAEAAADgFQADgDACgHIgWhGIAKAAIAPA3IABAAIAPg3IAKAAIgVBFIgFANQgBAEgEADQgEADgHABIgHgCg");
  this.shape_32.setTransform(130.675, -10);
  this.shape_33 = new cjs.Shape();
  this.shape_33.graphics.f("#0C593C").s().p("AgNAgQgFgFgCgIQgBgIgBgKQAAglAYAAQAKAAAFAHQAFAHAAAKIgJAAQAAgPgLAAQgIAAgCAIQgEAIAAAMQABAMACAIQADAHAHAAQAHAAADgEQACgFAAgIIAJAAQAAALgEAHQgGAIgKAAQgKAAgFgFg");
  this.shape_33.setTransform(126.1, -11.175);
  this.shape_34 = new cjs.Shape();
  this.shape_34.graphics.f("#0C593C").s().p("AAMAjIAAg8IgXAAIAAA8IgKAAIAAhFIArAAIAABFg");
  this.shape_34.setTransform(121.025, -11.175);
  this.shape_35 = new cjs.Shape();
  this.shape_35.graphics.f("#0C593C").s().p("AgXARQAAgGACgEQACgDADgDQAEgCAGgCIALgFQADgBAAgHQAAgGgCgDQgDgCgFAAQgFAAgCADQgCADgBAGIgJAAQABgVATAAQAHAAADADQAFACACAEQACAEAAAFIAAAoQAAAGAEAAIACgBIAAAIIgEABQgFAAgCgCQgCgCgCgHIAAAAQgCAFgEADQgDAEgFAAQgSAAAAgUgAAAABIgGAEIgFAEQgCADAAAFQAAALAKAAQAEAAAEgEIACgDIABgEIAAgGIAAgNIgIADg");
  this.shape_35.setTransform(116, -11.175);
  this.shape_36 = new cjs.Shape();
  this.shape_36.graphics.f("#0C593C").s().p("AAMAjIgRgjIgHAKIAAAZIgKAAIAAhFIAKAAIAAAhIAXghIALAAIgVAbIAWAqg");
  this.shape_36.setTransform(111.675, -11.175);
  this.shape_37 = new cjs.Shape();
  this.shape_37.graphics.f("#0C593C").s().p("AgLAhQgFgDgDgIQgCgIAAgOQAAgkAVAAQAKAAAFAGQAEAFACAIQABAHAAALIghAAIABAPQAAAGAEADQACADAEAAQAMAAAAgQIAKAAQAAAHgCAFQgDAGgEADQgFAEgHAAQgHAAgFgEgAgJgVQgCAGAAAJIAXAAQAAgKgDgGQgCgFgHAAQgGAAgDAGg");
  this.shape_37.setTransform(104.3, -11.175);
  this.shape_38 = new cjs.Shape();
  this.shape_38.graphics.f("#0C593C").s().p("AAVAjIAAg8IgSA8IgFAAIgSg8IAAA8IgJAAIAAhFIAPAAIANAtIABAOIACgOIANgtIAPAAIAABFg");
  this.shape_38.setTransform(98.475, -11.175);
  this.shape_39 = new cjs.Shape();
  this.shape_39.graphics.f("#0C593C").s().p("AgWAwIAAhdIAJAAIAAAIQACgFAEgCQAFgDACAAQAYABAAAjIgBAPQgBAGgDAFQgDAFgEADQgEADgHAAQgEAAgDgCQgDgCgDgFIAAAfgAgKgeQgCAIAAAMIAAAOQABAFADAFQADADAFAAQAHAAADgHQADgHAAgOQAAgbgNAAQgHAAgDAIg");
  this.shape_39.setTransform(92.4, -10.1);
  this.shape_40 = new cjs.Shape();
  this.shape_40.graphics.f("#0C593C").s().p("AgMAhQgGgDgDgIQgDgIAAgOQAAgRAGgJQAGgKAMAAQAZAAAAAkQAAAOgDAIQgDAIgGADQgFAEgIAAQgHAAgFgEgAgIgYQgDACgBAHQgCAGAAAKQAAAJACAGQABAGADADQADADAFAAQAGAAADgDQADgDABgGQACgGAAgJQAAgKgCgGQgBgHgEgCQgDgDgFAAQgEAAgEADg");
  this.shape_40.setTransform(86.875, -11.175);
  this.shape_41 = new cjs.Shape();
  this.shape_41.graphics.f("#0C593C").s().p("AgEA7IAAgfIgGAHQgEACgFAAQgJAAgFgFQgEgFgCgJQgCgIAAgKQAAgKACgIQACgIAFgEQAFgGAJAAQAEABAEACQAEACACAFIAAgfIAJAAIAAAfQACgEAEgDQAEgCAEgBQAMAAAGAKQAFAKAAAQQAAAlgWAAQgFAAgEgCIgGgHIAAAfgAAHgTQgCAJAAAKQAAANACAIQADAHAIAAQAIAAADgHQADgHAAgOQAAgbgOAAQgIAAgDAIgAgfAAQAAAOADAHQADAHAIAAQAGAAADgDQACgFABgGIABgOQAAgKgCgJQgDgIgIAAQgOAAAAAbg");
  this.shape_41.setTransform(79.775, -11.2);
  this.shape_42 = new cjs.Shape();
  this.shape_42.graphics.f("#0C593C").s().p("AgUAjIAAhFIAVAAQAIAAAGAFQAFAEAAAIQAAAGgDAFQgDAEgFABIAAABQAGAAADAEQADAFAAAHQAAAGgCAEQgCAEgEADQgEACgFAAgAgLAbIALAAQAHAAACgDQACgDAAgHQAAgFgCgDQgDgDgFAAIgMAAgAgLgEIALAAQAFAAACgDQADgDAAgFQAAgLgKAAIgLAAg");
  this.shape_42.setTransform(70.875, -11.175);
  this.shape_43 = new cjs.Shape();
  this.shape_43.graphics.f("#0C593C").s().p("AgLAhQgFgDgCgIQgDgIAAgOQAAgkAVAAQAKAAAEAGQAFAFABAIQACAHAAALIghAAIABAPQABAGADADQACADAFAAQALAAAAgQIAKAAQAAAHgCAFQgDAGgFADQgEAEgHAAQgHAAgFgEgAgIgVQgDAGAAAJIAWAAQAAgKgBgGQgDgFgHAAQgGAAgCAGg");
  this.shape_43.setTransform(63.65, -11.175);
  this.shape_44 = new cjs.Shape();
  this.shape_44.graphics.f("#0C593C").s().p("AAMAjIgRgjIgHAKIAAAZIgKAAIAAhFIAKAAIAAAhIAXghIALAAIgVAbIAWAqg");
  this.shape_44.setTransform(59.375, -11.175);
  this.shape_45 = new cjs.Shape();
  this.shape_45.graphics.f("#0C593C").s().p("AAMAjIAAghIgXAAIAAAhIgKAAIAAhFIAKAAIAAAdIAXAAIAAgdIAKAAIAABFg");
  this.shape_45.setTransform(53.925, -11.175);
  this.shape_46 = new cjs.Shape();
  this.shape_46.graphics.f("#0C593C").s().p("AAWAjIAAhFIAKAAIAABFgAgfAjIAAhFIAJAAIAAAeIAPAAQAFAAAEACQAEACADAEQACAFAAAGQAAAGgCAEQgDAFgEACQgDADgGAAgAgWAbIALAAQAHAAADgDQACgDAAgGQAAgMgLAAIgMAAg");
  this.shape_46.setTransform(47.55, -11.175);
  this.shape_47 = new cjs.Shape();
  this.shape_47.graphics.f("#0C593C").s().p("AgWAwIAAhdIAJAAIAAAIQADgFAEgCQAEgDACAAQAXABAAAjIAAAPQgCAGgCAFQgCAFgFADQgEADgGAAQgFAAgDgCQgDgCgDgFIAAAfgAgKgeQgDAIABAMIAAAOQABAFADAFQADADAFAAQAHAAADgHQADgHAAgOQAAgbgNAAQgHAAgDAIg");
  this.shape_47.setTransform(41.3, -10.1);
  this.shape_48 = new cjs.Shape();
  this.shape_48.graphics.f("#0C593C").s().p("AgXARQAAgGACgEQACgDADgDQADgCAHgCIAMgFQACgBAAgHQAAgGgCgDQgDgCgEAAQgGAAgCADQgDADABAGIgJAAQAAgVAUAAQAGAAADADQAFACACAEQACAEAAAFIAAAoQAAAGAEAAIACgBIAAAIIgEABQgFAAgCgCQgDgCgBgHIAAAAQgCAFgEADQgDAEgGAAQgRAAAAgUgAAAABIgHAEIgEAEQgCADAAAFQAAALAKAAQAEAAAFgEIABgDIABgEIAAgGIAAgNIgIADg");
  this.shape_48.setTransform(33.9, -11.175);
  this.shape_49 = new cjs.Shape();
  this.shape_49.graphics.f("#0C593C").s().p("AAMAjIAAghIgXAAIAAAhIgKAAIAAhFIAKAAIAAAdIAXAAIAAgdIAKAAIAABFg");
  this.shape_49.setTransform(28.825, -11.175);
  this.shape_50 = new cjs.Shape();
  this.shape_50.graphics.f("#0C593C").s().p("AAQAjIgQgdIgQAdIgKAAIAWgjIgUgiIAKAAIAPAbIAPgbIAKAAIgUAiIAVAjg");
  this.shape_50.setTransform(318.775, -23.675);
  this.shape_51 = new cjs.Shape();
  this.shape_51.graphics.f("#0C593C").s().p("AAWAjIAAhFIAKAAIAABFgAgfAjIAAhFIAJAAIAAAeIAPAAQAGAAADACQAEACACAEQADAFAAAGQAAAGgDAEQgCAFgEACQgDADgGAAgAgWAbIALAAQAHAAADgDQACgDAAgGQAAgMgLAAIgMAAg");
  this.shape_51.setTransform(312.75, -23.675);
  this.shape_52 = new cjs.Shape();
  this.shape_52.graphics.f("#0C593C").s().p("AAMAjIAAghIgXAAIAAAhIgKAAIAAhFIAKAAIAAAdIAXAAIAAgdIAKAAIAABFg");
  this.shape_52.setTransform(306.375, -23.675);
  this.shape_53 = new cjs.Shape();
  this.shape_53.graphics.f("#0C593C").s().p("AAMAjIAAghIgXAAIAAAhIgKAAIAAhFIAKAAIAAAdIAXAAIAAgdIAKAAIAABFg");
  this.shape_53.setTransform(300.975, -23.675);
  this.shape_54 = new cjs.Shape();
  this.shape_54.graphics.f("#0C593C").s().p("AgLAhQgFgDgDgIQgCgIAAgOQAAgkAVAAQAJAAAGAGQAEAFACAIQABAHAAALIghAAIABAPQABAGACADQADADAEAAQAMAAAAgQIAKAAQAAAHgDAFQgCAGgEADQgFAEgHAAQgHAAgFgEgAgJgVQgCAGAAAJIAXAAQgBgKgCgGQgCgFgHAAQgGAAgDAGg");
  this.shape_54.setTransform(295.9, -23.675);
  this.shape_55 = new cjs.Shape();
  this.shape_55.graphics.f("#0C593C").s().p("AgZAiIAAgHIAEAAQADAAABgDQACgBABgGIAAgRIAAgiIAoAAIAABFIgKAAIAAg8IgUAAIAAAaQAAARgDAJQgEAIgIAAIgGgBg");
  this.shape_55.setTransform(290.525, -23.65);
  this.shape_56 = new cjs.Shape();
  this.shape_56.graphics.f("#0C593C").s().p("AgUAjIAAhFIAVAAQAIAAAGAFQAFAEAAAIQAAAGgDAFQgDAEgFABIAAABQAGAAADAEQADAFAAAHQAAAGgCAEQgCAEgEADQgEACgFAAgAgLAbIALAAQAHAAACgDQACgDAAgHQAAgFgCgDQgDgDgFAAIgMAAgAgLgEIALAAQAFAAACgDQADgDAAgFQAAgLgKAAIgLAAg");
  this.shape_56.setTransform(285.925, -23.675);
  this.shape_57 = new cjs.Shape();
  this.shape_57.graphics.f("#0C593C").s().p("AgXARQAAgGABgEQACgDAEgDQAEgCAGgCIALgFQADgBAAgHQAAgGgCgDQgCgCgGAAQgFAAgCADQgDADAAAGIgJAAQAAgVAVAAQAFAAAFADQAEACACAEQACAEAAAFIAAAoQAAAGAEAAIACgBIAAAIIgEABQgFAAgDgCQgBgCgBgHIgBAAQgCAFgEADQgEAEgEAAQgSAAAAgUgAABABIgHAEIgFAEQgCADAAAFQAAALAJAAQAGAAADgEIACgDIABgEIAAgGIAAgNIgHADg");
  this.shape_57.setTransform(281, -23.675);
  this.shape_58 = new cjs.Shape();
  this.shape_58.graphics.f("#0C593C").s().p("AgEAjIAAg8IgSAAIAAgJIAtAAIAAAJIgSAAIAAA8g");
  this.shape_58.setTransform(276.7, -23.675);
  this.shape_59 = new cjs.Shape();
  this.shape_59.graphics.f("#0C593C").s().p("AgMAgQgGgFgCgIQgBgIAAgKQAAglAWAAQAKAAAGAHQAGAHAAAKIgKAAQAAgPgMAAQgGAAgEAIQgCAIAAAMQgBAMADAIQACAHAIAAQAHAAACgEQACgFABgIIAKAAQgBALgFAHQgEAIgMAAQgIAAgFgFg");
  this.shape_59.setTransform(272.4, -23.675);
  this.shape_60 = new cjs.Shape();
  this.shape_60.graphics.f("#0C593C").s().p("AAUAsIAAgTIgnAAIAAATIgJAAIAAgbIAGAAIAFgMIACgKIABgPIAAgXIAlAAIAAA8IAGAAIAAAbgAgFgPQAAAKgBAGIgGAQIAZAAIAAg0IgSAAg");
  this.shape_60.setTransform(267.225, -22.725);
  this.shape_61 = new cjs.Shape();
  this.shape_61.graphics.f("#0C593C").s().p("AgLAhQgFgDgCgIQgDgIAAgOQAAgkAVAAQAKAAAEAGQAFAFABAIQACAHAAALIghAAIABAPQABAGADADQACADAFAAQALAAAAgQIAKAAQAAAHgCAFQgDAGgFADQgEAEgHAAQgHAAgFgEgAgIgVQgDAGAAAJIAWAAQAAgKgBgGQgDgFgHAAQgGAAgCAGg");
  this.shape_61.setTransform(262.1, -23.675);
  this.shape_62 = new cjs.Shape();
  this.shape_62.graphics.f("#0C593C").s().p("AgWAwIAAhdIAJAAIAAAIQACgEAEgDQAFgDACAAQAYAAAAAkIgBAPQgBAGgDAFQgDAFgEADQgEADgHAAQgEAAgDgDQgDgCgDgEIAAAfgAgKgeQgDAIABAMIAAAOQABAGADAEQADADAFAAQAHABADgIQADgHAAgOQAAgbgNAAQgHAAgDAIg");
  this.shape_62.setTransform(257.2, -22.6);
  this.shape_63 = new cjs.Shape();
  this.shape_63.graphics.f("#0C593C").s().p("AAMAjIAAg8IgXAAIAAA8IgKAAIAAhFIArAAIAABFg");
  this.shape_63.setTransform(251.675, -23.675);
  this.shape_64 = new cjs.Shape();
  this.shape_64.graphics.f("#0C593C").s().p("AgFAKQAFgCAAgKIgFAAIAAgMIALAAIAAAOQAAAFgDAEQgDAFgFABg");
  this.shape_64.setTransform(245.625, -19.925);
  this.shape_65 = new cjs.Shape();
  this.shape_65.graphics.f("#0C593C").s().p("AgUAjIAAhFIAVAAQAIAAAGAFQAFAEAAAIQAAAGgDAFQgDAEgFABIAAABQAGAAADAEQADAFAAAHQAAAGgCAEQgCAEgEADQgEACgFAAgAgLAbIALAAQAHAAACgDQACgDAAgHQAAgFgCgDQgDgDgFAAIgMAAgAgLgEIALAAQAFAAACgDQADgDAAgFQAAgLgKAAIgLAAg");
  this.shape_65.setTransform(242.225, -23.675);
  this.shape_66 = new cjs.Shape();
  this.shape_66.graphics.f("#0C593C").s().p("AgEAjIAAg8IgSAAIAAgJIAtAAIAAAJIgSAAIAAA8g");
  this.shape_66.setTransform(237.7, -23.675);
  this.shape_67 = new cjs.Shape();
  this.shape_67.graphics.f("#0C593C").s().p("AgNAgQgFgFgCgIQgCgIAAgKQAAglAYAAQAKAAAFAHQAGAHgBAKIgJAAQAAgPgLAAQgIAAgCAIQgDAIgBAMQAAAMADAIQADAHAHAAQAHAAACgEQADgFAAgIIAJAAQAAALgEAHQgGAIgKAAQgJAAgGgFg");
  this.shape_67.setTransform(233.4, -23.675);
  this.shape_68 = new cjs.Shape();
  this.shape_68.graphics.f("#0C593C").s().p("AAUAsIAAgTIgnAAIAAATIgJAAIAAgbIAGAAIAFgMIACgKIABgPIAAgXIAlAAIAAA8IAGAAIAAAbgAgFgPQAAAKgBAGIgGAQIAZAAIAAg0IgSAAg");
  this.shape_68.setTransform(228.225, -22.725);
  this.shape_69 = new cjs.Shape();
  this.shape_69.graphics.f("#0C593C").s().p("AgLAhQgFgDgDgIQgCgIAAgOQAAgkAVAAQAKAAAFAGQAEAFACAIQABAHAAALIghAAIABAPQAAAGAEADQACADAEAAQAMAAAAgQIAKAAQAAAHgCAFQgDAGgEADQgFAEgHAAQgHAAgFgEgAgJgVQgCAGAAAJIAXAAQAAgKgDgGQgCgFgHAAQgGAAgDAGg");
  this.shape_69.setTransform(223.1, -23.675);
  this.shape_70 = new cjs.Shape();
  this.shape_70.graphics.f("#0C593C").s().p("AgXAwIAAhdIAKAAIAAAIQADgEADgDQAFgDADAAQAXAAAAAkIgCAPQgBAGgCAFQgDAFgEADQgFADgGAAQgDAAgEgDQgEgCgDgEIAAAfgAgKgeQgDAIAAAMIABAOQABAGADAEQADADAFAAQAHABADgIQADgHAAgOQAAgbgNAAQgIAAgCAIg");
  this.shape_70.setTransform(218.2, -22.6);
  this.shape_71 = new cjs.Shape();
  this.shape_71.graphics.f("#0C593C").s().p("AgNAgQgFgFgCgIQgBgIgBgKQAAglAYAAQAKAAAFAHQAGAHgBAKIgJAAQAAgPgLAAQgIAAgCAIQgEAIAAAMQAAAMADAIQADAHAHAAQAHAAADgEQACgFAAgIIAJAAQAAALgEAHQgGAIgKAAQgJAAgGgFg");
  this.shape_71.setTransform(213.05, -23.675);
  this.shape_72 = new cjs.Shape();
  this.shape_72.graphics.f("#0C593C").s().p("AAQAjIgQgdIgQAdIgKAAIAWgjIgUgiIAKAAIAPAbIAPgbIAKAAIgUAiIAVAjg");
  this.shape_72.setTransform(206.075, -23.675);
  this.shape_73 = new cjs.Shape();
  this.shape_73.graphics.f("#0C593C").s().p("AAWAjIAAhFIAKAAIAABFgAgfAjIAAhFIAKAAIAAAeIAOAAQAFAAAEACQAEACACAEQADAFAAAGQAAAGgDAEQgCAFgFACQgDADgFAAgAgVAbIAKAAQAHAAADgDQACgDAAgGQAAgMgLAAIgLAAg");
  this.shape_73.setTransform(200.05, -23.675);
  this.shape_74 = new cjs.Shape();
  this.shape_74.graphics.f("#0C593C").s().p("AAMAjIAAghIgXAAIAAAhIgKAAIAAhFIAKAAIAAAdIAXAAIAAgdIAKAAIAABFg");
  this.shape_74.setTransform(193.675, -23.675);
  this.shape_75 = new cjs.Shape();
  this.shape_75.graphics.f("#0C593C").s().p("AAMAjIAAghIgXAAIAAAhIgKAAIAAhFIAKAAIAAAdIAXAAIAAgdIAKAAIAABFg");
  this.shape_75.setTransform(188.275, -23.675);
  this.shape_76 = new cjs.Shape();
  this.shape_76.graphics.f("#0C593C").s().p("AgMAhQgGgDgDgIQgDgIAAgOQAAgRAGgJQAGgKAMAAQAZAAAAAkQAAAOgDAIQgDAIgGADQgFAEgIAAQgHAAgFgEgAgIgYQgDACgBAHQgCAGAAAKQAAAJACAGQABAGADADQADADAFAAQAGAAADgDQADgDABgGQACgGAAgJQAAgKgCgGQgBgHgEgCQgDgDgFAAQgEAAgEADg");
  this.shape_76.setTransform(182.875, -23.675);
  this.shape_77 = new cjs.Shape();
  this.shape_77.graphics.f("#0C593C").s().p("AgRAjIAAhFIAkAAIAAAJIgaAAIAAA8g");
  this.shape_77.setTransform(178.75, -23.675);
  this.shape_78 = new cjs.Shape();
  this.shape_78.graphics.f("#0C593C").s().p("AgMAhQgGgDgDgIQgDgIAAgOQAAgRAGgJQAGgKAMAAQAZAAAAAkQAAAOgDAIQgDAIgGADQgFAEgIAAQgHAAgFgEgAgIgYQgDACgBAHQgCAGAAAKQAAAJACAGQABAGADADQADADAFAAQAGAAADgDQADgDABgGQACgGAAgJQAAgKgCgGQgBgHgEgCQgDgDgFAAQgEAAgEADg");
  this.shape_78.setTransform(173.725, -23.675);
  this.shape_79 = new cjs.Shape();
  this.shape_79.graphics.f("#0C593C").s().p("AgWAwIAAhdIAJAAIAAAIQACgEAEgDQAFgDACAAQAYAAAAAkIgBAPQgBAGgDAFQgDAFgEADQgEADgHAAQgEAAgDgDQgDgCgDgEIAAAfgAgKgeQgCAIAAAMIAAAOQABAGADAEQADADAFAAQAHABADgIQADgHAAgOQAAgbgNAAQgHAAgDAIg");
  this.shape_79.setTransform(168.45, -22.6);
  this.shape_80 = new cjs.Shape();
  this.shape_80.graphics.f("#0C593C").s().p("AgEAjIAAg8IgSAAIAAgJIAtAAIAAAJIgSAAIAAA8g");
  this.shape_80.setTransform(163.7, -23.675);
  this.shape_81 = new cjs.Shape();
  this.shape_81.graphics.f("#0C593C").s().p("AgLAhQgFgDgCgIQgDgIAAgOQAAgkAVAAQAJAAAGAGQAEAFABAIQACAHAAALIghAAIABAPQAAAGADADQADADAEAAQAMAAAAgQIAKAAQAAAHgDAFQgBAGgGADQgEAEgHAAQgHAAgFgEgAgJgVQgCAGAAAJIAWAAQAAgKgCgGQgCgFgHAAQgGAAgDAGg");
  this.shape_81.setTransform(159.35, -23.675);
  this.shape_82 = new cjs.Shape();
  this.shape_82.graphics.f("#0C593C").s().p("AgUAjIAAhFIAVAAQAIAAAGAFQAFAEAAAIQAAAGgDAFQgDAEgFABIAAABQAGAAADAEQADAFAAAHQAAAGgCAEQgCAEgEADQgEACgFAAgAgLAbIALAAQAHAAACgDQACgDAAgHQAAgFgCgDQgDgDgFAAIgMAAgAgLgEIALAAQAFAAACgDQADgDAAgFQAAgLgKAAIgLAAg");
  this.shape_82.setTransform(154.775, -23.675);
  this.shape_83 = new cjs.Shape();
  this.shape_83.graphics.f("#0C593C").s().p("AgEAjIAAg8IgSAAIAAgJIAtAAIAAAJIgSAAIAAA8g");
  this.shape_83.setTransform(148, -23.675);
  this.shape_84 = new cjs.Shape();
  this.shape_84.graphics.f("#0C593C").s().p("AgMAhQgGgDgDgIQgDgIAAgOQAAgRAGgJQAGgKAMAAQAZAAAAAkQAAAOgDAIQgDAIgGADQgFAEgIAAQgHAAgFgEgAgIgYQgDACgBAHQgCAGAAAKQAAAJACAGQABAGADADQADADAFAAQAGAAADgDQADgDABgGQACgGAAgJQAAgKgCgGQgBgHgEgCQgDgDgFAAQgEAAgEADg");
  this.shape_84.setTransform(143.325, -23.675);
  this.shape_85 = new cjs.Shape();
  this.shape_85.graphics.f("#0C593C").s().p("AgLAhQgFgDgDgIQgCgIAAgOQAAgkAVAAQAKAAAEAGQAFAFACAIQABAHAAALIghAAIABAPQABAGADADQACADAFAAQALAAAAgQIAKAAQAAAHgCAFQgDAGgEADQgFAEgHAAQgHAAgFgEgAgIgVQgDAGAAAJIAXAAQAAgKgCgGQgDgFgHAAQgGAAgCAGg");
  this.shape_85.setTransform(136, -23.675);
  this.shape_86 = new cjs.Shape();
  this.shape_86.graphics.f("#0C593C").s().p("AANAjIAAg0IACgIIgDAIIgWA0IgMAAIAAhFIAKAAIAAA0IgBAIIACgIIAWg0IAMAAIAABFg");
  this.shape_86.setTransform(130.9, -23.675);
  this.shape_87 = new cjs.Shape();
  this.shape_87.graphics.f("#0C593C").s().p("AAMAjIAAghQgHACgIAAQgJAAgDgEQgFgFAAgIIAAgVIAKAAIAAAUQAAAGACACQACACAGAAIAMAAIAAgeIAJAAIAABFg");
  this.shape_87.setTransform(125.55, -23.675);
  this.shape_88 = new cjs.Shape();
  this.shape_88.graphics.f("#0C593C").s().p("AANAjIAAg0IABgIIgCAIIgWA0IgMAAIAAhFIAKAAIAAA0IgBAIIACgIIAXg0IALAAIAABFg");
  this.shape_88.setTransform(120.25, -23.675);
  this.shape_89 = new cjs.Shape();
  this.shape_89.graphics.f("#0C593C").s().p("AgZAiIAAgHIAEAAQADAAABgDQACgBABgGIAAgRIAAgiIAoAAIAABFIgKAAIAAg8IgUAAIAAAaQAAARgDAJQgEAIgIAAIgGgBg");
  this.shape_89.setTransform(114.475, -23.65);
  this.shape_90 = new cjs.Shape();
  this.shape_90.graphics.f("#0C593C").s().p("AgEAjIAAg8IgSAAIAAgJIAtAAIAAAJIgSAAIAAA8g");
  this.shape_90.setTransform(110.2, -23.675);
  this.shape_91 = new cjs.Shape();
  this.shape_91.graphics.f("#0C593C").s().p("AgMAhQgGgDgDgIQgDgIAAgOQAAgRAGgJQAGgKAMAAQAZAAAAAkQAAAOgDAIQgDAIgGADQgFAEgIAAQgHAAgFgEgAgIgYQgDACgBAHQgCAGAAAKQAAAJACAGQABAGADADQADADAFAAQAGAAADgDQADgDABgGQACgGAAgJQAAgKgCgGQgBgHgEgCQgDgDgFAAQgEAAgEADg");
  this.shape_91.setTransform(105.525, -23.675);
  this.shape_92 = new cjs.Shape();
  this.shape_92.graphics.f("#0C593C").s().p("AgUAjIAAhFIAVAAQAIAAAGAFQAFAEAAAIQAAAGgDAFQgDAEgFABIAAABQAGAAADAEQADAFAAAHQAAAGgCAEQgCAEgEADQgEACgFAAgAgLAbIALAAQAHAAACgDQACgDAAgHQAAgFgCgDQgDgDgFAAIgMAAgAgLgEIALAAQAFAAACgDQADgDAAgFQAAgLgKAAIgLAAg");
  this.shape_92.setTransform(98.325, -23.675);
  this.shape_93 = new cjs.Shape();
  this.shape_93.graphics.f("#0C593C").s().p("AgFAKQAFgCAAgKIgFAAIAAgMIALAAIAAAOQAAAFgDAEQgDAFgFABg");
  this.shape_93.setTransform(92.375, -19.925);
  this.shape_94 = new cjs.Shape();
  this.shape_94.graphics.f("#0C593C").s().p("AgNAtQgGgFgDgHQgDgIgBgIIgBgRQAAgNACgKQACgLAHgHQAHgHAKAAQAJAAAGAEQAGAEADAHQADAHAAAIIgKAAQAAgUgRAAQgLAAgDALQgDALAAAQIAAAOIACANQACAGAEADQAEAEAFAAQAGAAAEgEQADgDACgGIACgOIAKAAQgBAMgCAHQgCAIgGAFQgGAEgJAAQgJAAgGgEg");
  this.shape_94.setTransform(88.175, -24.875);
  this.shape_95 = new cjs.Shape();
  this.shape_95.graphics.f("#0C593C").s().p("AghAvIAAgJIAEABQAGgBABgFQADgEABgJIAAgZIAAgqIAzAAIAABeIgKAAIAAhUIgeAAIAAAlIgBARIgCAPQgCAHgDAEQgEAFgHAAIgHgBg");
  this.shape_95.setTransform(81.2, -24.85);
  this.shape_96 = new cjs.Shape();
  this.shape_96.graphics.f("#0C593C").s().p("AgaAvIAAhdIAaAAQAMAAAIAHQAHAGAAAOQAAAHgCAGQgCAFgEACQgEADgGACQgFABgGAAIgOAAIAAAogAgQgBIAKAAQAHAAAFgCQAFgBADgEQACgEAAgHQAAgKgFgEQgFgDgJAAIgNAAg");
  this.shape_96.setTransform(75.375, -24.875);
  this.shape_97 = new cjs.Shape();
  this.shape_97.graphics.f("#0C593C").s().p("AgXAvIAAhdIAvAAIAAAKIglAAIAABTg");
  this.shape_97.setTransform(69.825, -24.875);
  this.shape_98 = new cjs.Shape();
  this.shape_98.graphics.f("#0C593C").s().p("AAVAjIAAg8IgSA8IgFAAIgSg8IAAA8IgJAAIAAhFIAPAAIANAtIABAOIACgOIANgtIAPAAIAABFg");
  this.shape_98.setTransform(61.025, -23.675);
  this.shape_99 = new cjs.Shape();
  this.shape_99.graphics.f("#0C593C").s().p("AAWAjIAAhFIAKAAIAABFgAgfAjIAAhFIAJAAIAAAeIAPAAQAFAAAEACQAEACADAEQACAFAAAGQAAAGgCAEQgDAFgEACQgDADgGAAgAgWAbIALAAQAHAAADgDQACgDAAgGQAAgMgLAAIgMAAg");
  this.shape_99.setTransform(53.85, -23.675);
  this.shape_100 = new cjs.Shape();
  this.shape_100.graphics.f("#0C593C").s().p("AAMAjIAAghIgXAAIAAAhIgKAAIAAhFIAKAAIAAAdIAXAAIAAgdIAKAAIAABFg");
  this.shape_100.setTransform(47.475, -23.675);
  this.shape_101 = new cjs.Shape();
  this.shape_101.graphics.f("#0C593C").s().p("AAMAjIAAghIgXAAIAAAhIgKAAIAAhFIAKAAIAAAdIAXAAIAAgdIAKAAIAABFg");
  this.shape_101.setTransform(42.075, -23.675);
  this.shape_102 = new cjs.Shape();
  this.shape_102.graphics.f("#0C593C").s().p("AgXARQAAgGACgEQACgDADgDQADgCAHgCIAMgFQACgBAAgHQAAgGgCgDQgDgCgEAAQgGAAgCADQgDADABAGIgJAAQAAgVATAAQAHAAADADQAFACACAEQACAEAAAFIAAAoQAAAGAEAAIACgBIAAAIIgEABQgFAAgCgCQgDgCgBgHIAAAAQgCAFgEADQgDAEgGAAQgRAAAAgUgAAAABIgHAEIgEAEQgCADAAAFQAAALAKAAQAEAAAFgEIABgDIABgEIAAgGIAAgNIgIADg");
  this.shape_102.setTransform(37.05, -23.675);
  this.shape_103 = new cjs.Shape();
  this.shape_103.graphics.f("#0C593C").s().p("AAUAsIAAgTIgnAAIAAATIgJAAIAAgbIAGAAIAFgMIACgKIABgPIAAgXIAlAAIAAA8IAGAAIAAAbgAgFgPQAAAKgBAGIgGAQIAZAAIAAg0IgSAAg");
  this.shape_103.setTransform(31.875, -22.725);
  this.shape_104 = new cjs.Shape();
  this.shape_104.graphics.f("#0C593C").s().p("AgMAhQgGgDgDgIQgDgIAAgOQAAgRAGgJQAGgKAMAAQAZAAAAAkQAAAOgDAIQgDAIgGADQgFAEgIAAQgHAAgFgEgAgIgYQgDACgBAHQgCAGAAAKQAAAJACAGQABAGADADQADADAFAAQAGAAADgDQADgDABgGQACgGAAgJQAAgKgCgGQgBgHgEgCQgDgDgFAAQgEAAgEADg");
  this.shape_104.setTransform(24.175, -23.675);
  this.shape_105 = new cjs.Shape();
  this.shape_105.graphics.f("#0C593C").s().p("AASAvIAAhTIgjAAIAABTIgKAAIAAhdIA3AAIAABdg");
  this.shape_105.setTransform(18.075, -24.875);
  this.shape_106 = new cjs.Shape();
  this.shape_106.graphics.f("#0C593C").s().p("AgFAGIAAgLIALAAIAAALg");
  this.shape_106.setTransform(326.125, -33.325);
  this.shape_107 = new cjs.Shape();
  this.shape_107.graphics.f("#0C593C").s().p("AgLAhQgFgDgCgIQgDgIAAgOQAAgkAVAAQAJAAAGAGQAEAFABAIQACAHAAALIghAAIABAPQAAAGADADQADADAEAAQAMAAAAgQIAKAAQAAAHgDAFQgBAGgGADQgEAEgHAAQgHAAgFgEgAgIgVQgDAGAAAJIAWAAQAAgKgCgGQgCgFgHAAQgGAAgCAGg");
  this.shape_107.setTransform(322.6, -36.175);
  this.shape_108 = new cjs.Shape();
  this.shape_108.graphics.f("#0C593C").s().p("AgEAjIAAg8IgSAAIAAgJIAtAAIAAAJIgSAAIAAA8g");
  this.shape_108.setTransform(318.35, -36.175);
  this.shape_109 = new cjs.Shape();
  this.shape_109.graphics.f("#0C593C").s().p("AgWAwIAAhdIAJAAIAAAIQACgEAEgCQAFgEACAAQAYAAAAAkIgBAPQgBAGgDAFQgDAFgEADQgEADgHAAQgEAAgDgDQgDgCgDgEIAAAfgAgKgeQgCAIAAAMIAAAOQABAFADAEQADAEAFAAQAHABADgIQADgHAAgOQAAgbgNAAQgHAAgDAIg");
  this.shape_109.setTransform(313.8, -35.1);
  this.shape_110 = new cjs.Shape();
  this.shape_110.graphics.f("#0C593C").s().p("AgMAhQgGgDgDgIQgDgIAAgOQAAgRAGgJQAGgKAMAAQAZAAAAAkQAAAOgDAIQgDAIgGADQgFAEgIAAQgHAAgFgEgAgIgYQgDACgBAHQgCAGAAAKQAAAJACAGQABAGADADQADADAFAAQAGAAADgDQADgDABgGQACgGAAgJQAAgKgCgGQgBgHgEgCQgDgDgFAAQgEAAgEADg");
  this.shape_110.setTransform(308.275, -36.175);
  this.shape_111 = new cjs.Shape();
  this.shape_111.graphics.f("#0C593C").s().p("AgEAvIAAgMIgDAAQgJAAgIgDQgHgEgFgJQgEgIAAgLQAAgMAEgIQAFgIAIgEQAHgEAJAAIADAAIAAgKIAJAAIAAAKIADAAQAJAAAHAEQAIAEAFAIQAEAIAAAMQAAALgEAIQgFAJgHAEQgIADgJAAIgDAAIAAAMgAAFAaIADAAQAGAAAGgDQAFgDADgGQADgGAAgIQAAgNgHgHQgGgHgKAAIgDAAgAgTgYQgFADgDAGQgDAGAAAJQAAAIADAGQADAGAFADQAFADAHAAIADAAIAAg1IgDAAQgGAAgGADg");
  this.shape_111.setTransform(301.375, -37.375);
  this.shape_112 = new cjs.Shape();
  this.shape_112.graphics.f("#0C593C").s().p("AgLAiQgFgCgCgGQgDgFAAgIIAJAAIACAJQABADADACQACABAEAAQAMAAAAgNQAAgFgDgEQgDgDgFAAIgFAAIAAgIIAEAAQAFAAADgDQADgDAAgFQAAgFgDgDQgDgDgFAAQgFAAgDADQgDADAAAGIgJAAQAAgGACgEQADgFAFgDQAFgDAFAAQAGAAAEADQAFACADAEQACAEAAAFQAAAHgDAEQgEAEgFACIAAAAQAGABAEAEQAEAEAAAIQAAAGgDAFQgCAEgFADQgFADgHAAQgGAAgFgDg");
  this.shape_112.setTransform(292.725, -36.175);
  this.shape_113 = new cjs.Shape();
  this.shape_113.graphics.f("#0C593C").s().p("AgXARQAAgGABgEQACgDAEgDQAEgCAGgCIALgFQADgBAAgHQAAgGgCgDQgCgCgGAAQgFAAgCADQgDADAAAGIgJAAQAAgVAVAAQAFAAAFADQAEACACAEQACAEAAAFIAAAoQAAAGAEAAIACgBIAAAIIgEABQgFAAgDgCQgBgCgBgHIgBAAQgCAFgEADQgEAEgFAAQgRAAAAgUgAABABIgHAEIgFAEQgCADAAAFQAAALAJAAQAGAAADgEIACgDIABgEIAAgGIAAgNIgHADg");
  this.shape_113.setTransform(288.2, -36.175);
  this.shape_114 = new cjs.Shape();
  this.shape_114.graphics.f("#0C593C").s().p("AgSAjIAAhFIAlAAIAAAJIgaAAIAAA8g");
  this.shape_114.setTransform(284.4, -36.175);
  this.shape_115 = new cjs.Shape();
  this.shape_115.graphics.f("#0C593C").s().p("AgLAhQgFgDgDgIQgCgIAAgOQAAgkAVAAQAJAAAGAGQAEAFACAIQABAHAAALIghAAIABAPQABAGACADQADADAEAAQAMAAAAgQIAKAAQAAAHgDAFQgCAGgEADQgFAEgHAAQgHAAgFgEgAgJgVQgCAGAAAJIAXAAQgBgKgCgGQgCgFgHAAQgGAAgDAGg");
  this.shape_115.setTransform(279.7, -36.175);
  this.shape_116 = new cjs.Shape();
  this.shape_116.graphics.f("#0C593C").s().p("AgZAiIAAgHIAEAAQADAAABgCQACgDABgFIAAgRIAAgiIAoAAIAABFIgKAAIAAg8IgUAAIAAAaQAAARgDAJQgEAIgIAAIgGgBg");
  this.shape_116.setTransform(274.325, -36.15);
  this.shape_117 = new cjs.Shape();
  this.shape_117.graphics.f("#0C593C").s().p("AANAjIAAg0IABgIIgCAIIgWA0IgMAAIAAhFIAKAAIAAA0IgBAIIACgIIAXg0IALAAIAABFg");
  this.shape_117.setTransform(269.2, -36.175);
  this.shape_118 = new cjs.Shape();
  this.shape_118.graphics.f("#0C593C").s().p("AgEAjIAAg8IgSAAIAAgJIAtAAIAAAJIgSAAIAAA8g");
  this.shape_118.setTransform(264.55, -36.175);
  this.shape_119 = new cjs.Shape();
  this.shape_119.graphics.f("#0C593C").s().p("AgMAhQgGgDgDgIQgDgIAAgOQAAgRAGgJQAGgKAMAAQAZAAAAAkQAAAOgDAIQgDAIgGADQgFAEgIAAQgHAAgFgEgAgIgYQgDACgBAHQgCAGAAAKQAAAJACAGQABAGADADQADADAFAAQAGAAADgDQADgDABgGQACgGAAgJQAAgKgCgGQgBgHgEgCQgDgDgFAAQgEAAgEADg");
  this.shape_119.setTransform(259.875, -36.175);
  this.shape_120 = new cjs.Shape();
  this.shape_120.graphics.f("#0C593C").s().p("AAdAvIAAhMIAAgGIAAgGIAAAAIgCAGIgBAGIgUBMIgMAAIgThNIgCgLIgBAAIAAAGIABAGIAABMIgLAAIAAhdIATAAIASBIQABAFAAAJIAAAAIACgOIAThIIASAAIAABdg");
  this.shape_120.setTransform(252.75, -37.375);
  this.shape_121 = new cjs.Shape();
  this.shape_121.graphics.f("#0C593C").s().p("AgXARQAAgGABgEQACgDAEgDQAEgCAGgCIALgFQADgBAAgHQAAgGgCgDQgCgCgFAAQgGAAgCADQgDADAAAGIgJAAQAAgVAVAAQAGAAAEADQAEACACAEQACAEAAAFIAAAoQAAAGAEAAIACgBIAAAIIgEABQgFAAgDgCQgCgCAAgHIgBAAQgCAFgEADQgEAEgFAAQgRAAAAgUgAABABIgIAEIgEAEQgCADAAAFQAAALAJAAQAGAAADgEIACgDIABgEIAAgGIAAgNIgHADg");
  this.shape_121.setTransform(243.75, -36.175);
  this.shape_122 = new cjs.Shape();
  this.shape_122.graphics.f("#0C593C").s().p("AgEAjIAAg8IgSAAIAAgJIAtAAIAAAJIgSAAIAAA8g");
  this.shape_122.setTransform(239.45, -36.175);
  this.shape_123 = new cjs.Shape();
  this.shape_123.graphics.f("#0C593C").s().p("AgXARQAAgGACgEQACgDADgDQAEgCAGgCIAMgFQACgBAAgHQAAgGgCgDQgDgCgFAAQgFAAgCADQgDADABAGIgJAAQAAgVATAAQAHAAADADQAFACACAEQACAEAAAFIAAAoQAAAGAEAAIACgBIAAAIIgEABQgFAAgCgCQgCgCgCgHIAAAAQgCAFgEADQgDAEgFAAQgSAAAAgUgAAAABIgHAEIgEAEQgCADAAAFQAAALAKAAQAFAAAEgEIABgDIABgEIAAgGIAAgNIgIADg");
  this.shape_123.setTransform(235.15, -36.175);
  this.shape_124 = new cjs.Shape();
  this.shape_124.graphics.f("#0C593C").s().p("AgWAwIAAhdIAJAAIAAAIQACgEAEgCQAFgEACAAQAYAAAAAkIgBAPQgBAGgDAFQgDAFgEADQgEADgHAAQgEAAgDgDQgDgCgDgEIAAAfgAgKgeQgDAIABAMIAAAOQABAFADAEQADAEAFAAQAHABADgIQADgHAAgOQAAgbgNAAQgHAAgDAIg");
  this.shape_124.setTransform(230.2, -35.1);
  this.shape_125 = new cjs.Shape();
  this.shape_125.graphics.f("#0C593C").s().p("AgXARQAAgGACgEQABgDAEgDQADgCAHgCIAMgFQACgBAAgHQAAgGgCgDQgDgCgEAAQgGAAgCADQgCADAAAGIgJAAQgBgVAVAAQAFAAAEADQAFACACAEQACAEAAAFIAAAoQAAAGAEAAIACgBIAAAIIgEABQgFAAgDgCQgCgCgBgHIAAAAQgCAFgEADQgDAEgGAAQgRAAAAgUgAAAABIgHAEIgEAEQgCADAAAFQAAALAKAAQAEAAAFgEIABgDIABgEIAAgGIAAgNIgIADg");
  this.shape_125.setTransform(225.05, -36.175);
  this.shape_126 = new cjs.Shape();
  this.shape_126.graphics.f("#0C593C").s().p("AAMAjIAAg8IgXAAIAAA8IgKAAIAAhFIArAAIAABFg");
  this.shape_126.setTransform(219.975, -36.175);
  this.shape_127 = new cjs.Shape();
  this.shape_127.graphics.f("#0C593C").s().p("AgLAhQgFgDgDgIQgCgIAAgOQAAgkAVAAQAJAAAGAGQAEAFACAIQABAHAAALIghAAIABAPQABAGACADQADADAEAAQAMAAAAgQIAKAAQAAAHgDAFQgCAGgEADQgFAEgHAAQgHAAgFgEgAgJgVQgCAGAAAJIAXAAQgBgKgCgGQgCgFgHAAQgGAAgDAGg");
  this.shape_127.setTransform(214.9, -36.175);
  this.shape_128 = new cjs.Shape();
  this.shape_128.graphics.f("#0C593C").s().p("AgXAwIAAhdIAKAAIAAAIQADgEADgCQAFgEADAAQAXAAgBAkIgBAPQAAAGgDAFQgDAFgEADQgFADgGAAQgDAAgEgDQgDgCgEgEIAAAfgAgKgeQgDAIAAAMIABAOQABAFADAEQADAEAFAAQAHABADgIQADgHAAgOQAAgbgNAAQgIAAgCAIg");
  this.shape_128.setTransform(210, -35.1);
  this.shape_129 = new cjs.Shape();
  this.shape_129.graphics.f("#0C593C").s().p("AAMAjIAAg8IgXAAIAAA8IgKAAIAAhFIArAAIAABFg");
  this.shape_129.setTransform(204.475, -36.175);
  this.shape_130 = new cjs.Shape();
  this.shape_130.graphics.f("#0C593C").s().p("AgGAdQgHgIAAgTIgMAAIAAAhIgKAAIAAhFIAKAAIAAAdIAMAAQAAgOAHgIQAGgJALAAQAMAAAHAJQAGAJAAARQAAANgDAJQgDAIgGAEQgFAEgIAAQgLAAgGgIgAADgYQgDADgBAGQgBAGgBAKQAAANADAHQADAHAIAAQAIAAAEgHQACgHAAgNQABgPgEgHQgDgGgIAAQgFAAgDADg");
  this.shape_130.setTransform(195.75, -36.175);
  this.shape_131 = new cjs.Shape();
  this.shape_131.graphics.f("#0C593C").s().p("AAOAjIAAg0IAAgIIgCAIIgWA0IgMAAIAAhFIAKAAIAAA0IgBAIIACgIIAXg0IALAAIAABFg");
  this.shape_131.setTransform(188.9, -36.175);
  this.shape_132 = new cjs.Shape();
  this.shape_132.graphics.f("#0C593C").s().p("AAMAjIAAghIgXAAIAAAhIgKAAIAAhFIAKAAIAAAdIAXAAIAAgdIAKAAIAABFg");
  this.shape_132.setTransform(183.475, -36.175);
  this.shape_133 = new cjs.Shape();
  this.shape_133.graphics.f("#0C593C").s().p("AgLAhQgFgDgCgIQgDgIAAgOQAAgkAVAAQAKAAAEAGQAFAFABAIQACAHAAALIghAAIABAPQABAGADADQACADAFAAQALAAAAgQIAKAAQAAAHgCAFQgDAGgFADQgEAEgHAAQgHAAgFgEgAgIgVQgDAGAAAJIAXAAQAAgKgCgGQgDgFgHAAQgGAAgCAGg");
  this.shape_133.setTransform(178.4, -36.175);
  this.shape_134 = new cjs.Shape();
  this.shape_134.graphics.f("#0C593C").s().p("AAMAjIAAghIgXAAIAAAhIgKAAIAAhFIAKAAIAAAdIAXAAIAAgdIAKAAIAABFg");
  this.shape_134.setTransform(173.375, -36.175);
  this.shape_135 = new cjs.Shape();
  this.shape_135.graphics.f("#0C593C").s().p("AgLAhQgFgDgDgIQgCgIAAgOQAAgkAVAAQAKAAAEAGQAFAFACAIQABAHAAALIghAAIABAPQAAAGAEADQACADAFAAQALAAAAgQIAKAAQAAAHgCAFQgCAGgFADQgFAEgHAAQgHAAgFgEgAgJgVQgCAGAAAJIAXAAQAAgKgCgGQgDgFgHAAQgGAAgDAGg");
  this.shape_135.setTransform(168.3, -36.175);
  this.shape_136 = new cjs.Shape();
  this.shape_136.graphics.f("#0C593C").s().p("AAVAjIAAg8IgSA8IgFAAIgSg8IAAA8IgJAAIAAhFIAPAAIANAtIABAOIACgOIANgtIAPAAIAABFg");
  this.shape_136.setTransform(162.475, -36.175);
  this.shape_137 = new cjs.Shape();
  this.shape_137.graphics.f("#0C593C").s().p("AAOAjIAAg0IABgIIgDAIIgWA0IgMAAIAAhFIAKAAIAAA0IgBAIIACgIIAWg0IAMAAIAABFg");
  this.shape_137.setTransform(156.2, -36.175);
  this.shape_138 = new cjs.Shape();
  this.shape_138.graphics.f("#0C593C").s().p("AgWAwIAAhdIAJAAIAAAIQACgEAEgCQAFgEACAAQAYAAAAAkIgBAPQgBAGgDAFQgDAFgEADQgEADgHAAQgEAAgDgDQgDgCgDgEIAAAfgAgKgeQgCAIAAAMIAAAOQABAFADAEQADAEAFAAQAHABADgIQADgHAAgOQAAgbgNAAQgHAAgDAIg");
  this.shape_138.setTransform(150.9, -35.1);
  this.shape_139 = new cjs.Shape();
  this.shape_139.graphics.f("#0C593C").s().p("AAMAjIAAg8IgXAAIAAA8IgKAAIAAhFIArAAIAABFg");
  this.shape_139.setTransform(145.375, -36.175);
  this.shape_140 = new cjs.Shape();
  this.shape_140.graphics.f("#0C593C").s().p("AgXAuIAAgJQAEABAEABQAEAAADgFQADgDACgHIgWhGIAKAAIAPA3IABAAIAPg3IAKAAIgVBFIgFANQgBAEgEADQgEAEgHAAIgHgBg");
  this.shape_140.setTransform(137.975, -35);
  this.shape_141 = new cjs.Shape();
  this.shape_141.graphics.f("#0C593C").s().p("AAVAjIAAg8IgSA8IgFAAIgSg8IAAA8IgJAAIAAhFIAPAAIANAtIABAOIACgOIANgtIAPAAIAABFg");
  this.shape_141.setTransform(132.225, -36.175);
  this.shape_142 = new cjs.Shape();
  this.shape_142.graphics.f("#0C593C").s().p("AgMAhQgGgDgDgIQgDgIAAgOQAAgRAGgJQAGgKAMAAQAZAAAAAkQAAAOgDAIQgDAIgGADQgFAEgIAAQgHAAgFgEgAgIgYQgDACgBAHQgCAGAAAKQAAAJACAGQABAGADADQADADAFAAQAGAAADgDQADgDABgGQACgGAAgJQAAgKgCgGQgBgHgEgCQgDgDgFAAQgEAAgEADg");
  this.shape_142.setTransform(126.025, -36.175);
  this.shape_143 = new cjs.Shape();
  this.shape_143.graphics.f("#0C593C").s().p("AAMAjIgRgjIgHAKIAAAZIgKAAIAAhFIAKAAIAAAhIAXghIALAAIgVAbIAWAqg");
  this.shape_143.setTransform(121.375, -36.175);
  this.shape_144 = new cjs.Shape();
  this.shape_144.graphics.f("#0C593C").s().p("AgNAgQgFgFgCgIQgBgIgBgKQAAglAYAAQAKAAAFAHQAGAHgBAKIgJAAQAAgPgLAAQgIAAgCAIQgEAIAAAMQAAAMADAIQADAHAHAAQAHAAADgEQACgFAAgIIAJAAQAAALgEAHQgGAIgKAAQgJAAgGgFg");
  this.shape_144.setTransform(116.3, -36.175);
  this.shape_145 = new cjs.Shape();
  this.shape_145.graphics.f("#0C593C").s().p("AAMAjIAAghIgXAAIAAAhIgKAAIAAhFIAKAAIAAAdIAXAAIAAgdIAKAAIAABFg");
  this.shape_145.setTransform(111.225, -36.175);
  this.shape_146 = new cjs.Shape();
  this.shape_146.graphics.f("#0C593C").s().p("AANAjIAAg0IABgIIgCAIIgWA0IgMAAIAAhFIAKAAIAAA0IgBAIIACgIIAXg0IALAAIAABFg");
  this.shape_146.setTransform(105.75, -36.175);
  this.shape_147 = new cjs.Shape();
  this.shape_147.graphics.f("#0C593C").s().p("AARAsIAAgTIgqAAIAAhEIAKAAIAAA8IAYAAIAAg8IAKAAIAAA8IAGAAIAAAbg");
  this.shape_147.setTransform(100.5, -35.225);
  this.shape_148 = new cjs.Shape();
  this.shape_148.graphics.f("#0C593C").s().p("AANAjIAAg0IABgIIgCAIIgWA0IgMAAIAAhFIAKAAIAAA0IgBAIIACgIIAWg0IAMAAIAABFg");
  this.shape_148.setTransform(94.7, -36.175);
  this.shape_149 = new cjs.Shape();
  this.shape_149.graphics.f("#0C593C").s().p("AAUAsIAAgTIgnAAIAAATIgJAAIAAgbIAGAAIAFgMIACgKIABgPIAAgXIAlAAIAAA8IAGAAIAAAbgAgFgPQAAAKgBAGIgGAQIAZAAIAAg0IgSAAg");
  this.shape_149.setTransform(89.175, -35.225);
  this.shape_150 = new cjs.Shape();
  this.shape_150.graphics.f("#0C593C").s().p("AgLAhQgFgDgDgIQgCgIAAgOQAAgkAVAAQAKAAAFAGQAEAFACAIQABAHAAALIghAAIABAPQAAAGAEADQACADAEAAQAMAAAAgQIAKAAQAAAHgCAFQgDAGgEADQgFAEgHAAQgHAAgFgEgAgJgVQgCAGAAAJIAXAAQAAgKgDgGQgCgFgHAAQgGAAgDAGg");
  this.shape_150.setTransform(84.05, -36.175);
  this.shape_151 = new cjs.Shape();
  this.shape_151.graphics.f("#0C593C").s().p("AAVAjIAAg8IgSA8IgFAAIgSg8IAAA8IgJAAIAAhFIAPAAIANAtIABAOIACgOIANgtIAPAAIAABFg");
  this.shape_151.setTransform(78.225, -36.175);
  this.shape_152 = new cjs.Shape();
  this.shape_152.graphics.f("#0C593C").s().p("AgMAhQgGgDgDgIQgDgIAAgOQAAgRAGgJQAGgKAMAAQAZAAAAAkQAAAOgDAIQgDAIgGADQgFAEgIAAQgHAAgFgEgAgIgYQgDACgBAHQgCAGAAAKQAAAJACAGQABAGADADQADADAFAAQAGAAADgDQADgDABgGQACgGAAgJQAAgKgCgGQgBgHgEgCQgDgDgFAAQgEAAgEADg");
  this.shape_152.setTransform(69.775, -36.175);
  this.shape_153 = new cjs.Shape();
  this.shape_153.graphics.f("#0C593C").s().p("AAMAjIAAg8IgXAAIAAA8IgKAAIAAhFIArAAIAABFg");
  this.shape_153.setTransform(64.375, -36.175);
  this.shape_154 = new cjs.Shape();
  this.shape_154.graphics.f("#0C593C").s().p("AANAjIAAg0IACgIIgDAIIgWA0IgMAAIAAhFIAKAAIAAA0IgBAIIACgIIAWg0IAMAAIAABFg");
  this.shape_154.setTransform(56.65, -36.175);
  this.shape_155 = new cjs.Shape();
  this.shape_155.graphics.f("#0C593C").s().p("AANAjIAAg0IABgIIgCAIIgWA0IgMAAIAAhFIAKAAIAAA0IgBAIIACgIIAWg0IAMAAIAABFg");
  this.shape_155.setTransform(51.15, -36.175);
  this.shape_156 = new cjs.Shape();
  this.shape_156.graphics.f("#0C593C").s().p("AAQAsIAAgTIgoAAIAAhEIAKAAIAAA8IAXAAIAAg8IAKAAIAAA8IAGAAIAAAbg");
  this.shape_156.setTransform(45.9, -35.225);
  this.shape_157 = new cjs.Shape();
  this.shape_157.graphics.f("#0C593C").s().p("AAMAjIgRgjIgHAKIAAAZIgKAAIAAhFIAKAAIAAAhIAXghIALAAIgVAbIAWAqg");
  this.shape_157.setTransform(40.925, -36.175);
  this.shape_158 = new cjs.Shape();
  this.shape_158.graphics.f("#0C593C").s().p("AgXAuIAAgJQAEABAEABQAEAAADgFQADgDACgHIgWhGIAKAAIAPA3IABAAIAPg3IAKAAIgVBFIgFANQgBAEgEADQgEAEgHAAIgHgBg");
  this.shape_158.setTransform(35.725, -35);
  this.shape_159 = new cjs.Shape();
  this.shape_159.graphics.f("#0C593C").s().p("AgXAwIAAhdIAKAAIAAAIQADgEADgCQAFgEADAAQAXAAgBAkIgBAPQAAAGgDAFQgDAFgEADQgFADgGAAQgDAAgEgDQgDgCgEgEIAAAfgAgKgeQgDAIAAAMIABAOQABAFADAEQADAEAFAAQAHABADgIQADgHAAgOQAAgbgNAAQgIAAgCAIg");
  this.shape_159.setTransform(30.9, -35.1);
  this.shape_160 = new cjs.Shape();
  this.shape_160.graphics.f("#0C593C").s().p("AgEAjIAAg8IgSAAIAAgJIAtAAIAAAJIgSAAIAAA8g");
  this.shape_160.setTransform(26.15, -36.175);
  this.shape_161 = new cjs.Shape();
  this.shape_161.graphics.f("#0C593C").s().p("AgMAgQgGgFgCgIQgCgIABgKQAAglAWAAQAKAAAGAHQAFAHABAKIgKAAQAAgPgMAAQgHAAgDAIQgCAIAAAMQgBAMADAIQACAHAIAAQAHAAACgEQADgFAAgIIAKAAQAAALgGAHQgEAIgMAAQgIAAgFgFg");
  this.shape_161.setTransform(21.85, -36.175);
  this.shape_162 = new cjs.Shape();
  this.shape_162.graphics.f("#0C593C").s().p("AAMAjIAAghIgXAAIAAAhIgKAAIAAhFIAKAAIAAAdIAXAAIAAgdIAKAAIAABFg");
  this.shape_162.setTransform(16.775, -36.175);
  this.shape_163 = new cjs.Shape();
  this.shape_163.graphics.f("#0C593C").s().p("AAOAjIAAg0IABgIIgDAIIgWA0IgMAAIAAhFIAKAAIAAA0IgBAIIACgIIAWg0IAMAAIAABFg");
  this.shape_163.setTransform(11.3, -36.175);
  this.shape_164 = new cjs.Shape();
  this.shape_164.graphics.f("#0C593C").s().p("AANAjIAAg0IABgIIgCAIIgWA0IgMAAIAAhFIAKAAIAAA0IgBAIIACgIIAWg0IAMAAIAABFg");
  this.shape_164.setTransform(327.35, -48.675);
  this.shape_165 = new cjs.Shape();
  this.shape_165.graphics.f("#0C593C").s().p("AAVAjIAAg8IgSA8IgFAAIgSg8IAAA8IgJAAIAAhFIAPAAIANAtIABAOIACgOIANgtIAPAAIAABFg");
  this.shape_165.setTransform(321.125, -48.675);
  this.shape_166 = new cjs.Shape();
  this.shape_166.graphics.f("#0C593C").s().p("AAWAjIAAhFIAKAAIAABFgAgfAjIAAhFIAJAAIAAAeIAPAAQAFAAAEACQAEACADAEQACAFAAAGQAAAGgCAEQgDAFgEACQgDADgGAAgAgWAbIALAAQAHAAADgDQACgDAAgGQAAgMgLAAIgMAAg");
  this.shape_166.setTransform(313.95, -48.675);
  this.shape_167 = new cjs.Shape();
  this.shape_167.graphics.f("#0C593C").s().p("AAMAjIAAghIgXAAIAAAhIgKAAIAAhFIAKAAIAAAdIAXAAIAAgdIAKAAIAABFg");
  this.shape_167.setTransform(307.575, -48.675);
  this.shape_168 = new cjs.Shape();
  this.shape_168.graphics.f("#0C593C").s().p("AAMAjIAAghIgXAAIAAAhIgKAAIAAhFIAKAAIAAAdIAXAAIAAgdIAKAAIAABFg");
  this.shape_168.setTransform(302.175, -48.675);
  this.shape_169 = new cjs.Shape();
  this.shape_169.graphics.f("#0C593C").s().p("AgXARQAAgGACgEQACgDADgDQADgCAHgCIAMgFQACgBAAgHQAAgGgCgDQgDgCgEAAQgGAAgCADQgDADABAGIgJAAQgBgVAVAAQAGAAADADQAFACACAEQACAEAAAFIAAAoQAAAGAEAAIACgBIAAAIIgEABQgFAAgCgCQgDgCgBgHIAAAAQgCAFgEADQgDAEgGAAQgRAAAAgUgAAAABIgHAEIgEAEQgCADAAAFQAAALAKAAQAEAAAFgEIABgDIABgEIAAgGIAAgNIgIADg");
  this.shape_169.setTransform(297.15, -48.675);
  this.shape_170 = new cjs.Shape();
  this.shape_170.graphics.f("#0C593C").s().p("AAUAsIAAgTIgnAAIAAATIgJAAIAAgbIAGAAIAFgMIACgKIABgPIAAgXIAlAAIAAA8IAGAAIAAAbgAgFgPQAAAKgBAGIgGAQIAZAAIAAg0IgSAAg");
  this.shape_170.setTransform(291.975, -47.725);
  this.shape_171 = new cjs.Shape();
  this.shape_171.graphics.f("#0C593C").s().p("AgMAgQgGgFgCgIQgCgIABgKQAAglAWAAQAKAAAGAHQAFAHABAKIgKAAQAAgPgMAAQgHAAgDAIQgCAIAAAMQgBAMADAIQACAHAIAAQAHAAACgEQADgFAAgIIAKAAQAAALgGAHQgEAIgMAAQgIAAgFgFg");
  this.shape_171.setTransform(284.65, -48.675);
  this.shape_172 = new cjs.Shape();
  this.shape_172.graphics.f("#0C593C").s().p("AAOAjIAAg0IABgIIgDAIIgWA0IgMAAIAAhFIAKAAIAAA0IgBAIIACgIIAWg0IAMAAIAABFg");
  this.shape_172.setTransform(277.25, -48.675);
  this.shape_173 = new cjs.Shape();
  this.shape_173.graphics.f("#0C593C").s().p("AANAjIAAg0IACgIIgDAIIgWA0IgMAAIAAhFIAKAAIAAA0IgBAIIACgIIAWg0IAMAAIAABFg");
  this.shape_173.setTransform(271.75, -48.675);
  this.shape_174 = new cjs.Shape();
  this.shape_174.graphics.f("#0C593C").s().p("AgUAjIAAhFIAVAAQAIAAAGAFQAFAEAAAIQAAAGgDAFQgDAEgFABIAAABQAGAAADAEQADAFAAAHQAAAGgCAEQgCAEgEADQgEACgFAAgAgLAbIALAAQAHAAACgDQACgDAAgHQAAgFgCgDQgDgDgFAAIgMAAgAgLgEIALAAQAFAAACgDQADgDAAgFQAAgLgKAAIgLAAg");
  this.shape_174.setTransform(266.775, -48.675);
  this.shape_175 = new cjs.Shape();
  this.shape_175.graphics.f("#0C593C").s().p("AgEAjIAAg8IgSAAIAAgJIAtAAIAAAJIgSAAIAAA8g");
  this.shape_175.setTransform(262.25, -48.675);
  this.shape_176 = new cjs.Shape();
  this.shape_176.graphics.f("#0C593C").s().p("AgNAgQgFgFgCgIQgBgIgBgKQAAglAYAAQAKAAAFAHQAFAHAAAKIgJAAQAAgPgLAAQgIAAgCAIQgEAIAAAMQABAMACAIQADAHAHAAQAHAAADgEQACgFAAgIIAJAAQAAALgEAHQgGAIgKAAQgKAAgFgFg");
  this.shape_176.setTransform(257.95, -48.675);
  this.shape_177 = new cjs.Shape();
  this.shape_177.graphics.f("#0C593C").s().p("AgEAjIAAg8IgSAAIAAgJIAtAAIAAAJIgSAAIAAA8g");
  this.shape_177.setTransform(253.65, -48.675);
  this.shape_178 = new cjs.Shape();
  this.shape_178.graphics.f("#0C593C").s().p("AgLAhQgFgDgDgIQgCgIAAgOQAAgkAVAAQAKAAAEAGQAFAFACAIQABAHAAALIghAAIABAPQAAAGAEADQACADAFAAQALAAAAgQIAKAAQAAAHgCAFQgCAGgFADQgFAEgHAAQgHAAgFgEgAgJgVQgCAGAAAJIAXAAQAAgKgCgGQgDgFgHAAQgGAAgDAGg");
  this.shape_178.setTransform(249.3, -48.675);
  this.shape_179 = new cjs.Shape();
  this.shape_179.graphics.f("#0C593C").s().p("AgUAjIAAhFIAVAAQAIAAAGAFQAFAEAAAIQAAAGgDAFQgDAEgFABIAAABQAGAAADAEQADAFAAAHQAAAGgCAEQgCAEgEADQgEACgFAAgAgLAbIALAAQAHAAACgDQACgDAAgHQAAgFgCgDQgDgDgFAAIgMAAgAgLgEIALAAQAFAAACgDQADgDAAgFQAAgLgKAAIgLAAg");
  this.shape_179.setTransform(244.725, -48.675);
  this.shape_180 = new cjs.Shape();
  this.shape_180.graphics.f("#0C593C").s().p("AgEAjIAAg8IgSAAIAAgJIAtAAIAAAJIgSAAIAAA8g");
  this.shape_180.setTransform(240.2, -48.675);
  this.shape_181 = new cjs.Shape();
  this.shape_181.graphics.f("#0C593C").s().p("AgMAhQgGgDgDgIQgDgIAAgOQAAgRAGgJQAGgKAMAAQAZAAAAAkQAAAOgDAIQgDAIgGADQgFAEgIAAQgHAAgFgEgAgIgYQgDACgBAHQgCAGAAAKQAAAJACAGQABAGADADQADADAFAAQAGAAADgDQADgDABgGQACgGAAgJQAAgKgCgGQgBgHgEgCQgDgDgFAAQgEAAgEADg");
  this.shape_181.setTransform(235.525, -48.675);
  this.shape_182 = new cjs.Shape();
  this.shape_182.graphics.f("#0C593C").s().p("AgMAhQgGgDgDgIQgDgIAAgOQAAgRAGgJQAGgKAMAAQAZAAAAAkQAAAOgDAIQgDAIgGADQgFAEgIAAQgHAAgFgEgAgIgYQgDACgBAHQgCAGAAAKQAAAJACAGQABAGADADQADADAFAAQAGAAADgDQADgDABgGQACgGAAgJQAAgKgCgGQgBgHgEgCQgDgDgFAAQgEAAgEADg");
  this.shape_182.setTransform(230.125, -48.675);
  this.shape_183 = new cjs.Shape();
  this.shape_183.graphics.f("#0C593C").s().p("AgNAgQgFgFgCgIQgBgIgBgKQAAglAYAAQAKAAAFAHQAFAHAAAKIgJAAQAAgPgLAAQgIAAgCAIQgEAIAAAMQABAMACAIQADAHAHAAQAHAAADgEQACgFAAgIIAJAAQAAALgEAHQgGAIgKAAQgKAAgFgFg");
  this.shape_183.setTransform(225.1, -48.675);
  this.shape_184 = new cjs.Shape();
  this.shape_184.graphics.f("#0C593C").s().p("AgUAjIAAhFIAVAAQAIAAAGAFQAFAEAAAIQAAAGgDAFQgDAEgFABIAAABQAGAAADAEQADAFAAAHQAAAGgCAEQgCAEgEADQgEACgFAAgAgLAbIALAAQAHAAACgDQACgDAAgHQAAgFgCgDQgDgDgFAAIgMAAgAgLgEIALAAQAFAAACgDQADgDAAgFQAAgLgKAAIgLAAg");
  this.shape_184.setTransform(218.225, -48.675);
  this.shape_185 = new cjs.Shape();
  this.shape_185.graphics.f("#0C593C").s().p("AgFAiIAAgMIALAAIAAAMgAgFgVIAAgMIALAAIAAAMg");
  this.shape_185.setTransform(212.275, -48.6);
  this.shape_186 = new cjs.Shape();
  this.shape_186.graphics.f("#0C593C").s().p("AgXARQAAgGACgEQACgDADgDQADgCAHgCIALgFQADgBAAgHQAAgGgCgDQgDgCgFAAQgFAAgCADQgCADgBAGIgJAAQABgVATAAQAGAAAFADQAEACACAEQACAEAAAFIAAAoQAAAGAEAAIACgBIAAAIIgEABQgFAAgCgCQgCgCgBgHIgBAAQgCAFgEADQgEAEgEAAQgSAAAAgUgAABABIgHAEIgFAEQgCADAAAFQAAALAJAAQAFAAAEgEIACgDIABgEIAAgGIAAgNIgHADg");
  this.shape_186.setTransform(208.8, -48.675);
  this.shape_187 = new cjs.Shape();
  this.shape_187.graphics.f("#0C593C").s().p("AgUAjIAAhFIAVAAQAIAAAGAFQAFAEAAAIQAAAGgDAFQgDAEgFABIAAABQAGAAADAEQADAFAAAHQAAAGgCAEQgCAEgEADQgEACgFAAgAgLAbIALAAQAHAAACgDQACgDAAgHQAAgFgCgDQgDgDgFAAIgMAAgAgLgEIALAAQAFAAACgDQADgDAAgFQAAgLgKAAIgLAAg");
  this.shape_187.setTransform(204.175, -48.675);
  this.shape_188 = new cjs.Shape();
  this.shape_188.graphics.f("#0C593C").s().p("AgEAjIAAg8IgSAAIAAgJIAtAAIAAAJIgSAAIAAA8g");
  this.shape_188.setTransform(199.65, -48.675);
  this.shape_189 = new cjs.Shape();
  this.shape_189.graphics.f("#0C593C").s().p("AgMAgQgGgFgCgIQgBgIAAgKQgBglAXAAQALAAAFAHQAGAHAAAKIgKAAQAAgPgMAAQgGAAgEAIQgCAIAAAMQAAAMACAIQADAHAHAAQAHAAACgEQACgFABgIIAKAAQgBALgFAHQgEAIgMAAQgJAAgEgFg");
  this.shape_189.setTransform(195.35, -48.675);
  this.shape_190 = new cjs.Shape();
  this.shape_190.graphics.f("#0C593C").s().p("AAUAsIAAgTIgnAAIAAATIgJAAIAAgbIAGAAIAFgMIACgKIABgPIAAgXIAlAAIAAA8IAGAAIAAAbgAgFgPQAAAKgBAGIgGAQIAZAAIAAg0IgSAAg");
  this.shape_190.setTransform(190.175, -47.725);
  this.shape_191 = new cjs.Shape();
  this.shape_191.graphics.f("#0C593C").s().p("AgLAhQgFgDgDgIQgCgIAAgOQAAgkAVAAQAKAAAEAGQAFAFACAIQABAHAAALIghAAIABAPQABAGADADQACADAFAAQALAAAAgQIAKAAQAAAHgCAFQgDAGgEADQgFAEgHAAQgHAAgFgEgAgIgVQgDAGAAAJIAXAAQAAgKgCgGQgDgFgHAAQgGAAgCAGg");
  this.shape_191.setTransform(185.05, -48.675);
  this.shape_192 = new cjs.Shape();
  this.shape_192.graphics.f("#0C593C").s().p("AgWAwIAAhcIAJAAIAAAHQACgEAEgCQAFgEACAAQAYAAAAAkIgBAOQgBAHgDAFQgCAFgFADQgEADgHAAQgEAAgDgDQgDgCgDgEIAAAfgAgKgeQgCAIAAAMIAAANQABAGADAEQADAEAFABQAHAAADgIQADgHAAgOQAAgbgNAAQgHAAgDAIg");
  this.shape_192.setTransform(180.15, -47.6);
  this.shape_193 = new cjs.Shape();
  this.shape_193.graphics.f("#0C593C").s().p("AgNAgQgFgFgCgIQgCgIAAgKQAAglAXAAQALAAAFAHQAGAHgBAKIgJAAQAAgPgMAAQgGAAgDAIQgDAIAAAMQAAAMACAIQADAHAHAAQAHAAACgEQACgFABgIIAJAAQAAALgEAHQgFAIgMAAQgJAAgFgFg");
  this.shape_193.setTransform(175, -48.675);
  this.shape_194 = new cjs.Shape();
  this.shape_194.graphics.f("#0C593C").s().p("AgMAhQgGgDgDgIQgDgIAAgOQAAgRAGgJQAGgKAMAAQAZAAAAAkQAAAOgDAIQgDAIgGADQgFAEgIAAQgHAAgFgEgAgIgYQgDACgBAHQgCAGAAAKQAAAJACAGQABAGADADQADADAFAAQAGAAADgDQADgDABgGQACgGAAgJQAAgKgCgGQgBgHgEgCQgDgDgFAAQgEAAgEADg");
  this.shape_194.setTransform(167.675, -48.675);
  this.shape_195 = new cjs.Shape();
  this.shape_195.graphics.f("#0C593C").s().p("AgRAjIAAhFIAkAAIAAAJIgaAAIAAA8g");
  this.shape_195.setTransform(163.55, -48.675);
  this.shape_196 = new cjs.Shape();
  this.shape_196.graphics.f("#0C593C").s().p("AgMAhQgGgDgDgIQgDgIAAgOQAAgRAGgJQAGgKAMAAQAZAAAAAkQAAAOgDAIQgDAIgGADQgFAEgIAAQgHAAgFgEgAgIgYQgDACgBAHQgCAGAAAKQAAAJACAGQABAGADADQADADAFAAQAGAAADgDQADgDABgGQACgGAAgJQAAgKgCgGQgBgHgEgCQgDgDgFAAQgEAAgEADg");
  this.shape_196.setTransform(158.525, -48.675);
  this.shape_197 = new cjs.Shape();
  this.shape_197.graphics.f("#0C593C").s().p("AAMAjIAAghIgXAAIAAAhIgKAAIAAhFIAKAAIAAAdIAXAAIAAgdIAKAAIAABFg");
  this.shape_197.setTransform(153.125, -48.675);
  this.shape_198 = new cjs.Shape();
  this.shape_198.graphics.f("#0C593C").s().p("AALAjIAAghQgFACgJAAQgIAAgEgEQgFgFAAgIIAAgVIAKAAIAAAUQAAAGACACQACACAGAAIALAAIAAgeIAKAAIAABFg");
  this.shape_198.setTransform(147.8, -48.675);
  this.shape_199 = new cjs.Shape();
  this.shape_199.graphics.f("#0C593C").s().p("AAWAjIAAhFIAKAAIAABFgAgfAjIAAhFIAJAAIAAAeIAPAAQAFAAAEACQAEACADAEQACAFAAAGQAAAGgCAEQgDAFgFACQgCADgGAAgAgWAbIALAAQAHAAADgDQACgDAAgGQAAgMgLAAIgMAAg");
  this.shape_199.setTransform(141.6, -48.675);
  this.shape_200 = new cjs.Shape();
  this.shape_200.graphics.f("#0C593C").s().p("AgOArQgFgFgDgJQgCgJAAgOQAAgKABgIQACgIADgGQADgFAEgEQAEgDAGgBIAKgEQAEgBAAgDIAIAAQgBAHgFADQgEADgKACQgGACgEAFQgEAGgBAJQAGgLAJAAQAIAAAFAEQAFAEADAHQADAHAAAKQAAAMgDAIQgDAJgFAEQgFAEgJAAQgIAAgGgFgAgKgGQgEAGAAALQAAAJACAHQACAGADADQADADAEAAQAHAAAEgHQAEgHAAgOQAAgLgEgGQgEgHgHAAQgGAAgEAHg");
  this.shape_200.setTransform(135.4, -49.775);
  this.shape_201 = new cjs.Shape();
  this.shape_201.graphics.f("#0C593C").s().p("AgMAhQgGgDgDgIQgDgIAAgOQAAgRAGgJQAGgKAMAAQAZAAAAAkQAAAOgDAIQgDAIgGADQgFAEgIAAQgHAAgFgEgAgIgYQgDACgBAHQgCAGAAAKQAAAJACAGQABAGADADQADADAFAAQAGAAADgDQADgDABgGQACgGAAgJQAAgKgCgGQgBgHgEgCQgDgDgFAAQgEAAgEADg");
  this.shape_201.setTransform(130.275, -48.675);
  this.shape_202 = new cjs.Shape();
  this.shape_202.graphics.f("#0C593C").s().p("AgZAiIAAgHIAEAAQADAAABgCQACgCABgGIAAgRIAAgiIAoAAIAABFIgKAAIAAg9IgUAAIAAAbQAAAQgDAKQgEAIgIAAIgGgBg");
  this.shape_202.setTransform(122.275, -48.65);
  this.shape_203 = new cjs.Shape();
  this.shape_203.graphics.f("#0C593C").s().p("AgXAuIAAgJQAEABAEAAQAEAAADgDQADgEACgHIgWhFIAKAAIAPA2IABAAIAPg2IAKAAIgVBEIgFANQgBAFgEADQgEADgHAAIgHgBg");
  this.shape_203.setTransform(117.475, -47.5);
  this.shape_204 = new cjs.Shape();
  this.shape_204.graphics.f("#0C593C").s().p("AgNAgQgFgFgCgIQgCgIAAgKQAAglAXAAQALAAAFAHQAGAHgBAKIgJAAQAAgPgMAAQgGAAgDAIQgDAIAAAMQAAAMACAIQADAHAHAAQAHAAACgEQACgFABgIIAJAAQAAALgEAHQgFAIgMAAQgJAAgFgFg");
  this.shape_204.setTransform(112.9, -48.675);
  this.shape_205 = new cjs.Shape();
  this.shape_205.graphics.f("#0C593C").s().p("AAMAjIAAg8IgXAAIAAA8IgKAAIAAhFIArAAIAABFg");
  this.shape_205.setTransform(107.825, -48.675);
  this.shape_206 = new cjs.Shape();
  this.shape_206.graphics.f("#0C593C").s().p("AgXARQAAgGABgEQACgDAEgDQAEgCAGgCIALgFQADgBAAgHQAAgGgCgDQgCgCgGAAQgFAAgCADQgDADAAAGIgJAAQAAgVAVAAQAFAAAFADQAEACACAEQACAEAAAFIAAAoQAAAGAEAAIACgBIAAAIIgEABQgFAAgDgCQgBgCgBgHIgBAAQgCAFgEADQgEAEgEAAQgSAAAAgUgAABABIgHAEIgFAEQgCADAAAFQAAALAJAAQAGAAADgEIACgDIABgEIAAgGIAAgNIgHADg");
  this.shape_206.setTransform(102.8, -48.675);
  this.shape_207 = new cjs.Shape();
  this.shape_207.graphics.f("#0C593C").s().p("AAMAjIgRgjIgHAKIAAAZIgKAAIAAhFIAKAAIAAAhIAXghIALAAIgVAbIAWAqg");
  this.shape_207.setTransform(98.475, -48.675);
  this.shape_208 = new cjs.Shape();
  this.shape_208.graphics.f("#0C593C").s().p("AgYAvQAAgJABgGQACgGAFgGQAFgGAKgJQAGgFAEgGQAEgGAAgIQAAgQgNAAQgIAAgDAFQgCAGAAALIgKAAIAAgEQAAgIACgGQADgHAFgDQAGgEAHAAQAIAAAFADQAGAEADAFQACAGAAAIQAAAHgCAFQgCAGgEADIgJAJIgNANIgFAHIgCAHIAmAAIAAAKg");
  this.shape_208.setTransform(90.725, -49.875);
  this.shape_209 = new cjs.Shape();
  this.shape_209.graphics.f("#0C593C").s().p("AgMAhQgGgDgDgIQgDgIAAgOQAAgRAGgJQAGgKAMAAQAZAAAAAkQAAAOgDAIQgDAIgGADQgFAEgIAAQgHAAgFgEgAgIgYQgDACgBAHQgCAGAAAKQAAAJACAGQABAGADADQADADAFAAQAGAAADgDQADgDABgGQACgGAAgJQAAgKgCgGQgBgHgEgCQgDgDgFAAQgEAAgEADg");
  this.shape_209.setTransform(83.125, -48.675);
  this.shape_210 = new cjs.Shape();
  this.shape_210.graphics.f("#0C593C").s().p("AgEAjIAAg8IgSAAIAAgJIAtAAIAAAJIgSAAIAAA8g");
  this.shape_210.setTransform(78.5, -48.675);
  this.shape_211 = new cjs.Shape();
  this.shape_211.graphics.f("#0C593C").s().p("AgNAgQgFgFgCgIQgCgIAAgKQAAglAXAAQALAAAFAHQAGAHgBAKIgJAAQAAgPgMAAQgGAAgDAIQgDAIAAAMQAAAMACAIQADAHAHAAQAHAAACgEQACgFABgIIAJAAQAAALgEAHQgFAIgMAAQgJAAgFgFg");
  this.shape_211.setTransform(74.2, -48.675);
  this.shape_212 = new cjs.Shape();
  this.shape_212.graphics.f("#0C593C").s().p("AgLAhQgFgDgDgIQgCgIAAgOQAAgkAVAAQAJAAAGAGQAEAFABAIQACAHAAALIghAAIABAPQAAAGADADQADADAEAAQAMAAAAgQIAKAAQAAAHgDAFQgCAGgEADQgFAEgHAAQgHAAgFgEgAgJgVQgCAGAAAJIAWAAQAAgKgCgGQgCgFgHAAQgGAAgDAGg");
  this.shape_212.setTransform(69.45, -48.675);
  this.shape_213 = new cjs.Shape();
  this.shape_213.graphics.f("#0C593C").s().p("AAVAjIAAg8IgSA8IgFAAIgSg8IAAA8IgJAAIAAhFIAPAAIANAtIABAOIACgOIANgtIAPAAIAABFg");
  this.shape_213.setTransform(63.625, -48.675);
  this.shape_214 = new cjs.Shape();
  this.shape_214.graphics.f("#0C593C").s().p("AgUAjIAAhFIAVAAQAIAAAGAFQAFAEAAAIQAAAGgDAFQgDAEgFABIAAABQAGAAADAEQADAFAAAHQAAAGgCAEQgCAEgEADQgEACgFAAgAgLAbIALAAQAHAAACgDQACgDAAgHQAAgFgCgDQgDgDgFAAIgMAAgAgLgEIALAAQAFAAACgDQADgDAAgFQAAgLgKAAIgLAAg");
  this.shape_214.setTransform(57.875, -48.675);
  this.shape_215 = new cjs.Shape();
  this.shape_215.graphics.f("#0C593C").s().p("AgXARQAAgGABgEQACgDAEgDQAEgCAGgCIALgFQADgBAAgHQAAgGgCgDQgCgCgFAAQgGAAgCADQgDADAAAGIgJAAQAAgVAVAAQAGAAAEADQAEACACAEQACAEAAAFIAAAoQAAAGAEAAIACgBIAAAIIgEABQgFAAgDgCQgCgCAAgHIgBAAQgCAFgEADQgEAEgFAAQgRAAAAgUgAABABIgHAEIgFAEQgCADAAAFQAAALAJAAQAGAAADgEIACgDIABgEIAAgGIAAgNIgHADg");
  this.shape_215.setTransform(50.7, -48.675);
  this.shape_216 = new cjs.Shape();
  this.shape_216.graphics.f("#0C593C").s().p("AgZAiIAAgHIAEAAQADAAABgCQACgCABgGIAAgRIAAgiIAoAAIAABFIgKAAIAAg9IgUAAIAAAbQAAAQgDAKQgEAIgIAAIgGgBg");
  this.shape_216.setTransform(45.275, -48.65);
  this.shape_217 = new cjs.Shape();
  this.shape_217.graphics.f("#0C593C").s().p("AgXAuIAAgJQAEABAEAAQAEAAADgDQADgEACgHIgWhFIAKAAIAPA2IABAAIAPg2IAKAAIgVBEIgFANQgBAFgEADQgEADgHAAIgHgBg");
  this.shape_217.setTransform(40.475, -47.5);
  this.shape_218 = new cjs.Shape();
  this.shape_218.graphics.f("#0C593C").s().p("AgMAgQgGgFgCgIQgCgIABgKQAAglAXAAQAJAAAGAHQAFAHABAKIgKAAQAAgPgLAAQgHAAgEAIQgDAIAAAMQABAMACAIQACAHAIAAQAHAAADgEQABgFABgIIAKAAQAAALgGAHQgFAIgKAAQgKAAgEgFg");
  this.shape_218.setTransform(35.9, -48.675);
  this.shape_219 = new cjs.Shape();
  this.shape_219.graphics.f("#0C593C").s().p("AAMAjIAAg8IgXAAIAAA8IgKAAIAAhFIArAAIAABFg");
  this.shape_219.setTransform(30.825, -48.675);
  this.shape_220 = new cjs.Shape();
  this.shape_220.graphics.f("#0C593C").s().p("AgXARQAAgGACgEQACgDADgDQADgCAHgCIAMgFQACgBAAgHQAAgGgCgDQgDgCgEAAQgGAAgCADQgDADABAGIgJAAQAAgVATAAQAHAAADADQAFACACAEQACAEAAAFIAAAoQAAAGAEAAIACgBIAAAIIgEABQgFAAgCgCQgDgCgBgHIAAAAQgCAFgEADQgDAEgGAAQgRAAAAgUgAAAABIgHAEIgEAEQgCADAAAFQAAALAKAAQAEAAAFgEIABgDIABgEIAAgGIAAgNIgIADg");
  this.shape_220.setTransform(25.8, -48.675);
  this.shape_221 = new cjs.Shape();
  this.shape_221.graphics.f("#0C593C").s().p("AAMAjIgRgjIgHAKIAAAZIgKAAIAAhFIAKAAIAAAhIAXghIALAAIgVAbIAWAqg");
  this.shape_221.setTransform(21.475, -48.675);
  this.shape_222 = new cjs.Shape();
  this.shape_222.graphics.f("#0C593C").s().p("AAFAvIAAhDIgTAAIAAgJIAMgBQADgBACgEQADgEABgHIAIAAIAABdg");
  this.shape_222.setTransform(13.1, -49.875);
  this.shape_223 = new cjs.Shape();
  this.shape_223.graphics.f("#0C593C").s().p("AAAAGIgIAMIgGgEIAKgLIgOgFIACgFIAOAFIAAgPIAFAAIAAAPIAOgFIACAGIgOADIAKAMIgGAEg");
  this.shape_223.setTransform(8.375, -52.725);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_223
   }, {
    t: this.shape_222
   }, {
    t: this.shape_221
   }, {
    t: this.shape_220
   }, {
    t: this.shape_219
   }, {
    t: this.shape_218
   }, {
    t: this.shape_217
   }, {
    t: this.shape_216
   }, {
    t: this.shape_215
   }, {
    t: this.shape_214
   }, {
    t: this.shape_213
   }, {
    t: this.shape_212
   }, {
    t: this.shape_211
   }, {
    t: this.shape_210
   }, {
    t: this.shape_209
   }, {
    t: this.shape_208
   }, {
    t: this.shape_207
   }, {
    t: this.shape_206
   }, {
    t: this.shape_205
   }, {
    t: this.shape_204
   }, {
    t: this.shape_203
   }, {
    t: this.shape_202
   }, {
    t: this.shape_201
   }, {
    t: this.shape_200
   }, {
    t: this.shape_199
   }, {
    t: this.shape_198
   }, {
    t: this.shape_197
   }, {
    t: this.shape_196
   }, {
    t: this.shape_195
   }, {
    t: this.shape_194
   }, {
    t: this.shape_193
   }, {
    t: this.shape_192
   }, {
    t: this.shape_191
   }, {
    t: this.shape_190
   }, {
    t: this.shape_189
   }, {
    t: this.shape_188
   }, {
    t: this.shape_187
   }, {
    t: this.shape_186
   }, {
    t: this.shape_185
   }, {
    t: this.shape_184
   }, {
    t: this.shape_183
   }, {
    t: this.shape_182
   }, {
    t: this.shape_181
   }, {
    t: this.shape_180
   }, {
    t: this.shape_179
   }, {
    t: this.shape_178
   }, {
    t: this.shape_177
   }, {
    t: this.shape_176
   }, {
    t: this.shape_175
   }, {
    t: this.shape_174
   }, {
    t: this.shape_173
   }, {
    t: this.shape_172
   }, {
    t: this.shape_171
   }, {
    t: this.shape_170
   }, {
    t: this.shape_169
   }, {
    t: this.shape_168
   }, {
    t: this.shape_167
   }, {
    t: this.shape_166
   }, {
    t: this.shape_165
   }, {
    t: this.shape_164
   }, {
    t: this.shape_163
   }, {
    t: this.shape_162
   }, {
    t: this.shape_161
   }, {
    t: this.shape_160
   }, {
    t: this.shape_159
   }, {
    t: this.shape_158
   }, {
    t: this.shape_157
   }, {
    t: this.shape_156
   }, {
    t: this.shape_155
   }, {
    t: this.shape_154
   }, {
    t: this.shape_153
   }, {
    t: this.shape_152
   }, {
    t: this.shape_151
   }, {
    t: this.shape_150
   }, {
    t: this.shape_149
   }, {
    t: this.shape_148
   }, {
    t: this.shape_147
   }, {
    t: this.shape_146
   }, {
    t: this.shape_145
   }, {
    t: this.shape_144
   }, {
    t: this.shape_143
   }, {
    t: this.shape_142
   }, {
    t: this.shape_141
   }, {
    t: this.shape_140
   }, {
    t: this.shape_139
   }, {
    t: this.shape_138
   }, {
    t: this.shape_137
   }, {
    t: this.shape_136
   }, {
    t: this.shape_135
   }, {
    t: this.shape_134
   }, {
    t: this.shape_133
   }, {
    t: this.shape_132
   }, {
    t: this.shape_131
   }, {
    t: this.shape_130
   }, {
    t: this.shape_129
   }, {
    t: this.shape_128
   }, {
    t: this.shape_127
   }, {
    t: this.shape_126
   }, {
    t: this.shape_125
   }, {
    t: this.shape_124
   }, {
    t: this.shape_123
   }, {
    t: this.shape_122
   }, {
    t: this.shape_121
   }, {
    t: this.shape_120
   }, {
    t: this.shape_119
   }, {
    t: this.shape_118
   }, {
    t: this.shape_117
   }, {
    t: this.shape_116
   }, {
    t: this.shape_115
   }, {
    t: this.shape_114
   }, {
    t: this.shape_113
   }, {
    t: this.shape_112
   }, {
    t: this.shape_111
   }, {
    t: this.shape_110
   }, {
    t: this.shape_109
   }, {
    t: this.shape_108
   }, {
    t: this.shape_107
   }, {
    t: this.shape_106
   }, {
    t: this.shape_105
   }, {
    t: this.shape_104
   }, {
    t: this.shape_103
   }, {
    t: this.shape_102
   }, {
    t: this.shape_101
   }, {
    t: this.shape_100
   }, {
    t: this.shape_99
   }, {
    t: this.shape_98
   }, {
    t: this.shape_97
   }, {
    t: this.shape_96
   }, {
    t: this.shape_95
   }, {
    t: this.shape_94
   }, {
    t: this.shape_93
   }, {
    t: this.shape_92
   }, {
    t: this.shape_91
   }, {
    t: this.shape_90
   }, {
    t: this.shape_89
   }, {
    t: this.shape_88
   }, {
    t: this.shape_87
   }, {
    t: this.shape_86
   }, {
    t: this.shape_85
   }, {
    t: this.shape_84
   }, {
    t: this.shape_83
   }, {
    t: this.shape_82
   }, {
    t: this.shape_81
   }, {
    t: this.shape_80
   }, {
    t: this.shape_79
   }, {
    t: this.shape_78
   }, {
    t: this.shape_77
   }, {
    t: this.shape_76
   }, {
    t: this.shape_75
   }, {
    t: this.shape_74
   }, {
    t: this.shape_73
   }, {
    t: this.shape_72
   }, {
    t: this.shape_71
   }, {
    t: this.shape_70
   }, {
    t: this.shape_69
   }, {
    t: this.shape_68
   }, {
    t: this.shape_67
   }, {
    t: this.shape_66
   }, {
    t: this.shape_65
   }, {
    t: this.shape_64
   }, {
    t: this.shape_63
   }, {
    t: this.shape_62
   }, {
    t: this.shape_61
   }, {
    t: this.shape_60
   }, {
    t: this.shape_59
   }, {
    t: this.shape_58
   }, {
    t: this.shape_57
   }, {
    t: this.shape_56
   }, {
    t: this.shape_55
   }, {
    t: this.shape_54
   }, {
    t: this.shape_53
   }, {
    t: this.shape_52
   }, {
    t: this.shape_51
   }, {
    t: this.shape_50
   }, {
    t: this.shape_49
   }, {
    t: this.shape_48
   }, {
    t: this.shape_47
   }, {
    t: this.shape_46
   }, {
    t: this.shape_45
   }, {
    t: this.shape_44
   }, {
    t: this.shape_43
   }, {
    t: this.shape_42
   }, {
    t: this.shape_41
   }, {
    t: this.shape_40
   }, {
    t: this.shape_39
   }, {
    t: this.shape_38
   }, {
    t: this.shape_37
   }, {
    t: this.shape_36
   }, {
    t: this.shape_35
   }, {
    t: this.shape_34
   }, {
    t: this.shape_33
   }, {
    t: this.shape_32
   }, {
    t: this.shape_31
   }, {
    t: this.shape_30
   }, {
    t: this.shape_29
   }, {
    t: this.shape_28
   }, {
    t: this.shape_27
   }, {
    t: this.shape_26
   }, {
    t: this.shape_25
   }, {
    t: this.shape_24
   }, {
    t: this.shape_23
   }, {
    t: this.shape_22
   }, {
    t: this.shape_21
   }, {
    t: this.shape_20
   }, {
    t: this.shape_19
   }, {
    t: this.shape_18
   }, {
    t: this.shape_17
   }, {
    t: this.shape_16
   }, {
    t: this.shape_15
   }, {
    t: this.shape_14
   }, {
    t: this.shape_13
   }, {
    t: this.shape_12
   }, {
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
 }).prototype = getMCSymbolPrototype(lib.l4, new cjs.Rectangle(-3, -59, 341, 56.1), null);
 (lib.l3 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#0C593C").s().p("AAsBHIAAhZIABgOIABgRIgBAAIgmB4IgOAAIgmh4IgBAAIABARIABAOIAABZIgRAAIAAiNIAZAAIAkBzIAlhzIAZAAIAACNg");
  this.shape.setTransform(323.1, -11.175);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#0C593C").s().p("AgcA/QgMgJgFgRQgGgRAAgUQAAgjANgTQANgSAZAAQASAAALAJQAMAKAFAQQAGARAAAUQAAAVgGAQQgFARgMAKQgLAJgSAAQgRAAgLgKgAgYgqQgIAPAAAbQAAAcAIAPQAJAPAPAAQARAAAIgPQAIgPAAgcQAAgbgIgPQgIgPgRAAQgPAAgJAPg");
  this.shape_1.setTransform(310.475, -11.175);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#0C593C").s().p("AgIBHIAAh+IggAAIAAgPIBSAAIAAAPIghAAIAAB+g");
  this.shape_2.setTransform(301.3, -11.175);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#0C593C").s().p("AgcA2QgOgUABgiQgBgUAHgQQAGgRAMgKQAMgJARAAQARAAANAHIgGAPIgLgFQgGgCgHAAQgMAAgHAIQgIAIgEANQgDANgBAPQAAAbAKAPQAJAQARAAQAHAAAHgCIAMgEIAAAQQgMAFgQAAQgZAAgOgTg");
  this.shape_3.setTransform(293.5, -11.175);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#0C593C").s().p("AAfBHIAAhTIAAgQIABgQIgBAAIg4BzIgWAAIAAiNIASAAIAABSIgBAPIgBARIABAAIA4hyIAWAAIAACNg");
  this.shape_4.setTransform(283.225, -11.175);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#0C593C").s().p("AgwBGIAAgPQADACAFAAQAGAAAEgIQADgHACgPIADgZIADgiIAFgnIA/AAIAACNIgSAAIAAh9IgeAAIgCAXIgCAZIgDAWIgDASQgCANgDAJQgDAJgGAEQgFAEgKAAQgGAAgEgCg");
  this.shape_5.setTransform(271.8, -11.075);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#0C593C").s().p("AAgBHIgMgsIgnAAIgMAsIgTAAIApiNIATAAIApCNgAgBgsIgDALIgMAsIAgAAIgMgsIgCgLIgCgKIgBAKg");
  this.shape_6.setTransform(263.175, -11.175);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#0C593C").s().p("AAfBHIAAhTIAAgQIABgQIgBAAIg4BzIgWAAIAAiNIASAAIAABSIgBAPIgBARIABAAIA4hyIAWAAIAACNg");
  this.shape_7.setTransform(253.075, -11.175);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#0C593C").s().p("AAhBbIAAgnIhTAAIAAiNIASAAIAAB+IAzAAIAAh+IASAAIAAB+IAOAAIAAA2g");
  this.shape_8.setTransform(242.55, -9.25);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#0C593C").s().p("AgfBHIAAiNIA/AAIAAAPIgtAAIAAAtIAqAAIAAAOIgqAAIAAA0IAtAAIAAAPg");
  this.shape_9.setTransform(233.05, -11.175);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.f("#0C593C").s().p("AAZBHIAAh+IgxAAIAAB+IgSAAIAAiNIBVAAIAACNg");
  this.shape_10.setTransform(223.525, -11.175);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.f("#0C593C").s().p("AgbA2QgOgUgBgiQAAgUAHgQQAGgRAMgKQAMgJARAAQARAAAOAHIgHAPIgLgFQgGgCgHAAQgMAAgHAIQgIAIgDANQgFANAAAPQAAAbAKAPQAKAQAQAAQAHAAAHgCIALgEIAAAQQgLAFgQAAQgYAAgOgTg");
  this.shape_11.setTransform(214.15, -11.175);
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.f("#0C593C").s().p("AgcA/QgMgJgFgRQgGgRAAgUQAAgjANgTQANgSAZAAQASAAALAJQAMAKAFAQQAGARAAAUQAAAVgGAQQgFARgMAKQgLAJgSAAQgRAAgLgKgAgYgqQgIAPAAAbQAAAcAIAPQAJAPAPAAQARAAAIgPQAIgPAAgcQAAgbgIgPQgIgPgRAAQgPAAgJAPg");
  this.shape_12.setTransform(201.325, -11.175);
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.f("#0C593C").s().p("AgbA2QgOgUgBgiQAAgUAHgQQAGgRAMgKQAMgJARAAQARAAAOAHIgHAPIgLgFQgGgCgHAAQgMAAgHAIQgIAIgDANQgFANAAAPQAAAbAKAPQAKAQAQAAQAHAAAHgCIALgEIAAAQQgLAFgQAAQgYAAgOgTg");
  this.shape_13.setTransform(191.65, -11.175);
  this.shape_14 = new cjs.Shape();
  this.shape_14.graphics.f("#0C593C").s().p("AgmBHIAAiNIASAAIAAA7IAPAAQAWAAALALQALAKAAATQAAAUgLALQgMALgUAAgAgUA4IAPAAQAaAAAAgbQAAgNgHgGQgHgHgNAAIgOAAg");
  this.shape_14.setTransform(177.625, -11.175);
  this.shape_15 = new cjs.Shape();
  this.shape_15.graphics.f("#0C593C").s().p("AgbA2QgOgUgBgiQAAgUAHgQQAGgRAMgKQAMgJARAAQARAAAOAHIgHAPIgLgFQgGgCgHAAQgMAAgHAIQgIAIgDANQgFANAAAPQAAAbAKAPQAKAQAQAAQAHAAAHgCIALgEIAAAQQgLAFgQAAQgYAAgOgTg");
  this.shape_15.setTransform(168.7, -11.175);
  this.shape_16 = new cjs.Shape();
  this.shape_16.graphics.f("#0C593C").s().p("AgfBHIAAiNIA/AAIAAAPIgtAAIAAAtIAqAAIAAAOIgqAAIAAA0IAtAAIAAAPg");
  this.shape_16.setTransform(160.6, -11.175);
  this.shape_17 = new cjs.Shape();
  this.shape_17.graphics.f("#0C593C").s().p("AgIBHIAAh+IggAAIAAgPIBSAAIAAAPIghAAIAAB+g");
  this.shape_17.setTransform(152.8, -11.175);
  this.shape_18 = new cjs.Shape();
  this.shape_18.graphics.f("#0C593C").s().p("AAfBdIAAhUIAAgQIABgPIgBAAIg4BzIgWAAIAAiNIASAAIAABSIgBAPIgBARIABAAIA4hyIAWAAIAACNgAgVhGQgIgHgBgPIAQAAQABAKADAEQAEAFAHAAQAIAAAEgFQAEgEABgKIAPAAQgBAPgIAHQgIAIgPAAQgPAAgHgIg");
  this.shape_18.setTransform(143.275, -13.35);
  this.shape_19 = new cjs.Shape();
  this.shape_19.graphics.f("#0C593C").s().p("AgiBIIgHgCIAAgQQAGADAHAAQAFAAAEgDQADgCADgGQADgFADgLIgmhlIASAAIAZBDIACAGIABAJIABAAIACgIIACgGIAVhEIATAAIgiBlQgFAPgFAKQgFAJgGAEQgHAEgLAAIgHAAg");
  this.shape_19.setTransform(133.7, -11.075);
  this.shape_20 = new cjs.Shape();
  this.shape_20.graphics.f("#0C593C").s().p("AglBHIAAiNIAfAAQAWAAALAKQALALAAAVQAAAUgLAMQgLAMgYAAIgLAAIAAA3gAgTABIAKAAQAOAAAHgGQAHgHAAgQQAAgOgGgHQgHgGgNAAIgMAAg");
  this.shape_20.setTransform(125.825, -11.175);
  this.shape_21 = new cjs.Shape();
  this.shape_21.graphics.f("#0C593C").s().p("AAfBHIAAhTIAAgQIABgQIgBAAIg4BzIgWAAIAAiNIASAAIAABSIgBAPIgBARIABAAIA4hyIAWAAIAACNg");
  this.shape_21.setTransform(115.475, -11.175);
  this.shape_22 = new cjs.Shape();
  this.shape_22.graphics.f("#0C593C").s().p("AgIBHIAAh+IghAAIAAgPIBTAAIAAAPIghAAIAAB+g");
  this.shape_22.setTransform(106.15, -11.175);
  this.shape_23 = new cjs.Shape();
  this.shape_23.graphics.f("#0C593C").s().p("AgmBHIAAiNIASAAIAAA7IAPAAQAWAAALALQALAKAAATQAAAUgLALQgMALgUAAgAgUA4IAPAAQAaAAAAgbQAAgNgHgGQgHgHgNAAIgOAAg");
  this.shape_23.setTransform(98.475, -11.175);
  this.shape_24 = new cjs.Shape();
  this.shape_24.graphics.f("#0C593C").s().p("AgwBGIAAgPQADACAFAAQAHAAADgIQADgHACgPIADgZIADgiIAFgnIA/AAIAACNIgSAAIAAh9IgfAAIgBAXIgCAZIgDAWIgDASQgCANgDAJQgEAJgFAEQgFAEgJAAQgHAAgEgCg");
  this.shape_24.setTransform(87.9, -11.075);
  this.shape_25 = new cjs.Shape();
  this.shape_25.graphics.f("#0C593C").s().p("AgiBIIgGgCIAAgQQAFADAHAAQAFAAAEgDQADgCADgGQADgFADgLIgmhlIASAAIAZBDIACAGIABAJIABAAIACgIIACgGIAVhEIATAAIghBlQgGAPgFAKQgFAJgHAEQgGAEgLAAIgHAAg");
  this.shape_25.setTransform(79.8, -11.075);
  this.shape_26 = new cjs.Shape();
  this.shape_26.graphics.f("#0C593C").s().p("AgcA2QgOgUABgiQgBgUAHgQQAGgRAMgKQAMgJARAAQARAAANAHIgGAPIgLgFQgGgCgHAAQgMAAgHAIQgIAIgEANQgEANAAAPQAAAbAKAPQAJAQARAAQAHAAAHgCIAMgEIAAAQQgMAFgQAAQgZAAgOgTg");
  this.shape_26.setTransform(71.65, -11.175);
  this.shape_27 = new cjs.Shape();
  this.shape_27.graphics.f("#0C593C").s().p("AAaBHIAAhCIgzAAIAABCIgSAAIAAiNIASAAIAAA8IAzAAIAAg8IASAAIAACNg");
  this.shape_27.setTransform(61.75, -11.175);
  this.shape_28 = new cjs.Shape();
  this.shape_28.graphics.f("#0C593C").s().p("AgcA/QgMgJgFgRQgGgRAAgUQAAgjANgTQANgSAZAAQASAAALAJQAMAKAFAQQAGARAAAUQAAAVgGAQQgFARgMAKQgLAJgSAAQgRAAgLgKgAgYgqQgIAPAAAbQAAAcAIAPQAJAPAPAAQARAAAIgPQAIgPAAgcQAAgbgIgPQgIgPgRAAQgPAAgJAPg");
  this.shape_28.setTransform(50.875, -11.175);
  this.shape_29 = new cjs.Shape();
  this.shape_29.graphics.f("#0C593C").s().p("AAWBHIgthIIAABIIgSAAIAAiNIASAAIAABEIArhEIAUAAIgtBEIAvBJg");
  this.shape_29.setTransform(41.875, -11.175);
  this.shape_30 = new cjs.Shape();
  this.shape_30.graphics.f("#0C593C").s().p("AgcA/QgMgJgFgRQgGgRAAgUQAAgjANgTQANgSAZAAQASAAALAJQAMAKAFAQQAGARAAAUQAAAVgGAQQgFARgMAKQgLAJgSAAQgRAAgLgKgAgYgqQgIAPAAAbQAAAcAIAPQAJAPAPAAQARAAAIgPQAIgPAAgcQAAgbgIgPQgIgPgRAAQgPAAgJAPg");
  this.shape_30.setTransform(31.175, -11.175);
  this.shape_31 = new cjs.Shape();
  this.shape_31.graphics.f("#0C593C").s().p("AglBHIAAiNIAfAAQAWAAALAKQALALAAAVQAAAUgLAMQgLAMgYAAIgLAAIAAA3gAgTABIAKAAQAOAAAHgGQAHgHAAgQQAAgOgGgHQgHgGgNAAIgMAAg");
  this.shape_31.setTransform(21.825, -11.175);
  this.shape_32 = new cjs.Shape();
  this.shape_32.graphics.f("#0C593C").s().p("AAZBHIAAh+IgxAAIAAB+IgSAAIAAiNIBVAAIAACNg");
  this.shape_32.setTransform(11.725, -11.175);
  this.shape_33 = new cjs.Shape();
  this.shape_33.graphics.f("#0C593C").s().p("AgaAyQAAgJABgGQACgHAGgHQAFgGALgJQAGgGAFgGQAFgHAAgJQAAgRgPAAQgJAAgCAGQgDAGAAAMIgLAAIAAgEQAAgJACgHQAEgGAFgEQAHgFAHAAQAIABAHADQAFADAEAHQADAHAAAIQgBAHgCAGQgDAFgDAEIgKAKIgOAOIgGAHIgCAIIApAAIAAAKg");
  this.shape_33.setTransform(306.4, -44.25);
  this.shape_34 = new cjs.Shape();
  this.shape_34.graphics.f("#0C593C").s().p("AgFAHIAAgNIALAAIAAANg");
  this.shape_34.setTransform(299.075, -39.875);
  this.shape_35 = new cjs.Shape();
  this.shape_35.graphics.f("#0C593C").s().p("AANAlIAAhBIgZAAIAABBIgLAAIAAhKIAvAAIAABKg");
  this.shape_35.setTransform(294.575, -42.95);
  this.shape_36 = new cjs.Shape();
  this.shape_36.graphics.f("#0C593C").s().p("AgZAzIAAhjIALAAIAAAIQACgFAFgCQAEgDAEAAQAYAAABAmQgBAJgBAGQgBAIgDAFQgDAGgEADQgEADgIAAQgEAAgEgDQgDgCgEgFIAAAhgAgLghQgDAJAAANIABAPQABAGADAEQAEAFAFAAQAIAAADgIQADgIAAgPQAAgdgOAAQgIAAgDAIg");
  this.shape_36.setTransform(288.5, -41.775);
  this.shape_37 = new cjs.Shape();
  this.shape_37.graphics.f("#0C593C").s().p("AgOAkQgFgEgEgIQgDgKAAgOQAAgTAHgKQAGgKANABQAbAAAAAmQAAAPgEAJQgDAIgGAEQgGAEgIAAQgIAAgGgEgAgIgaQgEADgBAGQgCAIAAAKQAAAKACAGQABAHADADQAEAEAFAAQAGAAADgEQAEgDABgHQACgGAAgKQAAgKgCgIQgCgGgDgDQgDgDgGAAQgFAAgDADg");
  this.shape_37.setTransform(282.175, -42.95);
  this.shape_38 = new cjs.Shape();
  this.shape_38.graphics.f("#0C593C").s().p("AANAlIgSglIgIALIAAAaIgLAAIAAhKIALAAIAAAjIAZgjIAMAAIgWAdIAXAtg");
  this.shape_38.setTransform(276.75, -42.95);
  this.shape_39 = new cjs.Shape();
  this.shape_39.graphics.f("#0C593C").s().p("AgFAKQAGgBAAgLIgGAAIAAgOIALAAIAAAQQAAAGgDAEQgDAFgFABg");
  this.shape_39.setTransform(269.325, -38.9);
  this.shape_40 = new cjs.Shape();
  this.shape_40.graphics.f("#0C593C").s().p("AgRAxQACgQAFgPQAEgQAHgNQAHgOAKgNIgtAAIAAgKIA3AAIAAAJQgHAJgGALQgGALgEAKIgGAXIgEAYg");
  this.shape_40.setTransform(264.825, -44.125);
  this.shape_41 = new cjs.Shape();
  this.shape_41.graphics.f("#0C593C").s().p("AAFAyIAAhIIgUAAIAAgJQAIAAAEgBQAEgBADgEQADgFABgIIAIAAIAABkg");
  this.shape_41.setTransform(257.875, -44.25);
  this.shape_42 = new cjs.Shape();
  this.shape_42.graphics.f("#0C593C").s().p("AgFAHIAAgNIALAAIAAANg");
  this.shape_42.setTransform(254.075, -39.875);
  this.shape_43 = new cjs.Shape();
  this.shape_43.graphics.f("#0C593C").s().p("AAWAwIAAgVIgrAAIAAAVIgKAAIAAgeIAHAAIAFgNIADgLIABgQIAAgZIAnAAIAABBIAIAAIAAAegAgFgQQAAALgCAGIgGARIAbAAIAAg4IgTAAg");
  this.shape_43.setTransform(249.425, -41.925);
  this.shape_44 = new cjs.Shape();
  this.shape_44.graphics.f("#0C593C").s().p("AgFAKQAGgBAAgLIgGAAIAAgOIALAAIAAAQQAAAGgDAEQgDAFgFABg");
  this.shape_44.setTransform(241.975, -38.9);
  this.shape_45 = new cjs.Shape();
  this.shape_45.graphics.f("#0C593C").s().p("AAOAlIAAgfIgMAAIgOAfIgMAAIARggQgHgCgDgFQgEgFAAgIQAAgGADgFQADgFAEgDQAFgDAGAAIAYAAIAABKgAgHgZQgDAEAAAHQAAANAMgBIAMAAIAAgaIgMAAQgFAAgEADg");
  this.shape_45.setTransform(237.35, -42.95);
  this.shape_46 = new cjs.Shape();
  this.shape_46.graphics.f("#0C593C").s().p("AgZATQAAgHACgEQACgEAEgDIALgEIAMgGQADgBAAgIQAAgGgCgDQgDgCgFAAQgGAAgDADQgCADAAAHIgKAAQAAgXAWABQAGAAAEACQAFADADAEQABAFAAAFIAAArQAAAGAFAAIACAAIAAAHIgFACQgFgBgCgCQgCgBgCgIQgCAGgFADQgDAEgGAAQgTgBAAgUgAAAAAIgHAFIgFAFQgCADAAAFQAAAMAKAAQAGAAAEgFIACgCIAAgEIABgHIAAgOIgJACg");
  this.shape_46.setTransform(232.25, -42.95);
  this.shape_47 = new cjs.Shape();
  this.shape_47.graphics.f("#0C593C").s().p("AAMAlIgRglIgIALIAAAaIgLAAIAAhKIALAAIAAAjIAZgjIANAAIgYAdIAYAtg");
  this.shape_47.setTransform(227.2, -42.95);
  this.shape_48 = new cjs.Shape();
  this.shape_48.graphics.f("#0C593C").s().p("AgOAiQgGgFgCgIQgBgIAAgMQAAgnAZAAQAKAAAGAHQAGAHAAALIgKAAQAAgQgNAAQgHAAgDAIQgDAJAAANQAAANACAJQADAHAIABQAIgBACgFQADgFAAgIIAKAAQAAALgFAJQgGAHgLABQgKAAgGgGg");
  this.shape_48.setTransform(221.375, -42.95);
  this.shape_49 = new cjs.Shape();
  this.shape_49.graphics.f("#0C593C").s().p("AgEAlIAAhBIgUAAIAAgJIAxAAIAAAJIgUAAIAABBg");
  this.shape_49.setTransform(216.325, -42.95);
  this.shape_50 = new cjs.Shape();
  this.shape_50.graphics.f("#0C593C").s().p("AgZATQAAgHACgEQACgEAEgDIALgEIAMgGQADgBAAgIQAAgGgDgDQgCgCgFAAQgGAAgDADQgDADABAHIgKAAQAAgXAVABQAHAAAEACQAFADACAEQACAFAAAFIAAArQABAGAEAAIACAAIAAAHIgEACQgFgBgDgCQgDgBgBgIQgCAGgEADQgFAEgEAAQgUgBAAgUgAAAAAIgHAFIgFAFQgCADAAAFQAAAMAKAAQAGAAAEgFIABgCIABgEIABgHIAAgOIgJACg");
  this.shape_50.setTransform(211.3, -42.95);
  this.shape_51 = new cjs.Shape();
  this.shape_51.graphics.f("#0C593C").s().p("AgbAlIAAgIIAEAAQADAAACgCQACgCABgHIAAgSIAAglIArAAIAABKIgKAAIAAhBIgWAAIAAAdQAAASgEAJQgDAKgKAAIgGgBg");
  this.shape_51.setTransform(205.075, -42.925);
  this.shape_52 = new cjs.Shape();
  this.shape_52.graphics.f("#0C593C").s().p("AAYAlIAAhKIALAAIAABKgAghAlIAAhKIAKAAIAAAgIAQAAQAFAAAEADQAFACADAFQACAFAAAGQAAAGgCAFQgDAFgFADQgEACgFAAgAgXAdIALAAQAIAAADgEQACgDAAgGQAAgNgMAAIgMAAg");
  this.shape_52.setTransform(198.2, -42.95);
  this.shape_53 = new cjs.Shape();
  this.shape_53.graphics.f("#0C593C").s().p("AgYAzIAAhjIAKAAIAAAIQADgFAEgCQAFgDADAAQAZAAAAAmQAAAJgCAGQgBAIgDAFQgDAGgEADQgFADgHAAQgEAAgEgDQgEgCgDgFIAAAhgAgLghQgCAJgBANIABAPQABAGADAEQADAFAGAAQAHAAAEgIQADgIAAgPQAAgdgOAAQgIAAgDAIg");
  this.shape_53.setTransform(191.1, -41.775);
  this.shape_54 = new cjs.Shape();
  this.shape_54.graphics.f("#0C593C").s().p("AATAyIgagxIgMAPIAAAiIgMAAIAAhkIAMAAIAAAzIAkgzIANAAIgeArIAfA5g");
  this.shape_54.setTransform(184.8, -44.25);
  this.shape_55 = new cjs.Shape();
  this.shape_55.graphics.f("#0C593C").s().p("AgFAHIAAgNIALAAIAAANg");
  this.shape_55.setTransform(176.575, -39.875);
  this.shape_56 = new cjs.Shape();
  this.shape_56.graphics.f("#0C593C").s().p("AgbAlIAAgIIAEAAQADAAACgCQACgCABgHIAAgSIAAglIArAAIAABKIgKAAIAAhBIgWAAIAAAdQAAASgEAJQgDAKgKAAIgGgBg");
  this.shape_56.setTransform(171.675, -42.925);
  this.shape_57 = new cjs.Shape();
  this.shape_57.graphics.f("#0C593C").s().p("AgYAxIAAgJQADABAEAAQAGAAADgEIAFgLIgYhLIALAAIARA7IAQg7IALAAIgXBKIgFAOQgBAFgEADQgFADgHAAIgHgBg");
  this.shape_57.setTransform(166.125, -41.675);
  this.shape_58 = new cjs.Shape();
  this.shape_58.graphics.f("#0C593C").s().p("AgFAKQAGgBAAgLIgGAAIAAgOIALAAIAAAQQAAAGgDAEQgDAFgFABg");
  this.shape_58.setTransform(159.225, -38.9);
  this.shape_59 = new cjs.Shape();
  this.shape_59.graphics.f("#0C593C").s().p("AgZATQAAgHACgEQACgEAEgDIALgEIAMgGQADgBAAgIQAAgGgCgDQgDgCgFAAQgHAAgCADQgDADAAAHIgJAAQAAgXAWABQAGAAAEACQAFADADAEQACAFAAAFIAAArQgBAGAEAAIADAAIAAAHIgFACQgEgBgDgCQgCgBgCgIQgCAGgFADQgEAEgFAAQgTgBAAgUgAABAAIgIAFIgFAFQgCADAAAFQAAAMAKAAQAGAAAEgFIACgCIABgEIAAgHIAAgOIgIACg");
  this.shape_59.setTransform(155.1, -42.95);
  this.shape_60 = new cjs.Shape();
  this.shape_60.graphics.f("#0C593C").s().p("AgWAlIAAhKIAYAAQAIAAAFAGQAHAFAAAHQgBAIgDAEQgDAFgFABQAGABAEAFQADAFAAAHQAAAHgCAEQgDAEgEADQgEACgFAAgAgMAdIAMAAQAHAAADgEQACgCABgIQAAgFgEgEQgDgDgFAAIgNAAgAgMgFIAMAAQAFAAADgDQADgCAAgHQAAgKgLgBIgMAAg");
  this.shape_60.setTransform(149.75, -42.95);
  this.shape_61 = new cjs.Shape();
  this.shape_61.graphics.f("#0C593C").s().p("AANAlIgSglIgIALIAAAaIgLAAIAAhKIALAAIAAAjIAZgjIAMAAIgWAdIAXAtg");
  this.shape_61.setTransform(144.45, -42.95);
  this.shape_62 = new cjs.Shape();
  this.shape_62.graphics.f("#0C593C").s().p("AgOAiQgGgFgCgIQgBgIAAgMQAAgnAZAAQAKAAAGAHQAGAHAAALIgKAAQAAgQgNAAQgHAAgDAIQgDAJAAANQAAANACAJQADAHAIABQAIgBACgFQADgFAAgIIAKAAQAAALgFAJQgGAHgLABQgKAAgGgGg");
  this.shape_62.setTransform(138.625, -42.95);
  this.shape_63 = new cjs.Shape();
  this.shape_63.graphics.f("#0C593C").s().p("AgOAkQgFgEgEgIQgDgKAAgOQAAgTAHgKQAGgKANABQAbAAAAAmQAAAPgEAJQgDAIgGAEQgGAEgIAAQgIAAgGgEgAgIgaQgEADgBAGQgCAIAAAKQAAAKACAGQABAHADADQAEAEAFAAQAGAAADgEQAEgDABgHQACgGAAgKQAAgKgCgIQgCgGgDgDQgDgDgGAAQgFAAgDADg");
  this.shape_63.setTransform(132.775, -42.95);
  this.shape_64 = new cjs.Shape();
  this.shape_64.graphics.f("#0C593C").s().p("AAfAyIAAhSIAAgGIAAgGIAAAAIgCAHIgBAGIgWBRIgMAAIgVhSIgDgMIAAAAIAAAHIAAAGIAABRIgLAAIAAhkIAUAAIATBOIACAQIACgQIAUhOIAUAAIAABkg");
  this.shape_64.setTransform(124.675, -44.25);
  this.shape_65 = new cjs.Shape();
  this.shape_65.graphics.f("#0C593C").s().p("AgFAHIAAgNIALAAIAAANg");
  this.shape_65.setTransform(115.425, -39.875);
  this.shape_66 = new cjs.Shape();
  this.shape_66.graphics.f("#0C593C").s().p("AgTAlIAAhKIAnAAIAAAJIgcAAIAABBg");
  this.shape_66.setTransform(112.275, -42.95);
  this.shape_67 = new cjs.Shape();
  this.shape_67.graphics.f("#0C593C").s().p("AgFAKQAGgBAAgLIgGAAIAAgOIALAAIAAAQQAAAGgDAEQgDAFgFABg");
  this.shape_67.setTransform(105.275, -38.9);
  this.shape_68 = new cjs.Shape();
  this.shape_68.graphics.f("#0C593C").s().p("AAIAyIAAgYIgkAAIAAgLIAlhBIAKAAIAABBIAKAAIAAALIgKAAIAAAYgAgTAPIAbAAIAAgvg");
  this.shape_68.setTransform(100.625, -44.25);
  this.shape_69 = new cjs.Shape();
  this.shape_69.graphics.f("#0C593C").s().p("AAFAyIAAhIIgUAAIAAgJQAIAAAEgBQAEgBADgEQADgFABgIIAIAAIAABkg");
  this.shape_69.setTransform(93.825, -44.25);
  this.shape_70 = new cjs.Shape();
  this.shape_70.graphics.f("#0C593C").s().p("AgNAvQgGgEgDgHQgDgHgBgHIgBgRQAAgOACgMQABgLAHgKQAHgIAMgBQAGAAAGAEQAFADADAGQADAFAAAHIgLAAQAAgIgEgDQgDgDgHAAQgEAAgEAEQgDAEgCAGIgCALIgBAOQADgGAFgDQAFgEAFAAQANABAGAIQAHAIAAAOQAAAKgEAIQgDAIgGAEQgGAFgIAAQgJAAgFgFgAgPAQQAAANAFAHQAEAFAHABQAJgBADgGQADgIAAgKQAAgUgQgBQgPABAAATg");
  this.shape_70.setTransform(88.375, -44.15);
  this.shape_71 = new cjs.Shape();
  this.shape_71.graphics.f("#0C593C").s().p("AAFAyIAAhIIgUAAIAAgJQAIAAAEgBQAEgBADgEQADgFABgIIAIAAIAABkg");
  this.shape_71.setTransform(81.425, -44.25);
  this.shape_72 = new cjs.Shape();
  this.shape_72.graphics.f("#0C593C").s().p("AgaAyQAAgJABgGQADgHAFgHQAFgGALgJQAHgGAEgGQAFgHgBgJQAAgRgOAAQgIAAgEAGQgCAGAAAMIgLAAIAAgEQAAgJACgHQADgGAGgEQAHgFAHAAQAJABAFADQAHADACAHQAEAHAAAIQgBAHgCAGQgCAFgEAEIgKAKIgOAOIgGAHIgCAIIApAAIAAAKg");
  this.shape_72.setTransform(75.9, -44.25);
  this.shape_73 = new cjs.Shape();
  this.shape_73.graphics.f("#0C593C").s().p("AAFAyIAAhIIgUAAIAAgJQAIAAAEgBQAEgBADgEQADgFABgIIAIAAIAABkg");
  this.shape_73.setTransform(69.025, -44.25);
  this.shape_74 = new cjs.Shape();
  this.shape_74.graphics.f("#0C593C").s().p("AgFAKQAGgBAAgLIgGAAIAAgOIALAAIAAAQQAAAGgDAEQgDAFgFABg");
  this.shape_74.setTransform(62.375, -38.9);
  this.shape_75 = new cjs.Shape();
  this.shape_75.graphics.f("#0C593C").s().p("AAOAlIAAgfIgMAAIgOAfIgMAAIAQggQgFgCgEgFQgEgFABgIQgBgGADgFQADgFAEgDQAFgDAGAAIAZAAIAABKgAgHgZQgDAEAAAHQAAANAMgBIAMAAIAAgaIgMAAQgFAAgEADg");
  this.shape_75.setTransform(57.75, -42.95);
  this.shape_76 = new cjs.Shape();
  this.shape_76.graphics.f("#0C593C").s().p("AAOAlIAAg3IABgKIgCAKIgYA3IgNAAIAAhKIALAAIAAA4IgBAJIACgJIAYg4IANAAIAABKg");
  this.shape_76.setTransform(52.225, -42.95);
  this.shape_77 = new cjs.Shape();
  this.shape_77.graphics.f("#0C593C").s().p("AgOAiQgGgFgCgIQgBgIAAgMQAAgnAZAAQAKAAAGAHQAGAHAAALIgKAAQAAgQgNAAQgHAAgDAIQgDAJAAANQAAANACAJQADAHAIABQAIgBACgFQADgFAAgIIAKAAQAAALgFAJQgGAHgLABQgKAAgGgGg");
  this.shape_77.setTransform(46.375, -42.95);
  this.shape_78 = new cjs.Shape();
  this.shape_78.graphics.f("#0C593C").s().p("AgOAiQgGgFgCgIQgBgIAAgMQAAgnAZAAQAKAAAGAHQAGAHAAALIgKAAQAAgQgNAAQgHAAgDAIQgDAJAAANQAAANACAJQADAHAIABQAIgBACgFQADgFAAgIIAKAAQAAALgFAJQgGAHgLABQgKAAgGgGg");
  this.shape_78.setTransform(40.925, -42.95);
  this.shape_79 = new cjs.Shape();
  this.shape_79.graphics.f("#0C593C").s().p("AgOAkQgFgEgEgIQgDgKAAgOQAAgTAHgKQAGgKANABQAbAAAAAmQAAAPgEAJQgDAIgGAEQgGAEgIAAQgIAAgGgEgAgIgaQgEADgBAGQgCAIAAAKQAAAKACAGQABAHADADQAEAEAFAAQAGAAADgEQAEgDABgHQACgGAAgKQAAgKgCgIQgCgGgDgDQgDgDgGAAQgFAAgDADg");
  this.shape_79.setTransform(35.075, -42.95);
  this.shape_80 = new cjs.Shape();
  this.shape_80.graphics.f("#0C593C").s().p("AgcAyIAAhkIAcAAQANAAAIAHQAIAIAAAOQAAAJgCAFQgDAGgEACQgEAEgGACQgGABgGAAIgPAAIAAAqgAgRgBIALAAIANgCQAFgBADgEQACgFAAgIQAAgKgFgEQgFgEgKAAIgOAAg");
  this.shape_80.setTransform(28.775, -44.25);
  this.shape_81 = new cjs.Shape();
  this.shape_81.graphics.f("#0C593C").s().p("AgFAKQAGgBAAgLIgGAAIAAgOIALAAIAAAQQAAAFgDAFQgDAFgFACg");
  this.shape_81.setTransform(237.325, -53.5);
  this.shape_82 = new cjs.Shape();
  this.shape_82.graphics.f("#0C593C").s().p("AACAOIAOgOIgOgNIAAgLIAUAVIAAAHIgUAVgAgVAOIANgOIgNgNIAAgLIAUAVIAAAHIgUAVg");
  this.shape_82.setTransform(232.8, -57.975);
  this.shape_83 = new cjs.Shape();
  this.shape_83.graphics.f("#0C593C").s().p("AANAlIAAgjIgZAAIAAAjIgLAAIAAhJIALAAIAAAeIAZAAIAAgeIALAAIAABJg");
  this.shape_83.setTransform(226.625, -57.55);
  this.shape_84 = new cjs.Shape();
  this.shape_84.graphics.f("#0C593C").s().p("AgOAkQgFgEgEgIQgDgJAAgPQAAgSAHgKQAGgKANAAQAbAAAAAmQAAAPgEAJQgDAIgGAEQgGADgIAAQgIAAgGgDgAgIgaQgEADgBAGQgCAIAAAKQAAAJACAHQABAGADAEQAEADAFAAQAGAAADgDQAEgEABgGQACgHAAgJQAAgKgCgIQgCgGgDgDQgDgEgGABQgFgBgDAEg");
  this.shape_84.setTransform(220.425, -57.55);
  this.shape_85 = new cjs.Shape();
  this.shape_85.graphics.f("#0C593C").s().p("AgOAiQgGgFgCgJQgBgHAAgMQAAgnAZAAQAKgBAGAIQAGAHAAALIgKAAQAAgQgNAAQgHgBgDAJQgDAJAAANQAAANACAJQADAHAIAAQAIAAACgEQADgFAAgKIAKAAQAAAMgFAJQgGAHgLAAQgKABgGgGg");
  this.shape_85.setTransform(214.625, -57.55);
  this.shape_86 = new cjs.Shape();
  this.shape_86.graphics.f("#0C593C").s().p("AANAlIAAgjIgZAAIAAAjIgLAAIAAhJIALAAIAAAeIAZAAIAAgeIALAAIAABJg");
  this.shape_86.setTransform(208.775, -57.55);
  this.shape_87 = new cjs.Shape();
  this.shape_87.graphics.f("#0C593C").s().p("AgOAkQgFgEgEgIQgDgJAAgPQAAgSAHgKQAGgKANAAQAbAAAAAmQAAAPgEAJQgDAIgGAEQgGADgIAAQgIAAgGgDgAgIgaQgEADgBAGQgCAIAAAKQAAAJACAHQABAGADAEQAEADAFAAQAGAAADgDQAEgEABgGQACgHAAgJQAAgKgCgIQgCgGgDgDQgDgEgGABQgFgBgDAEg");
  this.shape_87.setTransform(202.575, -57.55);
  this.shape_88 = new cjs.Shape();
  this.shape_88.graphics.f("#0C593C").s().p("AAgAlIgSglIgIALIAAAaIgKAAIAAgaIgIgLIgTAlIgNAAIAYgtIgWgcIAMAAIAaAjIAAgjIAKAAIAAAjIAZgjIANAAIgXAcIAXAtg");
  this.shape_88.setTransform(195.2, -57.55);
  this.shape_89 = new cjs.Shape();
  this.shape_89.graphics.f("#0C593C").s().p("AAcA+IAAgXIg4AAIAAAXIgKAAIAAghIAGAAQAFgIACgJQACgKABgKIABgbIAAgaIA1AAIAABaIAIAAIAAAhgAgKgZIgBAWQgBAJgCAIQgDAIgDAHIAoAAIAAhQIgeAAg");
  this.shape_89.setTransform(187, -57.675);
  this.shape_90 = new cjs.Shape();
  this.shape_90.graphics.f("#0C593C").s().p("AgWAwQgGgDgEgHQgEgHABgJQgBgHADgFQADgGAEgEIALgHIgIgMQgCgFAAgGQAAgFADgFQACgFAFgDQAFgDAFAAQAIAAAHAGQAFAFAAAJQAAAOgQAMIASAbQADgKABgJIAKAAQgBARgHALIAOASIgOAAIgGgJQgJAMgOAAQgJAAgHgEgAgVAKQgDAFAAAHQAAAGACAFQADAEAEACQAEADAGAAQAJAAAHgKIgVggQgHAFgEAFgAgMgmQgCADAAAEQAAAHAHALIAIgIQADgEAAgGQAAgEgDgDQgBgEgFAAQgEAAgDAEg");
  this.shape_90.setTransform(178.95, -58.725);
  this.shape_91 = new cjs.Shape();
  this.shape_91.graphics.f("#0C593C").s().p("AANAlIAAgjIgZAAIAAAjIgLAAIAAhJIALAAIAAAeIAZAAIAAgeIALAAIAABJg");
  this.shape_91.setTransform(171.475, -57.55);
  this.shape_92 = new cjs.Shape();
  this.shape_92.graphics.f("#0C593C").s().p("AgOAkQgFgEgEgIQgDgJAAgPQAAgSAHgKQAGgKANAAQAbAAAAAmQAAAPgEAJQgDAIgGAEQgGADgIAAQgIAAgGgDgAgIgaQgEADgBAGQgCAIAAAKQAAAJACAHQABAGADAEQAEADAFAAQAGAAADgDQAEgEABgGQACgHAAgJQAAgKgCgIQgCgGgDgDQgDgEgGABQgFgBgDAEg");
  this.shape_92.setTransform(165.275, -57.55);
  this.shape_93 = new cjs.Shape();
  this.shape_93.graphics.f("#0C593C").s().p("AgOAiQgGgFgCgJQgBgHAAgMQAAgnAZAAQAKgBAGAIQAGAHAAALIgKAAQAAgQgNAAQgHgBgDAJQgDAJAAANQAAANACAJQADAHAIAAQAIAAACgEQADgFAAgKIAKAAQAAAMgFAJQgGAHgLAAQgKABgGgGg");
  this.shape_93.setTransform(159.475, -57.55);
  this.shape_94 = new cjs.Shape();
  this.shape_94.graphics.f("#0C593C").s().p("AANAlIAAgjIgZAAIAAAjIgLAAIAAhJIALAAIAAAeIAZAAIAAgeIALAAIAABJg");
  this.shape_94.setTransform(153.625, -57.55);
  this.shape_95 = new cjs.Shape();
  this.shape_95.graphics.f("#0C593C").s().p("AgOAkQgFgEgEgIQgDgJAAgPQAAgSAHgKQAGgKANAAQAbAAAAAmQAAAPgEAJQgDAIgGAEQgGADgIAAQgIAAgGgDgAgIgaQgEADgBAGQgCAIAAAKQAAAJACAHQABAGADAEQAEADAFAAQAGAAADgDQAEgEABgGQACgHAAgJQAAgKgCgIQgCgGgDgDQgDgEgGABQgFgBgDAEg");
  this.shape_95.setTransform(147.425, -57.55);
  this.shape_96 = new cjs.Shape();
  this.shape_96.graphics.f("#0C593C").s().p("AAgAlIgTglIgIALIAAAaIgJAAIAAgaIgJgLIgSAlIgMAAIAXgtIgWgcIAMAAIAaAjIAAgjIAJAAIAAAjIAagjIANAAIgXAcIAYAtg");
  this.shape_96.setTransform(140.05, -57.55);
  this.shape_97 = new cjs.Shape();
  this.shape_97.graphics.f("#0C593C").s().p("AAdA+IAAgXIg5AAIAAAXIgLAAIAAghIAHAAQAFgIACgJQACgKABgKIAAgbIAAgaIA1AAIAABaIAJAAIAAAhgAgKgZIgBAWQgBAJgCAIQgCAIgEAHIAoAAIAAhQIgeAAg");
  this.shape_97.setTransform(131.85, -57.675);
  this.shape_98 = new cjs.Shape();
  this.shape_98.graphics.f("#0C593C").s().p("AACAEIAAgHIAUgVIAAALIgNANIANAOIAAALgAgVAEIAAgHIAUgVIAAALIgNANIANAOIAAALg");
  this.shape_98.setTransform(124.75, -57.975);
  this.shape_99 = new cjs.Shape();
  this.shape_99.graphics.f("#0C593C").s().p("AgQAxQgHgFgDgHQgEgIgBgJIgBgUQAAgNACgMQADgMAHgHQAHgIANAAQAUAAAGAPQAHAPAAAWQAAAYgGAOQgHAOgUAAQgKAAgGgDgAgMglQgFAFgCAKQgCAIAAANIABASQABAJACAFQADAGAEADQAEADAGAAQAHAAAEgDQAEgDADgGQACgFABgJIABgSIgBgRQgBgGgDgGQgCgFgFgDQgEgDgGgBQgIABgEAEg");
  this.shape_99.setTransform(114.975, -58.8);
  this.shape_100 = new cjs.Shape();
  this.shape_100.graphics.f("#0C593C").s().p("AgQAxQgHgFgDgHQgEgIgBgJIgBgUQAAgNACgMQADgMAHgHQAHgIANAAQAUAAAGAPQAHAPAAAWQAAAYgGAOQgHAOgUAAQgKAAgGgDgAgMglQgFAFgCAKQgCAIAAANIABASQABAJACAFQADAGAEADQAEADAGAAQAHAAAEgDQAEgDADgGQACgFABgJIABgSIgBgRQgBgGgDgGQgCgFgFgDQgEgDgGgBQgIABgEAEg");
  this.shape_100.setTransform(107.275, -58.8);
  this.shape_101 = new cjs.Shape();
  this.shape_101.graphics.f("#0C593C").s().p("AgQAxQgHgFgDgHQgEgIgBgJIgBgUQAAgNACgMQADgMAHgHQAHgIANAAQAUAAAGAPQAHAPAAAWQAAAYgGAOQgHAOgUAAQgKAAgGgDgAgMglQgFAFgCAKQgCAIAAANIABASQABAJACAFQADAGAEADQAEADAGAAQAHAAAEgDQAEgDADgGQACgFABgJIABgSIgBgRQgBgGgDgGQgCgFgFgDQgEgDgGgBQgIABgEAEg");
  this.shape_101.setTransform(99.575, -58.8);
  this.shape_102 = new cjs.Shape();
  this.shape_102.graphics.f("#0C593C").s().p("AACAOIAOgOIgOgNIAAgLIAUAVIAAAHIgUAVgAgVAOIANgOIgNgNIAAgLIAUAVIAAAHIgUAVg");
  this.shape_102.setTransform(325.75, -71.475);
  this.shape_103 = new cjs.Shape();
  this.shape_103.graphics.f("#0C593C").s().p("AANAlIAAgjIgZAAIAAAjIgLAAIAAhJIALAAIAAAeIAZAAIAAgeIALAAIAABJg");
  this.shape_103.setTransform(319.575, -71.05);
  this.shape_104 = new cjs.Shape();
  this.shape_104.graphics.f("#0C593C").s().p("AgOAkQgFgEgEgIQgDgJAAgPQAAgSAHgKQAGgKANAAQAbAAAAAmQAAAPgEAJQgDAIgGAEQgGADgIAAQgIAAgGgDgAgIgaQgEADgBAGQgCAIAAAKQAAAJACAHQABAGADAEQAEADAFAAQAGAAADgDQAEgEABgGQACgHAAgJQAAgKgCgIQgCgGgDgDQgDgEgGABQgFgBgDAEg");
  this.shape_104.setTransform(313.375, -71.05);
  this.shape_105 = new cjs.Shape();
  this.shape_105.graphics.f("#0C593C").s().p("AgOAiQgGgFgCgJQgBgHAAgMQAAgnAZAAQAKgBAGAIQAGAHAAALIgKAAQAAgQgNAAQgHgBgDAJQgDAJAAANQAAANACAJQADAHAIAAQAIAAACgEQADgFAAgKIAKAAQAAAMgFAJQgGAHgLAAQgKABgGgGg");
  this.shape_105.setTransform(307.575, -71.05);
  this.shape_106 = new cjs.Shape();
  this.shape_106.graphics.f("#0C593C").s().p("AANAlIAAgjIgZAAIAAAjIgLAAIAAhJIALAAIAAAeIAZAAIAAgeIALAAIAABJg");
  this.shape_106.setTransform(301.725, -71.05);
  this.shape_107 = new cjs.Shape();
  this.shape_107.graphics.f("#0C593C").s().p("AgOAkQgFgEgEgIQgDgJAAgPQAAgSAHgKQAGgKANAAQAbAAAAAmQAAAPgEAJQgDAIgGAEQgGADgIAAQgIAAgGgDgAgIgaQgEADgBAGQgCAIAAAKQAAAJACAHQABAGADAEQAEADAFAAQAGAAADgDQAEgEABgGQACgHAAgJQAAgKgCgIQgCgGgDgDQgDgEgGABQgFgBgDAEg");
  this.shape_107.setTransform(295.525, -71.05);
  this.shape_108 = new cjs.Shape();
  this.shape_108.graphics.f("#0C593C").s().p("AAgAlIgSglIgIALIAAAaIgKAAIAAgaIgIgLIgTAlIgNAAIAZgtIgYgcIANAAIAaAjIAAgjIAKAAIAAAjIAZgjIANAAIgYAcIAYAtg");
  this.shape_108.setTransform(288.15, -71.05);
  this.shape_109 = new cjs.Shape();
  this.shape_109.graphics.f("#0C593C").s().p("AAcA+IAAgXIg4AAIAAAXIgKAAIAAghIAGAAQAFgIACgJQADgKAAgKIABgbIAAgaIA1AAIAABaIAHAAIAAAhgAgKgZIgBAWQgBAJgDAIQgCAIgDAHIAoAAIAAhQIgeAAg");
  this.shape_109.setTransform(279.95, -71.175);
  this.shape_110 = new cjs.Shape();
  this.shape_110.graphics.f("#0C593C").s().p("AgWAwQgGgDgEgHQgDgHAAgJQAAgHACgFQACgGAFgEIAMgHIgJgMQgCgFAAgGQAAgFADgFQADgFAEgDQAFgDAGAAQAHAAAHAGQAFAFAAAJQAAAOgRAMIATAbQADgKABgJIAKAAQgCARgGALIAOASIgOAAIgGgJQgKAMgNAAQgJAAgHgEgAgVAKQgDAFAAAHQAAAGACAFQADAEAFACQAEADAGAAQAIAAAHgKIgVggQgHAFgEAFgAgMgmQgCADAAAEQAAAHAIALIAHgIQADgEAAgGQAAgEgCgDQgCgEgEAAQgFAAgDAEg");
  this.shape_110.setTransform(271.9, -72.225);
  this.shape_111 = new cjs.Shape();
  this.shape_111.graphics.f("#0C593C").s().p("AANAlIAAgjIgZAAIAAAjIgLAAIAAhJIALAAIAAAeIAZAAIAAgeIALAAIAABJg");
  this.shape_111.setTransform(264.425, -71.05);
  this.shape_112 = new cjs.Shape();
  this.shape_112.graphics.f("#0C593C").s().p("AgOAkQgFgEgEgIQgDgJAAgPQAAgSAHgKQAGgKANAAQAbAAAAAmQAAAPgEAJQgDAIgGAEQgGADgIAAQgIAAgGgDgAgIgaQgEADgBAGQgCAIAAAKQAAAJACAHQABAGADAEQAEADAFAAQAGAAADgDQAEgEABgGQACgHAAgJQAAgKgCgIQgCgGgDgDQgDgEgGABQgFgBgDAEg");
  this.shape_112.setTransform(258.225, -71.05);
  this.shape_113 = new cjs.Shape();
  this.shape_113.graphics.f("#0C593C").s().p("AgOAiQgGgFgCgJQgBgHAAgMQAAgnAZAAQAKgBAGAIQAGAHAAALIgKAAQAAgQgNAAQgHgBgDAJQgDAJAAANQAAANACAJQADAHAIAAQAIAAACgEQADgFAAgKIAKAAQAAAMgFAJQgGAHgLAAQgKABgGgGg");
  this.shape_113.setTransform(252.425, -71.05);
  this.shape_114 = new cjs.Shape();
  this.shape_114.graphics.f("#0C593C").s().p("AANAlIAAgjIgZAAIAAAjIgLAAIAAhJIALAAIAAAeIAZAAIAAgeIALAAIAABJg");
  this.shape_114.setTransform(246.575, -71.05);
  this.shape_115 = new cjs.Shape();
  this.shape_115.graphics.f("#0C593C").s().p("AgOAkQgFgEgEgIQgDgJAAgPQAAgSAHgKQAGgKANAAQAbAAAAAmQAAAPgEAJQgDAIgGAEQgGADgIAAQgIAAgGgDgAgIgaQgEADgBAGQgCAIAAAKQAAAJACAHQABAGADAEQAEADAFAAQAGAAADgDQAEgEABgGQACgHAAgJQAAgKgCgIQgCgGgDgDQgDgEgGABQgFgBgDAEg");
  this.shape_115.setTransform(240.375, -71.05);
  this.shape_116 = new cjs.Shape();
  this.shape_116.graphics.f("#0C593C").s().p("AAgAlIgSglIgIALIAAAaIgKAAIAAgaIgIgLIgTAlIgNAAIAYgtIgWgcIAMAAIAaAjIAAgjIAKAAIAAAjIAZgjIANAAIgXAcIAXAtg");
  this.shape_116.setTransform(233, -71.05);
  this.shape_117 = new cjs.Shape();
  this.shape_117.graphics.f("#0C593C").s().p("AAcA+IAAgXIg4AAIAAAXIgKAAIAAghIAGAAQAFgIACgJQACgKABgKIABgbIAAgaIA1AAIAABaIAIAAIAAAhgAgKgZIgBAWQgBAJgCAIQgDAIgDAHIAoAAIAAhQIgeAAg");
  this.shape_117.setTransform(224.8, -71.175);
  this.shape_118 = new cjs.Shape();
  this.shape_118.graphics.f("#0C593C").s().p("AACAEIAAgHIAUgVIAAALIgOANIAOAOIAAALgAgVAEIAAgHIAUgVIAAALIgNANIANAOIAAALg");
  this.shape_118.setTransform(217.7, -71.475);
  this.shape_119 = new cjs.Shape();
  this.shape_119.graphics.f("#0C593C").s().p("AgQAxQgHgFgDgHQgEgIgBgJIgBgUQAAgNACgMQADgMAHgHQAHgIANAAQAUAAAGAPQAHAPAAAWQAAAYgGAOQgHAOgUAAQgKAAgGgDgAgMglQgFAFgCAKQgCAIAAANIABASQABAJACAFQADAGAEADQAEADAGAAQAHAAAEgDQAEgDADgGQACgFABgJIABgSIgBgRQgBgGgDgGQgCgFgFgDQgEgDgGgBQgIABgEAEg");
  this.shape_119.setTransform(207.925, -72.3);
  this.shape_120 = new cjs.Shape();
  this.shape_120.graphics.f("#0C593C").s().p("AgQAxQgHgFgDgHQgEgIgBgJIgBgUQAAgNACgMQADgMAHgHQAHgIANAAQAUAAAGAPQAHAPAAAWQAAAYgGAOQgHAOgUAAQgKAAgGgDgAgMglQgFAFgCAKQgCAIAAANIABASQABAJACAFQADAGAEADQAEADAGAAQAHAAAEgDQAEgDADgGQACgFABgJIABgSIgBgRQgBgGgDgGQgCgFgFgDQgEgDgGgBQgIABgEAEg");
  this.shape_120.setTransform(200.225, -72.3);
  this.shape_121 = new cjs.Shape();
  this.shape_121.graphics.f("#0C593C").s().p("AgQAxQgHgFgDgHQgEgIgBgJIgBgUQAAgNACgMQADgMAHgHQAHgIANAAQAUAAAGAPQAHAPAAAWQAAAYgGAOQgHAOgUAAQgKAAgGgDgAgMglQgFAFgCAKQgCAIAAANIABASQABAJACAFQADAGAEADQAEADAGAAQAHAAAEgDQAEgDADgGQACgFABgJIABgSIgBgRQgBgGgDgGQgCgFgFgDQgEgDgGgBQgIABgEAEg");
  this.shape_121.setTransform(192.525, -72.3);
  this.shape_122 = new cjs.Shape();
  this.shape_122.graphics.f("#0C593C").s().p("AgWAlIAAhJIAXAAQAJAAAGAEQAFAFAAAJQAAAGgDAFQgDAFgFACQAGAAADAFQAEAEAAAIQAAAGgDAFQgCAEgEADQgFADgEgBgAgLAdIALAAQAHAAADgDQACgEAAgGQAAgHgDgDQgDgDgFAAIgMAAgAgLgFIALAAQAFAAADgDQADgCgBgHQABgLgLABIgLAAg");
  this.shape_122.setTransform(183.2, -71.05);
  this.shape_123 = new cjs.Shape();
  this.shape_123.graphics.f("#0C593C").s().p("AgEAlIAAhAIgUAAIAAgJIAxAAIAAAJIgUAAIAABAg");
  this.shape_123.setTransform(177.925, -71.05);
  this.shape_124 = new cjs.Shape();
  this.shape_124.graphics.f("#0C593C").s().p("AgOAiQgGgFgCgJQgBgHAAgMQAAgnAZAAQAKgBAGAIQAGAHAAALIgKAAQAAgQgNAAQgHgBgDAJQgDAJAAANQAAANACAJQADAHAIAAQAIAAACgEQADgFAAgKIAKAAQAAAMgFAJQgGAHgLAAQgKABgGgGg");
  this.shape_124.setTransform(172.925, -71.05);
  this.shape_125 = new cjs.Shape();
  this.shape_125.graphics.f("#0C593C").s().p("AAWAwIAAgVIgrAAIAAAVIgKAAIAAgeIAHAAIAFgNIADgLIABgQIAAgZIAnAAIAABBIAIAAIAAAegAgFgQQAAALgCAGIgGARIAbAAIAAg4IgTAAg");
  this.shape_125.setTransform(166.925, -70.025);
  this.shape_126 = new cjs.Shape();
  this.shape_126.graphics.f("#0C593C").s().p("AgLAkQgGgEgDgIQgDgJAAgPQAAgmAXAAQALAAAFAFQAFAGABAJQACAIAAALIgjAAIAAAQQABAGADAEQADADAFAAQAMABAAgTIALAAQAAAIgDAGQgCAGgFAEQgFADgIAAQgHAAgFgDgAgJgXQgCAGAAAKIAYAAQAAgKgDgHQgCgFgHAAQgHgBgDAHg");
  this.shape_126.setTransform(160.975, -71.05);
  this.shape_127 = new cjs.Shape();
  this.shape_127.graphics.f("#0C593C").s().p("AgYAzIAAhjIAKAAIAAAIQADgFAEgCQAFgDADAAQAYAAAAAmQAAAJgBAGQgBAIgCAFQgDAGgFADQgFADgGAAQgFAAgDgDQgFgCgDgFIAAAhgAgLghQgCAJgBANIABAPQABAGADAEQADAFAGAAQAHAAAEgIQADgIAAgPQAAgdgOAAQgIAAgDAIg");
  this.shape_127.setTransform(155.35, -69.875);
  this.shape_128 = new cjs.Shape();
  this.shape_128.graphics.f("#0C593C").s().p("AgOAiQgGgFgCgJQgBgHAAgMQAAgnAZAAQAKgBAGAIQAGAHAAALIgKAAQAAgQgNAAQgHgBgDAJQgDAJAAANQAAANACAJQADAHAIAAQAIAAACgEQADgFAAgKIAKAAQAAAMgFAJQgGAHgLAAQgKABgGgGg");
  this.shape_128.setTransform(149.425, -71.05);
  this.shape_129 = new cjs.Shape();
  this.shape_129.graphics.f("#0C593C").s().p("AASAlIgSgeIgRAeIgLAAIAXglIgVgkIALAAIAQAcIAQgcIALAAIgWAkIAXAlg");
  this.shape_129.setTransform(141.075, -71.05);
  this.shape_130 = new cjs.Shape();
  this.shape_130.graphics.f("#0C593C").s().p("AAYAlIAAhJIAKAAIAABJgAghAlIAAhJIAKAAIAAAfIAQAAQAFAAAEADQAEACAEAFQACAFAAAGQAAAHgCAEQgEAFgEADQgEADgFgBgAgXAdIALAAQAIAAADgDQACgDAAgHQAAgNgMAAIgMAAg");
  this.shape_130.setTransform(134.2, -71.05);
  this.shape_131 = new cjs.Shape();
  this.shape_131.graphics.f("#0C593C").s().p("AANAlIAAgjIgZAAIAAAjIgLAAIAAhJIALAAIAAAeIAZAAIAAgeIALAAIAABJg");
  this.shape_131.setTransform(126.975, -71.05);
  this.shape_132 = new cjs.Shape();
  this.shape_132.graphics.f("#0C593C").s().p("AANAlIAAgjIgZAAIAAAjIgLAAIAAhJIALAAIAAAeIAZAAIAAgeIALAAIAABJg");
  this.shape_132.setTransform(120.775, -71.05);
  this.shape_133 = new cjs.Shape();
  this.shape_133.graphics.f("#0C593C").s().p("AgLAkQgGgEgDgIQgDgJAAgPQAAgmAXAAQALAAAFAFQAFAGABAJQACAIAAALIgjAAIAAAQQABAGADAEQADADAFAAQAMABAAgTIALAAQAAAIgDAGQgCAGgFAEQgFADgIAAQgHAAgFgDgAgJgXQgCAGAAAKIAYAAQAAgKgDgHQgCgFgHAAQgHgBgDAHg");
  this.shape_133.setTransform(114.875, -71.05);
  this.shape_134 = new cjs.Shape();
  this.shape_134.graphics.f("#0C593C").s().p("AgWAlIAAhJIAXAAQAJAAAGAEQAFAFABAJQAAAGgEAFQgDAFgFACQAGAAADAFQAEAEAAAIQAAAGgCAFQgDAEgEADQgEADgFgBgAgLAdIALAAQAHAAADgDQADgEAAgGQAAgHgEgDQgDgDgFAAIgMAAgAgLgFIALAAQAFAAADgDQACgCAAgHQAAgLgKABIgLAAg");
  this.shape_134.setTransform(109.6, -71.05);
  this.shape_135 = new cjs.Shape();
  this.shape_135.graphics.f("#0C593C").s().p("AgEAlIAAhAIgUAAIAAgJIAxAAIAAAJIgUAAIAABAg");
  this.shape_135.setTransform(104.325, -71.05);
  this.shape_136 = new cjs.Shape();
  this.shape_136.graphics.f("#0C593C").s().p("AgOAiQgGgFgCgJQgBgHAAgMQAAgnAZAAQAKgBAGAIQAGAHAAALIgKAAQAAgQgNAAQgHgBgDAJQgDAJAAANQAAANACAJQADAHAIAAQAIAAACgEQADgFAAgKIAKAAQAAAMgFAJQgGAHgLAAQgKABgGgGg");
  this.shape_136.setTransform(99.325, -71.05);
  this.shape_137 = new cjs.Shape();
  this.shape_137.graphics.f("#0C593C").s().p("AgYAzIAAhjIAKAAIAAAIQADgFAEgCQAEgDAEAAQAYAAAAAmQAAAJgBAGQgBAIgCAFQgDAGgFADQgFADgGAAQgFAAgDgDQgFgCgCgFIAAAhgAgLghQgDAJABANIAAAPQABAGADAEQADAFAGAAQAIAAADgIQADgIAAgPQAAgdgOAAQgIAAgDAIg");
  this.shape_137.setTransform(93.6, -69.875);
  this.shape_138 = new cjs.Shape();
  this.shape_138.graphics.f("#0C593C").s().p("AgZATQAAgGACgFQACgEAEgDIALgEIAMgGQADgBAAgIQAAgGgDgDQgCgCgGAAQgFgBgDAEQgDADABAHIgKAAQAAgWAVAAQAHAAAFACQAEADACAEQACAFABAFIAAArQAAAGADAAIADgBIAAAIIgEABQgFAAgDgCQgDgBgBgIQgCAFgEAEQgFADgEAAQgUAAAAgUgAAAAAIgHAFIgFAFQgCAEAAAEQAAAMAKAAQAGAAAEgEIABgDIABgEIABgHIAAgOIgJACg");
  this.shape_138.setTransform(87.65, -71.05);
  this.shape_139 = new cjs.Shape();
  this.shape_139.graphics.f("#0C593C").s().p("AANAlIgSglIgIALIAAAaIgLAAIAAhJIALAAIAAAjIAZgjIAMAAIgXAcIAYAtg");
  this.shape_139.setTransform(82.6, -71.05);
  this.shape_140 = new cjs.Shape();
  this.shape_140.graphics.f("#0C593C").s().p("AgLAkQgGgEgDgIQgDgJAAgPQAAgmAXAAQALAAAFAFQAFAGABAJQACAIAAALIgjAAIAAAQQABAGADAEQADADAFAAQAMABAAgTIALAAQAAAIgDAGQgCAGgFAEQgFADgIAAQgHAAgFgDgAgJgXQgCAGAAAKIAYAAQAAgKgDgHQgCgFgHAAQgHgBgDAHg");
  this.shape_140.setTransform(76.675, -71.05);
  this.shape_141 = new cjs.Shape();
  this.shape_141.graphics.f("#0C593C").s().p("AgbAlIAAgIIAEAAQADAAACgCQACgCABgHIAAgSIAAglIArAAIAABKIgKAAIAAhBIgWAAIAAAdQAAASgEAJQgDAKgKAAIgGgBg");
  this.shape_141.setTransform(70.525, -71.025);
  this.shape_142 = new cjs.Shape();
  this.shape_142.graphics.f("#0C593C").s().p("AgLAkQgGgEgDgIQgDgJAAgPQAAgmAXAAQALAAAFAFQAFAGABAJQACAIAAALIgjAAIAAAQQABAGADAEQADADAFAAQAMABAAgTIALAAQAAAIgDAGQgCAGgFAEQgFADgIAAQgHAAgFgDgAgJgXQgCAGAAAKIAYAAQAAgKgDgHQgCgFgHAAQgHgBgDAHg");
  this.shape_142.setTransform(62.175, -71.05);
  this.shape_143 = new cjs.Shape();
  this.shape_143.graphics.f("#0C593C").s().p("AAMAlIgRglIgIALIAAAaIgLAAIAAhJIALAAIAAAjIAZgjIANAAIgYAcIAYAtg");
  this.shape_143.setTransform(57.2, -71.05);
  this.shape_144 = new cjs.Shape();
  this.shape_144.graphics.f("#0C593C").s().p("AAOAxIAAg3IABgJIgCAJIgYA3IgNAAIAAhJIALAAIAAA3IgBAJIACgJIAYg3IANAAIAABJgAgLgkQgEgEgBgJIAGAAQACAKAIAAQAFAAADgCQADgDABgFIAFAAQAAAJgFAEQgFAEgHAAQgGAAgFgEg");
  this.shape_144.setTransform(50.925, -72.25);
  this.shape_145 = new cjs.Shape();
  this.shape_145.graphics.f("#0C593C").s().p("AgLAkQgGgEgDgIQgDgJAAgPQAAgmAXAAQALAAAFAFQAFAGABAJQACAIAAALIgjAAIAAAQQABAGADAEQADADAFAAQAMABAAgTIALAAQAAAIgDAGQgCAGgFAEQgFADgIAAQgHAAgFgDgAgJgXQgCAGAAAKIAYAAQAAgKgDgHQgCgFgHAAQgHgBgDAHg");
  this.shape_145.setTransform(44.975, -71.05);
  this.shape_146 = new cjs.Shape();
  this.shape_146.graphics.f("#0C593C").s().p("AANAlIAAgjIgZAAIAAAjIgLAAIAAhJIALAAIAAAeIAZAAIAAgeIALAAIAABJg");
  this.shape_146.setTransform(39.225, -71.05);
  this.shape_147 = new cjs.Shape();
  this.shape_147.graphics.f("#0C593C").s().p("AAOAlIAAg3IABgJIgCAJIgYA3IgNAAIAAhJIALAAIAAA3IgBAJIACgJIAYg3IANAAIAABJg");
  this.shape_147.setTransform(32.975, -71.05);
  this.shape_148 = new cjs.Shape();
  this.shape_148.graphics.f("#0C593C").s().p("AgbAlIAAgIIAEAAQADAAACgCQACgCABgHIAAgSIAAglIArAAIAABKIgKAAIAAhBIgWAAIAAAdQAAASgEAJQgDAKgKAAIgGgBg");
  this.shape_148.setTransform(26.325, -71.025);
  this.shape_149 = new cjs.Shape();
  this.shape_149.graphics.f("#0C593C").s().p("AgcAyIAAhkIAbAAQAIAAAHADQAFAEAEAFQADAGAAAIQAAAIgEAGQgEAGgHACQAFABAEACQAEADACAGQACAFABAGQAAAOgIAIQgHAHgOAAgAgQAoIAQAAQAIAAAFgEQAEgEAAgLQAAgSgSAAIgPAAgAgQgGIAOAAQAFAAADgCQAEgCACgEQACgDAAgGQAAgQgPAAIgPAAg");
  this.shape_149.setTransform(17.45, -72.35);
  this.shape_150 = new cjs.Shape();
  this.shape_150.graphics.f("#0C593C").s().p("AAAAGIgJANIgGgEIAKgMIgPgFIACgGIAQAGIAAgRIAGAAIAAAQIAOgFIADAGIgQAEIALANIgGAFg");
  this.shape_150.setTransform(10.725, -75.4);
  this.shape_151 = new cjs.Shape();
  this.shape_151.graphics.f("#0C593C").s().p("AAbA0IAAhBIAAgKIABgNIgBAAIgXBYIgIAAIgWhYIgBAAIABANIAAAKIAABBIgKAAIAAhnIAPAAIAVBUIAWhUIAPAAIAABng");
  this.shape_151.setTransform(324.85, -29.375);
  this.shape_152 = new cjs.Shape();
  this.shape_152.graphics.f("#0C593C").s().p("AgSA0IAAhnIAmAAIAAALIgbAAIAAAhIAZAAIAAAKIgZAAIAAAmIAbAAIAAALg");
  this.shape_152.setTransform(316.55, -29.375);
  this.shape_153 = new cjs.Shape();
  this.shape_153.graphics.f("#0C593C").s().p("AATA0IAAg8IAAgNIAAgLIAAAAIgiBUIgNAAIAAhnIALAAIAAA8IAAALIgBAMIABAAIAhhTIANAAIAABng");
  this.shape_153.setTransform(308.725, -29.375);
  this.shape_154 = new cjs.Shape();
  this.shape_154.graphics.f("#0C593C").s().p("AAQA0IAAgxIgfAAIAAAxIgLAAIAAhnIALAAIAAAsIAfAAIAAgsIALAAIAABng");
  this.shape_154.setTransform(300.2, -29.375);
  this.shape_155 = new cjs.Shape();
  this.shape_155.graphics.f("#0C593C").s().p("AgTA0IAAhnIAnAAIAAALIgbAAIAAAhIAYAAIAAAKIgYAAIAAAmIAbAAIAAALg");
  this.shape_155.setTransform(292.95, -29.375);
  this.shape_156 = new cjs.Shape();
  this.shape_156.graphics.f("#0C593C").s().p("AAPA0IAAgxIgdAAIAAAxIgLAAIAAhnIALAAIAAAsIAdAAIAAgsIAMAAIAABng");
  this.shape_156.setTransform(285.4, -29.375);
  this.shape_157 = new cjs.Shape();
  this.shape_157.graphics.f("#0C593C").s().p("AgSA0IAAhnIAlAAIAAALIgbAAIAAAhIAZAAIAAAKIgZAAIAAAmIAbAAIAAALg");
  this.shape_157.setTransform(278.15, -29.375);
  this.shape_158 = new cjs.Shape();
  this.shape_158.graphics.f("#0C593C").s().p("AAbA0IAAhBIAAgKIABgNIgBAAIgXBYIgIAAIgWhYIgBAAIABANIAAAKIAABBIgKAAIAAhnIAPAAIAVBUIAWhUIAPAAIAABng");
  this.shape_158.setTransform(269.5, -29.375);
  this.shape_159 = new cjs.Shape();
  this.shape_159.graphics.f("#0C593C").s().p("AATA0IAAg8IAAgNIAAgLIAAAAIgiBUIgNAAIAAhnIALAAIAAA8IAAALIgBAMIABAAIAhhTIANAAIAABng");
  this.shape_159.setTransform(259.875, -29.375);
  this.shape_160 = new cjs.Shape();
  this.shape_160.graphics.f("#0C593C").s().p("AgWA0IAAhnIATAAQANAAAGAIQAHAHAAAQQAAAPgHAIQgGAJgOAAIgHAAIAAAogAgLABIAGAAQAIAAAEgEQAFgFAAgMQAAgLgEgEQgEgFgIAAIgHAAg");
  this.shape_160.setTransform(252.225, -29.375);
  this.shape_161 = new cjs.Shape();
  this.shape_161.graphics.f("#0C593C").s().p("AAPA0IAAhcIgdAAIAABcIgLAAIAAhnIAzAAIAABng");
  this.shape_161.setTransform(244.225, -29.375);
  this.shape_162 = new cjs.Shape();
  this.shape_162.graphics.f("#0C593C").s().p("AAXBCIAAgcIgtAAIAAAcIgKAAIAAgnIAGAAQAHgWAEgWQAEgXABgZIAiAAIAABcIAJAAIAAAngAgDgaIgFAbIgHAaIAdAAIAAhRIgPAAIgCAcg");
  this.shape_162.setTransform(232.425, -27.975);
  this.shape_163 = new cjs.Shape();
  this.shape_163.graphics.f("#0C593C").s().p("AgTA0IAAhnIAnAAIAAALIgbAAIAAAhIAYAAIAAAKIgYAAIAAAmIAbAAIAAALg");
  this.shape_163.setTransform(225.45, -29.375);
  this.shape_164 = new cjs.Shape();
  this.shape_164.graphics.f("#0C593C").s().p("AgWA0IAAhnIATAAQANAAAGAIQAHAHAAAQQAAAPgHAIQgGAJgOAAIgHAAIAAAogAgLABIAGAAQAIAAAEgEQAFgFAAgMQAAgLgEgEQgEgFgIAAIgHAAg");
  this.shape_164.setTransform(218.725, -29.375);
  this.shape_165 = new cjs.Shape();
  this.shape_165.graphics.f("#0C593C").s().p("AgTA0IAAhnIAnAAIAAALIgcAAIAAAhIAZAAIAAAKIgZAAIAAAmIAcAAIAAALg");
  this.shape_165.setTransform(211.85, -29.375);
  this.shape_166 = new cjs.Shape();
  this.shape_166.graphics.f("#0C593C").s().p("AAPA0IAAhcIgdAAIAABcIgLAAIAAhnIAzAAIAABng");
  this.shape_166.setTransform(204.175, -29.375);
  this.shape_167 = new cjs.Shape();
  this.shape_167.graphics.f("#0C593C").s().p("AgEAHQgCgCAAgFQAAgEACgCQACgCACgBQADAAACACQACADAAAEQAAAFgCACQgCACgDAAQgCAAgCgCg");
  this.shape_167.setTransform(194.45, -24.95);
  this.shape_168 = new cjs.Shape();
  this.shape_168.graphics.f("#0C593C").s().p("AAPA0IAAgrIgLAAIgQArIgMAAIATguQgHgDgEgGQgDgHgBgLQAAgeAaAAIATAAIAABngAgEgkQgFAFAAAKQAAAUAPAAIAIAAIAAgnIgHAAQgIAAgDAEg");
  this.shape_168.setTransform(188.45, -29.375);
  this.shape_169 = new cjs.Shape();
  this.shape_169.graphics.f("#0C593C").s().p("AATA0IAAg8IAAgNIAAgLIAAAAIgiBUIgNAAIAAhnIALAAIAAA8IAAALIgBAMIABAAIAhhTIANAAIAABng");
  this.shape_169.setTransform(180.775, -29.375);
  this.shape_170 = new cjs.Shape();
  this.shape_170.graphics.f("#0C593C").s().p("AAPA0IAAgxIgdAAIAAAxIgMAAIAAhnIAMAAIAAAsIAdAAIAAgsIALAAIAABng");
  this.shape_170.setTransform(172.25, -29.375);
  this.shape_171 = new cjs.Shape();
  this.shape_171.graphics.f("#0C593C").s().p("AATA0IgHggIgXAAIgHAgIgMAAIAZhnIALAAIAZBngAAAggIgCAIIgHAgIATAAIgIggIgBgIIgBgHIAAAHg");
  this.shape_171.setTransform(164.475, -29.375);
  this.shape_172 = new cjs.Shape();
  this.shape_172.graphics.f("#0C593C").s().p("AgNA1IgKgEIAAgMQAEADAGABQAEACAGAAQAQAAAAgUQAAgKgFgFQgFgEgJAAIgJAAIAAgKIAIAAQATAAgBgUQAAgIgDgEQgEgEgFAAQgFAAgEACIgHAGIgFgJQAEgFAGgCQAGgDAGAAQALAAAFAHQAGAHABAMQAAAKgFAHQgFAGgHADIAAAAQAJABAEAGQAFAHAAAKQAAAOgHAIQgHAJgNAAIgKgBg");
  this.shape_172.setTransform(157.2, -29.375);
  this.shape_173 = new cjs.Shape();
  this.shape_173.graphics.f("#0C593C").s().p("AATA0IgHggIgXAAIgHAgIgMAAIAZhnIALAAIAZBngAAAggIgCAIIgHAgIATAAIgIggIgBgIIgBgHIAAAHg");
  this.shape_173.setTransform(150.275, -29.375);
  this.shape_174 = new cjs.Shape();
  this.shape_174.graphics.f("#0C593C").s().p("AANA0Igbg0IAAA0IgLAAIAAhnIALAAIAAAyIAagyIAMAAIgaAyIAcA1g");
  this.shape_174.setTransform(143.6, -29.375);
  this.shape_175 = new cjs.Shape();
  this.shape_175.graphics.f("#0C593C").s().p("AgRAvQgHgIgDgMQgDgMAAgPQAAgZAHgOQAJgOAOAAQALAAAHAHQAGAHAEAMQADANAAAOQAAAPgDAMQgEANgGAHQgHAHgLAAQgKAAgHgHgAgOgfQgFALAAAUQAAAVAFAKQAFALAJAAQAKAAAFgKQAEgLAAgVQAAgUgEgLQgFgKgKAAQgJAAgFAKg");
  this.shape_175.setTransform(135.3, -29.375);
  this.shape_176 = new cjs.Shape();
  this.shape_176.graphics.f("#0C593C").s().p("AAPA0IAAhcIgdAAIAABcIgLAAIAAhnIAzAAIAABng");
  this.shape_176.setTransform(126.775, -29.375);
  this.shape_177 = new cjs.Shape();
  this.shape_177.graphics.f("#0C593C").s().p("AgRAvQgGgIgEgMQgDgMAAgPQAAgZAIgOQAHgOAPAAQALAAAGAHQAIAHADAMQADANAAAOQAAAPgDAMQgDANgIAHQgGAHgLAAQgKAAgHgHgAgOgfQgFALAAAUQAAAVAFAKQAFALAJAAQAKAAAFgKQAFgLAAgVQAAgUgFgLQgFgKgKAAQgJAAgFAKg");
  this.shape_177.setTransform(118.35, -29.375);
  this.shape_178 = new cjs.Shape();
  this.shape_178.graphics.f("#0C593C").s().p("AgYA0IAAhnIAVAAQAMAAAHAGQAHAGAAANQAAAKgEAGQgDAGgHACIAAABQAIABAEAFQAEAGAAALQAAAOgHAIQgGAIgMAAgAgNApIANAAQAGAAAEgFQADgFAAgJQAAgJgEgFQgDgFgHAAIgMAAgAgNgHIALAAQAHAAADgEQADgFAAgJQAAgPgOAAIgKAAg");
  this.shape_178.setTransform(110.525, -29.375);
  this.shape_179 = new cjs.Shape();
  this.shape_179.graphics.f("#0C593C").s().p("AATA0IAAg8IAAgNIAAgLIAAAAIgiBUIgNAAIAAhnIALAAIAAA8IAAALIgBAMIABAAIAhhTIANAAIAABng");
  this.shape_179.setTransform(102.175, -29.375);
  this.shape_180 = new cjs.Shape();
  this.shape_180.graphics.f("#0C593C").s().p("AgEA0IAAhcIgUAAIAAgLIAxAAIAAALIgUAAIAABcg");
  this.shape_180.setTransform(94.6, -29.375);
  this.shape_181 = new cjs.Shape();
  this.shape_181.graphics.f("#0C593C").s().p("AgRAvQgHgIgDgMQgDgMAAgPQAAgZAIgOQAHgOAPAAQALAAAGAHQAIAHADAMQADANAAAOQAAAPgDAMQgDANgIAHQgGAHgLAAQgKAAgHgHgAgOgfQgFALAAAUQAAAVAFAKQAFALAJAAQAKAAAFgKQAFgLAAgVQAAgUgFgLQgFgKgKAAQgJAAgFAKg");
  this.shape_181.setTransform(87.2, -29.375);
  this.shape_182 = new cjs.Shape();
  this.shape_182.graphics.f("#0C593C").s().p("AgWA0IAAhnIATAAQANAAAGAIQAHAHAAAQQAAAPgHAIQgGAJgOAAIgHAAIAAAogAgLABIAGAAQAIAAAEgEQAFgFAAgMQAAgLgEgEQgEgFgIAAIgHAAg");
  this.shape_182.setTransform(79.625, -29.375);
  this.shape_183 = new cjs.Shape();
  this.shape_183.graphics.f("#0C593C").s().p("AAPA0IAAhcIgdAAIAABcIgLAAIAAhnIAzAAIAABng");
  this.shape_183.setTransform(71.625, -29.375);
  this.shape_184 = new cjs.Shape();
  this.shape_184.graphics.f("#0C593C").s().p("AAPA0IAAgrIgLAAIgQArIgNAAIAUguQgHgDgEgGQgEgHABgLQAAgeAaAAIATAAIAABngAgFgkQgEAFABAKQgBAUAPAAIAJAAIAAgnIgIAAQgHAAgFAEg");
  this.shape_184.setTransform(59.9, -29.375);
  this.shape_185 = new cjs.Shape();
  this.shape_185.graphics.f("#0C593C").s().p("AgQAnQgIgOAAgZQgBgOAEgMQADgNAIgHQAHgHAKAAQALAAAHAGIgEAKIgGgDQgDgCgFAAQgHAAgEAGQgFAGgCAKQgCAJgBALQAAAUAHALQAFALAJAAIAIgBIAIgDIAAAMQgHAEgKAAQgOAAgIgPg");
  this.shape_185.setTransform(53.2, -29.375);
  this.shape_186 = new cjs.Shape();
  this.shape_186.graphics.f("#0C593C").s().p("AgEA0IAAhcIgUAAIAAgLIAxAAIAAALIgUAAIAABcg");
  this.shape_186.setTransform(46.25, -29.375);
  this.shape_187 = new cjs.Shape();
  this.shape_187.graphics.f("#0C593C").s().p("AgIApQgHgNAAgZIgPAAIAAAxIgLAAIAAhnIALAAIAAAsIAPAAQAAgWAIgMQAHgMANAAQAOAAAHAOQAIAOAAAZQAAAPgDAMQgDANgGAHQgHAHgKAAQgNAAgIgNgAAAgeQgFAKABAUQgBAVAFAKQADALAKAAQAJAAAEgKQAFgLAAgVQAAgUgFgLQgEgKgJAAQgJAAgEALg");
  this.shape_187.setTransform(37.7, -29.375);
  this.shape_188 = new cjs.Shape();
  this.shape_188.graphics.f("#0C593C").s().p("AgTA0IAAhnIAnAAIAAALIgbAAIAAAhIAZAAIAAAKIgZAAIAAAmIAbAAIAAALg");
  this.shape_188.setTransform(28.9, -29.375);
  this.shape_189 = new cjs.Shape();
  this.shape_189.graphics.f("#0C593C").s().p("AAbA0IAAhBIAAgKIABgNIgBAAIgXBYIgIAAIgXhYIAAAAIAAANIABAKIAABBIgLAAIAAhnIAQAAIAVBUIAWhUIAQAAIAABng");
  this.shape_189.setTransform(20.25, -29.375);
  this.shape_190 = new cjs.Shape();
  this.shape_190.graphics.f("#0C593C").s().p("AATA0IAAg8IAAgNIAAgLIAAAAIgiBUIgNAAIAAhnIALAAIAAA8IAAALIgBAMIABAAIAhhTIANAAIAABng");
  this.shape_190.setTransform(10.625, -29.375);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_190
   }, {
    t: this.shape_189
   }, {
    t: this.shape_188
   }, {
    t: this.shape_187
   }, {
    t: this.shape_186
   }, {
    t: this.shape_185
   }, {
    t: this.shape_184
   }, {
    t: this.shape_183
   }, {
    t: this.shape_182
   }, {
    t: this.shape_181
   }, {
    t: this.shape_180
   }, {
    t: this.shape_179
   }, {
    t: this.shape_178
   }, {
    t: this.shape_177
   }, {
    t: this.shape_176
   }, {
    t: this.shape_175
   }, {
    t: this.shape_174
   }, {
    t: this.shape_173
   }, {
    t: this.shape_172
   }, {
    t: this.shape_171
   }, {
    t: this.shape_170
   }, {
    t: this.shape_169
   }, {
    t: this.shape_168
   }, {
    t: this.shape_167
   }, {
    t: this.shape_166
   }, {
    t: this.shape_165
   }, {
    t: this.shape_164
   }, {
    t: this.shape_163
   }, {
    t: this.shape_162
   }, {
    t: this.shape_161
   }, {
    t: this.shape_160
   }, {
    t: this.shape_159
   }, {
    t: this.shape_158
   }, {
    t: this.shape_157
   }, {
    t: this.shape_156
   }, {
    t: this.shape_155
   }, {
    t: this.shape_154
   }, {
    t: this.shape_153
   }, {
    t: this.shape_152
   }, {
    t: this.shape_151
   }, {
    t: this.shape_150
   }, {
    t: this.shape_149
   }, {
    t: this.shape_148
   }, {
    t: this.shape_147
   }, {
    t: this.shape_146
   }, {
    t: this.shape_145
   }, {
    t: this.shape_144
   }, {
    t: this.shape_143
   }, {
    t: this.shape_142
   }, {
    t: this.shape_141
   }, {
    t: this.shape_140
   }, {
    t: this.shape_139
   }, {
    t: this.shape_138
   }, {
    t: this.shape_137
   }, {
    t: this.shape_136
   }, {
    t: this.shape_135
   }, {
    t: this.shape_134
   }, {
    t: this.shape_133
   }, {
    t: this.shape_132
   }, {
    t: this.shape_131
   }, {
    t: this.shape_130
   }, {
    t: this.shape_129
   }, {
    t: this.shape_128
   }, {
    t: this.shape_127
   }, {
    t: this.shape_126
   }, {
    t: this.shape_125
   }, {
    t: this.shape_124
   }, {
    t: this.shape_123
   }, {
    t: this.shape_122
   }, {
    t: this.shape_121
   }, {
    t: this.shape_120
   }, {
    t: this.shape_119
   }, {
    t: this.shape_118
   }, {
    t: this.shape_117
   }, {
    t: this.shape_116
   }, {
    t: this.shape_115
   }, {
    t: this.shape_114
   }, {
    t: this.shape_113
   }, {
    t: this.shape_112
   }, {
    t: this.shape_111
   }, {
    t: this.shape_110
   }, {
    t: this.shape_109
   }, {
    t: this.shape_108
   }, {
    t: this.shape_107
   }, {
    t: this.shape_106
   }, {
    t: this.shape_105
   }, {
    t: this.shape_104
   }, {
    t: this.shape_103
   }, {
    t: this.shape_102
   }, {
    t: this.shape_101
   }, {
    t: this.shape_100
   }, {
    t: this.shape_99
   }, {
    t: this.shape_98
   }, {
    t: this.shape_97
   }, {
    t: this.shape_96
   }, {
    t: this.shape_95
   }, {
    t: this.shape_94
   }, {
    t: this.shape_93
   }, {
    t: this.shape_92
   }, {
    t: this.shape_91
   }, {
    t: this.shape_90
   }, {
    t: this.shape_89
   }, {
    t: this.shape_88
   }, {
    t: this.shape_87
   }, {
    t: this.shape_86
   }, {
    t: this.shape_85
   }, {
    t: this.shape_84
   }, {
    t: this.shape_83
   }, {
    t: this.shape_82
   }, {
    t: this.shape_81
   }, {
    t: this.shape_80
   }, {
    t: this.shape_79
   }, {
    t: this.shape_78
   }, {
    t: this.shape_77
   }, {
    t: this.shape_76
   }, {
    t: this.shape_75
   }, {
    t: this.shape_74
   }, {
    t: this.shape_73
   }, {
    t: this.shape_72
   }, {
    t: this.shape_71
   }, {
    t: this.shape_70
   }, {
    t: this.shape_69
   }, {
    t: this.shape_68
   }, {
    t: this.shape_67
   }, {
    t: this.shape_66
   }, {
    t: this.shape_65
   }, {
    t: this.shape_64
   }, {
    t: this.shape_63
   }, {
    t: this.shape_62
   }, {
    t: this.shape_61
   }, {
    t: this.shape_60
   }, {
    t: this.shape_59
   }, {
    t: this.shape_58
   }, {
    t: this.shape_57
   }, {
    t: this.shape_56
   }, {
    t: this.shape_55
   }, {
    t: this.shape_54
   }, {
    t: this.shape_53
   }, {
    t: this.shape_52
   }, {
    t: this.shape_51
   }, {
    t: this.shape_50
   }, {
    t: this.shape_49
   }, {
    t: this.shape_48
   }, {
    t: this.shape_47
   }, {
    t: this.shape_46
   }, {
    t: this.shape_45
   }, {
    t: this.shape_44
   }, {
    t: this.shape_43
   }, {
    t: this.shape_42
   }, {
    t: this.shape_41
   }, {
    t: this.shape_40
   }, {
    t: this.shape_39
   }, {
    t: this.shape_38
   }, {
    t: this.shape_37
   }, {
    t: this.shape_36
   }, {
    t: this.shape_35
   }, {
    t: this.shape_34
   }, {
    t: this.shape_33
   }, {
    t: this.shape_32
   }, {
    t: this.shape_31
   }, {
    t: this.shape_30
   }, {
    t: this.shape_29
   }, {
    t: this.shape_28
   }, {
    t: this.shape_27
   }, {
    t: this.shape_26
   }, {
    t: this.shape_25
   }, {
    t: this.shape_24
   }, {
    t: this.shape_23
   }, {
    t: this.shape_22
   }, {
    t: this.shape_21
   }, {
    t: this.shape_20
   }, {
    t: this.shape_19
   }, {
    t: this.shape_18
   }, {
    t: this.shape_17
   }, {
    t: this.shape_16
   }, {
    t: this.shape_15
   }, {
    t: this.shape_14
   }, {
    t: this.shape_13
   }, {
    t: this.shape_12
   }, {
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
 }).prototype = getMCSymbolPrototype(lib.l3, new cjs.Rectangle(-1, -82, 340, 86.5), null);
 (lib.l2 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#0C593C").s().p("AgFAHIAAgNIALAAIAAANg");
  this.shape.setTransform(309.725, -4.975);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#0C593C").s().p("AAXAlIAAhAIgUBAIgGAAIgThAIAABAIgKAAIAAhJIARAAIANAwIACAPIADgPIANgwIARAAIAABJg");
  this.shape_1.setTransform(303.825, -8.05);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#0C593C").s().p("AgLAkQgGgEgDgIQgDgJAAgPQAAgmAXAAQALAAAFAFQAFAGABAJQACAIAAALIgjAAIAAAQQABAGADAEQADADAFAAQAMABAAgTIALAAQAAAIgDAGQgCAGgFAEQgFADgIAAQgHAAgFgDgAgJgXQgCAGAAAKIAYAAQAAgKgDgHQgCgFgHAAQgHgBgDAHg");
  this.shape_2.setTransform(296.575, -8.05);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#0C593C").s().p("AAOAlIAAg3IABgJIgCAJIgYA3IgNAAIAAhJIALAAIAAA3IgBAJIACgJIAYg3IANAAIAABJg");
  this.shape_3.setTransform(290.275, -8.05);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#0C593C").s().p("AANAlIAAgjIgZAAIAAAjIgLAAIAAhJIALAAIAAAeIAZAAIAAgeIALAAIAABJg");
  this.shape_4.setTransform(283.525, -8.05);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#0C593C").s().p("AgZATQAAgGACgFQACgEAEgDIALgEIAMgGQADgBAAgIQAAgGgDgDQgCgCgGAAQgFgBgDAEQgCADAAAHIgKAAQAAgWAVAAQAHAAAFACQAEADACAEQADAFAAAFIAAArQAAAGADAAIADgBIAAAIIgEABQgFAAgDgCQgDgBgBgIQgCAFgEAEQgEADgFAAQgUAAAAgUgAABAAIgIAFIgFAFQgCAEAAAEQAAAMAKAAQAGAAAEgEIABgDIABgEIABgHIAAgOIgIACg");
  this.shape_5.setTransform(277.2, -8.05);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#0C593C").s().p("AgWAlIAAhJIAYAAQAIAAAFAEQAHAFAAAJQgBAGgDAFQgDAFgFACQAGAAAEAFQADAEAAAIQAAAGgCAFQgDAEgEADQgFADgEgBgAgMAdIAMAAQAHAAADgDQACgEABgGQAAgHgDgDQgDgDgGAAIgNAAgAgMgFIAMAAQAFAAADgDQADgCAAgHQAAgLgLABIgMAAg");
  this.shape_6.setTransform(271.35, -8.05);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#0C593C").s().p("AgOAkQgFgEgEgIQgDgJAAgPQAAgSAHgKQAGgKANAAQAbAAAAAmQAAAPgEAJQgDAIgGAEQgGADgIAAQgIAAgGgDgAgIgaQgEADgBAGQgCAIAAAKQAAAJACAHQABAGADAEQAEADAFAAQAGAAADgDQAEgEABgGQACgHAAgJQAAgKgCgIQgCgGgDgDQgDgEgGABQgFgBgDAEg");
  this.shape_7.setTransform(264.775, -8.05);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#0C593C").s().p("AgLAkQgGgCgCgGQgDgFgBgJIAKAAQAAAHACADQABADADACQAEABADAAQAOAAAAgNQAAgHgEgDQgDgEgGAAIgFAAIAAgIIAEAAQAGAAACgEQADgDAAgGQAAgEgDgEQgCgEgGABQgFgBgEAEQgDAEAAAFIgKAAQABgFACgFQADgGAGgDQAEgCAGAAQAGAAAFACQAGADACAEQADAFAAAFQAAAHgEAEQgDAFgGACQAGABAEAEQAFAFAAAIQAAAHgDAFQgCAFgGACQgFADgIAAQgGAAgFgDg");
  this.shape_8.setTransform(258.45, -8.05);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#0C593C").s().p("AgZATQAAgGACgFQACgEAEgDIALgEIAMgGQADgBAAgIQAAgGgCgDQgDgCgGAAQgFgBgDAEQgDADABAHIgKAAQAAgWAVAAQAHAAAEACQAFADACAEQACAFAAAFIAAArQABAGAEAAIACgBIAAAIIgEABQgFAAgDgCQgDgBgBgIQgCAFgEAEQgFADgEAAQgUAAAAgUgAAAAAIgHAFIgFAFQgCAEAAAEQAAAMAKAAQAGAAAEgEIABgDIABgEIABgHIAAgOIgJACg");
  this.shape_9.setTransform(252.7, -8.05);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.f("#0C593C").s().p("AgYAzIAAhjIAKAAIAAAIQADgFAEgCQAEgDAEAAQAZAAgBAmQABAJgCAGQgBAIgCAFQgEAGgEADQgFADgGAAQgFAAgDgDQgFgCgCgFIAAAhgAgLghQgDAJABANIAAAPQABAGADAEQAEAFAFAAQAIAAADgIQADgIAAgPQAAgdgOAAQgIAAgDAIg");
  this.shape_10.setTransform(246.5, -6.875);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.f("#0C593C").s().p("AgPAvQgGgGgCgJQgDgKAAgPQAAgMACgIQABgJADgGQAEgFAEgEQAEgDAGgCIAMgEQAEgCAAgDIAJAAQgCAHgFAEQgFAEgJACQgHABgFAHQgFAFAAAKQAGgMALAAQAHABAGAEQAGAEADAIQADAHAAALQAAANgDAJQgDAJgGAEQgGAFgJgBQgJAAgGgEgAgLgGQgEAGAAAMQAAAKACAHQABAHAEADQADADAFAAQAIABAEgIQAEgHAAgQQAAgLgEgHQgEgHgIgBQgHABgEAHg");
  this.shape_11.setTransform(239.825, -9.25);
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.f("#0C593C").s().p("AgOAkQgFgEgEgIQgDgJAAgPQAAgSAHgKQAGgKANAAQAbAAAAAmQAAAPgEAJQgDAIgGAEQgGADgIAAQgIAAgGgDgAgIgaQgEADgBAGQgCAIAAAKQAAAJACAHQABAGADAEQAEADAFAAQAGAAADgDQAEgEABgGQACgHAAgJQAAgKgCgIQgCgGgDgDQgDgEgGABQgFgBgDAEg");
  this.shape_12.setTransform(233.425, -8.05);
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.f("#0C593C").s().p("AgOAkQgFgEgEgIQgDgJAAgPQAAgSAHgKQAGgKANAAQAbAAAAAmQAAAPgEAJQgDAIgGAEQgGADgIAAQgIAAgGgDgAgIgaQgEADgBAGQgCAIAAAKQAAAJACAHQABAGADAEQAEADAFAAQAGAAADgDQAEgEABgGQACgHAAgJQAAgKgCgIQgCgGgDgDQgDgEgGABQgFgBgDAEg");
  this.shape_13.setTransform(226.725, -8.05);
  this.shape_14 = new cjs.Shape();
  this.shape_14.graphics.f("#0C593C").s().p("AgMAkQgEgCgEgGQgDgFAAgJIAKAAQAAAHACADQABADAEACQADABADAAQAOAAAAgNQgBgHgDgDQgEgEgFAAIgFAAIAAgIIAEAAQAGAAACgEQAEgDAAgGQAAgEgEgEQgCgEgGABQgFgBgEAEQgDAEAAAFIgKAAQAAgFADgFQADgGAFgDQAFgCAGAAQAGAAAGACQAFADACAEQADAFAAAFQAAAHgEAEQgDAFgGACQAGABAFAEQAEAFAAAIQAAAHgDAFQgCAFgGACQgFADgIAAQgHAAgFgDg");
  this.shape_14.setTransform(220.4, -8.05);
  this.shape_15 = new cjs.Shape();
  this.shape_15.graphics.f("#0C593C").s().p("AgZATQAAgGACgFQACgEAEgDIALgEIAMgGQADgBAAgIQAAgGgDgDQgCgCgGAAQgFgBgDAEQgCADAAAHIgKAAQAAgWAVAAQAHAAAFACQAEADACAEQADAFAAAFIAAArQAAAGADAAIADgBIAAAIIgEABQgFAAgDgCQgDgBgBgIQgCAFgEAEQgEADgFAAQgUAAAAgUgAABAAIgIAFIgFAFQgCAEAAAEQAAAMAKAAQAGAAAEgEIABgDIABgEIABgHIAAgOIgIACg");
  this.shape_15.setTransform(214.65, -8.05);
  this.shape_16 = new cjs.Shape();
  this.shape_16.graphics.f("#0C593C").s().p("AgTAlIAAhJIAnAAIAAAJIgcAAIAABAg");
  this.shape_16.setTransform(209.675, -8.05);
  this.shape_17 = new cjs.Shape();
  this.shape_17.graphics.f("#0C593C").s().p("AAXAlIAAhAIgUBAIgGAAIgThAIAABAIgKAAIAAhJIARAAIANAwIACAPIADgPIANgwIARAAIAABJg");
  this.shape_17.setTransform(199.125, -8.05);
  this.shape_18 = new cjs.Shape();
  this.shape_18.graphics.f("#0C593C").s().p("AAYAlIAAhJIAKAAIAABJgAgiAlIAAhJIALAAIAAAfIAPAAQAHAAADADQAEACADAFQADAFAAAGQAAAHgDAEQgDAFgEADQgEADgGgBgAgXAdIAMAAQAGAAAEgDQACgDAAgHQAAgNgMAAIgMAAg");
  this.shape_18.setTransform(190.5, -8.05);
  this.shape_19 = new cjs.Shape();
  this.shape_19.graphics.f("#0C593C").s().p("AANAlIAAgjIgZAAIAAAjIgLAAIAAhJIALAAIAAAeIAZAAIAAgeIALAAIAABJg");
  this.shape_19.setTransform(182.775, -8.05);
  this.shape_20 = new cjs.Shape();
  this.shape_20.graphics.f("#0C593C").s().p("AANAlIAAgjIgZAAIAAAjIgLAAIAAhJIALAAIAAAeIAZAAIAAgeIALAAIAABJg");
  this.shape_20.setTransform(176.075, -8.05);
  this.shape_21 = new cjs.Shape();
  this.shape_21.graphics.f("#0C593C").s().p("AgLAkQgGgEgDgIQgDgJAAgPQAAgmAXAAQALAAAFAFQAFAGABAJQACAIAAALIgjAAIAAAQQABAGADAEQADADAFAAQAMABAAgTIALAAQAAAIgDAGQgCAGgFAEQgFADgIAAQgHAAgFgDgAgJgXQgCAGAAAKIAYAAQAAgKgDgHQgCgFgHAAQgHgBgDAHg");
  this.shape_21.setTransform(169.675, -8.05);
  this.shape_22 = new cjs.Shape();
  this.shape_22.graphics.f("#0C593C").s().p("AgoAlIAAhJIALAAIAABAIAYAAIAAhAIAKAAIAABAIAYAAIAAhAIALAAIAABJg");
  this.shape_22.setTransform(161.75, -8.05);
  this.shape_23 = new cjs.Shape();
  this.shape_23.graphics.f("#0C593C").s().p("AAYAlIAAhJIALAAIAABJgAghAlIAAhJIAKAAIAAAfIAQAAQAFAAAEADQAFACADAFQACAFAAAGQAAAHgCAEQgDAFgFADQgEADgFgBgAgXAdIALAAQAIAAADgDQACgDAAgHQAAgNgMAAIgMAAg");
  this.shape_23.setTransform(152.3, -8.05);
  this.shape_24 = new cjs.Shape();
  this.shape_24.graphics.f("#0C593C").s().p("AgWAlIAAhJIAXAAQAJAAAGAEQAFAFABAJQAAAGgEAFQgDAFgFACQAGAAADAFQAEAEAAAIQAAAGgDAFQgCAEgEADQgEADgFgBgAgLAdIALAAQAHAAADgDQADgEAAgGQgBgHgDgDQgDgDgFAAIgMAAgAgLgFIALAAQAFAAADgDQACgCAAgHQAAgLgKABIgLAAg");
  this.shape_24.setTransform(145.05, -8.05);
  this.shape_25 = new cjs.Shape();
  this.shape_25.graphics.f("#0C593C").s().p("AgOAkQgFgEgEgIQgDgJAAgPQAAgSAHgKQAGgKANAAQAbAAAAAmQAAAPgEAJQgDAIgGAEQgGADgIAAQgIAAgGgDgAgIgaQgEADgBAGQgCAIAAAKQAAAJACAHQABAGADAEQAEADAFAAQAGAAADgDQAEgEABgGQACgHAAgJQAAgKgCgIQgCgGgDgDQgDgEgGABQgFgBgDAEg");
  this.shape_25.setTransform(138.475, -8.05);
  this.shape_26 = new cjs.Shape();
  this.shape_26.graphics.f("#0C593C").s().p("AANAlIAAhAIgZAAIAABAIgLAAIAAhJIAvAAIAABJg");
  this.shape_26.setTransform(131.775, -8.05);
  this.shape_27 = new cjs.Shape();
  this.shape_27.graphics.f("#0C593C").s().p("AAOAxIAAg3IABgJIgCAJIgYA3IgNAAIAAhJIALAAIAAA3IgBAJIACgJIAYg3IANAAIAABJgAgLgkQgEgEgBgJIAGAAQACAKAIAAQAFAAADgCQADgDABgFIAFAAQAAAJgFAEQgFAEgHAAQgGAAgFgEg");
  this.shape_27.setTransform(121.675, -9.25);
  this.shape_28 = new cjs.Shape();
  this.shape_28.graphics.f("#0C593C").s().p("AgOAkQgFgEgEgIQgDgJAAgPQAAgSAHgKQAGgKANAAQAbAAAAAmQAAAPgEAJQgDAIgGAEQgGADgIAAQgIAAgGgDgAgIgaQgEADgBAGQgCAIAAAKQAAAJACAHQABAGADAEQAEADAFAAQAGAAADgDQAEgEABgGQACgHAAgJQAAgKgCgIQgCgGgDgDQgDgEgGABQgFgBgDAEg");
  this.shape_28.setTransform(114.925, -8.05);
  this.shape_29 = new cjs.Shape();
  this.shape_29.graphics.f("#0C593C").s().p("AANAlIAAgjIgZAAIAAAjIgLAAIAAhJIALAAIAAAeIAZAAIAAgeIALAAIAABJg");
  this.shape_29.setTransform(108.225, -8.05);
  this.shape_30 = new cjs.Shape();
  this.shape_30.graphics.f("#0C593C").s().p("AANAlIAAgjIgZAAIAAAjIgLAAIAAhJIALAAIAAAeIAZAAIAAgeIALAAIAABJg");
  this.shape_30.setTransform(101.525, -8.05);
  this.shape_31 = new cjs.Shape();
  this.shape_31.graphics.f("#0C593C").s().p("AgZATQAAgGACgFQACgEAEgDIALgEIAMgGQADgBAAgIQAAgGgDgDQgCgCgGAAQgFgBgDAEQgDADABAHIgKAAQAAgWAVAAQAHAAAEACQAFADACAEQACAFAAAFIAAArQABAGAEAAIACgBIAAAIIgEABQgFAAgDgCQgDgBgBgIQgCAFgEAEQgFADgEAAQgUAAAAgUgAAAAAIgHAFIgFAFQgCAEAAAEQAAAMAKAAQAGAAAEgEIABgDIABgEIABgHIAAgOIgJACg");
  this.shape_31.setTransform(95.2, -8.05);
  this.shape_32 = new cjs.Shape();
  this.shape_32.graphics.f("#0C593C").s().p("AgWAlIAAhJIAXAAQAJAAAGAEQAFAFABAJQAAAGgEAFQgDAFgFACQAGAAADAFQAEAEAAAIQAAAGgCAFQgDAEgEADQgEADgFgBgAgLAdIALAAQAHAAADgDQADgEAAgGQAAgHgEgDQgDgDgFAAIgMAAgAgLgFIALAAQAFAAADgDQACgCAAgHQAAgLgKABIgLAAg");
  this.shape_32.setTransform(89.35, -8.05);
  this.shape_33 = new cjs.Shape();
  this.shape_33.graphics.f("#0C593C").s().p("AgLAkQgFgCgEgGQgDgFAAgJIAKAAQAAAHACADQABADAEACQADABADAAQAOAAAAgNQgBgHgDgDQgEgEgFAAIgFAAIAAgIIAEAAQAGAAACgEQAEgDAAgGQAAgEgEgEQgCgEgGABQgFgBgEAEQgDAEAAAFIgKAAQAAgFADgFQADgGAFgDQAFgCAGAAQAGAAAGACQAFADACAEQADAFAAAFQAAAHgEAEQgDAFgGACQAGABAFAEQAEAFAAAIQAAAHgDAFQgCAFgGACQgFADgIAAQgHAAgEgDg");
  this.shape_33.setTransform(83.15, -8.05);
  this.shape_34 = new cjs.Shape();
  this.shape_34.graphics.f("#0C593C").s().p("AAYAlIAAhJIAKAAIAABJgAghAlIAAhJIAKAAIAAAfIAPAAQAHAAADADQAEACADAFQADAFAAAGQAAAHgDAEQgDAFgEADQgEADgGgBgAgXAdIALAAQAHAAAEgDQACgDAAgHQAAgNgMAAIgMAAg");
  this.shape_34.setTransform(75.95, -8.05);
  this.shape_35 = new cjs.Shape();
  this.shape_35.graphics.f("#0C593C").s().p("AgWAlIAAhJIAXAAQAJAAAGAEQAFAFAAAJQABAGgEAFQgDAFgFACQAGAAAEAFQADAEAAAIQAAAGgDAFQgCAEgEADQgEADgFgBgAgMAdIAMAAQAHAAADgDQADgEgBgGQAAgHgCgDQgDgDgGAAIgNAAgAgMgFIAMAAQAFAAADgDQACgCAAgHQABgLgLABIgMAAg");
  this.shape_35.setTransform(68.7, -8.05);
  this.shape_36 = new cjs.Shape();
  this.shape_36.graphics.f("#0C593C").s().p("AgFAKQAGgBAAgLIgGAAIAAgOIALAAIAAAQQAAAFgDAFQgDAFgFACg");
  this.shape_36.setTransform(60.425, -4);
  this.shape_37 = new cjs.Shape();
  this.shape_37.graphics.f("#0C593C").s().p("AAOAlIAAg3IABgJIgCAJIgYA3IgNAAIAAhJIALAAIAAA3IgBAJIACgJIAYg3IANAAIAABJg");
  this.shape_37.setTransform(55.375, -8.05);
  this.shape_38 = new cjs.Shape();
  this.shape_38.graphics.f("#0C593C").s().p("AgbAlIAAgIIAEAAQADAAACgCQACgCABgHIAAgSIAAglIArAAIAABKIgKAAIAAhBIgWAAIAAAdQAAASgEAJQgDAKgKAAIgGgBg");
  this.shape_38.setTransform(48.225, -8.025);
  this.shape_39 = new cjs.Shape();
  this.shape_39.graphics.f("#0C593C").s().p("AgOAkQgFgEgEgIQgDgJAAgPQAAgSAHgKQAGgKANAAQAbAAAAAmQAAAPgEAJQgDAIgGAEQgGADgIAAQgIAAgGgDgAgIgaQgEADgBAGQgCAIAAAKQAAAJACAHQABAGADAEQAEADAFAAQAGAAADgDQAEgEABgGQACgHAAgJQAAgKgCgIQgCgGgDgDQgDgEgGABQgFgBgDAEg");
  this.shape_39.setTransform(41.925, -8.05);
  this.shape_40 = new cjs.Shape();
  this.shape_40.graphics.f("#0C593C").s().p("AgcAyIAAhkIAyAAIAAALIgmAAIAAAhIANAAQAGgBAHACQAFACAFACQAEADADAGQACAFAAAJQgBAPgHAGQgJAIgNgBgAgQAoIAMAAQALAAAFgDQAFgFAAgKQAAgIgDgEQgDgEgFgCQgFgCgHABIgKAAg");
  this.shape_40.setTransform(35.2, -9.35);
  this.shape_41 = new cjs.Shape();
  this.shape_41.graphics.f("#0C593C").s().p("AAAAGIgJANIgGgEIAKgMIgPgFIACgGIAQAGIAAgRIAGAAIAAAQIAOgFIADAGIgQAEIALANIgGAFg");
  this.shape_41.setTransform(27.975, -12.4);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_41
   }, {
    t: this.shape_40
   }, {
    t: this.shape_39
   }, {
    t: this.shape_38
   }, {
    t: this.shape_37
   }, {
    t: this.shape_36
   }, {
    t: this.shape_35
   }, {
    t: this.shape_34
   }, {
    t: this.shape_33
   }, {
    t: this.shape_32
   }, {
    t: this.shape_31
   }, {
    t: this.shape_30
   }, {
    t: this.shape_29
   }, {
    t: this.shape_28
   }, {
    t: this.shape_27
   }, {
    t: this.shape_26
   }, {
    t: this.shape_25
   }, {
    t: this.shape_24
   }, {
    t: this.shape_23
   }, {
    t: this.shape_22
   }, {
    t: this.shape_21
   }, {
    t: this.shape_20
   }, {
    t: this.shape_19
   }, {
    t: this.shape_18
   }, {
    t: this.shape_17
   }, {
    t: this.shape_16
   }, {
    t: this.shape_15
   }, {
    t: this.shape_14
   }, {
    t: this.shape_13
   }, {
    t: this.shape_12
   }, {
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
 }).prototype = getMCSymbolPrototype(lib.l2, new cjs.Rectangle(-1, -19, 338, 19.6), null);
 (lib.l1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#0C593C").s().p("AAOAmIAAg4IABgKIgCAKIgYA4IgNAAIAAhLIALAAIAAA5IgBAJIACgJIAYg5IANAAIAABLg");
  this.shape.setTransform(230.475, -9.45);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#0C593C").s().p("AgbAlIAAgIIAEAAQADAAACgCQACgCABgHIAAgSIAAglIArAAIAABKIgKAAIAAhBIgWAAIAAAdQAAASgEAJQgDAKgKAAIgGgBg");
  this.shape_1.setTransform(223.325, -9.425);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#0C593C").s().p("AgOAkQgFgEgEgJQgDgJAAgOQAAgSAHgLQAGgKANAAQAbAAAAAnQAAAPgEAIQgDAJgGAEQgGADgIABQgIgBgGgDgAgIgaQgEADgBAHQgCAGAAALQAAAJACAHQABAGADAEQAEADAFABQAGgBADgDQAEgEABgGQACgHAAgJQAAgLgCgGQgCgHgDgDQgDgDgGgBQgFABgDADg");
  this.shape_2.setTransform(217.025, -9.45);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#0C593C").s().p("AgPAuQgGgEgCgKQgDgKAAgPQAAgLACgJQABgJADgGQAEgFAEgEQAEgEAGgBIAMgEQAEgBAAgEIAJAAQgCAIgFADQgFAEgJACQgHACgFAFQgFAHAAAJQAGgMALABQAHgBAGAFQAGAEADAIQADAHAAALQAAANgDAJQgDAJgGAEQgGAEgJABQgJAAgGgGgAgLgGQgEAGAAAMQAAAKACAHQABAHAEADQADADAFABQAIgBAEgHQAEgIAAgPQAAgMgEgGQgEgIgIABQgHgBgEAIg");
  this.shape_3.setTransform(210.475, -10.65);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#0C593C").s().p("AAOAmIAAg4IABgKIgCAKIgYA4IgNAAIAAhLIALAAIAAA5IgBAJIACgJIAYg5IANAAIAABLg");
  this.shape_4.setTransform(200.675, -9.45);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#0C593C").s().p("AAOAmIAAg4IABgKIgCAKIgYA4IgNAAIAAhLIALAAIAAA5IgBAJIACgJIAYg5IANAAIAABLg");
  this.shape_5.setTransform(190.525, -9.45);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#0C593C").s().p("AAOAmIAAg4IABgKIgCAKIgYA4IgNAAIAAhLIALAAIAAA5IgBAJIACgJIAYg5IANAAIAABLg");
  this.shape_6.setTransform(183.725, -9.45);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#0C593C").s().p("AANAmIAAgjIgZAAIAAAjIgLAAIAAhLIALAAIAAAgIAZAAIAAggIALAAIAABLg");
  this.shape_7.setTransform(176.975, -9.45);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#0C593C").s().p("AgZATQAAgGACgFQACgEAEgDIALgFIAMgFQADgBAAgIQAAgGgDgDQgCgDgGAAQgFABgDADQgCAEgBAGIgJAAQAAgXAVAAQAHAAAFADQAEADADAEQACAEAAAGIAAArQAAAGADAAIADAAIAAAIIgEABQgFAAgDgCQgDgDgBgGQgCAFgFADQgDADgFABQgUAAAAgVgAABABIgIAEIgFAFQgCADAAAGQAAALAKAAQAGAAAEgFIABgCIACgEIAAgHIAAgPIgIAEg");
  this.shape_8.setTransform(170.65, -9.45);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#0C593C").s().p("AgWAmIAAhLIAYAAQAIABAFAFQAHAFgBAHQAAAIgDAEQgDAFgFABQAGABAEAFQADAEAAAIQAAAGgCAFQgDAEgEADQgFADgEAAgAgMAdIAMAAQAHAAADgEQACgCABgIQAAgFgDgEQgEgDgFAAIgNAAgAgMgFIAMAAQAFAAADgCQACgEABgFQgBgMgKAAIgMAAg");
  this.shape_9.setTransform(164.8, -9.45);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.f("#0C593C").s().p("AgOAkQgFgEgEgJQgDgJAAgOQAAgSAHgLQAGgKANAAQAbAAAAAnQAAAPgEAIQgDAJgGAEQgGADgIABQgIgBgGgDgAgIgaQgEADgBAHQgCAGAAALQAAAJACAHQABAGADAEQAEADAFABQAGgBADgDQAEgEABgGQACgHAAgJQAAgLgCgGQgCgHgDgDQgDgDgGgBQgFABgDADg");
  this.shape_10.setTransform(158.225, -9.45);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.f("#0C593C").s().p("AgLAlQgFgDgEgFQgCgHgBgIIAKAAQAAAGACAEQACADACACQADABAEABQAOgBAAgOQgBgFgDgFQgEgDgFAAIgFAAIAAgIIAEAAQAGAAACgEQADgDABgGQgBgFgDgDQgCgDgGgBQgGABgDADQgDAEAAAGIgKAAQAAgGADgFQADgGAFgDQAFgDAGAAQAGABAGACQAFACACAFQADAFAAAEQAAAIgEAFQgDAEgGACQAGABAEAEQAFAFAAAIQAAAHgDAFQgCAFgGADQgFADgIAAQgGAAgFgDg");
  this.shape_11.setTransform(151.9, -9.45);
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.f("#0C593C").s().p("AgZATQAAgGACgFQACgEAEgDIALgFIAMgFQADgBAAgIQAAgGgDgDQgCgDgGAAQgFABgDADQgDAEABAGIgKAAQAAgXAVAAQAHAAAFADQAEADACAEQACAEABAGIAAArQAAAGADAAIADAAIAAAIIgEABQgFAAgDgCQgDgDgBgGQgCAFgEADQgFADgEABQgUAAAAgVgAAAABIgHAEIgFAFQgCADAAAGQAAALAKAAQAGAAAEgFIABgCIABgEIABgHIAAgPIgJAEg");
  this.shape_12.setTransform(146.15, -9.45);
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.f("#0C593C").s().p("AgYAzIAAhjIAKAAIAAAIQADgFAEgCQAEgDAEAAQAYAAAAAmQAAAJgBAGQgBAIgCAFQgDAGgFADQgFADgGAAQgFAAgDgDQgFgCgCgFIAAAhgAgLghQgDAJABANIAAAPQABAGADAEQADAFAGAAQAIAAADgIQADgIAAgPQAAgdgOAAQgIAAgDAIg");
  this.shape_13.setTransform(139.95, -8.275);
  this.shape_14 = new cjs.Shape();
  this.shape_14.graphics.f("#0C593C").s().p("AgPAuQgGgEgCgKQgDgKAAgPQAAgLACgJQABgJADgGQAEgFAEgEQAEgEAGgBIAMgEQAEgBAAgEIAJAAQgCAIgFADQgFAEgJACQgHACgFAFQgFAHAAAJQAGgMALABQAHgBAGAFQAGAEADAIQADAHAAALQAAANgDAJQgDAJgGAEQgGAEgJABQgJAAgGgGgAgLgGQgEAGAAAMQAAAKACAHQABAHAEADQADADAFABQAIgBAEgHQAEgIAAgPQAAgMgEgGQgEgIgIABQgHgBgEAIg");
  this.shape_14.setTransform(133.275, -10.65);
  this.shape_15 = new cjs.Shape();
  this.shape_15.graphics.f("#0C593C").s().p("AgOAkQgFgEgEgJQgDgJAAgOQAAgSAHgLQAGgKANAAQAbAAAAAnQAAAPgEAIQgDAJgGAEQgGADgIABQgIgBgGgDgAgIgaQgEADgBAHQgCAGAAALQAAAJACAHQABAGADAEQAEADAFABQAGgBADgDQAEgEABgGQACgHAAgJQAAgLgCgGQgCgHgDgDQgDgDgGgBQgFABgDADg");
  this.shape_15.setTransform(126.875, -9.45);
  this.shape_16 = new cjs.Shape();
  this.shape_16.graphics.f("#0C593C").s().p("AgOAkQgFgEgEgJQgDgJAAgOQAAgSAHgLQAGgKANAAQAbAAAAAnQAAAPgEAIQgDAJgGAEQgGADgIABQgIgBgGgDgAgIgaQgEADgBAHQgCAGAAALQAAAJACAHQABAGADAEQAEADAFABQAGgBADgDQAEgEABgGQACgHAAgJQAAgLgCgGQgCgHgDgDQgDgDgGgBQgFABgDADg");
  this.shape_16.setTransform(120.175, -9.45);
  this.shape_17 = new cjs.Shape();
  this.shape_17.graphics.f("#0C593C").s().p("AgMAlQgFgDgDgFQgDgHAAgIIAKAAQABAGABAEQABADAEACQADABADABQANgBAAgOQAAgFgDgFQgDgDgGAAIgFAAIAAgIIAFAAQAEAAADgEQAEgDAAgGQAAgFgEgDQgCgDgGgBQgFABgEADQgCAEgBAGIgKAAQAAgGADgFQADgGAFgDQAGgDAFAAQAGABAGACQAEACADAFQADAFAAAEQAAAIgDAFQgEAEgGACQAGABAFAEQAEAFAAAIQAAAHgDAFQgCAFgGADQgGADgGAAQgIAAgFgDg");
  this.shape_17.setTransform(113.85, -9.45);
  this.shape_18 = new cjs.Shape();
  this.shape_18.graphics.f("#0C593C").s().p("AgZATQAAgGACgFQACgEAEgDIALgFIAMgFQADgBAAgIQAAgGgDgDQgCgDgGAAQgFABgDADQgCAEgBAGIgJAAQAAgXAVAAQAHAAAFADQAEADADAEQACAEAAAGIAAArQAAAGADAAIADAAIAAAIIgEABQgFAAgDgCQgDgDgBgGQgCAFgFADQgDADgFABQgUAAAAgVgAABABIgIAEIgFAFQgCADAAAGQAAALAKAAQAGAAAEgFIABgCIACgEIAAgHIAAgPIgIAEg");
  this.shape_18.setTransform(108.1, -9.45);
  this.shape_19 = new cjs.Shape();
  this.shape_19.graphics.f("#0C593C").s().p("AgTAmIAAhLIAnAAIAAAJIgcAAIAABCg");
  this.shape_19.setTransform(103.125, -9.45);
  this.shape_20 = new cjs.Shape();
  this.shape_20.graphics.f("#0C593C").s().p("AgFALQAGgCAAgLIgGAAIAAgNIALAAIAAAPQAAAGgDAEQgDAFgFABg");
  this.shape_20.setTransform(289.825, -17);
  this.shape_21 = new cjs.Shape();
  this.shape_21.graphics.f("#0C593C").s().p("AAOAmIAAg4IABgKIgCAKIgYA4IgNAAIAAhLIALAAIAAA5IgBAJIACgJIAYg5IANAAIAABLg");
  this.shape_21.setTransform(284.775, -21.05);
  this.shape_22 = new cjs.Shape();
  this.shape_22.graphics.f("#0C593C").s().p("AAOAmIAAg4IABgKIgCAKIgYA4IgNAAIAAhLIALAAIAAA5IgBAJIACgJIAYg5IANAAIAABLg");
  this.shape_22.setTransform(277.975, -21.05);
  this.shape_23 = new cjs.Shape();
  this.shape_23.graphics.f("#0C593C").s().p("AgEAmIAAhCIgUAAIAAgJIAxAAIAAAJIgUAAIAABCg");
  this.shape_23.setTransform(272.025, -21.05);
  this.shape_24 = new cjs.Shape();
  this.shape_24.graphics.f("#0C593C").s().p("AgYAxIAAgJQADABAEAAQAGAAADgEIAFgLIgYhLIALAAIARA7IAQg7IALAAIgXBKIgFAOQgBAFgEADQgFADgHAAIgHgBg");
  this.shape_24.setTransform(266.375, -19.775);
  this.shape_25 = new cjs.Shape();
  this.shape_25.graphics.f("#0C593C").s().p("AAWAwIAAgVIgrAAIAAAVIgKAAIAAgeIAHAAIAFgNIADgLIABgQIAAgZIAnAAIAABBIAIAAIAAAegAgFgQQAAALgCAGIgGARIAbAAIAAg4IgTAAg");
  this.shape_25.setTransform(260.025, -20.025);
  this.shape_26 = new cjs.Shape();
  this.shape_26.graphics.f("#0C593C").s().p("AgMAlQgEgDgDgFQgEgHAAgIIAKAAQABAHABADQACADACACQADABAEAAQANAAAAgOQABgFgEgFQgDgDgGAAIgFAAIAAgIIAFAAQAFAAADgDQACgEAAgFQAAgGgCgDQgDgDgGgBQgGABgCADQgDAEgBAGIgKAAQAAgGAEgFQACgFAGgDQAFgEAFAAQAGABAFACQAFACADAFQADAEAAAFQAAAIgDAFQgEAEgGACQAGABAFAEQAEAFAAAJQAAAGgDAFQgDAFgFADQgGACgGAAQgHAAgGgCg");
  this.shape_26.setTransform(253.65, -21.05);
  this.shape_27 = new cjs.Shape();
  this.shape_27.graphics.f("#0C593C").s().p("AgWAmIAAhLIAXAAQAJABAGAEQAFAFAAAIQAAAIgDAEQgDAFgFABQAGABADAFQAEAEAAAIQAAAGgDAFQgCAFgEACQgFACgEABgAgLAdIALAAQAHAAADgEQACgCAAgIQAAgFgDgEQgDgDgFAAIgMAAgAgLgFIALAAQAFAAADgCQADgEgBgFQABgMgLAAIgLAAg");
  this.shape_27.setTransform(248, -21.05);
  this.shape_28 = new cjs.Shape();
  this.shape_28.graphics.f("#0C593C").s().p("AAOAmIAAg4IABgKIgCAKIgYA4IgNAAIAAhLIALAAIAAA5IgBAJIACgJIAYg5IANAAIAABLg");
  this.shape_28.setTransform(238.025, -21.05);
  this.shape_29 = new cjs.Shape();
  this.shape_29.graphics.f("#0C593C").s().p("AgYAzIAAhjIAKAAIAAAIQADgFAEgCQAFgDADAAQAYAAAAAmQAAAJgBAGQgBAIgCAFQgDAGgFADQgFADgGAAQgFAAgDgDQgFgCgDgFIAAAhgAgLghQgCAJgBANIABAPQABAGADAEQADAFAGAAQAHAAAEgIQADgIAAgPQAAgdgOAAQgIAAgDAIg");
  this.shape_29.setTransform(231.4, -19.875);
  this.shape_30 = new cjs.Shape();
  this.shape_30.graphics.f("#0C593C").s().p("AANAmIAAhCIgZAAIAABCIgLAAIAAhLIAvAAIAABLg");
  this.shape_30.setTransform(224.575, -21.05);
  this.shape_31 = new cjs.Shape();
  this.shape_31.graphics.f("#0C593C").s().p("AgEAmIAAhCIgUAAIAAgJIAxAAIAAAJIgUAAIAABCg");
  this.shape_31.setTransform(215.325, -21.05);
  this.shape_32 = new cjs.Shape();
  this.shape_32.graphics.f("#0C593C").s().p("AgZAzIAAhjIALAAIAAAIQADgFAEgCQAFgDADAAQAZAAAAAmQAAAJgCAGQgBAIgDAFQgDAGgEADQgFADgHAAQgEAAgDgDQgFgCgDgFIAAAhgAgLghQgCAJgBANIABAPQABAGADAEQADAFAGAAQAHAAAEgIQADgIAAgPQAAgdgOAAQgIAAgDAIg");
  this.shape_32.setTransform(209.55, -19.875);
  this.shape_33 = new cjs.Shape();
  this.shape_33.graphics.f("#0C593C").s().p("AgOAkQgFgEgEgJQgDgIAAgPQAAgSAHgLQAGgJANgBQAbAAAAAnQAAAPgEAIQgDAJgGAEQgGADgIAAQgIAAgGgDgAgIgaQgEADgBAHQgCAGAAALQAAAKACAGQABAGADAEQAEADAFAAQAGAAADgDQAEgEABgGQACgGAAgKQAAgLgCgGQgCgHgDgDQgDgDgGgBQgFABgDADg");
  this.shape_33.setTransform(202.725, -21.05);
  this.shape_34 = new cjs.Shape();
  this.shape_34.graphics.f("#0C593C").s().p("AgEA/IAAghQgDAFgEACQgEADgFAAQgKAAgFgFQgFgGgCgJQgCgJAAgLQAAgLACgIQACgIAGgGQAFgFAJAAQAFAAAEADQAEADADAFIAAgjIAKAAIAAAjQACgFAEgDQAEgDAFAAQANAAAGALQAFAKAAARQAAAogYAAQgFAAgDgDQgEgCgDgFIAAAhgAAIgUQgCAJAAALQAAAOACAJQADAIAJAAQAIAAADgIQADgIAAgPQAAgdgOAAQgJAAgDAJgAghAAQAAAPADAIQAEAIAIAAQAGAAADgFQADgEABgGIABgQQAAgLgDgJQgCgJgJAAQgPAAAAAdg");
  this.shape_34.setTransform(194.125, -21.1);
  this.shape_35 = new cjs.Shape();
  this.shape_35.graphics.f("#0C593C").s().p("AAXAmIAAhCIgUBCIgGAAIgThCIAABCIgKAAIAAhLIARAAIANAxIACAPIADgPIANgxIARAAIAABLg");
  this.shape_35.setTransform(184.725, -21.05);
  this.shape_36 = new cjs.Shape();
  this.shape_36.graphics.f("#0C593C").s().p("AgOAkQgFgEgEgJQgDgIAAgPQAAgSAHgLQAGgJANgBQAbAAAAAnQAAAPgEAIQgDAJgGAEQgGADgIAAQgIAAgGgDgAgIgaQgEADgBAHQgCAGAAALQAAAKACAGQABAGADAEQAEADAFAAQAGAAADgDQAEgEABgGQACgGAAgKQAAgLgCgGQgCgHgDgDQgDgDgGgBQgFABgDADg");
  this.shape_36.setTransform(177.175, -21.05);
  this.shape_37 = new cjs.Shape();
  this.shape_37.graphics.f("#0C593C").s().p("AANAmIgSgmIgIALIAAAbIgLAAIAAhLIALAAIAAAjIAZgjIAMAAIgXAeIAYAtg");
  this.shape_37.setTransform(171.25, -21.05);
  this.shape_38 = new cjs.Shape();
  this.shape_38.graphics.f("#0C593C").s().p("AgOAiQgGgFgCgIQgBgJAAgLQAAgoAZAAQAKAAAGAIQAGAHAAALIgKAAQAAgRgNAAQgHAAgDAJQgDAJAAANQAAANACAIQADAJAIgBQAIABACgGQADgEAAgJIAKAAQAAAMgFAHQgGAJgLgBQgKAAgGgFg");
  this.shape_38.setTransform(164.925, -21.05);
  this.shape_39 = new cjs.Shape();
  this.shape_39.graphics.f("#0C593C").s().p("AAOAmIAAg4IABgKIgCAKIgYA4IgNAAIAAhLIALAAIAAA5IgBAJIACgJIAYg5IANAAIAABLg");
  this.shape_39.setTransform(158.525, -21.05);
  this.shape_40 = new cjs.Shape();
  this.shape_40.graphics.f("#0C593C").s().p("AAWAwIAAgVIgrAAIAAAVIgKAAIAAgeIAHAAIAFgNIADgLIABgQIAAgZIAnAAIAABBIAIAAIAAAegAgFgQQAAALgCAGIgGARIAbAAIAAg4IgTAAg");
  this.shape_40.setTransform(151.625, -20.025);
  this.shape_41 = new cjs.Shape();
  this.shape_41.graphics.f("#0C593C").s().p("AAOAmIAAggIgLAAIgPAgIgLAAIAQghQgHgDgDgEQgDgGgBgHQABgGACgFQACgFAFgCQAFgDAGgBIAYAAIAABLgAgHgYQgDADAAAHQAAAMAMAAIAMAAIAAgaIgLAAQgHABgDADg");
  this.shape_41.setTransform(141.4, -21.05);
  this.shape_42 = new cjs.Shape();
  this.shape_42.graphics.f("#0C593C").s().p("AgOAiQgGgFgCgIQgBgJAAgLQAAgoAZAAQAKAAAGAIQAGAHAAALIgKAAQAAgRgNAAQgHAAgDAJQgDAJAAANQAAANACAIQADAJAIgBQAIABACgGQADgEAAgJIAKAAQAAAMgFAHQgGAJgLgBQgKAAgGgFg");
  this.shape_42.setTransform(135.825, -21.05);
  this.shape_43 = new cjs.Shape();
  this.shape_43.graphics.f("#0C593C").s().p("AgEAmIAAhCIgUAAIAAgJIAxAAIAAAJIgUAAIAABCg");
  this.shape_43.setTransform(130.275, -21.05);
  this.shape_44 = new cjs.Shape();
  this.shape_44.graphics.f("#0C593C").s().p("AgLAkQgGgEgDgJQgDgIAAgPQAAgnAXAAQALAAAFAHQAFAFABAIQACAJAAALIgjAAIAAARQABAGADADQADADAFAAQAMAAAAgSIALAAQAAAIgDAGQgCAGgFAEQgFADgIAAQgHAAgFgDgAgJgXQgCAHAAAJIAYAAQAAgLgDgFQgCgHgHAAQgHABgDAGg");
  this.shape_44.setTransform(124.675, -21.05);
  this.shape_45 = new cjs.Shape();
  this.shape_45.graphics.f("#0C593C").s().p("AgZATQAAgHACgEQACgEAEgDIALgFIAMgFQADgBAAgHQAAgHgDgCQgCgEgGAAQgFABgDADQgCADgBAHIgJAAQAAgWAVgBQAHAAAFAEQAEACACAEQADAEAAAGIAAArQAAAGADAAIADAAIAAAIIgEABQgFAAgDgCQgDgCgBgHQgCAFgEADQgEADgFAAQgUABAAgVgAABABIgIAEIgFAFQgCADAAAGQAAALAKAAQAGAAAEgFIABgCIABgEIABgHIAAgPIgIAEg");
  this.shape_45.setTransform(118.8, -21.05);
  this.shape_46 = new cjs.Shape();
  this.shape_46.graphics.f("#0C593C").s().p("AgWAmIAAhLIAYAAQAIABAFAEQAHAFAAAIQgBAIgDAEQgDAFgFABQAGABAEAFQADAEAAAIQAAAGgCAFQgDAFgEACQgFACgEABgAgMAdIAMAAQAHAAADgEQACgCABgIQAAgFgDgEQgDgDgGAAIgNAAgAgMgFIAMAAQAFAAADgCQADgEAAgFQAAgMgLAAIgMAAg");
  this.shape_46.setTransform(112.95, -21.05);
  this.shape_47 = new cjs.Shape();
  this.shape_47.graphics.f("#0C593C").s().p("AgLAkQgGgEgDgJQgDgIAAgPQAAgnAXAAQALAAAFAHQAFAFABAIQACAJAAALIgjAAIAAARQABAGADADQADADAFAAQAMAAAAgSIALAAQAAAIgDAGQgCAGgFAEQgFADgIAAQgHAAgFgDgAgJgXQgCAHAAAJIAYAAQAAgLgDgFQgCgHgHAAQgHABgDAGg");
  this.shape_47.setTransform(106.675, -21.05);
  this.shape_48 = new cjs.Shape();
  this.shape_48.graphics.f("#0C593C").s().p("AAXAmIAAhCIgUBCIgGAAIgThCIAABCIgKAAIAAhLIARAAIANAxIACAPIADgPIANgxIARAAIAABLg");
  this.shape_48.setTransform(99.525, -21.05);
  this.shape_49 = new cjs.Shape();
  this.shape_49.graphics.f("#0C593C").s().p("AgYAxIAAgJQADABAEAAQAGAAADgEIAFgLIgYhLIALAAIARA7IAQg7IALAAIgXBKIgFAOQgBAFgEADQgFADgHAAIgHgBg");
  this.shape_49.setTransform(92.225, -19.775);
  this.shape_50 = new cjs.Shape();
  this.shape_50.graphics.f("#0C593C").s().p("AgMAlQgFgDgDgFQgDgHAAgIIAKAAQAAAHACADQABADAEACQADABADAAQANAAAAgOQAAgFgDgFQgDgDgGAAIgFAAIAAgIIAFAAQAEAAADgDQAEgEAAgFQAAgGgEgDQgCgDgGgBQgFABgEADQgCAEgBAGIgKAAQAAgGADgFQADgFAFgDQAGgEAFAAQAGABAGACQAEACADAFQADAEAAAFQAAAIgDAFQgEAEgGACQAGABAFAEQAEAFAAAJQAAAGgDAFQgCAFgGADQgGACgGAAQgIAAgFgCg");
  this.shape_50.setTransform(86.4, -21.05);
  this.shape_51 = new cjs.Shape();
  this.shape_51.graphics.f("#0C593C").s().p("AgZATQAAgHACgEQACgEAEgDIALgFIAMgFQADgBAAgHQAAgHgDgCQgCgEgGAAQgFABgDADQgCADgBAHIgJAAQAAgWAVgBQAHAAAFAEQAEACADAEQACAEAAAGIAAArQAAAGADAAIADAAIAAAIIgFABQgEAAgDgCQgDgCgBgHQgCAFgFADQgDADgFAAQgUABAAgVgAABABIgIAEIgFAFQgCADAAAGQAAALAKAAQAGAAAEgFIABgCIACgEIAAgHIAAgPIgIAEg");
  this.shape_51.setTransform(80.65, -21.05);
  this.shape_52 = new cjs.Shape();
  this.shape_52.graphics.f("#0C593C").s().p("AgYAzIAAhjIAKAAIAAAIQADgFAEgCQAFgDADAAQAZAAAAAmQAAAJgCAGQgBAIgDAFQgCAGgFADQgFADgGAAQgFAAgDgDQgEgCgEgFIAAAhgAgLghQgCAJgBANIABAPQABAGADAEQADAFAGAAQAHAAAEgIQADgIAAgPQAAgdgOAAQgIAAgDAIg");
  this.shape_52.setTransform(74.45, -19.875);
  this.shape_53 = new cjs.Shape();
  this.shape_53.graphics.f("#0C593C").s().p("AAWAwIAAgVIgrAAIAAAVIgKAAIAAgeIAHAAIAFgNIADgLIABgQIAAgZIAnAAIAABBIAIAAIAAAegAgFgQQAAALgCAGIgGARIAbAAIAAg4IgTAAg");
  this.shape_53.setTransform(67.475, -20.025);
  this.shape_54 = new cjs.Shape();
  this.shape_54.graphics.f("#0C593C").s().p("AgOAkQgFgEgEgJQgDgIAAgPQAAgSAHgLQAGgJANgBQAbAAAAAnQAAAPgEAIQgDAJgGAEQgGADgIAAQgIAAgGgDgAgIgaQgEADgBAHQgCAGAAALQAAAKACAGQABAGADAEQAEADAFAAQAGAAADgDQAEgEABgGQACgGAAgKQAAgLgCgGQgCgHgDgDQgDgDgGgBQgFABgDADg");
  this.shape_54.setTransform(60.725, -21.05);
  this.shape_55 = new cjs.Shape();
  this.shape_55.graphics.f("#0C593C").s().p("AATAzIAAhaIglAAIAABaIgLAAIAAhkIA8AAIAABkg");
  this.shape_55.setTransform(53.25, -22.35);
  this.shape_56 = new cjs.Shape();
  this.shape_56.graphics.f("#0C593C").s().p("AAAAGIgJANIgGgEIAKgMIgPgFIACgGIAQAGIAAgRIAGAAIAAARIAOgGIADAGIgQAFIALAMIgGAFg");
  this.shape_56.setTransform(45.825, -25.4);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_56
   }, {
    t: this.shape_55
   }, {
    t: this.shape_54
   }, {
    t: this.shape_53
   }, {
    t: this.shape_52
   }, {
    t: this.shape_51
   }, {
    t: this.shape_50
   }, {
    t: this.shape_49
   }, {
    t: this.shape_48
   }, {
    t: this.shape_47
   }, {
    t: this.shape_46
   }, {
    t: this.shape_45
   }, {
    t: this.shape_44
   }, {
    t: this.shape_43
   }, {
    t: this.shape_42
   }, {
    t: this.shape_41
   }, {
    t: this.shape_40
   }, {
    t: this.shape_39
   }, {
    t: this.shape_38
   }, {
    t: this.shape_37
   }, {
    t: this.shape_36
   }, {
    t: this.shape_35
   }, {
    t: this.shape_34
   }, {
    t: this.shape_33
   }, {
    t: this.shape_32
   }, {
    t: this.shape_31
   }, {
    t: this.shape_30
   }, {
    t: this.shape_29
   }, {
    t: this.shape_28
   }, {
    t: this.shape_27
   }, {
    t: this.shape_26
   }, {
    t: this.shape_25
   }, {
    t: this.shape_24
   }, {
    t: this.shape_23
   }, {
    t: this.shape_22
   }, {
    t: this.shape_21
   }, {
    t: this.shape_20
   }, {
    t: this.shape_19
   }, {
    t: this.shape_18
   }, {
    t: this.shape_17
   }, {
    t: this.shape_16
   }, {
    t: this.shape_15
   }, {
    t: this.shape_14
   }, {
    t: this.shape_13
   }, {
    t: this.shape_12
   }, {
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
 }).prototype = getMCSymbolPrototype(lib.l1, new cjs.Rectangle(5, -32, 324, 31.2), null);
 (lib.icon03 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.icon3();
  this.instance.parent = this;
  this.instance.setTransform(0, 0, 0.667, 0.667);
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));
 }).prototype = getMCSymbolPrototype(lib.icon03, new cjs.Rectangle(0, 0, 142.8, 142.8), null);
 (lib.icon02 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.icon2();
  this.instance.parent = this;
  this.instance.setTransform(0, 0, 0.667, 0.667);
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));
 }).prototype = getMCSymbolPrototype(lib.icon02, new cjs.Rectangle(0, 0, 113.4, 114.7), null);
 (lib.icon1_1_icon1_lact = function() {
  this.initialize(img.icon1_1_icon1_lact);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 212, 213);
 (lib.icon1_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_icon1 = new lib.icon1_1_icon1_lact();
  this.cvr_icon1.name = "cvr_icon1";
  this.cvr_icon1.parent = this;
  this.cvr_icon1.setTransform(0, 0, 0.6671361502347417, 0.6671361502347417);
  this.timeline.addTween(cjs.Tween.get(this.cvr_icon1).wait(1));
 }).prototype = getMCSymbolPrototype(lib.icon1_1, new cjs.Rectangle(0, 0, 141.4, 142.1), null);
 (lib.gr = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.lf(["rgba(217,237,141,0)", "#D9ED8D"], [0, 1], -6.7, -76.5, -6.7, -104.5).s().p("A6PV4MAAAgrvMA0fAAAMAAAArvg");
  this.shape.setTransform(168, 140);
  this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
 }).prototype = getMCSymbolPrototype(lib.gr, new cjs.Rectangle(0, 0, 336, 280), null);
 (lib.fish02 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.fish2();
  this.instance.parent = this;
  this.instance.setTransform(0, 0, 0.667, 0.667);
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));
 }).prototype = getMCSymbolPrototype(lib.fish02, new cjs.Rectangle(0, 0, 230.8, 177.4), null);
 (lib.fish01 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.fish1();
  this.instance.parent = this;
  this.instance.setTransform(0, 0, 0.667, 0.667);
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));
 }).prototype = getMCSymbolPrototype(lib.fish01, new cjs.Rectangle(0, 0, 228.1, 207.5), null);
 (lib.black_plate = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#C0DF53").s().p("A6PV4MAAAgrvMA0fAAAMAAAArvg");
  this.shape.setTransform(168, 140);
  this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
 }).prototype = getMCSymbolPrototype(lib.black_plate, new cjs.Rectangle(0, 0, 336, 280), null);
 (lib.bg_g = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.lf(["#C0DF53", "#D9ED8D"], [0, 1], -6.7, -76.5, -6.7, -104.5).s().p("A6PV4MAAAgrvMA0fAAAMAAAArvg");
  this.shape.setTransform(168, 140);
  this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
 }).prototype = getMCSymbolPrototype(lib.bg_g, new cjs.Rectangle(0, 0, 336, 280), null);
 (lib.b1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.bubble();
  this.instance.parent = this;
  this.instance.setTransform(0, 0, 0.667, 0.667);
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));
 }).prototype = getMCSymbolPrototype(lib.b1, new cjs.Rectangle(0, 0, 298.8, 298.8), null);
 (lib.txt04 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  var mask = new cjs.Shape();
  mask._off = true;
  mask.graphics.p("A2GN9IAAkSMAsNAAAIAAESg");
  mask.setTransform(141.4871, 89.261);
  this.instance = new lib.t4();
  this.instance.parent = this;
  this.instance.setTransform(78, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance.alpha = 0;
  this.instance._off = true;
  var maskedShapeInstanceList = [this.instance];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(10).to({
   _off: false
  }, 0).to({
   x: 108,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(11));
  var mask_1 = new cjs.Shape();
  mask_1._off = true;
  mask_1.graphics.p("A2GLyIAAj7MAsNAAAIAAD7g");
  mask_1.setTransform(141.4871, 75.4248);
  this.instance_1 = new lib.t4();
  this.instance_1.parent = this;
  this.instance_1.setTransform(78, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance_1.alpha = 0;
  this.instance_1._off = true;
  var maskedShapeInstanceList = [this.instance_1];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(5).to({
   _off: false
  }, 0).to({
   x: 108,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(16));
  var mask_2 = new cjs.Shape();
  mask_2._off = true;
  mask_2.graphics.p("A2GJ4IAAlxMAsNAAAIAAFxg");
  mask_2.setTransform(141.4871, 63.2475);
  this.instance_2 = new lib.t4();
  this.instance_2.parent = this;
  this.instance_2.setTransform(78, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance_2.alpha = 0;
  var maskedShapeInstanceList = [this.instance_2];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_2).to({
   x: 108,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(21));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(11, 92, 272, 86.5);
 (lib.txt03 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  var mask = new cjs.Shape();
  mask._off = true;
  mask.graphics.p("A2GKqIAAlxMAsNAAAIAAFxg");
  mask.setTransform(141.4902, 68.2498);
  this.instance = new lib.t3();
  this.instance.parent = this;
  this.instance.setTransform(78, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance.alpha = 0;
  this.instance._off = true;
  var maskedShapeInstanceList = [this.instance];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(5).to({
   _off: false
  }, 0).to({
   x: 108,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(16));
  var mask_1 = new cjs.Shape();
  mask_1._off = true;
  mask_1.graphics.p("A2GHvIAAnzMAsNAAAIAAHzg");
  mask_1.setTransform(141.4902, 49.5);
  this.instance_1 = new lib.t3();
  this.instance_1.parent = this;
  this.instance_1.setTransform(78, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance_1.alpha = 0;
  var maskedShapeInstanceList = [this.instance_1];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_1).to({
   x: 108,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(21));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(1, 67, 282, 62.80000000000001);
 (lib.txt02_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  var mask = new cjs.Shape();
  mask._off = true;
  mask.graphics.p("ABBOEIAAn0IZKAAIAAH0g");
  mask.setTransform(167.5, 90);
  this.instance = new lib.t2_1();
  this.instance.parent = this;
  this.instance.setTransform(78, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance.alpha = 0;
  this.instance._off = true;
  var maskedShapeInstanceList = [this.instance];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(5).to({
   _off: false
  }, 0).to({
   x: 108,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(1));
  var mask_1 = new cjs.Shape();
  mask_1._off = true;
  mask_1.graphics.p("ABBKKIAAn0IZKAAIAAH0g");
  mask_1.setTransform(167.5, 65);
  this.instance_1 = new lib.t2_1();
  this.instance_1.parent = this;
  this.instance_1.setTransform(78, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance_1.alpha = 0;
  var maskedShapeInstanceList = [this.instance_1];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_1).to({
   x: 108,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(6));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(174, 101, 105, 79);
 (lib.txt02 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  var mask = new cjs.Shape();
  mask._off = true;
  mask.graphics.p("AybMrIAAlkMAk3AAAIAAFkg");
  mask.setTransform(118, 81.0805);
  this.instance = new lib.t2();
  this.instance.parent = this;
  this.instance.setTransform(78, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance.alpha = 0;
  this.instance._off = true;
  var maskedShapeInstanceList = [this.instance];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(10).to({
   _off: false
  }, 0).to({
   x: 108,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(11));
  var mask_1 = new cjs.Shape();
  mask_1._off = true;
  mask_1.graphics.p("A2GJ3IAAkHMAsNAAAIAAEHg");
  mask_1.setTransform(141.4902, 63.0968);
  this.instance_1 = new lib.t2();
  this.instance_1.parent = this;
  this.instance_1.setTransform(78, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance_1.alpha = 0;
  this.instance_1._off = true;
  var maskedShapeInstanceList = [this.instance_1];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(5).to({
   _off: false
  }, 0).to({
   x: 108,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(16));
  var mask_2 = new cjs.Shape();
  mask_2._off = true;
  mask_2.graphics.p("A2GHzIAAlkMAsNAAAIAAFkg");
  mask_2.setTransform(141.4902, 49.8805);
  this.instance_2 = new lib.t2();
  this.instance_2.parent = this;
  this.instance_2.setTransform(78, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance_2.alpha = 0;
  var maskedShapeInstanceList = [this.instance_2];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_2).to({
   x: 108,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(21));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(0, 68, 283, 89.19999999999999);
 (lib.txt01 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  var mask = new cjs.Shape();
  mask._off = true;
  mask.graphics.p("AvAKoIAAk2IeBAAIAAE2g");
  mask.setTransform(96.1224, 67.9999);
  this.instance = new lib.t1();
  this.instance.parent = this;
  this.instance.setTransform(78, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance.alpha = 0;
  this.instance._off = true;
  var maskedShapeInstanceList = [this.instance];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(5).to({
   _off: false
  }, 0).to({
   x: 108,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(21));
  var mask_1 = new cjs.Shape();
  mask_1._off = true;
  mask_1.graphics.p("AvAINIAAk2IeBAAIAAE2g");
  mask_1.setTransform(96.1224, 52.4999);
  this.instance_1 = new lib.t1();
  this.instance_1.parent = this;
  this.instance_1.setTransform(78, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance_1.alpha = 0;
  var maskedShapeInstanceList = [this.instance_1];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_1).to({
   x: 108,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(26));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(0, 74, 192.3, 62);
 (lib._new = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.orange();
  this.instance.parent = this;
  this.instance.setTransform(52, 52, 1, 1, 0, 0, 0, 52, 52);
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   scaleX: 1.0787,
   scaleY: 1.0787,
   x: 52.05,
   y: 52.05
  }, 12, cjs.Ease.get(1)).to({
   scaleX: 1,
   scaleY: 1,
   x: 52,
   y: 52
  }, 12, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(-4, -4, 124.6, 112.2);
 (lib.icon1_2 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_icon1 = new lib.icon1_1();
  this.cvr_icon1.name = "cvr_icon1";
  this.cvr_icon1.parent = this;
  this.cvr_icon1.setTransform(70.7, 71, 1, 1, 0, 0, 0, 70.7, 71);
  this.timeline.addTween(cjs.Tween.get(this.cvr_icon1).wait(1));
 }).prototype = getMCSymbolPrototype(lib.icon1_2, new cjs.Rectangle(0, 0, 141.4, 142.1), null);
 (lib.fish02_float = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.fish02();
  this.instance.parent = this;
  this.instance.setTransform(114, 103.7, 1, 1, 0, 0, 0, 114, 103.7);
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   y: 98.7
  }, 9, cjs.Ease.get(-1)).to({
   y: 93.7
  }, 10, cjs.Ease.get(1)).to({
   y: 98.7
  }, 10, cjs.Ease.get(-1)).to({
   y: 103.7
  }, 10, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(0, -10, 230.8, 187.4);
 (lib.bubble_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.b1();
  this.instance.parent = this;
  this.instance.setTransform(149.4, 149.4, 1, 1, 0, 0, 0, 149.4, 149.4);
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   y: 143.75
  }, 9, cjs.Ease.get(-1)).to({
   y: 137.45
  }, 10, cjs.Ease.get(1)).to({
   y: 143.45
  }, 10, cjs.Ease.get(-1)).to({
   y: 149.4
  }, 10, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(0, -11.9, 298.8, 310.7);
 (lib.fish01_float = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.bubble_1();
  this.instance.parent = this;
  this.instance.setTransform(40, 98.7, 0.0337, 0.0337, 0, 0, 0, 145.6, 154.5);
  this.instance._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(21).to({
   _off: false
  }, 0).to({
   regX: 145.9,
   regY: 153.2,
   scaleX: 0.1707,
   scaleY: 0.1707,
   x: -20,
   y: 58.7
  }, 10, cjs.Ease.get(0.5)).to({
   regX: 145.7,
   regY: 154.5,
   scaleX: 0.034,
   scaleY: 0.034,
   y: 38.7
  }, 10, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(76));
  this.instance_1 = new lib.bubble_1();
  this.instance_1.parent = this;
  this.instance_1.setTransform(40, 98.7, 0.0337, 0.0337, 0, 0, 0, 145.6, 154.5);
  this.instance_1._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(16).to({
   _off: false
  }, 0).to({
   regX: 145.9,
   regY: 153.2,
   scaleX: 0.1707,
   scaleY: 0.1707,
   x: -30,
   y: 78.7
  }, 10, cjs.Ease.get(0.5)).to({
   regX: 145.7,
   regY: 154.5,
   scaleX: 0.034,
   scaleY: 0.034,
   x: -10,
   y: 48.7
  }, 10, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(81));
  this.instance_2 = new lib.bubble_1();
  this.instance_2.parent = this;
  this.instance_2.setTransform(40, 98.7, 0.0337, 0.0337, 0, 0, 0, 145.6, 154.5);
  this.instance_2._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(11).to({
   _off: false
  }, 0).to({
   regX: 145.9,
   regY: 153.2,
   scaleX: 0.1707,
   scaleY: 0.1707,
   x: -30,
   y: 68.7
  }, 10, cjs.Ease.get(0.5)).to({
   regX: 145.7,
   regY: 154.5,
   scaleX: 0.034,
   scaleY: 0.034,
   x: -40,
   y: 28.7
  }, 10, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(86));
  this.instance_3 = new lib.bubble_1();
  this.instance_3.parent = this;
  this.instance_3.setTransform(40, 98.7, 0.0337, 0.0337, 0, 0, 0, 145.6, 154.5);
  this.instance_3._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(6).to({
   _off: false
  }, 0).to({
   regX: 145.9,
   regY: 153.2,
   scaleX: 0.1707,
   scaleY: 0.1707,
   x: -20,
   y: 58.7
  }, 10, cjs.Ease.get(0.5)).to({
   regX: 145.7,
   regY: 154.5,
   scaleX: 0.034,
   scaleY: 0.034,
   y: 38.7
  }, 10, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(91));
  this.instance_4 = new lib.fish01();
  this.instance_4.parent = this;
  this.instance_4.setTransform(114, 103.7, 1, 1, 0, 0, 0, 114, 103.7);
  this.timeline.addTween(cjs.Tween.get(this.instance_4).to({
   y: 98.7
  }, 9, cjs.Ease.get(-1)).to({
   y: 93.7
  }, 10, cjs.Ease.get(1)).to({
   y: 98.7
  }, 10, cjs.Ease.get(-1)).to({
   y: 103.7
  }, 10, cjs.Ease.get(1)).to({
   y: 98.7
  }, 9, cjs.Ease.get(-1)).to({
   y: 93.7
  }, 10, cjs.Ease.get(1)).to({
   y: 98.7
  }, 10, cjs.Ease.get(-1)).to({
   y: 103.7
  }, 10, cjs.Ease.get(1)).to({
   y: 98.7
  }, 9, cjs.Ease.get(-1)).to({
   y: 93.7
  }, 10, cjs.Ease.get(1)).to({
   y: 98.7
  }, 10, cjs.Ease.get(-1)).to({
   y: 103.7
  }, 10, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(-54.9, -10, 283, 217.5);
 (lib.content = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {
   cvr_frame1_2: 83,
   cvr_frame2_3: 178,
   "cvr_frame#3": 240,
   cvr_stay: 262,
   cvr_frame4_1: 349
  });
  this.instance = new lib.black_plate();
  this.instance.parent = this;
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   alpha: 0
  }, 14, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(349).to({
   _off: false
  }, 0).to({
   alpha: 1
  }, 15, cjs.Ease.get(-1)).wait(1));
  this.instance_1 = new lib.logo();
  this.instance_1.parent = this;
  this.instance_1.setTransform(112.5, 26.1, 1, 1, 0, 0, 0, 112.5, 26.1);
  this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(180).to({
   alpha: 0
  }, 14, cjs.Ease.get(1)).wait(85).to({
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(87));
  this.instance_2 = new lib.txt04("synched", 0, false);
  this.instance_2.parent = this;
  this.instance_2.setTransform(108, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance_2._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(295).to({
   _off: false
  }, 0).wait(85));
  this.instance_3 = new lib.txt02("synched", 0, false);
  this.instance_3.parent = this;
  this.instance_3.setTransform(108, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance_3._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(105).to({
   _off: false
  }, 0).wait(75).to({
   startPosition: 34
  }, 0).to({
   alpha: 0
  }, 14, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(185));
  this.instance_4 = new lib.gr();
  this.instance_4.parent = this;
  this.instance_4.setTransform(150, 300, 1, 1, 0, 0, 0, 150, 300);
  this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(180).to({
   alpha: 0
  }, 14, cjs.Ease.get(1)).wait(85).to({
   regY: 300.1,
   y: 300.1,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(87));
  this.instance_5 = new lib.l4();
  this.instance_5.parent = this;
  this.instance_5.setTransform(149.5, 320.1, 1, 1, 0, 0, 0, 149.5, 40.1);
  this.instance_5.alpha = 0;
  this.instance_5._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(310).to({
   _off: false
  }, 0).to({
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(56));
  this.instance_6 = new lib.fish02_float();
  this.instance_6.parent = this;
  this.instance_6.setTransform(430, 184.8, 0.6923, 0.6923, 0, 0, 0, 114.1, 103.7);
  this.instance_6._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(285).to({
   _off: false
  }, 0).to({
   x: 250
  }, 14, cjs.Ease.get(1)).wait(81));
  var mask = new cjs.Shape();
  mask._off = true;
  var mask_graphics_300 = new cjs.Graphics().p("AOfH1QgTgTAAgcQAAgbATgTQATgUAcAAQAbAAATAUQATATAAAbQAAAcgTATQgTATgbAAQgcAAgTgTg");
  var mask_graphics_301 = new cjs.Graphics().p("ANkH+QghghAAgwQAAgvAhghQAhgiAwAAQAvAAAhAiQAiAhAAAvQAAAwgiAhQghAigvAAQgwAAghgig");
  var mask_graphics_302 = new cjs.Graphics().p("AMtIHQgugvAAhBQAAhCAugvQAvguBCAAQBCAAAuAuQAvAvAABCQAABBgvAvQguAvhCAAQhCAAgvgvg");
  var mask_graphics_303 = new cjs.Graphics().p("AL7IPQg6g7AAhTQAAhSA6g7QA7g7BTAAQBTAAA6A7QA7A7AABSQAABTg7A7Qg6A7hTAAQhTAAg7g7g");
  var mask_graphics_304 = new cjs.Graphics().p("ALNIWQhFhFAAhjQAAhiBFhGQBGhFBiAAQBjAABFBFQBGBGAABiQAABjhGBFQhFBGhjAAQhiAAhGhGg");
  var mask_graphics_305 = new cjs.Graphics().p("AKkIdQhQhQAAhwQAAhxBQhPQBPhQBxAAQBwAABQBQQBQBPAABxQAABwhQBQQhQBQhwAAQhxAAhPhQg");
  var mask_graphics_306 = new cjs.Graphics().p("AJ/IjQhZhZAAh9QAAh9BZhYQBYhZB9AAQB9AABZBZQBYBYAAB9QAAB9hYBZQhZBYh9AAQh9AAhYhYg");
  var mask_graphics_307 = new cjs.Graphics().p("AJeIoQhhhgAAiJQAAiIBhhgQBghgCJAAQCIAABgBgQBhBgAACIQAACJhhBgQhgBgiIAAQiJAAhghgg");
  var mask_graphics_308 = new cjs.Graphics().p("AJBItQhnhnAAiSQAAiSBnhoQBohmCSAAQCSAABnBmQBnBoAACSQAACShnBnQhnBniSAAQiSAAhohng");
  var mask_graphics_309 = new cjs.Graphics().p("AIpIxQhthtAAibQAAiaBthtQBthsCaAAQCbAABtBsQBsBtAACaQAACbhsBtQhtBsibAAQiaAAhthsg");
  var mask_graphics_310 = new cjs.Graphics().p("AIWI0QhyhyAAihQAAihByhxQBxhxChAAQChAAByBxQBxBxAAChQAAChhxByQhyBxihAAQihAAhxhxg");
  var mask_graphics_311 = new cjs.Graphics().p("AIGI2Qh1h1AAimQAAimB1h1QB2h1CmAAQCmAAB1B1QB1B1AACmQAACmh1B1Qh1B1imAAQimAAh2h1g");
  var mask_graphics_312 = new cjs.Graphics().p("AH8I4Qh4h4AAiqQAAipB4h3QB3h4CqAAQCqAAB4B4QB4B3AACpQAACqh4B4Qh4B4iqAAQiqAAh3h4g");
  var mask_graphics_313 = new cjs.Graphics().p("AH1I5Qh6h6AAisQAAirB6h5QB6h5CrAAQCsAAB6B5QB5B5AACrQAACsh5B6Qh6B5isAAQirAAh6h5g");
  var mask_graphics_314 = new cjs.Graphics().p("AHzI5Qh6h6AAitQAAisB6h5QB6h6CsAAQCtAAB6B6QB6B5AACsQAACth6B6Qh6B6itAAQisAAh6h6g");
  this.timeline.addTween(cjs.Tween.get(mask).to({
   graphics: null,
   x: 0,
   y: 0
  }).wait(300).to({
   graphics: mask_graphics_300,
   x: 103.9328,
   y: 52.0078
  }).wait(1).to({
   graphics: mask_graphics_301,
   x: 106.2871,
   y: 54.3662
  }).wait(1).to({
   graphics: mask_graphics_302,
   x: 108.4671,
   y: 56.55
  }).wait(1).to({
   graphics: mask_graphics_303,
   x: 110.4726,
   y: 58.559
  }).wait(1).to({
   graphics: mask_graphics_304,
   x: 112.3038,
   y: 60.3934
  }).wait(1).to({
   graphics: mask_graphics_305,
   x: 113.9606,
   y: 62.053
  }).wait(1).to({
   graphics: mask_graphics_306,
   x: 115.4429,
   y: 63.538
  }).wait(1).to({
   graphics: mask_graphics_307,
   x: 116.7509,
   y: 64.8482
  }).wait(1).to({
   graphics: mask_graphics_308,
   x: 117.8845,
   y: 65.9838
  }).wait(1).to({
   graphics: mask_graphics_309,
   x: 118.8436,
   y: 66.9446
  }).wait(1).to({
   graphics: mask_graphics_310,
   x: 119.6284,
   y: 67.7308
  }).wait(1).to({
   graphics: mask_graphics_311,
   x: 120.2388,
   y: 68.3422
  }).wait(1).to({
   graphics: mask_graphics_312,
   x: 120.6748,
   y: 68.779
  }).wait(1).to({
   graphics: mask_graphics_313,
   x: 120.9364,
   y: 69.041
  }).wait(1).to({
   graphics: mask_graphics_314,
   x: 121.0236,
   y: 69.0986
  }).wait(66));
  this.instance_7 = new lib.icon03();
  this.instance_7.parent = this;
  this.instance_7.setTransform(200.7, 97.05, 0.5883, 0.5883, 0, 0, 0, 72.6, 73.2);
  this.instance_7._off = true;
  var maskedShapeInstanceList = [this.instance_7];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(300).to({
   _off: false
  }, 0).wait(80));
  this.instance_8 = new lib.bubble_1();
  this.instance_8.parent = this;
  this.instance_8.setTransform(200.9, 97.1, 0.054, 0.054, 0, 0, 0, 152.7, 152.7);
  this.instance_8._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(295).to({
   _off: false
  }, 0).to({
   regX: 153,
   scaleX: 0.3413,
   scaleY: 0.3413,
   x: 200.95
  }, 14, cjs.Ease.get(1)).wait(71));
  this.instance_9 = new lib.bubble_1();
  this.instance_9.parent = this;
  this.instance_9.setTransform(88.3, 138, 0.0473, 0.0473, 0, 0, 0, 151, 152.1);
  this.instance_9._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(290).to({
   _off: false
  }, 0).to({
   regX: 150.7,
   regY: 152,
   scaleX: 0.5789,
   scaleY: 0.5789,
   x: 88.25,
   y: 137.9
  }, 14, cjs.Ease.get(1)).wait(76));
  this.instance_10 = new lib.black_plate();
  this.instance_10.parent = this;
  this.instance_10.alpha = 0;
  this.instance_10._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(277).to({
   _off: false
  }, 0).to({
   alpha: 1
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(87));
  this.instance_11 = new lib.l3();
  this.instance_11.parent = this;
  this.instance_11.setTransform(149.5, 320.1, 1, 1, 0, 0, 0, 149.5, 40.1);
  this.instance_11.alpha = 0;
  this.instance_11._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(205).to({
   _off: false
  }, 0).to({
   alpha: 1
  }, 14, cjs.Ease.get(1)).to({
   _off: true
  }, 74).wait(87));
  this.instance_12 = new lib.packshot_1();
  this.instance_12.parent = this;
  this.instance_12.setTransform(436.95, 158.8, 0.7018, 0.7018, 0, 0, 0, 117.4, 56.7);
  this.instance_12._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(185).to({
   _off: false
  }, 0).to({
   regX: 117.5,
   x: 240.45
  }, 14, cjs.Ease.get(1)).to({
   _off: true
  }, 94).wait(87));
  this.instance_13 = new lib.txt03("synched", 0, false);
  this.instance_13.parent = this;
  this.instance_13.setTransform(108, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance_13._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(195).to({
   _off: false
  }, 0).to({
   _off: true
  }, 98).wait(87));
  this.instance_14 = new lib.bubble_1();
  this.instance_14.parent = this;
  this.instance_14.setTransform(95.1, 96.15, 0.0681, 0.0681, 0, 0, 0, 149.9, 149.9);
  this.instance_14._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(190).to({
   _off: false
  }, 0).to({
   regX: 149.7,
   regY: 150,
   scaleX: 0.5421,
   scaleY: 0.5421,
   x: 95.05
  }, 13, cjs.Ease.get(1)).to({
   _off: true
  }, 90).wait(87));
  var mask_1 = new cjs.Shape();
  mask_1._off = true;
  var mask_1_graphics_200 = new cjs.Graphics().p("APkF9QgUgVAAgcQAAgdAUgVQAVgUAdAAQAdAAAUAUQAUAVAAAdQAAAcgUAVQgUAUgdAAQgdAAgVgUg");
  var mask_1_graphics_201 = new cjs.Graphics().p("AOhGIQglglAAg0QAAg0AlglQAlgkA0AAQA0AAAkAkQAlAlAAA0QAAA0glAlQgkAlg0AAQg0AAglglg");
  var mask_1_graphics_202 = new cjs.Graphics().p("ANiGSQg0gzAAhKQAAhJA0g0QA0g0BJAAQBKAAA0A0QA0A0AABJQAABKg0AzQg0A0hKAAQhJAAg0g0g");
  var mask_1_graphics_203 = new cjs.Graphics().p("AMoGcQhBhCAAhdQAAhdBBhCQBChCBdAAQBdAABCBCQBCBCAABdQAABdhCBCQhCBChdAAQhdAAhChCg");
  var mask_1_graphics_204 = new cjs.Graphics().p("AL0GlQhPhPAAhvQAAhvBPhPQBOhNBvAAQBvAABPBNQBPBPAABvQAABvhPBPQhPBOhvAAQhvAAhOhOg");
  var mask_1_graphics_205 = new cjs.Graphics().p("ALEGtQhahaAAiAQAAh/BahZQBahaB/AAQCAAABaBaQBaBZAAB/QAACAhaBaQhaBaiAAAQh/AAhahag");
  var mask_1_graphics_206 = new cjs.Graphics().p("AKZG0QhkhlAAiOQAAiOBkhjQBlhkCOAAQCOAABkBkQBkBjAACOQAACOhkBlQhkBkiOAAQiOAAhlhkg");
  var mask_1_graphics_207 = new cjs.Graphics().p("AJ0G6QhuhtAAibQAAibBuhsQBthuCbAAQCbAABtBuQBuBsAACbQAACbhuBtQhtBtibAAQibAAhthtg");
  var mask_1_graphics_208 = new cjs.Graphics().p("AJTG/Qh1h1AAimQAAilB1h1QB1h1CmAAQCmAAB2B1QB1B1AAClQAACmh1B1Qh2B2imAAQimAAh1h2g");
  var mask_1_graphics_209 = new cjs.Graphics().p("AI4HEQh8h8AAivQAAivB8h8QB8h8CvAAQCvAAB8B8QB8B8AACvQAACvh8B8Qh8B8ivAAQivAAh8h8g");
  var mask_1_graphics_210 = new cjs.Graphics().p("AIhHIQiBiCAAi3QAAi2CBiBQCBiCC3AAQC4AACBCCQCBCBAAC2QAAC3iBCCQiBCBi4AAQi3AAiBiBg");
  var mask_1_graphics_211 = new cjs.Graphics().p("AIPHLQiFiGAAi9QAAi8CFiGQCGiFC9AAQC9AACGCFQCGCGAAC8QAAC9iGCGQiGCFi9AAQi9AAiGiFg");
  var mask_1_graphics_212 = new cjs.Graphics().p("AIDHNQiJiJAAjBQAAjBCJiIQCJiJDBAAQDBAACJCJQCJCIAADBQAADBiJCJQiJCIjBAAQjBAAiJiIg");
  var mask_1_graphics_213 = new cjs.Graphics().p("AH7HOQiKiLAAjDQAAjDCKiLQCLiKDEAAQDEAACKCKQCLCLAADDQAADDiLCLQiKCKjEAAQjEAAiLiKg");
  var mask_1_graphics_214 = new cjs.Graphics().p("AH5HOQiLiLAAjFQAAjDCLiLQCLiLDFAAQDFAACLCLQCLCLAADDQAADFiLCLQiLCLjFAAQjFAAiLiLg");
  this.timeline.addTween(cjs.Tween.get(mask_1).to({
   graphics: null,
   x: 0,
   y: 0
  }).wait(200).to({
   graphics: mask_1_graphics_200,
   x: 111.5466,
   y: 40.1216
  }).wait(1).to({
   graphics: mask_1_graphics_201,
   x: 114.305,
   y: 42.88
  }).wait(1).to({
   graphics: mask_1_graphics_202,
   x: 116.8592,
   y: 45.4342
  }).wait(1).to({
   graphics: mask_1_graphics_203,
   x: 119.2089,
   y: 47.7839
  }).wait(1).to({
   graphics: mask_1_graphics_204,
   x: 121.3544,
   y: 49.9294
  }).wait(1).to({
   graphics: mask_1_graphics_205,
   x: 123.2955,
   y: 51.8705
  }).wait(1).to({
   graphics: mask_1_graphics_206,
   x: 125.0323,
   y: 53.6073
  }).wait(1).to({
   graphics: mask_1_graphics_207,
   x: 126.5648,
   y: 55.1398
  }).wait(1).to({
   graphics: mask_1_graphics_208,
   x: 127.8929,
   y: 56.4679
  }).wait(1).to({
   graphics: mask_1_graphics_209,
   x: 129.0168,
   y: 57.5918
  }).wait(1).to({
   graphics: mask_1_graphics_210,
   x: 129.9362,
   y: 58.5112
  }).wait(1).to({
   graphics: mask_1_graphics_211,
   x: 130.6514,
   y: 59.2264
  }).wait(1).to({
   graphics: mask_1_graphics_212,
   x: 131.1622,
   y: 59.7372
  }).wait(1).to({
   graphics: mask_1_graphics_213,
   x: 131.4687,
   y: 60.0437
  }).wait(1).to({
   graphics: mask_1_graphics_214,
   x: 131.5709,
   y: 60.1459
  }).wait(79).to({
   graphics: null,
   x: 0,
   y: 0
  }).wait(87));
  this.instance_15 = new lib._new();
  this.instance_15.parent = this;
  this.instance_15.setTransform(220, 73.35, 0.7529, 0.7529, 0, 0, 0, 58, 52.1);
  this.instance_15._off = true;
  var maskedShapeInstanceList = [this.instance_15];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(200).to({
   _off: false
  }, 0).to({
   _off: true
  }, 93).wait(87));
  this.instance_16 = new lib.bubble_1();
  this.instance_16.parent = this;
  this.instance_16.setTransform(216.65, 74.8, 0.0435, 0.0435, 0, 0, 0, 152.8, 152.8);
  this.instance_16._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(195).to({
   _off: false
  }, 0).to({
   regX: 153,
   regY: 153.1,
   scaleX: 0.3246,
   scaleY: 0.3246
  }, 13, cjs.Ease.get(1)).to({
   _off: true
  }, 85).wait(87));
  this.instance_17 = new lib.bg_g();
  this.instance_17.parent = this;
  this.instance_17.alpha = 0;
  this.instance_17._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(180).to({
   _off: false
  }, 0).to({
   alpha: 1
  }, 14, cjs.Ease.get(1)).to({
   _off: true
  }, 99).wait(87));
  this.instance_18 = new lib.fish01_float("synched", 0, false);
  this.instance_18.parent = this;
  this.instance_18.setTransform(437.9, 201.15, 0.7145, 0.7145, 0, 0, 0, 114.2, 103.9);
  this.instance_18._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(95).to({
   _off: false
  }, 0).to({
   regX: 114,
   x: 251.95,
   startPosition: 13
  }, 14, cjs.Ease.get(1)).to({
   _off: true
  }, 86).wait(185));
  this.instance_19 = new lib.l2();
  this.instance_19.parent = this;
  this.instance_19.setTransform(141.5, 294.8, 1, 1, 0, 0, 0, 141.5, 14.8);
  this.instance_19.alpha = 0;
  this.instance_19._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(120).to({
   _off: false
  }, 0).to({
   alpha: 1
  }, 14, cjs.Ease.get(1)).to({
   _off: true
  }, 61).wait(185));
  this.instance_20 = new lib.bubble_1();
  this.instance_20.parent = this;
  this.instance_20.setTransform(112.9, 103.5, 0.0588, 0.0588, 0, 0, 0, 150.5, 148.8);
  this.instance_20._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_20).wait(100).to({
   _off: false
  }, 0).to({
   regX: 150.1,
   regY: 149,
   scaleX: 0.6859,
   scaleY: 0.6859,
   y: 103.55
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 80).wait(185));
  this.instance_21 = new lib.black_plate();
  this.instance_21.parent = this;
  this.instance_21.alpha = 0;
  this.instance_21._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_21).wait(84).to({
   _off: false
  }, 0).to({
   alpha: 1
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(280));
  this.instance_22 = new lib.l1();
  this.instance_22.parent = this;
  this.instance_22.setTransform(141.5, 294.8, 1, 1, 0, 0, 0, 141.5, 14.8);
  this.instance_22.alpha = 0;
  this.instance_22._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_22).wait(40).to({
   _off: false
  }, 0).to({
   alpha: 1
  }, 14, cjs.Ease.get(1)).to({
   _off: true
  }, 46).wait(280));
  this.instance_23 = new lib.txt02_1("synched", 0, false);
  this.instance_23.parent = this;
  this.instance_23.setTransform(108, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance_23._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_23).wait(26).to({
   _off: false
  }, 0).to({
   _off: true
  }, 74).wait(280));
  this.instance_24 = new lib.txt01("synched", 0, false);
  this.instance_24.parent = this;
  this.instance_24.setTransform(108, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance_24._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_24).wait(5).to({
   _off: false
  }, 0).to({
   _off: true
  }, 95).wait(280));
  this.instance_25 = new lib.bubble_1();
  this.instance_25.parent = this;
  this.instance_25.setTransform(225.05, 135.1, 0.0528, 0.0528, 0, 0, 0, 152.5, 152.5);
  this.instance_25._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_25).wait(20).to({
   _off: false
  }, 0).to({
   regY: 152.7,
   scaleX: 0.3413,
   scaleY: 0.3413
  }, 14, cjs.Ease.get(1)).to({
   _off: true
  }, 66).wait(280));
  var mask_2 = new cjs.Shape();
  mask_2._off = true;
  var mask_2_graphics_30 = new cjs.Graphics().p("AT+QPQgWgVAAgfQAAgeAWgWQAVgVAeAAQAfAAAVAVQAWAWAAAeQAAAfgWAVQgVAVgfAAQgeAAgVgVg");
  var mask_2_graphics_31 = new cjs.Graphics().p("ATIQXQgigiAAgxQAAgwAigjQAjgiAwAAQAxAAAiAiQAjAjAAAwQAAAxgjAiQgiAjgxAAQgwAAgjgjg");
  var mask_2_graphics_32 = new cjs.Graphics().p("ASXQfQgvguAAhCQAAhCAvguQAugvBCAAQBBAAAvAvQAuAuAABCQAABCguAuQgvAuhBAAQhCAAgugug");
  var mask_2_graphics_33 = new cjs.Graphics().p("ARpQmQg6g5AAhSQAAhRA6g6QA5g5BSAAQBRAAA5A5QA6A6AABRQAABSg6A5Qg5A6hRAAQhSAAg5g6g");
  var mask_2_graphics_34 = new cjs.Graphics().p("AQ/QsQhDhDAAhgQAAhfBDhEQBEhDBfAAQBgAABEBDQBDBEAABfQAABghDBDQhEBEhgAAQhfAAhEhEg");
  var mask_2_graphics_35 = new cjs.Graphics().p("AQZQyQhMhMAAhtQAAhsBMhNQBNhNBtAAQBsAABNBNQBNBNAABsQAABthNBMQhNBNhsAAQhtAAhNhNg");
  var mask_2_graphics_36 = new cjs.Graphics().p("AP4Q4QhVhVAAh4QAAh5BVhUQBVhVB4AAQB4AABVBVQBVBUAAB5QAAB4hVBVQhVBUh4AAQh4AAhVhUg");
  var mask_2_graphics_37 = new cjs.Graphics().p("APaQ8QhchcAAiCQAAiDBchcQBchcCCAAQCDAABcBcQBcBcAACDQAACChcBcQhcBciDAAQiCAAhchcg");
  var mask_2_graphics_38 = new cjs.Graphics().p("APARAQhihiAAiLQAAiLBihjQBihiCMAAQCLAABiBiQBiBjAACLQAACLhiBiQhiBjiLAAQiMAAhihjg");
  var mask_2_graphics_39 = new cjs.Graphics().p("AOqREQhnhoAAiTQAAiSBnhoQBohoCTAAQCSAABoBoQBnBoAACSQAACThnBoQhoBniSAAQiTAAhohng");
  var mask_2_graphics_40 = new cjs.Graphics().p("AOYRGQhshsAAiYQAAiZBshsQBshsCZAAQCZAABsBsQBsBsAACZQAACYhsBsQhsBsiZAAQiZAAhshsg");
  var mask_2_graphics_41 = new cjs.Graphics().p("AOKRIQhvhvAAidQAAieBvhvQBwhwCdAAQCeAABvBwQBvBvAACeQAACdhvBvQhvBwieAAQidAAhwhwg");
  var mask_2_graphics_42 = new cjs.Graphics().p("AOBRKQhyhyAAihQAAihByhxQBxhyChAAQChAAByByQByBxAAChQAAChhyByQhyByihAAQihAAhxhyg");
  var mask_2_graphics_43 = new cjs.Graphics().p("AN7RLQh0hzAAijQAAijB0hzQBzh0CjAAQCjAABzB0QBzBzAACjQAACjhzBzQhzBzijAAQijAAhzhzg");
  var mask_2_graphics_44 = new cjs.Graphics().p("AN4RMQhzh0AAikQAAijBzh0QB0hzCkAAQCjAAB0BzQB0B0AACjQAACkh0B0Qh0BzijAAQikAAh0hzg");
  this.timeline.addTween(cjs.Tween.get(mask_2).to({
   graphics: null,
   x: 0,
   y: 0
  }).wait(30).to({
   graphics: mask_2_graphics_30,
   x: 140.2687,
   y: 106.0437
  }).wait(1).to({
   graphics: mask_2_graphics_31,
   x: 142.475,
   y: 108.1714
  }).wait(1).to({
   graphics: mask_2_graphics_32,
   x: 144.5179,
   y: 110.1415
  }).wait(1).to({
   graphics: mask_2_graphics_33,
   x: 146.3973,
   y: 111.954
  }).wait(1).to({
   graphics: mask_2_graphics_34,
   x: 148.1133,
   y: 113.6089
  }).wait(1).to({
   graphics: mask_2_graphics_35,
   x: 149.6659,
   y: 115.1062
  }).wait(1).to({
   graphics: mask_2_graphics_36,
   x: 151.0551,
   y: 116.4458
  }).wait(1).to({
   graphics: mask_2_graphics_37,
   x: 152.2808,
   y: 117.6279
  }).wait(1).to({
   graphics: mask_2_graphics_38,
   x: 153.3431,
   y: 118.6523
  }).wait(1).to({
   graphics: mask_2_graphics_39,
   x: 154.2419,
   y: 119.5192
  }).wait(1).to({
   graphics: mask_2_graphics_40,
   x: 154.9774,
   y: 120.2284
  }).wait(1).to({
   graphics: mask_2_graphics_41,
   x: 155.5494,
   y: 120.78
  }).wait(1).to({
   graphics: mask_2_graphics_42,
   x: 155.9579,
   y: 121.1741
  }).wait(1).to({
   graphics: mask_2_graphics_43,
   x: 156.2031,
   y: 121.4105
  }).wait(1).to({
   graphics: mask_2_graphics_44,
   x: 156.2707,
   y: 121.5457
  }).wait(56).to({
   graphics: null,
   x: 0,
   y: 0
  }).wait(280));
  this.instance_26 = new lib.icon02();
  this.instance_26.parent = this;
  this.instance_26.setTransform(273.3, 202.75, 0.7055, 0.7049, 0, 0, 0, 56.8, 57.5);
  this.instance_26._off = true;
  var maskedShapeInstanceList = [this.instance_26];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_26).wait(30).to({
   _off: false
  }, 0).to({
   _off: true
  }, 70).wait(280));
  this.instance_27 = new lib.bubble_1();
  this.instance_27.parent = this;
  this.instance_27.setTransform(273.5, 204.45, 0.0694, 0.0694, 0, 0, 0, 152.1, 152.1);
  this.instance_27._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_27).wait(25).to({
   _off: false
  }, 0).to({
   regX: 152.2,
   regY: 151.8,
   scaleX: 0.3279,
   scaleY: 0.3279
  }, 14, cjs.Ease.get(1)).to({
   _off: true
  }, 61).wait(280));
  var mask_3 = new cjs.Shape();
  mask_3._off = true;
  var mask_3_graphics_10 = new cjs.Graphics().p("AJuPtQgZgYAAgjQAAgiAZgZQAYgYAjAAQAiAAAZAYQAYAZAAAiQAAAjgYAYQgZAZgiAAQgjAAgYgZg");
  var mask_3_graphics_11 = new cjs.Graphics().p("AIpP5QgpgpAAg6QAAg6ApgpQApgpA6AAQA6AAApApQApApAAA6QAAA6gpApQgpApg6AAQg6AAgpgpg");
  var mask_3_graphics_12 = new cjs.Graphics().p("AHqQEQg5g5AAhQQAAhPA5g5QA4g4BQAAQBQAAA4A4QA4A5AABPQAABQg4A5Qg4A4hQAAQhQAAg4g4g");
  var mask_3_graphics_13 = new cjs.Graphics().p("AGvQNQhGhGAAhkQAAhkBGhGQBHhHBjAAQBkAABHBHQBGBGAABkQAABkhGBGQhHBHhkAAQhjAAhHhHg");
  var mask_3_graphics_14 = new cjs.Graphics().p("AF6QWQhUhTAAh2QAAh2BUhUQBThTB2AAQB2AABUBTQBTBUAAB2QAAB2hTBTQhUBUh2AAQh2AAhThUg");
  var mask_3_graphics_15 = new cjs.Graphics().p("AFJQfQhfhgAAiGQAAiHBfhfQBghfCGAAQCHAABfBfQBfBfAACHQAACGhfBgQhfBfiHAAQiGAAhghfg");
  var mask_3_graphics_16 = new cjs.Graphics().p("AEeQmQhphqAAiVQAAiWBphpQBqhqCVAAQCWAABpBqQBqBpAACWQAACVhqBqQhpBpiWAAQiVAAhqhpg");
  var mask_3_graphics_17 = new cjs.Graphics().p("AD4QsQhzhzAAiiQAAiiBzhzQBzhzCiAAQCjAABzBzQByBzAACiQAACihyBzQhzBzijAAQiiAAhzhzg");
  var mask_3_graphics_18 = new cjs.Graphics().p("ADXQyQh7h7AAiuQAAiuB7h6QB7h7CuAAQCtAAB7B7QB7B6AACuQAACuh7B7Qh7B7itAAQiuAAh7h7g");
  var mask_3_graphics_19 = new cjs.Graphics().p("AC7Q3QiCiCAAi3QAAi4CCiBQCCiCC3AAQC3AACCCCQCCCBAAC4QAAC3iCCCQiCCBi3AAQi3AAiCiBg");
  var mask_3_graphics_20 = new cjs.Graphics().p("ACkQ6QiHiHAAi/QAAi/CHiHQCHiHC/AAQDAAACHCHQCHCHAAC/QAAC/iHCHQiHCIjAAAQi/AAiHiIg");
  var mask_3_graphics_21 = new cjs.Graphics().p("ACSQ9QiLiLAAjFQAAjGCLiLQCMiLDFAAQDFAACMCLQCLCLAADGQAADFiLCLQiMCMjFAAQjFAAiMiMg");
  var mask_3_graphics_22 = new cjs.Graphics().p("ACGRAQiOiPAAjKQAAjJCOiPQCOiODKAAQDJAACPCOQCOCPAADJQAADKiOCPQiPCOjJAAQjKAAiOiOg");
  var mask_3_graphics_23 = new cjs.Graphics().p("AB+RBQiPiRAAjMQAAjMCPiQQCQiRDNAAQDMAACQCRQCRCQAADMQAADMiRCRQiQCQjMAAQjNAAiQiQg");
  var mask_3_graphics_24 = new cjs.Graphics().p("AB8RCQiQiRAAjNQAAjNCQiRQCRiRDNAAQDNAACRCRQCRCRAADNQAADNiRCRQiRCRjNAAQjNAAiRiRg");
  this.timeline.addTween(cjs.Tween.get(mask_3).to({
   graphics: null,
   x: 0,
   y: 0
  }).wait(10).to({
   graphics: mask_3_graphics_10,
   x: 76.4191,
   y: 102.9691
  }).wait(1).to({
   graphics: mask_3_graphics_11,
   x: 79.2345,
   y: 105.7866
  }).wait(1).to({
   graphics: mask_3_graphics_12,
   x: 81.8414,
   y: 108.3953
  }).wait(1).to({
   graphics: mask_3_graphics_13,
   x: 84.2397,
   y: 110.7953
  }).wait(1).to({
   graphics: mask_3_graphics_14,
   x: 86.4295,
   y: 112.9867
  }).wait(1).to({
   graphics: mask_3_graphics_15,
   x: 88.4107,
   y: 114.9693
  }).wait(1).to({
   graphics: mask_3_graphics_16,
   x: 90.1834,
   y: 116.7433
  }).wait(1).to({
   graphics: mask_3_graphics_17,
   x: 91.7475,
   y: 118.3085
  }).wait(1).to({
   graphics: mask_3_graphics_18,
   x: 93.1031,
   y: 119.665
  }).wait(1).to({
   graphics: mask_3_graphics_19,
   x: 94.2501,
   y: 120.8129
  }).wait(1).to({
   graphics: mask_3_graphics_20,
   x: 95.1886,
   y: 121.752
  }).wait(1).to({
   graphics: mask_3_graphics_21,
   x: 95.9185,
   y: 122.4825
  }).wait(1).to({
   graphics: mask_3_graphics_22,
   x: 96.4399,
   y: 123.0042
  }).wait(1).to({
   graphics: mask_3_graphics_23,
   x: 96.7527,
   y: 123.3173
  }).wait(1).to({
   graphics: mask_3_graphics_24,
   x: 96.8747,
   y: 123.4747
  }).wait(76).to({
   graphics: null,
   x: 0,
   y: 0
  }).wait(280));
  this.instance_28 = new lib.icon1_2();
  this.instance_28.parent = this;
  this.instance_28.setTransform(144, 197.1, 0.6931, 0.6927, 0, 0, 0, 71.2, 71.2);
  this.instance_28._off = true;
  var maskedShapeInstanceList = [this.instance_28];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_28).wait(10).to({
   _off: false
  }, 0).to({
   _off: true
  }, 90).wait(280));
  this.instance_29 = new lib.bubble_1();
  this.instance_29.parent = this;
  this.instance_29.setTransform(144.9, 198.05, 0.0943, 0.0943, 0, 0, 0, 150.7, 151.2);
  this.instance_29._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_29).wait(5).to({
   _off: false
  }, 0).to({
   regX: 150.4,
   regY: 150.8,
   scaleX: 0.3982,
   scaleY: 0.3982
  }, 14, cjs.Ease.get(1)).to({
   _off: true
  }, 81).wait(280));
  this.instance_30 = new lib.bubble_1();
  this.instance_30.parent = this;
  this.instance_30.setTransform(108.5, 107.6, 0.0543, 0.0543, 0, 0, 0, 150.1, 151);
  this.timeline.addTween(cjs.Tween.get(this.instance_30).to({
   regY: 150.8,
   scaleX: 0.6425,
   scaleY: 0.6425,
   x: 108.55,
   y: 107.5
  }, 14, cjs.Ease.get(1)).to({
   _off: true
  }, 86).wait(280));
  this.instance_31 = new lib.black_plate();
  this.instance_31.parent = this;
  this.timeline.addTween(cjs.Tween.get(this.instance_31).wait(380));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(-3, -0.3, 522.4, 284.8);
 (lib.JnJ_Motilegas_336x280 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.content();
  this.instance.parent = this;
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));
  this.instance_1 = new lib.black_plate();
  this.instance_1.parent = this;
  this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(167.5, 139.7, 169, 140.3);
 lib.properties = {
  id: '1E4D562F91EE4B408F0AC49B20246D76',
  width: 336,
  height: 280,
  fps: 24,
  color: "#FFFFFF",
  opacity: 1.00,
  manifest: [{
   src: "bubble.png",
   id: "bubble"
  }, {
   src: "fish1.png",
   id: "fish1"
  }, {
   src: "fish2.png",
   id: "fish2"
  }, {
   src: "icon2.png",
   id: "icon2"
  }, {
   src: "icon3.png",
   id: "icon3"
  }, {
   src: "packshot.png",
   id: "packshot"
  }, {
   src: "t2_1_t2_lact.png",
   id: "t2_1_t2_lact"
  }, {
   src: "t1_t1_lact.png",
   id: "t1_t1_lact"
  }, {
   src: "icon1_1_icon1_lact.png",
   id: "icon1_1_icon1_lact"
  }, ],
  preloads: []
 };
 (lib.Stage = function(canvas) {
  createjs.Stage.call(this, canvas);
 }).prototype = p = new createjs.Stage();
 p.setAutoPlay = function(autoPlay) {
  this.tickEnabled = autoPlay;
 }
 p.play = function() {
  this.tickEnabled = true;
  this.getChildAt(0).gotoAndPlay(this.getTimelinePosition())
 }
 p.stop = function(ms) {
  if (ms) this.seek(ms);
  this.tickEnabled = false;
 }
 p.seek = function(ms) {
  this.tickEnabled = true;
  this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000);
 }
 p.getDuration = function() {
  return this.getChildAt(0).totalFrames / lib.properties.fps * 1000;
 }
 p.getTimelinePosition = function() {
  return this.getChildAt(0).currentFrame / lib.properties.fps * 1000;
 }
 an.bootcompsLoaded = an.bootcompsLoaded || [];
 if (!an.bootstrapListeners) {
  an.bootstrapListeners = [];
 }
 an.bootstrapCallback = function(fnCallback) {
  an.bootstrapListeners.push(fnCallback);
  if (an.bootcompsLoaded.length > 0) {
   for (var i = 0; i < an.bootcompsLoaded.length; ++i) {
    fnCallback(an.bootcompsLoaded[i]);
   }
  }
 };
 an.compositions = an.compositions || {};
 an.compositions['1E4D562F91EE4B408F0AC49B20246D76'] = {
  getStage: function() {
   return exportRoot.getStage();
  },
  getLibrary: function() {
   return lib;
  },
  getSpriteSheet: function() {
   return ss;
  },
  getImages: function() {
   return img;
  }
 };
 an.compositionLoaded = function(id) {
  an.bootcompsLoaded.push(id);
  for (var j = 0; j < an.bootstrapListeners.length; j++) {
   an.bootstrapListeners[j](id);
  }
 }
 an.getComposition = function(id) {
  return an.compositions[id];
 }
 an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {
  var lastW, lastH, lastS = 1;
  window.addEventListener('resize', resizeCanvas);
  resizeCanvas();

  function resizeCanvas() {
   var w = lib.properties.width,
    h = lib.properties.height;
   var iw = window.innerWidth,
    ih = window.innerHeight;
   var pRatio = window.devicePixelRatio || 1,
    xRatio = iw / w,
    yRatio = ih / h,
    sRatio = 1;
   if (isResp) {
    if ((respDim == 'width' && lastW == iw) || (respDim == 'height' && lastH == ih)) {
     sRatio = lastS;
    } else if (!isScale) {
     if (iw < w || ih < h) sRatio = Math.min(xRatio, yRatio);
    } else if (scaleType == 1) {
     sRatio = Math.min(xRatio, yRatio);
    } else if (scaleType == 2) {
     sRatio = Math.max(xRatio, yRatio);
    }
   }
   domContainers[0].width = w * pRatio * sRatio;
   domContainers[0].height = h * pRatio * sRatio;
   domContainers.forEach(function(container) {
    container.style.width = w * sRatio + 'px';
    container.style.height = h * sRatio + 'px';
   });
   stage.scaleX = pRatio * sRatio;
   stage.scaleY = pRatio * sRatio;
   lastW = iw;
   lastH = ih;
   lastS = sRatio;
   stage.tickOnUpdate = false;
   stage.update();
   stage.tickOnUpdate = true;
  }
 }
})(createjs = createjs || {}, AdobeAn = AdobeAn || {});
var createjs, AdobeAn;