(function(cjs, an) {
 var p;
 var lib = {};
 var ss = {};
 var img = {};
 lib.ssMetadata = [];
 (lib.bubble = function() {
  this.initialize(img.bubble);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 448, 448);
 (lib.fish1 = function() {
  this.initialize(img.fish1);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 342, 311);
 (lib.fish2 = function() {
  this.initialize(img.fish2);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 346, 266);
 (lib.icon2 = function() {
  this.initialize(img.icon2);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 170, 172);
 (lib.icon3 = function() {
  this.initialize(img.icon3);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 214, 214);
 (lib.packshot = function() {
  this.initialize(img.packshot);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 352, 170);

 function mc_symbol_clone() {
  var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
  clone.gotoAndStop(this.currentFrame);
  clone.paused = this.paused;
  clone.framerate = this.framerate;
  return clone;
 }

 function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
  var prototype = cjs.extend(symbol, cjs.MovieClip);
  prototype.clone = mc_symbol_clone;
  prototype.nominalBounds = nominalBounds;
  prototype.frameBounds = frameBounds;
  return prototype;
 }
 (lib.t4 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#0C593C").s().p("AAAAJIgIAOIgGgFIAJgPIgOgEIACgJIAOAFIAAgRIAHAAIAAARIANgFIADAJIgNAEIAIAPIgHAFg");
  this.shape.setTransform(112.75, 204.15);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#0C593C").s().p("AgaBZQgLgFgJgMQgHgKgDgLQgDgLAAgMIAdAAQAAAFABAGIADALQAFAIAFAEQAGADAFABIAHABIAJgCQAFgBAEgDQAGgFACgHIACgMIgBgHIgCgJQgCgEgFgDQgEgDgFAAIgJgBIgPAAIAAgaIANAAIAIAAIAHgDQADgCADgFQADgFAAgIQAAgIgCgFQgCgEgDgDQgFgEgFgBIgHgBIgJABQgFABgEAEQgGAFgCAGQgCAHAAAGIgeAAIACgLQAAgHADgHQACgHAEgGQAJgKAMgFQAMgEAPAAIAMABIAOAEQAHADAGAFQAHAGADAHQADAHABAGIABALQAAAGgCAIQgCAJgHAHIgFAFIgIADIAAABIAJADIAHAEQAFAFAEAJQAEAJAAAOQAAAPgFAKQgGAKgGAFQgGAFgKADQgKAEgRAAIgCAAQgNAAgLgEg");
  this.shape_1.setTransform(103.275, 211.9775);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#0C593C").s().p("AAkBYIgKglIgzAAIgKAlIgeAAIA0ivIAbAAIA0CvgAATAZIgThLIgSBLIAlAAg");
  this.shape_2.setTransform(90.4, 212);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#0C593C").s().p("Ag3BYIAAiuIA3AAQAOgBALADQALADAIAKQAIAKACAKQACALAAAIQAAAQgFAKQgEAJgGAGQgJAJgLADQgKADgLgBIgZAAIAABBgAgZgCIAXAAQAEAAAGgBQAGgCAFgFIAEgHQACgFABgJQAAgHgCgFQgCgGgDgDQgFgFgGgBQgGgCgEAAIgXAAg");
  this.shape_3.setTransform(78.2042, 211.9964);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#0C593C").s().p("AgaBCQgFgBgFgCQgFgDgFgJQgFgIAAgMQAAgGACgGQABgGADgFQAEgFAEgDQAFgCAFgCIAMgDIARgDIAGgCIAGgCIAAgDIABgHQAAgFgBgFQgCgFgEgDIgGgEIgDAAQgIABgEADQgEADgCAEIgCAGIAAAGIgaAAIABgMQACgHADgGQAFgIAHgEQAHgEAHgBIAOgCIANACQAJACAIAFQAIAHADAJQADAJAAALIAAAyIAAAKIABADQAAABABAAQAAAAAAABQABAAAAAAQABAAAAAAIAFAAIAAAWIgHAAIgIAAIgGAAQgFgBgCgDIgFgFIgCgHIgBAAQgBAFgEADIgDADQgFAEgFACQgGABgIAAIgKgBgAANAEIgCABIgFACIgGACIgIADIgFABQgGAEgBAEQgCAEABAFIAAAGQAAAEADADIAFADIAFABQAEAAAEgCQADgCAFgFQAEgHACgIIABgPIAAgFIgCABg");
  this.shape_4.setTransform(60.45, 214.3);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#0C593C").s().p("AgOBDQgHgBgHgEQgJgGgFgKQgFgKAAgMIAaAAIABAIIAEAIQAEAGAFABIAHABIAFgBQADAAAEgDQADgCACgEQACgEAAgHQABgDgCgEQgBgEgEgDQgDgDgEAAIgGAAIgKAAIAAgUIAIAAIAFgBQADAAADgDQAEgCABgFQACgEgBgDQAAgFgBgDQgBgFgDgBQgCgDgEgBIgEgBIgIACQgEABgDAFQgCAEAAAEIgBAHIgaAAQAAgJADgIQADgJAFgFQAHgIAJgCQAKgCAHgBQAHAAAJACQAJACAIAIQAFAFADAHQACAHAAAIQABAGgCAGQgCAFgEAEIgFAEIgFACIAAABIAHABQAEACAEAEQAEAFABAFQACAEAAAHQAAAIgDAHQgCAGgDAFIgHAGQgIAGgJACIgQABIgOgBg");
  this.shape_5.setTransform(49.455, 214.4);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#0C593C").s().p("AgaBCQgFAAgFgDQgFgEgFgHQgFgJABgMQAAgHABgFQABgGADgFQAEgFAEgDQAFgCAFgCIANgDIARgDIAFgBIAGgEIAAgCIABgHQAAgGgBgEQgCgFgEgDIgFgDIgFgBQgHAAgEADQgEAEgCAEIgCAGIAAAGIgaAAIABgMQACgHADgGQAFgIAHgEQAHgEAHgBIANgCIAOACQAIABAJAGQAIAHADAJQACAJAAALIAAAyIABAJIABAEQAAAAABABQAAAAAAABQABAAAAAAQAAAAABABIAEAAIAAAUIgGABIgHAAIgHgBQgFAAgDgDIgEgGIgCgGIgBAAQgCAFgCACIgFAFQgEADgFABQgGACgIAAIgKgBgAANAEIgCACIgFACIgGABIgIACIgFACQgGAEgBAEQgCAEABAEIAAAHQAAADADAEIAFADIAFABQAEAAAEgCQAEgCADgFQAFgGACgJIABgPIAAgFIgCABg");
  this.shape_6.setTransform(115.1, 189.85);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#0C593C").s().p("AgtBAIgFgBIAAgVQAHACAEgDQAFgCACgEQACgDABgGIACgSIAAgeIAAgpIBOAAIAAB+IgbAAIAAhpIgZAAIAAAXIAAAVIAAAMIgBAHQgBAOgEAHQgEAIgEAFQgEAEgHACQgGADgIAAIgFAAg");
  this.shape_7.setTransform(103.225, 190);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#0C593C").s().p("AgTBXIgHAAIgIgBIAAgVIADABIAGAAQAGAAAEgEQADgEADgHIADgLIgvh+IAeAAIAbBbIABAAIAXhbIAaAAIgnCJIgDAMQgDAHgEAGQgFAHgFACQgFACgGAAIgDAAg");
  this.shape_8.setTransform(93.35, 192.3042);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#0C593C").s().p("AgJBEQgGgCgHgDQgGgEgHgHQgGgIgEgNQgEgNAAgSIABgOQABgJADgKQADgKAGgIQAIgJAKgEQAKgEAHAAQAIAAAKADQAJACAJAKQAGAGAEAJQADAJABAJIgaAAIgCgJIgEgIQgCgFgEgDQgEgCgGAAQgFAAgEADQgEAEgDAFIgEANIgCANIAAAJIABARQABAJAEAIQADAHAFADQAFAEAFAAQAGAAAEgEQAEgDACgFIADgLIABgIIAaAAQAAAIgDAJQgDAJgFAIQgJALgKADQgJAEgJAAIgLgBg");
  this.shape_9.setTransform(82.925, 189.95);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.f("#0C593C").s().p("AAUA/IAAhpIgnAAIAABpIgcAAIAAh+IBfAAIAAB+g");
  this.shape_10.setTransform(71.45, 189.95);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.f("#0C593C").s().p("AgZBCQgGAAgEgDQgHgEgEgHQgEgJgBgMQABgHABgFQABgGAEgFQADgFAEgDQAEgCAHgCIAMgDIAQgDIAHgBIAEgEIABgCIABgHQAAgGgCgEQgBgFgDgDIgHgDIgEgBQgHAAgEADQgEAEgCAEIgCAGIgBAGIgaAAIACgMQABgHAEgGQAFgIAHgEQAHgEAHgBIANgCIAOACQAIABAJAGQAIAHACAJQADAJAAALIAAAyIABAJIABAEQAAAAABABQAAAAAAABQABAAAAAAQAAAAABABIAEAAIAAAUIgGABIgHAAIgIgBQgDAAgEgDIgEgGIgCgGIAAAAQgDAFgCACIgEAFQgFADgFABQgGACgIAAIgJgBgAANAEIgCACIgGACIgEABIgIACIgHACQgEAEgCAEQgCAEAAAEIABAHQAAADAEAEIADADIAHABQADAAAEgCQADgCAFgFQADgGACgJIACgPIAAgFIgCABg");
  this.shape_11.setTransform(60.05, 189.85);
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.f("#0C593C").s().p("AAQA/Igig9IAAA9IgcAAIAAh+IAcAAIAAA2IAgg2IAeAAIgqA8IAtBCg");
  this.shape_12.setTransform(50.125, 189.95);
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.f("#0C593C").s().p("AAkBXIgKgkIgzAAIgLAkIgeAAIA1iuIAbAAIA1CugAATAYIgThKIgSBKIAlAAg");
  this.shape_13.setTransform(94.4, 163.1);
  this.shape_14 = new cjs.Shape();
  this.shape_14.graphics.f("#0C593C").s().p("AAcBXIAAhOIg3AAIAABOIgeAAIAAiuIAeAAIAABHIA3AAIAAhHIAeAAIAACug");
  this.shape_14.setTransform(80.975, 163.1);
  this.shape_15 = new cjs.Shape();
  this.shape_15.graphics.f("#0C593C").s().p("AAwBrIAAgnIhfAAIAAAnIgaAAIgBhCIAMAAIAGgJQADgHAEgMQAEgLADgOIACgTIACgUIABgSIAAglIBcAAIAACTIAUAAIgBBCgAgKg7IgBAYIgDAXQgCAPgEANQgFAOgFALIA5AAIAAh5IglAAg");
  this.shape_15.setTransform(66.55, 165.075);
  this.shape_16 = new cjs.Shape();
  this.shape_16.graphics.f("#0C593C").s().p("AAABdQgJAAgLgDQgLgDgKgJQgPgOgGgUQgHgUABgYQgBgXAHgUQAGgUAPgOQAKgJALgDQALgDAJAAQALAAAKADQALADAKAJQAPAOAHAUQAFAUAAAXQAAAYgFAUQgHAUgPAOQgKAJgLADQgJADgJAAIgDAAgAgLg/QgHACgGAIQgFAHgDAJQgDAKgCAKIgBARIABATQACAKADAJQADAKAFAHQAGAHAHACQAHADAEAAQAGAAAGgDQAGgCAHgHQAFgHADgKQADgJACgKIABgTIgBgRQgCgKgDgKQgDgJgFgHQgHgIgGgCQgGgCgGAAQgEAAgHACg");
  this.shape_16.setTransform(51.85, 163.0786);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_16
   }, {
    t: this.shape_15
   }, {
    t: this.shape_14
   }, {
    t: this.shape_13
   }, {
    t: this.shape_12
   }, {
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
 }).prototype = getMCSymbolPrototype(lib.t4, new cjs.Rectangle(42, 146.5, 335, 83.4), null);
 (lib.t3 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#0C593C").s().p("AgOBYIAAgiIAdAAIAAAigAgIAhIgGg7IAAg9IAdAAIAAA9IgHA7g");
  this.shape.setTransform(118.05, 197.05);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#0C593C").s().p("AgOBDQgHgBgHgEQgJgGgFgKQgFgKAAgMIAaAAIABAIIAEAIQAEAFAFACIAHABIAFAAQADgBAEgDQADgCACgEQACgEAAgHQABgDgCgEQgBgEgEgDQgDgDgEAAIgGAAIgKAAIAAgUIAIAAIAFgBQADAAADgCQAEgDABgFQACgEgBgDQAAgFgBgEQgBgEgDgBQgCgDgEgBIgEgBIgIABQgEACgDAFQgCAEAAAEIgBAHIgaAAQAAgJADgIQADgIAFgGQAHgIAJgCQAKgCAHgBQAHAAAJACQAJACAIAIQAFAFADAHQACAHAAAIQABAGgCAGQgCAFgEAEIgFAEIgFACIAAABIAHABQAEACAEAEQAEAFABAFQACAEAAAHQAAAIgDAHQgCAHgDAEIgHAGQgIAGgJACIgQABIgOgBg");
  this.shape_1.setTransform(109.105, 199.45);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#0C593C").s().p("AgaBDQgFgCgFgCQgFgDgFgJQgFgHAAgNQAAgGACgGQABgGADgFQAEgFAEgDQAFgCAFgCIAMgDIARgDIAGgCIAGgCIAAgDIABgHQAAgGgBgEQgCgFgEgDIgGgEIgDAAQgIAAgEAEQgEADgCADIgCAHIAAAHIgaAAIABgOQACgGADgGQAFgIAHgEQAHgEAHgBIAOgCIANACQAJACAIAGQAIAGADAJQADAJAAALIAAAyIAAAKIABADQAAABABAAQAAAAAAABQABAAAAAAQABAAAAAAIAFAAIAAAWIgHAAIgIAAIgGAAQgFgBgCgDIgFgFIgCgHIAAAAQgCAFgEADIgDADQgFAEgFACQgGABgIAAIgKAAgAANAFIgCAAIgFACIgGACIgIADIgFABQgGAEgBAEQgCAEABAFIAAAFQAAAFADADIAFADIAFABQAEAAAEgCQADgCAFgFQAEgGACgJIABgPIAAgEIgCABg");
  this.shape_2.setTransform(98.25, 199.35);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#0C593C").s().p("AglBAIAAh+IBLAAIAAAUIgvAAIAABqg");
  this.shape_3.setTransform(89, 199.45);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#0C593C").s().p("AgQBCQgKgDgJgKQgGgGgFgNQgEgMgBgVIABgOQABgKADgJQADgKAHgIQAJgKAKgEQAKgDAIgBQAKAAALAEQAKAFAIAMQAGAJADAOQACANABASIhKAAQAAAIACAJQACAIAEAHQAFAFAEADIAHABIAIgBQAFgCAEgGIADgGQABgDAAgDIAbAAQgBAIgEAHQgDAIgFAFQgJAJgKACQgKACgHAAQgIABgJgDgAgIgsIgGAFQgEAHgCAHIgCANIAtAAIAAgGIgCgJIgDgJQgEgFgEgDQgFgDgEAAQgFAAgEADg");
  this.shape_4.setTransform(78.175, 199.45);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#0C593C").s().p("AgtA/IgFAAIAAgUQAHABAEgCQAFgCACgFQACgDABgGIACgSIAAgdIAAgqIBOAAIAAB+IgbAAIAAhqIgZAAIAAAYIAAAUIAAAOIgBAHQgBANgEAIQgEAHgEAEQgEAFgHACQgGADgIAAIgFgBg");
  this.shape_5.setTransform(65.975, 199.5);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#0C593C").s().p("AAWBAIAAhaIgpBaIgdAAIAAh+IAbAAIAABZIAphZIAeAAIAAB+g");
  this.shape_6.setTransform(54.95, 199.45);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#0C593C").s().p("AgNBAIAAhqIgiAAIAAgUIBfAAIAAAUIgiAAIAABqg");
  this.shape_7.setTransform(44.2, 199.45);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#0C593C").s().p("AgaA9QgLgIgIgPQgDgIgCgKQgCgKAAgKQAAgJACgKQACgJADgJQAIgPALgIQAMgHAOgBQAQABALAHQAMAIAGAPQAFAJABAJIACATIgCAUQgBAKgFAIQgGAPgMAIQgLAHgQAAQgOAAgMgHgAgKgrQgEAEgEAGIgDALIgBAMIgBAKIABALIABALIADAMQAEAGAEAFQAFADAFAAQAGAAAGgDQAEgFACgGQADgFABgHIACgLIAAgLIAAgKIgCgMQgBgGgDgFQgCgGgEgEQgGgEgGAAQgFAAgFAEg");
  this.shape_8.setTransform(33.65, 199.45);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#0C593C").s().p("AAwBYIAAh3IABgTIgBAAIgkCKIgXAAIgkiKIgBAAIABATIAAB3IgdAAIAAivIAqAAIAiCEIAjiEIAqAAIAACvg");
  this.shape_9.setTransform(18.45, 197.05);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.f("#0C593C").s().p("AgQBCQgKgDgJgKQgGgGgFgMQgEgNgBgVIABgPQABgIADgKQADgKAHgIQAJgKAKgEQAKgEAIAAQAKABALAEQAKAEAIAMQAGAJADANQACAOABATIhKAAQAAAHACAJQACAJAEAFQAFAHAEABIAHACIAIgCQAFgBAEgGIADgFQABgDAAgEIAbAAQgBAIgEAIQgDAHgFAFQgJAIgKADQgKADgHAAQgIAAgJgDgAgIgsIgGAGQgEAFgCAIIgCANIAtAAIAAgGIgCgJIgDgJQgEgGgEgDQgFgCgEAAQgFAAgEADg");
  this.shape_10.setTransform(126.775, 176);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.f("#0C593C").s().p("AgNA/IAAhpIghAAIAAgVIBdAAIAAAVIghAAIAABpg");
  this.shape_11.setTransform(116.4, 176);
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.f("#0C593C").s().p("AAWBXIAAhZIgpBZIgdAAIAAh+IAbAAIAABaIAphaIAeAAIAAB+gAgMg1IgJgEIgFgDQgDgEgEgGQgEgHgCgJIAWAAIACAFIADAHQACADAFACIAFABIAHgBQAEgCADgDIACgHIABgFIAXAAQgBAJgFAHQgEAGgDAEIgEADIgJAEQgFACgJAAQgHAAgFgCg");
  this.shape_12.setTransform(105.65, 173.6);
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.f("#0C593C").s().p("AgaBCQgFAAgFgDQgFgEgFgHQgFgJABgMQAAgHABgFQABgGADgFQAEgFAEgDQAFgCAFgCIANgDIARgDIAFgBIAGgEIAAgCIABgHQAAgGgBgEQgCgFgEgDIgFgDIgFgBQgHAAgEADQgEAEgCAEIgCAGIAAAGIgaAAIABgMQACgHADgGQAFgIAHgEQAHgEAHgBIANgCIAOACQAIABAJAGQAIAHADAJQACAJAAALIAAAyIABAJIABAEQAAAAABABQAAAAAAABQABAAAAAAQABAAAAABIAFAAIAAAUIgHABIgIAAIgGgBQgFAAgCgDIgFgGIgCgGIgBAAQgBAFgDACIgFAFQgEADgFABQgGACgIAAIgKgBgAANAEIgCACIgFACIgGABIgIACIgFACQgFAEgCAEQgCAEABAEIAAAHQAAADADAEIAFADIAFABQAEAAAEgCQAEgCADgFQAEgGADgJIABgPIAAgFIgCABg");
  this.shape_13.setTransform(93.85, 175.9);
  this.shape_14 = new cjs.Shape();
  this.shape_14.graphics.f("#0C593C").s().p("AAlA/IAAhPIABgNIgBAAIgaBcIgVAAIgahcIgBAAIABANIAABPIgbAAIAAh+IAkAAIAbBfIAchfIAkAAIAAB+g");
  this.shape_14.setTransform(80.475, 176);
  this.shape_15 = new cjs.Shape();
  this.shape_15.graphics.f("#0C593C").s().p("AAWA/IAAhZIgpBZIgeAAIAAh+IAcAAIAABaIAphaIAdAAIAAB+g");
  this.shape_15.setTransform(66.6, 176);
  this.shape_16 = new cjs.Shape();
  this.shape_16.graphics.f("#0C593C").s().p("AATA/IAAg4IglAAIAAA4IgbAAIAAh+IAbAAIAAAzIAlAAIAAgzIAbAAIAAB+g");
  this.shape_16.setTransform(54.5, 176);
  this.shape_17 = new cjs.Shape();
  this.shape_17.graphics.f("#0C593C").s().p("AAWA/IAAhZIgpBZIgeAAIAAh+IAcAAIAABaIAphaIAdAAIAAB+g");
  this.shape_17.setTransform(42.4, 176);
  this.shape_18 = new cjs.Shape();
  this.shape_18.graphics.f("#0C593C").s().p("Ag0BZIAAisIAaAAIAAAMIABAAIAEgGIAGgEQADgDAGgCQAFgCAGAAQAJAAAIADQAJAEAGAJQAIAJADALQAEALAAAIIABANIgBAOIgDAPQgCAIgEAHQgDAGgGAGQgFAFgHADQgIAEgJAAQgFAAgEgCIgJgEIgGgFIgFgGIAAAAIAAA6gAgLhAQgFADgFAKQgDAIgBAIIgBAQIAAAKIACAMIAGANQAEAGAEADQAFACAEAAQADAAAEgCQAFgCAFgHQADgFACgIQADgIAAgOIgBgPQgBgIgDgIQgEgLgGgDQgGgEgEAAQgEAAgGAEg");
  this.shape_18.setTransform(30.2333, 178.075);
  this.shape_19 = new cjs.Shape();
  this.shape_19.graphics.f("#0C593C").s().p("AAcBXIAAiTIg2AAIAACTIgeAAIAAitIBxAAIAACtg");
  this.shape_19.setTransform(16.425, 173.6);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_19
   }, {
    t: this.shape_18
   }, {
    t: this.shape_17
   }, {
    t: this.shape_16
   }, {
    t: this.shape_15
   }, {
    t: this.shape_14
   }, {
    t: this.shape_13
   }, {
    t: this.shape_12
   }, {
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
 }).prototype = getMCSymbolPrototype(lib.t3, new cjs.Rectangle(7, 157, 269, 57.900000000000006), null);
 (lib.t2_1_t2_lact = function() {
  this.initialize(img.t2_1_t2_lact);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 85, 49);
 (lib.t2_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_t2 = new lib.t2_1_t2_lact();
  this.cvr_t2.name = "cvr_t2";
  this.cvr_t2.parent = this;
  this.cvr_t2.setTransform(12, 345, 0.5, 0.5);
  this.timeline.addTween(cjs.Tween.get(this.cvr_t2).wait(1));
  this.timeline.addTween(cjs.Tween.get(this.cvr_t2).wait(1));
 }).prototype = getMCSymbolPrototype(lib.t2_1, new cjs.Rectangle(10, 343, 89, 82.69999999999999), null);
 (lib.t2 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#0C593C").s().p("AAAALIgLAVIgJgIIAMgUIgSgGIADgMIATAIIAAgYIAJAAIAAAYIATgIIADAMIgSAGIAMAUIgJAIg");
  this.shape.setTransform(69.75, 230);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#0C593C").s().p("AAWA/IAAhZIgpBZIgeAAIAAh9IAcAAIAABZIAphZIAdAAIAAB9g");
  this.shape_1.setTransform(61.85, 239.9);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#0C593C").s().p("AgtBAIgFgBIAAgVQAHACAEgDQAFgCACgEQACgDABgGIACgSIAAgeIAAgpIBOAAIAAB+IgbAAIAAhpIgZAAIAAAXIAAAVIAAAMIgBAHQgBAOgEAHQgEAIgEAFQgEAEgHACQgGADgIAAIgFAAg");
  this.shape_2.setTransform(49.675, 239.95);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#0C593C").s().p("AgaA9QgMgIgGgPQgEgJgCgKQgCgKAAgJQAAgIACgKQACgLAEgIQAGgPAMgIQALgIAQAAQAPAAAMAIQALAIAHAPQADAIACALIACASIgCATQgCAKgDAJQgHAPgLAIQgMAIgPAAQgQAAgLgIgAgKgsQgEAEgDAHIgEAMIgCAMIAAAJIAAAKIACANIAEALQADAHAEADQAEAEAHAAQAGAAAFgEQAEgDADgHQACgFABgGIACgNIAAgKIAAgJIgCgMQgBgHgCgFQgDgHgEgEQgFgDgGAAQgHAAgEADg");
  this.shape_3.setTransform(39.25, 239.9);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#0C593C").s().p("AgQBcQgIgDgFgEIgJgIQgHgJgDgLQgEgMAAgLIgBgVQAAgSABgNQABgNACgIIADgLQAEgKAGgHQAGgHAJgEIAOgEIAQgDQAJgBADgCQADgDAAgDIAUAAIgBAIIgCAHQgEAKgIAEQgHADgKACIgRAEQgJACgGAGQgHAFgDALIgCAJIgBAJIAAAHIABAAIADgJIAGgJQAFgHAIgDQAHgEAJAAQAKAAAHAEQAIADAFAGQAGAGAEAJQAEAJACAJQACAKAAAKQAAAMgDANQgDANgIAKQgJALgKAEQgKAFgLAAQgJAAgHgDgAgHgPQgGADgEAIQgEAHgCAJQgBAJAAAHQAAAGABAJQABAJAEAJQAFAIAFADQAFACADAAQAFAAAFgDQAFgDAEgIQAEgIABgJQABgJAAgGIAAgKIgCgMIgEgLQgEgHgEgDQgFgDgFAAQgDAAgFADg");
  this.shape_4.setTransform(27.625, 237.275);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#0C593C").s().p("AAWA/IAAhZIgpBZIgdAAIAAh9IAbAAIAABZIAphZIAeAAIAAB9g");
  this.shape_5.setTransform(10.4, 239.9);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#0C593C").s().p("AAWA/IAAhZIgpBZIgdAAIAAh+IAbAAIAABaIAphaIAeAAIAAB+g");
  this.shape_6.setTransform(151, 214.45);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#0C593C").s().p("AAWA/IAAhZIgpBZIgdAAIAAh+IAbAAIAABaIAphaIAeAAIAAB+g");
  this.shape_7.setTransform(140, 214.45);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#0C593C").s().p("AATA/IAAg4IglAAIAAA4IgbAAIAAh+IAbAAIAAAzIAlAAIAAgzIAbAAIAAB+g");
  this.shape_8.setTransform(129.3, 214.45);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#0C593C").s().p("AgaBDQgFgCgEgCQgGgEgFgHQgEgJgBgMQABgGABgGQACgGADgFQADgFAEgDQAFgCAGgCIALgDIARgDIAHgBIAEgEIABgCIABgHQAAgGgCgEQgBgFgDgDIgHgEIgDAAQgIAAgEADQgEAEgCADIgCAHIgBAHIgZAAIABgOQACgGADgGQAFgIAHgEQAHgEAHgBIAOgBIANABQAIABAJAHQAIAGACAJQAEAJAAAMIAAAxIAAAJIABAEQAAAAABABQAAAAAAABQABAAAAAAQABAAAAAAIAFAAIAAAVIgHABIgIAAIgHgBQgDAAgDgDIgFgGIgCgGIAAAAQgDAFgDACIgDAFQgFADgFABQgGADgIAAIgKgBgAANAFIgCABIgFABIgFACIgJACIgGADQgFADgBAEQgCAEAAAEIABAGQABAEADAEIADADIAGABQAEAAAEgCQADgCAFgFQADgHACgIIACgPIAAgEIgCABg");
  this.shape_9.setTransform(119.2, 214.35);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.f("#0C593C").s().p("AgtA/IAAh+IA2AAIANACQAGABAGAFQAFAFACAGIACANQAAAGgCAFQgBAFgEAEQgEAEgDACIgGADIAAAAIAIACIAGAFQAEADADAGQACAGAAAJQAAALgDAFQgDAHgEADQgDADgHADQgHACgKAAgAgSArIARAAIAGgBIAHgCQACgCACgDQACgDAAgGQAAgFgBgEQgCgDgCgBQgDgEgFgBIgHAAIgQAAgAgSgLIAPAAIAGgBQAEgBADgDQADgCABgDIABgHIgBgHQgBgDgEgCIgEgBIgFgBIgSAAg");
  this.shape_10.setTransform(109.525, 214.45);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.f("#0C593C").s().p("AgaA9QgLgIgHgPQgEgJgCgKQgCgKAAgJQAAgIACgLQACgKAEgIQAHgPALgIQALgIAPABQAQgBALAIQAMAIAGAPQAEAIADAKIABATIgBATQgDAKgEAJQgGAPgMAIQgLAHgQABQgPgBgLgHgAgKgsQgFAFgDAGIgCAMIgDALIAAAKIAAAKIADANIACALQADAGAFAEQAFAEAFAAQAHAAAEgEQAFgEACgGQADgFABgGIACgNIAAgKIAAgKIgCgLQgBgHgDgFQgCgGgFgFQgEgDgHAAQgFAAgFADg");
  this.shape_11.setTransform(99.05, 214.45);
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.f("#0C593C").s().p("AgOBEQgHgCgHgEQgJgGgFgKQgFgKAAgMIAaAAIABAJIAEAIQAEAEAFACIAHABIAFAAQADgBAEgDQADgCACgEQACgEAAgHQABgDgCgEQgBgEgEgDQgDgCgEgBIgGgBIgKAAIAAgTIAIAAIAFAAQADgBADgCQAEgEABgDQACgEgBgEQAAgFgBgEQgBgDgDgDQgCgCgEgBIgEgBIgIABQgEACgDAFQgCAEAAAFIgBAGIgaAAQAAgJADgIQADgJAFgFQAHgHAJgDQAKgCAHAAQAHAAAJACQAJACAIAHQAFAFADAGQACAIAAAIQABAGgCAFQgCAFgEAFIgFAFIgFABIAAABIAHABQAEACAEAEQAEAFABAFQACAFAAAFQAAAKgDAGQgCAGgDAFIgHAHQgIAFgJACIgQACIgOgBg");
  this.shape_12.setTransform(89.005, 214.45);
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.f("#0C593C").s().p("AgaBDQgFgCgFgCQgFgEgFgHQgFgJABgMQAAgGABgGQABgGADgFQAEgFAEgDQAFgCAFgCIANgDIARgDIAFgBIAGgEIAAgCIABgHQAAgGgBgEQgCgFgEgDIgFgEIgFAAQgHAAgEADQgEAEgCADIgCAHIAAAHIgbAAIACgOQACgGADgGQAFgIAHgEQAHgEAHgBIANgBIAOABQAIABAJAHQAIAGADAJQACAJAAAMIAAAxIABAJIABAEQAAAAABABQAAAAAAABQABAAAAAAQAAAAABAAIAEAAIAAAVIgGABIgHAAIgHgBQgFAAgCgDIgFgGIgCgGIgBAAQgCAFgCACIgFAFQgEADgFABQgGADgIAAIgKgBgAANAFIgCABIgGABIgFACIgIACIgFADQgGADgBAEQgCAEABAEIAAAGQAAAEADAEIAFADIAFABQAEAAAEgCQAEgCADgFQAFgHACgIIABgPIAAgEIgCABg");
  this.shape_13.setTransform(79.55, 214.35);
  this.shape_14 = new cjs.Shape();
  this.shape_14.graphics.f("#0C593C").s().p("Ag0BZIAAisIAaAAIAAAMIABAAIAEgGIAGgEQADgDAGgCQAFgCAGAAQAJAAAIADQAJAEAGAJQAIAJADALQAEALAAAIIABANIgBAOIgDAPQgCAIgEAHQgDAGgGAGQgFAFgHADQgIAEgJAAQgFAAgEgCIgJgEIgGgFIgFgGIAAAAIAAA6gAgLhAQgFADgFAKQgDAIgBAIIgBAQIAAAKIACAMIAGANQAEAGAEADQAFACAEAAQADAAAEgCQAFgCAFgHQADgFACgIQADgIAAgOIgBgPQgBgIgDgIQgEgLgGgDQgGgEgEAAQgEAAgGAEg");
  this.shape_14.setTransform(69.2833, 216.525);
  this.shape_15 = new cjs.Shape();
  this.shape_15.graphics.f("#0C593C").s().p("AgQBcQgIgDgFgEIgJgIQgHgJgDgLQgEgMAAgLIgBgVQAAgSABgNQABgNACgIIADgLQAEgKAGgHQAGgHAJgEIAOgEIAQgDQAJgBADgCQADgDAAgDIAUAAIgBAIIgCAHQgEAKgIAEQgHADgKACIgRAEQgJACgGAGQgHAFgDALIgCAJIgBAJIAAAHIABAAIADgJIAGgJQAFgHAIgDQAHgEAJAAQAKAAAHAEQAIADAFAGQAGAGAEAJQAEAJACAJQACAKAAAKQAAAMgDANQgDANgIAKQgJALgKAEQgKAFgLAAQgJAAgHgDgAgHgPQgGADgEAIQgEAHgCAJQgBAJAAAHQAAAGABAJQABAJAEAJQAFAIAFADQAFACADAAQAFAAAFgDQAFgDAEgIQAEgIABgJQABgJAAgGIAAgKIgCgMIgEgLQgEgHgEgDQgFgDgFAAQgDAAgFADg");
  this.shape_15.setTransform(58.075, 211.825);
  this.shape_16 = new cjs.Shape();
  this.shape_16.graphics.f("#0C593C").s().p("AgaA9QgMgIgGgPQgEgJgCgKQgCgKAAgJQAAgIACgLQACgKAEgIQAGgPAMgIQAMgIAPABQAPgBAMAIQALAIAHAPQADAIADAKIABATIgBATQgDAKgDAJQgHAPgLAIQgMAHgPABQgPgBgMgHgAgKgsQgEAFgDAGIgEAMIgCALIAAAKIAAAKIACANIAEALQADAGAEAEQAEAEAHAAQAFAAAFgEQAFgEADgGQACgFABgGIACgNIAAgKIAAgKIgCgLQgBgHgCgFQgDgGgFgFQgFgDgFAAQgHAAgEADg");
  this.shape_16.setTransform(47.1, 214.45);
  this.shape_17 = new cjs.Shape();
  this.shape_17.graphics.f("#0C593C").s().p("AgaA9QgMgIgGgPQgEgJgCgKQgCgKAAgJQAAgIACgLQACgKAEgIQAGgPAMgIQALgIAQABQAPgBAMAIQALAIAHAPQADAIACAKIACATIgCATQgCAKgDAJQgHAPgLAIQgMAHgPABQgQgBgLgHgAgKgsQgEAFgDAGIgEAMIgBALIgBAKIABAKIABANIAEALQADAGAEAEQAEAEAHAAQAGAAAFgEQAEgEADgGQACgFABgGIACgNIAAgKIAAgKIgCgLQgBgHgCgFQgDgGgEgFQgFgDgGAAQgHAAgEADg");
  this.shape_17.setTransform(36.55, 214.45);
  this.shape_18 = new cjs.Shape();
  this.shape_18.graphics.f("#0C593C").s().p("AgOBEQgHgCgHgEQgJgGgFgKQgFgKAAgMIAaAAIABAJIAEAIQAEAEAFACIAHABIAFAAQADgBAEgDQADgCACgEQACgEAAgHQABgDgCgEQgBgEgEgDQgDgCgEgBIgGgBIgKAAIAAgTIAIAAIAFAAQADgBADgCQAEgEABgDQACgEgBgEQAAgFgBgEQgBgDgDgDQgCgCgEgBIgEgBIgIABQgEACgDAFQgCAEAAAFIgBAGIgaAAQAAgJADgIQADgJAFgFQAHgHAJgDQAKgCAHAAQAHAAAJACQAJACAIAHQAFAFADAGQACAIAAAIQABAGgCAFQgCAFgEAFIgFAFIgFABIAAABIAHABQAEACAEAEQAEAFABAFQACAFAAAFQAAAKgDAGQgCAGgDAFIgHAHQgIAFgJACIgQACIgOgBg");
  this.shape_18.setTransform(26.505, 214.45);
  this.shape_19 = new cjs.Shape();
  this.shape_19.graphics.f("#0C593C").s().p("AgaBDQgFgCgEgCQgGgEgFgHQgEgJgBgMQABgGABgGQACgGADgFQADgFAEgDQAFgCAGgCIALgDIARgDIAHgBIAEgEIABgCIABgHQAAgGgCgEQgBgFgDgDIgHgEIgDAAQgIAAgEADQgEAEgCADIgCAHIgBAHIgZAAIABgOQACgGADgGQAFgIAHgEQAHgEAHgBIAOgBIANABQAIABAJAHQAIAGACAJQAEAJAAAMIAAAxIAAAJIABAEQAAAAABABQAAAAAAABQABAAAAAAQABAAAAAAIAFAAIAAAVIgHABIgIAAIgHgBQgDAAgDgDIgFgGIgCgGIAAAAQgDAFgDACIgDAFQgFADgFABQgGADgIAAIgKgBgAANAFIgCABIgFABIgFACIgJACIgGADQgFADgBAEQgCAEAAAEIABAGQABAEADAEIADADIAGABQAEAAAEgCQADgCAFgFQADgHACgIIACgPIAAgEIgCABg");
  this.shape_19.setTransform(17.05, 214.35);
  this.shape_20 = new cjs.Shape();
  this.shape_20.graphics.f("#0C593C").s().p("AgkA/IAAh+IBKAAIAAAVIgvAAIAABpg");
  this.shape_20.setTransform(9.2, 214.45);
  this.shape_21 = new cjs.Shape();
  this.shape_21.graphics.f("#0C593C").s().p("AgNATIAFgBQADgBACgEQADgFAAgIIAAgCIgNAAIAAgiIAaAAIAAAjQABAHgCAIQgCAHgHAIQgDADgEABQgEADgFAAg");
  this.shape_21.setTransform(126.65, 195.65);
  this.shape_22 = new cjs.Shape();
  this.shape_22.graphics.f("#0C593C").s().p("AAWBAIAAhaIgpBaIgeAAIAAh/IAcAAIAABaIAphaIAdAAIAAB/g");
  this.shape_22.setTransform(117.55, 189);
  this.shape_23 = new cjs.Shape();
  this.shape_23.graphics.f("#0C593C").s().p("AAWBAIAAhaIgpBaIgdAAIAAh/IAbAAIAABaIAphaIAeAAIAAB/g");
  this.shape_23.setTransform(105.55, 189);
  this.shape_24 = new cjs.Shape();
  this.shape_24.graphics.f("#0C593C").s().p("AgMBAIAAhqIgjAAIAAgVIBfAAIAAAVIgiAAIAABqg");
  this.shape_24.setTransform(95.2, 189);
  this.shape_25 = new cjs.Shape();
  this.shape_25.graphics.f("#0C593C").s().p("AgTBXIgHAAIgIgBIAAgVIADABIAGAAQAGAAAEgEQAEgEACgHIADgLIgvh+IAeAAIAbBbIABAAIAXhbIAaAAIgmCJIgEAMQgDAHgEAGQgFAHgFACQgFACgGAAIgDAAg");
  this.shape_25.setTransform(85.8, 191.3542);
  this.shape_26 = new cjs.Shape();
  this.shape_26.graphics.f("#0C593C").s().p("AAnBQIAAghIhMAAIAAAhIgYAAIgCg1IAOAAIAFgLIAEgNQAFgRABgOQACgPgBgOIAAgWIBQAAIAABqIARAAIgCA1gAgIgrIgBARIgCAQIgEASIgHATIApAAIAAhWIgbAAg");
  this.shape_26.setTransform(74.725, 190.65);
  this.shape_27 = new cjs.Shape();
  this.shape_27.graphics.f("#0C593C").s().p("AgOBEQgHgCgHgEQgJgGgFgKQgFgKAAgMIAaAAIABAIIAEAJQAEAEAFACIAHABIAFAAQADgBAEgDQADgCACgEQACgEAAgHQABgDgCgEQgBgEgEgDQgDgDgEAAIgGAAIgKAAIAAgUIAIAAIAFgBQADAAADgCQAEgEABgEQACgDgBgEQAAgFgBgEQgBgDgDgCQgCgDgEgBIgEgBIgIABQgEACgDAFQgCAEAAAEIgBAHIgaAAQAAgJADgIQADgIAFgGQAHgIAJgCQAKgDAHABQAHAAAJABQAJACAIAIQAFAFADAGQACAIAAAIQABAGgCAFQgCAGgEAEIgFAFIgFABIAAABIAHABQAEACAEAEQAEAFABAFQACAEAAAGQAAAJgDAHQgCAHgDAEIgHAGQgIAGgJACIgQABIgOAAg");
  this.shape_27.setTransform(63.555, 189);
  this.shape_28 = new cjs.Shape();
  this.shape_28.graphics.f("#0C593C").s().p("AgtBAIAAh/IA2AAIANACQAGABAGAEQAFAGACAHIACAMQAAAFgCAFQgBAGgEAEQgEAEgDACIgGACIAAABIAIACIAGAEQAEAEADAGQACAGAAAJQAAAKgDAHQgDAGgEADQgDAEgHACQgHADgKAAgAgSArIARAAIAGgBIAHgCQACgCACgDQACgDAAgGQAAgFgBgEQgCgDgCgBQgDgDgFgCIgHAAIgQAAgAgSgMIAPAAIAGgBQAEAAADgCQADgDABgEIABgGIgBgGQgBgDgEgDIgEgBIgFgBIgSAAg");
  this.shape_28.setTransform(53.325, 189);
  this.shape_29 = new cjs.Shape();
  this.shape_29.graphics.f("#0C593C").s().p("AAWBAIAAhaIgpBaIgdAAIAAh/IAbAAIAABaIAphaIAeAAIAAB/g");
  this.shape_29.setTransform(36.6, 189);
  this.shape_30 = new cjs.Shape();
  this.shape_30.graphics.f("#0C593C").s().p("Ag0BZIAAisIAaAAIAAAMIABAAIAEgGIAGgEQADgDAGgCQAFgCAGAAQAJAAAIADQAJAEAGAJQAIAJADALQAEALAAAIIABANIgBAOIgDAPQgCAIgEAHQgDAGgGAGQgFAFgHADQgIAEgJAAQgFAAgEgCIgJgEIgGgFIgFgGIAAAAIAAA6gAgLhAQgFADgFAKQgDAIgBAIIgBAQIAAAKIACAMIAGANQAEAGAEADQAFACAEAAQADAAAEgCQAFgCAFgHQADgFACgIQADgIAAgOIgBgPQgBgIgDgIQgEgLgGgDQgGgEgEAAQgEAAgGAEg");
  this.shape_30.setTransform(24.8333, 191.075);
  this.shape_31 = new cjs.Shape();
  this.shape_31.graphics.f("#0C593C").s().p("AAcBYIAAiUIg2AAIAACUIgeAAIAAivIBxAAIAACvg");
  this.shape_31.setTransform(11.425, 186.6);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_31
   }, {
    t: this.shape_30
   }, {
    t: this.shape_29
   }, {
    t: this.shape_28
   }, {
    t: this.shape_27
   }, {
    t: this.shape_26
   }, {
    t: this.shape_25
   }, {
    t: this.shape_24
   }, {
    t: this.shape_23
   }, {
    t: this.shape_22
   }, {
    t: this.shape_21
   }, {
    t: this.shape_20
   }, {
    t: this.shape_19
   }, {
    t: this.shape_18
   }, {
    t: this.shape_17
   }, {
    t: this.shape_16
   }, {
    t: this.shape_15
   }, {
    t: this.shape_14
   }, {
    t: this.shape_13
   }, {
    t: this.shape_12
   }, {
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
 }).prototype = getMCSymbolPrototype(lib.t2, new cjs.Rectangle(2, 170, 331, 91.60000000000002), null);
 (lib.t1_t1_lact = function() {
  this.initialize(img.t1_t1_lact);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 143, 53);
 (lib.t1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_t1 = new lib.t1_t1_lact();
  this.cvr_t1.name = "cvr_t1";
  this.cvr_t1.parent = this;
  this.cvr_t1.setTransform(11, 176, 0.5, 0.5);
  this.timeline.addTween(cjs.Tween.get(this.cvr_t1).wait(1));
  this.timeline.addTween(cjs.Tween.get(this.cvr_t1).wait(1));
 }).prototype = getMCSymbolPrototype(lib.t1, new cjs.Rectangle(9, 174, 147, 94), null);
 (lib.packshot_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.packshot();
  this.instance.parent = this;
  this.instance.setTransform(0, 0, 0.667, 0.667);
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));
 }).prototype = getMCSymbolPrototype(lib.packshot_1, new cjs.Rectangle(0, 0, 234.8, 113.4), null);
 (lib.orange = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#0C593C").s().p("AAAAJIgJAQIgHgGIAKgPIgOgFIABgJIAQAFIAAgTIAIAAIAAATIAOgFIADAJIgPAFIAJAPIgHAGg");
  this.shape.setTransform(106, 45.6);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#FFFFFF").s().p("AgNBUIAAghIAcAAIAAAhgAgHAfIgGg4IAAg6IAcAAIAAA6IgHA4g");
  this.shape_1.setTransform(98.8, 54);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#FFFFFF").s().p("AAjBUIgKgjIgxAAIgKAjIgdAAIAzinIAaAAIAyCngAATAXIgThHIgRBHIAkAAg");
  this.shape_2.setTransform(89.825, 54);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#FFFFFF").s().p("AAXBUIgyhUIAABUIgdAAIAAinIAdAAIAABIIAvhIIAgAAIg1BOIA6BZg");
  this.shape_3.setTransform(78.7, 54);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#FFFFFF").s().p("AAbBUIAAhMIg1AAIAABMIgcAAIAAinIAcAAIAABDIA1AAIAAhDIAcAAIAACng");
  this.shape_4.setTransform(64.975, 54);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#FFFFFF").s().p("AAcBUIAAh6Ig4B6IgcAAIAAinIAdAAIAAB6IA4h6IAcAAIAACng");
  this.shape_5.setTransform(51.25, 54);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#FFFFFF").s().p("Ag3BUIAAinIA/AAQAHAAAJACQAIACAHAIQAHAHACAIQACAIAAAHQAAAHgCAHQgCAHgGAHIgFAFIgIADIAAABIAJADIAIAFQAEAEAEAIQADAIAAANQABAIgDAJQgCAKgJAJQgGAFgGADQgHACgGABIgLAAgAgaA7IAaAAIALgBQAFgBAEgEQAEgEABgFIABgKIgBgJQgBgFgEgEQgEgEgFgBQgFgCgGABIgaAAgAgagOIAaAAIAHgBQAFgBAEgEIADgGQACgDAAgGIgBgIQgBgFgDgDQgDgEgFgBQgEgCgFAAIgZAAg");
  this.shape_6.setTransform(38.0042, 53.9958);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#FFFFFF").s().p("AAABZQgJAAgKgDQgLgDgKgIQgOgNgGgUQgGgTAAgXQAAgWAGgTQAGgUAOgNQAKgIALgDQAKgDAJAAQAKAAAKADQALADAKAIQAOANAGAUQAGATAAAWQAAAXgGATQgGAUgOANQgKAIgLADQgIADgJAAIgDAAgAAMA9QAGgCAGgHQAFgHADgIQADgJABgKIABgSIgBgRQgBgKgDgJQgDgIgFgHQgGgHgGgCQgGgDgGAAQgEAAgGADQgHACgGAHQgFAHgDAIQgDAJgBAKIgBARIABASQABAKADAJQADAIAFAHQAGAHAHACQAGADAEAAQAGAAAGgDg");
  this.shape_7.setTransform(24.075, 54);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#FFFFFF").s().p("AAbBUIAAhMIg1AAIAABMIgcAAIAAinIAcAAIAABDIA1AAIAAhDIAcAAIAACng");
  this.shape_8.setTransform(10.175, 54);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#E07E22").s().p("AlvFvQiYiXAAjYQAAjXCYiYQCZiYDWAAQDXAACZCYQCYCYAADXQAADYiYCXQiZCZjXAAQjWAAiZiZg");
  this.shape_9.setTransform(52, 52);
  this.timeline.addTween(cjs.Tween.get(this.shape_9).wait(1));
 }).prototype = getMCSymbolPrototype(lib.orange, new cjs.Rectangle(0, 0, 115.6, 104), null);
 (lib.logo = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#FFFFFF").s().p("AgjAxIAShhIA1AAIgCAPIgkAAIgFAZIAiAAIgDANIgiAAIgFAdIAmAAIgDAPg");
  this.shape.setTransform(145.1889, 48.0205, 0.6043, 0.6031);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#FFFFFF").s().p("AgZAxIAQhSIgbAAIADgPIBGAAIgDAPIgbAAIgPBSg");
  this.shape_1.setTransform(140.8531, 48.0205, 0.6043, 0.6031);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#FFFFFF").s().p("AglAxIAShfQAIgCAPAAQAQAAAJAGQAJAIAAAMQAAARgNAIQgLAJgSAAIgJAAIgHAlgAgFgiIgGAhIAJABQAKAAAGgGQAHgGAAgIQAAgPgRAAg");
  this.shape_2.setTransform(135.4598, 48.0054, 0.6043, 0.6031);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#FFFFFF").s().p("AgjAmQgJgLAAgRQAAgbARgSQAPgOATAAQATAAAKAMQAJAKAAASQAAAcgRARQgNAOgVAAQgSAAgLgMgAgRgUQgJAOAAAPQAAAbAWAAIABAAQAMAAAKgPQAJgOAAgPQAAgbgXAAQgNAAgJAPg");
  this.shape_3.setTransform(129.7794, 48.0205, 0.6043, 0.6031);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#FFFFFF").s().p("AgRA1IABgJQgNgDgIgJQgLgKABgQQAAgYAQgOQAOgMARAAIACgIIAQAAIgCAJQAOACAJAJQAJAKABARQAAAXgQAOQgNAMgUAAIgBAJgAACAgQANgBAIgKQAJgLAAgQQAAgWgSgDgAgVgVQgJALAAAPQAAALAEAHQAGAHAHABIAMg/QgLABgJAKg");
  this.shape_4.setTransform(123.1775, 48.0205, 0.6043, 0.6031);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#005942").s().p("AhzBhQgggkAOg9QAPg5AtglQAugkA6AAQA4AAAdAiQAgAlgOA7QgQA/gyAkQgtAfg2AAQg3AAgdghgAgkg2QgXAXgIAiQgKAoATAXQAOAQAXAAQAdAAAZgYQAagZAJgjQAEgRgCgQQgCgUgKgMQgMgNgXAAQgiAAgZAag");
  this.shape_5.setTransform(41.4014, 32.8801, 0.6043, 0.6031);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#80BC1E").s().p("AguA0QgPgRAIgjQACAZAOAJQAOAJASgIQAsgVALhLQAHAKAAATQAAAKgDAMIgCAIQgFAMgGAKQgLATgRAMQgPALgSAAQgRAAgJgKg");
  this.shape_6.setTransform(41.3778, 33.242, 0.6043, 0.6031);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#80BC1E").s().p("AhNBxQgZgVAAgnIAAgJIA3AAIAAAEQAAATAMAKQALALAUgBQASAAALgKQAMgLABgWQAAgHgEgGQgDgGgFgCIgMgEQgGgCgIAAIgSAAIAIgpIALAAIAPgDQAJgBAGgEQAGgEAEgHQAFgIAAgKQAAgZggAAQgPAAgMAIQgLAHgFAVIg3AAQAEgYAJgQQAJgQAOgJQAPgKASgEQASgFAVABQAWgBAPAGQAOAEAKAKQAKAJAEAMQAEAKAAAQQAAAKgDAJQgEALgFAHQgEAGgJAHQgIAGgHACQAPACAKAOQAKAOAAAVQAAAXgHARQgJARgOAMQgOALgUAHQgTAFgXAAQgtAAgYgVg");
  this.shape_7.setTransform(142.1221, 32.8198, 0.6043, 0.6031);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#80BC1E").s().p("AhGCBQgNgFgJgKQgJgIgEgNQgEgKAAgPQAAgmAVgWQAWgUAngHIAkgEQAPgBALgEQALgDAEgGQAFgGAAgNQAAgKgEgFQgEgHgFgDQgGgDgGgBIgNgBQgPgBgMAKQgNAIgDAUIg4AAQADgZAKgPQAJgPAOgLQAQgLAQgDQAQgFASABQANAAASACQAOACAPAIQAOAHAIANQAJAOgBAVQAAARgEAaIgUBlIgCAjQAAAHACAIIg8AAIAAgZQgMAQgRAIQgRAHgTAAQgRABgOgGgAATAPIgZACIgRAEQgJADgFAEQgFADgEAJQgEAHAAAMQAAAPAKAGQAKAIAMAAQAOAAAJgFQAJgGAHgIQAEgFAGgNQAEgLACgKIAGgZQgMAJgMABg");
  this.shape_8.setTransform(128.1206, 32.8198, 0.6043, 0.6031);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#80BC1E").s().p("AhnCAIAvj/ICgAAIgKA1IhkAAIglDKg");
  this.shape_9.setTransform(115.8806, 32.8349, 0.6043, 0.6031);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.f("#005942").s().p("AgrB8QgUgIgPgTQgPgSgGgYQgIgZAAgdQAAgdAIgYQAHgZAPgRQAPgSAUgLQAUgLAYABQAagBAUAMQAUALANATQAOAVAGAXQAHAZAAAbIgBANIibAAQABAiANAQQAOAPAZAAQARAAANgLQAOgKADgMIA0AAQgNAugaATQgaAVglgBQgYAAgVgKgAgXhLQgJAHgFAHQgGAJgCAJQgCAGgBALIBgAAQgEgcgLgNQgLgOgWAAQgNAAgKAGg");
  this.shape_10.setTransform(101.8459, 32.8198, 0.6043, 0.6031);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.f("#005942").s().p("AhXCBIgagEIAAg2IAJACIAKAAQAOAAAHgPIADgKIADgaQACgWAAggQABgYAAhJICyAAIAAD/Ig7AAIAAjKIg9AAIgBBDIgDAxQgCASgDASQgFAQgEAHQgHAOgNAIQgOAJgUAAg");
  this.shape_11.setTransform(85.7566, 32.9555, 0.6043, 0.6031);
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.f("#005942").s().p("AAuCAIAAisIhRCsIhDAAIAAj/IA5AAIAACsIBRisIBDAAIAAD/g");
  this.shape_12.setTransform(70.5284, 32.8349, 0.6043, 0.6031);
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.f("#005942").s().p("AgdCAIAAjKIhHAAIAAg1IDJAAIAAA1IhHAAIAADKg");
  this.shape_13.setTransform(55.98, 32.8349, 0.6043, 0.6031);
  this.shape_14 = new cjs.Shape();
  this.shape_14.graphics.f("#005942").s().p("ABkCwIAAj5IgBAAIhJD5IgzAAIhJj2IgBAAIAAD2Ig+AAIAAlgIBdAAIBFDyIABAAIBDjyIBdAAIAAFgg");
  this.shape_14.setTransform(22.1093, 29.8948, 0.6043, 0.6031);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_14
   }, {
    t: this.shape_13
   }, {
    t: this.shape_12
   }, {
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
  this.shape_15 = new cjs.Shape();
  this.shape_15.graphics.lf(["#FFFFFF", "#F27E20"], [0.612, 0.765], -80, 1.2, 80, 1.2).s().p("AsfAyIAAhiIY/AAIAABig");
  this.shape_15.setTransform(80, 48.05);
  this.shape_16 = new cjs.Shape();
  this.shape_16.graphics.f("#FFFFFF").s().p("AsfDYIAAmvIY/AAIAAGvg");
  this.shape_16.setTransform(80, 21.55);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_16
   }, {
    t: this.shape_15
   }]
  }).wait(1));
 }).prototype = getMCSymbolPrototype(lib.logo, new cjs.Rectangle(0, 0, 160, 53), null);
 (lib.l4 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#0C593C").s().p("AgEAGIAAgLIAJAAIAAALg");
  this.shape.setTransform(152.575, 66.425);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#0C593C").s().p("AALAgIAAgeIgVAAIAAAeIgJAAIAAg/IAJAAIAAAbIAVAAIAAgbIAJAAIAAA/g");
  this.shape_1.setTransform(149.1, 63.8);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#0C593C").s().p("AgLAfQgGgDgCgIQgDgHAAgNQAAgPAFgJQAGgJALAAQAXAAAAAhQAAANgDAHQgCAIgFADQgGADgHAAQgHAAgEgDgAgHgWQgDACgBAGIgBAPIABAOQABAFACADQADADAFAAQAFAAADgDQADgDABgFIABgOIgBgPQgCgGgDgCQgCgDgFAAQgEAAgDADg");
  this.shape_2.setTransform(144.15, 63.775);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#0C593C").s().p("AALAgIgPggIgHAJIAAAXIgJAAIAAg/IAJAAIAAAeIAVgeIALAAIgUAZIAUAmg");
  this.shape_3.setTransform(139.875, 63.8);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#0C593C").s().p("AAMAgIAAgvIABgIIgCAIIgUAvIgLAAIAAg/IAJAAIAAAvIgBAIIACgIIAUgvIALAAIAAA/g");
  this.shape_4.setTransform(134.825, 63.8);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#0C593C").s().p("AgEAgIAAg3IgQAAIAAgIIApAAIAAAIIgRAAIAAA3g");
  this.shape_5.setTransform(130.525, 63.8);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#0C593C").s().p("AgKAfQgEgDgDgIQgCgHAAgNQAAghATAAQAJAAAEAFQAFAFABAHQABAHAAAKIgeAAIABAOQABAFACADQADADAEAAQAKAAAAgPIAJAAQAAAGgCAGQgCAFgEADQgFADgGAAQgGAAgFgDgAgIgTQgCAFAAAIIAVAAQAAgJgCgFQgCgFgHAAQgFAAgDAGg");
  this.shape_6.setTransform(126.525, 63.775);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#0C593C").s().p("AATAgIAAg3IgQA3IgFAAIgQg3IAAA3IgJAAIAAg/IAOAAIAMApIABANIACgNIAMgpIAOAAIAAA/g");
  this.shape_7.setTransform(121.175, 63.8);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#0C593C").s().p("AAMAgIAAgvIABgIIgCAIIgUAvIgLAAIAAg/IAJAAIAAAvIgBAIIACgIIAUgvIALAAIAAA/g");
  this.shape_8.setTransform(115.425, 63.8);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#0C593C").s().p("AgMAdQgEgEgCgHQgCgHAAgKQAAgiAVAAQAKAAAFAHQAFAGAAAJIgJAAQAAgOgLAAQgGAAgDAHQgCAIAAALQAAALACAHQACAHAHAAQAHAAACgEQACgEAAgIIAJAAQAAAKgFAHQgEAHgKAAQgJAAgFgFg");
  this.shape_9.setTransform(110.775, 63.775);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.f("#0C593C").s().p("AgcAEIAAgHIA5AAIAAAHg");
  this.shape_10.setTransform(104.025, 63.4);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.f("#0C593C").s().p("AgLAfQgFgDgEgIQgCgHAAgNQAAgPAFgJQAGgJALAAQAXAAAAAhQAAANgDAHQgCAIgFADQgGADgHAAQgHAAgEgDgAgHgWQgDACgBAGIgBAPIABAOQABAFACADQAEADAEAAQAFAAADgDQADgDABgFIABgOIgBgPQgCgGgDgCQgDgDgEAAQgEAAgDADg");
  this.shape_11.setTransform(97, 63.775);
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.f("#0C593C").s().p("AgTAgIAAg/IAUAAQAIAAAEAEQAFAFAAAGQAAAGgDAEQgCAEgEABQAEABAEAEQADAEAAAHQAAAFgCAEQgCAEgEACQgEACgEAAgAgJAYIAJAAQAGABADgDQACgDAAgGQgBgFgCgDQgDgCgEAAIgKAAgAgJgEIAJAAQAEAAACgCQADgDAAgFQAAgJgJAAIgJAAg");
  this.shape_12.setTransform(92.45, 63.8);
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.f("#0C593C").s().p("AgEAgIAAg3IgQAAIAAgIIApAAIAAAIIgRAAIAAA3g");
  this.shape_13.setTransform(88.275, 63.8);
  this.shape_14 = new cjs.Shape();
  this.shape_14.graphics.f("#0C593C").s().p("AgMAdQgEgEgCgHQgCgHAAgKQAAgiAVAAQAKAAAFAHQAFAGAAAJIgJAAQAAgOgLAAQgGAAgDAHQgCAIAAALQAAALACAHQACAHAHAAQAHAAACgEQACgEAAgIIAJAAQAAAKgFAHQgEAHgKAAQgJAAgFgFg");
  this.shape_14.setTransform(84.325, 63.775);
  this.shape_15 = new cjs.Shape();
  this.shape_15.graphics.f("#0C593C").s().p("AgKAfQgEgDgDgIQgCgHAAgNQAAghATAAQAJAAAEAFQAFAFABAHQABAHAAAKIgeAAIABAOQABAFACADQADADAEAAQAKAAAAgPIAJAAQAAAGgCAGQgCAFgEADQgFADgGAAQgGAAgFgDgAgIgTQgCAFAAAIIAVAAQAAgJgCgFQgCgFgHAAQgFAAgDAGg");
  this.shape_15.setTransform(79.975, 63.775);
  this.shape_16 = new cjs.Shape();
  this.shape_16.graphics.f("#0C593C").s().p("AAdApIAAgSIhCAAIAAg/IAKAAIAAA4IAUAAIAAg4IAJAAIAAA4IAUAAIAAg4IAKAAIAAA4IAGAAIAAAZg");
  this.shape_16.setTransform(74.275, 64.675);
  this.shape_17 = new cjs.Shape();
  this.shape_17.graphics.f("#0C593C").s().p("AgKAfQgEgDgDgIQgCgHAAgNQAAghATAAQAJAAAEAFQAFAFABAHQABAHAAAKIgeAAIABAOQABAFACADQADADAEAAQAKAAAAgPIAJAAQAAAGgCAGQgCAFgEADQgFADgGAAQgGAAgFgDgAgIgTQgCAFAAAIIAVAAQAAgJgCgFQgCgFgHAAQgFAAgDAGg");
  this.shape_17.setTransform(67.875, 63.775);
  this.shape_18 = new cjs.Shape();
  this.shape_18.graphics.f("#0C593C").s().p("AgTAgIAAg/IAUAAQAHAAAGAEQAEAFAAAGQAAAGgDAEQgCAEgFABQAGABACAEQAEAEAAAHQAAAFgDAEQgCAEgDACQgEACgEAAgAgKAYIAKAAQAGABACgDQACgDAAgGQAAgFgCgDQgDgCgFAAIgKAAgAgKgEIAKAAQAEAAACgCQADgDAAgFQAAgJgJAAIgKAAg");
  this.shape_18.setTransform(63.7, 63.8);
  this.shape_19 = new cjs.Shape();
  this.shape_19.graphics.f("#0C593C").s().p("AgKAfQgEgDgDgIQgCgHAAgNQAAghATAAQAJAAAEAFQAFAFABAHQABAHAAAKIgeAAIABAOQABAFACADQADADAEAAQAKAAAAgPIAJAAQAAAGgCAGQgCAFgEADQgFADgGAAQgGAAgFgDgAgIgTQgCAFAAAIIAVAAQAAgJgCgFQgCgFgHAAQgFAAgDAGg");
  this.shape_19.setTransform(57.025, 63.775);
  this.shape_20 = new cjs.Shape();
  this.shape_20.graphics.f("#0C593C").s().p("AgKAfQgEgDgDgIQgCgHAAgNQAAghATAAQAJAAAEAFQAFAFABAHQABAHAAAKIgeAAIABAOQABAFACADQADADAEAAQAKAAAAgPIAJAAQAAAGgCAGQgCAFgEADQgFADgGAAQgGAAgFgDgAgIgTQgCAFAAAIIAVAAQAAgJgCgFQgCgFgHAAQgFAAgDAGg");
  this.shape_20.setTransform(52.725, 63.775);
  this.shape_21 = new cjs.Shape();
  this.shape_21.graphics.f("#0C593C").s().p("AAdApIAAgSIhCAAIAAg/IAKAAIAAA4IAUAAIAAg4IAJAAIAAA4IAUAAIAAg4IAKAAIAAA4IAGAAIAAAZg");
  this.shape_21.setTransform(47.025, 64.675);
  this.shape_22 = new cjs.Shape();
  this.shape_22.graphics.f("#0C593C").s().p("AgGAbQgGgIAAgRIgLAAIAAAeIgJAAIAAg/IAJAAIAAAbIALAAQAAgNAGgIQAGgIAKAAQAMAAAFAJQAGAIAAAPQAAANgCAHQgEAIgEAEQgGADgHAAQgKAAgGgHgAACgWQgCACgBAGQgCAGABAJQAAAMACAHQACAGAIAAQAHAAADgGQAEgHAAgMQAAgOgEgGQgDgGgHAAQgFAAgDADg");
  this.shape_22.setTransform(39.3, 63.775);
  this.shape_23 = new cjs.Shape();
  this.shape_23.graphics.f("#0C593C").s().p("AgVAqIAAgIIAHABQAEAAADgDQACgEACgGIgUhAIAJAAIAOAyIABAAIAOgyIAJAAIgUA/IgEAMQgBAEgEADQgDADgGAAIgHgBg");
  this.shape_23.setTransform(33.325, 64.9);
  this.shape_24 = new cjs.Shape();
  this.shape_24.graphics.f("#0C593C").s().p("AgTAgIAAg/IAUAAQAHAAAFAEQAFAFAAAGQAAAGgCAEQgDAEgEABQAFABADAEQADAEAAAHQAAAFgCAEQgCAEgEACQgEACgEAAgAgJAYIAJAAQAGABADgDQABgDAAgGQABgFgDgDQgDgCgEAAIgKAAgAgJgEIAJAAQAEAAADgCQACgDAAgFQAAgJgJAAIgJAAg");
  this.shape_24.setTransform(29.2, 63.8);
  this.shape_25 = new cjs.Shape();
  this.shape_25.graphics.f("#0C593C").s().p("AgEAgIAAg3IgQAAIAAgIIApAAIAAAIIgRAAIAAA3g");
  this.shape_25.setTransform(25.025, 63.8);
  this.shape_26 = new cjs.Shape();
  this.shape_26.graphics.f("#0C593C").s().p("AgMAdQgEgEgCgHQgCgHAAgKQAAgiAVAAQAKAAAFAHQAFAGAAAJIgJAAQAAgOgLAAQgGAAgDAHQgCAIAAALQAAALACAHQACAHAHAAQAHAAACgEQACgEAAgIIAJAAQAAAKgFAHQgEAHgKAAQgJAAgFgFg");
  this.shape_26.setTransform(21.075, 63.775);
  this.shape_27 = new cjs.Shape();
  this.shape_27.graphics.f("#0C593C").s().p("AAMAqIAAgvIABgIIgCAIIgUAvIgLAAIAAg/IAJAAIAAAxIgBAHIACgHIAUgxIALAAIAAA/gAgJgfQgEgDAAgIIAEAAQACAJAHAAQAFgBACgBQACgCABgFIAFAAQAAAIgEADQgFAEgGAAQgFAAgEgEg");
  this.shape_27.setTransform(16.375, 62.75);
  this.shape_28 = new cjs.Shape();
  this.shape_28.graphics.f("#0C593C").s().p("AgKAfQgEgDgDgIQgCgHAAgNQAAghATAAQAJAAAEAFQAFAFABAHQABAHAAAKIgeAAIABAOQABAFACADQADADAEAAQAKAAAAgPIAJAAQAAAGgCAGQgCAFgEADQgFADgGAAQgGAAgFgDgAgIgTQgCAFAAAIIAVAAQAAgJgCgFQgCgFgHAAQgFAAgDAGg");
  this.shape_28.setTransform(11.675, 63.775);
  this.shape_29 = new cjs.Shape();
  this.shape_29.graphics.f("#0C593C").s().p("AAZA1IAAgUIgxAAIAAAUIgJAAIAAgcIAGAAQAEgHACgIQACgIAAgIIABgYIAAgWIAtAAIAABNIAHAAIAAAcgAgIgVIgBATIgDAOIgFANIAiAAIAAhFIgZAAg");
  this.shape_29.setTransform(6.325, 63.675);
  this.shape_30 = new cjs.Shape();
  this.shape_30.graphics.f("#0C593C").s().p("AgEAGIAAgLIAJAAIAAALg");
  this.shape_30.setTransform(155.325, 55.075);
  this.shape_31 = new cjs.Shape();
  this.shape_31.graphics.f("#0C593C").s().p("AgXAfIAAgHIAEABQAAAAABAAQABAAAAgBQAAAAABAAQAAgBABAAIACgHIAAgQIAAgfIAlAAIAAA/IgJAAIAAg4IgTAAIAAAZQAAAPgDAIQgDAIgIAAIgFgBg");
  this.shape_31.setTransform(149.425, 52.475);
  this.shape_32 = new cjs.Shape();
  this.shape_32.graphics.f("#0C593C").s().p("AgVAqIAAgIIAHABQAEAAADgDQACgEACgGIgUhAIAJAAIAOAyIABAAIAOgyIAJAAIgUBAIgEALQgBAEgEADQgDADgGAAIgHgBg");
  this.shape_32.setTransform(142.925, 53.55);
  this.shape_33 = new cjs.Shape();
  this.shape_33.graphics.f("#0C593C").s().p("AgMAdQgEgEgCgHQgCgHAAgKQAAgiAVAAQAKAAAFAHQAFAGAAAJIgJAAQAAgOgLAAQgGAAgDAHQgCAIAAALQAAALACAHQACAHAHAAQAHAAACgEQACgEAAgIIAJAAQAAAKgFAHQgEAHgKAAQgJAAgFgFg");
  this.shape_33.setTransform(136.625, 52.425);
  this.shape_34 = new cjs.Shape();
  this.shape_34.graphics.f("#0C593C").s().p("AALAgIAAg3IgVAAIAAA3IgJAAIAAg/IAnAAIAAA/g");
  this.shape_34.setTransform(129.9, 52.45);
  this.shape_35 = new cjs.Shape();
  this.shape_35.graphics.f("#0C593C").s().p("AgVAQQAAgFABgEQACgEADgCIAKgEIAKgEQADgBAAgHQAAgFgDgDQgCgCgEAAQgFAAgCADQgDADAAAFIgIAAQAAgTATAAQAFAAAEADQAEACACAEQACADAAAFIAAAlQAAAFADAAIACAAIAAAGIgEABQgEAAgCgCQgCgBgBgGIgBAAQgBAEgEADQgDADgFAAQgQAAAAgSgAABABIgHADIgEAFQgCADAAAEQAAAKAJAAQAFAAADgEIACgCIAAgEIABgGIAAgMIgHADg");
  this.shape_35.setTransform(123.175, 52.425);
  this.shape_36 = new cjs.Shape();
  this.shape_36.graphics.f("#0C593C").s().p("AALAgIgPggIgHAJIAAAXIgJAAIAAg/IAJAAIAAAeIAVgeIALAAIgUAYIAUAng");
  this.shape_36.setTransform(117.125, 52.45);
  this.shape_37 = new cjs.Shape();
  this.shape_37.graphics.f("#0C593C").s().p("AgKAfQgEgDgDgIQgCgHAAgNQAAghATAAQAJAAAEAFQAFAFABAHQABAHAAAKIgeAAIABAOQABAFACADQADADAEAAQAKAAAAgPIAJAAQAAAGgCAGQgCAFgEADQgFADgGAAQgGAAgFgDgAgIgTQgCAFAAAIIAVAAQAAgJgCgFQgCgFgHAAQgFAAgDAGg");
  this.shape_37.setTransform(106.125, 52.425);
  this.shape_38 = new cjs.Shape();
  this.shape_38.graphics.f("#0C593C").s().p("AATAgIAAg3IgQA3IgFAAIgQg3IAAA3IgJAAIAAg/IAOAAIAMApIABANIACgNIAMgpIAOAAIAAA/g");
  this.shape_38.setTransform(98.675, 52.45);
  this.shape_39 = new cjs.Shape();
  this.shape_39.graphics.f("#0C593C").s().p("AgVAsIAAhVIAJAAIAAAHIAAAAQACgEAEgCQAEgDADAAQAUAAABAhIgBANIgDALQgDAFgEACQgEADgGAAQgDAAgDgCQgEgCgDgEIAAAcgAgKgcQgCAIAAALIABAMQABAGADAEQACADAFAAQAGAAAEgGQACgHAAgNQAAgZgMAAQgHAAgDAHg");
  this.shape_39.setTransform(91, 53.425);
  this.shape_40 = new cjs.Shape();
  this.shape_40.graphics.f("#0C593C").s().p("AgLAfQgGgDgCgIQgDgHAAgNQAAgPAFgJQAGgJALAAQAXAAAAAhQAAANgDAHQgCAIgFADQgGADgHAAQgHAAgEgDgAgHgWQgDACgBAGIgBAPIABAOQABAFACADQADADAFAAQAFAAADgDQADgDABgFIABgOIgBgPQgCgGgDgCQgCgDgFAAQgEAAgDADg");
  this.shape_40.setTransform(83.85, 52.425);
  this.shape_41 = new cjs.Shape();
  this.shape_41.graphics.f("#0C593C").s().p("AgDA2IAAgcIgGAGQgDACgFAAQgJAAgEgFQgEgEgCgHQgCgJAAgJQAAgJACgHQACgIAFgEQAFgEAHgBQAEABAEACQADACADAFIAAgeIAIAAIAAAeQACgFADgCQAEgCADgBQAMAAAFAKQAFAJAAAOQAAAigVAAQgFAAgDgCIgFgGIAAAcgAAHgRQgCAIAAAKQAAALACAIQADAGAHABQAHgBACgGQADgHAAgNQAAgZgMABQgIAAgCAHgAgcAAQAAANACAHQADAGAHABQAFAAADgFQADgEABgFIABgMQgBgKgCgIQgCgHgIAAQgNgBABAZg");
  this.shape_41.setTransform(75.2, 52.4);
  this.shape_42 = new cjs.Shape();
  this.shape_42.graphics.f("#0C593C").s().p("AgTAgIAAg/IAUAAQAHAAAGAEQAEAEAAAHQAAAGgDAEQgCAEgFABQAGABACAEQAEAEAAAHQAAAFgDAEQgCAEgDACQgEACgEAAgAgKAYIAKAAQAGAAACgCQACgDAAgGQAAgFgCgDQgDgCgFAAIgKAAgAgKgEIAKAAQAEAAADgDQACgCAAgFQAAgJgJAAIgKAAg");
  this.shape_42.setTransform(62.8, 52.45);
  this.shape_43 = new cjs.Shape();
  this.shape_43.graphics.f("#0C593C").s().p("AgKAfQgEgDgDgIQgCgHAAgNQAAghATAAQAJAAAEAFQAFAFABAHQABAHAAAKIgeAAIABAOQABAFACADQADADAEAAQAKAAAAgPIAJAAQAAAGgCAGQgCAFgEADQgFADgGAAQgGAAgFgDgAgIgTQgCAFAAAIIAVAAQAAgJgCgFQgCgFgHAAQgFAAgDAGg");
  this.shape_43.setTransform(51.925, 52.425);
  this.shape_44 = new cjs.Shape();
  this.shape_44.graphics.f("#0C593C").s().p("AALAgIgPggIgHAJIAAAXIgJAAIAAg/IAJAAIAAAeIAVgeIALAAIgUAYIAUAng");
  this.shape_44.setTransform(45.925, 52.45);
  this.shape_45 = new cjs.Shape();
  this.shape_45.graphics.f("#0C593C").s().p("AALAgIAAgeIgVAAIAAAeIgJAAIAAg/IAJAAIAAAbIAVAAIAAgbIAJAAIAAA/g");
  this.shape_45.setTransform(38.85, 52.45);
  this.shape_46 = new cjs.Shape();
  this.shape_46.graphics.f("#0C593C").s().p("AAVAgIAAg/IAJAAIAAA/gAgdAgIAAg/IAKAAIAAAbIAMAAQAGAAADADQAEABACAEQACAFAAAFQAAAFgCAFQgCADgEADQgDACgGAAgAgTAYIAJAAQAGAAADgCQACgDAAgFQAAgLgKAAIgKAAg");
  this.shape_46.setTransform(30.875, 52.45);
  this.shape_47 = new cjs.Shape();
  this.shape_47.graphics.f("#0C593C").s().p("AgVAsIAAhVIAJAAIAAAHIAAAAQACgEAEgCQAEgDADAAQAUAAAAAhIAAANIgDALQgDAFgEACQgEADgGAAQgDAAgDgCQgEgCgDgEIAAAcgAgKgcQgCAIAAALIABAMQABAGADAEQACADAFAAQAGAAAEgGQACgHAAgNQAAgZgMAAQgHAAgDAHg");
  this.shape_47.setTransform(23.05, 53.425);
  this.shape_48 = new cjs.Shape();
  this.shape_48.graphics.f("#0C593C").s().p("AgVAQQAAgFABgEQACgEADgCIAKgEIAKgEQADgBAAgHQAAgFgDgDQgCgCgEAAQgFAAgCADQgDADAAAFIgIAAQAAgTATAAQAFAAAEADQAEACACAEQACADAAAFIAAAlQAAAFADAAIACAAIAAAGIgEABQgEAAgCgCQgCgBgBgGIgBAAQgBAEgEADQgDADgFAAQgQAAAAgSgAABABIgHADIgEAFQgCADAAAEQAAAKAJAAQAFAAADgEIACgCIAAgEIABgGIAAgMIgHADg");
  this.shape_48.setTransform(12.025, 52.425);
  this.shape_49 = new cjs.Shape();
  this.shape_49.graphics.f("#0C593C").s().p("AALAgIAAgeIgWAAIAAAeIgJAAIAAg/IAJAAIAAAbIAWAAIAAgbIAKAAIAAA/g");
  this.shape_49.setTransform(5.3, 52.45);
  this.shape_50 = new cjs.Shape();
  this.shape_50.graphics.f("#0C593C").s().p("AAPAgIgPgaIgOAaIgJAAIATggIgSgfIAJAAIAOAYIAOgYIAJAAIgSAfIATAgg");
  this.shape_50.setTransform(152.35, 41.1);
  this.shape_51 = new cjs.Shape();
  this.shape_51.graphics.f("#0C593C").s().p("AAVAgIAAg/IAJAAIAAA/gAgdAgIAAg/IAKAAIAAAbIAMAAQAGAAADADQAEABACAEQACAEAAAGQAAAFgCAFQgCADgEACQgDADgGAAgAgTAZIAJAAQAGAAADgDQACgDAAgFQAAgMgKAAIgKAAg");
  this.shape_51.setTransform(144.525, 41.1);
  this.shape_52 = new cjs.Shape();
  this.shape_52.graphics.f("#0C593C").s().p("AALAgIAAgeIgVAAIAAAeIgJAAIAAg/IAJAAIAAAbIAVAAIAAgbIAJAAIAAA/g");
  this.shape_52.setTransform(136.4, 41.1);
  this.shape_53 = new cjs.Shape();
  this.shape_53.graphics.f("#0C593C").s().p("AALAgIAAgeIgWAAIAAAeIgJAAIAAg/IAJAAIAAAbIAWAAIAAgbIAKAAIAAA/g");
  this.shape_53.setTransform(129.15, 41.1);
  this.shape_54 = new cjs.Shape();
  this.shape_54.graphics.f("#0C593C").s().p("AgKAfQgEgDgDgIQgCgHAAgNQAAghATAAQAJAAAEAFQAFAFABAHQABAHAAAKIgeAAIABAOQABAFACADQADADAEAAQAKAAAAgPIAJAAQAAAGgCAGQgCAFgEADQgFADgGAAQgGAAgFgDgAgIgTQgCAFAAAIIAVAAQAAgJgCgFQgCgFgHAAQgFAAgDAGg");
  this.shape_54.setTransform(122.175, 41.075);
  this.shape_55 = new cjs.Shape();
  this.shape_55.graphics.f("#0C593C").s().p("AgXAfIAAgHIAEABQAAAAABAAQAAgBABAAQAAAAABAAQAAgBABAAIACgHIAAgQIAAgfIAlAAIAAA/IgJAAIAAg4IgTAAIAAAZQAAAPgDAIQgDAIgIAAIgFgBg");
  this.shape_55.setTransform(114.975, 41.125);
  this.shape_56 = new cjs.Shape();
  this.shape_56.graphics.f("#0C593C").s().p("AgTAgIAAg/IAUAAQAIAAAEAEQAFAEAAAHQAAAGgDAEQgCAEgFACQAGAAACAEQAEAEAAAHQAAAFgDAEQgBAEgEACQgEACgEAAgAgKAZIAKAAQAGgBACgCQADgDAAgGQAAgFgDgDQgDgDgEAAIgLAAgAgKgEIAKAAQAEAAACgDQADgCAAgGQAAgIgJgBIgKAAg");
  this.shape_56.setTransform(108.45, 41.1);
  this.shape_57 = new cjs.Shape();
  this.shape_57.graphics.f("#0C593C").s().p("AgVAQQAAgFABgEQACgEADgCIAKgEIAKgEQADgBAAgHQAAgFgDgDQgCgCgEAAQgFAAgCADQgDADAAAFIgIAAQAAgTATAAQAFAAAEADQAEACACAEQACADAAAFIAAAlQAAAFADAAIACAAIAAAGIgEABQgEAAgCgCQgCgBgBgGIgBAAQgBAEgEADQgDADgFAAQgQAAAAgSgAABABIgHADIgEAFQgCADAAAEQAAAKAJAAQAFAAADgEIACgCIAAgEIABgGIAAgMIgHADg");
  this.shape_57.setTransform(101.625, 41.075);
  this.shape_58 = new cjs.Shape();
  this.shape_58.graphics.f("#0C593C").s().p("AgEAgIAAg4IgQAAIAAgHIApAAIAAAHIgRAAIAAA4g");
  this.shape_58.setTransform(95.375, 41.1);
  this.shape_59 = new cjs.Shape();
  this.shape_59.graphics.f("#0C593C").s().p("AgMAdQgEgEgCgHQgCgHAAgKQAAgiAVAAQAKAAAFAHQAFAGAAAJIgJAAQAAgOgLAAQgGAAgDAHQgCAIAAALQAAALACAHQACAHAHAAQAHAAACgEQACgEAAgIIAJAAQAAAKgFAHQgEAHgKAAQgJAAgFgFg");
  this.shape_59.setTransform(89.125, 41.075);
  this.shape_60 = new cjs.Shape();
  this.shape_60.graphics.f("#0C593C").s().p("AATApIAAgSIglAAIAAASIgIAAIAAgZIAFAAIAFgMIACgJIABgOIAAgVIAiAAIAAA4IAGAAIAAAZgAgEgOQAAAKgCAFQgBAGgEAJIAXAAIAAgwIgQAAg");
  this.shape_60.setTransform(82.075, 41.975);
  this.shape_61 = new cjs.Shape();
  this.shape_61.graphics.f("#0C593C").s().p("AgKAfQgEgDgDgIQgCgHAAgNQAAghATAAQAJAAAEAFQAFAFABAHQABAHAAAKIgeAAIABAOQABAFACADQADADAEAAQAKAAAAgPIAJAAQAAAGgCAGQgCAFgEADQgFADgGAAQgGAAgFgDgAgIgTQgCAFAAAIIAVAAQAAgJgCgFQgCgFgHAAQgFAAgDAGg");
  this.shape_61.setTransform(75.075, 41.075);
  this.shape_62 = new cjs.Shape();
  this.shape_62.graphics.f("#0C593C").s().p("AgUAsIAAhVIAIAAIAAAHIAAAAQADgEADgCQAEgDACAAQAWAAAAAhIgBANIgEALQgCAFgEACQgEADgGAAQgDAAgDgCQgEgCgDgEIAAAcgAgKgcQgCAIAAALIABAMQABAGACAEQAEADAEAAQAHAAACgGQADgHAAgNQAAgZgMAAQgHAAgDAHg");
  this.shape_62.setTransform(68.3, 42.075);
  this.shape_63 = new cjs.Shape();
  this.shape_63.graphics.f("#0C593C").s().p("AALAgIAAg4IgWAAIAAA4IgJAAIAAg/IAoAAIAAA/g");
  this.shape_63.setTransform(60.95, 41.1);
  this.shape_64 = new cjs.Shape();
  this.shape_64.graphics.f("#0C593C").s().p("AgEAJQAFgCAAgJIgFAAIAAgLIAJAAIAAANQAAAEgCAFQgDAEgEABg");
  this.shape_64.setTransform(50.675, 44.575);
  this.shape_65 = new cjs.Shape();
  this.shape_65.graphics.f("#0C593C").s().p("AgTAgIAAg/IAUAAQAIAAAEAEQAFAEAAAHQAAAGgCAEQgDAEgEACQAEAAAEAEQADAEAAAHQAAAFgCAEQgCAEgEACQgEACgEAAgAgJAZIAJAAQAGgBADgCQABgDAAgGQAAgFgCgDQgDgDgEAAIgKAAgAgJgEIAJAAQAEAAADgDQACgCAAgGQAAgIgJgBIgJAAg");
  this.shape_65.setTransform(45.3, 41.1);
  this.shape_66 = new cjs.Shape();
  this.shape_66.graphics.f("#0C593C").s().p("AgEAgIAAg4IgQAAIAAgHIApAAIAAAHIgRAAIAAA4g");
  this.shape_66.setTransform(38.825, 41.1);
  this.shape_67 = new cjs.Shape();
  this.shape_67.graphics.f("#0C593C").s().p("AgMAdQgEgEgCgHQgCgHAAgKQAAgiAVAAQAKAAAFAHQAFAGAAAJIgJAAQAAgOgLAAQgGAAgDAHQgCAIAAALQAAALACAHQACAHAHAAQAHAAACgEQACgEAAgIIAJAAQAAAKgFAHQgEAHgKAAQgJAAgFgFg");
  this.shape_67.setTransform(32.575, 41.075);
  this.shape_68 = new cjs.Shape();
  this.shape_68.graphics.f("#0C593C").s().p("AATApIAAgSIglAAIAAASIgIAAIAAgZIAFAAIAFgMIACgJIABgOIAAgVIAiAAIAAA4IAGAAIAAAZgAgEgOQAAAKgCAFQgBAGgEAJIAXAAIAAgwIgQAAg");
  this.shape_68.setTransform(25.525, 41.975);
  this.shape_69 = new cjs.Shape();
  this.shape_69.graphics.f("#0C593C").s().p("AgKAfQgEgDgDgIQgCgHAAgNQAAghATAAQAJAAAEAFQAFAFABAHQABAHAAAKIgeAAIABAOQABAFACADQADADAEAAQAKAAAAgPIAJAAQAAAGgCAGQgCAFgEADQgFADgGAAQgGAAgFgDgAgIgTQgCAFAAAIIAVAAQAAgJgCgFQgCgFgHAAQgFAAgDAGg");
  this.shape_69.setTransform(18.525, 41.075);
  this.shape_70 = new cjs.Shape();
  this.shape_70.graphics.f("#0C593C").s().p("AgUAsIAAhVIAIAAIAAAHIABAAQACgEADgCQAEgDACAAQAWAAgBAhIgBANIgCALQgDAFgEACQgEADgGAAQgDAAgEgCQgDgCgCgEIAAAcgAgJgcQgCAIAAALIAAAMQABAGACAEQAEADAEAAQAHAAACgGQADgHAAgNQAAgZgMAAQgHAAgCAHg");
  this.shape_70.setTransform(11.75, 42.075);
  this.shape_71 = new cjs.Shape();
  this.shape_71.graphics.f("#0C593C").s().p("AgMAdQgEgEgCgHQgCgHAAgKQAAgiAVAAQAKAAAFAHQAFAGAAAJIgJAAQAAgOgLAAQgGAAgDAHQgCAIAAALQAAALACAHQACAHAHAAQAHAAACgEQACgEAAgIIAJAAQAAAKgFAHQgEAHgKAAQgJAAgFgFg");
  this.shape_71.setTransform(4.725, 41.075);
  this.shape_72 = new cjs.Shape();
  this.shape_72.graphics.f("#0C593C").s().p("AAQAgIgQgaIgOAaIgKAAIAUggIgTgfIAKAAIAOAYIAOgYIAJAAIgSAfIATAgg");
  this.shape_72.setTransform(153.85, 29.75);
  this.shape_73 = new cjs.Shape();
  this.shape_73.graphics.f("#0C593C").s().p("AAVAgIAAg/IAJAAIAAA/gAgdAgIAAg/IAKAAIAAAbIAMAAQAGAAADADQAEABACAEQACAEAAAGQAAAFgCAFQgCADgEACQgDADgGAAgAgTAZIAJAAQAGAAADgEQACgCAAgFQAAgMgKAAIgKAAg");
  this.shape_73.setTransform(147.525, 29.75);
  this.shape_74 = new cjs.Shape();
  this.shape_74.graphics.f("#0C593C").s().p("AALAgIAAgeIgVAAIAAAeIgJAAIAAg/IAJAAIAAAaIAVAAIAAgaIAJAAIAAA/g");
  this.shape_74.setTransform(140.9, 29.75);
  this.shape_75 = new cjs.Shape();
  this.shape_75.graphics.f("#0C593C").s().p("AALAgIAAgeIgVAAIAAAeIgJAAIAAg/IAJAAIAAAaIAVAAIAAgaIAJAAIAAA/g");
  this.shape_75.setTransform(135.15, 29.75);
  this.shape_76 = new cjs.Shape();
  this.shape_76.graphics.f("#0C593C").s().p("AgLAfQgFgDgEgIQgCgHAAgNQAAgPAFgJQAGgJALAAQAXAAAAAhQAAANgDAHQgCAIgFADQgGADgHAAQgHAAgEgDgAgHgWQgDACgBAGIgBAPIABAOQABAFACADQAEADAEAAQAFAAADgDQADgDABgFIABgOIgBgPQgCgGgDgCQgDgDgEAAQgEAAgDADg");
  this.shape_76.setTransform(129.4, 29.725);
  this.shape_77 = new cjs.Shape();
  this.shape_77.graphics.f("#0C593C").s().p("AgQAgIAAg/IAhAAIAAAHIgYAAIAAA4g");
  this.shape_77.setTransform(124.775, 29.75);
  this.shape_78 = new cjs.Shape();
  this.shape_78.graphics.f("#0C593C").s().p("AgLAfQgGgDgCgIQgDgHAAgNQAAgPAFgJQAGgJALAAQAXAAAAAhQAAANgDAHQgCAIgFADQgGADgHAAQgHAAgEgDgAgHgWQgDACgBAGIgBAPIABAOQABAFACADQADADAFAAQAFAAADgDQADgDABgFIABgOIgBgPQgCgGgCgCQgDgDgFAAQgEAAgDADg");
  this.shape_78.setTransform(119.4, 29.725);
  this.shape_79 = new cjs.Shape();
  this.shape_79.graphics.f("#0C593C").s().p("AgVAsIAAhVIAJAAIAAAHIAAAAQADgEADgCQAEgDACAAQAWAAAAAhIgBANIgEALQgCAFgEACQgEADgGAAQgDAAgDgCQgEgCgDgEIAAAcgAgKgcQgCAIAAALIABAMQABAGACAEQAEADAEAAQAHAAACgGQADgHAAgNQAAgZgMAAQgHAAgDAHg");
  this.shape_79.setTransform(113.75, 30.725);
  this.shape_80 = new cjs.Shape();
  this.shape_80.graphics.f("#0C593C").s().p("AgEAgIAAg4IgQAAIAAgHIApAAIAAAHIgRAAIAAA4g");
  this.shape_80.setTransform(108.575, 29.75);
  this.shape_81 = new cjs.Shape();
  this.shape_81.graphics.f("#0C593C").s().p("AgKAfQgEgDgDgIQgCgHAAgNQAAghATAAQAJAAAEAFQAFAFABAHQABAHAAAKIgeAAIABAOQABAFACADQADADAEAAQAKAAAAgPIAJAAQAAAGgCAGQgCAFgEADQgFADgGAAQgGAAgFgDgAgIgTQgCAFAAAIIAVAAQAAgJgCgFQgCgFgHAAQgFAAgDAGg");
  this.shape_81.setTransform(103.775, 29.725);
  this.shape_82 = new cjs.Shape();
  this.shape_82.graphics.f("#0C593C").s().p("AgTAgIAAg/IAUAAQAHAAAGAEQAEAFAAAGQAAAGgDAEQgCAEgFACQAGAAACAEQAEAEAAAHQAAAFgDAEQgCAEgDACQgEACgEAAgAgKAZIAKAAQAGgBACgCQACgDAAgGQAAgFgCgDQgDgDgFAAIgKAAgAgKgEIAKAAQAEAAACgDQADgCAAgGQAAgIgJgBIgKAAg");
  this.shape_82.setTransform(98.8, 29.75);
  this.shape_83 = new cjs.Shape();
  this.shape_83.graphics.f("#0C593C").s().p("AgEAgIAAg4IgQAAIAAgHIApAAIAAAHIgRAAIAAA4g");
  this.shape_83.setTransform(90.925, 29.75);
  this.shape_84 = new cjs.Shape();
  this.shape_84.graphics.f("#0C593C").s().p("AgMAfQgEgDgEgIQgCgHAAgNQAAgPAFgJQAGgJALAAQAXAAAAAhQAAANgDAHQgDAIgEADQgGADgHAAQgHAAgFgDgAgHgWQgDACgCAGIAAAPIAAAOQACAFACADQADADAFAAQAFAAADgDQADgDABgFIABgOIgBgPQgCgGgDgCQgDgDgEAAQgEAAgDADg");
  this.shape_84.setTransform(85.85, 29.725);
  this.shape_85 = new cjs.Shape();
  this.shape_85.graphics.f("#0C593C").s().p("AgKAfQgEgDgDgIQgCgHAAgNQAAghATAAQAJAAAEAFQAFAFABAHQABAHAAAKIgeAAIABAOQABAFACADQADADAEAAQAKAAAAgPIAJAAQAAAGgCAGQgCAFgEADQgFADgGAAQgGAAgFgDgAgIgTQgCAFAAAIIAVAAQAAgJgCgFQgCgFgHAAQgFAAgDAGg");
  this.shape_85.setTransform(77.475, 29.725);
  this.shape_86 = new cjs.Shape();
  this.shape_86.graphics.f("#0C593C").s().p("AAMAgIAAgwIABgIIgCAIIgUAwIgLAAIAAg/IAJAAIAAAwIgBAIIACgIIAUgwIALAAIAAA/g");
  this.shape_86.setTransform(72.025, 29.75);
  this.shape_87 = new cjs.Shape();
  this.shape_87.graphics.f("#0C593C").s().p("AAKAgIAAgeQgFABgHAAQgIAAgFgDQgDgFgBgHIAAgTIAKAAIAAASQgBAFACACQADACAFABIAKgBIAAgbIAJAAIAAA/g");
  this.shape_87.setTransform(66.3, 29.75);
  this.shape_88 = new cjs.Shape();
  this.shape_88.graphics.f("#0C593C").s().p("AAMAgIAAgwIABgIIgCAIIgUAwIgLAAIAAg/IAJAAIAAAwIgBAIIACgIIAUgwIALAAIAAA/g");
  this.shape_88.setTransform(60.625, 29.75);
  this.shape_89 = new cjs.Shape();
  this.shape_89.graphics.f("#0C593C").s().p("AgXAfIAAgHIAEABQAAAAABAAQABgBAAAAQABAAAAAAQAAgBABAAIACgHIAAgQIAAgfIAlAAIAAA/IgJAAIAAg4IgTAAIAAAZQAAAPgDAIQgDAIgIAAIgFgBg");
  this.shape_89.setTransform(54.525, 29.775);
  this.shape_90 = new cjs.Shape();
  this.shape_90.graphics.f("#0C593C").s().p("AgEAgIAAg4IgQAAIAAgHIApAAIAAAHIgRAAIAAA4g");
  this.shape_90.setTransform(49.775, 29.75);
  this.shape_91 = new cjs.Shape();
  this.shape_91.graphics.f("#0C593C").s().p("AgLAfQgGgDgCgIQgDgHAAgNQAAgPAFgJQAGgJALAAQAXAAAAAhQAAANgDAHQgCAIgFADQgGADgHAAQgHAAgEgDgAgHgWQgDACgBAGIgBAPIABAOQABAFACADQADADAFAAQAFAAADgDQADgDABgFIABgOIgBgPQgCgGgCgCQgDgDgFAAQgEAAgDADg");
  this.shape_91.setTransform(44.7, 29.725);
  this.shape_92 = new cjs.Shape();
  this.shape_92.graphics.f("#0C593C").s().p("AgTAgIAAg/IAUAAQAIAAAEAEQAFAFAAAGQAAAGgDAEQgCAEgFACQAGAAACAEQAEAEAAAHQAAAFgDAEQgBAEgEACQgEACgEAAgAgKAZIAKAAQAGgBACgCQADgDAAgGQAAgFgDgDQgDgDgEAAIgLAAgAgKgEIAKAAQAEAAACgDQADgCAAgGQAAgIgJgBIgKAAg");
  this.shape_92.setTransform(36.45, 29.75);
  this.shape_93 = new cjs.Shape();
  this.shape_93.graphics.f("#0C593C").s().p("AgEAJQAFgCAAgJIgFAAIAAgLIAJAAIAAANQAAAEgCAFQgDAEgEABg");
  this.shape_93.setTransform(29.275, 33.225);
  this.shape_94 = new cjs.Shape();
  this.shape_94.graphics.f("#0C593C").s().p("AgMApQgGgEgCgHQgDgHgBgHIgBgQQAAgMACgKQACgJAHgGQAFgHALAAQAHAAAGADQAFAEADAGQADAGAAAJIgKAAQAAgUgPABQgKAAgDAKQgDAKAAAPIABANIACAMQACAFADADQAEADAEABQAGAAADgDQADgDACgGIABgNIAKAAQAAAKgDAIQgCAHgGAEQgFAEgIAAQgIAAgGgEg");
  this.shape_94.setTransform(24.65, 28.65);
  this.shape_95 = new cjs.Shape();
  this.shape_95.graphics.f("#0C593C").s().p("AgeArIAAgIIAEAAQAEAAACgEQACgEABgJIABgXIAAgmIAvAAIAABWIgKAAIAAhNIgcAAIAAAiIAAAQIgCANQgCAHgDAEQgEAEgGAAIgGgBg");
  this.shape_95.setTransform(17.425, 28.675);
  this.shape_96 = new cjs.Shape();
  this.shape_96.graphics.f("#0C593C").s().p("AgYArIAAhVIAYAAQALAAAHAGQAHAGAAAMQAAAIgCAFQgCAFgEABQgEADgFABQgEACgGAAIgNAAIAAAkgAgPgBIAKAAQAGAAAFgBQAEgBACgEQADgEAAgHQAAgJgFgDQgFgEgHAAIgNAAg");
  this.shape_96.setTransform(11.3, 28.625);
  this.shape_97 = new cjs.Shape();
  this.shape_97.graphics.f("#0C593C").s().p("AgWArIAAhVIAsAAIAAAIIgiAAIAABNg");
  this.shape_97.setTransform(5.35, 28.625);
  this.shape_98 = new cjs.Shape();
  this.shape_98.graphics.f("#0C593C").s().p("AATAgIAAg4IgQA4IgFAAIgQg4IAAA4IgJAAIAAg/IAOAAIAMApIABANIACgNIAMgpIAOAAIAAA/g");
  this.shape_98.setTransform(151.025, 18.4);
  this.shape_99 = new cjs.Shape();
  this.shape_99.graphics.f("#0C593C").s().p("AAVAgIAAg/IAJAAIAAA/gAgdAgIAAg/IAKAAIAAAbIAMAAQAGAAADADQAEABACAEQACAFAAAFQAAAFgCAFQgCAEgEABQgDADgGAAgAgTAZIAJAAQAGAAADgEQACgCAAgGQAAgKgKgBIgKAAg");
  this.shape_99.setTransform(143.225, 18.4);
  this.shape_100 = new cjs.Shape();
  this.shape_100.graphics.f("#0C593C").s().p("AALAgIAAgeIgVAAIAAAeIgJAAIAAg/IAJAAIAAAaIAVAAIAAgaIAJAAIAAA/g");
  this.shape_100.setTransform(136.2, 18.4);
  this.shape_101 = new cjs.Shape();
  this.shape_101.graphics.f("#0C593C").s().p("AALAgIAAgeIgWAAIAAAeIgJAAIAAg/IAJAAIAAAaIAWAAIAAgaIAKAAIAAA/g");
  this.shape_101.setTransform(130.05, 18.4);
  this.shape_102 = new cjs.Shape();
  this.shape_102.graphics.f("#0C593C").s().p("AgVAQQAAgFABgEQACgEADgCIAKgEIAKgEQADgBAAgHQAAgFgDgDQgCgCgEAAQgFAAgCADQgDADAAAFIgIAAQAAgTATAAQAFAAAEADQAEACACAEQACADAAAFIAAAlQAAAFADAAIACAAIAAAGIgEABQgEAAgCgCQgCgBgBgGIgBAAQgBAEgEADQgDADgFAAQgQAAAAgSgAABABIgHADIgEAFQgCADAAAEQAAAKAJAAQAFAAADgEIACgCIAAgEIABgGIAAgMIgHADg");
  this.shape_102.setTransform(124.225, 18.375);
  this.shape_103 = new cjs.Shape();
  this.shape_103.graphics.f("#0C593C").s().p("AATApIAAgSIglAAIAAASIgIAAIAAgZIAFAAIAFgMIACgJIABgOIAAgVIAiAAIAAA4IAGAAIAAAZgAgEgOQAAAKgCAFQgBAGgEAJIAXAAIAAgwIgQAAg");
  this.shape_103.setTransform(118.275, 19.275);
  this.shape_104 = new cjs.Shape();
  this.shape_104.graphics.f("#0C593C").s().p("AgMAfQgEgDgEgIQgCgHAAgNQAAgPAFgJQAGgJALAAQAXAAAAAhQAAANgDAHQgDAIgEADQgGADgHAAQgHAAgFgDgAgHgWQgDACgCAGIAAAPIAAAOQACAFACADQADADAFAAQAFAAADgDQADgDABgFIABgOIgBgPQgCgGgDgCQgDgDgEAAQgEAAgDADg");
  this.shape_104.setTransform(108.8, 18.375);
  this.shape_105 = new cjs.Shape();
  this.shape_105.graphics.f("#0C593C").s().p("AAQArIAAhNIgfAAIAABNIgKAAIAAhVIAzAAIAABVg");
  this.shape_105.setTransform(101.975, 17.275);
  this.shape_106 = new cjs.Shape();
  this.shape_106.graphics.f("#0C593C").s().p("AgEAGIAAgLIAJAAIAAALg");
  this.shape_106.setTransform(93.275, 21.025);
  this.shape_107 = new cjs.Shape();
  this.shape_107.graphics.f("#0C593C").s().p("AgKAfQgEgDgDgIQgCgHAAgNQAAghATAAQAJAAAEAFQAFAFABAHQABAHAAAKIgeAAIABAOQABAFACADQADADAEAAQAKAAAAgPIAJAAQAAAGgCAGQgCAFgEADQgFADgGAAQgGAAgFgDgAgIgTQgCAFAAAIIAVAAQAAgJgCgFQgCgFgHAAQgFAAgDAGg");
  this.shape_107.setTransform(88.875, 18.375);
  this.shape_108 = new cjs.Shape();
  this.shape_108.graphics.f("#0C593C").s().p("AgEAgIAAg4IgQAAIAAgHIApAAIAAAHIgRAAIAAA4g");
  this.shape_108.setTransform(83.775, 18.4);
  this.shape_109 = new cjs.Shape();
  this.shape_109.graphics.f("#0C593C").s().p("AgVAsIAAhVIAJAAIAAAHIAAAAQACgEAEgCQAEgDADAAQAUAAAAAhIAAANIgDALQgDAFgEACQgEADgGAAQgDAAgDgCQgEgCgDgEIAAAcgAgKgcQgCAIAAALIABAMQABAGADAEQACADAFAAQAGAAAEgGQACgHAAgNQAAgZgMAAQgHAAgDAHg");
  this.shape_109.setTransform(78.4, 19.375);
  this.shape_110 = new cjs.Shape();
  this.shape_110.graphics.f("#0C593C").s().p("AgLAfQgGgDgCgIQgDgHAAgNQAAgPAFgJQAGgJALAAQAXAAAAAhQAAANgDAHQgCAIgFADQgGADgHAAQgHAAgEgDgAgHgWQgDACgBAGIgBAPIABAOQABAFACADQADADAFAAQAFAAADgDQADgDABgFIABgOIgBgPQgCgGgCgCQgDgDgFAAQgEAAgDADg");
  this.shape_110.setTransform(72.15, 18.375);
  this.shape_111 = new cjs.Shape();
  this.shape_111.graphics.f("#0C593C").s().p("AgEArIAAgKIgCAAQgJAAgHgEQgHgDgEgIQgEgIAAgKQAAgLAEgIQAEgHAHgEQAIgDAIAAIACAAIAAgJIAJAAIAAAJIACAAQAIAAAHADQAHAEAFAHQAEAIAAALQAAAKgEAIQgEAIgHADQgHAEgJAAIgCAAIAAAKgAAFAYIACAAQAGAAAFgDQAFgCADgGQACgGAAgHQAAgMgGgGQgFgHgKAAIgCAAgAgRgWQgFADgDAFQgCAGAAAIQAAAHACAGQADAGAFACQAFADAGAAIACAAIAAgxIgCAAQgGAAgFADg");
  this.shape_111.setTransform(64.625, 17.275);
  this.shape_112 = new cjs.Shape();
  this.shape_112.graphics.f("#0C593C").s().p("AgJAgQgFgDgCgFQgDgEgBgIIAJAAQABAGABADQABADACABQADABADAAQALAAAAgMQAAgFgCgDQgDgEgFAAIgFAAIAAgGIAFAAQAEAAACgDQADgDAAgFQAAgEgCgDQgDgDgFAAQgEAAgDADQgDADAAAFIgIAAQAAgFACgEQADgEAEgDQAEgDAFAAQAFAAAFADQAEACADADQACAEAAAFQAAAGgDAEQgDAEgFABIAAABQAEAAAFAEQADAEAAAHQAAAGgCAEQgCAEgFADQgFACgFAAQgGAAgEgCg");
  this.shape_112.setTransform(54.2, 18.375);
  this.shape_113 = new cjs.Shape();
  this.shape_113.graphics.f("#0C593C").s().p("AgVAQQAAgFABgEQACgEADgCIAKgEIAKgEQADgBAAgHQAAgFgDgDQgCgCgEAAQgFAAgCADQgDADAAAFIgIAAQAAgTATAAQAFAAAEADQAEACACAEQACADAAAFIAAAlQAAAFADAAIACAAIAAAGIgEABQgEAAgCgCQgCgBgBgGIgBAAQgBAEgEADQgDADgFAAQgQAAAAgSgAABABIgHADIgEAFQgCADAAAEQAAAKAJAAQAFAAADgEIACgCIAAgEIABgGIAAgMIgHADg");
  this.shape_113.setTransform(48.875, 18.375);
  this.shape_114 = new cjs.Shape();
  this.shape_114.graphics.f("#0C593C").s().p("AgQAgIAAg/IAhAAIAAAHIgYAAIAAA4g");
  this.shape_114.setTransform(44.175, 18.4);
  this.shape_115 = new cjs.Shape();
  this.shape_115.graphics.f("#0C593C").s().p("AgKAfQgEgDgDgIQgCgHAAgNQAAghATAAQAJAAAEAFQAFAFABAHQABAHAAAKIgeAAIABAOQABAFACADQADADAEAAQAKAAAAgPIAJAAQAAAGgCAGQgCAFgEADQgFADgGAAQgGAAgFgDgAgIgTQgCAFAAAIIAVAAQAAgJgCgFQgCgFgHAAQgFAAgDAGg");
  this.shape_115.setTransform(38.675, 18.375);
  this.shape_116 = new cjs.Shape();
  this.shape_116.graphics.f("#0C593C").s().p("AgXAfIAAgHIAEABQAAAAABAAQABgBAAAAQABAAAAAAQAAgBABAAIACgHIAAgQIAAgfIAlAAIAAA/IgJAAIAAg4IgTAAIAAAZQAAAPgDAIQgDAIgIAAIgFgBg");
  this.shape_116.setTransform(32.575, 18.425);
  this.shape_117 = new cjs.Shape();
  this.shape_117.graphics.f("#0C593C").s().p("AAMAgIAAgwIABgIIgCAIIgUAwIgLAAIAAg/IAJAAIAAAwIgBAIIACgIIAUgwIALAAIAAA/g");
  this.shape_117.setTransform(26.675, 18.4);
  this.shape_118 = new cjs.Shape();
  this.shape_118.graphics.f("#0C593C").s().p("AgEAgIAAg4IgQAAIAAgHIApAAIAAAHIgRAAIAAA4g");
  this.shape_118.setTransform(21.175, 18.4);
  this.shape_119 = new cjs.Shape();
  this.shape_119.graphics.f("#0C593C").s().p("AgLAfQgGgDgCgIQgDgHAAgNQAAgPAFgJQAGgJALAAQAXAAAAAhQAAANgDAHQgDAIgFADQgFADgHAAQgGAAgFgDgAgHgWQgDACgBAGIgCAPIACAOQABAFACADQADADAFAAQAFAAADgDQADgDABgFIABgOIgBgPQgBgGgDgCQgDgDgFAAQgEAAgDADg");
  this.shape_119.setTransform(15.7, 18.375);
  this.shape_120 = new cjs.Shape();
  this.shape_120.graphics.f("#0C593C").s().p("AAbArIAAhGIAAgGIAAgFIgCAGIgBAGIgSBFIgLAAIgShGIgCgLIgBAAIAAAGIABAFIAABGIgKAAIAAhVIARAAIARBCIABANIACgNIARhCIARAAIAABVg");
  this.shape_120.setTransform(7.925, 17.275);
  this.shape_121 = new cjs.Shape();
  this.shape_121.graphics.f("#0C593C").s().p("AgVAQQAAgFABgEQACgEADgCIAKgEIAKgEQADgBAAgHQAAgFgDgDQgCgCgEAAQgFAAgCADQgDADAAAFIgIAAQAAgTATAAQAFAAAEADQAEACACAEQACADAAAFIAAAlQAAAFADAAIACAAIAAAGIgEABQgEAAgCgCQgCgBgBgGIgBAAQgBAEgEADQgDADgFAAQgQAAAAgSgAABABIgHADIgEAFQgCADAAAEQAAAKAJAAQAFAAADgEIACgCIAAgEIABgGIAAgMIgHADg");
  this.shape_121.setTransform(151.075, 7.025);
  this.shape_122 = new cjs.Shape();
  this.shape_122.graphics.f("#0C593C").s().p("AgEAgIAAg4IgQAAIAAgHIApAAIAAAHIgRAAIAAA4g");
  this.shape_122.setTransform(144.225, 7.05);
  this.shape_123 = new cjs.Shape();
  this.shape_123.graphics.f("#0C593C").s().p("AgVAQQAAgFABgEQACgEADgCIAKgEIAKgEQADgBAAgHQAAgFgDgDQgCgCgEAAQgFAAgCADQgDADAAAFIgIAAQAAgTATAAQAFAAAEADQAEACACAEQACADAAAFIAAAlQAAAFADAAIACAAIAAAGIgEABQgEAAgCgCQgCgBgBgGIgBAAQgBAEgEADQgDADgFAAQgQAAAAgSgAABABIgHADIgEAFQgCADAAAEQAAAKAJAAQAFAAADgEIACgCIAAgEIABgGIAAgMIgHADg");
  this.shape_123.setTransform(137.375, 7.025);
  this.shape_124 = new cjs.Shape();
  this.shape_124.graphics.f("#0C593C").s().p("AgUAsIAAhVIAIAAIAAAHIAAAAQADgEADgCQAEgDACAAQAWAAAAAhIgBANIgEALQgCAFgEACQgEADgGAAQgDAAgDgCQgEgCgDgEIAAAcgAgKgcQgBAIgBALIABAMQABAGACAEQAEADAEAAQAHAAACgGQADgHAAgNQAAgZgMAAQgHAAgDAHg");
  this.shape_124.setTransform(129.95, 8.025);
  this.shape_125 = new cjs.Shape();
  this.shape_125.graphics.f("#0C593C").s().p("AgVAQQAAgFABgEQACgEADgCIAKgEIAKgEQADgBAAgHQAAgFgDgDQgCgCgEAAQgFAAgCADQgDADAAAFIgIAAQAAgTATAAQAFAAAEADQAEACACAEQACADAAAFIAAAlQAAAFADAAIACAAIAAAGIgEABQgEAAgCgCQgCgBgBgGIgBAAQgBAEgEADQgDADgFAAQgQAAAAgSgAABABIgHADIgEAFQgCADAAAEQAAAKAJAAQAFAAADgEIACgCIAAgEIABgGIAAgMIgHADg");
  this.shape_125.setTransform(122.325, 7.025);
  this.shape_126 = new cjs.Shape();
  this.shape_126.graphics.f("#0C593C").s().p("AALAgIAAg4IgVAAIAAA4IgJAAIAAg/IAnAAIAAA/g");
  this.shape_126.setTransform(114.8, 7.05);
  this.shape_127 = new cjs.Shape();
  this.shape_127.graphics.f("#0C593C").s().p("AgKAfQgEgDgDgIQgCgHAAgNQAAghATAAQAJAAAEAFQAFAFABAHQABAHAAAKIgeAAIABAOQABAFACADQADADAEAAQAKAAAAgPIAJAAQAAAGgCAGQgCAFgEADQgFADgGAAQgGAAgFgDgAgIgTQgCAFAAAIIAVAAQAAgJgCgFQgCgFgHAAQgFAAgDAGg");
  this.shape_127.setTransform(107.225, 7.025);
  this.shape_128 = new cjs.Shape();
  this.shape_128.graphics.f("#0C593C").s().p("AgUAsIAAhVIAIAAIAAAHIABAAQABgEAEgCQAEgDADAAQAVAAgBAhIgBANIgCALQgDAFgEACQgEADgGAAQgEAAgDgCQgDgCgCgEIAAAcgAgJgcQgCAIAAALIAAAMQABAGADAEQADADAEAAQAGAAADgGQADgHAAgNQAAgZgMAAQgHAAgCAHg");
  this.shape_128.setTransform(99.85, 8.025);
  this.shape_129 = new cjs.Shape();
  this.shape_129.graphics.f("#0C593C").s().p("AALAgIAAg4IgWAAIAAA4IgJAAIAAg/IApAAIAAA/g");
  this.shape_129.setTransform(91.9, 7.05);
  this.shape_130 = new cjs.Shape();
  this.shape_130.graphics.f("#0C593C").s().p("AgGAbQgGgIAAgRIgLAAIAAAeIgJAAIAAg/IAJAAIAAAbIALAAQAAgNAGgIQAGgIAKAAQAMAAAFAJQAGAIAAAPQAAANgCAHQgEAIgEAEQgGADgHAAQgKAAgGgHgAACgWQgCACgBAGQgCAGABAJQAAAMACAHQACAGAIAAQAHAAADgGQAEgHAAgMQAAgOgEgGQgDgGgHAAQgFAAgDADg");
  this.shape_130.setTransform(78, 7.025);
  this.shape_131 = new cjs.Shape();
  this.shape_131.graphics.f("#0C593C").s().p("AAMAgIAAgvIABgJIgCAJIgUAvIgLAAIAAg/IAJAAIAAAwIgBAIIACgIIAUgwIALAAIAAA/g");
  this.shape_131.setTransform(68.825, 7.05);
  this.shape_132 = new cjs.Shape();
  this.shape_132.graphics.f("#0C593C").s().p("AALAgIAAgeIgWAAIAAAeIgJAAIAAg/IAJAAIAAAaIAWAAIAAgaIAJAAIAAA/g");
  this.shape_132.setTransform(60.95, 7.05);
  this.shape_133 = new cjs.Shape();
  this.shape_133.graphics.f("#0C593C").s().p("AgKAfQgEgDgDgIQgCgHAAgNQAAghATAAQAJAAAEAFQAFAFABAHQABAHAAAKIgeAAIABAOQABAFACADQADADAEAAQAKAAAAgPIAJAAQAAAGgCAGQgCAFgEADQgFADgGAAQgGAAgFgDgAgIgTQgCAFAAAIIAVAAQAAgJgCgFQgCgFgHAAQgFAAgDAGg");
  this.shape_133.setTransform(53.375, 7.025);
  this.shape_134 = new cjs.Shape();
  this.shape_134.graphics.f("#0C593C").s().p("AALAgIAAgeIgWAAIAAAeIgJAAIAAg/IAJAAIAAAaIAWAAIAAgaIAKAAIAAA/g");
  this.shape_134.setTransform(45.9, 7.05);
  this.shape_135 = new cjs.Shape();
  this.shape_135.graphics.f("#0C593C").s().p("AgKAfQgEgDgDgIQgCgHAAgNQAAghATAAQAJAAAEAFQAFAFABAHQABAHAAAKIgeAAIABAOQABAFACADQADADAEAAQAKAAAAgPIAJAAQAAAGgCAGQgCAFgEADQgFADgGAAQgGAAgFgDgAgIgTQgCAFAAAIIAVAAQAAgJgCgFQgCgFgHAAQgFAAgDAGg");
  this.shape_135.setTransform(38.325, 7.025);
  this.shape_136 = new cjs.Shape();
  this.shape_136.graphics.f("#0C593C").s().p("AATAgIAAg4IgQA4IgFAAIgQg4IAAA4IgJAAIAAg/IAOAAIAMApIABANIACgNIAMgpIAOAAIAAA/g");
  this.shape_136.setTransform(30.075, 7.05);
  this.shape_137 = new cjs.Shape();
  this.shape_137.graphics.f("#0C593C").s().p("AAMAgIAAgvIABgJIgCAJIgUAvIgLAAIAAg/IAJAAIAAAwIgBAIIACgIIAUgwIALAAIAAA/g");
  this.shape_137.setTransform(21.425, 7.05);
  this.shape_138 = new cjs.Shape();
  this.shape_138.graphics.f("#0C593C").s().p("AgUAsIAAhVIAIAAIAAAHIABAAQACgEADgCQAEgDACAAQAWAAAAAhIgCANIgDALQgCAFgEACQgEADgGAAQgEAAgDgCQgDgCgCgEIAAAcgAgKgcQgBAIAAALIAAAMQABAGACAEQADADAFAAQAHAAACgGQADgHAAgNQAAgZgMAAQgHAAgDAHg");
  this.shape_138.setTransform(13.65, 8.025);
  this.shape_139 = new cjs.Shape();
  this.shape_139.graphics.f("#0C593C").s().p("AALAgIAAg4IgVAAIAAA4IgJAAIAAg/IAnAAIAAA/g");
  this.shape_139.setTransform(5.7, 7.05);
  this.shape_140 = new cjs.Shape();
  this.shape_140.graphics.f("#0C593C").s().p("AgVAqIAAgIIAHABQAEAAADgDQACgEACgGIgUhAIAJAAIAOAyIABAAIAOgyIAJAAIgUA/IgEAMQgBAEgEADQgDADgGAAIgHgBg");
  this.shape_140.setTransform(152.375, -3.2);
  this.shape_141 = new cjs.Shape();
  this.shape_141.graphics.f("#0C593C").s().p("AATAgIAAg4IgQA4IgFAAIgQg4IAAA4IgJAAIAAg/IAOAAIAMApIABANIACgNIAMgpIAOAAIAAA/g");
  this.shape_141.setTransform(145.875, -4.3);
  this.shape_142 = new cjs.Shape();
  this.shape_142.graphics.f("#0C593C").s().p("AgLAfQgGgDgCgIQgDgHAAgNQAAgPAFgJQAGgJALAAQAXAAAAAhQAAANgDAHQgDAIgFADQgFADgHAAQgGAAgFgDgAgHgWQgDACgBAGIgCAPIACAOQABAFACADQADADAFAAQAFAAADgDQADgDABgFIABgOIgBgPQgBgGgDgCQgDgDgFAAQgEAAgDADg");
  this.shape_142.setTransform(139, -4.325);
  this.shape_143 = new cjs.Shape();
  this.shape_143.graphics.f("#0C593C").s().p("AALAgIgPggIgHAJIAAAXIgJAAIAAg/IAJAAIAAAeIAVgeIALAAIgUAZIAUAmg");
  this.shape_143.setTransform(133.525, -4.3);
  this.shape_144 = new cjs.Shape();
  this.shape_144.graphics.f("#0C593C").s().p("AgMAdQgEgEgCgHQgCgHAAgKQAAgiAVAAQAKAAAFAHQAFAGAAAJIgJAAQAAgOgLAAQgGAAgDAHQgCAIAAALQAAALACAHQACAHAHAAQAHAAACgEQACgEAAgIIAJAAQAAAKgFAHQgEAHgKAAQgJAAgFgFg");
  this.shape_144.setTransform(127.675, -4.325);
  this.shape_145 = new cjs.Shape();
  this.shape_145.graphics.f("#0C593C").s().p("AALAgIAAgeIgWAAIAAAeIgJAAIAAg/IAJAAIAAAaIAWAAIAAgaIAKAAIAAA/g");
  this.shape_145.setTransform(121.85, -4.3);
  this.shape_146 = new cjs.Shape();
  this.shape_146.graphics.f("#0C593C").s().p("AAMAgIAAgvIABgJIgCAJIgUAvIgLAAIAAg/IAJAAIAAAwIgBAHIACgHIAUgwIALAAIAAA/g");
  this.shape_146.setTransform(115.625, -4.3);
  this.shape_147 = new cjs.Shape();
  this.shape_147.graphics.f("#0C593C").s().p("AAPApIAAgSIglAAIAAg/IAJAAIAAA4IAVAAIAAg4IAJAAIAAA4IAHAAIAAAZg");
  this.shape_147.setTransform(109.6, -3.425);
  this.shape_148 = new cjs.Shape();
  this.shape_148.graphics.f("#0C593C").s().p("AAMAgIAAgvIABgJIgCAJIgUAvIgLAAIAAg/IAJAAIAAAwIgBAHIACgHIAUgwIALAAIAAA/g");
  this.shape_148.setTransform(103.075, -4.3);
  this.shape_149 = new cjs.Shape();
  this.shape_149.graphics.f("#0C593C").s().p("AATApIAAgSIglAAIAAASIgIAAIAAgZIAFAAIAFgMIACgJIABgOIAAgVIAiAAIAAA4IAGAAIAAAZgAgEgOQAAAKgCAFQgBAGgEAJIAXAAIAAgwIgQAAg");
  this.shape_149.setTransform(96.775, -3.425);
  this.shape_150 = new cjs.Shape();
  this.shape_150.graphics.f("#0C593C").s().p("AgKAfQgEgDgDgIQgCgHAAgNQAAghATAAQAJAAAEAFQAFAFABAHQABAHAAAKIgeAAIABAOQABAFACADQADADAEAAQAKAAAAgPIAJAAQAAAGgCAGQgCAFgEADQgFADgGAAQgGAAgFgDgAgIgTQgCAFAAAIIAVAAQAAgJgCgFQgCgFgHAAQgFAAgDAGg");
  this.shape_150.setTransform(90.875, -4.325);
  this.shape_151 = new cjs.Shape();
  this.shape_151.graphics.f("#0C593C").s().p("AATAgIAAg4IgQA4IgFAAIgQg4IAAA4IgJAAIAAg/IAOAAIAMApIABANIACgNIAMgpIAOAAIAAA/g");
  this.shape_151.setTransform(84.325, -4.3);
  this.shape_152 = new cjs.Shape();
  this.shape_152.graphics.f("#0C593C").s().p("AgLAfQgFgDgEgIQgCgHAAgNQAAgPAFgJQAGgJALAAQAXAAAAAhQAAANgDAHQgDAIgEADQgGADgHAAQgHAAgEgDgAgHgWQgDACgBAGIgBAPIABAOQABAFACADQADADAFAAQAFAAADgDQADgDABgFIABgOIgBgPQgCgGgDgCQgDgDgEAAQgEAAgDADg");
  this.shape_152.setTransform(74.15, -4.325);
  this.shape_153 = new cjs.Shape();
  this.shape_153.graphics.f("#0C593C").s().p("AALAgIAAg4IgVAAIAAA4IgJAAIAAg/IAnAAIAAA/g");
  this.shape_153.setTransform(68, -4.3);
  this.shape_154 = new cjs.Shape();
  this.shape_154.graphics.f("#0C593C").s().p("AAMAgIAAgvIABgJIgCAJIgUAvIgLAAIAAg/IAJAAIAAAwIgBAHIACgHIAUgwIALAAIAAA/g");
  this.shape_154.setTransform(58.475, -4.3);
  this.shape_155 = new cjs.Shape();
  this.shape_155.graphics.f("#0C593C").s().p("AAMAgIAAgvIABgJIgCAJIgUAvIgLAAIAAg/IAJAAIAAAwIgBAHIACgHIAUgwIALAAIAAA/g");
  this.shape_155.setTransform(52.225, -4.3);
  this.shape_156 = new cjs.Shape();
  this.shape_156.graphics.f("#0C593C").s().p("AAPApIAAgSIgmAAIAAg/IAJAAIAAA4IAWAAIAAg4IAKAAIAAA4IAFAAIAAAZg");
  this.shape_156.setTransform(46.2, -3.425);
  this.shape_157 = new cjs.Shape();
  this.shape_157.graphics.f("#0C593C").s().p("AALAgIgPggIgHAJIAAAXIgJAAIAAg/IAJAAIAAAeIAVgeIALAAIgUAZIAUAmg");
  this.shape_157.setTransform(40.425, -4.3);
  this.shape_158 = new cjs.Shape();
  this.shape_158.graphics.f("#0C593C").s().p("AgVAqIAAgIIAHABQAEAAADgDQACgEACgGIgUhAIAJAAIAOAyIABAAIAOgyIAJAAIgUA/IgEAMQgBAEgEADQgDADgGAAIgHgBg");
  this.shape_158.setTransform(34.475, -3.2);
  this.shape_159 = new cjs.Shape();
  this.shape_159.graphics.f("#0C593C").s().p("AgUAsIAAhVIAIAAIAAAHIABAAQACgEADgCQAEgDACAAQAWAAgBAhIgBANIgCALQgDAFgEACQgEADgGAAQgDAAgEgCQgDgCgCgEIAAAcgAgJgcQgCAIAAALIAAAMQABAGACAEQAEADAEAAQAHAAACgGQADgHAAgNQAAgZgMAAQgHAAgCAHg");
  this.shape_159.setTransform(28.85, -3.325);
  this.shape_160 = new cjs.Shape();
  this.shape_160.graphics.f("#0C593C").s().p("AgEAgIAAg4IgQAAIAAgHIApAAIAAAHIgRAAIAAA4g");
  this.shape_160.setTransform(23.275, -4.3);
  this.shape_161 = new cjs.Shape();
  this.shape_161.graphics.f("#0C593C").s().p("AgMAdQgEgEgCgHQgCgHAAgKQAAgiAVAAQAKAAAFAHQAFAGAAAJIgJAAQAAgOgLAAQgGAAgDAHQgCAIAAALQAAALACAHQACAHAHAAQAHAAACgEQACgEAAgIIAJAAQAAAKgFAHQgEAHgKAAQgJAAgFgFg");
  this.shape_161.setTransform(18.125, -4.325);
  this.shape_162 = new cjs.Shape();
  this.shape_162.graphics.f("#0C593C").s().p("AALAgIAAgeIgVAAIAAAeIgJAAIAAg/IAJAAIAAAaIAVAAIAAgaIAJAAIAAA/g");
  this.shape_162.setTransform(12.3, -4.3);
  this.shape_163 = new cjs.Shape();
  this.shape_163.graphics.f("#0C593C").s().p("AAMAgIAAgvIABgJIgCAJIgUAvIgLAAIAAg/IAJAAIAAAwIgBAHIACgHIAUgwIALAAIAAA/g");
  this.shape_163.setTransform(6.075, -4.3);
  this.shape_164 = new cjs.Shape();
  this.shape_164.graphics.f("#0C593C").s().p("AAMAgIAAgvIABgIIgCAIIgUAvIgLAAIAAg/IAJAAIAAAvIgBAIIACgIIAUgvIALAAIAAA/g");
  this.shape_164.setTransform(150.625, -15.65);
  this.shape_165 = new cjs.Shape();
  this.shape_165.graphics.f("#0C593C").s().p("AATAgIAAg3IgQA3IgFAAIgQg3IAAA3IgJAAIAAg/IAOAAIAMApIABANIACgNIAMgpIAOAAIAAA/g");
  this.shape_165.setTransform(142.975, -15.65);
  this.shape_166 = new cjs.Shape();
  this.shape_166.graphics.f("#0C593C").s().p("AAVAgIAAg/IAJAAIAAA/gAgdAgIAAg/IAKAAIAAAbIAMAAQAGAAADACQAEACACAEQACAEAAAGQAAAFgCAEQgCAFgEACQgDACgGAAgAgTAYIAJAAQAGAAADgDQACgCAAgGQAAgLgKABIgKAAg");
  this.shape_166.setTransform(134.475, -15.65);
  this.shape_167 = new cjs.Shape();
  this.shape_167.graphics.f("#0C593C").s().p("AALAgIAAgeIgVAAIAAAeIgJAAIAAg/IAJAAIAAAaIAVAAIAAgaIAJAAIAAA/g");
  this.shape_167.setTransform(126.75, -15.65);
  this.shape_168 = new cjs.Shape();
  this.shape_168.graphics.f("#0C593C").s().p("AALAgIAAgeIgWAAIAAAeIgJAAIAAg/IAJAAIAAAaIAWAAIAAgaIAJAAIAAA/g");
  this.shape_168.setTransform(119.9, -15.65);
  this.shape_169 = new cjs.Shape();
  this.shape_169.graphics.f("#0C593C").s().p("AgVAQQAAgFABgEQACgEADgCIAKgEIAKgEQADgBAAgHQAAgFgDgDQgCgCgEAAQgFAAgCADQgDADAAAFIgIAAQAAgTATAAQAFAAAEADQAEACACAEQACADAAAFIAAAlQAAAFADAAIACAAIAAAGIgEABQgEAAgCgCQgCgBgBgGIgBAAQgBAEgEADQgDADgFAAQgQAAAAgSgAABABIgHADIgEAFQgCADAAAEQAAAKAJAAQAFAAADgEIACgCIAAgEIABgGIAAgMIgHADg");
  this.shape_169.setTransform(113.375, -15.675);
  this.shape_170 = new cjs.Shape();
  this.shape_170.graphics.f("#0C593C").s().p("AATApIAAgSIglAAIAAASIgIAAIAAgZIAFAAIAFgMIACgJIABgOIAAgVIAiAAIAAA4IAGAAIAAAZgAgEgOQAAAKgCAFQgBAGgEAJIAXAAIAAgwIgQAAg");
  this.shape_170.setTransform(106.725, -14.775);
  this.shape_171 = new cjs.Shape();
  this.shape_171.graphics.f("#0C593C").s().p("AgMAdQgEgEgCgHQgCgHAAgKQAAgiAVAAQAKAAAFAHQAFAGAAAJIgJAAQAAgOgLAAQgGAAgDAHQgCAIAAALQAAALACAHQACAHAHAAQAHAAACgEQACgEAAgIIAJAAQAAAKgFAHQgEAHgKAAQgJAAgFgFg");
  this.shape_171.setTransform(96.175, -15.675);
  this.shape_172 = new cjs.Shape();
  this.shape_172.graphics.f("#0C593C").s().p("AAMAgIAAgvIABgIIgCAIIgUAvIgLAAIAAg/IAJAAIAAAvIgBAIIACgIIAUgvIALAAIAAA/g");
  this.shape_172.setTransform(85.575, -15.65);
  this.shape_173 = new cjs.Shape();
  this.shape_173.graphics.f("#0C593C").s().p("AAMAgIAAgvIABgIIgCAIIgUAvIgLAAIAAg/IAJAAIAAAvIgBAIIACgIIAUgvIALAAIAAA/g");
  this.shape_173.setTransform(78.625, -15.65);
  this.shape_174 = new cjs.Shape();
  this.shape_174.graphics.f("#0C593C").s().p("AgTAgIAAg/IAUAAQAHAAAGAEQAEAEAAAHQAAAGgCAEQgDAEgFABQAFABADAEQAEAEAAAGQAAAGgDAEQgCAEgDACQgEACgEAAgAgKAYIAKAAQAGAAACgCQACgDAAgGQAAgFgCgDQgDgDgFABIgKAAgAgKgEIAKAAQAEAAADgCQACgDAAgFQAAgKgJABIgKAAg");
  this.shape_174.setTransform(72.15, -15.65);
  this.shape_175 = new cjs.Shape();
  this.shape_175.graphics.f("#0C593C").s().p("AgEAgIAAg3IgQAAIAAgIIApAAIAAAIIgRAAIAAA3g");
  this.shape_175.setTransform(66.075, -15.65);
  this.shape_176 = new cjs.Shape();
  this.shape_176.graphics.f("#0C593C").s().p("AgMAdQgEgEgCgHQgCgHAAgKQAAgiAVAAQAKAAAFAHQAFAGAAAJIgJAAQAAgOgLAAQgGAAgDAHQgCAIAAALQAAALACAHQACAHAHAAQAHAAACgEQACgEAAgIIAJAAQAAAKgFAHQgEAHgKAAQgJAAgFgFg");
  this.shape_176.setTransform(60.225, -15.675);
  this.shape_177 = new cjs.Shape();
  this.shape_177.graphics.f("#0C593C").s().p("AgEAgIAAg3IgQAAIAAgIIApAAIAAAIIgRAAIAAA3g");
  this.shape_177.setTransform(54.375, -15.65);
  this.shape_178 = new cjs.Shape();
  this.shape_178.graphics.f("#0C593C").s().p("AgKAfQgEgDgDgIQgCgHAAgNQAAghATAAQAJAAAEAFQAFAFABAHQABAHAAAKIgeAAIABAOQABAFACADQADADAEAAQAKAAAAgPIAJAAQAAAGgCAGQgCAFgEADQgFADgGAAQgGAAgFgDgAgIgTQgCAFAAAIIAVAAQAAgJgCgFQgCgFgHAAQgFAAgDAGg");
  this.shape_178.setTransform(48.475, -15.675);
  this.shape_179 = new cjs.Shape();
  this.shape_179.graphics.f("#0C593C").s().p("AgTAgIAAg/IAUAAQAIAAAEAEQAFAEAAAHQAAAGgDAEQgCAEgEABQAEABADAEQAEAEAAAGQAAAGgCAEQgDAEgDACQgEACgEAAgAgKAYIAKAAQAGAAADgCQACgDAAgGQgBgFgCgDQgDgDgEABIgLAAgAgKgEIAKAAQAEAAACgCQADgDAAgFQAAgKgJABIgKAAg");
  this.shape_179.setTransform(42.4, -15.65);
  this.shape_180 = new cjs.Shape();
  this.shape_180.graphics.f("#0C593C").s().p("AgEAgIAAg3IgQAAIAAgIIApAAIAAAIIgRAAIAAA3g");
  this.shape_180.setTransform(36.325, -15.65);
  this.shape_181 = new cjs.Shape();
  this.shape_181.graphics.f("#0C593C").s().p("AgMAfQgFgDgDgIQgCgHAAgNQAAgPAGgJQAFgJALAAQAXAAAAAhQAAANgDAHQgDAIgEADQgGADgHAAQgHAAgFgDgAgHgWQgDACgCAGIgBAPIABAOQACAFADADQADADAEAAQAFAAADgDQADgDABgFIABgOIgBgPQgBgGgEgCQgDgDgEAAQgEAAgDADg");
  this.shape_181.setTransform(30.15, -15.675);
  this.shape_182 = new cjs.Shape();
  this.shape_182.graphics.f("#0C593C").s().p("AgMAfQgEgDgEgIQgCgHAAgNQAAgPAFgJQAGgJALAAQAXAAAAAhQAAANgDAHQgDAIgEADQgGADgHAAQgHAAgFgDgAgHgWQgDACgCAGIAAAPIAAAOQACAFACADQADADAFAAQAFAAADgDQADgDABgFIABgOIgBgPQgCgGgDgCQgDgDgEAAQgEAAgDADg");
  this.shape_182.setTransform(23.3, -15.675);
  this.shape_183 = new cjs.Shape();
  this.shape_183.graphics.f("#0C593C").s().p("AgMAdQgEgEgCgHQgCgHAAgKQAAgiAVAAQAKAAAFAHQAFAGAAAJIgJAAQAAgOgLAAQgGAAgDAHQgCAIAAALQAAALACAHQACAHAHAAQAHAAACgEQACgEAAgIIAJAAQAAAKgFAHQgEAHgKAAQgJAAgFgFg");
  this.shape_183.setTransform(16.775, -15.675);
  this.shape_184 = new cjs.Shape();
  this.shape_184.graphics.f("#0C593C").s().p("AgTAgIAAg/IAUAAQAIAAAFAEQAEAEAAAHQAAAGgDAEQgCAEgFABQAGABACAEQAEAEAAAGQAAAGgDAEQgCAEgDACQgEACgEAAgAgKAYIAKAAQAGAAACgCQACgDABgGQAAgFgDgDQgDgDgFABIgKAAgAgKgEIAKAAQAEAAACgCQADgDAAgFQAAgKgJABIgKAAg");
  this.shape_184.setTransform(6.65, -15.65);
  this.shape_185 = new cjs.Shape();
  this.shape_185.graphics.f("#0C593C").s().p("AgEAgIAAgMIAJAAIAAAMgAgEgTIAAgLIAJAAIAAALg");
  this.shape_185.setTransform(151.575, -26.95);
  this.shape_186 = new cjs.Shape();
  this.shape_186.graphics.f("#0C593C").s().p("AgVAQQAAgFABgEQACgEADgCIAKgEIAKgEQADgBAAgHQAAgFgDgDQgCgCgEAAQgFAAgCADQgDADAAAFIgIAAQAAgTATAAQAFAAAEADQAEACACAEQACADAAAFIAAAlQAAAFADAAIACAAIAAAGIgEABQgEAAgCgCQgCgBgBgGIgBAAQgBAEgEADQgDADgFAAQgQAAAAgSgAABABIgHADIgEAFQgCADAAAEQAAAKAJAAQAFAAADgEIACgCIAAgEIABgGIAAgMIgHADg");
  this.shape_186.setTransform(144.225, -27.025);
  this.shape_187 = new cjs.Shape();
  this.shape_187.graphics.f("#0C593C").s().p("AgTAgIAAg/IAUAAQAIAAAFAEQAEAFAAAGQAAAGgDAEQgCAEgFABQAGABACAEQAEAEAAAGQAAAGgDAEQgCAEgDACQgEACgEAAgAgKAYIAKAAQAGABACgDQACgDABgGQAAgFgDgDQgDgDgFABIgKAAgAgKgEIAKAAQAEAAACgCQADgDAAgFQAAgKgJABIgKAAg");
  this.shape_187.setTransform(135.8, -27);
  this.shape_188 = new cjs.Shape();
  this.shape_188.graphics.f("#0C593C").s().p("AgEAgIAAg3IgQAAIAAgIIApAAIAAAIIgRAAIAAA3g");
  this.shape_188.setTransform(127.425, -27);
  this.shape_189 = new cjs.Shape();
  this.shape_189.graphics.f("#0C593C").s().p("AgMAdQgEgEgCgHQgCgHAAgKQAAgiAVAAQAKAAAFAHQAFAGAAAJIgJAAQAAgOgLAAQgGAAgDAHQgCAIAAALQAAALACAHQACAHAHAAQAHAAACgEQACgEAAgIIAJAAQAAAKgFAHQgEAHgKAAQgJAAgFgFg");
  this.shape_189.setTransform(119.275, -27.025);
  this.shape_190 = new cjs.Shape();
  this.shape_190.graphics.f("#0C593C").s().p("AATApIAAgSIglAAIAAASIgIAAIAAgZIAFAAIAFgMIACgJIABgOIAAgVIAiAAIAAA4IAGAAIAAAZgAgEgOQAAAKgCAFQgBAGgEAJIAXAAIAAgwIgQAAg");
  this.shape_190.setTransform(110.325, -26.125);
  this.shape_191 = new cjs.Shape();
  this.shape_191.graphics.f("#0C593C").s().p("AgKAfQgEgDgDgIQgCgHAAgNQAAghATAAQAJAAAEAFQAFAFABAHQABAHAAAKIgeAAIABAOQABAFACADQADADAEAAQAKAAAAgPIAJAAQAAAGgCAGQgCAFgEADQgFADgGAAQgGAAgFgDgAgIgTQgCAFAAAIIAVAAQAAgJgCgFQgCgFgHAAQgFAAgDAGg");
  this.shape_191.setTransform(101.425, -27.025);
  this.shape_192 = new cjs.Shape();
  this.shape_192.graphics.f("#0C593C").s().p("AgUAsIAAhVIAIAAIAAAHIABAAQACgEADgCQAEgDACAAQAWAAgBAhIgBANIgCALQgDAFgEACQgEADgGAAQgDAAgEgCQgDgCgCgEIAAAcgAgJgcQgCAIAAALIAAAMQABAGACAEQAEADAEAAQAHAAACgGQADgHAAgNQAAgZgMAAQgHAAgCAHg");
  this.shape_192.setTransform(92.75, -26.025);
  this.shape_193 = new cjs.Shape();
  this.shape_193.graphics.f("#0C593C").s().p("AgMAdQgEgEgCgHQgCgHAAgKQAAgiAVAAQAKAAAFAHQAFAGAAAJIgJAAQAAgOgLAAQgGAAgDAHQgCAIAAALQAAALACAHQACAHAHAAQAHAAACgEQACgEAAgIIAJAAQAAAKgFAHQgEAHgKAAQgJAAgFgFg");
  this.shape_193.setTransform(83.825, -27.025);
  this.shape_194 = new cjs.Shape();
  this.shape_194.graphics.f("#0C593C").s().p("AgMAfQgEgDgDgIQgDgHAAgNQAAgPAGgJQAFgJALAAQAXAAAAAhQAAANgDAHQgDAIgFADQgFADgHAAQgGAAgGgDgAgHgWQgDACgCAGIgBAPIABAOQACAFADADQADADAEAAQAFAAADgDQADgDABgFIABgOIgBgPQgBgGgDgCQgEgDgEAAQgEAAgDADg");
  this.shape_194.setTransform(68.7, -27.025);
  this.shape_195 = new cjs.Shape();
  this.shape_195.graphics.f("#0C593C").s().p("AgQAgIAAg/IAhAAIAAAIIgYAAIAAA3g");
  this.shape_195.setTransform(60.675, -27);
  this.shape_196 = new cjs.Shape();
  this.shape_196.graphics.f("#0C593C").s().p("AgLAfQgGgDgCgIQgDgHAAgNQAAgPAFgJQAGgJALAAQAXAAAAAhQAAANgDAHQgCAIgFADQgGADgHAAQgHAAgEgDgAgHgWQgDACgBAGIgBAPIABAOQABAFACADQADADAFAAQAFAAADgDQADgDABgFIABgOIgBgPQgCgGgDgCQgCgDgFAAQgEAAgDADg");
  this.shape_196.setTransform(51.9, -27.025);
  this.shape_197 = new cjs.Shape();
  this.shape_197.graphics.f("#0C593C").s().p("AALAgIAAgeIgWAAIAAAeIgJAAIAAg/IAJAAIAAAbIAWAAIAAgbIAKAAIAAA/g");
  this.shape_197.setTransform(42.75, -27);
  this.shape_198 = new cjs.Shape();
  this.shape_198.graphics.f("#0C593C").s().p("AAKAgIAAgeQgFABgIABQgIAAgDgFQgFgEAAgHIAAgTIAJAAIAAASQAAAFACADQADABAFAAIAKAAIAAgbIAKAAIAAA/g");
  this.shape_198.setTransform(33.65, -27);
  this.shape_199 = new cjs.Shape();
  this.shape_199.graphics.f("#0C593C").s().p("AAVAgIAAg/IAJAAIAAA/gAgdAgIAAg/IAKAAIAAAbIAMAAQAGAAADACQAEACACAEQACAFAAAFQAAAFgCAEQgCAEgEADQgDACgGAAgAgTAYIAJAAQAGAAADgCQACgDAAgGQAAgLgKABIgKAAg");
  this.shape_199.setTransform(23.725, -27);
  this.shape_200 = new cjs.Shape();
  this.shape_200.graphics.f("#0C593C").s().p("AgMAoQgGgEgCgIQgCgJAAgNIABgRQACgIACgFQADgFADgDQAEgDAFgBIAKgDQADgBABgDIAIAAQgCAGgEADQgEADgJACQgFACgFAEQgDAGgBAIQAFgKAJAAQAHAAAFADQAEAEADAHQADAGAAAJQAAAMgCAHQgDAIgFADQgGAEgHAAQgIAAgEgEgAgJgFQgDAFAAAKIAAAPQACAGADADQADADAEAAQAHgBADgGQADgHAAgNQAAgKgDgFQgEgHgGAAQgGAAgDAHg");
  this.shape_200.setTransform(13.85, -28.05);
  this.shape_201 = new cjs.Shape();
  this.shape_201.graphics.f("#0C593C").s().p("AgMAfQgFgDgDgIQgCgHAAgNQAAgPAGgJQAFgJALAAQAXAAAAAhQAAANgDAHQgDAIgEADQgGADgHAAQgHAAgFgDgAgHgWQgDACgCAGIgBAPIABAOQACAFADADQADADAEAAQAFAAADgDQADgDABgFIABgOIgBgPQgBgGgEgCQgDgDgEAAQgEAAgDADg");
  this.shape_201.setTransform(4.95, -27.025);
  this.shape_202 = new cjs.Shape();
  this.shape_202.graphics.f("#0C593C").s().p("AgXAfIAAgHIAEABQAAAAABAAQABAAAAgBQABAAAAAAQAAgBABAAIACgHIAAgQIAAgfIAlAAIAAA/IgJAAIAAg4IgTAAIAAAZQAAAPgDAIQgDAIgIAAIgFgBg");
  this.shape_202.setTransform(152.175, -38.325);
  this.shape_203 = new cjs.Shape();
  this.shape_203.graphics.f("#0C593C").s().p("AgVAqIAAgIIAHABQAEAAADgDQACgEACgGIgUhAIAJAAIAOAyIABAAIAOgyIAJAAIgUA/IgEAMQgBAEgEADQgDADgGAAIgHgBg");
  this.shape_203.setTransform(146.075, -37.25);
  this.shape_204 = new cjs.Shape();
  this.shape_204.graphics.f("#0C593C").s().p("AgMAdQgEgEgCgHQgCgHAAgKQAAgiAVAAQAKAAAFAHQAFAGAAAJIgJAAQAAgOgLAAQgGAAgDAHQgCAIAAALQAAALACAHQACAHAHAAQAHAAACgEQACgEAAgIIAJAAQAAAKgFAHQgEAHgKAAQgJAAgFgFg");
  this.shape_204.setTransform(140.175, -38.375);
  this.shape_205 = new cjs.Shape();
  this.shape_205.graphics.f("#0C593C").s().p("AALAgIAAg3IgWAAIAAA3IgJAAIAAg/IAoAAIAAA/g");
  this.shape_205.setTransform(133.85, -38.35);
  this.shape_206 = new cjs.Shape();
  this.shape_206.graphics.f("#0C593C").s().p("AgVAQQAAgFABgEQACgEADgCIAKgEIAKgEQADgBAAgHQAAgFgDgDQgCgCgEAAQgFAAgCADQgDADAAAFIgIAAQAAgTATAAQAFAAAEADQAEACACAEQACADAAAFIAAAlQAAAFADAAIACAAIAAAGIgEABQgEAAgCgCQgCgBgBgGIgBAAQgBAEgEADQgDADgFAAQgQAAAAgSgAABABIgHADIgEAFQgCADAAAEQAAAKAJAAQAFAAADgEIACgCIAAgEIABgGIAAgMIgHADg");
  this.shape_206.setTransform(127.525, -38.375);
  this.shape_207 = new cjs.Shape();
  this.shape_207.graphics.f("#0C593C").s().p("AALAgIgPggIgHAJIAAAXIgJAAIAAg/IAJAAIAAAeIAVgeIALAAIgUAZIAUAmg");
  this.shape_207.setTransform(121.875, -38.35);
  this.shape_208 = new cjs.Shape();
  this.shape_208.graphics.f("#0C593C").s().p("AgWArQAAgIABgFQACgGAEgGQAFgFAJgIQAGgFAEgFQAEgGAAgHQAAgQgNAAQgHAAgDAGQgCAFAAAKIgJAAIAAgEQAAgHACgGQADgGAFgDQAFgDAGAAQAHAAAFADQAGADACAFQADAGAAAHQAAAGgCAFQgCAFgEADIgIAIIgMAMIgFAGIgCAIIAjAAIAAAIg");
  this.shape_208.setTransform(111.325, -39.475);
  this.shape_209 = new cjs.Shape();
  this.shape_209.graphics.f("#0C593C").s().p("AgLAfQgGgDgCgIQgDgHAAgNQAAgPAFgJQAGgJALAAQAXAAAAAhQAAANgDAHQgCAIgFADQgGADgHAAQgHAAgEgDgAgHgWQgDACgBAGIgBAPIABAOQABAFACADQADADAFAAQAFAAADgDQADgDABgFIABgOIgBgPQgCgGgDgCQgCgDgFAAQgEAAgDADg");
  this.shape_209.setTransform(100.95, -38.375);
  this.shape_210 = new cjs.Shape();
  this.shape_210.graphics.f("#0C593C").s().p("AgEAgIAAg3IgQAAIAAgIIApAAIAAAIIgRAAIAAA3g");
  this.shape_210.setTransform(94.975, -38.35);
  this.shape_211 = new cjs.Shape();
  this.shape_211.graphics.f("#0C593C").s().p("AgMAdQgEgEgCgHQgCgHAAgKQAAgiAVAAQAKAAAFAHQAFAGAAAJIgJAAQAAgOgLAAQgGAAgDAHQgCAIAAALQAAALACAHQACAHAHAAQAHAAACgEQACgEAAgIIAJAAQAAAKgFAHQgEAHgKAAQgJAAgFgFg");
  this.shape_211.setTransform(89.325, -38.375);
  this.shape_212 = new cjs.Shape();
  this.shape_212.graphics.f("#0C593C").s().p("AgKAfQgEgDgDgIQgCgHAAgNQAAghATAAQAJAAAEAFQAFAFABAHQABAHAAAKIgeAAIABAOQABAFACADQADADAEAAQAKAAAAgPIAJAAQAAAGgCAGQgCAFgEADQgFADgGAAQgGAAgFgDgAgIgTQgCAFAAAIIAVAAQAAgJgCgFQgCgFgHAAQgFAAgDAGg");
  this.shape_212.setTransform(83.275, -38.375);
  this.shape_213 = new cjs.Shape();
  this.shape_213.graphics.f("#0C593C").s().p("AATAgIAAg3IgQA3IgFAAIgQg3IAAA3IgJAAIAAg/IAOAAIAMApIABANIACgNIAMgpIAOAAIAAA/g");
  this.shape_213.setTransform(76.225, -38.35);
  this.shape_214 = new cjs.Shape();
  this.shape_214.graphics.f("#0C593C").s().p("AgTAgIAAg/IAUAAQAHAAAFAEQAFAFAAAGQAAAGgCAEQgDAEgEABQAFABADAEQADAEAAAGQAAAGgCAEQgCAEgEACQgEACgEAAgAgJAYIAJAAQAGABADgDQABgDAAgGQABgFgDgDQgDgCgFAAIgJAAgAgJgEIAJAAQAEAAADgCQACgDAAgFQAAgJgJAAIgJAAg");
  this.shape_214.setTransform(69.25, -38.35);
  this.shape_215 = new cjs.Shape();
  this.shape_215.graphics.f("#0C593C").s().p("AgVAQQAAgFABgEQACgEADgCIAKgEIAKgEQADgBAAgHQAAgFgDgDQgCgCgEAAQgFAAgCADQgDADAAAFIgIAAQAAgTATAAQAFAAAEADQAEACACAEQACADAAAFIAAAlQAAAFADAAIACAAIAAAGIgEABQgEAAgCgCQgCgBgBgGIgBAAQgBAEgEADQgDADgFAAQgQAAAAgSgAABABIgHADIgEAFQgCADAAAEQAAAKAJAAQAFAAADgEIACgCIAAgEIABgGIAAgMIgHADg");
  this.shape_215.setTransform(59.225, -38.375);
  this.shape_216 = new cjs.Shape();
  this.shape_216.graphics.f("#0C593C").s().p("AgXAfIAAgHIAEABQAAAAABAAQABAAAAgBQABAAAAAAQAAgBABAAIACgHIAAgQIAAgfIAlAAIAAA/IgJAAIAAg4IgTAAIAAAZQAAAPgDAIQgDAIgIAAIgFgBg");
  this.shape_216.setTransform(52.575, -38.325);
  this.shape_217 = new cjs.Shape();
  this.shape_217.graphics.f("#0C593C").s().p("AgVAqIAAgIIAHABQAEAAADgDQACgEACgGIgUhAIAJAAIAOAyIABAAIAOgyIAJAAIgUA/IgEAMQgBAEgEADQgDADgGAAIgHgBg");
  this.shape_217.setTransform(46.475, -37.25);
  this.shape_218 = new cjs.Shape();
  this.shape_218.graphics.f("#0C593C").s().p("AgMAdQgEgEgCgHQgCgHAAgKQAAgiAVAAQAKAAAFAHQAFAGAAAJIgJAAQAAgOgLAAQgGAAgDAHQgCAIAAALQAAALACAHQACAHAHAAQAHAAACgEQACgEAAgIIAJAAQAAAKgFAHQgEAHgKAAQgJAAgFgFg");
  this.shape_218.setTransform(40.575, -38.375);
  this.shape_219 = new cjs.Shape();
  this.shape_219.graphics.f("#0C593C").s().p("AALAgIAAg3IgVAAIAAA3IgJAAIAAg/IAnAAIAAA/g");
  this.shape_219.setTransform(34.25, -38.35);
  this.shape_220 = new cjs.Shape();
  this.shape_220.graphics.f("#0C593C").s().p("AgVAQQAAgFABgEQACgEADgCIAKgEIAKgEQADgBAAgHQAAgFgDgDQgCgCgEAAQgFAAgCADQgDADAAAFIgIAAQAAgTATAAQAFAAAEADQAEACACAEQACADAAAFIAAAlQAAAFADAAIACAAIAAAGIgEABQgEAAgCgCQgCgBgBgGIgBAAQgBAEgEADQgDADgFAAQgQAAAAgSgAABABIgHADIgEAFQgCADAAAEQAAAKAJAAQAFAAADgEIACgCIAAgEIABgGIAAgMIgHADg");
  this.shape_220.setTransform(27.925, -38.375);
  this.shape_221 = new cjs.Shape();
  this.shape_221.graphics.f("#0C593C").s().p("AALAgIgPggIgHAJIAAAXIgJAAIAAg/IAJAAIAAAeIAVgeIALAAIgUAZIAUAmg");
  this.shape_221.setTransform(22.275, -38.35);
  this.shape_222 = new cjs.Shape();
  this.shape_222.graphics.f("#0C593C").s().p("AAFArIAAg+IgSAAIAAgHIALgBQADgCADgDQACgEAAgGIAIAAIAABVg");
  this.shape_222.setTransform(11.15, -39.475);
  this.shape_223 = new cjs.Shape();
  this.shape_223.graphics.f("#0C593C").s().p("AAAAFIgHAMIgFgEIAIgLIgNgEIACgEIANAEIAAgOIAFAAIAAAOIANgEIACAFIgNADIAIALIgEAEg");
  this.shape_223.setTransform(5.125, -42.1);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_223
   }, {
    t: this.shape_222
   }, {
    t: this.shape_221
   }, {
    t: this.shape_220
   }, {
    t: this.shape_219
   }, {
    t: this.shape_218
   }, {
    t: this.shape_217
   }, {
    t: this.shape_216
   }, {
    t: this.shape_215
   }, {
    t: this.shape_214
   }, {
    t: this.shape_213
   }, {
    t: this.shape_212
   }, {
    t: this.shape_211
   }, {
    t: this.shape_210
   }, {
    t: this.shape_209
   }, {
    t: this.shape_208
   }, {
    t: this.shape_207
   }, {
    t: this.shape_206
   }, {
    t: this.shape_205
   }, {
    t: this.shape_204
   }, {
    t: this.shape_203
   }, {
    t: this.shape_202
   }, {
    t: this.shape_201
   }, {
    t: this.shape_200
   }, {
    t: this.shape_199
   }, {
    t: this.shape_198
   }, {
    t: this.shape_197
   }, {
    t: this.shape_196
   }, {
    t: this.shape_195
   }, {
    t: this.shape_194
   }, {
    t: this.shape_193
   }, {
    t: this.shape_192
   }, {
    t: this.shape_191
   }, {
    t: this.shape_190
   }, {
    t: this.shape_189
   }, {
    t: this.shape_188
   }, {
    t: this.shape_187
   }, {
    t: this.shape_186
   }, {
    t: this.shape_185
   }, {
    t: this.shape_184
   }, {
    t: this.shape_183
   }, {
    t: this.shape_182
   }, {
    t: this.shape_181
   }, {
    t: this.shape_180
   }, {
    t: this.shape_179
   }, {
    t: this.shape_178
   }, {
    t: this.shape_177
   }, {
    t: this.shape_176
   }, {
    t: this.shape_175
   }, {
    t: this.shape_174
   }, {
    t: this.shape_173
   }, {
    t: this.shape_172
   }, {
    t: this.shape_171
   }, {
    t: this.shape_170
   }, {
    t: this.shape_169
   }, {
    t: this.shape_168
   }, {
    t: this.shape_167
   }, {
    t: this.shape_166
   }, {
    t: this.shape_165
   }, {
    t: this.shape_164
   }, {
    t: this.shape_163
   }, {
    t: this.shape_162
   }, {
    t: this.shape_161
   }, {
    t: this.shape_160
   }, {
    t: this.shape_159
   }, {
    t: this.shape_158
   }, {
    t: this.shape_157
   }, {
    t: this.shape_156
   }, {
    t: this.shape_155
   }, {
    t: this.shape_154
   }, {
    t: this.shape_153
   }, {
    t: this.shape_152
   }, {
    t: this.shape_151
   }, {
    t: this.shape_150
   }, {
    t: this.shape_149
   }, {
    t: this.shape_148
   }, {
    t: this.shape_147
   }, {
    t: this.shape_146
   }, {
    t: this.shape_145
   }, {
    t: this.shape_144
   }, {
    t: this.shape_143
   }, {
    t: this.shape_142
   }, {
    t: this.shape_141
   }, {
    t: this.shape_140
   }, {
    t: this.shape_139
   }, {
    t: this.shape_138
   }, {
    t: this.shape_137
   }, {
    t: this.shape_136
   }, {
    t: this.shape_135
   }, {
    t: this.shape_134
   }, {
    t: this.shape_133
   }, {
    t: this.shape_132
   }, {
    t: this.shape_131
   }, {
    t: this.shape_130
   }, {
    t: this.shape_129
   }, {
    t: this.shape_128
   }, {
    t: this.shape_127
   }, {
    t: this.shape_126
   }, {
    t: this.shape_125
   }, {
    t: this.shape_124
   }, {
    t: this.shape_123
   }, {
    t: this.shape_122
   }, {
    t: this.shape_121
   }, {
    t: this.shape_120
   }, {
    t: this.shape_119
   }, {
    t: this.shape_118
   }, {
    t: this.shape_117
   }, {
    t: this.shape_116
   }, {
    t: this.shape_115
   }, {
    t: this.shape_114
   }, {
    t: this.shape_113
   }, {
    t: this.shape_112
   }, {
    t: this.shape_111
   }, {
    t: this.shape_110
   }, {
    t: this.shape_109
   }, {
    t: this.shape_108
   }, {
    t: this.shape_107
   }, {
    t: this.shape_106
   }, {
    t: this.shape_105
   }, {
    t: this.shape_104
   }, {
    t: this.shape_103
   }, {
    t: this.shape_102
   }, {
    t: this.shape_101
   }, {
    t: this.shape_100
   }, {
    t: this.shape_99
   }, {
    t: this.shape_98
   }, {
    t: this.shape_97
   }, {
    t: this.shape_96
   }, {
    t: this.shape_95
   }, {
    t: this.shape_94
   }, {
    t: this.shape_93
   }, {
    t: this.shape_92
   }, {
    t: this.shape_91
   }, {
    t: this.shape_90
   }, {
    t: this.shape_89
   }, {
    t: this.shape_88
   }, {
    t: this.shape_87
   }, {
    t: this.shape_86
   }, {
    t: this.shape_85
   }, {
    t: this.shape_84
   }, {
    t: this.shape_83
   }, {
    t: this.shape_82
   }, {
    t: this.shape_81
   }, {
    t: this.shape_80
   }, {
    t: this.shape_79
   }, {
    t: this.shape_78
   }, {
    t: this.shape_77
   }, {
    t: this.shape_76
   }, {
    t: this.shape_75
   }, {
    t: this.shape_74
   }, {
    t: this.shape_73
   }, {
    t: this.shape_72
   }, {
    t: this.shape_71
   }, {
    t: this.shape_70
   }, {
    t: this.shape_69
   }, {
    t: this.shape_68
   }, {
    t: this.shape_67
   }, {
    t: this.shape_66
   }, {
    t: this.shape_65
   }, {
    t: this.shape_64
   }, {
    t: this.shape_63
   }, {
    t: this.shape_62
   }, {
    t: this.shape_61
   }, {
    t: this.shape_60
   }, {
    t: this.shape_59
   }, {
    t: this.shape_58
   }, {
    t: this.shape_57
   }, {
    t: this.shape_56
   }, {
    t: this.shape_55
   }, {
    t: this.shape_54
   }, {
    t: this.shape_53
   }, {
    t: this.shape_52
   }, {
    t: this.shape_51
   }, {
    t: this.shape_50
   }, {
    t: this.shape_49
   }, {
    t: this.shape_48
   }, {
    t: this.shape_47
   }, {
    t: this.shape_46
   }, {
    t: this.shape_45
   }, {
    t: this.shape_44
   }, {
    t: this.shape_43
   }, {
    t: this.shape_42
   }, {
    t: this.shape_41
   }, {
    t: this.shape_40
   }, {
    t: this.shape_39
   }, {
    t: this.shape_38
   }, {
    t: this.shape_37
   }, {
    t: this.shape_36
   }, {
    t: this.shape_35
   }, {
    t: this.shape_34
   }, {
    t: this.shape_33
   }, {
    t: this.shape_32
   }, {
    t: this.shape_31
   }, {
    t: this.shape_30
   }, {
    t: this.shape_29
   }, {
    t: this.shape_28
   }, {
    t: this.shape_27
   }, {
    t: this.shape_26
   }, {
    t: this.shape_25
   }, {
    t: this.shape_24
   }, {
    t: this.shape_23
   }, {
    t: this.shape_22
   }, {
    t: this.shape_21
   }, {
    t: this.shape_20
   }, {
    t: this.shape_19
   }, {
    t: this.shape_18
   }, {
    t: this.shape_17
   }, {
    t: this.shape_16
   }, {
    t: this.shape_15
   }, {
    t: this.shape_14
   }, {
    t: this.shape_13
   }, {
    t: this.shape_12
   }, {
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
 }).prototype = getMCSymbolPrototype(lib.l4, new cjs.Rectangle(-4.5, -48, 167.6, 119.6), null);
 (lib.l3 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#0C593C").s().p("AAtBHIAAhZIAAgOIABgRIgBAAIglB4IgPAAIglh4IgBAAIABARIAAAOIAABZIgRAAIAAiNIAaAAIAjBzIAkhzIAaAAIAACNg");
  this.shape.setTransform(143.5, 65.775);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#0C593C").s().p("AgcA/QgMgJgFgRQgGgRAAgUQAAgjANgTQANgSAZAAQASAAALAJQAMAKAFAQQAGARAAAUQAAAVgGAQQgFARgMAKQgLAJgSAAQgRAAgLgKgAgYgqQgIAPAAAbQAAAcAIAPQAJAPAPAAQARAAAIgPQAIgPAAgcQAAgbgIgPQgIgPgRAAQgPAAgJAPg");
  this.shape_1.setTransform(130.625, 65.775);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#0C593C").s().p("AgIBHIAAh+IggAAIAAgPIBSAAIAAAPIghAAIAAB+g");
  this.shape_2.setTransform(121.2, 65.775);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#0C593C").s().p("AgbA2QgOgUgBgiQAAgUAHgQQAGgRAMgKQAMgJARAAQARAAAOAHIgHAPIgLgFQgGgCgHAAQgMAAgHAIQgIAIgDANQgFANAAAPQAAAbAKAPQAJAQARAAQAHAAAHgCIALgEIAAAQQgLAFgQAAQgYAAgOgTg");
  this.shape_3.setTransform(113.25, 65.775);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#0C593C").s().p("AAfBHIAAhTIAAgQIABgQIgBAAIg4BzIgWAAIAAiNIASAAIAABSIgBAPIgBARIABAAIA4hyIAWAAIAACNg");
  this.shape_4.setTransform(102.775, 65.775);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#0C593C").s().p("AgwBGIAAgPQADACAFAAQAHAAADgIQADgHACgPIACgZIAFgiIAEgnIA/AAIAACNIgTAAIAAh9IgdAAIgCAXIgDAZIgCAWIgCASQgDANgDAJQgEAJgFAEQgGAEgJAAQgGAAgEgCg");
  this.shape_5.setTransform(91.1, 65.875);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#0C593C").s().p("AAgBHIgMgsIgnAAIgMAsIgTAAIApiNIATAAIApCNgAgBgsIgDALIgMAsIAgAAIgMgsIgCgLIgCgKIgBAKg");
  this.shape_6.setTransform(82.275, 65.775);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#0C593C").s().p("AAfBHIAAhTIAAgQIABgQIgBAAIg4BzIgWAAIAAiNIASAAIAABSIgBAPIgBARIABAAIA4hyIAWAAIAACNg");
  this.shape_7.setTransform(71.975, 65.775);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#0C593C").s().p("AAhBbIAAgnIhTAAIAAiNIASAAIAAB+IAzAAIAAh+IASAAIAAB+IAOAAIAAA2g");
  this.shape_8.setTransform(61.2, 67.7);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#0C593C").s().p("AgfBHIAAiNIA/AAIAAAPIgtAAIAAAtIArAAIAAAOIgrAAIAAA0IAtAAIAAAPg");
  this.shape_9.setTransform(51.5, 65.775);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.f("#0C593C").s().p("AAZBHIAAh+IgxAAIAAB+IgSAAIAAiNIBVAAIAACNg");
  this.shape_10.setTransform(41.775, 65.775);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.f("#0C593C").s().p("AgbA2QgOgUgBgiQAAgUAHgQQAGgRAMgKQAMgJARAAQARAAAOAHIgHAPIgLgFQgGgCgHAAQgMAAgHAIQgIAIgDANQgFANAAAPQAAAbAKAPQAJAQARAAQAHAAAHgCIALgEIAAAQQgLAFgQAAQgYAAgOgTg");
  this.shape_11.setTransform(32.25, 65.775);
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.f("#0C593C").s().p("AgcA/QgMgJgFgRQgGgRAAgUQAAgjANgTQANgSAZAAQASAAALAJQAMAKAFAQQAGARAAAUQAAAVgGAQQgFARgMAKQgLAJgSAAQgRAAgLgKgAgYgqQgIAPAAAbQAAAcAIAPQAJAPAPAAQARAAAIgPQAIgPAAgcQAAgbgIgPQgIgPgRAAQgPAAgJAPg");
  this.shape_12.setTransform(18.925, 65.775);
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.f("#0C593C").s().p("AgcA2QgOgUABgiQgBgUAHgQQAGgRAMgKQAMgJARAAQARAAANAHIgGAPIgLgFQgGgCgHAAQgMAAgHAIQgIAIgEANQgEANABAPQAAAbAJAPQAJAQARAAQAHAAAHgCIAMgEIAAAQQgMAFgQAAQgZAAgOgTg");
  this.shape_13.setTransform(9.1, 65.775);
  this.shape_14 = new cjs.Shape();
  this.shape_14.graphics.f("#0C593C").s().p("AAgA+IAAhNIAAgNIAAgOIAAAAIgbBoIgKAAIgbhoIAAAAIAAAOIABANIAABNIgMAAIAAh7IASAAIAZBkIAahkIASAAIAAB7g");
  this.shape_14.setTransform(145.725, 29.925);
  this.shape_15 = new cjs.Shape();
  this.shape_15.graphics.f("#0C593C").s().p("AgWA+IAAh7IAtAAIAAANIggAAIAAAoIAeAAIAAAMIgeAAIAAAsIAgAAIAAAOg");
  this.shape_15.setTransform(136.825, 29.925);
  this.shape_16 = new cjs.Shape();
  this.shape_16.graphics.f("#0C593C").s().p("AAVA+IAAhIIABgOIAAgOIAAAAIgoBkIgPAAIAAh7IAMAAIAABHIAAAOIgBAOIABAAIAohjIAPAAIAAB7g");
  this.shape_16.setTransform(128.55, 29.925);
  this.shape_17 = new cjs.Shape();
  this.shape_17.graphics.f("#0C593C").s().p("AASA+IAAg6IgkAAIAAA6IgMAAIAAh7IAMAAIAAA1IAkAAIAAg1IANAAIAAB7g");
  this.shape_17.setTransform(119.425, 29.925);
  this.shape_18 = new cjs.Shape();
  this.shape_18.graphics.f("#0C593C").s().p("AgWA+IAAh7IAtAAIAAANIggAAIAAAoIAeAAIAAAMIgeAAIAAAsIAgAAIAAAOg");
  this.shape_18.setTransform(111.825, 29.925);
  this.shape_19 = new cjs.Shape();
  this.shape_19.graphics.f("#0C593C").s().p("AASA+IAAg6IgkAAIAAA6IgMAAIAAh7IAMAAIAAA1IAkAAIAAg1IANAAIAAB7g");
  this.shape_19.setTransform(103.825, 29.925);
  this.shape_20 = new cjs.Shape();
  this.shape_20.graphics.f("#0C593C").s().p("AgWA+IAAh7IAtAAIAAANIggAAIAAAoIAeAAIAAAMIgeAAIAAAsIAgAAIAAAOg");
  this.shape_20.setTransform(96.225, 29.925);
  this.shape_21 = new cjs.Shape();
  this.shape_21.graphics.f("#0C593C").s().p("AAgA+IAAhNIAAgNIAAgOIAAAAIgbBoIgKAAIgbhoIAAAAIAAAOIABANIAABNIgMAAIAAh7IASAAIAZBkIAahkIASAAIAAB7g");
  this.shape_21.setTransform(86.925, 29.925);
  this.shape_22 = new cjs.Shape();
  this.shape_22.graphics.f("#0C593C").s().p("AAWA+IAAhIIAAgOIABgOIgBAAIgoBkIgPAAIAAh7IAMAAIAABHIAAAOIgBAOIABAAIAohjIAPAAIAAB7g");
  this.shape_22.setTransform(76.5, 29.925);
  this.shape_23 = new cjs.Shape();
  this.shape_23.graphics.f("#0C593C").s().p("AgaA+IAAh7IAWAAQAPAAAIAJQAIAKAAASQAAASgIAJQgIALgQAAIgIAAIAAAwgAgNABIAHAAQAKAAAFgFQAFgGAAgOQAAgNgFgFQgFgGgJAAIgIAAg");
  this.shape_23.setTransform(68.425, 29.925);
  this.shape_24 = new cjs.Shape();
  this.shape_24.graphics.f("#0C593C").s().p("AASA+IAAhtIgjAAIAABtIgNAAIAAh7IA9AAIAAB7g");
  this.shape_24.setTransform(59.875, 29.925);
  this.shape_25 = new cjs.Shape();
  this.shape_25.graphics.f("#0C593C").s().p("AAbBOIAAghIg1AAIAAAhIgMAAIAAguIAHAAQAIgaAFgaQAFgcABgdIApAAIAABtIAKAAIAAAugAgEgeIgGAgIgIAeIAiAAIAAhgIgRAAIgDAig");
  this.shape_25.setTransform(38.075, 31.575);
  this.shape_26 = new cjs.Shape();
  this.shape_26.graphics.f("#0C593C").s().p("AgWA+IAAh7IAtAAIAAANIggAAIAAAoIAeAAIAAAMIgeAAIAAAsIAgAAIAAAOg");
  this.shape_26.setTransform(30.775, 29.925);
  this.shape_27 = new cjs.Shape();
  this.shape_27.graphics.f("#0C593C").s().p("AgaA+IAAh7IAWAAQAPAAAIAJQAIAKAAASQAAASgIAJQgIALgQAAIgIAAIAAAwgAgNABIAHAAQAKAAAFgFQAFgGAAgOQAAgNgFgFQgFgGgJAAIgIAAg");
  this.shape_27.setTransform(23.775, 29.925);
  this.shape_28 = new cjs.Shape();
  this.shape_28.graphics.f("#0C593C").s().p("AgWA+IAAh7IAtAAIAAANIggAAIAAAoIAeAAIAAAMIgeAAIAAAsIAgAAIAAAOg");
  this.shape_28.setTransform(16.625, 29.925);
  this.shape_29 = new cjs.Shape();
  this.shape_29.graphics.f("#0C593C").s().p("AASA+IAAhtIgjAAIAABtIgNAAIAAh7IA9AAIAAB7g");
  this.shape_29.setTransform(8.525, 29.925);
  this.shape_30 = new cjs.Shape();
  this.shape_30.graphics.f("#0C593C").s().p("AghA+IAAh7IAPAAIAAA0IAOAAQATAAAJAJQAKAIAAARQAAARgKAKQgKAKgSAAgAgSAxIAOAAQAWAAAAgYQAAgLgGgGQgFgFgMAAIgNAAg");
  this.shape_30.setTransform(149.3, 48.925);
  this.shape_31 = new cjs.Shape();
  this.shape_31.graphics.f("#0C593C").s().p("AgYAvQgMgRAAgeQAAgRAGgOQAEgOALgJQALgIAOAAQAPAAAMAGIgGANIgKgFQgEgBgHAAQgKAAgGAGQgHAIgDALQgEALABAOQgBAXAJANQAIANAOAAQAGAAAGgBQAFgBAGgCIAAANQgLAEgOABQgVAAgMgRg");
  this.shape_31.setTransform(141.8, 48.9);
  this.shape_32 = new cjs.Shape();
  this.shape_32.graphics.f("#0C593C").s().p("AgbA+IAAh7IA3AAIAAANIgnAAIAAAoIAkAAIAAAMIgkAAIAAAsIAnAAIAAAOg");
  this.shape_32.setTransform(134.975, 48.925);
  this.shape_33 = new cjs.Shape();
  this.shape_33.graphics.f("#0C593C").s().p("AgHA+IAAhtIgcAAIAAgOIBHAAIAAAOIgdAAIAABtg");
  this.shape_33.setTransform(128.4, 48.925);
  this.shape_34 = new cjs.Shape();
  this.shape_34.graphics.f("#0C593C").s().p("AAaBRIAAhJIABgNIABgOIgBAAIgxBkIgTAAIAAh7IAQAAIAABHIgBAOIAAAOIAAAAIAwhjIATAAIAAB7gAgSg8QgHgGgBgOIANAAQABAKAEADQADAEAGAAQAHAAADgEQAEgEAAgJIAOAAQgCANgGAHQgHAGgNAAQgNAAgGgGg");
  this.shape_34.setTransform(120.35, 47.025);
  this.shape_35 = new cjs.Shape();
  this.shape_35.graphics.f("#0C593C").s().p("AgdA+IgGgBIAAgOQAFACAGAAQAEAAADgCQADgBADgGIAFgNIghhZIAQAAIAWA6IABAGIABAIIABAAIACgIIACgEIASg8IARAAIgeBYQgEAOgFAHQgEAJgGADQgGADgIABIgHgBg");
  this.shape_35.setTransform(112.2, 49);
  this.shape_36 = new cjs.Shape();
  this.shape_36.graphics.f("#0C593C").s().p("AggA+IAAh7IAaAAQAUAAAJAJQAKAKAAASQAAASgKAJQgJALgVAAIgJAAIAAAwgAgQABIAIAAQAMAAAGgFQAHgGAAgOQAAgNgGgFQgGgGgLAAIgKAAg");
  this.shape_36.setTransform(105.575, 48.925);
  this.shape_37 = new cjs.Shape();
  this.shape_37.graphics.f("#0C593C").s().p("AAaA+IAAhIIABgOIABgOIgBAAIgxBkIgTAAIAAh7IAQAAIAABHIgBAOIAAAOIAAAAIAwhjIATAAIAAB7g");
  this.shape_37.setTransform(96.85, 48.925);
  this.shape_38 = new cjs.Shape();
  this.shape_38.graphics.f("#0C593C").s().p("AgHA+IAAhtIgcAAIAAgOIBHAAIAAAOIgdAAIAABtg");
  this.shape_38.setTransform(88.9, 48.925);
  this.shape_39 = new cjs.Shape();
  this.shape_39.graphics.f("#0C593C").s().p("AghA+IAAh7IAPAAIAAA0IAOAAQATAAAJAJQAKAIAAARQAAARgKAKQgKAKgSAAgAgSAxIAOAAQAWAAAAgYQAAgLgGgGQgFgFgMAAIgNAAg");
  this.shape_39.setTransform(82.35, 48.925);
  this.shape_40 = new cjs.Shape();
  this.shape_40.graphics.f("#0C593C").s().p("AgpA9IAAgNQACABAFAAQAFABADgHQADgGABgOIADgVIADgdIAEgjIA2AAIAAB7IgPAAIAAhtIgbAAIAAAVIgDAVIgCATIgCAPIgFATQgDAJgEADQgFADgIABQgGAAgDgCg");
  this.shape_40.setTransform(73.375, 49);
  this.shape_41 = new cjs.Shape();
  this.shape_41.graphics.f("#0C593C").s().p("AgdA+IgGgBIAAgOQAFACAGAAQAFAAACgCQADgBADgGIAFgNIgihZIARAAIAWA6IABAGIABAIIABAAIACgIIACgEIASg8IAQAAIgdBYQgFAOgEAHQgEAJgGADQgFADgKABIgGgBg");
  this.shape_41.setTransform(66.55, 49);
  this.shape_42 = new cjs.Shape();
  this.shape_42.graphics.f("#0C593C").s().p("AgXAvQgNgRAAgeQAAgRAGgOQAEgOALgJQALgIAOAAQAPAAAMAGIgGANIgJgFQgGgBgFAAQgLAAgGAGQgGAIgEALQgDALgBAOQAAAXAIANQAJANAOAAQAGAAAGgBQAFgBAFgCIAAANQgKAEgOABQgUAAgMgRg");
  this.shape_42.setTransform(59.75, 48.9);
  this.shape_43 = new cjs.Shape();
  this.shape_43.graphics.f("#0C593C").s().p("AAXA+IAAg6IgsAAIAAA6IgQAAIAAh7IAQAAIAAA1IAsAAIAAg1IAPAAIAAB7g");
  this.shape_43.setTransform(51.35, 48.925);
  this.shape_44 = new cjs.Shape();
  this.shape_44.graphics.f("#0C593C").s().p("AgZA3QgKgIgEgPQgFgOAAgSQAAgeALgQQAMgQAVAAQAPAAALAIQAJAIAFAOQAFAPAAARQAAASgFAOQgFAPgJAIQgLAIgPAAQgPAAgKgIgAgVgkQgGAMAAAYQAAAYAGANQAIANANAAQAPAAAGgNQAHgNAAgYQAAgYgHgMQgGgNgPAAQgNAAgIANg");
  this.shape_44.setTransform(42.15, 48.925);
  this.shape_45 = new cjs.Shape();
  this.shape_45.graphics.f("#0C593C").s().p("AATA+Igng/IAAA/IgPAAIAAh7IAPAAIAAA8IAmg8IARAAIgnA8IApA/g");
  this.shape_45.setTransform(34.5, 48.925);
  this.shape_46 = new cjs.Shape();
  this.shape_46.graphics.f("#0C593C").s().p("AgZA3QgJgIgFgPQgFgOAAgSQAAgeAMgQQAKgQAWAAQAPAAAKAIQALAIAEAOQAFAPAAARQAAASgFAOQgEAPgLAIQgKAIgPAAQgPAAgKgIgAgUgkQgIAMAAAYQAAAYAIANQAGANAOAAQAOAAAIgNQAGgNAAgYQAAgYgGgMQgIgNgOAAQgOAAgGANg");
  this.shape_46.setTransform(25.45, 48.925);
  this.shape_47 = new cjs.Shape();
  this.shape_47.graphics.f("#0C593C").s().p("AggA+IAAh7IAaAAQAUAAAJAJQAKAKAAASQAAASgKAJQgJALgVAAIgJAAIAAAwgAgQABIAIAAQAMAAAGgFQAHgGAAgOQAAgNgGgFQgGgGgLAAIgKAAg");
  this.shape_47.setTransform(17.525, 48.925);
  this.shape_48 = new cjs.Shape();
  this.shape_48.graphics.f("#0C593C").s().p("AAWA+IAAhtIgrAAIAABtIgPAAIAAh7IBJAAIAAB7g");
  this.shape_48.setTransform(8.95, 48.925);
  this.shape_49 = new cjs.Shape();
  this.shape_49.graphics.f("#0C593C").s().p("AgWArQAAgIABgFQACgGAEgGQAFgFAJgIQAGgFAEgFQAEgGAAgHQAAgQgNAAQgHAAgDAGQgCAFAAAKIgJAAIAAgEQAAgHACgGQADgGAFgDQAFgDAGAAQAHAAAFADQAGADACAFQADAGAAAHQAAAGgCAFQgCAFgEADIgIAIIgMAMIgFAGIgCAIIAjAAIAAAIg");
  this.shape_49.setTransform(139.325, -2.275);
  this.shape_50 = new cjs.Shape();
  this.shape_50.graphics.f("#0C593C").s().p("AgEAGIAAgLIAJAAIAAALg");
  this.shape_50.setTransform(132.525, 1.475);
  this.shape_51 = new cjs.Shape();
  this.shape_51.graphics.f("#0C593C").s().p("AALAgIAAg4IgWAAIAAA4IgJAAIAAg/IApAAIAAA/g");
  this.shape_51.setTransform(128.45, -1.15);
  this.shape_52 = new cjs.Shape();
  this.shape_52.graphics.f("#0C593C").s().p("AgUAsIAAhVIAIAAIAAAHIABAAQACgEADgCQAEgDACAAQAWAAAAAhIgCANIgDALQgCAFgEACQgEADgGAAQgEAAgDgCQgDgCgCgEIAAAcgAgKgcQgBAIAAALIAAAMQABAGACAEQADADAFAAQAHAAACgGQADgHAAgNQAAgZgMAAQgHAAgDAHg");
  this.shape_52.setTransform(123, -0.175);
  this.shape_53 = new cjs.Shape();
  this.shape_53.graphics.f("#0C593C").s().p("AgMAfQgEgDgEgIQgCgHAAgNQAAgPAFgJQAGgJALAAQAXAAAAAhQAAANgDAHQgDAIgEADQgGADgHAAQgHAAgFgDgAgHgWQgDACgCAGIAAAPIAAAOQACAFACADQADADAFAAQAFAAADgDQADgDABgFIABgOIgBgPQgCgGgDgCQgDgDgEAAQgEAAgDADg");
  this.shape_53.setTransform(117.35, -1.175);
  this.shape_54 = new cjs.Shape();
  this.shape_54.graphics.f("#0C593C").s().p("AALAgIgPggIgHAJIAAAXIgJAAIAAg/IAJAAIAAAeIAVgeIALAAIgUAZIAUAmg");
  this.shape_54.setTransform(112.475, -1.15);
  this.shape_55 = new cjs.Shape();
  this.shape_55.graphics.f("#0C593C").s().p("AgEAJQAFgCAAgJIgFAAIAAgLIAJAAIAAANQAAAEgCAFQgDAEgEABg");
  this.shape_55.setTransform(105.575, 2.325);
  this.shape_56 = new cjs.Shape();
  this.shape_56.graphics.f("#0C593C").s().p("AgOAqQABgNAEgOQAEgNAGgLQAGgNAJgLIgnAAIAAgIIAvAAIAAAIQgGAIgFAJQgFAJgEAJIgFAUIgDAUg");
  this.shape_56.setTransform(101.475, -2.175);
  this.shape_57 = new cjs.Shape();
  this.shape_57.graphics.f("#0C593C").s().p("AAFArIAAg+IgSAAIAAgHIALgBQADgCADgDQACgEAAgGIAIAAIAABVg");
  this.shape_57.setTransform(95.3, -2.275);
  this.shape_58 = new cjs.Shape();
  this.shape_58.graphics.f("#0C593C").s().p("AgEAGIAAgLIAJAAIAAALg");
  this.shape_58.setTransform(91.775, 1.475);
  this.shape_59 = new cjs.Shape();
  this.shape_59.graphics.f("#0C593C").s().p("AATApIAAgSIglAAIAAASIgIAAIAAgZIAFAAIAFgMIACgJIABgOIAAgVIAiAAIAAA4IAGAAIAAAZgAgEgOQAAAKgCAFQgBAGgEAJIAXAAIAAgwIgQAAg");
  this.shape_59.setTransform(87.575, -0.275);
  this.shape_60 = new cjs.Shape();
  this.shape_60.graphics.f("#0C593C").s().p("AgEAJQAFgCAAgJIgFAAIAAgLIAJAAIAAANQAAAEgCAFQgDAEgEABg");
  this.shape_60.setTransform(80.675, 2.325);
  this.shape_61 = new cjs.Shape();
  this.shape_61.graphics.f("#0C593C").s().p("AALAgIAAgbIgJAAIgMAbIgKAAIANgcQgFgCgDgEQgDgFAAgGQAAgFACgFQADgDAEgDQAEgCAFAAIAVAAIAAA/gAgGgVQgCADgBAFQAAALAKAAIAKAAIAAgWIgJAAQgGABgCACg");
  this.shape_61.setTransform(76.55, -1.15);
  this.shape_62 = new cjs.Shape();
  this.shape_62.graphics.f("#0C593C").s().p("AgVAQQAAgFABgEQACgEADgCIAKgEIAKgEQADgBAAgHQAAgFgDgDQgCgCgEAAQgFAAgCADQgDADAAAFIgIAAQAAgTATAAQAFAAAEADQAEACACAEQACADAAAFIAAAlQAAAFADAAIACAAIAAAGIgEABQgEAAgCgCQgCgBgBgGIgBAAQgBAEgEADQgDADgFAAQgQAAAAgSgAABABIgHADIgEAFQgCADAAAEQAAAKAJAAQAFAAADgEIACgCIAAgEIABgGIAAgMIgHADg");
  this.shape_62.setTransform(71.925, -1.175);
  this.shape_63 = new cjs.Shape();
  this.shape_63.graphics.f("#0C593C").s().p("AALAgIgPggIgHAJIAAAXIgJAAIAAg/IAJAAIAAAeIAVgeIALAAIgUAZIAUAmg");
  this.shape_63.setTransform(67.375, -1.15);
  this.shape_64 = new cjs.Shape();
  this.shape_64.graphics.f("#0C593C").s().p("AgMAdQgEgEgCgHQgCgHAAgKQAAgiAVAAQAKAAAFAHQAFAGAAAJIgJAAQAAgOgLAAQgGAAgDAHQgCAIAAALQAAALACAHQACAHAHAAQAHAAACgEQACgEAAgIIAJAAQAAAKgFAHQgEAHgKAAQgJAAgFgFg");
  this.shape_64.setTransform(62.125, -1.175);
  this.shape_65 = new cjs.Shape();
  this.shape_65.graphics.f("#0C593C").s().p("AgEAgIAAg4IgQAAIAAgHIApAAIAAAHIgRAAIAAA4g");
  this.shape_65.setTransform(57.575, -1.15);
  this.shape_66 = new cjs.Shape();
  this.shape_66.graphics.f("#0C593C").s().p("AgVAQQAAgFABgEQACgEADgCIAKgEIAKgEQADgBAAgHQAAgFgDgDQgCgCgEAAQgFAAgCADQgDADAAAFIgIAAQAAgTATAAQAFAAAEADQAEACACAEQACADAAAFIAAAlQAAAFADAAIACAAIAAAGIgEABQgEAAgCgCQgCgBgBgGIgBAAQgBAEgEADQgDADgFAAQgQAAAAgSgAABABIgHADIgEAFQgCADAAAEQAAAKAJAAQAFAAADgEIACgCIAAgEIABgGIAAgMIgHADg");
  this.shape_66.setTransform(53.025, -1.175);
  this.shape_67 = new cjs.Shape();
  this.shape_67.graphics.f("#0C593C").s().p("AgXAfIAAgHIAEABQAAAAABAAQAAAAABgBQAAAAABAAQAAgBABAAIACgHIAAgQIAAgfIAlAAIAAA/IgJAAIAAg4IgTAAIAAAZQAAAPgDAIQgDAIgIAAIgFgBg");
  this.shape_67.setTransform(47.475, -1.125);
  this.shape_68 = new cjs.Shape();
  this.shape_68.graphics.f("#0C593C").s().p("AAVAgIAAg/IAJAAIAAA/gAgdAgIAAg/IAKAAIAAAbIAMAAQAGAAADACQAEACACAEQACAEAAAGQAAAFgCAEQgCAFgEABQgDADgGAAgAgTAYIAJAAQAGAAADgDQACgCAAgGQAAgLgKAAIgKAAg");
  this.shape_68.setTransform(41.325, -1.15);
  this.shape_69 = new cjs.Shape();
  this.shape_69.graphics.f("#0C593C").s().p("AgVAsIAAhVIAJAAIAAAHIAAAAQADgEADgCQAEgDACAAQAWAAAAAhIgBANIgEALQgCAFgEACQgEADgGAAQgDAAgDgCQgEgCgDgEIAAAcgAgKgcQgBAIgBALIABAMQABAGACAEQAEADAEAAQAHAAACgGQADgHAAgNQAAgZgMAAQgHAAgDAHg");
  this.shape_69.setTransform(35, -0.175);
  this.shape_70 = new cjs.Shape();
  this.shape_70.graphics.f("#0C593C").s().p("AAQArIgWgqIgKAMIAAAeIgKAAIAAhVIAKAAIAAArIAegrIAMAAIgaAkIAbAxg");
  this.shape_70.setTransform(29.4, -2.275);
  this.shape_71 = new cjs.Shape();
  this.shape_71.graphics.f("#0C593C").s().p("AgEAGIAAgLIAJAAIAAALg");
  this.shape_71.setTransform(21.825, 1.475);
  this.shape_72 = new cjs.Shape();
  this.shape_72.graphics.f("#0C593C").s().p("AgXAfIAAgHIAEABQAAAAABAAQAAAAABgBQAAAAABAAQAAgBABAAIACgHIAAgQIAAgfIAlAAIAAA/IgJAAIAAg4IgTAAIAAAZQAAAPgDAIQgDAIgIAAIgFgBg");
  this.shape_72.setTransform(17.425, -1.125);
  this.shape_73 = new cjs.Shape();
  this.shape_73.graphics.f("#0C593C").s().p("AgVAqIAAgIIAHABQAEAAADgDQACgEACgGIgUhAIAJAAIAOAyIABAAIAOgyIAJAAIgUA/IgEAMQgBAEgEADQgDADgGAAIgHgBg");
  this.shape_73.setTransform(12.425, -0.05);
  this.shape_74 = new cjs.Shape();
  this.shape_74.graphics.f("#0C593C").s().p("AgEAJQAFgCAAgJIgFAAIAAgLIAJAAIAAANQAAAEgCAFQgDAEgEABg");
  this.shape_74.setTransform(135.975, -9.025);
  this.shape_75 = new cjs.Shape();
  this.shape_75.graphics.f("#0C593C").s().p("AgVAQQAAgFABgEQACgEADgCIAKgEIAKgEQADgBAAgHQAAgFgDgDQgCgCgEAAQgFAAgCADQgDADAAAFIgIAAQAAgTATAAQAFAAAEADQAEACACAEQACADAAAFIAAAlQAAAFADAAIACAAIAAAGIgEABQgEAAgCgCQgCgBgBgGIgBAAQgBAEgEADQgDADgFAAQgQAAAAgSgAABABIgHADIgEAFQgCADAAAEQAAAKAJAAQAFAAADgEIACgCIAAgEIABgGIAAgMIgHADg");
  this.shape_75.setTransform(132.225, -12.525);
  this.shape_76 = new cjs.Shape();
  this.shape_76.graphics.f("#0C593C").s().p("AgTAgIAAg/IAUAAQAHAAAGAEQAEAEAAAHQAAAGgCAEQgDAEgFABQAFABAEAEQADAEAAAGQAAAGgDAEQgCAEgDACQgEACgEAAgAgJAYIAJAAQAGAAACgCQACgDAAgGQABgFgDgDQgDgDgFABIgJAAgAgJgEIAJAAQAEAAADgCQACgDAAgFQAAgKgJABIgJAAg");
  this.shape_76.setTransform(127.4, -12.5);
  this.shape_77 = new cjs.Shape();
  this.shape_77.graphics.f("#0C593C").s().p("AALAgIgPggIgHAJIAAAXIgJAAIAAg/IAJAAIAAAeIAVgeIALAAIgUAZIAUAmg");
  this.shape_77.setTransform(122.625, -12.5);
  this.shape_78 = new cjs.Shape();
  this.shape_78.graphics.f("#0C593C").s().p("AgMAdQgEgEgCgHQgCgHAAgKQAAgiAVAAQAKAAAFAHQAFAGAAAJIgJAAQAAgOgLAAQgGAAgDAHQgCAIAAALQAAALACAHQACAHAHAAQAHAAACgEQACgEAAgIIAJAAQAAAKgFAHQgEAHgKAAQgJAAgFgFg");
  this.shape_78.setTransform(117.375, -12.525);
  this.shape_79 = new cjs.Shape();
  this.shape_79.graphics.f("#0C593C").s().p("AgMAfQgEgDgEgIQgCgHAAgNQAAgPAGgJQAFgJALAAQAXAAAAAhQAAANgDAHQgDAIgEADQgGADgHAAQgGAAgGgDgAgHgWQgDACgCAGIgBAPIABAOQACAFADADQADADAEAAQAFAAADgDQADgDABgFIABgOIgBgPQgBgGgEgCQgDgDgEAAQgEAAgDADg");
  this.shape_79.setTransform(112.15, -12.525);
  this.shape_80 = new cjs.Shape();
  this.shape_80.graphics.f("#0C593C").s().p("AAbArIAAhGIAAgGIAAgFIgCAGIgBAGIgSBFIgLAAIgShGIgCgLIgBAAIAAAGIABAFIAABGIgKAAIAAhVIARAAIARBCIABANIACgNIARhCIARAAIAABVg");
  this.shape_80.setTransform(104.975, -13.625);
  this.shape_81 = new cjs.Shape();
  this.shape_81.graphics.f("#0C593C").s().p("AgEAGIAAgLIAJAAIAAALg");
  this.shape_81.setTransform(96.525, -9.875);
  this.shape_82 = new cjs.Shape();
  this.shape_82.graphics.f("#0C593C").s().p("AgQAgIAAg/IAhAAIAAAIIgYAAIAAA3g");
  this.shape_82.setTransform(93.575, -12.5);
  this.shape_83 = new cjs.Shape();
  this.shape_83.graphics.f("#0C593C").s().p("AgEAJQAFgCAAgJIgFAAIAAgLIAJAAIAAANQAAAEgCAFQgDAEgEABg");
  this.shape_83.setTransform(87.075, -9.025);
  this.shape_84 = new cjs.Shape();
  this.shape_84.graphics.f("#0C593C").s().p("AAHArIAAgVIgfAAIAAgJIAgg3IAJAAIAAA3IAIAAIAAAJIgIAAIAAAVgAgQANIAXAAIAAgog");
  this.shape_84.setTransform(82.85, -13.625);
  this.shape_85 = new cjs.Shape();
  this.shape_85.graphics.f("#0C593C").s().p("AAEArIAAg+IgRAAIAAgHIALgBQADgCACgDQADgEABgGIAHAAIAABVg");
  this.shape_85.setTransform(76.8, -13.625);
  this.shape_86 = new cjs.Shape();
  this.shape_86.graphics.f("#0C593C").s().p("AgLAoQgFgDgDgGQgDgGAAgGIgBgPQAAgMACgKQABgKAGgIQAFgHALAAQAFAAAFACQAEADADAFQACAFABAGIgKAAQAAgHgEgDQgDgDgFAAQgDAAgDAEQgEAEgBAFIgBAKIgBALQACgFAFgDQADgDAFAAQAKAAAGAIQAGAHAAALQAAAJgDAHQgDAHgFADQgGAEgGAAQgIAAgEgEgAgMANQAAAMADAFQAEAFAFAAQAIAAADgGQADgGAAgJQAAgRgOAAQgMAAAAAQg");
  this.shape_86.setTransform(71.9, -13.525);
  this.shape_87 = new cjs.Shape();
  this.shape_87.graphics.f("#0C593C").s().p("AAFArIAAg+IgSAAIAAgHIALgBQADgCADgDQACgEAAgGIAIAAIAABVg");
  this.shape_87.setTransform(65.7, -13.625);
  this.shape_88 = new cjs.Shape();
  this.shape_88.graphics.f("#0C593C").s().p("AgWArQAAgIABgFQACgGAEgGQAFgFAJgIQAGgFAEgFQAEgGAAgHQAAgQgNAAQgHAAgDAGQgCAFAAAKIgJAAIAAgEQAAgHACgGQADgGAFgDQAFgDAGAAQAHAAAFADQAGADACAFQADAGAAAHQAAAGgCAFQgCAFgEADIgIAIIgMAMIgFAGIgCAIIAjAAIAAAIg");
  this.shape_88.setTransform(60.725, -13.625);
  this.shape_89 = new cjs.Shape();
  this.shape_89.graphics.f("#0C593C").s().p("AAFArIAAg+IgSAAIAAgHIALgBQADgCADgDQACgEABgGIAHAAIAABVg");
  this.shape_89.setTransform(54.6, -13.625);
  this.shape_90 = new cjs.Shape();
  this.shape_90.graphics.f("#0C593C").s().p("AgEAJQAFgCAAgJIgFAAIAAgLIAJAAIAAANQAAAEgCAFQgDAEgEABg");
  this.shape_90.setTransform(48.375, -9.025);
  this.shape_91 = new cjs.Shape();
  this.shape_91.graphics.f("#0C593C").s().p("AALAgIAAgbIgJAAIgMAbIgKAAIANgcQgFgCgDgEQgDgFAAgGQAAgFACgFQACgDAFgDQAEgCAEAAIAWAAIAAA/gAgGgVQgCADgBAFQABALAJAAIAKAAIAAgVIgJAAQgGgBgCADg");
  this.shape_91.setTransform(44.25, -12.5);
  this.shape_92 = new cjs.Shape();
  this.shape_92.graphics.f("#0C593C").s().p("AAMAgIAAgvIABgIIgCAIIgUAvIgLAAIAAg/IAJAAIAAAvIgBAIIACgIIAUgvIALAAIAAA/g");
  this.shape_92.setTransform(39.225, -12.5);
  this.shape_93 = new cjs.Shape();
  this.shape_93.graphics.f("#0C593C").s().p("AgMAdQgEgEgCgHQgCgHAAgKQAAgiAVAAQAKAAAFAHQAFAGAAAJIgJAAQAAgOgLAAQgGAAgDAHQgCAIAAALQAAALACAHQACAHAHAAQAHAAACgEQACgEAAgIIAJAAQAAAKgFAHQgEAHgKAAQgJAAgFgFg");
  this.shape_93.setTransform(33.975, -12.525);
  this.shape_94 = new cjs.Shape();
  this.shape_94.graphics.f("#0C593C").s().p("AgMAdQgEgEgCgHQgCgHAAgKQAAgiAVAAQAKAAAFAHQAFAGAAAJIgJAAQAAgOgLAAQgGAAgDAHQgCAIAAALQAAALACAHQACAHAHAAQAHAAACgEQACgEAAgIIAJAAQAAAKgFAHQgEAHgKAAQgJAAgFgFg");
  this.shape_94.setTransform(29.075, -12.525);
  this.shape_95 = new cjs.Shape();
  this.shape_95.graphics.f("#0C593C").s().p("AgMAfQgFgDgDgIQgCgHAAgNQAAgPAGgJQAFgJALAAQAXAAAAAhQAAANgDAHQgDAIgEADQgGADgHAAQgHAAgFgDgAgHgWQgDACgCAGIgBAPIABAOQACAFADADQADADAEAAQAFAAADgDQADgDABgFIABgOIgBgPQgBgGgEgCQgDgDgEAAQgEAAgDADg");
  this.shape_95.setTransform(23.85, -12.525);
  this.shape_96 = new cjs.Shape();
  this.shape_96.graphics.f("#0C593C").s().p("AgYArIAAhVIAYAAQALAAAHAGQAHAGAAAMQAAAIgCAFQgDAFgDABQgEADgFABQgEACgGAAIgMAAIAAAkgAgOgBIAJAAQAGAAAFgBQAEgBADgEQACgEAAgHQAAgJgFgDQgEgEgIAAIgMAAg");
  this.shape_96.setTransform(18.25, -13.625);
  this.shape_97 = new cjs.Shape();
  this.shape_97.graphics.f("#0C593C").s().p("AgEAJQAFgCAAgJIgFAAIAAgLIAJAAIAAANQAAAEgCAFQgDAEgEABg");
  this.shape_97.setTransform(138.675, -20.375);
  this.shape_98 = new cjs.Shape();
  this.shape_98.graphics.f("#0C593C").s().p("AABAMIAMgMIgMgLIAAgJIASASIAAAGIgSARgAgSAMIALgMIgLgLIAAgJIARASIAAAGIgRARg");
  this.shape_98.setTransform(134.6, -24.225);
  this.shape_99 = new cjs.Shape();
  this.shape_99.graphics.f("#0C593C").s().p("AALAgIAAgeIgWAAIAAAeIgJAAIAAg/IAJAAIAAAbIAWAAIAAgbIAKAAIAAA/g");
  this.shape_99.setTransform(129.05, -23.85);
  this.shape_100 = new cjs.Shape();
  this.shape_100.graphics.f("#0C593C").s().p("AgMAfQgEgDgEgIQgCgHAAgNQAAgPAGgJQAFgJALAAQAXAAAAAhQAAANgDAHQgDAIgFADQgFADgHAAQgGAAgGgDgAgHgWQgDACgCAGIgBAPIABAOQACAFADADQADADAEAAQAFAAADgDQADgDABgFIABgOIgBgPQgCgGgCgCQgDgDgFAAQgEAAgDADg");
  this.shape_100.setTransform(123.5, -23.875);
  this.shape_101 = new cjs.Shape();
  this.shape_101.graphics.f("#0C593C").s().p("AgMAdQgEgEgCgHQgCgHAAgKQAAgiAVAAQAKAAAFAHQAFAGAAAJIgJAAQAAgOgLAAQgGAAgDAHQgCAIAAALQAAALACAHQACAHAHAAQAHAAACgEQACgEAAgIIAJAAQAAAKgFAHQgEAHgKAAQgJAAgFgFg");
  this.shape_101.setTransform(118.275, -23.875);
  this.shape_102 = new cjs.Shape();
  this.shape_102.graphics.f("#0C593C").s().p("AALAgIAAgeIgWAAIAAAeIgJAAIAAg/IAJAAIAAAbIAWAAIAAgbIAKAAIAAA/g");
  this.shape_102.setTransform(113.05, -23.85);
  this.shape_103 = new cjs.Shape();
  this.shape_103.graphics.f("#0C593C").s().p("AgLAfQgGgDgCgIQgDgHAAgNQAAgPAFgJQAGgJALAAQAXAAAAAhQAAANgDAHQgDAIgFADQgFADgHAAQgGAAgFgDgAgHgWQgDACgBAGIgCAPIACAOQABAFADADQACADAFAAQAFAAADgDQADgDABgFIABgOIgBgPQgBgGgDgCQgDgDgFAAQgEAAgDADg");
  this.shape_103.setTransform(107.5, -23.875);
  this.shape_104 = new cjs.Shape();
  this.shape_104.graphics.f("#0C593C").s().p("AAcAgIgQggIgIAJIAAAXIgIAAIAAgXIgHgJIgPAgIgLAAIAVgmIgVgZIAMAAIAVAeIAAgeIAIAAIAAAeIAXgeIALAAIgUAZIAUAmg");
  this.shape_104.setTransform(100.9, -23.85);
  this.shape_105 = new cjs.Shape();
  this.shape_105.graphics.f("#0C593C").s().p("AAZA1IAAgUIgxAAIAAAUIgJAAIAAgcIAGAAQAEgHACgIQACgIAAgIIABgYIAAgWIAtAAIAABNIAHAAIAAAcgAgIgVIgBATIgDAOIgFANIAiAAIAAhFIgZAAg");
  this.shape_105.setTransform(93.625, -23.975);
  this.shape_106 = new cjs.Shape();
  this.shape_106.graphics.f("#0C593C").s().p("AgSApQgGgDgDgFQgDgGAAgIQAAgGACgFQACgEAEgEIAKgGQgFgFgCgFQgCgEAAgFQAAgFACgEQACgEAEgDQAEgCAFAAQAHAAAFAEQAFAFAAAIQAAAMgOAKIAQAXQACgIABgIIAJAAQgCAOgFAJIALAQIgLAAIgFgHQgIAJgMAAQgHAAgGgDgAgRAIQgDAFAAAGQAAAFACAEQACAEAEACQADACAFAAQAHAAAHgIIgSgcQgGAEgDAEgAgKghQgCADAAAEQAAAGAHAJQAFgDABgEQACgDAAgFQAAgEgCgDQgBgCgEAAQgDAAgDACg");
  this.shape_106.setTransform(86.475, -24.875);
  this.shape_107 = new cjs.Shape();
  this.shape_107.graphics.f("#0C593C").s().p("AALAgIAAgeIgWAAIAAAeIgJAAIAAg/IAJAAIAAAbIAWAAIAAgbIAKAAIAAA/g");
  this.shape_107.setTransform(79.85, -23.85);
  this.shape_108 = new cjs.Shape();
  this.shape_108.graphics.f("#0C593C").s().p("AgLAfQgGgDgCgIQgDgHAAgNQAAgPAFgJQAGgJALAAQAXAAAAAhQAAANgDAHQgCAIgGADQgFADgHAAQgHAAgEgDgAgHgWQgDACgBAGIgBAPIABAOQABAFACADQADADAFAAQAFAAADgDQADgDABgFIABgOIgBgPQgBgGgDgCQgDgDgFAAQgEAAgDADg");
  this.shape_108.setTransform(74.3, -23.875);
  this.shape_109 = new cjs.Shape();
  this.shape_109.graphics.f("#0C593C").s().p("AgMAdQgEgEgCgHQgCgHAAgKQAAgiAVAAQAKAAAFAHQAFAGAAAJIgJAAQAAgOgLAAQgGAAgDAHQgCAIAAALQAAALACAHQACAHAHAAQAHAAACgEQACgEAAgIIAJAAQAAAKgFAHQgEAHgKAAQgJAAgFgFg");
  this.shape_109.setTransform(69.075, -23.875);
  this.shape_110 = new cjs.Shape();
  this.shape_110.graphics.f("#0C593C").s().p("AALAgIAAgeIgVAAIAAAeIgJAAIAAg/IAJAAIAAAbIAVAAIAAgbIAJAAIAAA/g");
  this.shape_110.setTransform(63.85, -23.85);
  this.shape_111 = new cjs.Shape();
  this.shape_111.graphics.f("#0C593C").s().p("AgLAfQgFgDgDgIQgDgHAAgNQAAgPAFgJQAGgJALAAQAXAAAAAhQAAANgDAHQgCAIgFADQgGADgHAAQgHAAgEgDgAgHgWQgDACgBAGIgBAPIABAOQABAFACADQAEADAEAAQAFAAADgDQADgDABgFIABgOIgBgPQgCgGgDgCQgDgDgEAAQgEAAgDADg");
  this.shape_111.setTransform(58.3, -23.875);
  this.shape_112 = new cjs.Shape();
  this.shape_112.graphics.f("#0C593C").s().p("AAcAgIgRggIgHAJIAAAXIgIAAIAAgXIgGgJIgQAgIgLAAIAVgmIgUgZIAKAAIAWAeIAAgeIAIAAIAAAeIAXgeIAKAAIgTAZIAUAmg");
  this.shape_112.setTransform(51.7, -23.85);
  this.shape_113 = new cjs.Shape();
  this.shape_113.graphics.f("#0C593C").s().p("AAZA1IAAgUIgxAAIAAAUIgJAAIAAgcIAGAAQAEgHACgIQACgIAAgIIABgYIAAgWIAtAAIAABNIAHAAIAAAcgAgIgVIgBATIgDAOIgFANIAiAAIAAhFIgZAAg");
  this.shape_113.setTransform(44.425, -23.975);
  this.shape_114 = new cjs.Shape();
  this.shape_114.graphics.f("#0C593C").s().p("AACADIAAgGIARgRIAAAJIgMALIAMAMIAAAJgAgSADIAAgGIARgRIAAAJIgLALIALAMIAAAJg");
  this.shape_114.setTransform(38.15, -24.225);
  this.shape_115 = new cjs.Shape();
  this.shape_115.graphics.f("#0C593C").s().p("AgOAqQgFgEgDgGQgDgGgCgJIgBgRQAAgMADgJQACgKAFgHQAHgGALAAQARAAAGANQAFANABASQgBAVgFAMQgGAMgRAAQgIAAgGgDgAgLgfQgEAFgBAHQgCAHAAALIABAQIADAMQABAEAEADQAEACAFAAQAFAAAFgCQADgDACgEQACgFAAgHIACgQIgCgNIgDgMQgBgEgFgDQgDgCgFgBQgGABgFAEg");
  this.shape_115.setTransform(29.25, -24.95);
  this.shape_116 = new cjs.Shape();
  this.shape_116.graphics.f("#0C593C").s().p("AgOAqQgFgEgDgGQgDgGgCgJIgBgRQAAgMACgJQADgKAFgHQAHgGALAAQARAAAGANQAFANABASQgBAVgFAMQgGAMgRAAQgIAAgGgDgAgLgfQgDAFgCAHQgCAHAAALIABAQIADAMQACAEADADQAEACAFAAQAFAAAEgCQAEgDACgEQACgFAAgHIABgQIgBgNIgCgMQgCgEgFgDQgDgCgFgBQgHABgEAEg");
  this.shape_116.setTransform(22.4, -24.95);
  this.shape_117 = new cjs.Shape();
  this.shape_117.graphics.f("#0C593C").s().p("AgOAqQgFgEgDgGQgEgGgBgJIgBgRQAAgMACgJQACgKAGgHQAHgGALAAQARAAAGANQAFANAAASQAAAVgFAMQgGAMgRAAQgIAAgGgDgAgLgfQgDAFgCAHQgBAHgBALIABAQIADAMQACAEADADQAEACAFAAQAFAAAEgCQAEgDACgEQACgFAAgHIABgQIgBgNIgCgMQgCgEgFgDQgDgCgFgBQgGABgFAEg");
  this.shape_117.setTransform(15.55, -24.95);
  this.shape_118 = new cjs.Shape();
  this.shape_118.graphics.f("#0C593C").s().p("AACAMIALgMIgLgLIAAgJIARASIAAAGIgRARgAgSAMIAMgMIgMgLIAAgJIARASIAAAGIgRARg");
  this.shape_118.setTransform(134.55, -38.375);
  this.shape_119 = new cjs.Shape();
  this.shape_119.graphics.f("#0C593C").s().p("AALAgIAAgeIgVAAIAAAeIgJAAIAAg/IAJAAIAAAbIAVAAIAAgbIAJAAIAAA/g");
  this.shape_119.setTransform(129.2, -38);
  this.shape_120 = new cjs.Shape();
  this.shape_120.graphics.f("#0C593C").s().p("AgMAfQgEgDgEgIQgCgHAAgNQAAgPAGgJQAFgJALAAQAXAAAAAhQAAANgDAHQgDAIgFADQgFADgHAAQgGAAgGgDgAgHgWQgDACgCAGIgBAPIABAOQACAFADADQADADAEAAQAFAAADgDQADgDABgFIABgOIgBgPQgBgGgEgCQgDgDgEAAQgEAAgDADg");
  this.shape_120.setTransform(123.85, -38.025);
  this.shape_121 = new cjs.Shape();
  this.shape_121.graphics.f("#0C593C").s().p("AgMAdQgEgEgCgHQgCgHAAgKQAAgiAVAAQAKAAAFAHQAFAGAAAJIgJAAQAAgOgLAAQgGAAgDAHQgCAIAAALQAAALACAHQACAHAHAAQAHAAACgEQACgEAAgIIAJAAQAAAKgFAHQgEAHgKAAQgJAAgFgFg");
  this.shape_121.setTransform(118.825, -38.025);
  this.shape_122 = new cjs.Shape();
  this.shape_122.graphics.f("#0C593C").s().p("AALAgIAAgeIgVAAIAAAeIgJAAIAAg/IAJAAIAAAbIAVAAIAAgbIAJAAIAAA/g");
  this.shape_122.setTransform(113.8, -38);
  this.shape_123 = new cjs.Shape();
  this.shape_123.graphics.f("#0C593C").s().p("AgMAfQgFgDgDgIQgCgHAAgNQAAgPAGgJQAFgJALAAQAXAAAAAhQAAANgDAHQgDAIgEADQgGADgHAAQgHAAgFgDgAgHgWQgDACgCAGIgBAPIABAOQACAFADADQADADAEAAQAFAAADgDQADgDABgFIABgOIgBgPQgBgGgEgCQgDgDgEAAQgEAAgDADg");
  this.shape_123.setTransform(108.45, -38.025);
  this.shape_124 = new cjs.Shape();
  this.shape_124.graphics.f("#0C593C").s().p("AAbAgIgPggIgHAJIAAAXIgIAAIAAgXIgIgJIgQAgIgKAAIAUgnIgUgYIALAAIAXAeIAAgeIAIAAIAAAeIAWgeIALAAIgUAYIAUAng");
  this.shape_124.setTransform(102.05, -38);
  this.shape_125 = new cjs.Shape();
  this.shape_125.graphics.f("#0C593C").s().p("AAZA1IAAgUIgxAAIAAAUIgJAAIAAgcIAGAAQAEgHACgIQACgIAAgIIABgYIAAgWIAtAAIAABNIAHAAIAAAcgAgIgVIgBATIgDAOIgFANIAiAAIAAhFIgZAAg");
  this.shape_125.setTransform(94.975, -38.125);
  this.shape_126 = new cjs.Shape();
  this.shape_126.graphics.f("#0C593C").s().p("AgSApQgGgDgDgFQgDgGAAgIQAAgGACgFQACgEAEgEIAKgGQgFgFgCgFQgCgEAAgFQAAgFACgEQACgEAEgDQAEgCAFAAQAHAAAFAEQAFAFAAAIQAAAMgOAKIAQAXQACgIABgIIAJAAQgCAOgFAJIALAQIgLAAIgFgHQgIAJgMAAQgHAAgGgDgAgRAIQgDAFAAAGQAAAFACAEQACAEAEACQADACAFAAQAHAAAHgIIgSgcQgGAEgDAEgAgKghQgCADAAAEQAAAGAHAJQAFgDABgEQACgDAAgFQAAgEgCgDQgBgCgEAAQgDAAgDACg");
  this.shape_126.setTransform(88.025, -39.025);
  this.shape_127 = new cjs.Shape();
  this.shape_127.graphics.f("#0C593C").s().p("AALAgIAAgeIgVAAIAAAeIgJAAIAAg/IAJAAIAAAbIAVAAIAAgbIAJAAIAAA/g");
  this.shape_127.setTransform(81.6, -38);
  this.shape_128 = new cjs.Shape();
  this.shape_128.graphics.f("#0C593C").s().p("AgMAfQgEgDgEgIQgCgHAAgNQAAgPAGgJQAFgJALAAQAXAAAAAhQAAANgDAHQgDAIgFADQgFADgHAAQgGAAgGgDgAgHgWQgDACgCAGIgBAPIABAOQACAFADADQADADAEAAQAFAAADgDQADgDABgFIABgOIgBgPQgCgGgCgCQgDgDgFAAQgEAAgDADg");
  this.shape_128.setTransform(76.25, -38.025);
  this.shape_129 = new cjs.Shape();
  this.shape_129.graphics.f("#0C593C").s().p("AgMAdQgEgEgCgHQgCgHAAgKQAAgiAVAAQAKAAAFAHQAFAGAAAJIgJAAQAAgOgLAAQgGAAgDAHQgCAIAAALQAAALACAHQACAHAHAAQAHAAACgEQACgEAAgIIAJAAQAAAKgFAHQgEAHgKAAQgJAAgFgFg");
  this.shape_129.setTransform(71.225, -38.025);
  this.shape_130 = new cjs.Shape();
  this.shape_130.graphics.f("#0C593C").s().p("AALAgIAAgeIgVAAIAAAeIgJAAIAAg/IAJAAIAAAbIAVAAIAAgbIAJAAIAAA/g");
  this.shape_130.setTransform(66.2, -38);
  this.shape_131 = new cjs.Shape();
  this.shape_131.graphics.f("#0C593C").s().p("AgMAfQgEgDgEgIQgCgHAAgNQAAgPAGgJQAFgJALAAQAXAAAAAhQAAANgDAHQgDAIgFADQgFADgHAAQgGAAgGgDgAgHgWQgDACgCAGIgBAPIABAOQACAFADADQADADAEAAQAFAAADgDQADgDABgFIABgOIgBgPQgBgGgEgCQgDgDgEAAQgEAAgDADg");
  this.shape_131.setTransform(60.85, -38.025);
  this.shape_132 = new cjs.Shape();
  this.shape_132.graphics.f("#0C593C").s().p("AAcAgIgQggIgIAJIAAAXIgIAAIAAgXIgHgJIgQAgIgKAAIAVgnIgVgYIAMAAIAVAeIAAgeIAIAAIAAAeIAXgeIALAAIgUAYIAUAng");
  this.shape_132.setTransform(54.45, -38);
  this.shape_133 = new cjs.Shape();
  this.shape_133.graphics.f("#0C593C").s().p("AAZA1IAAgUIgxAAIAAAUIgJAAIAAgcIAGAAQAEgHACgIQACgIAAgIIABgYIAAgWIAtAAIAABNIAHAAIAAAcgAgIgVIgBATIgDAOIgFANIAiAAIAAhFIgZAAg");
  this.shape_133.setTransform(47.375, -38.125);
  this.shape_134 = new cjs.Shape();
  this.shape_134.graphics.f("#0C593C").s().p("AACADIAAgGIARgRIAAAJIgMALIAMAMIAAAJgAgSADIAAgGIARgRIAAAJIgLALIALAMIAAAJg");
  this.shape_134.setTransform(41.3, -38.375);
  this.shape_135 = new cjs.Shape();
  this.shape_135.graphics.f("#0C593C").s().p("AgOAqQgFgEgEgGQgDgGAAgJIgBgRQAAgLABgKQACgKAHgGQAGgHALAAQARAAAFAMQAHAOgBASQABAVgHAMQgFAMgRAAQgIAAgGgDgAgKgfQgFAEgBAIQgCAIABAKIAAAQIACAMQADAEAEADQADADAFgBQAGABAEgDQADgDACgEQACgFABgHIAAgQIAAgOIgDgLQgDgEgDgDQgEgCgFgBQgHABgDAEg");
  this.shape_135.setTransform(32.8, -39.1);
  this.shape_136 = new cjs.Shape();
  this.shape_136.graphics.f("#0C593C").s().p("AgOAqQgGgEgDgGQgDgGgBgJIAAgRQAAgLABgKQADgKAFgGQAHgHALAAQARAAAGAMQAFAOAAASQAAAVgFAMQgGAMgRAAQgJAAgFgDgAgKgfQgFAEgBAIQgBAIgBAKIABAQIACAMQACAEAEADQAEADAFgBQAGABADgDQAEgDACgEQACgFAAgHIABgQIgBgOIgCgLQgCgEgEgDQgEgCgFgBQgHABgDAEg");
  this.shape_136.setTransform(26.15, -39.1);
  this.shape_137 = new cjs.Shape();
  this.shape_137.graphics.f("#0C593C").s().p("AgOAqQgFgEgDgGQgEgGgBgJIgBgRQAAgLACgKQADgKAFgGQAHgHALAAQARAAAGAMQAFAOAAASQAAAVgFAMQgGAMgRAAQgJAAgFgDgAgKgfQgEAEgCAIQgBAIgBAKIABAQIACAMQADAEADADQAEADAFgBQAFABAEgDQAEgDACgEQACgFAAgHIABgQIgBgOIgCgLQgDgEgEgDQgDgCgFgBQgGABgEAEg");
  this.shape_137.setTransform(19.5, -39.1);
  this.shape_138 = new cjs.Shape();
  this.shape_138.graphics.f("#0C593C").s().p("AgTAgIAAg/IAUAAQAIAAAFAEQAEAEAAAHQAAAGgDAEQgCAEgFABQAGABACAEQAEAEAAAHQAAAFgDAEQgCAEgDACQgEACgEAAgAgKAZIAKAAQAGgBACgCQACgDABgGQAAgFgDgDQgDgDgFAAIgKAAgAgKgEIAKAAQAEAAACgDQADgCAAgGQAAgIgJgBIgKAAg");
  this.shape_138.setTransform(148.4, -49.35);
  this.shape_139 = new cjs.Shape();
  this.shape_139.graphics.f("#0C593C").s().p("AgEAgIAAg4IgQAAIAAgHIApAAIAAAHIgRAAIAAA4g");
  this.shape_139.setTransform(144.025, -49.35);
  this.shape_140 = new cjs.Shape();
  this.shape_140.graphics.f("#0C593C").s().p("AgMAdQgEgEgCgHQgCgHAAgKQAAgiAVAAQAKAAAFAHQAFAGAAAJIgJAAQAAgOgLAAQgGAAgDAHQgCAIAAALQAAALACAHQACAHAHAAQAHAAACgEQACgEAAgIIAJAAQAAAKgFAHQgEAHgKAAQgJAAgFgFg");
  this.shape_140.setTransform(139.875, -49.375);
  this.shape_141 = new cjs.Shape();
  this.shape_141.graphics.f("#0C593C").s().p("AATApIAAgSIglAAIAAASIgIAAIAAgZIAFAAIAFgMIACgJIABgOIAAgVIAiAAIAAA4IAGAAIAAAZgAgEgOQAAAKgCAFQgBAGgEAJIAXAAIAAgwIgQAAg");
  this.shape_141.setTransform(134.925, -48.475);
  this.shape_142 = new cjs.Shape();
  this.shape_142.graphics.f("#0C593C").s().p("AgKAfQgEgDgDgIQgCgHAAgNQAAghATAAQAJAAAEAFQAFAFABAHQABAHAAAKIgeAAIABAOQABAFACADQADADAEAAQAKAAAAgPIAJAAQAAAGgCAGQgCAFgEADQgFADgGAAQgGAAgFgDgAgIgTQgCAFAAAIIAVAAQAAgJgCgFQgCgFgHAAQgFAAgDAGg");
  this.shape_142.setTransform(130.025, -49.375);
  this.shape_143 = new cjs.Shape();
  this.shape_143.graphics.f("#0C593C").s().p("AgUAsIAAhVIAIAAIAAAHIABAAQACgEADgCQAEgDACAAQAWAAAAAhIgBANIgEALQgCAFgEACQgEADgGAAQgDAAgDgCQgEgCgCgEIAAAcgAgKgcQgBAIAAALIAAAMQABAGACAEQAEADAEAAQAHAAACgGQADgHAAgNQAAgZgMAAQgHAAgDAHg");
  this.shape_143.setTransform(125.35, -48.375);
  this.shape_144 = new cjs.Shape();
  this.shape_144.graphics.f("#0C593C").s().p("AgMAdQgEgEgCgHQgCgHAAgKQAAgiAVAAQAKAAAFAHQAFAGAAAJIgJAAQAAgOgLAAQgGAAgDAHQgCAIAAALQAAALACAHQACAHAHAAQAHAAACgEQACgEAAgIIAJAAQAAAKgFAHQgEAHgKAAQgJAAgFgFg");
  this.shape_144.setTransform(120.425, -49.375);
  this.shape_145 = new cjs.Shape();
  this.shape_145.graphics.f("#0C593C").s().p("AAPAgIgOgaIgPAaIgJAAIATggIgTgfIAKAAIAOAYIANgYIAKAAIgTAfIATAgg");
  this.shape_145.setTransform(113.6, -49.35);
  this.shape_146 = new cjs.Shape();
  this.shape_146.graphics.f("#0C593C").s().p("AAVAgIAAg/IAJAAIAAA/gAgdAgIAAg/IAKAAIAAAbIAMAAQAGAAADADQAEABACAEQACAEAAAGQAAAFgCAFQgCADgEACQgDADgGAAgAgTAZIAJAAQAGAAADgDQACgDAAgFQAAgMgKAAIgKAAg");
  this.shape_146.setTransform(107.875, -49.35);
  this.shape_147 = new cjs.Shape();
  this.shape_147.graphics.f("#0C593C").s().p("AALAgIAAgeIgVAAIAAAeIgJAAIAAg/IAJAAIAAAbIAVAAIAAgbIAJAAIAAA/g");
  this.shape_147.setTransform(101.85, -49.35);
  this.shape_148 = new cjs.Shape();
  this.shape_148.graphics.f("#0C593C").s().p("AALAgIAAgeIgVAAIAAAeIgJAAIAAg/IAJAAIAAAbIAVAAIAAgbIAJAAIAAA/g");
  this.shape_148.setTransform(96.7, -49.35);
  this.shape_149 = new cjs.Shape();
  this.shape_149.graphics.f("#0C593C").s().p("AgKAfQgEgDgDgIQgCgHAAgNQAAghATAAQAJAAAEAFQAFAFABAHQABAHAAAKIgeAAIABAOQABAFACADQADADAEAAQAKAAAAgPIAJAAQAAAGgCAGQgCAFgEADQgFADgGAAQgGAAgFgDgAgIgTQgCAFAAAIIAVAAQAAgJgCgFQgCgFgHAAQgFAAgDAGg");
  this.shape_149.setTransform(91.825, -49.375);
  this.shape_150 = new cjs.Shape();
  this.shape_150.graphics.f("#0C593C").s().p("AgTAgIAAg/IAUAAQAHAAAGAEQAEAEAAAHQAAAGgCAEQgDAEgFABQAFABADAEQAEAEAAAHQAAAFgDAEQgCAEgDACQgEACgEAAgAgJAZIAJAAQAGgBACgCQACgDAAgGQAAgFgCgDQgDgDgFAAIgJAAgAgJgEIAJAAQAEAAADgDQACgCAAgGQAAgIgJgBIgJAAg");
  this.shape_150.setTransform(87.45, -49.35);
  this.shape_151 = new cjs.Shape();
  this.shape_151.graphics.f("#0C593C").s().p("AgEAgIAAg4IgQAAIAAgHIApAAIAAAHIgRAAIAAA4g");
  this.shape_151.setTransform(83.075, -49.35);
  this.shape_152 = new cjs.Shape();
  this.shape_152.graphics.f("#0C593C").s().p("AgMAdQgEgEgCgHQgCgHAAgKQAAgiAVAAQAKAAAFAHQAFAGAAAJIgJAAQAAgOgLAAQgGAAgDAHQgCAIAAALQAAALACAHQACAHAHAAQAHAAACgEQACgEAAgIIAJAAQAAAKgFAHQgEAHgKAAQgJAAgFgFg");
  this.shape_152.setTransform(78.925, -49.375);
  this.shape_153 = new cjs.Shape();
  this.shape_153.graphics.f("#0C593C").s().p("AgUAsIAAhVIAIAAIAAAHIABAAQABgEAEgCQAEgDADAAQAVAAgBAhIgBANIgCALQgDAFgEACQgEADgGAAQgEAAgDgCQgDgCgCgEIAAAcgAgJgcQgCAIAAALIAAAMQABAGACAEQAEADAEAAQAGAAAEgGQACgHAAgNQAAgZgMAAQgHAAgCAHg");
  this.shape_153.setTransform(74.2, -48.375);
  this.shape_154 = new cjs.Shape();
  this.shape_154.graphics.f("#0C593C").s().p("AgVAQQAAgFABgEQACgEADgCIAKgEIAKgEQADgBAAgHQAAgFgDgDQgCgCgEAAQgFAAgCADQgDADAAAFIgIAAQAAgTATAAQAFAAAEADQAEACACAEQACADAAAFIAAAlQAAAFADAAIACAAIAAAGIgEABQgEAAgCgCQgCgBgBgGIgBAAQgBAEgEADQgDADgFAAQgQAAAAgSgAABABIgHADIgEAFQgCADAAAEQAAAKAJAAQAFAAADgEIACgCIAAgEIABgGIAAgMIgHADg");
  this.shape_154.setTransform(69.275, -49.375);
  this.shape_155 = new cjs.Shape();
  this.shape_155.graphics.f("#0C593C").s().p("AALAgIgPggIgHAJIAAAXIgJAAIAAg/IAJAAIAAAeIAVgeIALAAIgUAYIAUAng");
  this.shape_155.setTransform(65.125, -49.35);
  this.shape_156 = new cjs.Shape();
  this.shape_156.graphics.f("#0C593C").s().p("AgKAfQgEgDgDgIQgCgHAAgNQAAghATAAQAJAAAEAFQAFAFABAHQABAHAAAKIgeAAIABAOQABAFACADQADADAEAAQAKAAAAgPIAJAAQAAAGgCAGQgCAFgEADQgFADgGAAQgGAAgFgDgAgIgTQgCAFAAAIIAVAAQAAgJgCgFQgCgFgHAAQgFAAgDAGg");
  this.shape_156.setTransform(60.225, -49.375);
  this.shape_157 = new cjs.Shape();
  this.shape_157.graphics.f("#0C593C").s().p("AgXAfIAAgHIAEABQAAAAABAAQAAgBABAAQAAAAABAAQAAgBABAAIACgHIAAgQIAAgfIAlAAIAAA/IgJAAIAAg4IgTAAIAAAZQAAAPgDAIQgDAIgIAAIgFgBg");
  this.shape_157.setTransform(55.125, -49.325);
  this.shape_158 = new cjs.Shape();
  this.shape_158.graphics.f("#0C593C").s().p("AgKAfQgEgDgDgIQgCgHAAgNQAAghATAAQAJAAAEAFQAFAFABAHQABAHAAAKIgeAAIABAOQABAFACADQADADAEAAQAKAAAAgPIAJAAQAAAGgCAGQgCAFgEADQgFADgGAAQgGAAgFgDgAgIgTQgCAFAAAIIAVAAQAAgJgCgFQgCgFgHAAQgFAAgDAGg");
  this.shape_158.setTransform(48.275, -49.375);
  this.shape_159 = new cjs.Shape();
  this.shape_159.graphics.f("#0C593C").s().p("AALAgIgPggIgHAJIAAAXIgJAAIAAg/IAJAAIAAAeIAVgeIALAAIgUAYIAUAng");
  this.shape_159.setTransform(44.175, -49.35);
  this.shape_160 = new cjs.Shape();
  this.shape_160.graphics.f("#0C593C").s().p("AAMAqIAAgvIABgIIgCAIIgUAvIgLAAIAAg/IAJAAIAAAxIgBAHIACgHIAUgxIALAAIAAA/gAgJgfQgEgDAAgHIAEAAQACAHAHABQAFAAACgCQACgCABgEIAFAAQAAAHgEADQgFAEgGAAQgFAAgEgEg");
  this.shape_160.setTransform(38.925, -50.4);
  this.shape_161 = new cjs.Shape();
  this.shape_161.graphics.f("#0C593C").s().p("AgKAfQgEgDgDgIQgCgHAAgNQAAghATAAQAJAAAEAFQAFAFABAHQABAHAAAKIgeAAIABAOQABAFACADQADADAEAAQAKAAAAgPIAJAAQAAAGgCAGQgCAFgEADQgFADgGAAQgGAAgFgDgAgIgTQgCAFAAAIIAVAAQAAgJgCgFQgCgFgHAAQgFAAgDAGg");
  this.shape_161.setTransform(34.025, -49.375);
  this.shape_162 = new cjs.Shape();
  this.shape_162.graphics.f("#0C593C").s().p("AALAgIAAgeIgWAAIAAAeIgJAAIAAg/IAJAAIAAAbIAWAAIAAgbIAKAAIAAA/g");
  this.shape_162.setTransform(29.25, -49.35);
  this.shape_163 = new cjs.Shape();
  this.shape_163.graphics.f("#0C593C").s().p("AAMAgIAAgwIABgIIgCAIIgUAwIgLAAIAAg/IAJAAIAAAvIgBAJIACgJIAUgvIALAAIAAA/g");
  this.shape_163.setTransform(24.025, -49.35);
  this.shape_164 = new cjs.Shape();
  this.shape_164.graphics.f("#0C593C").s().p("AgXAfIAAgHIAEABQAAAAABAAQABgBAAAAQABAAAAAAQAAgBABAAIACgHIAAgQIAAgfIAlAAIAAA/IgJAAIAAg4IgTAAIAAAZQAAAPgDAIQgDAIgIAAIgFgBg");
  this.shape_164.setTransform(18.525, -49.325);
  this.shape_165 = new cjs.Shape();
  this.shape_165.graphics.f("#0C593C").s().p("AgYArIAAhVIAYAAQAGAAAFACQAGADACAFQADAFAAAGQAAAIgDAFQgEAFgGABIAAABQAEAAAEACQAEADABAEQADAFAAAGQAAAMgHAGQgGAGgMAAgAgOAjIAOAAQAHAAAEgEQAEgEAAgJQAAgQgPAAIgOAAgAgOgFIAMAAQAEAAAEgCQADgBABgDQACgEAAgFQAAgOgNAAIgNAAg");
  this.shape_165.setTransform(11.2, -50.475);
  this.shape_166 = new cjs.Shape();
  this.shape_166.graphics.f("#0C593C").s().p("AAAAFIgHALIgFgDIAIgKIgNgFIACgEIANAEIAAgOIAFAAIAAAOIANgEIACAFIgNAEIAIAKIgEAEg");
  this.shape_166.setTransform(5.575, -53.1);
  this.shape_167 = new cjs.Shape();
  this.shape_167.graphics.f("#0C593C").s().p("AgDAGQgCgCAAgEQAAgDACgCQAAAAABgBQAAAAABAAQAAgBABAAQAAAAAAAAQABAAAAAAQABAAAAABQABAAAAAAQABABAAAAQACACAAADQAAAEgCACQAAABgBAAQAAAAgBAAQAAABgBAAQAAAAgBAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQgBAAAAgBg");
  this.shape_167.setTransform(151.175, 15.725);
  this.shape_168 = new cjs.Shape();
  this.shape_168.graphics.f("#0C593C").s().p("AAMArIAAgkIgJAAIgNAkIgKAAIAQgmQgFgCgEgFQgDgGAAgJQAAgZAVAAIAQAAIAABVgAgDgdQgEAEAAAIQAAARAMAAIAHAAIAAghIgHAAQgFAAgDAEg");
  this.shape_168.setTransform(146.6, 12.125);
  this.shape_169 = new cjs.Shape();
  this.shape_169.graphics.f("#0C593C").s().p("AAPArIAAgyIAAgKIAAgJIAAAAIgbBFIgLAAIAAhVIAJAAIAAAxIAAAJIAAAKIAbhEIAKAAIAABVg");
  this.shape_169.setTransform(140.6, 12.125);
  this.shape_170 = new cjs.Shape();
  this.shape_170.graphics.f("#0C593C").s().p("AANArIAAgoIgZAAIAAAoIgJAAIAAhVIAJAAIAAAlIAZAAIAAglIAIAAIAABVg");
  this.shape_170.setTransform(133.95, 12.125);
  this.shape_171 = new cjs.Shape();
  this.shape_171.graphics.f("#0C593C").s().p("AAQArIgGgbIgTAAIgGAbIgJAAIAUhVIAJAAIAUBVgAAAgaIgBAGIgGAbIAPAAIgGgbIgBgGIgBgGIAAAGg");
  this.shape_171.setTransform(127.925, 12.125);
  this.shape_172 = new cjs.Shape();
  this.shape_172.graphics.f("#0C593C").s().p("AgLArQgEgBgDgCIAAgKIAHAEIAIABQANAAAAgQQAAgIgDgEQgFgEgHAAIgGAAIAAgIIAGAAQAOAAAAgQQAAgGgCgEQgEgDgDAAQgFAAgDACIgGAEIgEgHQAEgEAEgCQAFgCAFAAQAJAAAEAGQAGAGgBAJQABAIgEAGQgEAFgHACIAAAAQAIABAEAFQADAFAAAJQAAALgFAHQgFAHgLAAIgJgBg");
  this.shape_172.setTransform(122.35, 12.125);
  this.shape_173 = new cjs.Shape();
  this.shape_173.graphics.f("#0C593C").s().p("AAQArIgGgbIgTAAIgGAbIgJAAIAUhVIAJAAIAUBVgAAAgaIgBAGIgGAbIAPAAIgGgbIgBgGIgBgGIAAAGg");
  this.shape_173.setTransform(117.025, 12.125);
  this.shape_174 = new cjs.Shape();
  this.shape_174.graphics.f("#0C593C").s().p("AALArIgWgrIAAArIgJAAIAAhVIAJAAIAAApIAVgpIAKAAIgWApIAXAsg");
  this.shape_174.setTransform(111.875, 12.125);
  this.shape_175 = new cjs.Shape();
  this.shape_175.graphics.f("#0C593C").s().p("AgOAmQgFgGgCgKQgEgKAAgMQABgVAGgLQAHgLALAAQAJAAAGAGQAFAGADAJQACAKABAMQgBAMgCAKQgDAKgFAGQgGAGgJAAQgIAAgGgGgAgLgZQgEAJAAAQQAAARAEAJQAEAJAHAAQAIAAAEgJQAEgJAAgRQAAgQgEgJQgDgJgJAAQgHAAgEAJg");
  this.shape_175.setTransform(105.35, 12.125);
  this.shape_176 = new cjs.Shape();
  this.shape_176.graphics.f("#0C593C").s().p("AAMArIAAhMIgYAAIAABMIgIAAIAAhVIApAAIAABVg");
  this.shape_176.setTransform(98.725, 12.125);
  this.shape_177 = new cjs.Shape();
  this.shape_177.graphics.f("#0C593C").s().p("AgNAmQgGgGgCgKQgDgKAAgMQgBgVAHgLQAGgLAMAAQAJAAAFAGQAGAGADAJQADAKgBAMQABAMgDAKQgDAKgGAGQgFAGgJAAQgIAAgFgGgAgLgZQgEAJAAAQQAAARAEAJQAEAJAHAAQAIAAAFgJQADgJAAgRQAAgQgDgJQgFgJgIAAQgHAAgEAJg");
  this.shape_177.setTransform(92.15, 12.125);
  this.shape_178 = new cjs.Shape();
  this.shape_178.graphics.f("#0C593C").s().p("AgTArIAAhVIARAAQAKAAAFAFQAGAFAAALQAAAIgEAFQgCAFgGACQAHABADAEQADAFAAAJQAAAMgFAGQgGAHgJAAgAgLAiIALAAQAFAAADgEQADgEAAgIQAAgIgDgEQgEgDgFAAIgKAAgAgLgFIAJAAQAGAAACgEQAEgEAAgHQAAgNgMAAIgJAAg");
  this.shape_178.setTransform(86.05, 12.125);
  this.shape_179 = new cjs.Shape();
  this.shape_179.graphics.f("#0C593C").s().p("AAPArIAAgyIAAgKIAAgJIAAAAIgbBFIgKAAIAAhVIAIAAIAAAxIAAAJIAAAKIAbhEIALAAIAABVg");
  this.shape_179.setTransform(79.55, 12.125);
  this.shape_180 = new cjs.Shape();
  this.shape_180.graphics.f("#0C593C").s().p("AgDArIAAhMIgRAAIAAgJIApAAIAAAJIgQAAIAABMg");
  this.shape_180.setTransform(73.7, 12.125);
  this.shape_181 = new cjs.Shape();
  this.shape_181.graphics.f("#0C593C").s().p("AgOAmQgFgGgDgKQgDgKAAgMQABgVAGgLQAHgLALAAQAJAAAGAGQAGAGACAJQACAKABAMQgBAMgCAKQgCAKgGAGQgGAGgJAAQgIAAgGgGgAgLgZQgEAJAAAQQAAARAEAJQAEAJAHAAQAJAAADgJQAEgJAAgRQAAgQgEgJQgDgJgJAAQgHAAgEAJg");
  this.shape_181.setTransform(67.9, 12.125);
  this.shape_182 = new cjs.Shape();
  this.shape_182.graphics.f("#0C593C").s().p("AgRArIAAhVIAPAAQAKAAAFAHQAGAGAAANQgBAMgFAGQgFAHgMAAIgFAAIAAAigAgJAAIAFAAQAGAAAEgDQADgEABgJQgBgJgDgEQgDgEgGAAIgGAAg");
  this.shape_182.setTransform(62.05, 12.125);
  this.shape_183 = new cjs.Shape();
  this.shape_183.graphics.f("#0C593C").s().p("AAMArIAAhMIgYAAIAABMIgIAAIAAhVIApAAIAABVg");
  this.shape_183.setTransform(55.825, 12.125);
  this.shape_184 = new cjs.Shape();
  this.shape_184.graphics.f("#0C593C").s().p("AAMArIAAgkIgJAAIgNAkIgKAAIAQgmQgFgCgEgFQgDgGAAgJQAAgZAVAAIAQAAIAABVgAgDgdQgEAEAAAIQAAARAMAAIAHAAIAAghIgGAAQgGAAgDAEg");
  this.shape_184.setTransform(46.85, 12.125);
  this.shape_185 = new cjs.Shape();
  this.shape_185.graphics.f("#0C593C").s().p("AgNAhQgHgMAAgVQAAgLADgKQADgKAGgGQAGgGAIAAQAJAAAGAFIgDAJIgFgEIgHgBQgGABgDAEQgEAFgCAHQgBAJAAAIQAAAQAEAKQAFAJAHAAIAHgBIAGgDIAAAKQgGADgHAAQgMAAgHgLg");
  this.shape_185.setTransform(41.65, 12.1);
  this.shape_186 = new cjs.Shape();
  this.shape_186.graphics.f("#0C593C").s().p("AgDArIAAhMIgRAAIAAgJIApAAIAAAJIgQAAIAABMg");
  this.shape_186.setTransform(36.35, 12.125);
  this.shape_187 = new cjs.Shape();
  this.shape_187.graphics.f("#0C593C").s().p("AgGAhQgGgKgBgUIgMAAIAAAoIgIAAIAAhVIAIAAIAAAlIANAAQAAgTAGgJQAGgKAKAAQAMAAAGAMQAGALAAAUQAAAMgCAKQgDAKgFAGQgFAGgJAAQgKAAgGgLgAAAgZQgEAJAAAQQAAARAEAJQADAJAHAAQAIAAADgJQAEgJAAgRQAAgQgEgJQgDgJgIAAQgHAAgDAJg");
  this.shape_187.setTransform(29.675, 12.125);
  this.shape_188 = new cjs.Shape();
  this.shape_188.graphics.f("#0C593C").s().p("AgPArIAAhVIAfAAIAAAJIgWAAIAAAcIAUAAIAAAIIgUAAIAAAfIAWAAIAAAJg");
  this.shape_188.setTransform(22.775, 12.125);
  this.shape_189 = new cjs.Shape();
  this.shape_189.graphics.f("#0C593C").s().p("AAWArIAAg1IAAgJIABgKIgBAAIgSBIIgHAAIgShIIgBAAIABAKIAAAJIAAA1IgIAAIAAhVIAMAAIARBFIAShFIANAAIAABVg");
  this.shape_189.setTransform(16, 12.125);
  this.shape_190 = new cjs.Shape();
  this.shape_190.graphics.f("#0C593C").s().p("AAPArIAAgyIAAgKIAAgJIAAAAIgbBFIgKAAIAAhVIAIAAIAAAxIAAAJIAAAKIAbhEIALAAIAABVg");
  this.shape_190.setTransform(8.45, 12.125);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_190
   }, {
    t: this.shape_189
   }, {
    t: this.shape_188
   }, {
    t: this.shape_187
   }, {
    t: this.shape_186
   }, {
    t: this.shape_185
   }, {
    t: this.shape_184
   }, {
    t: this.shape_183
   }, {
    t: this.shape_182
   }, {
    t: this.shape_181
   }, {
    t: this.shape_180
   }, {
    t: this.shape_179
   }, {
    t: this.shape_178
   }, {
    t: this.shape_177
   }, {
    t: this.shape_176
   }, {
    t: this.shape_175
   }, {
    t: this.shape_174
   }, {
    t: this.shape_173
   }, {
    t: this.shape_172
   }, {
    t: this.shape_171
   }, {
    t: this.shape_170
   }, {
    t: this.shape_169
   }, {
    t: this.shape_168
   }, {
    t: this.shape_167
   }, {
    t: this.shape_166
   }, {
    t: this.shape_165
   }, {
    t: this.shape_164
   }, {
    t: this.shape_163
   }, {
    t: this.shape_162
   }, {
    t: this.shape_161
   }, {
    t: this.shape_160
   }, {
    t: this.shape_159
   }, {
    t: this.shape_158
   }, {
    t: this.shape_157
   }, {
    t: this.shape_156
   }, {
    t: this.shape_155
   }, {
    t: this.shape_154
   }, {
    t: this.shape_153
   }, {
    t: this.shape_152
   }, {
    t: this.shape_151
   }, {
    t: this.shape_150
   }, {
    t: this.shape_149
   }, {
    t: this.shape_148
   }, {
    t: this.shape_147
   }, {
    t: this.shape_146
   }, {
    t: this.shape_145
   }, {
    t: this.shape_144
   }, {
    t: this.shape_143
   }, {
    t: this.shape_142
   }, {
    t: this.shape_141
   }, {
    t: this.shape_140
   }, {
    t: this.shape_139
   }, {
    t: this.shape_138
   }, {
    t: this.shape_137
   }, {
    t: this.shape_136
   }, {
    t: this.shape_135
   }, {
    t: this.shape_134
   }, {
    t: this.shape_133
   }, {
    t: this.shape_132
   }, {
    t: this.shape_131
   }, {
    t: this.shape_130
   }, {
    t: this.shape_129
   }, {
    t: this.shape_128
   }, {
    t: this.shape_127
   }, {
    t: this.shape_126
   }, {
    t: this.shape_125
   }, {
    t: this.shape_124
   }, {
    t: this.shape_123
   }, {
    t: this.shape_122
   }, {
    t: this.shape_121
   }, {
    t: this.shape_120
   }, {
    t: this.shape_119
   }, {
    t: this.shape_118
   }, {
    t: this.shape_117
   }, {
    t: this.shape_116
   }, {
    t: this.shape_115
   }, {
    t: this.shape_114
   }, {
    t: this.shape_113
   }, {
    t: this.shape_112
   }, {
    t: this.shape_111
   }, {
    t: this.shape_110
   }, {
    t: this.shape_109
   }, {
    t: this.shape_108
   }, {
    t: this.shape_107
   }, {
    t: this.shape_106
   }, {
    t: this.shape_105
   }, {
    t: this.shape_104
   }, {
    t: this.shape_103
   }, {
    t: this.shape_102
   }, {
    t: this.shape_101
   }, {
    t: this.shape_100
   }, {
    t: this.shape_99
   }, {
    t: this.shape_98
   }, {
    t: this.shape_97
   }, {
    t: this.shape_96
   }, {
    t: this.shape_95
   }, {
    t: this.shape_94
   }, {
    t: this.shape_93
   }, {
    t: this.shape_92
   }, {
    t: this.shape_91
   }, {
    t: this.shape_90
   }, {
    t: this.shape_89
   }, {
    t: this.shape_88
   }, {
    t: this.shape_87
   }, {
    t: this.shape_86
   }, {
    t: this.shape_85
   }, {
    t: this.shape_84
   }, {
    t: this.shape_83
   }, {
    t: this.shape_82
   }, {
    t: this.shape_81
   }, {
    t: this.shape_80
   }, {
    t: this.shape_79
   }, {
    t: this.shape_78
   }, {
    t: this.shape_77
   }, {
    t: this.shape_76
   }, {
    t: this.shape_75
   }, {
    t: this.shape_74
   }, {
    t: this.shape_73
   }, {
    t: this.shape_72
   }, {
    t: this.shape_71
   }, {
    t: this.shape_70
   }, {
    t: this.shape_69
   }, {
    t: this.shape_68
   }, {
    t: this.shape_67
   }, {
    t: this.shape_66
   }, {
    t: this.shape_65
   }, {
    t: this.shape_64
   }, {
    t: this.shape_63
   }, {
    t: this.shape_62
   }, {
    t: this.shape_61
   }, {
    t: this.shape_60
   }, {
    t: this.shape_59
   }, {
    t: this.shape_58
   }, {
    t: this.shape_57
   }, {
    t: this.shape_56
   }, {
    t: this.shape_55
   }, {
    t: this.shape_54
   }, {
    t: this.shape_53
   }, {
    t: this.shape_52
   }, {
    t: this.shape_51
   }, {
    t: this.shape_50
   }, {
    t: this.shape_49
   }, {
    t: this.shape_48
   }, {
    t: this.shape_47
   }, {
    t: this.shape_46
   }, {
    t: this.shape_45
   }, {
    t: this.shape_44
   }, {
    t: this.shape_43
   }, {
    t: this.shape_42
   }, {
    t: this.shape_41
   }, {
    t: this.shape_40
   }, {
    t: this.shape_39
   }, {
    t: this.shape_38
   }, {
    t: this.shape_37
   }, {
    t: this.shape_36
   }, {
    t: this.shape_35
   }, {
    t: this.shape_34
   }, {
    t: this.shape_33
   }, {
    t: this.shape_32
   }, {
    t: this.shape_31
   }, {
    t: this.shape_30
   }, {
    t: this.shape_29
   }, {
    t: this.shape_28
   }, {
    t: this.shape_27
   }, {
    t: this.shape_26
   }, {
    t: this.shape_25
   }, {
    t: this.shape_24
   }, {
    t: this.shape_23
   }, {
    t: this.shape_22
   }, {
    t: this.shape_21
   }, {
    t: this.shape_20
   }, {
    t: this.shape_19
   }, {
    t: this.shape_18
   }, {
    t: this.shape_17
   }, {
    t: this.shape_16
   }, {
    t: this.shape_15
   }, {
    t: this.shape_14
   }, {
    t: this.shape_13
   }, {
    t: this.shape_12
   }, {
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
 }).prototype = getMCSymbolPrototype(lib.l3, new cjs.Rectangle(-4, -59, 322.6, 140.5), null);
 (lib.l2 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#0C593C").s().p("AgEAGIAAgLIAJAAIAAALg");
  this.shape.setTransform(113.675, 28.625);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#0C593C").s().p("AATAgIAAg3IgQA3IgFAAIgQg3IAAA3IgJAAIAAg/IAOAAIAMApIABANIACgNIAMgpIAOAAIAAA/g");
  this.shape_1.setTransform(108.725, 26);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#0C593C").s().p("AgKAfQgEgDgDgIQgCgHAAgNQAAghATAAQAJAAAEAFQAFAFABAHQABAHAAAKIgeAAIABAOQABAFACADQADADAEAAQAKAAAAgPIAJAAQAAAGgCAGQgCAFgEADQgFADgGAAQgGAAgFgDgAgIgTQgCAFAAAIIAVAAQAAgJgCgFQgCgFgHAAQgFAAgDAGg");
  this.shape_2.setTransform(102.625, 25.975);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#0C593C").s().p("AAMAgIAAgvIABgIIgCAIIgUAvIgLAAIAAg/IAJAAIAAAvIgBAIIACgIIAUgvIALAAIAAA/g");
  this.shape_3.setTransform(97.275, 26);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#0C593C").s().p("AALAgIAAgeIgWAAIAAAeIgJAAIAAg/IAJAAIAAAbIAWAAIAAgbIAKAAIAAA/g");
  this.shape_4.setTransform(91.6, 26);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#0C593C").s().p("AgVAQQAAgFABgEQACgEADgCIAKgEIAKgEQADgBAAgHQAAgFgDgDQgCgCgEAAQgFAAgCADQgDADAAAFIgIAAQAAgTATAAQAFAAAEADQAEACACAEQACADAAAFIAAAlQAAAFADAAIACAAIAAAGIgEABQgEAAgCgCQgCgBgBgGIgBAAQgBAEgEADQgDADgFAAQgQAAAAgSgAABABIgHADIgEAFQgCADAAAEQAAAKAJAAQAFAAADgEIACgCIAAgEIABgGIAAgMIgHADg");
  this.shape_5.setTransform(86.275, 25.975);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#0C593C").s().p("AgTAgIAAg/IAUAAQAIAAAFAEQAEAFAAAGQAAAGgDAEQgCAEgFABQAGABACAEQAEAEAAAGQAAAGgDAEQgCAEgDACQgEACgEAAgAgKAYIAKAAQAGABACgDQACgDABgGQAAgFgDgDQgDgCgFAAIgKAAgAgKgEIAKAAQAEAAACgCQADgDAAgFQAAgJgJAAIgKAAg");
  this.shape_6.setTransform(81.35, 26);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#0C593C").s().p("AgMAfQgEgDgEgIQgCgHAAgNQAAgPAGgJQAFgJALAAQAXAAAAAhQAAANgDAHQgDAIgFADQgFADgHAAQgGAAgGgDgAgHgWQgDACgCAGIgBAPIABAOQACAFADADQADADAEAAQAFAAADgDQADgDABgFIABgOIgBgPQgCgGgCgCQgDgDgFAAQgEAAgDADg");
  this.shape_7.setTransform(75.8, 25.975);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#0C593C").s().p("AgJAgQgFgDgCgFQgDgEAAgIIAIAAQAAAGACADQABADACABQADABADAAQALAAAAgMQAAgFgCgDQgDgEgFAAIgFAAIAAgGIAFAAQADAAADgDQADgDAAgFQAAgEgCgDQgDgDgFAAQgEAAgDADQgDADAAAFIgIAAQAAgFACgEQADgEAEgDQAFgDAEAAQAGAAAEADQAEACADADQACAEAAAFQAAAGgDAEQgDAEgFABIAAABQAEAAAFAEQADAEAAAHQABAGgDAEQgDAEgEADQgFACgFAAQgGAAgEgCg");
  this.shape_8.setTransform(70.5, 25.975);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#0C593C").s().p("AgVAQQAAgFABgEQACgEADgCIAKgEIAKgEQADgBAAgHQAAgFgDgDQgCgCgEAAQgFAAgCADQgDADAAAFIgIAAQAAgTATAAQAFAAAEADQAEACACAEQACADAAAFIAAAlQAAAFADAAIACAAIAAAGIgEABQgEAAgCgCQgCgBgBgGIgBAAQgBAEgEADQgDADgFAAQgQAAAAgSgAABABIgHADIgEAFQgCADAAAEQAAAKAJAAQAFAAADgEIACgCIAAgEIABgGIAAgMIgHADg");
  this.shape_9.setTransform(65.675, 25.975);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.f("#0C593C").s().p("AgUAsIAAhVIAIAAIAAAHIABAAQACgEADgCQAEgDACAAQAWAAAAAhIgCANIgDALQgCAFgEACQgEADgGAAQgEAAgDgCQgDgCgCgEIAAAcgAgKgcQgBAIAAALIAAAMQABAGACAEQADADAFAAQAHAAACgGQADgHAAgNQAAgZgMAAQgHAAgDAHg");
  this.shape_10.setTransform(60.45, 26.975);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.f("#0C593C").s().p("AgNAoQgFgEgCgIQgCgJAAgNIABgRQABgIADgFQADgEAEgEQADgDAGgBIAJgDQAEgBAAgDIAHAAQgBAGgEADQgFADgIACQgGACgDAEQgEAFgCAJQAHgKAIAAQAHAAAEAEQAFADADAHQADAGAAAKQAAAKgDAIQgCAIgFADQgGAEgHAAQgHAAgGgEgAgJgFQgEAFAAALIACAOQABAFADADQADAEAEAAQAHgBADgGQADgHAAgMQAAgLgDgFQgEgHgGAAQgGAAgDAHg");
  this.shape_11.setTransform(54.85, 24.95);
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.f("#0C593C").s().p("AgLAfQgGgDgCgIQgDgHAAgNQAAgPAGgJQAFgJALAAQAXAAAAAhQAAANgDAHQgDAIgFADQgFADgHAAQgGAAgFgDgAgHgWQgDACgBAGIgCAPIACAOQABAFACADQADADAFAAQAFAAADgDQADgDABgFIABgOIgBgPQgBgGgDgCQgDgDgFAAQgEAAgDADg");
  this.shape_12.setTransform(49.45, 25.975);
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.f("#0C593C").s().p("AgLAfQgGgDgCgIQgDgHAAgNQAAgPAFgJQAGgJALAAQAXAAAAAhQAAANgDAHQgCAIgFADQgGADgHAAQgHAAgEgDgAgHgWQgDACgBAGIgBAPIABAOQABAFACADQADADAFAAQAFAAADgDQADgDABgFIABgOIgBgPQgCgGgDgCQgCgDgFAAQgEAAgDADg");
  this.shape_13.setTransform(43.8, 25.975);
  this.shape_14 = new cjs.Shape();
  this.shape_14.graphics.f("#0C593C").s().p("AgKAgQgEgDgDgFQgCgEAAgIIAIAAQAAAGACADQABADADABQACABADAAQAMAAAAgMQgBgFgDgDQgCgEgGAAIgDAAIAAgGIADAAQAEAAADgDQADgDAAgFQAAgEgDgDQgCgDgFAAQgEAAgDADQgDADAAAFIgJAAQABgFACgEQACgEAFgDQAEgDAFAAQAFAAAEADQAFACACADQADAEAAAFQAAAGgDAEQgEAEgFABIAAABQAFAAAEAEQAEAEABAHQAAAGgDAEQgDAEgEADQgEACgHAAQgFAAgFgCg");
  this.shape_14.setTransform(38.5, 25.975);
  this.shape_15 = new cjs.Shape();
  this.shape_15.graphics.f("#0C593C").s().p("AgVAQQAAgFABgEQACgEADgCIAKgEIAKgEQADgBAAgHQAAgFgDgDQgCgCgEAAQgFAAgCADQgDADAAAFIgIAAQAAgTATAAQAFAAAEADQAEACACAEQACADAAAFIAAAlQAAAFADAAIACAAIAAAGIgEABQgEAAgCgCQgCgBgBgGIgBAAQgBAEgEADQgDADgFAAQgQAAAAgSgAABABIgHADIgEAFQgCADAAAEQAAAKAJAAQAFAAADgEIACgCIAAgEIABgGIAAgMIgHADg");
  this.shape_15.setTransform(33.675, 25.975);
  this.shape_16 = new cjs.Shape();
  this.shape_16.graphics.f("#0C593C").s().p("AgQAgIAAg/IAhAAIAAAIIgYAAIAAA3g");
  this.shape_16.setTransform(29.475, 26);
  this.shape_17 = new cjs.Shape();
  this.shape_17.graphics.f("#0C593C").s().p("AATAgIAAg3IgQA3IgFAAIgQg3IAAA3IgJAAIAAg/IAOAAIAMApIABANIACgNIAMgpIAOAAIAAA/g");
  this.shape_17.setTransform(142.825, 14.65);
  this.shape_18 = new cjs.Shape();
  this.shape_18.graphics.f("#0C593C").s().p("AAVAgIAAg/IAJAAIAAA/gAgdAgIAAg/IAKAAIAAAbIAMAAQAGAAADACQAEACACAEQACAFAAAFQAAAFgCAFQgCADgEADQgDACgGAAgAgTAZIAJAAQAGgBADgCQACgDAAgFQAAgLgKAAIgKAAg");
  this.shape_18.setTransform(135.525, 14.65);
  this.shape_19 = new cjs.Shape();
  this.shape_19.graphics.f("#0C593C").s().p("AALAgIAAgeIgVAAIAAAeIgJAAIAAg/IAJAAIAAAbIAVAAIAAgbIAJAAIAAA/g");
  this.shape_19.setTransform(129, 14.65);
  this.shape_20 = new cjs.Shape();
  this.shape_20.graphics.f("#0C593C").s().p("AALAgIAAgeIgVAAIAAAeIgJAAIAAg/IAJAAIAAAbIAVAAIAAgbIAJAAIAAA/g");
  this.shape_20.setTransform(123.35, 14.65);
  this.shape_21 = new cjs.Shape();
  this.shape_21.graphics.f("#0C593C").s().p("AgKAfQgEgDgDgIQgCgHAAgNQAAghATAAQAJAAAEAFQAFAFABAHQABAHAAAKIgeAAIABAOQABAFACADQADADAEAAQAKAAAAgPIAJAAQAAAGgCAGQgCAFgEADQgFADgGAAQgGAAgFgDgAgIgTQgCAFAAAIIAVAAQAAgJgCgFQgCgFgHAAQgFAAgDAGg");
  this.shape_21.setTransform(117.975, 14.625);
  this.shape_22 = new cjs.Shape();
  this.shape_22.graphics.f("#0C593C").s().p("AgiAgIAAg/IAKAAIAAA4IAUAAIAAg4IAJAAIAAA4IAUAAIAAg4IAKAAIAAA/g");
  this.shape_22.setTransform(111.275, 14.65);
  this.shape_23 = new cjs.Shape();
  this.shape_23.graphics.f("#0C593C").s().p("AAVAgIAAg/IAJAAIAAA/gAgdAgIAAg/IAKAAIAAAbIAMAAQAGAAADACQAEACACAEQACAFAAAFQAAAFgCAFQgCADgEADQgDACgGAAgAgTAZIAJAAQAGgBADgCQACgDAAgFQAAgLgKAAIgKAAg");
  this.shape_23.setTransform(103.275, 14.65);
  this.shape_24 = new cjs.Shape();
  this.shape_24.graphics.f("#0C593C").s().p("AgTAgIAAg/IAUAAQAHAAAFAEQAFAEAAAHQAAAGgCAEQgDAEgEABQAFABADAEQADAEAAAHQAAAFgCAEQgCAEgEACQgEACgEAAgAgJAZIAJAAQAGgBADgCQABgDAAgGQABgFgDgDQgDgCgFAAIgJAAgAgJgEIAJAAQAEAAADgDQACgCAAgFQAAgJgJAAIgJAAg");
  this.shape_24.setTransform(97.15, 14.65);
  this.shape_25 = new cjs.Shape();
  this.shape_25.graphics.f("#0C593C").s().p("AgLAfQgFgDgEgIQgCgHAAgNQAAgPAFgJQAGgJALAAQAXAAAAAhQAAANgDAHQgCAIgFADQgGADgHAAQgHAAgEgDgAgHgWQgDACgBAGIgBAPIABAOQABAFACADQAEADAEAAQAFAAADgDQADgDABgFIABgOIgBgPQgCgGgDgCQgDgDgEAAQgEAAgDADg");
  this.shape_25.setTransform(91.6, 14.625);
  this.shape_26 = new cjs.Shape();
  this.shape_26.graphics.f("#0C593C").s().p("AALAgIAAg3IgWAAIAAA3IgJAAIAAg/IApAAIAAA/g");
  this.shape_26.setTransform(85.95, 14.65);
  this.shape_27 = new cjs.Shape();
  this.shape_27.graphics.f("#0C593C").s().p("AAMAqIAAgvIABgIIgCAIIgUAvIgLAAIAAg/IAJAAIAAAxIgBAHIACgHIAUgxIALAAIAAA/gAgJgfQgEgDAAgHIAEAAQACAHAHABQAFgBACgBQACgCABgEIAFAAQAAAHgEADQgFAEgGAAQgFAAgEgEg");
  this.shape_27.setTransform(77.425, 13.6);
  this.shape_28 = new cjs.Shape();
  this.shape_28.graphics.f("#0C593C").s().p("AgMAfQgEgDgEgIQgCgHAAgNQAAgPAGgJQAFgJALAAQAXAAAAAhQAAANgDAHQgDAIgFADQgFADgHAAQgGAAgGgDgAgHgWQgDACgCAGIgBAPIABAOQACAFADADQADADAEAAQAFAAADgDQADgDABgFIABgOIgBgPQgCgGgCgCQgDgDgFAAQgEAAgDADg");
  this.shape_28.setTransform(71.75, 14.625);
  this.shape_29 = new cjs.Shape();
  this.shape_29.graphics.f("#0C593C").s().p("AALAgIAAgeIgVAAIAAAeIgJAAIAAg/IAJAAIAAAbIAVAAIAAgbIAJAAIAAA/g");
  this.shape_29.setTransform(66.1, 14.65);
  this.shape_30 = new cjs.Shape();
  this.shape_30.graphics.f("#0C593C").s().p("AALAgIAAgeIgVAAIAAAeIgJAAIAAg/IAJAAIAAAbIAVAAIAAgbIAJAAIAAA/g");
  this.shape_30.setTransform(60.45, 14.65);
  this.shape_31 = new cjs.Shape();
  this.shape_31.graphics.f("#0C593C").s().p("AgVAQQAAgFABgEQACgEADgCIAKgEIAKgEQADgBAAgHQAAgFgDgDQgCgCgEAAQgFAAgCADQgDADAAAFIgIAAQAAgTATAAQAFAAAEADQAEACACAEQACADAAAFIAAAlQAAAFADAAIACAAIAAAGIgEABQgEAAgCgCQgCgBgBgGIgBAAQgBAEgEADQgDADgFAAQgQAAAAgSgAABABIgHADIgEAFQgCADAAAEQAAAKAJAAQAFAAADgEIACgCIAAgEIABgGIAAgMIgHADg");
  this.shape_31.setTransform(55.125, 14.625);
  this.shape_32 = new cjs.Shape();
  this.shape_32.graphics.f("#0C593C").s().p("AgTAgIAAg/IAUAAQAHAAAGAEQAEAEAAAHQAAAGgDAEQgCAEgFABQAGABACAEQAEAEAAAHQAAAFgDAEQgCAEgDACQgEACgEAAgAgKAZIAKAAQAGgBACgCQACgDAAgGQAAgFgCgDQgDgCgFAAIgKAAgAgKgEIAKAAQAEAAACgDQADgCAAgFQAAgJgJAAIgKAAg");
  this.shape_32.setTransform(50.2, 14.65);
  this.shape_33 = new cjs.Shape();
  this.shape_33.graphics.f("#0C593C").s().p("AgKAgQgEgDgCgFQgDgEgBgIIAJAAQABAGABADQABADADABQACABADAAQAMAAAAgMQAAgFgEgDQgCgEgFAAIgFAAIAAgGIAFAAQAEAAACgDQADgDAAgFQAAgEgDgDQgCgDgFAAQgFAAgCADQgDADAAAFIgJAAQAAgFADgEQADgEAEgDQAFgDAEAAQAFAAAFADQAEACACADQADAEAAAFQAAAGgDAEQgDAEgGABIAAABQAGAAADAEQAFAEAAAHQgBAGgCAEQgCAEgFADQgEACgGAAQgGAAgFgCg");
  this.shape_33.setTransform(45, 14.625);
  this.shape_34 = new cjs.Shape();
  this.shape_34.graphics.f("#0C593C").s().p("AAVAgIAAg/IAJAAIAAA/gAgdAgIAAg/IAKAAIAAAbIAMAAQAGAAADACQAEACACAEQACAFAAAFQAAAFgCAFQgCADgEADQgDACgGAAgAgTAZIAJAAQAGgBADgCQACgDAAgFQAAgLgKAAIgKAAg");
  this.shape_34.setTransform(38.925, 14.65);
  this.shape_35 = new cjs.Shape();
  this.shape_35.graphics.f("#0C593C").s().p("AgTAgIAAg/IAUAAQAHAAAFAEQAFAEAAAHQAAAGgCAEQgDAEgEABQAFABADAEQADAEAAAHQAAAFgCAEQgCAEgEACQgEACgEAAgAgJAZIAJAAQAGgBADgCQABgDAAgGQABgFgDgDQgDgCgFAAIgJAAgAgJgEIAJAAQAEAAADgDQACgCAAgFQAAgJgJAAIgJAAg");
  this.shape_35.setTransform(32.8, 14.65);
  this.shape_36 = new cjs.Shape();
  this.shape_36.graphics.f("#0C593C").s().p("AgEAJQAFgCAAgJIgFAAIAAgLIAJAAIAAANQAAAEgCAFQgDAEgEABg");
  this.shape_36.setTransform(25.825, 18.125);
  this.shape_37 = new cjs.Shape();
  this.shape_37.graphics.f("#0C593C").s().p("AAMAgIAAgwIABgHIgCAHIgUAwIgLAAIAAg/IAJAAIAAAvIgBAJIACgJIAUgvIALAAIAAA/g");
  this.shape_37.setTransform(21.575, 14.65);
  this.shape_38 = new cjs.Shape();
  this.shape_38.graphics.f("#0C593C").s().p("AgXAfIAAgHIAEABQAAAAABAAQABAAAAgBQABAAAAAAQAAgBABAAIACgHIAAgQIAAgfIAlAAIAAA/IgJAAIAAg4IgTAAIAAAZQAAAPgDAIQgDAIgIAAIgFgBg");
  this.shape_38.setTransform(15.575, 14.675);
  this.shape_39 = new cjs.Shape();
  this.shape_39.graphics.f("#0C593C").s().p("AgMAfQgEgDgEgIQgCgHAAgNQAAgPAFgJQAGgJALAAQAXAAAAAhQAAANgDAHQgDAIgEADQgGADgHAAQgHAAgFgDgAgHgWQgDACgCAGIAAAPIAAAOQACAFACADQADADAFAAQAFAAADgDQADgDABgFIABgOIgBgPQgCgGgDgCQgDgDgEAAQgEAAgDADg");
  this.shape_39.setTransform(10.25, 14.625);
  this.shape_40 = new cjs.Shape();
  this.shape_40.graphics.f("#0C593C").s().p("AgXArIAAhVIAqAAIAAAIIghAAIAAAdIALAAIALABQAFABADADQAFACABAFQACAFAAAHQAAAMgGAGQgHAGgMAAgAgOAjIALAAQAIAAAFgEQAFgDgBgJQABgHgDgDQgCgEgFgBQgFgCgFAAIgJAAg");
  this.shape_40.setTransform(4.6, 13.525);
  this.shape_41 = new cjs.Shape();
  this.shape_41.graphics.f("#0C593C").s().p("AAAAFIgHALIgFgDIAIgKIgNgFIACgEIANAEIAAgOIAFAAIAAAOIANgEIACAFIgNAEIAIAKIgEAEg");
  this.shape_41.setTransform(-1.525, 10.9);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_41
   }, {
    t: this.shape_40
   }, {
    t: this.shape_39
   }, {
    t: this.shape_38
   }, {
    t: this.shape_37
   }, {
    t: this.shape_36
   }, {
    t: this.shape_35
   }, {
    t: this.shape_34
   }, {
    t: this.shape_33
   }, {
    t: this.shape_32
   }, {
    t: this.shape_31
   }, {
    t: this.shape_30
   }, {
    t: this.shape_29
   }, {
    t: this.shape_28
   }, {
    t: this.shape_27
   }, {
    t: this.shape_26
   }, {
    t: this.shape_25
   }, {
    t: this.shape_24
   }, {
    t: this.shape_23
   }, {
    t: this.shape_22
   }, {
    t: this.shape_21
   }, {
    t: this.shape_20
   }, {
    t: this.shape_19
   }, {
    t: this.shape_18
   }, {
    t: this.shape_17
   }, {
    t: this.shape_16
   }, {
    t: this.shape_15
   }, {
    t: this.shape_14
   }, {
    t: this.shape_13
   }, {
    t: this.shape_12
   }, {
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
 }).prototype = getMCSymbolPrototype(lib.l2, new cjs.Rectangle(-12, 5, 166, 28.700000000000003), null);
 (lib.l1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#0C593C").s().p("AAMAgIAAgwIABgHIgCAHIgUAwIgLAAIAAg/IAJAAIAAAvIgBAIIACgIIAUgvIALAAIAAA/g");
  this.shape.setTransform(84.375, 26.35);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#0C593C").s().p("AgXAfIAAgHIAEABQAAAAABAAQABAAAAgBQABAAAAAAQAAgBABAAIACgHIAAgQIAAgfIAlAAIAAA/IgJAAIAAg4IgTAAIAAAZQAAAPgDAIQgDAIgIAAIgFgBg");
  this.shape_1.setTransform(78.475, 26.375);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#0C593C").s().p("AgMAfQgEgDgEgIQgCgHAAgNQAAgPAFgJQAGgJALAAQAXAAAAAhQAAANgDAHQgDAIgEADQgGADgHAAQgHAAgFgDgAgHgWQgDACgCAGIAAAPIAAAOQACAFACADQADADAFAAQAFAAADgDQADgDABgFIABgOIgBgPQgCgGgDgCQgDgDgEAAQgEAAgDADg");
  this.shape_2.setTransform(73.25, 26.325);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#0C593C").s().p("AgMAoQgGgEgCgIQgCgJAAgNIABgRQACgIACgEQADgFADgEQAEgCAFgCIAKgDQADgCABgCIAIAAQgCAGgEADQgEADgJACQgFACgFAEQgDAFgBAJQAFgKAJAAQAHAAAFAEQAEADADAHQADAGAAAKQAAALgCAIQgDAHgFADQgGAEgHAAQgIAAgEgEgAgJgFQgDAFAAALIAAAOQACAFADADQADAEAEAAQAHAAADgHQADgGAAgNQAAgKgDgGQgEgGgGgBQgGABgDAGg");
  this.shape_3.setTransform(67.85, 25.3);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#0C593C").s().p("AAMAgIAAgwIABgHIgCAHIgUAwIgLAAIAAg/IAJAAIAAAvIgBAIIACgIIAUgvIALAAIAAA/g");
  this.shape_4.setTransform(59.775, 26.35);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#0C593C").s().p("AAMAgIAAgwIABgIIgCAIIgUAwIgLAAIAAg/IAJAAIAAAvIgBAJIACgJIAUgvIALAAIAAA/g");
  this.shape_5.setTransform(138.325, 15);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#0C593C").s().p("AAMAgIAAgwIABgIIgCAIIgUAwIgLAAIAAg/IAJAAIAAAvIgBAJIACgJIAUgvIALAAIAAA/g");
  this.shape_6.setTransform(132.675, 15);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#0C593C").s().p("AALAgIAAgeIgWAAIAAAeIgJAAIAAg/IAJAAIAAAbIAWAAIAAgbIAJAAIAAA/g");
  this.shape_7.setTransform(127.1, 15);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#0C593C").s().p("AgVAQQAAgFABgEQACgEADgCIAKgEIAKgEQADgBAAgHQAAgFgDgDQgCgCgEAAQgFAAgCADQgDADAAAFIgIAAQAAgTATAAQAFAAAEADQAEACACAEQACADAAAFIAAAlQAAAFADAAIACAAIAAAGIgEABQgEAAgCgCQgCgBgBgGIgBAAQgBAEgEADQgDADgFAAQgQAAAAgSgAABABIgHADIgEAFQgCADAAAEQAAAKAJAAQAFAAADgEIACgCIAAgEIABgGIAAgMIgHADg");
  this.shape_8.setTransform(121.875, 14.975);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#0C593C").s().p("AgTAgIAAg/IAUAAQAHAAAGAEQAEAEAAAHQAAAGgCAEQgDAEgEABQAEABAEAEQADAEAAAHQAAAFgDAEQgCAEgDACQgEACgEAAgAgJAZIAJAAQAGgBADgCQABgDAAgGQABgFgDgDQgDgDgFAAIgJAAgAgJgEIAJAAQAEAAADgDQACgCAAgGQAAgIgJgBIgJAAg");
  this.shape_9.setTransform(117.05, 15);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.f("#0C593C").s().p("AgMAfQgFgDgDgIQgCgHAAgNQAAgPAGgJQAFgJALAAQAXAAAAAhQAAANgDAHQgDAIgEADQgGADgHAAQgHAAgFgDgAgHgWQgDACgCAGIAAAPIAAAOQACAFADADQADADAEAAQAFAAADgDQADgDABgFIABgOIgBgPQgBgGgEgCQgDgDgEAAQgEAAgDADg");
  this.shape_10.setTransform(111.6, 14.975);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.f("#0C593C").s().p("AgJAgQgFgDgCgFQgDgEgBgIIAJAAQABAGABADQABADACABQADABADAAQALAAAAgMQAAgFgCgDQgDgEgFAAIgFAAIAAgGIAFAAQAEAAACgDQADgDAAgFQAAgEgCgDQgDgDgFAAQgEAAgDADQgDADAAAFIgIAAQAAgFACgEQADgEAEgDQAEgDAFAAQAFAAAFADQAEACADADQACAEAAAFQAAAGgDAEQgDAEgFABIAAABQAEAAAFAEQADAEAAAHQAAAGgCAEQgCAEgFADQgFACgFAAQgGAAgEgCg");
  this.shape_11.setTransform(106.4, 14.975);
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.f("#0C593C").s().p("AgVAQQAAgFABgEQACgEADgCIAKgEIAKgEQADgBAAgHQAAgFgDgDQgCgCgEAAQgFAAgCADQgDADAAAFIgIAAQAAgTATAAQAFAAAEADQAEACACAEQACADAAAFIAAAlQAAAFADAAIACAAIAAAGIgEABQgEAAgCgCQgCgBgBgGIgBAAQgBAEgEADQgDADgFAAQgQAAAAgSgAABABIgHADIgEAFQgCADAAAEQAAAKAJAAQAFAAADgEIACgCIAAgEIABgGIAAgMIgHADg");
  this.shape_12.setTransform(101.675, 14.975);
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.f("#0C593C").s().p("AgUAsIAAhVIAIAAIAAAHIABAAQACgEADgCQAEgDACAAQAWAAAAAhIgBANIgEALQgCAFgEACQgEADgGAAQgDAAgDgCQgEgCgCgEIAAAcgAgKgcQgBAIAAALIAAAMQABAGACAEQAEADAEAAQAHAAACgGQADgHAAgNQAAgZgMAAQgHAAgDAHg");
  this.shape_13.setTransform(96.55, 15.975);
  this.shape_14 = new cjs.Shape();
  this.shape_14.graphics.f("#0C593C").s().p("AgMAoQgGgEgCgIQgCgJAAgNIABgRQABgIADgEQADgGAEgCQAEgDAFgCIAJgDQAEgCAAgCIAHAAQgBAGgEADQgFADgIACQgGACgEAFQgDAEgBAJQAFgKAJAAQAHAAAFAEQAFADACAHQADAGAAAKQAAAKgDAJQgCAHgFADQgGAEgHAAQgIAAgEgEgAgJgFQgEAFABALIABAOQABAFADADQADADAEABQAHAAADgHQADgGAAgNQAAgKgDgGQgDgGgHgBQgGABgDAGg");
  this.shape_14.setTransform(91.05, 13.95);
  this.shape_15 = new cjs.Shape();
  this.shape_15.graphics.f("#0C593C").s().p("AgLAfQgFgDgEgIQgCgHAAgNQAAgPAFgJQAGgJALAAQAXAAAAAhQAAANgDAHQgCAIgFADQgGADgHAAQgHAAgEgDgAgHgWQgDACgBAGIgBAPIABAOQABAFACADQAEADAEAAQAFAAADgDQADgDABgFIABgOIgBgPQgCgGgDgCQgDgDgEAAQgEAAgDADg");
  this.shape_15.setTransform(85.75, 14.975);
  this.shape_16 = new cjs.Shape();
  this.shape_16.graphics.f("#0C593C").s().p("AgMAfQgEgDgEgIQgCgHAAgNQAAgPAGgJQAFgJALAAQAXAAAAAhQAAANgDAHQgDAIgFADQgFADgHAAQgGAAgGgDgAgHgWQgDACgCAGIgBAPIABAOQACAFADADQADADAEAAQAFAAADgDQADgDABgFIABgOIgBgPQgBgGgEgCQgDgDgEAAQgEAAgDADg");
  this.shape_16.setTransform(80.2, 14.975);
  this.shape_17 = new cjs.Shape();
  this.shape_17.graphics.f("#0C593C").s().p("AgJAgQgFgDgCgFQgDgEAAgIIAIAAQAAAGACADQABADACABQADABADAAQALAAAAgMQAAgFgCgDQgDgEgFAAIgFAAIAAgGIAFAAQADAAADgDQADgDAAgFQAAgEgCgDQgDgDgFAAQgEAAgDADQgDADAAAFIgIAAQAAgFACgEQADgEAEgDQAFgDAEAAQAGAAAEADQAEACADADQACAEAAAFQAAAGgDAEQgDAEgFABIAAABQAEAAAFAEQADAEAAAHQABAGgDAEQgDAEgEADQgFACgFAAQgGAAgEgCg");
  this.shape_17.setTransform(75, 14.975);
  this.shape_18 = new cjs.Shape();
  this.shape_18.graphics.f("#0C593C").s().p("AgVAQQAAgFABgEQACgEADgCIAKgEIAKgEQADgBAAgHQAAgFgDgDQgCgCgEAAQgFAAgCADQgDADAAAFIgIAAQAAgTATAAQAFAAAEADQAEACACAEQACADAAAFIAAAlQAAAFADAAIACAAIAAAGIgEABQgEAAgCgCQgCgBgBgGIgBAAQgBAEgEADQgDADgFAAQgQAAAAgSgAABABIgHADIgEAFQgCADAAAEQAAAKAJAAQAFAAADgEIACgCIAAgEIABgGIAAgMIgHADg");
  this.shape_18.setTransform(70.275, 14.975);
  this.shape_19 = new cjs.Shape();
  this.shape_19.graphics.f("#0C593C").s().p("AgQAgIAAg/IAhAAIAAAHIgYAAIAAA4g");
  this.shape_19.setTransform(66.175, 15);
  this.shape_20 = new cjs.Shape();
  this.shape_20.graphics.f("#0C593C").s().p("AgEAJQAFgCAAgJIgFAAIAAgLIAJAAIAAANQAAAEgCAFQgDAEgEABg");
  this.shape_20.setTransform(59.675, 18.475);
  this.shape_21 = new cjs.Shape();
  this.shape_21.graphics.f("#0C593C").s().p("AAMAgIAAgwIABgIIgCAIIgUAwIgLAAIAAg/IAJAAIAAAvIgBAJIACgJIAUgvIALAAIAAA/g");
  this.shape_21.setTransform(55.525, 15);
  this.shape_22 = new cjs.Shape();
  this.shape_22.graphics.f("#0C593C").s().p("AAMAgIAAgwIABgIIgCAIIgUAwIgLAAIAAg/IAJAAIAAAvIgBAJIACgJIAUgvIALAAIAAA/g");
  this.shape_22.setTransform(49.875, 15);
  this.shape_23 = new cjs.Shape();
  this.shape_23.graphics.f("#0C593C").s().p("AgEAgIAAg4IgQAAIAAgHIApAAIAAAHIgRAAIAAA4g");
  this.shape_23.setTransform(44.975, 15);
  this.shape_24 = new cjs.Shape();
  this.shape_24.graphics.f("#0C593C").s().p("AgVAqIAAgIIAHABQAEAAADgDQACgDACgHIgUhAIAJAAIAOAyIABAAIAOgyIAJAAIgUBAIgEALQgBAEgEADQgDADgGAAIgHgBg");
  this.shape_24.setTransform(40.325, 16.1);
  this.shape_25 = new cjs.Shape();
  this.shape_25.graphics.f("#0C593C").s().p("AATApIAAgSIglAAIAAASIgIAAIAAgZIAFAAIAFgMIACgJIABgOIAAgVIAiAAIAAA4IAGAAIAAAZgAgEgOQAAAKgCAFQgBAGgEAJIAXAAIAAgwIgQAAg");
  this.shape_25.setTransform(35.075, 15.875);
  this.shape_26 = new cjs.Shape();
  this.shape_26.graphics.f("#0C593C").s().p("AgKAgQgEgDgDgFQgCgEAAgIIAIAAQAAAGACADQABADACABQADABADAAQAMAAgBgMQAAgFgDgDQgCgEgGAAIgDAAIAAgGIADAAQAFAAACgDQADgDAAgFQAAgEgCgDQgDgDgFAAQgEAAgDADQgDADAAAFIgJAAQABgFACgEQACgEAFgDQAEgDAFAAQAFAAAEADQAFACACADQADAEAAAFQAAAGgDAEQgEAEgEABIAAABQAEAAAEAEQAEAEAAAHQAAAGgCAEQgDAEgEADQgEACgHAAQgFAAgFgCg");
  this.shape_26.setTransform(29.85, 14.975);
  this.shape_27 = new cjs.Shape();
  this.shape_27.graphics.f("#0C593C").s().p("AgTAgIAAg/IAUAAQAIAAAEAEQAFAEAAAHQAAAGgDAEQgCAEgFABQAGABACAEQAEAEAAAHQAAAFgDAEQgBAEgEACQgEACgEAAgAgKAZIAKAAQAGgBACgCQADgDAAgGQAAgFgDgDQgDgDgEAAIgLAAgAgKgEIAKAAQAEAAACgDQADgCAAgGQAAgIgJgBIgKAAg");
  this.shape_27.setTransform(25.2, 15);
  this.shape_28 = new cjs.Shape();
  this.shape_28.graphics.f("#0C593C").s().p("AAMAgIAAgwIABgIIgCAIIgUAwIgLAAIAAg/IAJAAIAAAvIgBAJIACgJIAUgvIALAAIAAA/g");
  this.shape_28.setTransform(16.975, 15);
  this.shape_29 = new cjs.Shape();
  this.shape_29.graphics.f("#0C593C").s().p("AgUAsIAAhVIAIAAIAAAHIABAAQACgEADgCQAEgDACAAQAWAAAAAhIgBANIgEALQgCAFgEACQgEADgGAAQgDAAgDgCQgEgCgCgEIAAAcgAgKgcQgBAIAAALIAAAMQABAGACAEQAEADAEAAQAHAAACgGQADgHAAgNQAAgZgMAAQgHAAgDAHg");
  this.shape_29.setTransform(11.5, 15.975);
  this.shape_30 = new cjs.Shape();
  this.shape_30.graphics.f("#0C593C").s().p("AALAgIAAg4IgWAAIAAA4IgJAAIAAg/IApAAIAAA/g");
  this.shape_30.setTransform(5.85, 15);
  this.shape_31 = new cjs.Shape();
  this.shape_31.graphics.f("#0C593C").s().p("AgEAgIAAg4IgQAAIAAgHIApAAIAAAHIgRAAIAAA4g");
  this.shape_31.setTransform(142.525, 3.65);
  this.shape_32 = new cjs.Shape();
  this.shape_32.graphics.f("#0C593C").s().p("AgUAsIAAhVIAIAAIAAAHIABAAQACgEADgCQAEgDACAAQAWAAgBAhIgBANIgCALQgDAFgEACQgEADgGAAQgDAAgEgCQgDgCgCgEIAAAcgAgJgcQgCAIAAALIAAAMQABAGACAEQAEADAEAAQAHAAACgGQADgHAAgNQAAgZgMAAQgHAAgCAHg");
  this.shape_32.setTransform(137.75, 4.625);
  this.shape_33 = new cjs.Shape();
  this.shape_33.graphics.f("#0C593C").s().p("AgLAfQgFgDgDgIQgDgHAAgNQAAgPAFgJQAGgJALAAQAXAAAAAhQAAANgDAHQgCAIgFADQgGADgHAAQgHAAgEgDgAgHgWQgDACgBAGIgBAPIABAOQABAFACADQAEADAEAAQAFAAADgDQADgDABgFIABgOIgBgPQgCgGgDgCQgDgDgEAAQgEAAgDADg");
  this.shape_33.setTransform(132.1, 3.625);
  this.shape_34 = new cjs.Shape();
  this.shape_34.graphics.f("#0C593C").s().p("AgEA2IAAgcIgFAGQgEACgEAAQgIAAgFgEQgEgFgCgIQgCgHAAgKQAAgJACgHQACgIAFgEQAFgFAHABQAFgBADADQADACACAFIAAgeIAIAAIAAAeQADgFADgCQADgDAFABQALgBAFAKQAFAIAAAPQAAAigVAAQgFAAgCgCIgHgGIAAAcgAAHgRQgDAIAAAKQAAALADAIQADAGAHAAQAHAAADgGQACgHAAgNQABgYgNAAQgIgBgCAIgAgcAAQAAANADAHQADAGAGAAQAGAAADgEQACgDABgGIAAgMQAAgKgCgIQgCgIgIABQgMAAAAAYg");
  this.shape_34.setTransform(124.95, 3.6);
  this.shape_35 = new cjs.Shape();
  this.shape_35.graphics.f("#0C593C").s().p("AATAgIAAg4IgQA4IgFAAIgQg4IAAA4IgJAAIAAg/IAOAAIAMApIABANIACgNIAMgpIAOAAIAAA/g");
  this.shape_35.setTransform(117.075, 3.65);
  this.shape_36 = new cjs.Shape();
  this.shape_36.graphics.f("#0C593C").s().p("AgMAfQgEgDgEgIQgCgHAAgNQAAgPAGgJQAFgJALAAQAXAAAAAhQAAANgDAHQgDAIgFADQgFADgHAAQgGAAgGgDgAgHgWQgDACgCAGIgBAPIABAOQACAFADADQADADAEAAQAFAAADgDQADgDABgFIABgOIgBgPQgBgGgEgCQgDgDgEAAQgEAAgDADg");
  this.shape_36.setTransform(110.8, 3.625);
  this.shape_37 = new cjs.Shape();
  this.shape_37.graphics.f("#0C593C").s().p("AALAgIgPggIgHAJIAAAXIgJAAIAAg/IAJAAIAAAeIAVgeIALAAIgUAYIAUAng");
  this.shape_37.setTransform(105.925, 3.65);
  this.shape_38 = new cjs.Shape();
  this.shape_38.graphics.f("#0C593C").s().p("AgMAdQgEgEgCgHQgCgHAAgKQAAgiAVAAQAKAAAFAHQAFAGAAAJIgJAAQAAgOgLAAQgGAAgDAHQgCAIAAALQAAALACAHQACAHAHAAQAHAAACgEQACgEAAgIIAJAAQAAAKgFAHQgEAHgKAAQgJAAgFgFg");
  this.shape_38.setTransform(100.675, 3.625);
  this.shape_39 = new cjs.Shape();
  this.shape_39.graphics.f("#0C593C").s().p("AAMAgIAAgwIABgIIgCAIIgUAwIgLAAIAAg/IAJAAIAAAwIgBAIIACgIIAUgwIALAAIAAA/g");
  this.shape_39.setTransform(95.375, 3.65);
  this.shape_40 = new cjs.Shape();
  this.shape_40.graphics.f("#0C593C").s().p("AATApIAAgSIglAAIAAASIgIAAIAAgZIAFAAIAFgMIACgJIABgOIAAgVIAiAAIAAA4IAGAAIAAAZgAgEgOQAAAKgCAFQgBAGgEAJIAXAAIAAgwIgQAAg");
  this.shape_40.setTransform(89.675, 4.525);
  this.shape_41 = new cjs.Shape();
  this.shape_41.graphics.f("#0C593C").s().p("AAMAgIAAgbIgKAAIgMAbIgKAAIAOgcQgGgCgDgDQgDgGAAgGQAAgFADgFQACgEADgCQAFgCAEAAIAWAAIAAA/gAgGgVQgDADAAAGQAAAKALABIAKAAIAAgXIgKAAQgFAAgDADg");
  this.shape_41.setTransform(81.35, 3.65);
  this.shape_42 = new cjs.Shape();
  this.shape_42.graphics.f("#0C593C").s().p("AgMAdQgEgEgCgHQgCgHAAgKQAAgiAVAAQAKAAAFAHQAFAGAAAJIgJAAQAAgOgLAAQgGAAgDAHQgCAIAAALQAAALACAHQACAHAHAAQAHAAACgEQACgEAAgIIAJAAQAAAKgFAHQgEAHgKAAQgJAAgFgFg");
  this.shape_42.setTransform(76.725, 3.625);
  this.shape_43 = new cjs.Shape();
  this.shape_43.graphics.f("#0C593C").s().p("AgEAgIAAg4IgQAAIAAgHIApAAIAAAHIgRAAIAAA4g");
  this.shape_43.setTransform(72.175, 3.65);
  this.shape_44 = new cjs.Shape();
  this.shape_44.graphics.f("#0C593C").s().p("AgKAfQgEgDgDgIQgCgHAAgNQAAghATAAQAJAAAEAFQAFAFABAHQABAHAAAKIgeAAIABAOQABAFACADQADADAEAAQAKAAAAgPIAJAAQAAAGgCAGQgCAFgEADQgFADgGAAQgGAAgFgDgAgIgTQgCAFAAAIIAVAAQAAgJgCgFQgCgFgHAAQgFAAgDAGg");
  this.shape_44.setTransform(67.575, 3.625);
  this.shape_45 = new cjs.Shape();
  this.shape_45.graphics.f("#0C593C").s().p("AgVAQQAAgFABgEQACgEADgCIAKgEIAKgEQADgBAAgHQAAgFgDgDQgCgCgEAAQgFAAgCADQgDADAAAFIgIAAQAAgTATAAQAFAAAEADQAEACACAEQACADAAAFIAAAlQAAAFADAAIACAAIAAAGIgEABQgEAAgCgCQgCgBgBgGIgBAAQgBAEgEADQgDADgFAAQgQAAAAgSgAABABIgHADIgEAFQgCADAAAEQAAAKAJAAQAFAAADgEIACgCIAAgEIABgGIAAgMIgHADg");
  this.shape_45.setTransform(62.725, 3.625);
  this.shape_46 = new cjs.Shape();
  this.shape_46.graphics.f("#0C593C").s().p("AgTAgIAAg/IAUAAQAIAAAEAEQAFAFAAAGQAAAGgCAEQgDAEgEACQAEAAAEAEQADAEAAAHQAAAFgCAEQgCAEgEACQgEACgEAAgAgJAZIAJAAQAGgBADgCQACgDAAgGQgBgFgCgDQgDgDgEAAIgKAAgAgJgEIAJAAQAEAAADgDQACgCAAgGQAAgIgJgBIgJAAg");
  this.shape_46.setTransform(57.9, 3.65);
  this.shape_47 = new cjs.Shape();
  this.shape_47.graphics.f("#0C593C").s().p("AgKAfQgEgDgDgIQgCgHAAgNQAAghATAAQAJAAAEAFQAFAFABAHQABAHAAAKIgeAAIABAOQABAFACADQADADAEAAQAKAAAAgPIAJAAQAAAGgCAGQgCAFgEADQgFADgGAAQgGAAgFgDgAgIgTQgCAFAAAIIAVAAQAAgJgCgFQgCgFgHAAQgFAAgDAGg");
  this.shape_47.setTransform(52.725, 3.625);
  this.shape_48 = new cjs.Shape();
  this.shape_48.graphics.f("#0C593C").s().p("AATAgIAAg4IgQA4IgFAAIgQg4IAAA4IgJAAIAAg/IAOAAIAMApIABANIACgNIAMgpIAOAAIAAA/g");
  this.shape_48.setTransform(46.775, 3.65);
  this.shape_49 = new cjs.Shape();
  this.shape_49.graphics.f("#0C593C").s().p("AgVAqIAAgIIAHABQAEAAADgDQACgDACgHIgUhAIAJAAIAOAyIABAAIAOgyIAJAAIgUBAIgEALQgBAFgEACQgDADgGAAIgHgBg");
  this.shape_49.setTransform(40.725, 4.75);
  this.shape_50 = new cjs.Shape();
  this.shape_50.graphics.f("#0C593C").s().p("AgJAgQgFgDgCgFQgDgEAAgIIAIAAQAAAGACADQABADACABQADABADAAQALAAAAgMQAAgFgCgDQgDgEgGAAIgEAAIAAgGIAEAAQAEAAADgDQADgDAAgFQAAgEgCgDQgDgDgFAAQgEAAgDADQgDADAAAFIgIAAQgBgFADgEQADgEAEgDQAFgDAEAAQAGAAADADQAFACADADQACAEAAAFQAAAGgDAEQgEAEgEABIAAABQAEAAAFAEQADAEAAAHQABAGgDAEQgDAEgEADQgFACgGAAQgFAAgEgCg");
  this.shape_50.setTransform(35.95, 3.625);
  this.shape_51 = new cjs.Shape();
  this.shape_51.graphics.f("#0C593C").s().p("AgVAQQAAgFABgEQACgEADgCIAKgEIAKgEQADgBAAgHQAAgFgDgDQgCgCgEAAQgFAAgCADQgDADAAAFIgIAAQAAgTATAAQAFAAAEADQAEACACAEQACADAAAFIAAAlQAAAFADAAIACAAIAAAGIgEABQgEAAgCgCQgCgBgBgGIgBAAQgBAEgEADQgDADgFAAQgQAAAAgSgAABABIgHADIgEAFQgCADAAAEQAAAKAJAAQAFAAADgEIACgCIAAgEIABgGIAAgMIgHADg");
  this.shape_51.setTransform(31.225, 3.625);
  this.shape_52 = new cjs.Shape();
  this.shape_52.graphics.f("#0C593C").s().p("AgVAsIAAhVIAJAAIAAAHIAAAAQACgEAEgCQAEgDADAAQAUAAABAhIgBANIgEALQgCAFgEACQgEADgGAAQgDAAgDgCQgEgCgDgEIAAAcgAgKgcQgCAIAAALIABAMQABAGADAEQADADAEAAQAGAAAEgGQACgHAAgNQAAgZgMAAQgHAAgDAHg");
  this.shape_52.setTransform(26.1, 4.625);
  this.shape_53 = new cjs.Shape();
  this.shape_53.graphics.f("#0C593C").s().p("AATApIAAgSIglAAIAAASIgIAAIAAgZIAFAAIAFgMIACgJIABgOIAAgVIAiAAIAAA4IAGAAIAAAZgAgEgOQAAAKgCAFQgBAGgEAJIAXAAIAAgwIgQAAg");
  this.shape_53.setTransform(20.325, 4.525);
  this.shape_54 = new cjs.Shape();
  this.shape_54.graphics.f("#0C593C").s().p("AgMAfQgEgDgEgIQgCgHAAgNQAAgPAFgJQAGgJALAAQAXAAAAAhQAAANgDAHQgDAIgEADQgGADgHAAQgHAAgFgDgAgHgWQgDACgCAGIAAAPIAAAOQACAFACADQADADAFAAQAFAAADgDQADgDABgFIABgOIgBgPQgCgGgDgCQgDgDgEAAQgEAAgDADg");
  this.shape_54.setTransform(14.75, 3.625);
  this.shape_55 = new cjs.Shape();
  this.shape_55.graphics.f("#0C593C").s().p("AAQArIAAhNIgfAAIAABNIgKAAIAAhVIAzAAIAABVg");
  this.shape_55.setTransform(8.525, 2.525);
  this.shape_56 = new cjs.Shape();
  this.shape_56.graphics.f("#0C593C").s().p("AAAAFIgHALIgFgCIAIgLIgNgFIACgEIANAEIAAgOIAFAAIAAAOIANgEIACAFIgNAEIAIALIgEADg");
  this.shape_56.setTransform(2.325, -0.1);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_56
   }, {
    t: this.shape_55
   }, {
    t: this.shape_54
   }, {
    t: this.shape_53
   }, {
    t: this.shape_52
   }, {
    t: this.shape_51
   }, {
    t: this.shape_50
   }, {
    t: this.shape_49
   }, {
    t: this.shape_48
   }, {
    t: this.shape_47
   }, {
    t: this.shape_46
   }, {
    t: this.shape_45
   }, {
    t: this.shape_44
   }, {
    t: this.shape_43
   }, {
    t: this.shape_42
   }, {
    t: this.shape_41
   }, {
    t: this.shape_40
   }, {
    t: this.shape_39
   }, {
    t: this.shape_38
   }, {
    t: this.shape_37
   }, {
    t: this.shape_36
   }, {
    t: this.shape_35
   }, {
    t: this.shape_34
   }, {
    t: this.shape_33
   }, {
    t: this.shape_32
   }, {
    t: this.shape_31
   }, {
    t: this.shape_30
   }, {
    t: this.shape_29
   }, {
    t: this.shape_28
   }, {
    t: this.shape_27
   }, {
    t: this.shape_26
   }, {
    t: this.shape_25
   }, {
    t: this.shape_24
   }, {
    t: this.shape_23
   }, {
    t: this.shape_22
   }, {
    t: this.shape_21
   }, {
    t: this.shape_20
   }, {
    t: this.shape_19
   }, {
    t: this.shape_18
   }, {
    t: this.shape_17
   }, {
    t: this.shape_16
   }, {
    t: this.shape_15
   }, {
    t: this.shape_14
   }, {
    t: this.shape_13
   }, {
    t: this.shape_12
   }, {
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
 }).prototype = getMCSymbolPrototype(lib.l1, new cjs.Rectangle(-7, -6, 158, 40.1), null);
 (lib.icon03 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.icon3();
  this.instance.parent = this;
  this.instance.setTransform(0, 0, 0.667, 0.667);
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));
 }).prototype = getMCSymbolPrototype(lib.icon03, new cjs.Rectangle(0, 0, 142.8, 142.8), null);
 (lib.icon02 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.icon2();
  this.instance.parent = this;
  this.instance.setTransform(0, 0, 0.667, 0.667);
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));
 }).prototype = getMCSymbolPrototype(lib.icon02, new cjs.Rectangle(0, 0, 113.4, 114.7), null);
 (lib.icon1_1_icon1_lact = function() {
  this.initialize(img.icon1_1_icon1_lact);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 212, 213);
 (lib.icon1_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_icon1 = new lib.icon1_1_icon1_lact();
  this.cvr_icon1.name = "cvr_icon1";
  this.cvr_icon1.parent = this;
  this.cvr_icon1.setTransform(0, 0, 0.6671361502347417, 0.6671361502347417);
  this.timeline.addTween(cjs.Tween.get(this.cvr_icon1).wait(1));
 }).prototype = getMCSymbolPrototype(lib.icon1_1, new cjs.Rectangle(0, 0, 141.4, 142.1), null);
 (lib.gr = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.lf(["rgba(217,237,141,0)", "#D9ED8D"], [0, 1], -2.2, -187.9, -2.2, -247.9).s().p("EgMfAu4MAAAhdvIY/AAMAAABdvg");
  this.shape.setTransform(80, 300);
  this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
 }).prototype = getMCSymbolPrototype(lib.gr, new cjs.Rectangle(0, 0, 160, 600), null);
 (lib.fish02 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.fish2();
  this.instance.parent = this;
  this.instance.setTransform(0, 0, 0.667, 0.667);
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));
 }).prototype = getMCSymbolPrototype(lib.fish02, new cjs.Rectangle(0, 0, 230.8, 177.4), null);
 (lib.fish01 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.fish1();
  this.instance.parent = this;
  this.instance.setTransform(0, 0, 0.667, 0.667);
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));
 }).prototype = getMCSymbolPrototype(lib.fish01, new cjs.Rectangle(0, 0, 228.1, 207.5), null);
 (lib.black_plate = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#C0DF53").s().p("EgMfAu4MAAAhdvIY/AAMAAABdvg");
  this.shape.setTransform(80, 300);
  this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
 }).prototype = getMCSymbolPrototype(lib.black_plate, new cjs.Rectangle(0, 0, 160, 600), null);
 (lib.bg_g = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.lf(["#C0DF53", "#D9ED8D"], [0, 1], -3.2, -163.9, -3.2, -223.9).s().p("EgMfAu4MAAAhdvIY/AAMAAABdvg");
  this.shape.setTransform(80, 300);
  this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
 }).prototype = getMCSymbolPrototype(lib.bg_g, new cjs.Rectangle(0, 0, 160, 600), null);
 (lib.b1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.bubble();
  this.instance.parent = this;
  this.instance.setTransform(0, 0, 0.667, 0.667);
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));
 }).prototype = getMCSymbolPrototype(lib.b1, new cjs.Rectangle(0, 0, 298.8, 298.8), null);
 (lib.txt04 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  var mask = new cjs.Shape();
  mask._off = true;
  mask.graphics.p("A2GRnIAAjqMAsNAAAIAADqg");
  mask.setTransform(141.4902, 112.7064);
  this.instance = new lib.t4();
  this.instance.parent = this;
  this.instance.setTransform(78, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance.alpha = 0;
  this.instance._off = true;
  var maskedShapeInstanceList = [this.instance];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(10).to({
   _off: false
  }, 0).to({
   x: 108,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(11));
  var mask_1 = new cjs.Shape();
  mask_1._off = true;
  mask_1.graphics.p("A2GPyIAAjWMAsNAAAIAADWg");
  mask_1.setTransform(141.4902, 101.0285);
  this.instance_1 = new lib.t4();
  this.instance_1.parent = this;
  this.instance_1.setTransform(78, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance_1.alpha = 0;
  this.instance_1._off = true;
  var maskedShapeInstanceList = [this.instance_1];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(5).to({
   _off: false
  }, 0).to({
   x: 108,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(16));
  var mask_2 = new cjs.Shape();
  mask_2._off = true;
  mask_2.graphics.p("A2GOJIAAk8MAsNAAAIAAE8g");
  mask_2.setTransform(141.4902, 90.4902);
  this.instance_2 = new lib.t4();
  this.instance_2.parent = this;
  this.instance_2.setTransform(78, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance_2.alpha = 0;
  var maskedShapeInstanceList = [this.instance_2];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_2).to({
   x: 108,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(21));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(12, 149.4, 271, 76);
 (lib.txt03 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  var mask = new cjs.Shape();
  mask._off = true;
  mask.graphics.p("A2GRiIAAlyMAsNAAAIAAFyg");
  mask.setTransform(141.4902, 112.2498);
  this.instance = new lib.t3();
  this.instance.parent = this;
  this.instance.setTransform(78, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance.alpha = 0;
  this.instance._off = true;
  var maskedShapeInstanceList = [this.instance];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(5).to({
   _off: false
  }, 0).to({
   x: 108,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(16));
  var mask_1 = new cjs.Shape();
  mask_1._off = true;
  mask_1.graphics.p("A2GOsIAAn0MAsNAAAIAAH0g");
  mask_1.setTransform(141.4902, 94);
  this.instance_1 = new lib.t3();
  this.instance_1.parent = this;
  this.instance_1.setTransform(78, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance_1.alpha = 0;
  var maskedShapeInstanceList = [this.instance_1];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_1).to({
   x: 108,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(21));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(0, 157, 276, 57.900000000000006);
 (lib.txt02_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  var mask = new cjs.Shape();
  mask._off = true;
  mask.graphics.p("EgSbAg0IAAn0MAk3AAAIAAH0g");
  mask.setTransform(118, 210);
  this.instance = new lib.t2_1();
  this.instance.parent = this;
  this.instance.setTransform(78, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance.alpha = 0;
  this.instance._off = true;
  var maskedShapeInstanceList = [this.instance];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(5).to({
   _off: false
  }, 0).to({
   x: 108,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(1));
  var mask_1 = new cjs.Shape();
  mask_1._off = true;
  mask_1.graphics.p("Aybc6IAAn0MAk3AAAIAAH0g");
  mask_1.setTransform(118, 185);
  this.instance_1 = new lib.t2_1();
  this.instance_1.parent = this;
  this.instance_1.setTransform(78, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance_1.alpha = 0;
  var maskedShapeInstanceList = [this.instance_1];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_1).to({
   x: 108,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(6));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(0, 343, 99, 77);
 (lib.txt02 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  var mask = new cjs.Shape();
  mask._off = true;
  mask.graphics.p("AybUbIAAlbMAk3AAAIAAFbg");
  mask.setTransform(118, 130.6718);
  this.instance = new lib.t2();
  this.instance.parent = this;
  this.instance.setTransform(78, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance.alpha = 0;
  this.instance._off = true;
  var maskedShapeInstanceList = [this.instance];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(10).to({
   _off: false
  }, 0).to({
   x: 108,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(11));
  var mask_1 = new cjs.Shape();
  mask_1._off = true;
  mask_1.graphics.p("A2GRtIAAkAMAsNAAAIAAEAg");
  mask_1.setTransform(141.4902, 113.2928);
  this.instance_1 = new lib.t2();
  this.instance_1.parent = this;
  this.instance_1.setTransform(78, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance_1.alpha = 0;
  this.instance_1._off = true;
  var maskedShapeInstanceList = [this.instance_1];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(5).to({
   _off: false
  }, 0).to({
   x: 108,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(16));
  var mask_2 = new cjs.Shape();
  mask_2._off = true;
  mask_2.graphics.p("A2GPtIAAlaMAsNAAAIAAFag");
  mask_2.setTransform(141.4902, 100.4968);
  this.instance_2 = new lib.t2();
  this.instance_2.parent = this;
  this.instance_2.setTransform(78, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance_2.alpha = 0;
  var maskedShapeInstanceList = [this.instance_2];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_2).to({
   x: 108,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(21));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(0, 170, 283, 91.39999999999998);
 (lib.txt01 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  var mask = new cjs.Shape();
  mask._off = true;
  mask.graphics.p("AsgSHIAAkTIZBAAIAAETg");
  mask.setTransform(80.1239, 115.9251);
  this.instance = new lib.t1();
  this.instance.parent = this;
  this.instance.setTransform(78, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance.alpha = 0;
  this.instance._off = true;
  var maskedShapeInstanceList = [this.instance];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(5).to({
   _off: false
  }, 0).to({
   x: 108,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(21));
  var mask_1 = new cjs.Shape();
  mask_1._off = true;
  mask_1.graphics.p("AsgP+IAAkTIZBAAIAAETg");
  mask_1.setTransform(80.1239, 102.1751);
  this.instance_1 = new lib.t1();
  this.instance_1.parent = this;
  this.instance_1.setTransform(78, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance_1.alpha = 0;
  var maskedShapeInstanceList = [this.instance_1];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_1).to({
   x: 108,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(26));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(0, 176.9, 156, 55);
 (lib._new = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.orange();
  this.instance.parent = this;
  this.instance.setTransform(52, 52, 1, 1, 0, 0, 0, 52, 52);
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   scaleX: 1.0787,
   scaleY: 1.0787,
   x: 52.05,
   y: 52.05
  }, 12, cjs.Ease.get(1)).to({
   scaleX: 1,
   scaleY: 1,
   x: 52,
   y: 52
  }, 12, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(-4, -4, 124.6, 112.2);
 (lib.icon1_2 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_icon1 = new lib.icon1_1();
  this.cvr_icon1.name = "cvr_icon1";
  this.cvr_icon1.parent = this;
  this.cvr_icon1.setTransform(70.7, 71, 1, 1, 0, 0, 0, 70.7, 71);
  this.timeline.addTween(cjs.Tween.get(this.cvr_icon1).wait(1));
 }).prototype = getMCSymbolPrototype(lib.icon1_2, new cjs.Rectangle(0, 0, 141.4, 142.1), null);
 (lib.fish02_float = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.fish02();
  this.instance.parent = this;
  this.instance.setTransform(114, 103.7, 1, 1, 0, 0, 0, 114, 103.7);
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   y: 98.7
  }, 9, cjs.Ease.get(-1)).to({
   y: 93.7
  }, 10, cjs.Ease.get(1)).to({
   y: 98.7
  }, 10, cjs.Ease.get(-1)).to({
   y: 103.7
  }, 10, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(0, -10, 230.8, 187.4);
 (lib.bubble_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.b1();
  this.instance.parent = this;
  this.instance.setTransform(149.4, 149.4, 1, 1, 0, 0, 0, 149.4, 149.4);
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   y: 143.75
  }, 9, cjs.Ease.get(-1)).to({
   y: 137.45
  }, 10, cjs.Ease.get(1)).to({
   y: 143.45
  }, 10, cjs.Ease.get(-1)).to({
   y: 149.4
  }, 10, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(0, -11.9, 298.8, 310.7);
 (lib.fish01_float = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.bubble_1();
  this.instance.parent = this;
  this.instance.setTransform(40, 98.7, 0.0337, 0.0337, 0, 0, 0, 145.6, 154.5);
  this.instance._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(21).to({
   _off: false
  }, 0).to({
   regX: 145.9,
   regY: 153.2,
   scaleX: 0.1707,
   scaleY: 0.1707,
   x: -10.4,
   y: -36.7
  }, 10, cjs.Ease.get(0.5)).to({
   regX: 145.7,
   regY: 154.5,
   scaleX: 0.034,
   scaleY: 0.034,
   x: 3.85,
   y: -137.85
  }, 10, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(76));
  this.instance_1 = new lib.bubble_1();
  this.instance_1.parent = this;
  this.instance_1.setTransform(40, 98.7, 0.0337, 0.0337, 0, 0, 0, 145.6, 154.5);
  this.instance_1._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(16).to({
   _off: false
  }, 0).to({
   regX: 145.9,
   regY: 153.2,
   scaleX: 0.1707,
   scaleY: 0.1707,
   x: -6,
   y: -40.55
  }, 10, cjs.Ease.get(0.5)).to({
   regX: 145.7,
   regY: 154.5,
   scaleX: 0.034,
   scaleY: 0.034,
   x: -10,
   y: -165.95
  }, 10, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(81));
  this.instance_2 = new lib.bubble_1();
  this.instance_2.parent = this;
  this.instance_2.setTransform(40, 98.7, 0.0337, 0.0337, 0, 0, 0, 145.6, 154.5);
  this.instance_2._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(11).to({
   _off: false
  }, 0).to({
   regX: 145.9,
   regY: 153.2,
   scaleX: 0.1707,
   scaleY: 0.1707,
   x: -1.5,
   y: -26.7
  }, 10, cjs.Ease.get(0.5)).to({
   regX: 145.7,
   regY: 154.5,
   scaleX: 0.034,
   scaleY: 0.034,
   x: -9.1,
   y: -138.25
  }, 10, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(86));
  this.instance_3 = new lib.bubble_1();
  this.instance_3.parent = this;
  this.instance_3.setTransform(40, 98.7, 0.0337, 0.0337, 0, 0, 0, 145.6, 154.5);
  this.instance_3._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(6).to({
   _off: false
  }, 0).to({
   regX: 145.9,
   regY: 153.2,
   scaleX: 0.1707,
   scaleY: 0.1707,
   x: 3.85,
   y: -12.85
  }, 10, cjs.Ease.get(0.5)).to({
   regX: 145.7,
   regY: 154.5,
   scaleX: 0.034,
   scaleY: 0.034,
   y: -128.25
  }, 10, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(91));
  this.instance_4 = new lib.fish01();
  this.instance_4.parent = this;
  this.instance_4.setTransform(114, 103.7, 1, 1, 0, 0, 0, 114, 103.7);
  this.timeline.addTween(cjs.Tween.get(this.instance_4).to({
   y: 98.7
  }, 9, cjs.Ease.get(-1)).to({
   y: 93.7
  }, 10, cjs.Ease.get(1)).to({
   y: 98.7
  }, 10, cjs.Ease.get(-1)).to({
   y: 103.7
  }, 10, cjs.Ease.get(1)).to({
   y: 98.7
  }, 9, cjs.Ease.get(-1)).to({
   y: 93.7
  }, 10, cjs.Ease.get(1)).to({
   y: 98.7
  }, 10, cjs.Ease.get(-1)).to({
   y: 103.7
  }, 10, cjs.Ease.get(1)).to({
   y: 98.7
  }, 9, cjs.Ease.get(-1)).to({
   y: 93.7
  }, 10, cjs.Ease.get(1)).to({
   y: 98.7
  }, 10, cjs.Ease.get(-1)).to({
   y: 103.7
  }, 10, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(-35.3, -171.2, 263.4, 378.7);
 (lib.content = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {
   cvr_frame1_2: 83,
   cvr_frame2_3: 178,
   "cvr_frame#3": 240,
   cvr_stay: 262,
   cvr_frame4_1: 349
  });
  this.instance = new lib.black_plate();
  this.instance.parent = this;
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   alpha: 0
  }, 14, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(349).to({
   _off: false
  }, 0).to({
   alpha: 1
  }, 15, cjs.Ease.get(-1)).wait(1));
  this.instance_1 = new lib.logo();
  this.instance_1.parent = this;
  this.instance_1.setTransform(112.5, 26.1, 1, 1, 0, 0, 0, 112.5, 26.1);
  this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(180).to({
   alpha: 0
  }, 14, cjs.Ease.get(1)).wait(85).to({
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(87));
  this.instance_2 = new lib.gr();
  this.instance_2.parent = this;
  this.instance_2.setTransform(150, 300, 1, 1, 0, 0, 0, 150, 300);
  this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(180).to({
   alpha: 0
  }, 14, cjs.Ease.get(1)).wait(85).to({
   regY: 300.1,
   y: 300.1,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(87));
  this.instance_3 = new lib.txt04("synched", 0, false);
  this.instance_3.parent = this;
  this.instance_3.setTransform(108, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance_3._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(295).to({
   _off: false
  }, 0).wait(85));
  this.instance_4 = new lib.l4();
  this.instance_4.parent = this;
  this.instance_4.setTransform(150.5, 560.1, 1, 1, 0, 0, 0, 149.5, 40.1);
  this.instance_4.alpha = 0;
  this.instance_4._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(310).to({
   _off: false
  }, 0).to({
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(56));
  this.instance_5 = new lib.fish02_float();
  this.instance_5.parent = this;
  this.instance_5.setTransform(254, 385.25, 0.6387, 0.6387, 0, 0, 0, 114.2, 103.8);
  this.instance_5._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(285).to({
   _off: false
  }, 0).to({
   x: 87.95
  }, 14, cjs.Ease.get(1)).wait(81));
  var mask = new cjs.Shape();
  mask._off = true;
  var mask_graphics_300 = new cjs.Graphics().p("ADTW9QgVgUAAgdQAAgdAVgVQAUgUAdAAQAdAAAVAUQAUAVAAAdQAAAdgUAUQgVAVgdAAQgdAAgUgVg");
  var mask_graphics_301 = new cjs.Graphics().p("ACUXIQgkgkAAgyQAAgzAkgkQAjgkAzAAQAzAAAkAkQAjAkAAAzQAAAygjAkQgkAkgzAAQgzAAgjgkg");
  var mask_graphics_302 = new cjs.Graphics().p("ABZXSQgygyAAhHQAAhGAygyQAygyBHAAQBHAAAyAyQAyAyAABGQAABHgyAyQgyAyhHAAQhHAAgygyg");
  var mask_graphics_303 = new cjs.Graphics().p("AAjXcQg+hAAAhZQAAhZA+g/QA/g/BaAAQBZAAA/A/QA/A/AABZQAABZg/BAQg/A/hZAAQhaAAg/g/g");
  var mask_graphics_304 = new cjs.Graphics().p("AgNXkQhLhLAAhqQAAhqBLhLQBKhLBqAAQBqAABLBLQBLBLAABqQAABqhLBLQhLBLhqAAQhqAAhKhLg");
  var mask_graphics_305 = new cjs.Graphics().p("Ag5XsQhWhWAAh5QAAh6BWhWQBUhVB6AAQB5AABWBVQBWBWAAB6QAAB5hWBWQhWBVh5AAQh6AAhUhVg");
  var mask_graphics_306 = new cjs.Graphics().p("AhhXzQhghgAAiHQAAiHBghfQBfhgCGAAQCHAABgBgQBfBfAACHQAACHhfBgQhgBfiHAAQiGAAhfhfg");
  var mask_graphics_307 = new cjs.Graphics().p("AiEX5QhohoAAiTQAAiUBohnQBohoCSAAQCTAABoBoQBoBnAACUQAACThoBoQhoBoiTAAQiSAAhohog");
  var mask_graphics_308 = new cjs.Graphics().p("AijX+QhvhwAAidQAAieBvhvQBwhvCcAAQCeAABvBvQBvBvAACeQAACdhvBwQhvBvieAAQicAAhwhvg");
  var mask_graphics_309 = new cjs.Graphics().p("Ai9YCQh1h1AAinQAAimB1h2QB2h1ClAAQCnAAB1B1QB2B2AACmQAACnh2B1Qh1B2inAAQilAAh2h2g");
  var mask_graphics_310 = new cjs.Graphics().p("AjSYGQh6h7AAitQAAiuB6h7QB7h6CtAAQCtAAB7B6QB7B7AACuQAACth7B7Qh7B7itAAQitAAh7h7g");
  var mask_graphics_311 = new cjs.Graphics().p("AjiYJQh/h/AAizQAAizB/h/QB/h/CyAAQCzAAB/B/QB+B/AACzQAACzh+B/Qh/B+izAAQiyAAh/h+g");
  var mask_graphics_312 = new cjs.Graphics().p("AjuYLQiBiCAAi3QAAi3CBiCQCCiBC2AAQC3AACCCBQCBCCAAC3QAAC3iBCCQiCCBi3AAQi2AAiCiBg");
  var mask_graphics_313 = new cjs.Graphics().p("Aj1YMQiDiDAAi6QAAi6CDiDQCEiDC4AAQC6AACDCDQCDCDAAC6QAAC6iDCDQiDCDi6AAQi4AAiEiDg");
  var mask_graphics_314 = new cjs.Graphics().p("Aj3YMQiEiEAAi6QAAi6CEiEQCEiEC5AAQC6AACECEQCECEAAC6QAAC6iECEQiECEi6AAQi5AAiEiEg");
  this.timeline.addTween(cjs.Tween.get(mask).to({
   graphics: null,
   x: 0,
   y: 0
  }).wait(300).to({
   graphics: mask_graphics_300,
   x: 33.0318,
   y: 148.9818
  }).wait(1).to({
   graphics: mask_graphics_301,
   x: 35.647,
   y: 151.6039
  }).wait(1).to({
   graphics: mask_graphics_302,
   x: 38.0684,
   y: 154.0317
  }).wait(1).to({
   graphics: mask_graphics_303,
   x: 40.2961,
   y: 156.2652
  }).wait(1).to({
   graphics: mask_graphics_304,
   x: 42.3301,
   y: 158.3046
  }).wait(1).to({
   graphics: mask_graphics_305,
   x: 44.1704,
   y: 160.1497
  }).wait(1).to({
   graphics: mask_graphics_306,
   x: 45.8169,
   y: 161.8006
  }).wait(1).to({
   graphics: mask_graphics_307,
   x: 47.2698,
   y: 163.2573
  }).wait(1).to({
   graphics: mask_graphics_308,
   x: 48.5289,
   y: 164.5197
  }).wait(1).to({
   graphics: mask_graphics_309,
   x: 49.5943,
   y: 165.588
  }).wait(1).to({
   graphics: mask_graphics_310,
   x: 50.4661,
   y: 166.462
  }).wait(1).to({
   graphics: mask_graphics_311,
   x: 51.1441,
   y: 167.1418
  }).wait(1).to({
   graphics: mask_graphics_312,
   x: 51.6283,
   y: 167.6273
  }).wait(1).to({
   graphics: mask_graphics_313,
   x: 51.9189,
   y: 167.9187
  }).wait(1).to({
   graphics: mask_graphics_314,
   x: 51.9997,
   y: 167.9997
  }).wait(66));
  this.instance_6 = new lib.icon03();
  this.instance_6.parent = this;
  this.instance_6.setTransform(60.25, 291.35, 0.6305, 0.6305, 0, 0, 0, 71.8, 71.9);
  this.instance_6._off = true;
  var maskedShapeInstanceList = [this.instance_6];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(300).to({
   _off: false
  }, 0).wait(80));
  this.instance_7 = new lib.bubble_1();
  this.instance_7.parent = this;
  this.instance_7.setTransform(60.35, 291.2, 0.0511, 0.0511, 0, 0, 0, 151.6, 150.7);
  this.instance_7._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(295).to({
   _off: false
  }, 0).to({
   regX: 151.4,
   regY: 150.9,
   scaleX: 0.3748,
   scaleY: 0.3748
  }, 14, cjs.Ease.get(1)).wait(71));
  this.instance_8 = new lib.bubble_1();
  this.instance_8.parent = this;
  this.instance_8.setTransform(80.05, 185.9, 0.063, 0.063, 0, 0, 0, 150.9, 151.7);
  this.instance_8._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(290).to({
   _off: false
  }, 0).to({
   regX: 150.8,
   scaleX: 0.5337,
   scaleY: 0.5337
  }, 14, cjs.Ease.get(1)).wait(76));
  this.instance_9 = new lib.black_plate();
  this.instance_9.parent = this;
  this.instance_9.alpha = 0;
  this.instance_9._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(277).to({
   _off: false
  }, 0).to({
   alpha: 1
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(87));
  this.instance_10 = new lib.l3();
  this.instance_10.parent = this;
  this.instance_10.setTransform(150.5, 560.1, 1, 1, 0, 0, 0, 149.5, 40.1);
  this.instance_10.alpha = 0;
  this.instance_10._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(205).to({
   _off: false
  }, 0).to({
   alpha: 1
  }, 14, cjs.Ease.get(1)).to({
   _off: true
  }, 74).wait(87));
  this.instance_11 = new lib.packshot_1();
  this.instance_11.parent = this;
  this.instance_11.setTransform(263.55, 353.45, 0.6469, 0.6484, 0, 0, 0, 119.5, 58.9);
  this.instance_11._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(185).to({
   _off: false
  }, 0).to({
   regX: 120.6,
   x: 82.35
  }, 14, cjs.Ease.get(1)).to({
   _off: true
  }, 94).wait(87));
  this.instance_12 = new lib.txt03("synched", 0, false);
  this.instance_12.parent = this;
  this.instance_12.setTransform(108, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance_12._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(195).to({
   _off: false
  }, 0).to({
   _off: true
  }, 98).wait(87));
  this.instance_13 = new lib.bubble_1();
  this.instance_13.parent = this;
  this.instance_13.setTransform(73.2, 185.85, 0.053, 0.053, 0, 0, 0, 150.8, 150.8);
  this.instance_13._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(190).to({
   _off: false
  }, 0).to({
   scaleX: 0.4786,
   scaleY: 0.4786,
   x: 73.15
  }, 13, cjs.Ease.get(1)).to({
   _off: true
  }, 90).wait(87));
  var mask_1 = new cjs.Shape();
  mask_1._off = true;
  var mask_1_graphics_200 = new cjs.Graphics().p("AHYVkQgUgUAAgcQAAgcAUgUQAUgUAbAAQAcAAAUAUQAUAUAAAcQAAAcgUAUQgUAUgcAAQgbAAgUgUg");
  var mask_1_graphics_201 = new cjs.Graphics().p("AGZVuQgjgjAAgxQAAgyAjgjQAjgjAxAAQAyAAAjAjQAjAjAAAyQAAAxgjAjQgjAjgyAAQgxAAgjgjg");
  var mask_1_graphics_202 = new cjs.Graphics().p("AFfV4QgygxAAhGQAAhFAygxQAxgxBFAAQBGAAAxAxQAxAxAABFQAABGgxAxQgxAxhGAAQhFAAgxgxg");
  var mask_1_graphics_203 = new cjs.Graphics().p("AEpWBQg+g+AAhYQAAhYA+g+QA+g+BYAAQBYAAA+A+QA+A+AABYQAABYg+A+Qg+A+hYAAQhYAAg+g+g");
  var mask_1_graphics_204 = new cjs.Graphics().p("AD4WJQhKhKAAhpQAAhoBKhKQBKhKBoAAQBpAABKBKQBKBKAABoQAABphKBKQhKBKhpAAQhoAAhKhKg");
  var mask_1_graphics_205 = new cjs.Graphics().p("ADMWQQhVhVAAh3QAAh4BVhVQBUhUB4AAQB4AABUBUQBVBVAAB4QAAB3hVBVQhUBVh4AAQh4AAhUhVg");
  var mask_1_graphics_206 = new cjs.Graphics().p("ACkWXQhehfAAiFQAAiFBeheQBehfCGAAQCFAABeBfQBeBeAACFQAACFheBfQheBeiFAAQiGAAheheg");
  var mask_1_graphics_207 = new cjs.Graphics().p("ACBWcQhnhmAAiSQAAiRBnhnQBnhmCRAAQCRAABnBmQBnBnAACRQAACShnBmQhnBniRAAQiRAAhnhng");
  var mask_1_graphics_208 = new cjs.Graphics().p("ABjWhQhthuAAibQAAicBthuQBuhuCbAAQCcAABuBuQBuBuAACcQAACbhuBuQhuBuicAAQibAAhuhug");
  var mask_1_graphics_209 = new cjs.Graphics().p("ABJWmQhzh1AAikQAAikBzh1QB0h0ClAAQCkAAB0B0QB1B1AACkQAACkh1B1Qh0B0ikAAQilAAh0h0g");
  var mask_1_graphics_210 = new cjs.Graphics().p("AA0WpQh4h5AAisQAAirB4h6QB5h5CsAAQCsAAB5B5QB5B6AACrQAACsh5B5Qh5B5isAAQisAAh5h5g");
  var mask_1_graphics_211 = new cjs.Graphics().p("AAkWsQh8h+AAixQAAixB8h9QB9h9CxAAQCxAAB+B9QB9B9AACxQAACxh9B+Qh+B9ixAAQixAAh9h9g");
  var mask_1_graphics_212 = new cjs.Graphics().p("AAYWuQh/iAAAi2QAAi1B/iAQCAiAC1AAQC2AACACAQCACAAAC1QAAC2iACAQiACAi2AAQi1AAiAiAg");
  var mask_1_graphics_213 = new cjs.Graphics().p("AARWvQiBiCAAi4QAAi3CBiCQCCiCC3AAQC4AACCCCQCBCCABC3QgBC4iBCCQiCCCi4AAQi3AAiCiCg");
  var mask_1_graphics_214 = new cjs.Graphics().p("AAPWwQiBiDAAi4QAAi4CBiDQCCiCC5AAQC4AACCCCQCCCDAAC4QAAC4iCCDQiCCCi4AAQi5AAiCiCg");
  this.timeline.addTween(cjs.Tween.get(mask_1).to({
   graphics: null,
   x: 0,
   y: 0
  }).wait(200).to({
   graphics: mask_1_graphics_200,
   x: 58.7026,
   y: 139.9526
  }).wait(1).to({
   graphics: mask_1_graphics_201,
   x: 61.2846,
   y: 142.5142
  }).wait(1).to({
   graphics: mask_1_graphics_202,
   x: 63.6752,
   y: 144.8861
  }).wait(1).to({
   graphics: mask_1_graphics_203,
   x: 65.8747,
   y: 147.0682
  }).wait(1).to({
   graphics: mask_1_graphics_204,
   x: 67.8828,
   y: 149.0605
  }).wait(1).to({
   graphics: mask_1_graphics_205,
   x: 69.6997,
   y: 150.8631
  }).wait(1).to({
   graphics: mask_1_graphics_206,
   x: 71.3254,
   y: 152.476
  }).wait(1).to({
   graphics: mask_1_graphics_207,
   x: 72.7598,
   y: 153.8991
  }).wait(1).to({
   graphics: mask_1_graphics_208,
   x: 74.003,
   y: 155.1324
  }).wait(1).to({
   graphics: mask_1_graphics_209,
   x: 75.0549,
   y: 156.176
  }).wait(1).to({
   graphics: mask_1_graphics_210,
   x: 75.9155,
   y: 157.0299
  }).wait(1).to({
   graphics: mask_1_graphics_211,
   x: 76.5849,
   y: 157.694
  }).wait(1).to({
   graphics: mask_1_graphics_212,
   x: 77.063,
   y: 158.1684
  }).wait(1).to({
   graphics: mask_1_graphics_213,
   x: 77.3499,
   y: 158.453
  }).wait(1).to({
   graphics: mask_1_graphics_214,
   x: 77.4455,
   y: 158.5955
  }).wait(79).to({
   graphics: null,
   x: 0,
   y: 0
  }).wait(87));
  this.instance_14 = new lib._new();
  this.instance_14.parent = this;
  this.instance_14.setTransform(114.75, 273.05, 0.6837, 0.6837, 0, 0, 0, 57.9, 52.1);
  this.instance_14._off = true;
  var maskedShapeInstanceList = [this.instance_14];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(200).to({
   _off: false
  }, 0).to({
   _off: true
  }, 93).wait(87));
  this.instance_15 = new lib.bubble_1();
  this.instance_15.parent = this;
  this.instance_15.setTransform(111.6, 274.25, 0.0461, 0.0461, 0, 0, 0, 152, 152);
  this.instance_15._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(195).to({
   _off: false
  }, 0).to({
   regX: 152.1,
   regY: 151.8,
   scaleX: 0.2958,
   scaleY: 0.2958
  }, 13, cjs.Ease.get(1)).to({
   _off: true
  }, 85).wait(87));
  this.instance_16 = new lib.bg_g();
  this.instance_16.parent = this;
  this.instance_16.alpha = 0;
  this.instance_16._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(180).to({
   _off: false
  }, 0).to({
   alpha: 1
  }, 14, cjs.Ease.get(1)).to({
   _off: true
  }, 99).wait(87));
  this.instance_17 = new lib.txt02("synched", 0, false);
  this.instance_17.parent = this;
  this.instance_17.setTransform(108, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance_17._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(105).to({
   _off: false
  }, 0).to({
   _off: true
  }, 90).wait(185));
  this.instance_18 = new lib.l2();
  this.instance_18.parent = this;
  this.instance_18.setTransform(148.5, 577.85, 1, 1, 0, 0, 0, 141.5, 14.8);
  this.instance_18.alpha = 0;
  this.instance_18._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(120).to({
   _off: false
  }, 0).to({
   alpha: 1
  }, 14, cjs.Ease.get(1)).to({
   _off: true
  }, 61).wait(185));
  this.instance_19 = new lib.bubble_1();
  this.instance_19.parent = this;
  this.instance_19.setTransform(77.7, 206.35, 0.0662, 0.0662, 0, 0, 0, 149.5, 149.5);
  this.instance_19._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(100).to({
   _off: false
  }, 0).to({
   regX: 149.2,
   regY: 149.6,
   scaleX: 0.6358,
   scaleY: 0.6358,
   x: 77.65
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 80).wait(185));
  this.instance_20 = new lib.fish01_float("synched", 0, false);
  this.instance_20.parent = this;
  this.instance_20.setTransform(258.05, 449.6, 0.6502, 0.6502, 0, 0, 0, 114.2, 103.8);
  this.instance_20._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_20).wait(95).to({
   _off: false
  }, 0).to({
   x: 89.05,
   startPosition: 13
  }, 14, cjs.Ease.get(1)).to({
   _off: true
  }, 86).wait(185));
  this.instance_21 = new lib.black_plate();
  this.instance_21.parent = this;
  this.instance_21.alpha = 0;
  this.instance_21._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_21).wait(84).to({
   _off: false
  }, 0).to({
   alpha: 1
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(280));
  this.instance_22 = new lib.l1();
  this.instance_22.parent = this;
  this.instance_22.setTransform(148.5, 577.85, 1, 1, 0, 0, 0, 141.5, 14.8);
  this.instance_22.alpha = 0;
  this.instance_22._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_22).wait(40).to({
   _off: false
  }, 0).to({
   alpha: 1
  }, 14, cjs.Ease.get(1)).to({
   _off: true
  }, 46).wait(280));
  this.instance_23 = new lib.txt02_1("synched", 0, false);
  this.instance_23.parent = this;
  this.instance_23.setTransform(108, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance_23._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_23).wait(26).to({
   _off: false
  }, 0).to({
   _off: true
  }, 74).wait(280));
  this.instance_24 = new lib.txt01("synched", 0, false);
  this.instance_24.parent = this;
  this.instance_24.setTransform(108, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance_24._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_24).wait(5).to({
   _off: false
  }, 0).to({
   _off: true
  }, 95).wait(280));
  this.instance_25 = new lib.bubble_1();
  this.instance_25.parent = this;
  this.instance_25.setTransform(51.95, 373, 0.0598, 0.0598, 0, 0, 0, 151.3, 151.3);
  this.instance_25._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_25).wait(20).to({
   _off: false
  }, 0).to({
   regX: 151.2,
   regY: 151.5,
   scaleX: 0.3112,
   scaleY: 0.3112,
   y: 373.05
  }, 14, cjs.Ease.get(1)).to({
   _off: true
  }, 66).wait(280));
  var mask_2 = new cjs.Shape();
  mask_2._off = true;
  var mask_2_graphics_30 = new cjs.Graphics().p("EAGFAiuQgTgSAAgaQAAgbATgSQATgTAaAAQAaAAATATQASASAAAbQAAAagSASQgTATgaAAQgaAAgTgTg");
  var mask_2_graphics_31 = new cjs.Graphics().p("EAFTAi2QgegfAAgrQAAgrAegeQAfgfArAAQArAAAfAfQAeAeAAArQAAArgeAfQgfAegrAAQgrAAgfgeg");
  var mask_2_graphics_32 = new cjs.Graphics().p("EAEmAi9QgqgqAAg7QAAg6AqgqQApgqA7AAQA7AAApAqQAqAqAAA6QAAA7gqAqQgpApg7AAQg7AAgpgpg");
  var mask_2_graphics_33 = new cjs.Graphics().p("EAD7AjDQgzgzAAhKQAAhJAzg0QA0gzBJAAQBKAAAzAzQA0A0AABJQAABKg0AzQgzA0hKAAQhJAAg0g0g");
  var mask_2_graphics_34 = new cjs.Graphics().p("EADVAjJQg9g9AAhWQAAhXA9g9QA9g9BWAAQBXAAA9A9QA9A9AABXQAABWg9A9Qg9A9hXAAQhWAAg9g9g");
  var mask_2_graphics_35 = new cjs.Graphics().p("EACyAjPQhGhGAAhiQAAhjBGhFQBFhGBjAAQBiAABGBGQBFBFAABjQAABihFBGQhGBFhiAAQhjAAhFhFg");
  var mask_2_graphics_36 = new cjs.Graphics().p("EACTAjTQhNhNAAhtQAAhtBNhNQBNhNBtAAQBtAABNBNQBNBNAABtQAABthNBNQhNBNhtAAQhtAAhNhNg");
  var mask_2_graphics_37 = new cjs.Graphics().p("EAB3AjYQhUhUAAh2QAAh3BUhUQBUhTB2AAQB3AABTBTQBUBUAAB3QAAB2hUBUQhTBTh3AAQh2AAhUhTg");
  var mask_2_graphics_38 = new cjs.Graphics().p("EABfAjbQhZhZAAh/QAAh+BZhaQBahZB+AAQB/AABZBZQBaBaAAB+QAAB/haBZQhZBah/AAQh+AAhahag");
  var mask_2_graphics_39 = new cjs.Graphics().p("EABLAjeQhdheAAiFQAAiGBdheQBeheCGAAQCFAABfBeQBeBeAACGQAACFheBeQhfBfiFAAQiGAAhehfg");
  var mask_2_graphics_40 = new cjs.Graphics().p("EAA7AjhQhihiAAiLQAAiMBihiQBihiCLAAQCLAABiBiQBjBiAACMQAACLhjBiQhiBiiLAAQiLAAhihig");
  var mask_2_graphics_41 = new cjs.Graphics().p("EAAuAjjQhlhmAAiPQAAiPBlhmQBlhlCQAAQCPAABmBlQBlBmAACPQAACPhlBmQhmBliPAAQiQAAhlhlg");
  var mask_2_graphics_42 = new cjs.Graphics().p("EAAlAjkQhnhnAAiTQAAiTBnhnQBnhoCTAAQCSAABoBoQBoBnAACTQAACThoBnQhoBoiSAAQiTAAhnhog");
  var mask_2_graphics_43 = new cjs.Graphics().p("EAAfAjlQhohpAAiUQAAiVBohpQBphpCVAAQCUAABpBpQBpBpAACVQAACUhpBpQhpBpiUAAQiVAAhphpg");
  var mask_2_graphics_44 = new cjs.Graphics().p("EAAdAjlQhohpAAiVQAAiWBohpQBqhpCVAAQCVAABpBpQBqBpAACWQAACVhqBpQhpBpiVAAQiVAAhqhpg");
  this.timeline.addTween(cjs.Tween.get(mask_2).to({
   graphics: null,
   x: 0,
   y: 0
  }).wait(30).to({
   graphics: mask_2_graphics_30,
   x: 49.7036,
   y: 224.0786
  }).wait(1).to({
   graphics: mask_2_graphics_31,
   x: 51.7236,
   y: 226.035
  }).wait(1).to({
   graphics: mask_2_graphics_32,
   x: 53.594,
   y: 227.8465
  }).wait(1).to({
   graphics: mask_2_graphics_33,
   x: 55.3147,
   y: 229.5131
  }).wait(1).to({
   graphics: mask_2_graphics_34,
   x: 56.8858,
   y: 231.0348
  }).wait(1).to({
   graphics: mask_2_graphics_35,
   x: 58.3073,
   y: 232.4115
  }).wait(1).to({
   graphics: mask_2_graphics_36,
   x: 59.5791,
   y: 233.6434
  }).wait(1).to({
   graphics: mask_2_graphics_37,
   x: 60.7014,
   y: 234.7303
  }).wait(1).to({
   graphics: mask_2_graphics_38,
   x: 61.6739,
   y: 235.6723
  }).wait(1).to({
   graphics: mask_2_graphics_39,
   x: 62.4969,
   y: 236.4693
  }).wait(1).to({
   graphics: mask_2_graphics_40,
   x: 63.1702,
   y: 237.1215
  }).wait(1).to({
   graphics: mask_2_graphics_41,
   x: 63.6939,
   y: 237.6287
  }).wait(1).to({
   graphics: mask_2_graphics_42,
   x: 64.068,
   y: 237.991
  }).wait(1).to({
   graphics: mask_2_graphics_43,
   x: 64.2925,
   y: 238.2084
  }).wait(1).to({
   graphics: mask_2_graphics_44,
   x: 64.3673,
   y: 238.2423
  }).wait(56).to({
   graphics: null,
   x: 0,
   y: 0
  }).wait(280));
  this.instance_26 = new lib.icon02();
  this.instance_26.parent = this;
  this.instance_26.setTransform(93.35, 439.9, 0.6437, 0.6434, 0, 0, 0, 57.6, 58.1);
  this.instance_26._off = true;
  var maskedShapeInstanceList = [this.instance_26];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_26).wait(30).to({
   _off: false
  }, 0).to({
   _off: true
  }, 70).wait(280));
  this.instance_27 = new lib.bubble_1();
  this.instance_27.parent = this;
  this.instance_27.setTransform(94.55, 441.3, 0.0496, 0.0496, 0, 0, 0, 154.2, 155.2);
  this.instance_27._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_27).wait(25).to({
   _off: false
  }, 0).to({
   regX: 153.7,
   regY: 155.5,
   scaleX: 0.3046,
   scaleY: 0.3046
  }, 14, cjs.Ease.get(1)).to({
   _off: true
  }, 61).wait(280));
  var mask_3 = new cjs.Shape();
  mask_3._off = true;
  var mask_3_graphics_10 = new cjs.Graphics().p("AGmYCQgWgWAAgfQAAgfAWgWQAWgWAfAAQAfAAAWAWQAWAWAAAfQAAAfgWAWQgWAWgfAAQgfAAgWgWg");
  var mask_3_graphics_11 = new cjs.Graphics().p("AFoYNQglglAAg1QAAg0AlglQAlglA0AAQA1AAAlAlQAlAlAAA0QAAA1glAlQglAlg1AAQg0AAglglg");
  var mask_3_graphics_12 = new cjs.Graphics().p("AEvYWQgzgyAAhIQAAhIAzgzQAzgzBIAAQBIAAAyAzQAzAzAABIQAABIgzAyQgyAzhIAAQhIAAgzgzg");
  var mask_3_graphics_13 = new cjs.Graphics().p("AD7YfQhAg/AAhaQAAhaBAg/QA/hABaAAQBaAAA/BAQBAA/AABaQAABahAA/Qg/BAhaAAQhaAAg/hAg");
  var mask_3_graphics_14 = new cjs.Graphics().p("ADLYnQhLhLAAhqQAAhqBLhLQBLhLBqAAQBqAABLBLQBLBLAABqQAABqhLBLQhLBLhqAAQhqAAhLhLg");
  var mask_3_graphics_15 = new cjs.Graphics().p("ACfYvQhVhWAAh5QAAh5BVhWQBWhVB5AAQB5AABWBVQBVBWAAB5QAAB5hVBWQhWBVh5AAQh5AAhWhVg");
  var mask_3_graphics_16 = new cjs.Graphics().p("AB5Y1QhfhfAAiGQAAiGBfhfQBfhfCGAAQCGAABfBfQBfBfAACGQAACGhfBfQhfBfiGAAQiGAAhfhfg");
  var mask_3_graphics_17 = new cjs.Graphics().p("ABWY7QhmhnAAiSQAAiSBmhoQBohnCSAAQCSAABnBnQBnBoAACSQAACShnBnQhnBniSAAQiSAAhohng");
  var mask_3_graphics_18 = new cjs.Graphics().p("AA5ZAQhuhuAAidQAAicBuhuQBuhvCcAAQCdAABuBvQBvBuAACcQAACdhvBuQhuBvidAAQicAAhuhvg");
  var mask_3_graphics_19 = new cjs.Graphics().p("AAgZEQh0h0AAilQAAilB0h0QB0h1ClAAQClAAB0B1QB1B0AAClQAAClh1B0Qh0B1ilAAQilAAh0h1g");
  var mask_3_graphics_20 = new cjs.Graphics().p("AALZIQh4h6AAirQAAisB4h6QB6h5CsAAQCrAAB6B5QB5B6AACsQAACrh5B6Qh6B5irAAQisAAh6h5g");
  var mask_3_graphics_21 = new cjs.Graphics().p("AgEZLQh9h+AAixQAAixB9h+QB9h9CxAAQCxAAB+B9QB9B+AACxQAACxh9B+Qh+B9ixAAQixAAh9h9g");
  var mask_3_graphics_22 = new cjs.Graphics().p("AgPZMQiAiAAAi1QAAi1CAiAQB/iAC1AAQC1AACACAQCBCAAAC1QAAC1iBCAQiACBi1AAQi1AAh/iBg");
  var mask_3_graphics_23 = new cjs.Graphics().p("AgWZOQiCiCAAi4QAAi3CCiCQCBiCC3AAQC4AACCCCQCBCCAAC3QAAC4iBCCQiCCBi4AAQi3AAiBiBg");
  var mask_3_graphics_24 = new cjs.Graphics().p("AgYZPQiCiDAAi4QAAi4CCiDQCCiCC4AAQC4AACDCCQCCCDAAC4QAAC4iCCDQiDCCi4AAQi4AAiCiCg");
  this.timeline.addTween(cjs.Tween.get(mask_3).to({
   graphics: null,
   x: 0,
   y: 0
  }).wait(10).to({
   graphics: mask_3_graphics_10,
   x: 55.027,
   y: 156.027
  }).wait(1).to({
   graphics: mask_3_graphics_11,
   x: 57.563,
   y: 158.563
  }).wait(1).to({
   graphics: mask_3_graphics_12,
   x: 59.9111,
   y: 160.9111
  }).wait(1).to({
   graphics: mask_3_graphics_13,
   x: 62.0714,
   y: 163.0714
  }).wait(1).to({
   graphics: mask_3_graphics_14,
   x: 64.0438,
   y: 165.0438
  }).wait(1).to({
   graphics: mask_3_graphics_15,
   x: 65.8283,
   y: 166.8283
  }).wait(1).to({
   graphics: mask_3_graphics_16,
   x: 67.4251,
   y: 168.4251
  }).wait(1).to({
   graphics: mask_3_graphics_17,
   x: 68.8339,
   y: 169.8339
  }).wait(1).to({
   graphics: mask_3_graphics_18,
   x: 70.055,
   y: 171.055
  }).wait(1).to({
   graphics: mask_3_graphics_19,
   x: 71.0881,
   y: 172.0881
  }).wait(1).to({
   graphics: mask_3_graphics_20,
   x: 71.9335,
   y: 172.9335
  }).wait(1).to({
   graphics: mask_3_graphics_21,
   x: 72.5909,
   y: 173.5909
  }).wait(1).to({
   graphics: mask_3_graphics_22,
   x: 73.0605,
   y: 174.0605
  }).wait(1).to({
   graphics: mask_3_graphics_23,
   x: 73.3423,
   y: 174.3423
  }).wait(1).to({
   graphics: mask_3_graphics_24,
   x: 73.4998,
   y: 174.4998
  }).wait(76).to({
   graphics: null,
   x: 0,
   y: 0
  }).wait(280));
  this.instance_28 = new lib.icon1_2();
  this.instance_28.parent = this;
  this.instance_28.setTransform(102.45, 306.45, 0.6365, 0.6357, 0, 0, 0, 71.4, 71.5);
  this.instance_28._off = true;
  var maskedShapeInstanceList = [this.instance_28];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_28).wait(10).to({
   _off: false
  }, 0).to({
   _off: true
  }, 90).wait(280));
  this.instance_29 = new lib.bubble_1();
  this.instance_29.parent = this;
  this.instance_29.setTransform(102.45, 307.25, 0.0563, 0.0563, 0, 0, 0, 151.1, 152);
  this.instance_29._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_29).wait(5).to({
   _off: false
  }, 0).to({
   regX: 151.3,
   regY: 151.6,
   scaleX: 0.3681,
   scaleY: 0.3681
  }, 14, cjs.Ease.get(1)).to({
   _off: true
  }, 81).wait(280));
  this.instance_30 = new lib.bubble_1();
  this.instance_30.parent = this;
  this.instance_30.setTransform(77.9, 207.3, 0.0656, 0.0656, 0, 0, 0, 148.8, 150.2);
  this.timeline.addTween(cjs.Tween.get(this.instance_30).to({
   regX: 149,
   regY: 150,
   scaleX: 0.5957,
   scaleY: 0.5957,
   y: 207.2
  }, 14, cjs.Ease.get(1)).to({
   _off: true
  }, 86).wait(280));
  this.instance_31 = new lib.black_plate();
  this.instance_31.parent = this;
  this.timeline.addTween(cjs.Tween.get(this.instance_31).wait(380));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(-17.2, 0, 355.4, 601.5);
 (lib.JnJ_Motilegas_160x600 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.content();
  this.instance.parent = this;
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));
  this.instance_1 = new lib.black_plate();
  this.instance_1.parent = this;
  this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(80, 300, 80, 300);
 lib.properties = {
  id: '1E4D562F91EE4B408F0AC49B20246D76',
  width: 160,
  height: 600,
  fps: 24,
  color: "#FFFFFF",
  opacity: 1.00,
  manifest: [{
   src: "bubble.png",
   id: "bubble"
  }, {
   src: "fish1.png",
   id: "fish1"
  }, {
   src: "fish2.png",
   id: "fish2"
  }, {
   src: "icon2.png",
   id: "icon2"
  }, {
   src: "icon3.png",
   id: "icon3"
  }, {
   src: "packshot.png",
   id: "packshot"
  }, {
   src: "t2_1_t2_lact.png",
   id: "t2_1_t2_lact"
  }, {
   src: "t1_t1_lact.png",
   id: "t1_t1_lact"
  }, {
   src: "icon1_1_icon1_lact.png",
   id: "icon1_1_icon1_lact"
  }, ],
  preloads: []
 };
 (lib.Stage = function(canvas) {
  createjs.Stage.call(this, canvas);
 }).prototype = p = new createjs.Stage();
 p.setAutoPlay = function(autoPlay) {
  this.tickEnabled = autoPlay;
 }
 p.play = function() {
  this.tickEnabled = true;
  this.getChildAt(0).gotoAndPlay(this.getTimelinePosition())
 }
 p.stop = function(ms) {
  if (ms) this.seek(ms);
  this.tickEnabled = false;
 }
 p.seek = function(ms) {
  this.tickEnabled = true;
  this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000);
 }
 p.getDuration = function() {
  return this.getChildAt(0).totalFrames / lib.properties.fps * 1000;
 }
 p.getTimelinePosition = function() {
  return this.getChildAt(0).currentFrame / lib.properties.fps * 1000;
 }
 an.bootcompsLoaded = an.bootcompsLoaded || [];
 if (!an.bootstrapListeners) {
  an.bootstrapListeners = [];
 }
 an.bootstrapCallback = function(fnCallback) {
  an.bootstrapListeners.push(fnCallback);
  if (an.bootcompsLoaded.length > 0) {
   for (var i = 0; i < an.bootcompsLoaded.length; ++i) {
    fnCallback(an.bootcompsLoaded[i]);
   }
  }
 };
 an.compositions = an.compositions || {};
 an.compositions['1E4D562F91EE4B408F0AC49B20246D76'] = {
  getStage: function() {
   return exportRoot.getStage();
  },
  getLibrary: function() {
   return lib;
  },
  getSpriteSheet: function() {
   return ss;
  },
  getImages: function() {
   return img;
  }
 };
 an.compositionLoaded = function(id) {
  an.bootcompsLoaded.push(id);
  for (var j = 0; j < an.bootstrapListeners.length; j++) {
   an.bootstrapListeners[j](id);
  }
 }
 an.getComposition = function(id) {
  return an.compositions[id];
 }
 an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {
  var lastW, lastH, lastS = 1;
  window.addEventListener('resize', resizeCanvas);
  resizeCanvas();

  function resizeCanvas() {
   var w = lib.properties.width,
    h = lib.properties.height;
   var iw = window.innerWidth,
    ih = window.innerHeight;
   var pRatio = window.devicePixelRatio || 1,
    xRatio = iw / w,
    yRatio = ih / h,
    sRatio = 1;
   if (isResp) {
    if ((respDim == 'width' && lastW == iw) || (respDim == 'height' && lastH == ih)) {
     sRatio = lastS;
    } else if (!isScale) {
     if (iw < w || ih < h) sRatio = Math.min(xRatio, yRatio);
    } else if (scaleType == 1) {
     sRatio = Math.min(xRatio, yRatio);
    } else if (scaleType == 2) {
     sRatio = Math.max(xRatio, yRatio);
    }
   }
   domContainers[0].width = w * pRatio * sRatio;
   domContainers[0].height = h * pRatio * sRatio;
   domContainers.forEach(function(container) {
    container.style.width = w * sRatio + 'px';
    container.style.height = h * sRatio + 'px';
   });
   stage.scaleX = pRatio * sRatio;
   stage.scaleY = pRatio * sRatio;
   lastW = iw;
   lastH = ih;
   lastS = sRatio;
   stage.tickOnUpdate = false;
   stage.update();
   stage.tickOnUpdate = true;
  }
 }
})(createjs = createjs || {}, AdobeAn = AdobeAn || {});
var createjs, AdobeAn;