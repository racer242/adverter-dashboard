(function(cjs, an) {
 var p;
 var lib = {};
 var ss = {};
 var img = {};
 lib.ssMetadata = [];
 (lib.bubble = function() {
  this.initialize(img.bubble);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 448, 448);
 (lib.fish1 = function() {
  this.initialize(img.fish1);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 342, 311);
 (lib.fish2 = function() {
  this.initialize(img.fish2);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 346, 266);
 (lib.icon2 = function() {
  this.initialize(img.icon2);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 170, 172);
 (lib.icon3 = function() {
  this.initialize(img.icon3);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 214, 214);
 (lib.packshot = function() {
  this.initialize(img.packshot);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 352, 170);

 function mc_symbol_clone() {
  var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
  clone.gotoAndStop(this.currentFrame);
  clone.paused = this.paused;
  clone.framerate = this.framerate;
  return clone;
 }

 function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
  var prototype = cjs.extend(symbol, cjs.MovieClip);
  prototype.clone = mc_symbol_clone;
  prototype.nominalBounds = nominalBounds;
  prototype.frameBounds = frameBounds;
  return prototype;
 }
 (lib.t4 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#0C593C").s().p("AAAAMIgLAUIgIgIIALgUIgSgGIADgLIATAHIAAgYIAKAAIAAAYIASgHIADALIgSAGIALAUIgIAIg");
  this.shape.setTransform(181.95, 202.4);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#0C593C").s().p("AgsCVQgUgIgOgUQgMgQgFgUQgEgSgBgVIAxAAQAAAJACAKQABAJAEAJQAHAOAKAGQAKAGAIABIAMABQAIAAAIgCQAIgBAHgHQAKgIADgLQADgKAAgKIgBgMQgBgIgDgGQgEgIgHgFQgHgEgJgBIgOgCIgaAAIAAgrIAWAAIANgBQAHgCAGgEQAFgDAFgIQAFgIAAgOQAAgMgEgJQgEgIgFgEQgIgHgIgCIgMgCQgHABgIACQgJACgIAGQgIAIgEALQgEAKAAALIgxAAIACgTQABgLAEgMQAEgLAHgLQAOgRAVgHQAVgHAZAAIAUACQAMABAMAEQALAFALAJQALAKAFAMQAFAMABALIACASQAAAKgDANQgDAOgMANQgDAEgGADQgGAFgHABIAAACQAJABAHAFQAHACAEAFQAJAHAHAPQAGAQAAAWQAAAagJARQgJARgLAJQgJAIgRAFQgSAHgbAAQgZAAgUgHg");
  this.shape_1.setTransform(167.075, 216.3);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#0C593C").s().p("AA9CTIgRg+IhXAAIgRA+IgzAAIBYklIAuAAIBYElgAAgApIggh+IggB+IBAAAg");
  this.shape_2.setTransform(144.75, 216.3);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#0C593C").s().p("AhdCTIAAklIBeAAQAWAAASAFQASAFAPARQAMAQAFARQADARAAAOQAAAbgIARQgGARgLAJQgPAPgSAFQgRAEgSAAIgsAAIAABsgAgrgFIAmAAQAJABAJgCQALgDAIgIQAEgFADgIQADgIABgOQAAgNgDgJQgDgIgFgFQgIgKgKgCQgLgDgHABIgnAAg");
  this.shape_3.setTransform(123.6, 216.2977);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#0C593C").s().p("AgrBwQgJgCgIgFQgKgFgHgNQgIgOgBgVQABgLACgJQACgKAGgIQAFgJAIgFQAHgEAJgDQAKgEAMgBIAcgGIAKgCQAFgBADgEIACgEQABgDAAgJQAAgJgCgIQgDgIgGgGQgEgEgGgBQgEgBgEAAQgMAAgGAGQgHAGgDAGQgCAEgBAGIgCAMIgsAAQAAgLADgLQADgLAGgKQAIgOALgHQAMgGAMgCQAMgDALABQAJgBAPADQAOADANAKQAOALAFAPQAEAPABATIAABUIABAQIABAGQACADADABIAHAAIAAAjIgKABIgNAAQgFABgHgCQgGgBgGgEQgEgEgDgGQgCgFgBgFIgBAAQgEAHgEAFIgIAHQgHAFgKADQgKADgMAAIgQgBgAAWAIIgDABIgJAEIgJACIgOAEQgGABgEADQgIAFgDAHQgEAHABAIQAAAEABAGQABAGAFAGQADADAEACQAFACAFAAQAGAAAHgDQAGgEAGgJQAIgLACgNQADgOAAgMIAAgHIgDACg");
  this.shape_4.setTransform(92.35, 220.1708);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#0C593C").s().p("AgYBxQgMgCgMgHQgOgKgJgRQgIgRgBgUIAsAAQAAAHACAHQADAIAEAGQAGAIAIADQAIACAFAAIAJgBQAFgBAGgFQAGgDADgHQAEgHAAgLQAAgGgCgHQgCgGgHgFQgFgEgGgBIgLgBIgRAAIAAghIAOAAIAHgBQAGgBAGgEQAGgFADgHIABgMQAAgJgCgGQgDgHgEgDQgEgFgFgBQgFgCgEABQgGgBgGADQgHACgFAJQgEAHgBAHIgBALIgsAAQAAgPAFgOQAFgOAIgJQANgNAPgEQAQgEANAAQAMAAAQADQAPAEANAMQAIAIAEAMQAFAMAAAOQAAAKgDAJQgDAJgGAHQgFAFgEACQgFADgDAAIAAACQAGAAAGACQAHADAGAIQAHAIACAIQADAIAAAJQAAAPgEALQgEALgGAIQgFAHgGAEQgNAJgPADQgQADgNAAQgKAAgNgCg");
  this.shape_5.setTransform(73.175, 220.3469);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#0C593C").s().p("AgsBwQgJgCgHgFQgKgFgIgNQgHgOgBgVQAAgLADgJQADgKAFgIQAFgJAIgFQAHgEAKgDQAJgEALgBIAdgGIAKgCQAFgBADgEIACgEQABgDABgJQgBgJgCgIQgCgIgGgGQgGgEgFgBQgEgBgEAAQgMAAgHAGQgGAGgDAGQgCAEgBAGIgBAMIgtAAQAAgLADgLQADgLAFgKQAJgOALgHQAMgGAMgCQAMgDALABQAJgBAOADQAPADANAKQAOALAEAPQAGAPAAATIAABUIAAAQIACAGQACADADABIAIAAIAAAjIgLABIgNAAQgFABgGgCQgHgBgGgEQgEgEgCgGQgDgFgBgFIgBAAQgEAHgFAFIgHAHQgHAFgKADQgJADgNAAIgRgBgAAWAIIgEABIgIAEIgJACIgOAEQgGABgEADQgJAFgCAHQgDAHAAAIQgBAEACAGQABAGAFAGQADADAEACQAEACAFAAQAHAAAHgDQAGgEAGgJQAIgLACgNQAEgOAAgMIAAgHIgEACg");
  this.shape_6.setTransform(187.6, 180.0208);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#0C593C").s().p("AhMBrIgJgBIAAgjQALADAIgEQAHgEAEgHQAEgFACgLQACgKABgTIAAgzIAAhGICEAAIAADVIguAAIAAiyIgqAAIAAAoIAAAjIgBAVIAAAMQgEAXgGANQgFAOgHAFQgIAIgLAFQgLADgNAAIgIAAg");
  this.shape_7.setTransform(166.95, 180.25);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#0C593C").s().p("AguCSIgMgCIAAgiIAGABIAIABQAMgBAGgGQAGgHADgNIAGgSIhPjVIAzAAIAvCbIABAAIAmibIAsAAIhBDnIgGAVQgEAMgIALQgIAKgKADQgJAFgNAAIgOgBg");
  this.shape_8.setTransform(149.675, 184.15);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#0C593C").s().p("AADBzIgTgBQgKgCgLgGQgLgHgLgMQgLgNgGgWQgHgVAAgeIABgZQACgPAFgRQAFgRALgOQAOgQAQgFQAQgGAOAAQANAAAQAEQAPAFAPAOQALAMAGAPQAGAPABAOIgsAAIgDgOQgCgIgEgGQgFgHgGgFQgHgEgJAAQgJAAgHAFQgHAFgFAKQgEAKgDALIgDAVIAAASQgBANADAPQACAPAGANQAGAMAIAGQAHAGAJAAQALAAAGgGQAHgGAEgJQAEgKABgJIACgMIArAAQAAANgFAPQgFAPgJANQgOATgRAGQgPAFgOAAIgCAAg");
  this.shape_9.setTransform(131.475, 180.1994);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.f("#0C593C").s().p("AAiBrIAAiyIhDAAIAACyIguAAIAAjVICfAAIAADVg");
  this.shape_10.setTransform(111.475, 180.175);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.f("#0C593C").s().p("AgsBwQgIgCgIgFQgKgFgHgNQgIgOAAgVQAAgLACgJQADgKAFgIQAGgJAGgFQAIgEAJgDQAKgEALgBIAegGIAJgCQAGgBADgEIABgEQACgDgBgJQABgJgDgIQgDgIgFgGQgFgEgGgBQgEgBgDAAQgNAAgGAGQgIAGgCAGQgDAEgBAGIgBAMIgsAAQAAgLADgLQACgLAGgKQAJgOAMgHQALgGAMgCQANgDAKABQAJgBAPADQAOADAOAKQANALAFAPQAEAPAAATIAABUIABAQIACAGQACADADABIAIAAIAAAjIgLABIgNAAQgFABgGgCQgHgBgGgEQgEgEgCgGQgDgFgBgFIgBAAQgDAHgGAFIgGAHQgIAFgJADQgKADgNAAIgRgBgAAWAIIgEABIgJAEIgIACIgOAEQgGABgEADQgIAFgEAHQgCAHAAAIQAAAEABAGQABAGAFAGQADADAEACQAEACAGAAQAGAAAHgDQAGgEAHgJQAHgLADgNQACgOAAgMIAAgHIgDACg");
  this.shape_11.setTransform(91.6, 180.0208);
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.f("#0C593C").s().p("AAbBrIg7hoIAABoIguAAIAAjVIAuAAIAABZIA4hZIAyAAIhGBkIBLBxg");
  this.shape_12.setTransform(74.3, 180.175);
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.f("#0C593C").s().p("AA9CTIgRg+IhXAAIgRA+IgyAAIBXklIAvAAIBXElgAAhApIghh+IggB+IBBAAg");
  this.shape_13.setTransform(150.8, 136);
  this.shape_14 = new cjs.Shape();
  this.shape_14.graphics.f("#0C593C").s().p("AAvCTIAAiEIhdAAIAACEIgyAAIAAklIAyAAIAAB1IBdAAIAAh1IAyAAIAAElg");
  this.shape_14.setTransform(127.575, 136);
  this.shape_15 = new cjs.Shape();
  this.shape_15.graphics.f("#0C593C").s().p("ABSC0IAAhCIijAAIAABCIgqAAIgDhvIAWAAIAJgQQAGgLAGgUQAHgSAGgZIADggIACghIABgeIAAg/ICeAAIAAD4IAhAAIgDBvgAgShkQAAAVgCAUQgBAUgCATQgFAZgHAXQgIAWgIATIBfAAIAAjMIg+AAg");
  this.shape_15.setTransform(102.6, 139.325);
  this.shape_16 = new cjs.Shape();
  this.shape_16.graphics.f("#0C593C").s().p("AgiCYQgTgGgSgPQgYgXgLgiQgKghAAgpQAAgnAKgiQALgiAYgWQASgQATgFQASgFAQAAQASAAASAFQASAFASAQQAZAWAKAiQAKAiAAAnQAAApgKAhQgKAigZAXQgSAPgSAGQgSAEgSAAQgQAAgSgEgAgThqQgLADgLANQgIALgFAQQgGAQgCARQgCARAAANQAAAPACARQACAQAGAQQAFAQAIALQALANALAEQAKAEAJAAQAKAAAKgEQALgEALgNQAJgLAFgQQAFgQACgQQACgRAAgPQAAgNgCgRQgCgRgFgQQgFgQgJgLQgLgNgLgDQgKgFgKABIgBgBQgJAAgJAFg");
  this.shape_16.setTransform(77.1761, 135.9977);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_16
   }, {
    t: this.shape_15
   }, {
    t: this.shape_14
   }, {
    t: this.shape_13
   }, {
    t: this.shape_12
   }, {
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
 }).prototype = getMCSymbolPrototype(lib.t4, new cjs.Rectangle(62, 109.5, 269, 135.5), null);
 (lib.t3 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#0C593C").s().p("AgYCTIAAg5IAxAAIAAA5gAgNA3IgLhkIAAhlIAxAAIAABlIgLBkg");
  this.shape.setTransform(219.575, 154.15);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#0C593C").s().p("AgYBxQgMgCgMgHQgOgKgJgRQgIgRgBgUIAsAAQAAAHACAHQADAIAEAGQAGAIAIADQAIACAFAAIAJgBQAFgBAGgFQAGgDADgHQAEgHAAgLQAAgGgCgHQgCgGgHgFQgFgEgGgBIgLgBIgRAAIAAghIAOAAIAHgBQAGgBAGgEQAGgFADgHIABgMQAAgJgCgGQgDgHgEgDQgEgFgFgBQgFgCgEABQgGgBgGADQgHACgFAJQgEAHgBAHIgBALIgsAAQAAgPAFgOQAFgOAIgJQANgNAPgEQAQgEANAAQAMAAAQADQAPAEANAMQAIAIAEAMQAFAMAAAOQAAAKgDAJQgDAJgGAHQgFAFgEACQgFADgDAAIAAACQAGAAAGACQAHADAGAIQAHAIACAIQADAIAAAJQAAAPgEALQgEALgGAIQgFAHgGAEQgNAJgPADQgQADgNAAQgKAAgNgCg");
  this.shape_1.setTransform(204.675, 158.1969);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#0C593C").s().p("AgsBwQgIgCgIgFQgKgFgHgNQgIgOAAgVQAAgLACgJQADgKAFgIQAGgJAGgFQAIgEAJgDQAKgEALgBIAegGIAJgCQAGgBADgEIABgEQACgDgBgJQABgJgDgIQgDgIgFgGQgFgEgGgBQgEgBgDAAQgNAAgGAGQgIAGgCAGQgDAEgBAGIgBAMIgsAAQAAgLADgLQACgLAGgKQAJgOAMgHQALgGAMgCQANgDAKABQAJgBAPADQAOADAOAKQANALAFAPQAEAPAAATIAABUIABAQIACAGQACADADABIAIAAIAAAjIgLABIgNAAQgFABgHgCQgGgBgGgEQgEgEgCgGQgDgFgBgFIgBAAQgDAHgGAFIgGAHQgIAFgJADQgKADgNAAIgRgBgAAWAIIgEABIgJAEIgIACIgOAEQgGABgEADQgIAFgEAHQgCAHAAAIQAAAEABAGQABAGAFAGQADADAEACQAEACAGAAQAGAAAHgDQAGgEAHgJQAHgLADgNQACgOAAgMIAAgHIgDACg");
  this.shape_2.setTransform(186.55, 158.0208);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#0C593C").s().p("Ag+BrIAAjVIB9AAIAAAjIhPAAIAACyg");
  this.shape_3.setTransform(171.15, 158.175);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#0C593C").s().p("AABBzQgNAAgQgFQgQgFgPgQQgKgLgIgVQgIgUgBgjIACgZQABgQAGgQQAFgRALgOQAOgRASgGQARgGAOABQARgBARAHQASAIANAUQAKAPAEAXQAFAWABAhIh8AAQAAAMADAPQAEAOAGALQAIAJAHADQAIADAFAAQAFAAAIgCQAHgDAHgJQAEgEACgGQACgFAAgGIAtAAQgCANgGANQgGANgIAIQgPAPgQAEQgPAEgMAAIgDAAgAAmgVIAAgKQAAgHgCgIQgCgIgEgIQgGgJgIgFQgHgEgIAAQgIAAgHAFQgHAEgEAGQgHAJgDANQgCAMAAAKIBLAAIAAAAg");
  this.shape_4.setTransform(153.075, 158.2006);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#0C593C").s().p("AhNBrIgIgBIAAgiQALACAIgEQAHgEAFgHQACgGACgJQADgLABgTIABgyIAAhGICDAAIAADUIguAAIAAiyIgpAAIAAAoIgBAiIgBAWIgBANQgCAWgHANQgFAOgHAFQgJAIgKAEQgLAFgOAAIgIgBg");
  this.shape_5.setTransform(132.7, 158.25);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#0C593C").s().p("AAlBrIAAiYIhFCYIgyAAIAAjVIAuAAIAACYIBFiYIAyAAIAADVg");
  this.shape_6.setTransform(114.3, 158.175);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#0C593C").s().p("AgWBrIAAiyIg5AAIAAgjICfAAIAAAjIg5AAIAACyg");
  this.shape_7.setTransform(96.375, 158.175);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#0C593C").s().p("AgtBmQgTgNgLgZQgHgPgDgQQgDgRAAgQQAAgPADgRQADgRAHgPQALgZATgMQATgNAaAAQAaAAAUANQATAMALAZQAHAPADARQADARAAAPQAAAQgDARQgDAQgHAPQgLAZgTANQgUANgaAAQgaAAgTgNgAgShJQgHAGgFALQgEAIgCAKIgDAVIAAARIAAARIADAVQACAKAEAJQAFALAHAHQAIAFAKAAQALAAAHgFQAIgHAFgLQAEgJACgKIADgVIAAgRIAAgRIgDgVQgCgKgEgIQgFgLgIgGQgHgGgLgBQgKABgIAGg");
  this.shape_8.setTransform(78.825, 158.2);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#0C593C").s().p("ABRCTIAAjHIACggIgCAAIg+DnIgmAAIg9jnIgCAAIACAgIAADHIgxAAIAAklIBGAAIA7DeIA7jeIBHAAIAAElg");
  this.shape_9.setTransform(53.4, 154.15);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.f("#0C593C").s().p("AABBzQgNAAgQgFQgQgFgPgQQgKgLgIgVQgIgUgBgjIACgZQABgQAGgQQAFgRALgOQAOgRASgGQARgGAOABQARgBARAHQASAIANAUQAKAPAEAXQAFAWABAhIh8AAQAAAMADAPQAEAOAGALQAIAJAHADQAIADAFAAQAFAAAIgCQAHgDAHgJQAEgEACgGQACgFAAgGIAtAAQgCANgGANQgGANgIAIQgPAPgQAEQgPAEgMAAIgDAAgAAmgVIAAgKQAAgHgCgIQgCgIgEgIQgGgJgIgFQgHgEgIAAQgIAAgHAFQgHAEgEAGQgHAJgDANQgCAMAAAKIBLAAIAAAAg");
  this.shape_10.setTransform(234.125, 118.0506);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.f("#0C593C").s().p("AgWBrIAAiyIg5AAIAAgjICfAAIAAAjIg5AAIAACyg");
  this.shape_11.setTransform(216.825, 118.025);
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.f("#0C593C").s().p("AAlCTIAAiXIhFCXIgyAAIAAjUIAuAAIAACXIBFiXIAyAAIAADUgAgWhZQgJgDgGgEIgIgGQgGgFgGgLQgHgLgCgRIAlAAIACAKQACAFADAFQAFAGAGADQAHACAEgBQAFABAHgCQAGgDAEgGQAEgFACgFQACgFAAgFIAlAAQgCARgHALQgGALgGAFIgIAGQgGAEgJADQgJADgOAAQgNAAgJgDg");
  this.shape_12.setTransform(198.9, 114);
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.f("#0C593C").s().p("AgrBwQgJgCgIgFQgKgFgHgNQgIgOAAgVQAAgLACgJQACgKAGgIQAFgJAIgFQAHgEAJgDQAKgEAMgBIAcgGIAKgCQAFgBADgEIACgEQABgDAAgJQAAgJgCgIQgDgIgGgGQgEgEgGgBQgEgBgEAAQgMAAgHAGQgGAGgDAGQgCAEgBAGIgCAMIgsAAQAAgLADgLQADgLAGgKQAIgOALgHQAMgGAMgCQANgDAKABQAJgBAPADQAOADAOAKQANALAEAPQAFAPABATIAABUIABAQIABAGQACADADABIAHAAIAAAjIgKABIgNAAQgFABgHgCQgGgBgGgEQgEgEgDgGQgCgFgBgFIgBAAQgEAHgEAFIgIAHQgHAFgKADQgKADgMAAIgQgBgAAWAIIgDABIgJAEIgJACIgOAEQgGABgEADQgIAFgDAHQgEAHABAIQAAAEABAGQABAGAFAGQADADAEACQAFACAFAAQAGAAAHgDQAGgEAGgJQAIgLACgNQADgOAAgMIAAgHIgDACg");
  this.shape_13.setTransform(179.2, 117.8708);
  this.shape_14 = new cjs.Shape();
  this.shape_14.graphics.f("#0C593C").s().p("AA/BrIAAiHIACgVIgCAAIgtCcIgjAAIgticIgCAAIACAVIAACHIgtAAIAAjVIA8AAIAvCfIAwifIA8AAIAADVg");
  this.shape_14.setTransform(156.875, 118.025);
  this.shape_15 = new cjs.Shape();
  this.shape_15.graphics.f("#0C593C").s().p("AAlBrIAAiYIhGCYIgxAAIAAjVIAuAAIAACYIBGiYIAxAAIAADVg");
  this.shape_15.setTransform(133.7, 118.025);
  this.shape_16 = new cjs.Shape();
  this.shape_16.graphics.f("#0C593C").s().p("AAgBrIAAhfIg/AAIAABfIguAAIAAjVIAuAAIAABUIA/AAIAAhUIAuAAIAADVg");
  this.shape_16.setTransform(113.5, 118.025);
  this.shape_17 = new cjs.Shape();
  this.shape_17.graphics.f("#0C593C").s().p("AAlBrIAAiYIhGCYIgxAAIAAjVIAuAAIAACYIBGiYIAxAAIAADVg");
  this.shape_17.setTransform(93.3, 118.025);
  this.shape_18 = new cjs.Shape();
  this.shape_18.graphics.f("#0C593C").s().p("AhYCWIAAkiIArAAIAAAVIABAAIAIgKQAEgFAFgDQAHgFAJgDQAJgDAKAAQAPgBAOAHQAOAGAMAOQAMAQAGASQAFASACAPIABAUIgCAZIgFAaQgEAOgGALQgGAKgJAJQgJAJgMAGQgMAFgQABQgIAAgIgDQgIgCgHgFQgGgDgEgGQgFgFgDgEIgBAAIAABhgAgThsQgKAGgHARQgFAMgCAPQgCAOAAALIABARQABALADAKQACALAGALQAHAKAHAFQAIAEAIAAQAFABAIgEQAIgEAIgMQAFgIAEgOQAEgOAAgXQAAgMgBgNQgCgOgFgOQgIgRgJgGQgKgGgHAAIgBAAQgHAAgJAGg");
  this.shape_18.setTransform(73.075, 121.4982);
  this.shape_19 = new cjs.Shape();
  this.shape_19.graphics.f("#0C593C").s().p("AAuCTIAAj4IhcAAIAAD4IgxAAIAAklIC/AAIAAElg");
  this.shape_19.setTransform(50.025, 114);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_19
   }, {
    t: this.shape_18
   }, {
    t: this.shape_17
   }, {
    t: this.shape_16
   }, {
    t: this.shape_15
   }, {
    t: this.shape_14
   }, {
    t: this.shape_13
   }, {
    t: this.shape_12
   }, {
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
 }).prototype = getMCSymbolPrototype(lib.t3, new cjs.Rectangle(35.5, 87.5, 269, 95.30000000000001), null);
 (lib.t2_1_t2_office = function() {
  this.initialize(img.t2_1_t2_office);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 212, 81);
 (lib.t2_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_t2 = new lib.t2_1_t2_office();
  this.cvr_t2.name = "cvr_t2";
  this.cvr_t2.parent = this;
  this.cvr_t2.setTransform(334.75, 129, 0.5, 0.5);
  this.timeline.addTween(cjs.Tween.get(this.cvr_t2).wait(1));
  this.timeline.addTween(cjs.Tween.get(this.cvr_t2).wait(1));
 }).prototype = getMCSymbolPrototype(lib.t2_1, new cjs.Rectangle(332.8, 127, 215.99999999999994, 85.1), null);
 (lib.t2 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#0C593C").s().p("AAAANIgNAXIgKgIIAOgXIgVgIIAEgMIAUAIIAAgbIANAAIAAAbIAVgIIACAMIgUAIIANAXIgKAIg");
  this.shape.setTransform(148.8, 190.45);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#0C593C").s().p("AAjBmIAAiQIhCCQIgvAAIAAjLIAsAAIAACQIBCiQIAvAAIAADLg");
  this.shape_1.setTransform(131.875, 196.55);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#0C593C").s().p("AhJBmIgIgBIAAghQALACAHgDQAHgEAEgHQADgFACgKQACgKABgSIABgwIAAhCIB9AAIAADKIgsAAIAAiqIgoAAIAAAmIAAAhIgBAVIgBALQgCAWgGAMQgGANgGAGQgIAHgKAEQgKAEgNAAIgIAAg");
  this.shape_2.setTransform(112.15, 196.625);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#0C593C").s().p("AgrBhQgSgMgLgYQgGgOgDgQQgDgQAAgPQAAgOADgQQADgQAGgOQALgYASgMQATgMAYgBQAZABATAMQASAMALAYQAGAOADAQQADAQAAAOQAAAPgDAQQgDAQgGAOQgLAYgSAMQgTANgZAAQgYAAgTgNgAgRhGQgHAGgFAKQgDAJgCAJIgDAUIAAAQIAAAQIADAUQACAKADAIQAFALAHAGQAIAFAJABQAKgBAIgFQAHgGAFgLQADgIACgKIADgUIAAgQIAAgQIgDgUQgCgJgDgJQgFgKgHgGQgIgGgKAAQgJAAgIAGg");
  this.shape_3.setTransform(95.225, 196.55);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#0C593C").s().p("AgaCTQgMgEgJgGQgIgHgGgHQgLgOgFgSQgGgSgBgSQgCgSABgPQAAgfACgVQACgVADgMQACgMADgGQAFgPAKgLQAKgMAPgHQAKgEAMgCIAagEQAOgCAFgEQAFgEAAgFIAgAAIgCANIgDAMQgHAPgMAGQgMAGgQADIgcAGQgNAEgLAJQgKAIgFASIgEAOIgBAPIgBALIACAAQACgIAEgHQAEgIAFgHQAJgKAMgGQALgGAPAAQAQAAAMAGQAMAGAIAIQAKALAGAOQAHAPADAPQADAQAAAPQAAAUgFAUQgFAVgNARQgNARgRAHQgQAHgRAAQgPAAgMgFgAgMgZQgIAFgHANQgHAMgCAPQgDAOAAALQAAAKACAPQACAOAHANQAHAOAIAEQAIAEAGAAQAHAAAIgFQAIgEAGgNQAHgNACgOQACgPgBgKIAAgQQgBgKgCgKQgCgJgEgIQgGgMgIgEQgHgFgIAAIgBAAQgGAAgHAEg");
  this.shape_4.setTransform(76.2958, 192.325);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#0C593C").s().p("AAjBmIAAiQIhCCQIgvAAIAAjLIAsAAIAACQIBCiQIAvAAIAADLg");
  this.shape_5.setTransform(48.225, 196.55);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#0C593C").s().p("AAjBmIAAiRIhCCRIgvAAIAAjLIAsAAIAACQIBCiQIAvAAIAADLg");
  this.shape_6.setTransform(299.375, 156.85);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#0C593C").s().p("AAjBmIAAiRIhCCRIgvAAIAAjLIAsAAIAACQIBCiQIAvAAIAADLg");
  this.shape_7.setTransform(279.875, 156.85);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#0C593C").s().p("AAfBmIAAhbIg8AAIAABbIgtAAIAAjLIAtAAIAABRIA8AAIAAhRIAsAAIAADLg");
  this.shape_8.setTransform(260.9, 156.85);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#0C593C").s().p("AgpBqQgJgBgHgEQgJgGgIgMQgHgNgBgVQABgKACgJQACgJAFgIQAGgIAHgFQAHgDAIgEIAVgFIAbgFIAJgCQAGgBACgDIACgEQABgEAAgIQAAgJgCgHQgDgIgFgFQgFgEgFgBIgHgBQgMAAgGAGQgHAFgDAGIgDAKIgBALIgqAAQAAgKACgLQADgLAGgJQAIgNALgHQAKgGANgCQALgCAKAAQAJAAAOACQANADANAKQANAKAEAOQAFAOAAATIAABQIABAPIABAGQACADADABIAIAAIAAAhIgLABIgMAAQgFABgGgCQgHgBgFgEQgEgEgCgFIgEgKIgBAAQgDAHgFAFIgGAGQgIAFgIADQgKADgMAAQgHAAgIgCgAAVAIIgEABIgIADIgJACIgMAEQgGACgEACQgIAFgDAHQgDAGAAAIIABAJQACAGAEAFQADAEAEABQAEACAFAAQAGABAHgEQAFgDAHgJQAGgKADgNQADgNAAgLIAAgHIgDACg");
  this.shape_9.setTransform(242.9, 156.6958);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.f("#0C593C").s().p("AhJBmIAAjKIBYAAQAKgBAKADQALACAIAHQAJAJADAKQADAKgBAJQAAAKgCAIQgDAIgGAHQgFAHgGADIgJAEIAAABQAGABAGACQAGADAFAFQAGAFAEAJQAEAKAAAPQAAAQgFAKQgFAKgGAFQgGAGgKAEQgLAEgRAAgAgdBFIAbAAIAKgBQAGgBAEgDQAFgCADgGQADgFAAgJQAAgIgCgGQgDgFgDgDQgGgFgHgBIgLgBIgaAAgAgdgTIAYAAIAKgBQAGgBAEgEQAFgEACgGIACgKQAAgFgCgFQgCgGgGgDIgHgDIgIgBIgcAAg");
  this.shape_10.setTransform(225.575, 156.8458);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.f("#0C593C").s().p("AgrBhQgSgMgLgYQgGgOgDgQQgDgQAAgPQAAgOADgQQADgQAGgOQALgYASgNQATgLAYgBQAZABATALQASANALAYQAGAOADAQQADAQAAAOQAAAPgDAQQgDAQgGAOQgLAYgSAMQgTAMgZAAQgYAAgTgMgAgRhGQgHAGgFAKQgDAIgCAKIgDAUIAAAQIAAAQQABALACAJQACAKADAIQAFALAHAGQAIAFAJABQAKgBAIgFQAHgGAFgLQADgIACgKIADgUIAAgQIAAgQIgDgUQgCgKgDgIQgFgKgHgGQgIgGgKAAQgJAAgIAGg");
  this.shape_11.setTransform(206.975, 156.85);
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.f("#0C593C").s().p("AgWBsQgNgCgLgHQgOgJgHgRQgJgQAAgTIAqAAQAAAHACAHQACAHAEAGQAGAIAHACQAIACAFAAQACAAAGgBQAFgBAHgEQAEgEAEgGQADgHAAgKQABgGgCgGQgDgGgFgFQgGgEgGgBIgKgBIgQAAIAAgfIANAAIAHgBQAFgBAGgEQAGgFACgGQACgHAAgFQAAgIgCgGQgDgGgEgEQgEgEgFgBIgIgCQgGAAgGADQgGACgFAIQgEAHgBAGIgBALIgqAAQABgOAEgNQAFgNAIgJQAMgNAOgEQAPgEANABQAMgBAOAEQAPADAMAMQAHAIAFALQAFALgBAOQABAJgDAJQgDAIgGAHQgFAFgEACIgIADIAAABQAGAAAGACQAHADAGAIQAGAHADAIQACAHAAAJQAAAPgEAKQgDALgGAHQgGAGgFAEQgNAJgOADQgPADgMAAIgVgCg");
  this.shape_12.setTransform(189, 156.8469);
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.f("#0C593C").s().p("AgpBqQgJgBgHgEQgKgGgHgMQgHgNgBgVQAAgKADgJQACgJAGgIQAFgIAHgFQAGgDAKgEIAUgFIAbgFIAJgCQAFgBADgDIABgEQACgEAAgIQAAgJgDgHQgBgIgHgFQgFgEgFgBIgHgBQgLAAgHAGQgGAFgDAGIgDAKIgBALIgqAAQAAgKACgLQADgLAFgJQAJgNALgHQALgGAMgCQALgCAKAAQAIAAAPACQANADANAKQANAKAFAOQAEAOAAATIAABQIABAPIABAGQACADADABIAIAAIAAAhIgKABIgNAAQgFABgHgCQgFgBgGgEQgEgEgCgFIgDgKIgBAAQgEAHgEAFIgHAGQgIAFgIADQgKADgMAAQgHAAgIgCgAAVAIIgDABIgJADIgIACIgOAEQgFACgEACQgIAFgDAHQgCAGAAAIIABAJQABAGAEAFQADAEAEABQAEACAFAAQAGABAHgEQAFgDAHgJQAGgKADgNQADgNAAgLIAAgHIgDACg");
  this.shape_13.setTransform(172, 156.6958);
  this.shape_14 = new cjs.Shape();
  this.shape_14.graphics.f("#0C593C").s().p("AhUCPIAAkUIApAAIAAAUIABAAQADgGAFgEIAJgIQAGgEAIgDQAJgDAKAAQAOgBANAGQAOAHALANQAMAPAFARQAFARABAOIACAUIgCAXQgBAMgEANQgEANgFALQgGAKgIAIQgJAJgMAFQgLAGgPAAQgIAAgHgDQgIgCgHgEQgFgEgFgFQgEgEgDgFIgBAAIAABdgAAKApQAIgEAHgLQAGgIADgOQAEgMAAgWIgBgZQgCgNgFgNQgHgQgJgGQgJgGgHAAQgHAAgJAGQgJAGgHAQQgFAMgCANIgCAZIABAQQABAKADAKQACAKAGAKQAGAKAHAFQAIAEAHAAQAFAAAHgDg");
  this.shape_14.setTransform(153.675, 160.1481);
  this.shape_15 = new cjs.Shape();
  this.shape_15.graphics.f("#0C593C").s().p("AgaCTQgMgEgJgGQgIgHgGgHQgLgOgFgSQgGgSgBgSQgCgSABgPQAAgfACgVQACgVADgMQACgMADgGQAFgPAKgLQAKgMAPgHQAKgEAMgCIAagEQAOgCAFgEQAFgEAAgFIAgAAIgCANIgDAMQgHAPgMAGQgMAGgQADIgcAGQgNAEgLAJQgKAIgFASIgEAOIgBAPIgBALIACAAQACgIAEgHQAEgIAFgHQAJgKAMgGQALgGAPAAQAQAAAMAGQAMAGAIAIQAKALAGAOQAHAPADAPQADAQAAAPQAAAUgFAUQgFAVgNARQgNARgRAHQgQAHgRAAQgPAAgMgFgAgMgZQgIAFgHANQgHAMgCAPQgDAOAAALQAAAKACAPQACAOAHANQAHAOAIAEQAIAEAGAAQAHAAAIgFQAIgEAGgNQAHgNACgOQACgPgBgKIAAgQQgBgKgCgKQgCgJgEgIQgGgMgIgEQgHgFgIAAIgBAAQgGAAgHAEg");
  this.shape_15.setTransform(133.8458, 152.625);
  this.shape_16 = new cjs.Shape();
  this.shape_16.graphics.f("#0C593C").s().p("AgrBhQgSgMgLgYQgGgOgDgQQgDgQAAgPQAAgOADgQQADgQAGgOQALgYASgNQATgLAYgBQAZABATALQASANALAYQAGAOADAQQADAQAAAOQAAAPgDAQQgDAQgGAOQgLAYgSAMQgTAMgZAAQgYAAgTgMgAgRhGQgHAGgFAKQgDAIgCAKIgDAUIAAAQIAAAQIADAUQACAKADAIQAFALAHAGQAIAFAJABQAKgBAIgFQAHgGAFgLQADgIACgKIADgUIAAgQIAAgQIgDgUQgCgKgDgIQgFgKgHgGQgIgGgKAAQgJAAgIAGg");
  this.shape_16.setTransform(114.475, 156.85);
  this.shape_17 = new cjs.Shape();
  this.shape_17.graphics.f("#0C593C").s().p("AgrBhQgSgMgLgYQgGgOgDgQQgDgQAAgPQAAgOADgQQADgQAGgOQALgYASgNQATgLAYgBQAZABATALQASANALAYQAGAOADAQQADAQAAAOQAAAPgDAQQgDAQgGAOQgLAYgSAMQgTAMgZAAQgYAAgTgMgAgRhGQgHAGgFAKQgDAIgCAKIgDAUIAAAQIAAAQIADAUQACAKADAIQAFALAHAGQAIAFAJABQAKgBAIgFQAHgGAFgLQADgIACgKIADgUIAAgQIAAgQIgDgUQgCgKgDgIQgFgKgHgGQgIgGgKAAQgJAAgIAGg");
  this.shape_17.setTransform(95.725, 156.85);
  this.shape_18 = new cjs.Shape();
  this.shape_18.graphics.f("#0C593C").s().p("AgWBsQgMgCgMgHQgOgJgHgRQgJgQAAgTIAqAAQAAAHACAHQACAHAEAGQAGAIAIACQAHACAFAAQACAAAGgBQAFgBAHgEQAEgEADgGQAEgHABgKQAAgGgCgGQgCgGgGgFQgGgEgGgBIgKgBIgRAAIAAgfIAOAAIAHgBQAGgBAFgEQAGgFACgGQACgHAAgFQAAgIgCgGQgDgGgEgEQgEgEgFgBIgIgCQgGAAgGADQgGACgFAIQgDAHgCAGIgBALIgqAAQABgOAFgNQAEgNAIgJQAMgNAOgEQAPgEANABQAMgBAOAEQAPADAMAMQAHAIAFALQAEALAAAOQABAJgDAJQgDAIgGAHQgFAFgEACIgHADIAAABQAFAAAGACQAHADAGAIQAGAHADAIQACAHAAAJQgBAPgDAKQgEALgFAHQgFAGgGAEQgMAJgPADQgOADgNAAIgVgCg");
  this.shape_18.setTransform(77.75, 156.8469);
  this.shape_19 = new cjs.Shape();
  this.shape_19.graphics.f("#0C593C").s().p("AgpBqQgJgBgHgEQgKgGgHgMQgHgNgBgVQAAgKADgJQACgJAFgIQAGgIAHgFQAGgDAKgEIAUgFIAbgFIAJgCQAGgBACgDIACgEQABgEAAgIQAAgJgCgHQgDgIgGgFQgEgEgFgBIgIgBQgLAAgHAGQgGAFgDAGIgDAKIgBALIgqAAQAAgKACgLQADgLAFgJQAJgNALgHQAKgGANgCQALgCAKAAQAIAAAPACQANADANAKQANAKAFAOQAEAOAAATIAABQIABAPIABAGQACADADABIAIAAIAAAhIgKABIgNAAQgFABgGgCQgGgBgGgEQgEgEgCgFIgDgKIgCAAQgDAHgEAFIgHAGQgIAFgIADQgKADgMAAQgHAAgIgCgAAVAIIgEABIgIADIgIACIgOAEQgFACgEACQgIAFgDAHQgDAGAAAIIACAJQABAGAEAFQADAEAEABQAEACAFAAQAGABAHgEQAFgDAHgJQAGgKADgNQADgNAAgLIAAgHIgDACg");
  this.shape_19.setTransform(60.75, 156.6958);
  this.shape_20 = new cjs.Shape();
  this.shape_20.graphics.f("#0C593C").s().p("Ag7BmIAAjLIB3AAIAAAhIhLAAIAACqg");
  this.shape_20.setTransform(46.3, 156.85);
  this.shape_21 = new cjs.Shape();
  this.shape_21.graphics.f("#0C593C").s().p("AgVAfQADAAAFgCQAEgCAEgHQAEgHAAgNIAAgEIgUAAIAAg2IAqAAIAAA4QABALgDANQgDANgLALQgFAFgGADQgHADgIACg");
  this.shape_21.setTransform(237.2536, 127.775);
  this.shape_22 = new cjs.Shape();
  this.shape_22.graphics.f("#0C593C").s().p("AAjBlIAAiQIhCCQIgvAAIAAjJIAsAAIAACPIBCiPIAvAAIAADJg");
  this.shape_22.setTransform(222.375, 117.15);
  this.shape_23 = new cjs.Shape();
  this.shape_23.graphics.f("#0C593C").s().p("AAjBlIAAiQIhCCQIgvAAIAAjJIAsAAIAACPIBCiPIAvAAIAADJg");
  this.shape_23.setTransform(202.875, 117.15);
  this.shape_24 = new cjs.Shape();
  this.shape_24.graphics.f("#0C593C").s().p("AgVBlIAAipIg2AAIAAggICXAAIAAAgIg2AAIAACpg");
  this.shape_24.setTransform(186.05, 117.15);
  this.shape_25 = new cjs.Shape();
  this.shape_25.graphics.f("#0C593C").s().p("AgfCLIgMAAIgNgCIAAghIAHACIAHABQALgBAGgGQAGgHADgMIAFgRIhLjKIAwAAIAtCTIACAAIAkiTIApAAIg9DbIgGAUQgEAMgHAKQgIAJgJAEQgIADgLAAIgDAAg");
  this.shape_25.setTransform(170.75, 120.9278);
  this.shape_26 = new cjs.Shape();
  this.shape_26.graphics.f("#0C593C").s().p("AA+CAIAAg1Ih6AAIAAA1IgnAAIgDhWIAXAAIAIgRIAGgUQAJgbABgYQACgXAAgWIAAgkICAAAIAACpIAcAAIgEBWgAgNhFIgBAbIgEAZQgCAQgFAOIgLAdIBDAAIAAiIIgsAAg");
  this.shape_26.setTransform(152.8, 119.775);
  this.shape_27 = new cjs.Shape();
  this.shape_27.graphics.f("#0C593C").s().p("AgWBsQgNgCgLgHQgNgJgIgRQgJgQAAgTIAqAAQAAAHACAHQACAHAEAGQAHAIAGACQAIACAFAAQADAAAFgBQAFgBAHgEQAEgEAEgGQADgHAAgKQAAgGgBgGQgDgGgFgFQgGgEgGgBIgKgBIgQAAIAAgfIAMAAIAIgBQAFgBAGgEQAHgFABgGQACgHAAgFQAAgIgDgGQgCgGgEgEQgEgEgFgBIgIgCQgGAAgGADQgGACgFAIQgEAHgBAGIgBALIgpAAQAAgOAEgNQAFgNAIgJQALgNAPgEQAQgEAMABQAMgBAOAEQAPADAMAMQAIAIAEALQAFALgBAOQAAAJgCAJQgDAIgHAHQgEAFgEACIgIADIAAABQAGAAAHACQAGADAGAIQAGAHADAIQACAHAAAJQgBAPgDAKQgDALgGAHQgGAGgFAEQgNAJgOADQgPADgMAAIgVgCg");
  this.shape_27.setTransform(134.65, 117.1469);
  this.shape_28 = new cjs.Shape();
  this.shape_28.graphics.f("#0C593C").s().p("AhJBmIAAjKIBYAAQAKgBAKADQALACAIAHQAJAJADAKQADAKgBAJQAAAKgCAIQgDAIgGAHQgFAHgGADIgJAEIAAABQAGABAGACQAGADAFAFQAGAFAEAJQAEAKAAAPQAAAQgFAKQgFAKgGAFQgGAGgKAEQgLAEgRAAgAgdBFIAbAAIAKgBQAGgBAEgDQAFgCADgGQADgFAAgJQAAgIgCgGQgDgFgDgDQgGgFgHgBIgLgBIgaAAgAgdgTIAYAAIAKgBQAGgBAEgEQAFgEACgGIACgKQAAgFgCgFQgCgGgGgDIgHgDIgIgBIgcAAg");
  this.shape_28.setTransform(118.025, 117.1458);
  this.shape_29 = new cjs.Shape();
  this.shape_29.graphics.f("#0C593C").s().p("AAjBlIAAiQIhCCQIgvAAIAAjJIAsAAIAACPIBCiPIAvAAIAADJg");
  this.shape_29.setTransform(90.725, 117.15);
  this.shape_30 = new cjs.Shape();
  this.shape_30.graphics.f("#0C593C").s().p("AhUCPIAAkUIApAAIAAAUIABAAQADgGAFgEIAJgIQAGgEAIgDQAJgDAKAAQAOgBANAGQAOAHALANQAMAPAFARQAFARABAOIACAUIgCAXQgBAMgEANQgEANgFALQgGAKgIAIQgJAJgMAFQgLAGgPAAQgIAAgHgDQgIgCgHgEQgFgEgFgFQgEgEgDgFIgBAAIAABdgAAKApQAIgEAHgLQAGgIADgOQAEgMAAgWIgBgZQgCgNgFgNQgHgQgJgGQgJgGgHAAQgHAAgJAGQgJAGgHAQQgFAMgCANIgCAZIABAQQABAKADAKQACAKAGAKQAGAKAHAFQAIAEAHAAQAFAAAHgDg");
  this.shape_30.setTransform(71.625, 120.4481);
  this.shape_31 = new cjs.Shape();
  this.shape_31.graphics.f("#0C593C").s().p("AAtCMIAAjsIhYAAIAADsIgvAAIAAkXIC1AAIAAEXg");
  this.shape_31.setTransform(49.9, 113.3);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_31
   }, {
    t: this.shape_30
   }, {
    t: this.shape_29
   }, {
    t: this.shape_28
   }, {
    t: this.shape_27
   }, {
    t: this.shape_26
   }, {
    t: this.shape_25
   }, {
    t: this.shape_24
   }, {
    t: this.shape_23
   }, {
    t: this.shape_22
   }, {
    t: this.shape_21
   }, {
    t: this.shape_20
   }, {
    t: this.shape_19
   }, {
    t: this.shape_18
   }, {
    t: this.shape_17
   }, {
    t: this.shape_16
   }, {
    t: this.shape_15
   }, {
    t: this.shape_14
   }, {
    t: this.shape_13
   }, {
    t: this.shape_12
   }, {
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
 }).prototype = getMCSymbolPrototype(lib.t2, new cjs.Rectangle(36, 88, 274.9, 138), null);
 (lib.t1_t1_office = function() {
  this.initialize(img.t1_t1_office);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 243, 86);
 (lib.t1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_t1 = new lib.t1_t1_office();
  this.cvr_t1.name = "cvr_t1";
  this.cvr_t1.parent = this;
  this.cvr_t1.setTransform(41, 86, 0.5, 0.5);
  this.timeline.addTween(cjs.Tween.get(this.cvr_t1).wait(1));
  this.timeline.addTween(cjs.Tween.get(this.cvr_t1).wait(1));
 }).prototype = getMCSymbolPrototype(lib.t1, new cjs.Rectangle(39, 84, 247, 94), null);
 (lib.packshot_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.packshot();
  this.instance.parent = this;
  this.instance.setTransform(254, -216, 0.741, 0.741);
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));
 }).prototype = getMCSymbolPrototype(lib.packshot_1, new cjs.Rectangle(254, -216, 260.79999999999995, 126), null);
 (lib.orange = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#0C593C").s().p("AAAAJIgJAQIgGgGIAJgPIgPgFIACgJIAQAFIAAgTIAIAAIAAATIAPgFIACAJIgPAFIAJAPIgHAGg");
  this.shape.setTransform(109.25, 45.6);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#FFFFFF").s().p("AgNBUIAAggIAcAAIAAAggAgHAgIgGg5IAAg6IAcAAIAAA6IgHA5g");
  this.shape_1.setTransform(98.8, 53.25);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#FFFFFF").s().p("AAjBUIgKgjIgxAAIgKAjIgdAAIAzinIAaAAIAyCngAATAYIgThIIgRBIIAkAAg");
  this.shape_2.setTransform(89.825, 53.25);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#FFFFFF").s().p("AAXBUIgyhUIAABUIgdAAIAAinIAdAAIAABJIAvhJIAgAAIg1BNIA6Bag");
  this.shape_3.setTransform(78.7, 53.25);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#FFFFFF").s().p("AAbBUIAAhMIg1AAIAABMIgcAAIAAinIAcAAIAABDIA1AAIAAhDIAcAAIAACng");
  this.shape_4.setTransform(64.975, 53.25);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#FFFFFF").s().p("AAcBUIAAh5Ig4B5IgcAAIAAinIAdAAIAAB5IA4h5IAcAAIAACng");
  this.shape_5.setTransform(51.25, 53.25);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#FFFFFF").s().p("Ag3BUIAAinIA/AAQAHAAAJACQAIACAHAIQAHAHACAIQACAIAAAHQAAAHgCAHQgCAHgGAHIgFAFIgIADIAAABIAJADIAIAFQAEAEAEAIQADAIAAANQABAIgDAJQgCAKgJAJQgGAFgGADQgHACgGABIgLAAgAgaA7IAaAAIALgBQAFgBAEgEQAEgEABgFIABgKIgBgJQgBgFgEgEQgEgEgFgBQgFgCgGABIgaAAgAgagOIAaAAIAHgBQAFgBAEgEIADgGQACgDAAgGIgBgIQgBgFgDgDQgDgEgFgBQgEgCgFAAIgZAAg");
  this.shape_6.setTransform(38.0042, 53.2458);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#FFFFFF").s().p("AAABZQgJABgKgDQgLgDgKgKQgOgNgGgSQgGgUAAgXQAAgWAGgUQAGgSAOgNQAKgKALgCQAKgEAJABQAKgBAKAEQALACAKAKQAOANAGASQAGAUAAAWQAAAXgGAUQgGASgOANQgKAKgLADQgIACgJAAIgDAAgAAMA9QAGgBAGgIQAFgGADgKQADgIABgKIABgSIgBgRQgBgJgDgKQgDgJgFgGQgGgIgGgCQgGgCgGAAQgEAAgGACQgHACgGAIQgFAGgDAJQgDAKgBAJIgBARIABASQABAKADAIQADAKAFAGQAGAIAHABQAGADAEgBQAGABAGgDg");
  this.shape_7.setTransform(24.075, 53.25);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#FFFFFF").s().p("AAbBUIAAhMIg1AAIAABMIgcAAIAAinIAcAAIAABDIA1AAIAAhDIAcAAIAACng");
  this.shape_8.setTransform(10.175, 53.25);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#E07E22").s().p("Al2FvQibiXAAjYQAAjXCbiYQCbiYDbAAQDcAACbCYQCbCYAADXQAADYibCXQibCZjcAAQjbAAibiZg");
  this.shape_9.setTransform(50.975, 52);
  this.timeline.addTween(cjs.Tween.get(this.shape_9).wait(1));
 }).prototype = getMCSymbolPrototype(lib.orange, new cjs.Rectangle(-2, 0, 117.6, 104), null);
 (lib.logo = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#FFFFFF").s().p("AgjAxIAShhIA1AAIgCAPIgkAAIgFAZIAiAAIgDANIgiAAIgFAdIAmAAIgDAPg");
  this.shape.setTransform(547.8741, 50.8705, 0.7393, 0.7386);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#FFFFFF").s().p("AgZAxIAQhSIgbAAIADgPIBGAAIgDAPIgbAAIgPBSg");
  this.shape_1.setTransform(542.5694, 50.8705, 0.7393, 0.7386);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#FFFFFF").s().p("AglAxIAShfQAIgCAPAAQAQAAAJAGQAJAIAAAMQAAARgNAIQgLAJgSAAIgJAAIgHAlgAgFgiIgGAhIAJABQAKAAAGgGQAHgGAAgIQAAgPgRAAg");
  this.shape_2.setTransform(535.9708, 50.8521, 0.7393, 0.7386);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#FFFFFF").s().p("AgjAmQgJgLAAgRQAAgbARgSQAPgOATAAQATAAAKAMQAJAKAAASQAAAcgRARQgNAOgVAAQgSAAgLgMgAgRgUQgJAOAAAPQAAAbAWAAIABAAQAMAAAKgPQAJgOAAgPQAAgbgXAAQgNAAgJAPg");
  this.shape_3.setTransform(529.0211, 50.8705, 0.7393, 0.7386);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#FFFFFF").s().p("AgRA1IABgJQgNgDgIgJQgLgKABgQQAAgYAQgOQAOgMARAAIACgIIAQAAIgCAJQAOACAJAJQAJAKABARQAAAXgQAOQgNAMgUAAIgBAJgAACAgQANgBAIgKQAJgLAAgQQAAgWgSgDgAgVgVQgJALAAAPQAAALAEAHQAGAHAHABIAMg/QgLABgJAKg");
  this.shape_4.setTransform(520.9439, 50.8705, 0.7393, 0.7386);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#005942").s().p("AhzBhQgggkAOg9QAPg5AtglQAugkA6AAQA4AAAdAiQAgAlgOA7QgQA/gyAkQgtAfg2AAQg3AAgdghgAgkg2QgXAXgIAiQgKAoATAXQAOAQAXAAQAdAAAZgYQAagZAJgjQAEgRgCgQQgCgUgKgMQgMgNgXAAQgiAAgZAag");
  this.shape_5.setTransform(421.491, 32.5521, 0.7486, 0.7479);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#80BC1E").s().p("AguA0QgPgRAIgjQACAZAOAJQAOAJASgIQAsgVALhLQAHAKAAATQAAAKgDAMIgCAIQgFAMgGAKQgLATgRAMQgPALgSAAQgRAAgJgKg");
  this.shape_6.setTransform(421.4617, 33.0008, 0.7486, 0.7479);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#80BC1E").s().p("AhNBxQgZgVAAgnIAAgJIA3AAIAAAEQAAATAMAKQALALAUgBQASAAALgKQAMgLABgWQAAgHgEgGQgDgGgFgCIgMgEQgGgCgIAAIgSAAIAIgpIALAAIAPgDQAJgBAGgEQAGgEAEgHQAFgIAAgKQAAgZggAAQgPAAgMAIQgLAHgFAVIg3AAQAEgYAJgQQAJgQAOgJQAPgKASgEQASgFAVABQAWgBAPAGQAOAEAKAKQAKAJAEAMQAEAKAAAQQAAAKgDAJQgEALgFAHQgEAGgJAHQgIAGgHACQAPACAKAOQAKAOAAAVQAAAXgHARQgJARgOAMQgOALgUAHQgTAFgXAAQgtAAgYgVg");
  this.shape_7.setTransform(544.0994, 32.6026, 0.7364, 0.7357);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#80BC1E").s().p("AhGCBQgNgFgJgKQgJgIgEgNQgEgKAAgPQAAgmAVgWQAWgUAngHIAkgEQAPgBALgEQALgDAEgGQAFgGAAgNQAAgKgEgFQgEgHgFgDQgGgDgGgBIgNgBQgPgBgMAKQgNAIgDAUIg4AAQADgZAKgPQAJgPAOgLQAQgLAQgDQAQgFASABQANAAASACQAOACAPAIQAOAHAIANQAJAOgBAVQAAARgEAaIgUBlIgCAjQAAAHACAIIg8AAIAAgZQgMAQgRAIQgRAHgTAAQgRABgOgGgAATAPIgZACIgRAEQgJADgFAEQgFADgEAJQgEAHAAAMQAAAPAKAGQAKAIAMAAQAOAAAJgFQAJgGAHgIQAEgFAGgNQAEgLACgKIAGgZQgMAJgMABg");
  this.shape_8.setTransform(527.0362, 32.6026, 0.7364, 0.7357);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#80BC1E").s().p("AhnCAIAvj/ICgAAIgKA1IhkAAIglDKg");
  this.shape_9.setTransform(512.1197, 32.621, 0.7364, 0.7357);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.f("#005942").s().p("AgrB8QgUgIgPgTQgPgSgGgYQgIgZAAgdQAAgdAIgYQAHgZAPgRQAPgSAUgLQAUgLAYABQAagBAUAMQAUALANATQAOAVAGAXQAHAZAAAbIgBANIibAAQABAiANAQQAOAPAZAAQARAAANgLQAOgKADgMIA0AAQgNAugaATQgaAVglgBQgYAAgVgKgAgXhLQgJAHgFAHQgGAJgCAJQgCAGgBALIBgAAQgEgcgLgNQgLgOgWAAQgNAAgKAGg");
  this.shape_10.setTransform(495.016, 32.6026, 0.7364, 0.7357);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.f("#005942").s().p("AhXCBIgagEIAAg2IAJACIAKAAQAOAAAHgPIADgKIADgaQACgWAAggQABgYAAhJICyAAIAAD/Ig7AAIAAjKIg9AAIgBBDIgDAxQgCASgDASQgFAQgEAHQgHAOgNAIQgOAJgUAAg");
  this.shape_11.setTransform(475.4084, 32.7681, 0.7364, 0.7357);
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.f("#005942").s().p("AAuCAIAAisIhRCsIhDAAIAAj/IA5AAIAACsIBRisIBDAAIAAD/g");
  this.shape_12.setTransform(456.8503, 32.621, 0.7364, 0.7357);
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.f("#005942").s().p("AgdCAIAAjKIhHAAIAAg1IDJAAIAAA1IhHAAIAADKg");
  this.shape_13.setTransform(439.1206, 32.621, 0.7364, 0.7357);
  this.shape_14 = new cjs.Shape();
  this.shape_14.graphics.f("#005942").s().p("ABkCwIAAj5IgBAAIhJD5IgzAAIhJj2IgBAAIAAD2Ig+AAIAAlgIBdAAIBFDyIABAAIBDjyIBdAAIAAFgg");
  this.shape_14.setTransform(397.8434, 29.0346, 0.7364, 0.7357);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_14
   }, {
    t: this.shape_13
   }, {
    t: this.shape_12
   }, {
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
  this.shape_15 = new cjs.Shape();
  this.shape_15.graphics.lf(["#FFFFFF", "#F27E20"], [0.612, 0.765], -158.7, -1.5, 44.4, -1.5).s().p("Am1BCIAAiDINqAEIAAB/g");
  this.shape_15.setTransform(536.25, 51.375);
  this.timeline.addTween(cjs.Tween.get(this.shape_15).wait(1));
  this.shape_16 = new cjs.Shape();
  this.shape_16.graphics.f("#FFFFFF").s().p("Al8EhQi6gFhigXQhzgciDg4QkQh0iPlfMApbAAAIAAJDIz6AAQh+AChuAAQhpAAhbgCg");
  this.shape_16.setTransform(447.35, 29.1295);
  this.timeline.addTween(cjs.Tween.get(this.shape_16).wait(1));
 }).prototype = getMCSymbolPrototype(lib.logo, new cjs.Rectangle(314.7, 0, 265.3, 58.3), null);
 (lib.l4 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#0C593C").s().p("AgHAJIAAgRIAQAAIAAARg");
  this.shape.setTransform(520.05, -11.3);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#0C593C").s().p("AATA0IAAgxIgkAAIAAAxIgPAAIAAhnIAPAAIAAArIAkAAIAAgrIAOAAIAABng");
  this.shape_1.setTransform(513.525, -15.55);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#0C593C").s().p("AgTAxQgIgEgFgNQgEgMAAgUQAAgaAJgOQAJgOASAAQAlAAAAA2QAAAUgEAMQgEANgJAEQgIAGgMAAQgLAAgIgGgAgMglQgEAEgDAJQgCAKAAAPQAAANACAJQACAJAFAFQAFAGAHgBQAJAAAEgEQAFgFACgKQACgIAAgOQAAgPgCgKQgCgJgFgEQgFgEgIgBQgHABgFAEg");
  this.shape_2.setTransform(504.675, -15.55);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#0C593C").s().p("AARA0IgZg0IgLAPIAAAlIgPAAIAAhnIAPAAIAAAwIAjgwIASAAIghAoIAiA/g");
  this.shape_3.setTransform(496.975, -15.55);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#0C593C").s().p("AATA0IAAhOIADgNIgEANIgiBOIgSAAIAAhnIAQAAIAABOIgCAMIADgMIAihOIARAAIAABng");
  this.shape_4.setTransform(487.95, -15.55);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#0C593C").s().p("AgGA0IAAhbIgcAAIAAgMIBFAAIAAAMIgbAAIAABbg");
  this.shape_5.setTransform(480.125, -15.55);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#0C593C").s().p("AgRAxQgHgEgEgNQgEgMAAgUQAAg2AgAAQAOAAAIAIQAHAIACAMQACALAAAQIgyAAIACAXQABAJAEAFQAEAEAHAAQARAAAAgZIAPAAQAAALgDAJQgEAIgHAFQgHAFgKAAQgLAAgIgGgAgNghQgEAKAAANIAiAAQABgPgEgIQgDgIgLgBQgJAAgEAJg");
  this.shape_6.setTransform(472.85, -15.55);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#0C593C").s().p("AAgA0IAAhbIgbBbIgJAAIgahbIAABbIgPAAIAAhnIAXAAIATBEIADAVIAEgVIAThEIAXAAIAABng");
  this.shape_7.setTransform(463.325, -15.55);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#0C593C").s().p("AATA0IAAhOIACgNIgDANIgiBOIgSAAIAAhnIAQAAIAABOIgCAMIADgMIAihOIASAAIAABng");
  this.shape_8.setTransform(453.2, -15.55);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#0C593C").s().p("AgUAvQgIgHgCgLQgDgMAAgPQAAg4AkAAQAPAAAHAKQAJAKAAAQIgOAAQAAgYgSAAQgLAAgEAMQgEAMgBAUQAAARAFAMQADAMALgBQALAAADgGQAEgIABgNIAOAAQAAASgIALQgHALgQAAQgPAAgIgIg");
  this.shape_9.setTransform(444.85, -15.55);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.f("#0C593C").s().p("AguAHIAAgNIBdAAIAAANg");
  this.shape_10.setTransform(432.275, -16.15);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.f("#0C593C").s().p("AgTAxQgIgEgFgNQgEgMAAgUQAAgaAJgOQAJgOASAAQAlAAAAA2QAAAUgEAMQgEANgJAEQgIAGgMAAQgLAAgIgGgAgMglQgEAEgDAJQgCAKAAAPQAAANACAJQACAJAFAFQAFAGAHgBQAJAAAEgEQAFgFACgKQACgIAAgOQAAgPgCgKQgCgJgFgEQgFgEgIgBQgHABgFAEg");
  this.shape_11.setTransform(419.225, -15.55);
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.f("#0C593C").s().p("AgfA0IAAhnIAhAAQAMAAAIAHQAIAGAAAMQAAAJgFAHQgEAGgHACIAAABQAJABAEAGQAFAHAAAKQAAAJgDAHQgEAGgGADQgGAEgGAAgAgQAoIAQAAQAKAAAEgEQADgFAAgKQAAgJgEgEQgEgEgIAAIgRAAgAgQgHIAPAAQAIAAAEgFQAEgDAAgJQAAgPgPAAIgQAAg");
  this.shape_12.setTransform(411.075, -15.55);
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.f("#0C593C").s().p("AgGA0IAAhbIgcAAIAAgMIBFAAIAAAMIgbAAIAABbg");
  this.shape_13.setTransform(403.475, -15.55);
  this.shape_14 = new cjs.Shape();
  this.shape_14.graphics.f("#0C593C").s().p("AgTAvQgJgHgCgLQgDgMAAgPQAAg4AjAAQAPAAAJAKQAIAKAAAQIgOAAQAAgYgSAAQgLAAgEAMQgFAMABAUQAAARADAMQAEAMALgBQALAAAEgGQADgIABgNIAOAAQAAASgHALQgJALgQAAQgOAAgHgIg");
  this.shape_14.setTransform(396.3, -15.55);
  this.shape_15 = new cjs.Shape();
  this.shape_15.graphics.f("#0C593C").s().p("AgRAxQgHgEgEgNQgEgMAAgUQAAg2AgAAQAPAAAGAIQAIAIACAMQACALAAAQIgyAAIABAXQACAJAEAFQAEAEAHAAQARAAAAgZIAPAAQAAALgEAJQgDAIgHAFQgHAFgLAAQgKAAgIgGgAgNghQgDAKgBANIAiAAQAAgPgDgIQgDgIgLgBQgKAAgDAJg");
  this.shape_15.setTransform(388.4, -15.55);
  this.shape_16 = new cjs.Shape();
  this.shape_16.graphics.f("#0C593C").s().p("AAwBCIAAgcIhsAAIAAhnIAPAAIAABaIAiAAIAAhaIAOAAIAABaIAhAAIAAhaIAPAAIAABaIAKAAIAAApg");
  this.shape_16.setTransform(378.325, -14.125);
  this.shape_17 = new cjs.Shape();
  this.shape_17.graphics.f("#0C593C").s().p("AgRAxQgHgEgEgNQgEgMAAgUQAAg2AgAAQAOAAAIAIQAHAIACAMQACALAAAQIgyAAIACAXQABAJAEAFQAEAEAHAAQARAAAAgZIAPAAQAAALgDAJQgEAIgHAFQgHAFgKAAQgLAAgIgGgAgNghQgEAKAAANIAiAAQABgPgEgIQgDgIgLgBQgJAAgEAJg");
  this.shape_17.setTransform(367.1, -15.55);
  this.shape_18 = new cjs.Shape();
  this.shape_18.graphics.f("#0C593C").s().p("AgfA0IAAhnIAhAAQAMAAAIAHQAIAGAAAMQAAAJgFAHQgEAGgHACIAAABQAJABAEAGQAFAHAAAKQAAAJgDAHQgEAGgGADQgGAEgGAAgAgQAoIAQAAQAKAAAEgEQADgFAAgKQAAgJgEgEQgEgEgIAAIgRAAgAgQgHIAPAAQAIAAAEgFQAEgDAAgJQAAgPgPAAIgQAAg");
  this.shape_18.setTransform(359.525, -15.55);
  this.shape_19 = new cjs.Shape();
  this.shape_19.graphics.f("#0C593C").s().p("AgRAxQgHgEgEgNQgEgMAAgUQAAg2AgAAQAOAAAIAIQAHAIACAMQACALAAAQIgyAAIABAXQACAJAEAFQAEAEAHAAQARAAAAgZIAPAAQAAALgEAJQgDAIgHAFQgHAFgLAAQgKAAgIgGgAgNghQgDAKgBANIAiAAQAAgPgDgIQgDgIgLgBQgKAAgDAJg");
  this.shape_19.setTransform(347.1, -15.55);
  this.shape_20 = new cjs.Shape();
  this.shape_20.graphics.f("#0C593C").s().p("AgQAxQgIgEgEgNQgEgMAAgUQAAg2AhAAQANAAAIAIQAHAIACAMQACALAAAQIgxAAIABAXQABAJAEAFQAEAEAHAAQARAAAAgZIAPAAQAAALgDAJQgEAIgHAFQgHAFgKAAQgLAAgHgGgAgNghQgDAKAAANIAhAAQAAgPgDgIQgDgIgKgBQgKAAgEAJg");
  this.shape_20.setTransform(339.3, -15.55);
  this.shape_21 = new cjs.Shape();
  this.shape_21.graphics.f("#0C593C").s().p("AAwBCIAAgcIhsAAIAAhnIAPAAIAABaIAiAAIAAhaIAOAAIAABaIAhAAIAAhaIAPAAIAABaIAKAAIAAApg");
  this.shape_21.setTransform(329.225, -14.125);
  this.shape_22 = new cjs.Shape();
  this.shape_22.graphics.f("#0C593C").s().p("AgKArQgKgMAAgcIgSAAIAAAxIgPAAIAAhnIAPAAIAAArIASAAQAAgVAKgNQAJgMARAAQATAAAJANQAKAOAAAYQAAAWgFAMQgEANgJAFQgIAGgMAAQgQAAgKgMgAAEglQgEAEgCAKQgDAJAAAPQAAAUAFAKQAEALAMAAQANABAEgLQAFgKAAgVQAAgWgFgLQgFgKgMAAQgHABgFAEg");
  this.shape_22.setTransform(315.925, -15.55);
  this.shape_23 = new cjs.Shape();
  this.shape_23.graphics.f("#0C593C").s().p("AgjBEIAAgNQAFACAGAAQAIAAAEgFQAEgGADgKIghhpIAPAAIAYBSIAXhSIAPAAIggBoIgHATQgCAHgGAEQgGAFgKAAIgLgCg");
  this.shape_23.setTransform(305.375, -13.775);
  this.shape_24 = new cjs.Shape();
  this.shape_24.graphics.f("#0C593C").s().p("AgfA0IAAhnIAhAAQAMAAAIAHQAIAGAAAMQAAAJgFAHQgEAGgHACIAAABQAJABAEAGQAFAHAAAKQAAAJgDAHQgEAGgGADQgGAEgGAAgAgQAoIAQAAQAKAAAEgEQADgFAAgKQAAgJgEgEQgEgEgIAAIgRAAgAgQgHIAPAAQAIAAAEgFQAEgDAAgJQAAgPgPAAIgQAAg");
  this.shape_24.setTransform(297.875, -15.55);
  this.shape_25 = new cjs.Shape();
  this.shape_25.graphics.f("#0C593C").s().p("AgGA0IAAhbIgcAAIAAgMIBFAAIAAAMIgbAAIAABbg");
  this.shape_25.setTransform(290.275, -15.55);
  this.shape_26 = new cjs.Shape();
  this.shape_26.graphics.f("#0C593C").s().p("AgTAvQgJgHgCgLQgDgMAAgPQAAg4AjAAQAPAAAJAKQAIAKAAAQIgOAAQAAgYgSAAQgLAAgEAMQgEAMgBAUQAAARAEAMQAEAMALgBQALAAAEgGQADgIABgNIAOAAQAAASgIALQgIALgQAAQgOAAgHgIg");
  this.shape_26.setTransform(283.1, -15.55);
  this.shape_27 = new cjs.Shape();
  this.shape_27.graphics.f("#0C593C").s().p("AATBFIAAhOIADgNIgEANIgiBOIgSAAIAAhnIAPAAIAABOIgBAMIADgMIAhhOIATAAIAABngAgQgzQgFgFgBgMIAHAAQADAOAMAAQAIAAADgEQAEgDABgHIAIAAQgBAMgGAFQgHAHgKAAQgJAAgHgHg");
  this.shape_27.setTransform(274.65, -17.25);
  this.shape_28 = new cjs.Shape();
  this.shape_28.graphics.f("#0C593C").s().p("AgRAxQgHgEgEgNQgEgMAAgUQAAg2AgAAQAOAAAIAIQAHAIACAMQACALAAAQIgyAAIABAXQACAJAEAFQAEAEAHAAQARAAAAgZIAPAAQAAALgDAJQgEAIgHAFQgHAFgLAAQgKAAgIgGgAgNghQgEAKAAANIAiAAQABgPgEgIQgDgIgLgBQgJAAgEAJg");
  this.shape_28.setTransform(266.2, -15.55);
  this.shape_29 = new cjs.Shape();
  this.shape_29.graphics.f("#0C593C").s().p("AAoBXIAAghIhPAAIAAAhIgPAAIAAgvIAJAAQAHgLADgNQADgNABgOIABgnIAAgkIBKAAIAAB+IALAAIAAAvgAgOgjQAAAQgCAOQgBANgDALQgDALgFAKIA4AAIAAhwIgqAAg");
  this.shape_29.setTransform(256.75, -15.725);
  this.shape_30 = new cjs.Shape();
  this.shape_30.graphics.f("#0C593C").s().p("AgHAJIAAgRIAQAAIAAARg");
  this.shape_30.setTransform(240.6, -11.3);
  this.shape_31 = new cjs.Shape();
  this.shape_31.graphics.f("#0C593C").s().p("AgnAzIAAgLIAHAAQAEAAADgDQACgDABgJIABgZIAAgzIA9AAIAABnIgQAAIAAhbIgeAAIAAAoQgBAagFAMQgEANgOAAQgFAAgEgBg");
  this.shape_31.setTransform(233.55, -15.525);
  this.shape_32 = new cjs.Shape();
  this.shape_32.graphics.f("#0C593C").s().p("AgjBEIAAgNQAFACAGAAQAIAAAEgFQAEgGADgKIghhpIAPAAIAYBSIAXhSIAPAAIggBoIgHATQgCAHgGAEQgGAFgKAAIgLgCg");
  this.shape_32.setTransform(225.625, -13.775);
  this.shape_33 = new cjs.Shape();
  this.shape_33.graphics.f("#0C593C").s().p("AgUAvQgHgHgDgLQgDgMAAgPQAAg4AkAAQAOAAAJAKQAIAKAAAQIgOAAQAAgYgSAAQgLAAgEAMQgFAMABAUQAAARADAMQAEAMAMgBQAKAAADgGQAEgIABgNIAOAAQAAASgHALQgJALgPAAQgOAAgJgIg");
  this.shape_33.setTransform(218, -15.55);
  this.shape_34 = new cjs.Shape();
  this.shape_34.graphics.f("#0C593C").s().p("AATA0IAAhbIgkAAIAABbIgPAAIAAhnIBBAAIAABng");
  this.shape_34.setTransform(209.625, -15.55);
  this.shape_35 = new cjs.Shape();
  this.shape_35.graphics.f("#0C593C").s().p("AgjAaQAAgJADgGQACgGAGgDQAFgDAKgEIASgIQADgCAAgKQAAgJgDgEQgDgDgIgBQgIABgEAEQgEAEAAAKIgNAAQAAgfAeAAQAJAAAHADQAGAEADAGQADAGAAAIIAAA8QAAAJAGgBIADAAIAAALIgGABQgHAAgEgDQgDgCgCgKIAAAAQgDAHgGAFQgGAFgHAAQgbAAAAgdgAABABIgLAGQgEACgDAFQgDAEAAAIQAAAPAOAAQAJAAAFgFIADgFIABgFIAAgKIAAgUIgLAFg");
  this.shape_35.setTransform(201.325, -15.55);
  this.shape_36 = new cjs.Shape();
  this.shape_36.graphics.f("#0C593C").s().p("AARA0IgZg0IgLAPIAAAlIgPAAIAAhnIAPAAIAAAwIAjgwIASAAIghAoIAiA/g");
  this.shape_36.setTransform(194.125, -15.55);
  this.shape_37 = new cjs.Shape();
  this.shape_37.graphics.f("#0C593C").s().p("AgQAxQgIgEgEgNQgEgMAAgUQAAg2AhAAQANAAAHAIQAIAIACAMQACALAAAQIgxAAIABAXQABAJAEAFQAEAEAHAAQARAAAAgZIAPAAQAAALgDAJQgEAIgHAFQgHAFgKAAQgLAAgHgGgAgNghQgEAKABANIAiAAQAAgPgEgIQgDgIgKgBQgKAAgEAJg");
  this.shape_37.setTransform(181.45, -15.55);
  this.shape_38 = new cjs.Shape();
  this.shape_38.graphics.f("#0C593C").s().p("AAgA0IAAhbIgbBbIgJAAIgahbIAABbIgPAAIAAhnIAXAAIATBEIADAVIAEgVIAThEIAXAAIAABng");
  this.shape_38.setTransform(171.925, -15.55);
  this.shape_39 = new cjs.Shape();
  this.shape_39.graphics.f("#0C593C").s().p("AgiBHIAAiKIAOAAIAAALIAAAAQAEgHAGgDQAGgEAFAAQAiAAAAA1QAAANgBAJQgCAKgEAHQgDAIgHAEQgGAFgKAAQgGAAgGgEQgFgDgEgHIAAAugAgQguQgDAMAAASIABAVQABAJAEAGQAFAGAIAAQALAAAEgLQAFgLAAgVQAAgpgUAAQgMAAgEAMg");
  this.shape_39.setTransform(162.075, -13.925);
  this.shape_40 = new cjs.Shape();
  this.shape_40.graphics.f("#0C593C").s().p("AgTAxQgIgEgFgNQgEgMAAgUQAAgaAJgOQAJgOASAAQAlAAAAA2QAAAUgEAMQgEANgJAEQgIAGgMAAQgLAAgIgGgAgMglQgEAEgDAJQgCAKAAAPQAAANACAJQACAJAFAFQAFAGAHgBQAJAAAEgEQAFgFACgKQACgIAAgOQAAgPgCgKQgCgJgFgEQgFgEgIgBQgHABgFAEg");
  this.shape_40.setTransform(153.025, -15.55);
  this.shape_41 = new cjs.Shape();
  this.shape_41.graphics.f("#0C593C").s().p("AgGBYIAAguQgFAHgFADQgFAEgIAAQgNAAgHgIQgIgIgCgMQgDgNAAgPQAAgQADgLQADgMAIgHQAIgHAMAAQAHAAAGADQAFAEAEAHIAAgwIAOAAIAAAwQADgHAGgEQAFgDAHAAQASAAAIAOQAIAPAAAYQAAA4ghAAQgIAAgFgEQgFgDgEgHIAAAugAALgcQgDAMAAAQQAAAUADAMQAEALAMAAQALAAAFgLQAFgLAAgVQAAgpgVAAQgMAAgEANgAguAAQAAAVAEALQAFALALAAQAJAAAEgGQAEgHACgJIABgVQAAgQgEgMQgDgNgNAAQgUAAAAApg");
  this.shape_41.setTransform(141.575, -15.625);
  this.shape_42 = new cjs.Shape();
  this.shape_42.graphics.f("#0C593C").s().p("AgfA0IAAhnIAhAAQAMAAAIAHQAIAGAAAMQAAAJgFAHQgEAGgHACIAAABQAJABAEAGQAFAHAAAKQAAAJgDAHQgEAGgGADQgGAEgGAAgAgQAoIAQAAQAKAAAEgEQADgFAAgKQAAgJgEgEQgEgEgIAAIgRAAgAgQgHIAPAAQAIAAAEgFQAEgDAAgJQAAgPgPAAIgQAAg");
  this.shape_42.setTransform(126.675, -15.55);
  this.shape_43 = new cjs.Shape();
  this.shape_43.graphics.f("#0C593C").s().p("AgRAxQgHgEgEgNQgEgMAAgUQAAg2AgAAQAPAAAGAIQAIAIACAMQACALAAAQIgyAAIABAXQACAJAEAFQAEAEAHAAQARAAAAgZIAPAAQAAALgEAJQgDAIgHAFQgHAFgLAAQgKAAgIgGgAgNghQgDAKgBANIAjAAQgBgPgDgIQgDgIgLgBQgKAAgDAJg");
  this.shape_43.setTransform(114.25, -15.55);
  this.shape_44 = new cjs.Shape();
  this.shape_44.graphics.f("#0C593C").s().p("AARA0IgZg0IgLAPIAAAlIgPAAIAAhnIAPAAIAAAwIAjgwIASAAIghAoIAiA/g");
  this.shape_44.setTransform(107.125, -15.55);
  this.shape_45 = new cjs.Shape();
  this.shape_45.graphics.f("#0C593C").s().p("AATA0IAAgxIgkAAIAAAxIgPAAIAAhnIAPAAIAAArIAkAAIAAgrIAOAAIAABng");
  this.shape_45.setTransform(98.175, -15.55);
  this.shape_46 = new cjs.Shape();
  this.shape_46.graphics.f("#0C593C").s().p("AAhA0IAAhnIAPAAIAABngAgvA0IAAhnIAPAAIAAAsIAVAAQAIAAAGADQAGAEAEAGQAEAIAAAIQAAAJgEAHQgEAHgGADQgGAEgIAAgAggAoIAPAAQALAAAEgEQADgFAAgJQAAgSgQAAIgRAAg");
  this.shape_46.setTransform(87.825, -15.55);
  this.shape_47 = new cjs.Shape();
  this.shape_47.graphics.f("#0C593C").s().p("AgiBHIAAiKIAOAAIAAALIAAAAQAEgHAGgDQAGgEAFAAQAiAAAAA1QAAANgBAJQgCAKgEAHQgDAIgHAEQgGAFgKAAQgGAAgGgEQgFgDgEgHIAAAugAgQguQgDAMAAASIABAVQABAJAEAGQAFAGAIAAQALAAAEgLQAFgLAAgVQAAgpgUAAQgMAAgEAMg");
  this.shape_47.setTransform(77.725, -13.925);
  this.shape_48 = new cjs.Shape();
  this.shape_48.graphics.f("#0C593C").s().p("AgjAaQAAgJADgGQACgGAGgDQAFgDAKgEIASgIQADgCAAgKQAAgJgDgEQgDgDgIgBQgIABgEAEQgEAEAAAKIgNAAQAAgfAeAAQAJAAAHADQAGAEADAGQADAGAAAIIAAA8QAAAJAGgBIADAAIAAALIgGABQgHAAgEgDQgDgCgCgKIAAAAQgDAHgGAFQgGAFgHAAQgbAAAAgdgAABABIgLAGQgEACgDAFQgDAEAAAIQAAAPAOAAQAJAAAFgFIADgFIABgFIAAgKIAAgUIgLAFg");
  this.shape_48.setTransform(65.025, -15.55);
  this.shape_49 = new cjs.Shape();
  this.shape_49.graphics.f("#0C593C").s().p("AATA0IAAgxIgkAAIAAAxIgPAAIAAhnIAPAAIAAArIAkAAIAAgrIAOAAIAABng");
  this.shape_49.setTransform(56.675, -15.55);
  this.shape_50 = new cjs.Shape();
  this.shape_50.graphics.f("#0C593C").s().p("AAZA0IgYgrIgYArIgQAAIAgg1IgegyIAPAAIAXAoIAWgoIAQAAIgeAyIAfA1g");
  this.shape_50.setTransform(542.25, -36.75);
  this.shape_51 = new cjs.Shape();
  this.shape_51.graphics.f("#0C593C").s().p("AAhA0IAAhnIAPAAIAABngAgvA0IAAhnIAPAAIAAArIAVAAQAIAAAGAFQAGADAEAHQAEAGAAAKQAAAIgEAHQgEAGgGAFQgGADgIAAgAggAoIAPAAQALAAAEgFQADgEAAgJQAAgSgQAAIgRAAg");
  this.shape_51.setTransform(532.425, -36.75);
  this.shape_52 = new cjs.Shape();
  this.shape_52.graphics.f("#0C593C").s().p("AATA0IAAgwIgkAAIAAAwIgPAAIAAhnIAPAAIAAArIAkAAIAAgrIAOAAIAABng");
  this.shape_52.setTransform(522.125, -36.75);
  this.shape_53 = new cjs.Shape();
  this.shape_53.graphics.f("#0C593C").s().p("AATA0IAAgwIgkAAIAAAwIgPAAIAAhnIAPAAIAAArIAkAAIAAgrIAOAAIAABng");
  this.shape_53.setTransform(513.275, -36.75);
  this.shape_54 = new cjs.Shape();
  this.shape_54.graphics.f("#0C593C").s().p("AgQAyQgIgGgEgLQgEgNAAgUQAAg2AhAAQANAAAIAIQAHAHACAMQACAMAAAQIgxAAIABAXQABAJAEAEQAEAGAHAAQARgBAAgZIAPAAQAAALgDAIQgEAJgHAFQgHAFgKAAQgLAAgHgFgAgNghQgDAJAAAOIAhAAQAAgPgDgIQgDgJgKAAQgKABgEAIg");
  this.shape_54.setTransform(504.9, -36.75);
  this.shape_55 = new cjs.Shape();
  this.shape_55.graphics.f("#0C593C").s().p("AgnAzIAAgLIAHAAQAFAAACgDQACgDABgJIABgZIAAgzIA8AAIAABnIgPAAIAAhbIgeAAIAAAoQAAAagGAMQgFANgNAAQgEAAgFgBg");
  this.shape_55.setTransform(496.1, -36.725);
  this.shape_56 = new cjs.Shape();
  this.shape_56.graphics.f("#0C593C").s().p("AgfA0IAAhnIAhAAQAMAAAIAGQAIAIAAAKQAAALgFAGQgEAHgHACIAAAAQAJABAEAHQAFAGAAALQAAAIgDAHQgEAGgGAEQgGADgGAAgAgQAoIAQAAQAKAAAEgFQADgEAAgJQAAgKgEgEQgEgEgIAAIgRAAgAgQgIIAPAAQAIAAAEgDQAEgFAAgIQAAgPgPAAIgQAAg");
  this.shape_56.setTransform(488.475, -36.75);
  this.shape_57 = new cjs.Shape();
  this.shape_57.graphics.f("#0C593C").s().p("AgjAaQAAgJADgGQACgGAGgEQAFgDAKgDIASgIQADgCAAgLQAAgIgDgEQgDgEgIAAQgIAAgEAFQgEAFAAAJIgNAAQAAgfAeAAQAJAAAHADQAGAEADAGQADAGAAAHIAAA9QAAAJAGAAIADgBIAAALIgGABQgHAAgEgCQgDgDgCgKIAAAAQgDAHgGAFQgGAFgHAAQgbAAAAgdgAABABIgLAGQgEADgDAEQgDAFAAAGQAAAQAOABQAJAAAFgHIADgDIABgGIAAgKIAAgUIgLAFg");
  this.shape_57.setTransform(480.325, -36.75);
  this.shape_58 = new cjs.Shape();
  this.shape_58.graphics.f("#0C593C").s().p("AgGA0IAAhaIgcAAIAAgNIBFAAIAAANIgbAAIAABag");
  this.shape_58.setTransform(473.075, -36.75);
  this.shape_59 = new cjs.Shape();
  this.shape_59.graphics.f("#0C593C").s().p("AgTAvQgJgHgCgMQgDgLAAgQQAAg3AjAAQAQAAAHAKQAJAKAAAPIgOAAQAAgXgSAAQgLAAgEANQgEAMgBASQAAATAFALQADAMALAAQALAAAEgIQADgGABgNIAOAAQAAAQgIALQgHAMgRAAQgOAAgHgIg");
  this.shape_59.setTransform(465.9, -36.75);
  this.shape_60 = new cjs.Shape();
  this.shape_60.graphics.f("#0C593C").s().p("AAfBCIAAgcIg8AAIAAAcIgOAAIAAgpIAJAAIAHgSQADgHABgJQACgJAAgNIAAgiIA3AAIAABaIAKAAIAAApgAgIgXQABAPgDAJQgCALgHANIAmAAIAAhOIgbAAg");
  this.shape_60.setTransform(457.35, -35.325);
  this.shape_61 = new cjs.Shape();
  this.shape_61.graphics.f("#0C593C").s().p("AgRAyQgHgGgEgLQgEgNAAgUQAAg2AgAAQAOAAAIAIQAHAHACAMQACAMAAAQIgyAAIABAXQACAJAEAEQAEAGAHAAQARgBAAgZIAPAAQAAALgDAIQgEAJgHAFQgHAFgLAAQgKAAgIgFgAgNghQgEAJAAAOIAiAAQABgPgEgIQgDgJgLAAQgJABgEAIg");
  this.shape_61.setTransform(448.9, -36.75);
  this.shape_62 = new cjs.Shape();
  this.shape_62.graphics.f("#0C593C").s().p("AgiBHIAAiKIAOAAIAAALIAAAAQAEgHAGgDQAGgEAFAAQAiAAAAA1QAAANgBAJQgCAKgEAHQgDAIgHAEQgGAFgKAAQgGAAgGgEQgFgDgEgHIAAAugAgQguQgDAMAAASIABAVQABAJAEAGQAFAGAIAAQALAAAEgLQAFgLAAgVQAAgpgUAAQgMAAgEAMg");
  this.shape_62.setTransform(440.825, -35.125);
  this.shape_63 = new cjs.Shape();
  this.shape_63.graphics.f("#0C593C").s().p("AATA0IAAhaIgkAAIAABaIgPAAIAAhnIBBAAIAABng");
  this.shape_63.setTransform(431.775, -36.75);
  this.shape_64 = new cjs.Shape();
  this.shape_64.graphics.f("#0C593C").s().p("AgHAPQAIgDAAgPIgIAAIAAgTIAQAAIAAAWQgBAHgEAHQgEAHgHACg");
  this.shape_64.setTransform(421.05, -31.125);
  this.shape_65 = new cjs.Shape();
  this.shape_65.graphics.f("#0C593C").s().p("AgfA0IAAhnIAhAAQAMAAAIAGQAIAIAAAKQAAALgFAGQgEAHgHACIAAAAQAJABAEAHQAFAGAAALQAAAIgDAHQgEAGgGAEQgGADgGAAgAgQAoIAQAAQAKAAAEgFQADgEAAgJQAAgKgEgEQgEgEgIAAIgRAAgAgQgIIAPAAQAIAAAEgDQAEgFAAgIQAAgPgPAAIgQAAg");
  this.shape_65.setTransform(415.225, -36.75);
  this.shape_66 = new cjs.Shape();
  this.shape_66.graphics.f("#0C593C").s().p("AgGA0IAAhaIgcAAIAAgNIBFAAIAAANIgbAAIAABag");
  this.shape_66.setTransform(407.625, -36.75);
  this.shape_67 = new cjs.Shape();
  this.shape_67.graphics.f("#0C593C").s().p("AgTAvQgJgHgCgMQgDgLAAgQQAAg3AjAAQAPAAAJAKQAIAKAAAPIgOAAQAAgXgSAAQgLAAgEANQgEAMAAASQAAATADALQAEAMALAAQALAAAEgIQADgGABgNIAOAAQAAAQgHALQgJAMgQAAQgOAAgHgIg");
  this.shape_67.setTransform(400.45, -36.75);
  this.shape_68 = new cjs.Shape();
  this.shape_68.graphics.f("#0C593C").s().p("AAeBCIAAgcIg7AAIAAAcIgOAAIAAgpIAJAAIAIgSQACgHABgJQABgJAAgNIAAgiIA4AAIAABaIAKAAIAAApgAgIgXQAAAPgCAJQgCALgHANIAmAAIAAhOIgbAAg");
  this.shape_68.setTransform(391.9, -35.325);
  this.shape_69 = new cjs.Shape();
  this.shape_69.graphics.f("#0C593C").s().p("AgRAyQgHgGgEgLQgEgNAAgUQAAg2AgAAQAPAAAGAIQAIAHACAMQACAMAAAQIgyAAIABAXQACAJAEAEQAEAGAHAAQARgBAAgZIAPAAQAAALgEAIQgDAJgHAFQgHAFgLAAQgKAAgIgFgAgNghQgDAJgBAOIAiAAQAAgPgDgIQgDgJgLAAQgKABgDAIg");
  this.shape_69.setTransform(383.45, -36.75);
  this.shape_70 = new cjs.Shape();
  this.shape_70.graphics.f("#0C593C").s().p("AgiBHIAAiKIAOAAIAAALIAAAAQAEgHAGgDQAGgEAFAAQAiAAAAA1QAAANgBAJQgCAKgEAHQgDAIgHAEQgGAFgKAAQgGAAgGgEQgFgDgEgHIAAAugAgQguQgDAMAAASIABAVQABAJAEAGQAFAGAIAAQALAAAEgLQAFgLAAgVQAAgpgUAAQgMAAgEAMg");
  this.shape_70.setTransform(375.375, -35.125);
  this.shape_71 = new cjs.Shape();
  this.shape_71.graphics.f("#0C593C").s().p("AgTAvQgJgHgCgMQgDgLAAgQQAAg3AjAAQAQAAAHAKQAJAKAAAPIgOAAQAAgXgSAAQgLAAgEANQgEAMgBASQAAATAFALQADAMALAAQALAAAEgIQADgGABgNIAOAAQAAAQgIALQgHAMgRAAQgOAAgHgIg");
  this.shape_71.setTransform(366.9, -36.75);
  this.shape_72 = new cjs.Shape();
  this.shape_72.graphics.f("#0C593C").s().p("AAZA0IgZgrIgXArIgQAAIAgg1IgegyIAQAAIAWAoIAXgoIAPAAIgeAyIAfA1g");
  this.shape_72.setTransform(354.85, -36.75);
  this.shape_73 = new cjs.Shape();
  this.shape_73.graphics.f("#0C593C").s().p("AAhA0IAAhnIAPAAIAABngAgvA0IAAhnIAPAAIAAArIAVAAQAIAAAGAFQAGADAEAHQAEAGAAAKQAAAIgEAHQgEAGgGAFQgGADgIAAgAggAoIAPAAQALAAAEgFQADgEAAgJQAAgSgQAAIgRAAg");
  this.shape_73.setTransform(345.025, -36.75);
  this.shape_74 = new cjs.Shape();
  this.shape_74.graphics.f("#0C593C").s().p("AATA0IAAgwIgkAAIAAAwIgPAAIAAhnIAPAAIAAArIAkAAIAAgrIAOAAIAABng");
  this.shape_74.setTransform(334.725, -36.75);
  this.shape_75 = new cjs.Shape();
  this.shape_75.graphics.f("#0C593C").s().p("AATA0IAAgwIgkAAIAAAwIgPAAIAAhnIAPAAIAAArIAkAAIAAgrIAOAAIAABng");
  this.shape_75.setTransform(325.875, -36.75);
  this.shape_76 = new cjs.Shape();
  this.shape_76.graphics.f("#0C593C").s().p("AgTAyQgIgGgFgLQgEgNAAgUQAAgaAJgOQAJgOASAAQAlAAAAA2QAAAVgEAMQgEALgJAGQgIAFgMAAQgLAAgIgFgAgMglQgEAEgDAJQgCAKAAAPQAAANACAJQACAJAFAFQAFAFAHABQAJAAAEgGQAFgFACgIQACgKAAgNQAAgPgCgKQgCgJgFgEQgFgFgIAAQgHAAgFAFg");
  this.shape_76.setTransform(317.025, -36.75);
  this.shape_77 = new cjs.Shape();
  this.shape_77.graphics.f("#0C593C").s().p("AgbA0IAAhnIA3AAIAAANIgoAAIAABag");
  this.shape_77.setTransform(310.05, -36.75);
  this.shape_78 = new cjs.Shape();
  this.shape_78.graphics.f("#0C593C").s().p("AgTAyQgIgGgFgLQgEgNAAgUQAAgaAJgOQAJgOASAAQAlAAAAA2QAAAVgEAMQgEALgJAGQgIAFgMAAQgLAAgIgFgAgMglQgEAEgDAJQgCAKAAAPQAAANACAJQACAJAFAFQAFAFAHABQAJAAAEgGQAFgFACgIQACgKAAgNQAAgPgCgKQgCgJgFgEQgFgFgIAAQgHAAgFAFg");
  this.shape_78.setTransform(301.775, -36.75);
  this.shape_79 = new cjs.Shape();
  this.shape_79.graphics.f("#0C593C").s().p("AgiBHIAAiKIAOAAIAAALIAAAAQAEgHAGgDQAGgEAFAAQAiAAAAA1QAAANgBAJQgCAKgEAHQgDAIgHAEQgGAFgKAAQgGAAgGgEQgFgDgEgHIAAAugAgQguQgDAMAAASIABAVQABAJAEAGQAFAGAIAAQALAAAEgLQAFgLAAgVQAAgpgUAAQgMAAgEAMg");
  this.shape_79.setTransform(293.125, -35.125);
  this.shape_80 = new cjs.Shape();
  this.shape_80.graphics.f("#0C593C").s().p("AgGA0IAAhaIgcAAIAAgNIBFAAIAAANIgbAAIAABag");
  this.shape_80.setTransform(285.175, -36.75);
  this.shape_81 = new cjs.Shape();
  this.shape_81.graphics.f("#0C593C").s().p("AgRAyQgHgGgEgLQgEgNAAgUQAAg2AgAAQAOAAAIAIQAHAHACAMQACAMAAAQIgyAAIABAXQACAJAEAEQAEAGAHAAQARgBAAgZIAPAAQAAALgDAIQgEAJgHAFQgHAFgLAAQgKAAgIgFgAgNghQgEAJAAAOIAiAAQABgPgEgIQgDgJgLAAQgJABgEAIg");
  this.shape_81.setTransform(277.9, -36.75);
  this.shape_82 = new cjs.Shape();
  this.shape_82.graphics.f("#0C593C").s().p("AgfA0IAAhnIAhAAQAMAAAIAGQAIAIAAAKQAAALgFAGQgEAHgHACIAAAAQAJABAEAHQAFAGAAALQAAAIgDAHQgEAGgGAEQgGADgGAAgAgQAoIAQAAQAKAAAEgFQADgEAAgJQAAgKgEgEQgEgEgIAAIgRAAgAgQgIIAPAAQAIAAAEgDQAEgFAAgIQAAgPgPAAIgQAAg");
  this.shape_82.setTransform(270.325, -36.75);
  this.shape_83 = new cjs.Shape();
  this.shape_83.graphics.f("#0C593C").s().p("AgGA0IAAhaIgcAAIAAgNIBFAAIAAANIgbAAIAABag");
  this.shape_83.setTransform(258.525, -36.75);
  this.shape_84 = new cjs.Shape();
  this.shape_84.graphics.f("#0C593C").s().p("AgTAyQgIgGgFgLQgEgNAAgUQAAgaAJgOQAJgOASAAQAlAAAAA2QAAAVgEAMQgEALgJAGQgIAFgMAAQgLAAgIgFgAgMglQgEAEgDAJQgCAKAAAPQAAANACAJQACAJAFAFQAFAFAHABQAJAAAEgGQAFgFACgIQACgKAAgNQAAgPgCgKQgCgJgFgEQgFgFgIAAQgHAAgFAFg");
  this.shape_84.setTransform(250.775, -36.75);
  this.shape_85 = new cjs.Shape();
  this.shape_85.graphics.f("#0C593C").s().p("AgRAyQgHgGgEgLQgEgNAAgUQAAg2AgAAQAOAAAIAIQAHAHACAMQACAMAAAQIgyAAIABAXQACAJAEAEQAEAGAHAAQARgBAAgZIAPAAQAAALgEAIQgDAJgHAFQgHAFgLAAQgKAAgIgFgAgNghQgDAJgBAOIAiAAQAAgPgDgIQgDgJgLAAQgKABgDAIg");
  this.shape_85.setTransform(238.2, -36.75);
  this.shape_86 = new cjs.Shape();
  this.shape_86.graphics.f("#0C593C").s().p("AAUA0IAAhOIACgNIgEANIghBOIgSAAIAAhnIAOAAIAABOIgBANIADgNIAhhOIASAAIAABng");
  this.shape_86.setTransform(229.85, -36.75);
  this.shape_87 = new cjs.Shape();
  this.shape_87.graphics.f("#0C593C").s().p("AARA0IAAgwQgJACgNAAQgNAAgGgHQgHgIAAgLIAAgfIAPAAIAAAeQAAAHAEAEQADAEAJAAIARgBIAAgsIAPAAIAABng");
  this.shape_87.setTransform(221.025, -36.75);
  this.shape_88 = new cjs.Shape();
  this.shape_88.graphics.f("#0C593C").s().p("AATA0IAAhOIACgNIgDANIgiBOIgSAAIAAhnIAQAAIAABOIgCANIADgNIAihOIASAAIAABng");
  this.shape_88.setTransform(212.35, -36.75);
  this.shape_89 = new cjs.Shape();
  this.shape_89.graphics.f("#0C593C").s().p("AgmAzIAAgLIAGAAQAEAAADgDQACgDABgJIABgZIAAgzIA8AAIAABnIgOAAIAAhbIggAAIAAAoQAAAagEAMQgFANgNAAQgGAAgDgBg");
  this.shape_89.setTransform(202.9, -36.725);
  this.shape_90 = new cjs.Shape();
  this.shape_90.graphics.f("#0C593C").s().p("AgGA0IAAhaIgcAAIAAgNIBFAAIAAANIgbAAIAABag");
  this.shape_90.setTransform(195.675, -36.75);
  this.shape_91 = new cjs.Shape();
  this.shape_91.graphics.f("#0C593C").s().p("AgTAyQgIgGgFgLQgEgNAAgUQAAgaAJgOQAJgOASAAQAlAAAAA2QAAAVgEAMQgEALgJAGQgIAFgMAAQgLAAgIgFgAgMglQgEAEgDAJQgCAKAAAPQAAANACAJQACAJAFAFQAFAFAHABQAJAAAEgGQAFgFACgIQACgKAAgNQAAgPgCgKQgCgJgFgEQgFgFgIAAQgHAAgFAFg");
  this.shape_91.setTransform(187.925, -36.75);
  this.shape_92 = new cjs.Shape();
  this.shape_92.graphics.f("#0C593C").s().p("AgfA0IAAhnIAhAAQAMAAAIAGQAIAIAAAKQAAALgFAGQgEAHgHACIAAAAQAJABAEAHQAFAGAAALQAAAIgDAHQgEAGgGAEQgGADgGAAgAgQAoIAQAAQAKAAAEgFQADgEAAgJQAAgKgEgEQgEgEgIAAIgRAAgAgQgIIAPAAQAIAAAEgDQAEgFAAgIQAAgPgPAAIgQAAg");
  this.shape_92.setTransform(175.575, -36.75);
  this.shape_93 = new cjs.Shape();
  this.shape_93.graphics.f("#0C593C").s().p("AgIAPQAJgDgBgPIgIAAIAAgTIAQAAIAAAWQAAAHgEAHQgEAHgIACg");
  this.shape_93.setTransform(160.8, -31.125);
  this.shape_94 = new cjs.Shape();
  this.shape_94.graphics.f("#0C593C").s().p("AgUBCQgJgGgFgLQgFgLgBgNQgBgMAAgOQAAgTAEgQQACgPAKgLQALgKAQAAQANAAAJAFQAJAGAFALQAEAKAAANIgPAAQAAgfgaAAQgQAAgFAQQgFARAAAXIABAXQABAKACAJQADAIAGAGQAFAFAIAAQAKAAAGgFQAEgFACgIQADgJABgNIAPAAQgBASgDALQgEAMgIAHQgJAGgPAAQgNAAgJgHg");
  this.shape_94.setTransform(153.75, -38.525);
  this.shape_95 = new cjs.Shape();
  this.shape_95.graphics.f("#0C593C").s().p("AgxBGIAAgOIAGABQAHAAAEgHQACgHABgOIABgmIAAg9IBOAAIAACLIgQAAIAAh9IgtAAIAAA4IgBAaQgBALgCALQgDAKgGAGQgGAHgJAAQgFAAgFgBg");
  this.shape_95.setTransform(142.55, -38.475);
  this.shape_96 = new cjs.Shape();
  this.shape_96.graphics.f("#0C593C").s().p("AgoBGIAAiLIAnAAQATAAALAKQAMAJAAAUQAAAMgEAIQgDAJgGADQgGAFgIACQgIACgKAAIgUAAIAAA7gAgYgCIAPAAQALAAAHgCQAHgCAEgGQAEgGAAgMQAAgOgHgFQgIgGgOAAIgTAAg");
  this.shape_96.setTransform(133.075, -38.575);
  this.shape_97 = new cjs.Shape();
  this.shape_97.graphics.f("#0C593C").s().p("AgjBGIAAiLIBIAAIAAAOIg5AAIAAB9g");
  this.shape_97.setTransform(123.95, -38.575);
  this.shape_98 = new cjs.Shape();
  this.shape_98.graphics.f("#0C593C").s().p("AAgA0IAAhaIgbBaIgJAAIgahaIAABaIgPAAIAAhnIAXAAIATBDIADAVIAEgVIAThDIAXAAIAABng");
  this.shape_98.setTransform(109.125, -36.75);
  this.shape_99 = new cjs.Shape();
  this.shape_99.graphics.f("#0C593C").s().p("AAhA0IAAhnIAPAAIAABngAgvA0IAAhnIAPAAIAAArIAVAAQAIAAAGAFQAGADAEAHQAEAGAAAKQAAAIgEAHQgEAGgGAFQgGADgIAAgAggAoIAPAAQALAAAEgFQADgEAAgJQAAgSgQAAIgRAAg");
  this.shape_99.setTransform(97.575, -36.75);
  this.shape_100 = new cjs.Shape();
  this.shape_100.graphics.f("#0C593C").s().p("AATA0IAAgwIgkAAIAAAwIgPAAIAAhnIAPAAIAAArIAkAAIAAgrIAOAAIAABng");
  this.shape_100.setTransform(87.275, -36.75);
  this.shape_101 = new cjs.Shape();
  this.shape_101.graphics.f("#0C593C").s().p("AATA0IAAgwIgkAAIAAAwIgPAAIAAhnIAPAAIAAArIAkAAIAAgrIAOAAIAABng");
  this.shape_101.setTransform(78.425, -36.75);
  this.shape_102 = new cjs.Shape();
  this.shape_102.graphics.f("#0C593C").s().p("AgjAaQAAgJADgGQACgGAGgEQAFgDAKgDIASgIQADgCAAgLQAAgIgDgEQgDgEgIAAQgIAAgEAFQgEAFAAAJIgNAAQAAgfAeAAQAJAAAHADQAGAEADAGQADAGAAAHIAAA9QAAAJAGAAIADgBIAAALIgGABQgHAAgEgCQgDgDgCgKIAAAAQgDAHgGAFQgGAFgHAAQgbAAAAgdgAABABIgLAGQgEADgDAEQgDAFAAAGQAAAQAOABQAJAAAFgHIADgDIABgGIAAgKIAAgUIgLAFg");
  this.shape_102.setTransform(70.125, -36.75);
  this.shape_103 = new cjs.Shape();
  this.shape_103.graphics.f("#0C593C").s().p("AAeBCIAAgcIg7AAIAAAcIgOAAIAAgpIAJAAIAIgSQACgHABgJQABgJAAgNIAAgiIA4AAIAABaIAKAAIAAApgAgIgXQAAAPgCAJQgCALgHANIAmAAIAAhOIgbAAg");
  this.shape_103.setTransform(61.6, -35.325);
  this.shape_104 = new cjs.Shape();
  this.shape_104.graphics.f("#0C593C").s().p("AgTAyQgIgGgFgLQgEgNAAgUQAAgaAJgOQAJgOASAAQAlAAAAA2QAAAVgEAMQgEALgJAGQgIAFgMAAQgLAAgIgFgAgMglQgEAEgDAJQgCAKAAAPQAAANACAJQACAJAFAFQAFAFAHABQAJAAAEgGQAFgFACgIQACgKAAgNQAAgPgCgKQgCgJgFgEQgFgFgIAAQgHAAgFAFg");
  this.shape_104.setTransform(48.475, -36.75);
  this.shape_105 = new cjs.Shape();
  this.shape_105.graphics.f("#0C593C").s().p("AAbBGIAAh9Ig1AAIAAB9IgPAAIAAiLIBTAAIAACLg");
  this.shape_105.setTransform(38.575, -38.575);
  this.shape_106 = new cjs.Shape();
  this.shape_106.graphics.f("#0C593C").s().p("AgIAKIAAgSIAQAAIAAASg");
  this.shape_106.setTransform(551.05, -53.7);
  this.shape_107 = new cjs.Shape();
  this.shape_107.graphics.f("#0C593C").s().p("AgRAxQgHgEgEgNQgEgMAAgUQAAg2AgAAQAPAAAGAIQAIAHACANQACALAAAQIgyAAIABAXQACAIAEAGQAEAEAHAAQARAAAAgZIAPAAQAAALgEAJQgDAIgHAFQgHAFgLAAQgKAAgIgGgAgNggQgDAJgBANIAjAAQgBgPgDgIQgDgIgLAAQgKgBgDAKg");
  this.shape_107.setTransform(545, -57.95);
  this.shape_108 = new cjs.Shape();
  this.shape_108.graphics.f("#0C593C").s().p("AgGA0IAAhbIgcAAIAAgMIBFAAIAAAMIgbAAIAABbg");
  this.shape_108.setTransform(537.825, -57.95);
  this.shape_109 = new cjs.Shape();
  this.shape_109.graphics.f("#0C593C").s().p("AgiBHIAAiKIAOAAIAAALIAAAAQAEgHAGgDQAGgEAFAAQAiAAAAA1QAAANgBAJQgCAKgEAHQgDAIgHAEQgGAFgKAAQgGAAgGgEQgFgDgEgHIAAAugAgQguQgDAMAAASIABAVQABAJAEAGQAFAGAIAAQALAAAEgLQAFgLAAgVQAAgpgUAAQgMAAgEAMg");
  this.shape_109.setTransform(530.275, -56.325);
  this.shape_110 = new cjs.Shape();
  this.shape_110.graphics.f("#0C593C").s().p("AgTAxQgIgEgFgNQgEgMAAgUQAAgaAJgOQAJgOASAAQAlAAAAA2QAAAUgEAMQgEANgJAEQgIAGgMAAQgLAAgIgGgAgMglQgEAEgDAKQgCAJAAAPQAAANACAJQACAJAFAFQAFAGAHgBQAJAAAEgEQAFgGACgJQACgIAAgOQAAgPgCgJQgCgKgFgEQgFgEgIAAQgHAAgFAEg");
  this.shape_110.setTransform(521.225, -57.95);
  this.shape_111 = new cjs.Shape();
  this.shape_111.graphics.f("#0C593C").s().p("AgHBGIAAgRIgEAAQgOAAgLgGQgMgFgHgNQgGgMAAgRQAAgTAHgMQAHgMALgGQAMgGANAAIAEAAIAAgOIAPAAIAAAOIAEAAQANAAALAGQAMAGAHAMQAHAMAAATQAAARgHAMQgHAMgLAGQgMAGgOAAIgDAAIAAARgAAIAnIAEAAQAKAAAHgEQAIgFAEgJQAFgJAAgNQAAgTgKgLQgJgKgPAAIgEAAgAgcgkQgIAEgFAJQgEAJAAANQAAANAEAJQAFAJAHAFQAIAEAKAAIAEAAIAAhQIgEAAQgKAAgHAFg");
  this.shape_111.setTransform(510.175, -59.775);
  this.shape_112 = new cjs.Shape();
  this.shape_112.graphics.f("#0C593C").s().p("AgQAzQgHgEgFgIQgEgIAAgMIANAAQABAJADAFQABAFAEACQAFACAFAAQATAAAAgTQAAgIgFgGQgFgFgIgBIgHAAIAAgKIAHAAQAHgBAEgFQAEgFAAgHQAAgHgEgFQgEgEgIAAQgIAAgFAEQgDAFgBAJIgOAAQAAgJAFgHQAEgGAHgFQAHgEAIAAQAJAAAGAEQAIADAEAGQAEAGAAAHQAAAKgGAHQgEAGgJADIAAAAQAJACAGAFQAHAIgBALQAAAJgDAHQgEAHgIAEQgIAEgJAAQgKAAgHgEg");
  this.shape_112.setTransform(495.55, -57.95);
  this.shape_113 = new cjs.Shape();
  this.shape_113.graphics.f("#0C593C").s().p("AgjAaQAAgJADgGQACgGAGgDQAFgEAKgDIASgIQADgCAAgKQAAgJgDgEQgDgDgIAAQgIAAgEAEQgEAFAAAJIgNAAQAAgfAeAAQAJAAAHAEQAGADADAGQADAHAAAGIAAA9QAAAIAGAAIADAAIAAALIgGABQgHAAgEgDQgDgCgCgKIAAAAQgDAHgGAFQgGAFgHAAQgbAAAAgdgAABABIgLAGQgEACgDAFQgDAFAAAGQAAARAOgBQAJAAAFgFIADgFIABgFIAAgKIAAgUIgLAFg");
  this.shape_113.setTransform(488.025, -57.95);
  this.shape_114 = new cjs.Shape();
  this.shape_114.graphics.f("#0C593C").s().p("AgbA0IAAhnIA2AAIAAAMIgmAAIAABbg");
  this.shape_114.setTransform(481.55, -57.95);
  this.shape_115 = new cjs.Shape();
  this.shape_115.graphics.f("#0C593C").s().p("AgRAxQgHgEgEgNQgEgMAAgUQAAg2AgAAQAOAAAIAIQAHAHACANQACALAAAQIgyAAIACAXQABAIAEAGQAEAEAHAAQARAAAAgZIAPAAQAAALgDAJQgEAIgHAFQgHAFgKAAQgLAAgIgGgAgNggQgEAJAAANIAiAAQABgPgEgIQgDgIgLAAQgJgBgEAKg");
  this.shape_115.setTransform(473.75, -57.95);
  this.shape_116 = new cjs.Shape();
  this.shape_116.graphics.f("#0C593C").s().p("AgnAzIAAgLIAHAAQAEAAADgDQACgDABgJIABgZIAAgzIA8AAIAABnIgPAAIAAhbIgeAAIAAAoQAAAagGAMQgEANgOAAQgEAAgFgBg");
  this.shape_116.setTransform(464.95, -57.925);
  this.shape_117 = new cjs.Shape();
  this.shape_117.graphics.f("#0C593C").s().p("AATA0IAAhOIADgNIgEANIgiBOIgSAAIAAhnIAPAAIAABOIgBAMIADgMIAhhOIASAAIAABng");
  this.shape_117.setTransform(456.55, -57.95);
  this.shape_118 = new cjs.Shape();
  this.shape_118.graphics.f("#0C593C").s().p("AgGA0IAAhbIgcAAIAAgMIBFAAIAAAMIgbAAIAABbg");
  this.shape_118.setTransform(448.725, -57.95);
  this.shape_119 = new cjs.Shape();
  this.shape_119.graphics.f("#0C593C").s().p("AgTAxQgIgEgFgNQgEgMAAgUQAAgaAJgOQAJgOASAAQAlAAAAA2QAAAUgEAMQgEANgJAEQgIAGgMAAQgLAAgIgGgAgMglQgEAEgDAKQgCAJAAAPQAAANACAJQACAJAFAFQAFAGAHgBQAJAAAEgEQAFgGACgJQACgIAAgOQAAgPgCgJQgCgKgFgEQgFgEgIAAQgHAAgFAEg");
  this.shape_119.setTransform(440.975, -57.95);
  this.shape_120 = new cjs.Shape();
  this.shape_120.graphics.f("#0C593C").s().p("AArBGIAAhyIAAgJIABgJIgBAAIgCAJIgDAKIgdBxIgSAAIgdhzIgEgRIgBAAIABAJIAAAJIAAByIgQAAIAAiLIAcAAIAbBsQACAIABANIAAAAIADgVIAchsIAcAAIAACLg");
  this.shape_120.setTransform(429.525, -59.775);
  this.shape_121 = new cjs.Shape();
  this.shape_121.graphics.f("#0C593C").s().p("AgjAaQAAgJADgGQACgGAGgDQAFgEAKgDIASgIQADgCAAgKQAAgJgDgEQgDgDgIAAQgIAAgEAEQgEAFAAAJIgNAAQAAgfAeAAQAJAAAHAEQAGADADAGQADAHAAAGIAAA9QAAAIAGAAIADAAIAAALIgGABQgHAAgEgDQgDgCgCgKIAAAAQgDAHgGAFQgGAFgHAAQgbAAAAgdgAABABIgLAGQgEACgDAFQgDAFAAAGQAAARAOgBQAJAAAFgFIADgFIABgFIAAgKIAAgUIgLAFg");
  this.shape_121.setTransform(414.425, -57.95);
  this.shape_122 = new cjs.Shape();
  this.shape_122.graphics.f("#0C593C").s().p("AgGA0IAAhbIgcAAIAAgMIBFAAIAAAMIgbAAIAABbg");
  this.shape_122.setTransform(407.175, -57.95);
  this.shape_123 = new cjs.Shape();
  this.shape_123.graphics.f("#0C593C").s().p("AgjAaQAAgJADgGQACgGAGgDQAFgEAKgDIASgIQADgCAAgKQAAgJgDgEQgDgDgIAAQgIAAgEAEQgEAFAAAJIgNAAQAAgfAeAAQAJAAAHAEQAGADADAGQADAHAAAGIAAA9QAAAIAGAAIADAAIAAALIgGABQgHAAgEgDQgDgCgCgKIAAAAQgDAHgGAFQgGAFgHAAQgbAAAAgdgAABABIgLAGQgEACgDAFQgDAFAAAGQAAARAOgBQAJAAAFgFIADgFIABgFIAAgKIAAgUIgLAFg");
  this.shape_123.setTransform(399.975, -57.95);
  this.shape_124 = new cjs.Shape();
  this.shape_124.graphics.f("#0C593C").s().p("AgiBHIAAiKIAOAAIAAALIAAAAQAEgHAGgDQAGgEAFAAQAiAAAAA1QAAANgBAJQgCAKgEAHQgDAIgHAEQgGAFgKAAQgGAAgGgEQgFgDgEgHIAAAugAgQguQgDAMAAASIABAVQABAJAEAGQAFAGAIAAQALAAAEgLQAFgLAAgVQAAgpgUAAQgMAAgEAMg");
  this.shape_124.setTransform(391.825, -56.325);
  this.shape_125 = new cjs.Shape();
  this.shape_125.graphics.f("#0C593C").s().p("AgjAaQAAgJADgGQACgGAGgDQAFgEAKgDIASgIQADgCAAgKQAAgJgDgEQgDgDgIAAQgIAAgEAEQgEAFAAAJIgNAAQAAgfAeAAQAJAAAHAEQAGADADAGQADAHAAAGIAAA9QAAAIAGAAIADAAIAAALIgGABQgHAAgEgDQgDgCgCgKIAAAAQgDAHgGAFQgGAFgHAAQgbAAAAgdgAABABIgLAGQgEACgDAFQgDAFAAAGQAAARAOgBQAJAAAFgFIADgFIABgFIAAgKIAAgUIgLAFg");
  this.shape_125.setTransform(383.325, -57.95);
  this.shape_126 = new cjs.Shape();
  this.shape_126.graphics.f("#0C593C").s().p("AATA0IAAhbIgkAAIAABbIgPAAIAAhnIBBAAIAABng");
  this.shape_126.setTransform(374.975, -57.95);
  this.shape_127 = new cjs.Shape();
  this.shape_127.graphics.f("#0C593C").s().p("AgQAxQgIgEgEgNQgEgMAAgUQAAg2AhAAQAOAAAGAIQAIAHACANQACALAAAQIgxAAIAAAXQACAIAEAGQAEAEAHAAQARAAAAgZIAPAAQAAALgEAJQgDAIgHAFQgHAFgLAAQgKAAgHgGgAgNggQgDAJAAANIAiAAQgBgPgDgIQgDgIgKAAQgLgBgDAKg");
  this.shape_127.setTransform(366.6, -57.95);
  this.shape_128 = new cjs.Shape();
  this.shape_128.graphics.f("#0C593C").s().p("AgiBHIAAiKIAOAAIAAALIAAAAQAEgHAGgDQAGgEAFAAQAiAAAAA1QAAANgBAJQgCAKgEAHQgDAIgHAEQgGAFgKAAQgGAAgGgEQgFgDgEgHIAAAugAgQguQgDAMAAASIABAVQABAJAEAGQAFAGAIAAQALAAAEgLQAFgLAAgVQAAgpgUAAQgMAAgEAMg");
  this.shape_128.setTransform(358.525, -56.325);
  this.shape_129 = new cjs.Shape();
  this.shape_129.graphics.f("#0C593C").s().p("AATA0IAAhbIgkAAIAABbIgPAAIAAhnIBBAAIAABng");
  this.shape_129.setTransform(349.475, -57.95);
  this.shape_130 = new cjs.Shape();
  this.shape_130.graphics.f("#0C593C").s().p("AgKArQgKgMAAgcIgSAAIAAAxIgPAAIAAhnIAPAAIAAArIASAAQAAgVAKgMQAJgNARAAQATAAAJANQAKAOAAAYQAAAWgFAMQgEANgJAFQgIAGgMAAQgQAAgKgMgAAEglQgEAEgCAKQgDAJAAAPQAAAUAFAKQAEALAMAAQANAAAEgKQAFgKAAgVQAAgXgFgKQgFgKgMABQgHAAgFAEg");
  this.shape_130.setTransform(334.825, -57.95);
  this.shape_131 = new cjs.Shape();
  this.shape_131.graphics.f("#0C593C").s().p("AATA0IAAhOIADgNIgEANIgiBOIgSAAIAAhnIAPAAIAABOIgBAMIADgMIAhhOIASAAIAABng");
  this.shape_131.setTransform(323.8, -57.95);
  this.shape_132 = new cjs.Shape();
  this.shape_132.graphics.f("#0C593C").s().p("AATA0IAAgxIgkAAIAAAxIgPAAIAAhnIAPAAIAAArIAkAAIAAgrIAOAAIAABng");
  this.shape_132.setTransform(314.875, -57.95);
  this.shape_133 = new cjs.Shape();
  this.shape_133.graphics.f("#0C593C").s().p("AgRAxQgHgEgEgNQgEgMAAgUQAAg2AgAAQAPAAAGAIQAIAHACANQACALAAAQIgyAAIABAXQACAIAEAGQAEAEAHAAQARAAAAgZIAPAAQAAALgEAJQgDAIgHAFQgHAFgLAAQgKAAgIgGgAgNggQgDAJgBANIAjAAQgBgPgDgIQgDgIgLAAQgKgBgDAKg");
  this.shape_133.setTransform(306.5, -57.95);
  this.shape_134 = new cjs.Shape();
  this.shape_134.graphics.f("#0C593C").s().p("AATA0IAAgxIgkAAIAAAxIgPAAIAAhnIAPAAIAAArIAkAAIAAgrIAOAAIAABng");
  this.shape_134.setTransform(298.225, -57.95);
  this.shape_135 = new cjs.Shape();
  this.shape_135.graphics.f("#0C593C").s().p("AgRAxQgHgEgEgNQgEgMAAgUQAAg2AgAAQAPAAAGAIQAIAHACANQACALAAAQIgyAAIABAXQACAIAEAGQAEAEAHAAQARAAAAgZIAPAAQAAALgEAJQgDAIgHAFQgHAFgLAAQgKAAgIgGgAgNggQgDAJgBANIAjAAQgBgPgDgIQgDgIgLAAQgKgBgDAKg");
  this.shape_135.setTransform(289.85, -57.95);
  this.shape_136 = new cjs.Shape();
  this.shape_136.graphics.f("#0C593C").s().p("AAgA0IAAhbIgbBbIgJAAIgahbIAABbIgPAAIAAhnIAXAAIATBDIADAWIAEgWIAThDIAXAAIAABng");
  this.shape_136.setTransform(280.325, -57.95);
  this.shape_137 = new cjs.Shape();
  this.shape_137.graphics.f("#0C593C").s().p("AAUA0IAAhOIABgNIgDANIghBOIgSAAIAAhnIAPAAIAABOIgCAMIADgMIAihOIASAAIAABng");
  this.shape_137.setTransform(270.2, -57.95);
  this.shape_138 = new cjs.Shape();
  this.shape_138.graphics.f("#0C593C").s().p("AgiBHIAAiKIAOAAIAAALIAAAAQAEgHAGgDQAGgEAFAAQAiAAAAA1QAAANgBAJQgCAKgEAHQgDAIgHAEQgGAFgKAAQgGAAgGgEQgFgDgEgHIAAAugAgQguQgDAMAAASIABAVQABAJAEAGQAFAGAIAAQALAAAEgLQAFgLAAgVQAAgpgUAAQgMAAgEAMg");
  this.shape_138.setTransform(261.475, -56.325);
  this.shape_139 = new cjs.Shape();
  this.shape_139.graphics.f("#0C593C").s().p("AATA0IAAhbIgkAAIAABbIgPAAIAAhnIBBAAIAABng");
  this.shape_139.setTransform(252.425, -57.95);
  this.shape_140 = new cjs.Shape();
  this.shape_140.graphics.f("#0C593C").s().p("AgjBEIAAgNQAFACAGAAQAIAAAEgFQAEgGADgKIghhpIAPAAIAYBSIAXhSIAPAAIggBoIgHATQgCAHgGAEQgGAFgKAAIgLgCg");
  this.shape_140.setTransform(239.775, -56.175);
  this.shape_141 = new cjs.Shape();
  this.shape_141.graphics.f("#0C593C").s().p("AAgA0IAAhbIgbBbIgJAAIgahbIAABbIgPAAIAAhnIAXAAIATBDIADAWIAEgWIAThDIAXAAIAABng");
  this.shape_141.setTransform(230.325, -57.95);
  this.shape_142 = new cjs.Shape();
  this.shape_142.graphics.f("#0C593C").s().p("AgTAxQgIgEgFgNQgEgMAAgUQAAgaAJgOQAJgOASAAQAlAAAAA2QAAAUgEAMQgEANgJAEQgIAGgMAAQgLAAgIgGgAgMglQgEAEgDAKQgCAJAAAPQAAANACAJQACAJAFAFQAFAGAHgBQAJAAAEgEQAFgGACgJQACgIAAgOQAAgPgCgJQgCgKgFgEQgFgEgIAAQgHAAgFAEg");
  this.shape_142.setTransform(220.275, -57.95);
  this.shape_143 = new cjs.Shape();
  this.shape_143.graphics.f("#0C593C").s().p("AARA0IgZg0IgLAPIAAAlIgPAAIAAhnIAPAAIAAAwIAjgwIASAAIghAoIAiA/g");
  this.shape_143.setTransform(212.575, -57.95);
  this.shape_144 = new cjs.Shape();
  this.shape_144.graphics.f("#0C593C").s().p("AgUAwQgHgIgDgLQgDgMAAgPQAAg4AkAAQAPAAAHAKQAJAKAAAPIgOAAQAAgWgSAAQgLgBgEAMQgFAMAAAUQAAARAFAMQADALAMAAQAKAAADgGQAEgIABgNIAOAAQAAASgIAKQgHAMgQAAQgOAAgJgHg");
  this.shape_144.setTransform(204.2, -57.95);
  this.shape_145 = new cjs.Shape();
  this.shape_145.graphics.f("#0C593C").s().p("AATA0IAAgxIgkAAIAAAxIgPAAIAAhnIAPAAIAAArIAkAAIAAgrIAOAAIAABng");
  this.shape_145.setTransform(195.825, -57.95);
  this.shape_146 = new cjs.Shape();
  this.shape_146.graphics.f("#0C593C").s().p("AATA0IAAhOIADgNIgEANIgiBOIgSAAIAAhnIAPAAIAABOIgBAMIADgMIAihOIARAAIAABng");
  this.shape_146.setTransform(186.9, -57.95);
  this.shape_147 = new cjs.Shape();
  this.shape_147.graphics.f("#0C593C").s().p("AAZBCIAAgcIg+AAIAAhnIAOAAIAABaIAlAAIAAhaIAOAAIAABaIAKAAIAAApg");
  this.shape_147.setTransform(178.25, -56.525);
  this.shape_148 = new cjs.Shape();
  this.shape_148.graphics.f("#0C593C").s().p("AATA0IAAhOIACgNIgDANIgiBOIgSAAIAAhnIAQAAIAABOIgCAMIADgMIAihOIASAAIAABng");
  this.shape_148.setTransform(168.8, -57.95);
  this.shape_149 = new cjs.Shape();
  this.shape_149.graphics.f("#0C593C").s().p("AAeBCIAAgcIg7AAIAAAcIgOAAIAAgpIAJAAIAIgSQACgHABgJQABgJAAgNIAAgiIA4AAIAABaIAKAAIAAApgAgIgXQAAAPgCAJQgCALgHANIAmAAIAAhOIgbAAg");
  this.shape_149.setTransform(159.7, -56.525);
  this.shape_150 = new cjs.Shape();
  this.shape_150.graphics.f("#0C593C").s().p("AgRAxQgHgEgEgNQgEgMAAgUQAAg2AgAAQAPAAAGAIQAIAHACANQACALAAAQIgyAAIABAXQACAIAEAGQAEAEAHAAQARAAAAgZIAPAAQAAALgEAJQgDAIgHAFQgHAFgLAAQgKAAgIgGgAgNggQgDAJgBANIAjAAQgBgPgDgIQgDgIgLAAQgKgBgDAKg");
  this.shape_150.setTransform(151.25, -57.95);
  this.shape_151 = new cjs.Shape();
  this.shape_151.graphics.f("#0C593C").s().p("AAgA0IAAhbIgbBbIgJAAIgahbIAABbIgPAAIAAhnIAXAAIATBDIADAWIAEgWIAThDIAXAAIAABng");
  this.shape_151.setTransform(141.725, -57.95);
  this.shape_152 = new cjs.Shape();
  this.shape_152.graphics.f("#0C593C").s().p("AgTAxQgIgEgFgNQgEgMAAgUQAAgaAJgOQAJgOASAAQAlAAAAA2QAAAUgEAMQgEANgJAEQgIAGgMAAQgLAAgIgGgAgMglQgEAEgDAKQgCAJAAAPQAAANACAJQACAJAFAFQAFAGAHgBQAJAAAEgEQAFgGACgJQACgIAAgOQAAgPgCgJQgCgKgFgEQgFgEgIAAQgHAAgFAEg");
  this.shape_152.setTransform(127.475, -57.95);
  this.shape_153 = new cjs.Shape();
  this.shape_153.graphics.f("#0C593C").s().p("AATA0IAAhbIgkAAIAABbIgPAAIAAhnIBBAAIAABng");
  this.shape_153.setTransform(118.625, -57.95);
  this.shape_154 = new cjs.Shape();
  this.shape_154.graphics.f("#0C593C").s().p("AAUA0IAAhOIABgNIgDANIghBOIgSAAIAAhnIAPAAIAABOIgCAMIADgMIAihOIASAAIAABng");
  this.shape_154.setTransform(105.5, -57.95);
  this.shape_155 = new cjs.Shape();
  this.shape_155.graphics.f("#0C593C").s().p("AAUA0IAAhOIABgNIgDANIghBOIgSAAIAAhnIAPAAIAABOIgCAMIADgMIAihOIASAAIAABng");
  this.shape_155.setTransform(96.5, -57.95);
  this.shape_156 = new cjs.Shape();
  this.shape_156.graphics.f("#0C593C").s().p("AAYBCIAAgcIg+AAIAAhnIAQAAIAABaIAjAAIAAhaIAPAAIAABaIALAAIAAApg");
  this.shape_156.setTransform(87.85, -56.525);
  this.shape_157 = new cjs.Shape();
  this.shape_157.graphics.f("#0C593C").s().p("AARA0IgZg0IgLAPIAAAlIgPAAIAAhnIAPAAIAAAwIAjgwIASAAIghAoIAiA/g");
  this.shape_157.setTransform(79.625, -57.95);
  this.shape_158 = new cjs.Shape();
  this.shape_158.graphics.f("#0C593C").s().p("AgjBEIAAgNQAFACAGAAQAIAAAEgFQAEgGADgKIghhpIAPAAIAYBSIAXhSIAPAAIggBoIgHATQgCAHgGAEQgGAFgKAAIgLgCg");
  this.shape_158.setTransform(71.075, -56.175);
  this.shape_159 = new cjs.Shape();
  this.shape_159.graphics.f("#0C593C").s().p("AgiBHIAAiKIAOAAIAAALIAAAAQAEgHAGgDQAGgEAFAAQAiAAAAA1QAAANgBAJQgCAKgEAHQgDAIgHAEQgGAFgKAAQgGAAgGgEQgFgDgEgHIAAAugAgQguQgDAMAAASIABAVQABAJAEAGQAFAGAIAAQALAAAEgLQAFgLAAgVQAAgpgUAAQgMAAgEAMg");
  this.shape_159.setTransform(63.075, -56.325);
  this.shape_160 = new cjs.Shape();
  this.shape_160.graphics.f("#0C593C").s().p("AgGA0IAAhbIgcAAIAAgMIBFAAIAAAMIgbAAIAABbg");
  this.shape_160.setTransform(55.125, -57.95);
  this.shape_161 = new cjs.Shape();
  this.shape_161.graphics.f("#0C593C").s().p("AgUAwQgHgIgDgLQgDgMAAgPQAAg4AkAAQAPAAAHAKQAJAKAAAPIgOAAQAAgWgSAAQgLgBgEAMQgEAMgBAUQAAARAFAMQADALALAAQALAAADgGQAEgIABgNIAOAAQAAASgIAKQgHAMgQAAQgPAAgIgHg");
  this.shape_161.setTransform(47.95, -57.95);
  this.shape_162 = new cjs.Shape();
  this.shape_162.graphics.f("#0C593C").s().p("AATA0IAAgxIgkAAIAAAxIgPAAIAAhnIAPAAIAAArIAkAAIAAgrIAOAAIAABng");
  this.shape_162.setTransform(39.575, -57.95);
  this.shape_163 = new cjs.Shape();
  this.shape_163.graphics.f("#0C593C").s().p("AATA0IAAhOIACgNIgDANIgiBOIgSAAIAAhnIAQAAIAABOIgCAMIADgMIAihOIASAAIAABng");
  this.shape_163.setTransform(30.65, -57.95);
  this.shape_164 = new cjs.Shape();
  this.shape_164.graphics.f("#0C593C").s().p("AATA0IAAhOIACgNIgDANIgiBOIgSAAIAAhnIAQAAIAABOIgCAMIADgMIAihOIASAAIAABng");
  this.shape_164.setTransform(555.35, -79.15);
  this.shape_165 = new cjs.Shape();
  this.shape_165.graphics.f("#0C593C").s().p("AAgA0IAAhaIgbBaIgJAAIgahaIAABaIgPAAIAAhnIAXAAIATBEIADAUIAEgUIAThEIAXAAIAABng");
  this.shape_165.setTransform(545.175, -79.15);
  this.shape_166 = new cjs.Shape();
  this.shape_166.graphics.f("#0C593C").s().p("AAhA0IAAhnIAPAAIAABngAgvA0IAAhnIAPAAIAAArIAVAAQAIAAAGAFQAGADAEAHQAEAGAAAKQAAAIgEAHQgEAGgGAEQgGAEgIAAgAggAoIAPAAQALAAAEgFQADgEAAgJQAAgSgQAAIgRAAg");
  this.shape_166.setTransform(533.625, -79.15);
  this.shape_167 = new cjs.Shape();
  this.shape_167.graphics.f("#0C593C").s().p("AATA0IAAgxIgkAAIAAAxIgPAAIAAhnIAPAAIAAArIAkAAIAAgrIAOAAIAABng");
  this.shape_167.setTransform(523.325, -79.15);
  this.shape_168 = new cjs.Shape();
  this.shape_168.graphics.f("#0C593C").s().p("AATA0IAAgxIgkAAIAAAxIgPAAIAAhnIAPAAIAAArIAkAAIAAgrIAOAAIAABng");
  this.shape_168.setTransform(514.475, -79.15);
  this.shape_169 = new cjs.Shape();
  this.shape_169.graphics.f("#0C593C").s().p("AgjAaQAAgJADgGQACgGAGgEQAFgDAKgDIASgIQADgCAAgLQAAgIgDgEQgDgEgIAAQgIAAgEAFQgEAFAAAJIgNAAQAAgfAeAAQAJAAAHADQAGAEADAGQADAGAAAIIAAA8QAAAJAGAAIADgBIAAALIgGABQgHAAgEgCQgDgDgCgKIAAAAQgDAHgGAFQgGAFgHAAQgbAAAAgdgAABABIgLAGQgEADgDAEQgDAEAAAIQAAAQAOAAQAJgBAFgGIADgDIABgGIAAgKIAAgUIgLAFg");
  this.shape_169.setTransform(506.175, -79.15);
  this.shape_170 = new cjs.Shape();
  this.shape_170.graphics.f("#0C593C").s().p("AAeBCIAAgcIg7AAIAAAcIgOAAIAAgpIAJAAIAIgSQACgHABgJQABgJAAgNIAAgiIA4AAIAABaIAKAAIAAApgAgIgXQAAAPgCAJQgCALgHANIAmAAIAAhOIgbAAg");
  this.shape_170.setTransform(497.65, -77.725);
  this.shape_171 = new cjs.Shape();
  this.shape_171.graphics.f("#0C593C").s().p("AgUAvQgHgHgDgMQgDgLAAgQQAAg3AkAAQAPAAAHAKQAJAKAAAQIgOAAQAAgYgSAAQgLAAgEANQgFAMAAASQABATAEALQADAMAMAAQAKAAADgIQAEgHABgMIAOAAQAAAQgIAMQgHALgQAAQgOAAgJgIg");
  this.shape_171.setTransform(485.1, -79.15);
  this.shape_172 = new cjs.Shape();
  this.shape_172.graphics.f("#0C593C").s().p("AATA0IAAhOIACgNIgDANIgiBOIgSAAIAAhnIAQAAIAABOIgCAMIADgMIAihOIASAAIAABng");
  this.shape_172.setTransform(472.45, -79.15);
  this.shape_173 = new cjs.Shape();
  this.shape_173.graphics.f("#0C593C").s().p("AATA0IAAhOIACgNIgDANIgiBOIgSAAIAAhnIAQAAIAABOIgCAMIADgMIAihOIASAAIAABng");
  this.shape_173.setTransform(463.45, -79.15);
  this.shape_174 = new cjs.Shape();
  this.shape_174.graphics.f("#0C593C").s().p("AgfA0IAAhnIAhAAQAMAAAIAGQAIAIAAAKQAAALgFAGQgEAHgHACIAAAAQAJABAEAHQAFAGAAALQAAAIgDAHQgEAGgGADQgGAEgGAAgAgQAoIAQAAQAKAAAEgFQADgEAAgKQAAgIgEgFQgEgEgIAAIgRAAgAgQgIIAPAAQAIAAAEgDQAEgFAAgIQAAgPgPAAIgQAAg");
  this.shape_174.setTransform(455.225, -79.15);
  this.shape_175 = new cjs.Shape();
  this.shape_175.graphics.f("#0C593C").s().p("AgGA0IAAhaIgcAAIAAgNIBFAAIAAANIgbAAIAABag");
  this.shape_175.setTransform(447.625, -79.15);
  this.shape_176 = new cjs.Shape();
  this.shape_176.graphics.f("#0C593C").s().p("AgUAvQgHgHgDgMQgDgLAAgQQAAg3AkAAQAPAAAHAKQAJAKAAAQIgOAAQAAgYgSAAQgLAAgEANQgFAMAAASQAAATAFALQADAMAMAAQAKAAADgIQAEgHABgMIAOAAQAAAQgIAMQgHALgQAAQgOAAgJgIg");
  this.shape_176.setTransform(440.45, -79.15);
  this.shape_177 = new cjs.Shape();
  this.shape_177.graphics.f("#0C593C").s().p("AgGA0IAAhaIgcAAIAAgNIBFAAIAAANIgbAAIAABag");
  this.shape_177.setTransform(433.175, -79.15);
  this.shape_178 = new cjs.Shape();
  this.shape_178.graphics.f("#0C593C").s().p("AgQAyQgIgGgEgLQgEgNAAgUQAAg2AhAAQAOAAAGAIQAIAIACALQACAMAAAQIgxAAIABAXQABAJAEAEQAEAGAHAAQARgBAAgZIAPAAQAAALgDAIQgEAJgHAFQgHAFgKAAQgLAAgHgFgAgNghQgEAJABAOIAiAAQAAgPgEgIQgDgJgKAAQgLABgDAIg");
  this.shape_178.setTransform(425.9, -79.15);
  this.shape_179 = new cjs.Shape();
  this.shape_179.graphics.f("#0C593C").s().p("AgfA0IAAhnIAhAAQAMAAAIAGQAIAIAAAKQAAALgFAGQgEAHgHACIAAAAQAJABAEAHQAFAGAAALQAAAIgDAHQgEAGgGADQgGAEgGAAgAgQAoIAQAAQAKAAAEgFQADgEAAgKQAAgIgEgFQgEgEgIAAIgRAAgAgQgIIAPAAQAIAAAEgDQAEgFAAgIQAAgPgPAAIgQAAg");
  this.shape_179.setTransform(418.325, -79.15);
  this.shape_180 = new cjs.Shape();
  this.shape_180.graphics.f("#0C593C").s().p("AgGA0IAAhaIgcAAIAAgNIBFAAIAAANIgbAAIAABag");
  this.shape_180.setTransform(410.725, -79.15);
  this.shape_181 = new cjs.Shape();
  this.shape_181.graphics.f("#0C593C").s().p("AgTAyQgIgGgFgLQgEgNAAgUQAAgaAJgOQAJgOASAAQAlAAAAA2QAAAVgEAMQgEALgJAGQgIAFgMAAQgLAAgIgFgAgMglQgEAEgDAJQgCAKAAAPQAAANACAJQACAJAFAFQAFAFAHABQAJAAAEgGQAFgFACgIQACgJAAgOQAAgPgCgKQgCgJgFgEQgFgFgIAAQgHAAgFAFg");
  this.shape_181.setTransform(402.975, -79.15);
  this.shape_182 = new cjs.Shape();
  this.shape_182.graphics.f("#0C593C").s().p("AgTAyQgIgGgFgLQgEgNAAgUQAAgaAJgOQAJgOASAAQAlAAAAA2QAAAVgEAMQgEALgJAGQgIAFgMAAQgLAAgIgFgAgMglQgEAEgDAJQgCAKAAAPQAAANACAJQACAJAFAFQAFAFAHABQAJAAAEgGQAFgFACgIQACgJAAgOQAAgPgCgKQgCgJgFgEQgFgFgIAAQgHAAgFAFg");
  this.shape_182.setTransform(394.125, -79.15);
  this.shape_183 = new cjs.Shape();
  this.shape_183.graphics.f("#0C593C").s().p("AgUAvQgHgHgDgMQgDgLAAgQQAAg3AkAAQAOAAAJAKQAIAKAAAQIgOAAQAAgYgSAAQgLAAgEANQgFAMABASQAAATADALQAEAMAMAAQAKAAADgIQAEgHABgMIAOAAQAAAQgHAMQgJALgPAAQgOAAgJgIg");
  this.shape_183.setTransform(385.85, -79.15);
  this.shape_184 = new cjs.Shape();
  this.shape_184.graphics.f("#0C593C").s().p("AgfA0IAAhnIAhAAQAMAAAIAGQAIAIAAAKQAAALgFAGQgEAHgHACIAAAAQAJABAEAHQAFAGAAALQAAAIgDAHQgEAGgGADQgGAEgGAAgAgQAoIAQAAQAKAAAEgFQADgEAAgKQAAgIgEgFQgEgEgIAAIgRAAgAgQgIIAPAAQAIAAAEgDQAEgFAAgIQAAgPgPAAIgQAAg");
  this.shape_184.setTransform(373.975, -79.15);
  this.shape_185 = new cjs.Shape();
  this.shape_185.graphics.f("#0C593C").s().p("AgIAzIAAgTIAQAAIAAATgAgIgfIAAgTIAQAAIAAATg");
  this.shape_185.setTransform(363.4, -79.075);
  this.shape_186 = new cjs.Shape();
  this.shape_186.graphics.f("#0C593C").s().p("AgjAaQAAgJADgGQACgGAGgEQAFgDAKgDIASgIQADgCAAgLQAAgIgDgEQgDgEgIAAQgIAAgEAFQgEAFAAAJIgNAAQAAgfAeAAQAJAAAHADQAGAEADAGQADAGAAAIIAAA8QAAAJAGAAIADgBIAAALIgGABQgHAAgEgCQgDgDgCgKIAAAAQgDAHgGAFQgGAFgHAAQgbAAAAgdgAABABIgLAGQgEADgDAEQgDAEAAAIQAAAQAOAAQAJgBAFgGIADgDIABgGIAAgKIAAgUIgLAFg");
  this.shape_186.setTransform(357.425, -79.15);
  this.shape_187 = new cjs.Shape();
  this.shape_187.graphics.f("#0C593C").s().p("AgfA0IAAhnIAhAAQAMAAAIAGQAIAIAAAKQAAALgFAGQgEAHgHACIAAAAQAJABAEAHQAFAGAAALQAAAIgDAHQgEAGgGADQgGAEgGAAgAgQAoIAQAAQAKAAAEgFQADgEAAgKQAAgIgEgFQgEgEgIAAIgRAAgAgQgIIAPAAQAIAAAEgDQAEgFAAgIQAAgPgPAAIgQAAg");
  this.shape_187.setTransform(349.775, -79.15);
  this.shape_188 = new cjs.Shape();
  this.shape_188.graphics.f("#0C593C").s().p("AgGA0IAAhaIgcAAIAAgNIBFAAIAAANIgbAAIAABag");
  this.shape_188.setTransform(342.175, -79.15);
  this.shape_189 = new cjs.Shape();
  this.shape_189.graphics.f("#0C593C").s().p("AgUAvQgHgHgDgMQgDgLAAgQQAAg3AkAAQAOAAAJAKQAIAKAAAQIgOAAQAAgYgSAAQgLAAgEANQgFAMABASQAAATADALQAEAMAMAAQAKAAADgIQAEgHABgMIAOAAQAAAQgHAMQgJALgPAAQgOAAgJgIg");
  this.shape_189.setTransform(335, -79.15);
  this.shape_190 = new cjs.Shape();
  this.shape_190.graphics.f("#0C593C").s().p("AAeBCIAAgcIg8AAIAAAcIgNAAIAAgpIAJAAIAIgSQACgHABgJQACgJgBgNIAAgiIA4AAIAABaIAKAAIAAApgAgHgXQgBAPgCAJQgDALgGANIAnAAIAAhOIgbAAg");
  this.shape_190.setTransform(326.45, -77.725);
  this.shape_191 = new cjs.Shape();
  this.shape_191.graphics.f("#0C593C").s().p("AgQAyQgIgGgEgLQgEgNAAgUQAAg2AhAAQAOAAAGAIQAIAIACALQACAMAAAQIgxAAIABAXQABAJAEAEQAEAGAHAAQARgBAAgZIAPAAQAAALgEAIQgDAJgHAFQgHAFgLAAQgKAAgHgFgAgNghQgDAJAAAOIAiAAQgBgPgDgIQgDgJgKAAQgLABgDAIg");
  this.shape_191.setTransform(318, -79.15);
  this.shape_192 = new cjs.Shape();
  this.shape_192.graphics.f("#0C593C").s().p("AgiBHIAAiKIAOAAIAAALIAAAAQAEgHAGgDQAGgEAFAAQAiAAAAA1QAAANgBAJQgCAKgEAHQgDAIgHAEQgGAFgKAAQgGAAgGgEQgFgDgEgHIAAAugAgQguQgDAMAAASIABAVQABAJAEAGQAFAGAIAAQALAAAEgLQAFgLAAgVQAAgpgUAAQgMAAgEAMg");
  this.shape_192.setTransform(309.925, -77.525);
  this.shape_193 = new cjs.Shape();
  this.shape_193.graphics.f("#0C593C").s().p("AgTAvQgJgHgCgMQgDgLAAgQQAAg3AjAAQAPAAAJAKQAIAKAAAQIgOAAQAAgYgSAAQgLAAgEANQgEAMAAASQAAATADALQAEAMALAAQALAAAEgIQADgHABgMIAOAAQAAAQgHAMQgJALgQAAQgOAAgHgIg");
  this.shape_193.setTransform(301.45, -79.15);
  this.shape_194 = new cjs.Shape();
  this.shape_194.graphics.f("#0C593C").s().p("AgTAyQgIgGgFgLQgEgNAAgUQAAgaAJgOQAJgOASAAQAlAAAAA2QAAAVgEAMQgEALgJAGQgIAFgMAAQgLAAgIgFgAgMglQgEAEgDAJQgCAKAAAPQAAANACAJQACAJAFAFQAFAFAHABQAJAAAEgGQAFgFACgIQACgJAAgOQAAgPgCgKQgCgJgFgEQgFgFgIAAQgHAAgFAFg");
  this.shape_194.setTransform(288.875, -79.15);
  this.shape_195 = new cjs.Shape();
  this.shape_195.graphics.f("#0C593C").s().p("AgaA0IAAhnIA2AAIAAANIgoAAIAABag");
  this.shape_195.setTransform(281.9, -79.15);
  this.shape_196 = new cjs.Shape();
  this.shape_196.graphics.f("#0C593C").s().p("AgTAyQgIgGgFgLQgEgNAAgUQAAgaAJgOQAJgOASAAQAlAAAAA2QAAAVgEAMQgEALgJAGQgIAFgMAAQgLAAgIgFgAgMglQgEAEgDAJQgCAKAAAPQAAANACAJQACAJAFAFQAFAFAHABQAJAAAEgGQAFgFACgIQACgJAAgOQAAgPgCgKQgCgJgFgEQgFgFgIAAQgHAAgFAFg");
  this.shape_196.setTransform(273.625, -79.15);
  this.shape_197 = new cjs.Shape();
  this.shape_197.graphics.f("#0C593C").s().p("AATA0IAAgxIgkAAIAAAxIgPAAIAAhnIAPAAIAAArIAkAAIAAgrIAOAAIAABng");
  this.shape_197.setTransform(264.775, -79.15);
  this.shape_198 = new cjs.Shape();
  this.shape_198.graphics.f("#0C593C").s().p("AARA0IAAgxQgJADgNAAQgNAAgGgHQgHgIAAgLIAAgfIAPAAIAAAeQAAAIAEAEQADADAJAAIARgBIAAgsIAPAAIAABng");
  this.shape_198.setTransform(256.025, -79.15);
  this.shape_199 = new cjs.Shape();
  this.shape_199.graphics.f("#0C593C").s().p("AAhA0IAAhnIAPAAIAABngAgvA0IAAhnIAPAAIAAArIAVAAQAIAAAGAFQAGADAEAHQAEAGAAAKQAAAIgEAHQgEAGgGAEQgGAEgIAAgAggAoIAPAAQALAAAEgFQADgEAAgJQAAgSgQAAIgRAAg");
  this.shape_199.setTransform(245.925, -79.15);
  this.shape_200 = new cjs.Shape();
  this.shape_200.graphics.f("#0C593C").s().p("AgVBBQgIgHgEgOQgDgNAAgWQAAgQACgMQACgMAEgIQAFgIAGgFQAGgFAIgCIARgFQAFgDABgEIAMAAQgCAKgHAFQgHAFgOADQgKACgGAJQgHAIgBANQAJgQAPAAQALAAAIAGQAIAGAEALQAEAKAAAQQAAASgEAMQgEAMgIAGQgIAHgNAAQgNAAgIgHgAgPgJQgGAJAAARQAAAOACAJQADAKAEAEQAFAFAHAAQALAAAGgLQAFgKAAgVQAAgRgGgJQgFgKgLAAQgKAAgFAKg");
  this.shape_200.setTransform(235.875, -80.825);
  this.shape_201 = new cjs.Shape();
  this.shape_201.graphics.f("#0C593C").s().p("AgTAyQgIgGgFgLQgEgNAAgUQAAgaAJgOQAJgOASAAQAlAAAAA2QAAAVgEAMQgEALgJAGQgIAFgMAAQgLAAgIgFgAgMglQgEAEgDAJQgCAKAAAPQAAANACAJQACAJAFAFQAFAFAHABQAJAAAEgGQAFgFACgIQACgJAAgOQAAgPgCgKQgCgJgFgEQgFgFgIAAQgHAAgFAFg");
  this.shape_201.setTransform(227.425, -79.15);
  this.shape_202 = new cjs.Shape();
  this.shape_202.graphics.f("#0C593C").s().p("AgnAzIAAgLIAHAAQAFAAACgDQACgDABgJIABgZIAAgzIA9AAIAABnIgQAAIAAhbIgeAAIAAAoQAAAagGAMQgEANgOAAQgEAAgFgBg");
  this.shape_202.setTransform(213.85, -79.125);
  this.shape_203 = new cjs.Shape();
  this.shape_203.graphics.f("#0C593C").s().p("AgjBEIAAgNQAFACAGAAQAIAAAEgFQAEgGADgKIghhpIAPAAIAYBSIAXhSIAPAAIggBoIgHATQgCAHgGAEQgGAFgKAAIgLgCg");
  this.shape_203.setTransform(205.925, -77.375);
  this.shape_204 = new cjs.Shape();
  this.shape_204.graphics.f("#0C593C").s().p("AgTAvQgJgHgCgMQgDgLAAgQQAAg3AjAAQAPAAAJAKQAIAKAAAQIgOAAQAAgYgSAAQgLAAgEANQgFAMABASQAAATADALQAEAMALAAQALAAAEgIQADgHABgMIAOAAQAAAQgHAMQgJALgQAAQgOAAgHgIg");
  this.shape_204.setTransform(198.3, -79.15);
  this.shape_205 = new cjs.Shape();
  this.shape_205.graphics.f("#0C593C").s().p("AATA0IAAhaIgkAAIAABaIgPAAIAAhnIBBAAIAABng");
  this.shape_205.setTransform(189.925, -79.15);
  this.shape_206 = new cjs.Shape();
  this.shape_206.graphics.f("#0C593C").s().p("AgjAaQAAgJADgGQACgGAGgEQAFgDAKgDIASgIQADgCAAgLQAAgIgDgEQgDgEgIAAQgIAAgEAFQgEAFAAAJIgNAAQAAgfAeAAQAJAAAHADQAGAEADAGQADAGAAAIIAAA8QAAAJAGAAIADgBIAAALIgGABQgHAAgEgCQgDgDgCgKIAAAAQgDAHgGAFQgGAFgHAAQgbAAAAgdgAABABIgLAGQgEADgDAEQgDAEAAAIQAAAQAOAAQAJgBAFgGIADgDIABgGIAAgKIAAgUIgLAFg");
  this.shape_206.setTransform(181.625, -79.15);
  this.shape_207 = new cjs.Shape();
  this.shape_207.graphics.f("#0C593C").s().p("AARA0IgZg0IgLAPIAAAlIgPAAIAAhnIAPAAIAAAxIAjgxIASAAIghAoIAiA/g");
  this.shape_207.setTransform(174.425, -79.15);
  this.shape_208 = new cjs.Shape();
  this.shape_208.graphics.f("#0C593C").s().p("AglBGQAAgNADgJQACgJAIgJQAHgJAPgNQAKgIAGgJQAHgJAAgMQAAgZgVAAQgMAAgEAIQgEAJAAARIgPAAIAAgHQAAgMAEgJQAEgJAIgGQAIgFAMAAQALAAAIAFQAJAFAEAIQAEAJAAAMQAAAKgDAIQgEAIgFAFIgOAOIgUAUQgFAFgDAFQgCAEgBAHIA6AAIAAAOg");
  this.shape_208.setTransform(161.175, -80.975);
  this.shape_209 = new cjs.Shape();
  this.shape_209.graphics.f("#0C593C").s().p("AgTAyQgIgGgFgLQgEgNAAgUQAAgaAJgOQAJgOASAAQAlAAAAA2QAAAVgEAMQgEALgJAGQgIAFgMAAQgLAAgIgFgAgMglQgEAEgDAJQgCAKAAAPQAAANACAJQACAJAFAFQAFAFAHABQAJAAAEgGQAFgFACgIQACgJAAgOQAAgPgCgKQgCgJgFgEQgFgFgIAAQgHAAgFAFg");
  this.shape_209.setTransform(148.225, -79.15);
  this.shape_210 = new cjs.Shape();
  this.shape_210.graphics.f("#0C593C").s().p("AgGA0IAAhaIgcAAIAAgNIBFAAIAAANIgbAAIAABag");
  this.shape_210.setTransform(140.475, -79.15);
  this.shape_211 = new cjs.Shape();
  this.shape_211.graphics.f("#0C593C").s().p("AgUAvQgHgHgDgMQgDgLAAgQQAAg3AkAAQAPAAAHAKQAJAKAAAQIgOAAQAAgYgSAAQgLAAgEANQgFAMABASQAAATADALQAEAMAMAAQAKAAADgIQAEgHABgMIAOAAQAAAQgHAMQgJALgPAAQgOAAgJgIg");
  this.shape_211.setTransform(133.3, -79.15);
  this.shape_212 = new cjs.Shape();
  this.shape_212.graphics.f("#0C593C").s().p("AgQAyQgIgGgEgLQgEgNAAgUQAAg2AhAAQAOAAAGAIQAIAIACALQACAMAAAQIgxAAIABAXQABAJAEAEQAEAGAHAAQARgBAAgZIAPAAQAAALgEAIQgDAJgHAFQgHAFgKAAQgLAAgHgFgAgNghQgDAJAAAOIAiAAQgBgPgDgIQgDgJgKAAQgLABgDAIg");
  this.shape_212.setTransform(125.4, -79.15);
  this.shape_213 = new cjs.Shape();
  this.shape_213.graphics.f("#0C593C").s().p("AAgA0IAAhaIgbBaIgJAAIgahaIAABaIgPAAIAAhnIAXAAIATBEIADAUIAEgUIAThEIAXAAIAABng");
  this.shape_213.setTransform(115.875, -79.15);
  this.shape_214 = new cjs.Shape();
  this.shape_214.graphics.f("#0C593C").s().p("AgfA0IAAhnIAhAAQAMAAAIAGQAIAIAAAKQAAALgFAGQgEAHgHACIAAAAQAJABAEAHQAFAGAAALQAAAIgDAHQgEAGgGADQgGAEgGAAgAgQAoIAQAAQAKAAAEgFQADgEAAgKQAAgIgEgFQgEgEgIAAIgRAAgAgQgIIAPAAQAIAAAEgDQAEgFAAgIQAAgPgPAAIgQAAg");
  this.shape_214.setTransform(106.525, -79.15);
  this.shape_215 = new cjs.Shape();
  this.shape_215.graphics.f("#0C593C").s().p("AgjAaQAAgJADgGQACgGAGgEQAFgDAKgDIASgIQADgCAAgLQAAgIgDgEQgDgEgIAAQgIAAgEAFQgEAFAAAJIgNAAQAAgfAeAAQAJAAAHADQAGAEADAGQADAGAAAIIAAA8QAAAJAGAAIADgBIAAALIgGABQgHAAgEgCQgDgDgCgKIAAAAQgDAHgGAFQgGAFgHAAQgbAAAAgdgAABABIgLAGQgEADgDAEQgDAEAAAIQAAAQAOAAQAJgBAFgGIADgDIABgGIAAgKIAAgUIgLAFg");
  this.shape_215.setTransform(94.175, -79.15);
  this.shape_216 = new cjs.Shape();
  this.shape_216.graphics.f("#0C593C").s().p("AgmAzIAAgLIAGAAQAEAAACgDQADgDABgJIABgZIAAgzIA9AAIAABnIgPAAIAAhbIggAAIAAAoQAAAagEAMQgFANgNAAQgFAAgEgBg");
  this.shape_216.setTransform(85.3, -79.125);
  this.shape_217 = new cjs.Shape();
  this.shape_217.graphics.f("#0C593C").s().p("AgjBEIAAgNQAFACAGAAQAIAAAEgFQAEgGADgKIghhpIAPAAIAYBSIAXhSIAPAAIggBoIgHATQgCAHgGAEQgGAFgKAAIgLgCg");
  this.shape_217.setTransform(77.375, -77.375);
  this.shape_218 = new cjs.Shape();
  this.shape_218.graphics.f("#0C593C").s().p("AgUAvQgHgHgDgMQgDgLAAgQQAAg3AkAAQAPAAAHAKQAJAKAAAQIgOAAQAAgYgSAAQgLAAgEANQgFAMAAASQABATAEALQADAMAMAAQAKAAADgIQAEgHABgMIAOAAQAAAQgIAMQgHALgQAAQgOAAgJgIg");
  this.shape_218.setTransform(69.75, -79.15);
  this.shape_219 = new cjs.Shape();
  this.shape_219.graphics.f("#0C593C").s().p("AATA0IAAhaIgkAAIAABaIgPAAIAAhnIBBAAIAABng");
  this.shape_219.setTransform(61.375, -79.15);
  this.shape_220 = new cjs.Shape();
  this.shape_220.graphics.f("#0C593C").s().p("AgjAaQAAgJADgGQACgGAGgEQAFgDAKgDIASgIQADgCAAgLQAAgIgDgEQgDgEgIAAQgIAAgEAFQgEAFAAAJIgNAAQAAgfAeAAQAJAAAHADQAGAEADAGQADAGAAAIIAAA8QAAAJAGAAIADgBIAAALIgGABQgHAAgEgCQgDgDgCgKIAAAAQgDAHgGAFQgGAFgHAAQgbAAAAgdgAABABIgLAGQgEADgDAEQgDAEAAAIQAAAQAOAAQAJgBAFgGIADgDIABgGIAAgKIAAgUIgLAFg");
  this.shape_220.setTransform(53.075, -79.15);
  this.shape_221 = new cjs.Shape();
  this.shape_221.graphics.f("#0C593C").s().p("AARA0IgZg0IgLAPIAAAlIgPAAIAAhnIAPAAIAAAxIAjgxIASAAIghAoIAiA/g");
  this.shape_221.setTransform(45.875, -79.15);
  this.shape_222 = new cjs.Shape();
  this.shape_222.graphics.f("#0C593C").s().p("AAHBGIAAhlIgdAAIAAgMQALAAAHgCQAFgCAEgGQAEgGABgKIANAAIAACLg");
  this.shape_222.setTransform(31.725, -80.975);
  this.shape_223 = new cjs.Shape();
  this.shape_223.graphics.f("#0C593C").s().p("AAAAJIgNASIgIgFIAOgSIgVgHIADgIIAWAIIAAgYIAIAAIAAAXIAVgHIADAJIgVAGIANASIgHAGg");
  this.shape_223.setTransform(23.9, -85.225);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_223
   }, {
    t: this.shape_222
   }, {
    t: this.shape_221
   }, {
    t: this.shape_220
   }, {
    t: this.shape_219
   }, {
    t: this.shape_218
   }, {
    t: this.shape_217
   }, {
    t: this.shape_216
   }, {
    t: this.shape_215
   }, {
    t: this.shape_214
   }, {
    t: this.shape_213
   }, {
    t: this.shape_212
   }, {
    t: this.shape_211
   }, {
    t: this.shape_210
   }, {
    t: this.shape_209
   }, {
    t: this.shape_208
   }, {
    t: this.shape_207
   }, {
    t: this.shape_206
   }, {
    t: this.shape_205
   }, {
    t: this.shape_204
   }, {
    t: this.shape_203
   }, {
    t: this.shape_202
   }, {
    t: this.shape_201
   }, {
    t: this.shape_200
   }, {
    t: this.shape_199
   }, {
    t: this.shape_198
   }, {
    t: this.shape_197
   }, {
    t: this.shape_196
   }, {
    t: this.shape_195
   }, {
    t: this.shape_194
   }, {
    t: this.shape_193
   }, {
    t: this.shape_192
   }, {
    t: this.shape_191
   }, {
    t: this.shape_190
   }, {
    t: this.shape_189
   }, {
    t: this.shape_188
   }, {
    t: this.shape_187
   }, {
    t: this.shape_186
   }, {
    t: this.shape_185
   }, {
    t: this.shape_184
   }, {
    t: this.shape_183
   }, {
    t: this.shape_182
   }, {
    t: this.shape_181
   }, {
    t: this.shape_180
   }, {
    t: this.shape_179
   }, {
    t: this.shape_178
   }, {
    t: this.shape_177
   }, {
    t: this.shape_176
   }, {
    t: this.shape_175
   }, {
    t: this.shape_174
   }, {
    t: this.shape_173
   }, {
    t: this.shape_172
   }, {
    t: this.shape_171
   }, {
    t: this.shape_170
   }, {
    t: this.shape_169
   }, {
    t: this.shape_168
   }, {
    t: this.shape_167
   }, {
    t: this.shape_166
   }, {
    t: this.shape_165
   }, {
    t: this.shape_164
   }, {
    t: this.shape_163
   }, {
    t: this.shape_162
   }, {
    t: this.shape_161
   }, {
    t: this.shape_160
   }, {
    t: this.shape_159
   }, {
    t: this.shape_158
   }, {
    t: this.shape_157
   }, {
    t: this.shape_156
   }, {
    t: this.shape_155
   }, {
    t: this.shape_154
   }, {
    t: this.shape_153
   }, {
    t: this.shape_152
   }, {
    t: this.shape_151
   }, {
    t: this.shape_150
   }, {
    t: this.shape_149
   }, {
    t: this.shape_148
   }, {
    t: this.shape_147
   }, {
    t: this.shape_146
   }, {
    t: this.shape_145
   }, {
    t: this.shape_144
   }, {
    t: this.shape_143
   }, {
    t: this.shape_142
   }, {
    t: this.shape_141
   }, {
    t: this.shape_140
   }, {
    t: this.shape_139
   }, {
    t: this.shape_138
   }, {
    t: this.shape_137
   }, {
    t: this.shape_136
   }, {
    t: this.shape_135
   }, {
    t: this.shape_134
   }, {
    t: this.shape_133
   }, {
    t: this.shape_132
   }, {
    t: this.shape_131
   }, {
    t: this.shape_130
   }, {
    t: this.shape_129
   }, {
    t: this.shape_128
   }, {
    t: this.shape_127
   }, {
    t: this.shape_126
   }, {
    t: this.shape_125
   }, {
    t: this.shape_124
   }, {
    t: this.shape_123
   }, {
    t: this.shape_122
   }, {
    t: this.shape_121
   }, {
    t: this.shape_120
   }, {
    t: this.shape_119
   }, {
    t: this.shape_118
   }, {
    t: this.shape_117
   }, {
    t: this.shape_116
   }, {
    t: this.shape_115
   }, {
    t: this.shape_114
   }, {
    t: this.shape_113
   }, {
    t: this.shape_112
   }, {
    t: this.shape_111
   }, {
    t: this.shape_110
   }, {
    t: this.shape_109
   }, {
    t: this.shape_108
   }, {
    t: this.shape_107
   }, {
    t: this.shape_106
   }, {
    t: this.shape_105
   }, {
    t: this.shape_104
   }, {
    t: this.shape_103
   }, {
    t: this.shape_102
   }, {
    t: this.shape_101
   }, {
    t: this.shape_100
   }, {
    t: this.shape_99
   }, {
    t: this.shape_98
   }, {
    t: this.shape_97
   }, {
    t: this.shape_96
   }, {
    t: this.shape_95
   }, {
    t: this.shape_94
   }, {
    t: this.shape_93
   }, {
    t: this.shape_92
   }, {
    t: this.shape_91
   }, {
    t: this.shape_90
   }, {
    t: this.shape_89
   }, {
    t: this.shape_88
   }, {
    t: this.shape_87
   }, {
    t: this.shape_86
   }, {
    t: this.shape_85
   }, {
    t: this.shape_84
   }, {
    t: this.shape_83
   }, {
    t: this.shape_82
   }, {
    t: this.shape_81
   }, {
    t: this.shape_80
   }, {
    t: this.shape_79
   }, {
    t: this.shape_78
   }, {
    t: this.shape_77
   }, {
    t: this.shape_76
   }, {
    t: this.shape_75
   }, {
    t: this.shape_74
   }, {
    t: this.shape_73
   }, {
    t: this.shape_72
   }, {
    t: this.shape_71
   }, {
    t: this.shape_70
   }, {
    t: this.shape_69
   }, {
    t: this.shape_68
   }, {
    t: this.shape_67
   }, {
    t: this.shape_66
   }, {
    t: this.shape_65
   }, {
    t: this.shape_64
   }, {
    t: this.shape_63
   }, {
    t: this.shape_62
   }, {
    t: this.shape_61
   }, {
    t: this.shape_60
   }, {
    t: this.shape_59
   }, {
    t: this.shape_58
   }, {
    t: this.shape_57
   }, {
    t: this.shape_56
   }, {
    t: this.shape_55
   }, {
    t: this.shape_54
   }, {
    t: this.shape_53
   }, {
    t: this.shape_52
   }, {
    t: this.shape_51
   }, {
    t: this.shape_50
   }, {
    t: this.shape_49
   }, {
    t: this.shape_48
   }, {
    t: this.shape_47
   }, {
    t: this.shape_46
   }, {
    t: this.shape_45
   }, {
    t: this.shape_44
   }, {
    t: this.shape_43
   }, {
    t: this.shape_42
   }, {
    t: this.shape_41
   }, {
    t: this.shape_40
   }, {
    t: this.shape_39
   }, {
    t: this.shape_38
   }, {
    t: this.shape_37
   }, {
    t: this.shape_36
   }, {
    t: this.shape_35
   }, {
    t: this.shape_34
   }, {
    t: this.shape_33
   }, {
    t: this.shape_32
   }, {
    t: this.shape_31
   }, {
    t: this.shape_30
   }, {
    t: this.shape_29
   }, {
    t: this.shape_28
   }, {
    t: this.shape_27
   }, {
    t: this.shape_26
   }, {
    t: this.shape_25
   }, {
    t: this.shape_24
   }, {
    t: this.shape_23
   }, {
    t: this.shape_22
   }, {
    t: this.shape_21
   }, {
    t: this.shape_20
   }, {
    t: this.shape_19
   }, {
    t: this.shape_18
   }, {
    t: this.shape_17
   }, {
    t: this.shape_16
   }, {
    t: this.shape_15
   }, {
    t: this.shape_14
   }, {
    t: this.shape_13
   }, {
    t: this.shape_12
   }, {
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
 }).prototype = getMCSymbolPrototype(lib.l4, new cjs.Rectangle(-0.6, -93.6, 580, 89.39999999999999), null);
 (lib.l3 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#0C593C").s().p("ABEBtIAAiJIABgWIABgZIgBAAIg6C4IgXAAIg5i4IgBAAIABAZIABAXIAACIIgaAAIAAjZIAnAAIA3CyIAAAAIA4iyIAnAAIAADZg");
  this.shape.setTransform(556.025, -19.775);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#0C593C").s().p("AgtBhQgRgPgIgZQgIgaAAgfQAAg2ATgdQAUgcAnAAQAbAAASAPQASAOAIAZQAIAaAAAfQAAAggIAZQgIAagSAPQgSAOgbAAQgbAAgSgPgAglhBQgNAXAAAqQAAArANAXQANAXAYAAQAZAAAMgXQANgXAAgrQAAgrgMgWQgNgXgZAAQgYAAgNAXg");
  this.shape_1.setTransform(534.675, -19.775);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#0C593C").s().p("AgNBtIAAjCIgyAAIAAgXIB/AAIAAAXIgyAAIAADCg");
  this.shape_2.setTransform(518.525, -19.775);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#0C593C").s().p("AgrBTQgVgfAAg0QAAgfAJgZQAKgZASgPQASgPAbgBQAaAAAVAMIgKAXQgIgFgJgDQgJgCgKAAQgTAAgMALQgMAMgGAVQgFATAAAZQAAApAOAYQAPAXAaAAQALAAAJgDQAKgBAJgFIAAAYQgSAIgYAAQgmAAgWgdg");
  this.shape_3.setTransform(504.65, -19.8);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#0C593C").s().p("AAvBtIAAiAIAAgZIACgYIgBAAIhXCxIghAAIAAjZIAbAAIAAB+IgBAYIgBAaIABAAIBWiwIAhAAIAADZg");
  this.shape_4.setTransform(486.925, -19.775);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#0C593C").s().p("AhKBrIAAgWQAFADAHAAQALAAAEgMQAFgMADgXIAFglIAGg1IAGg8IBhAAIAADZIgcAAIAAjBIguAAIgDAkIgEAmIgEAjIgEAbQgDAUgFAOQgFANgIAHQgJAFgOAAQgKAAgGgDg");
  this.shape_5.setTransform(467.325, -19.65);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#0C593C").s().p("AAxBtIgThEIg8AAIgTBEIgdAAIA/jZIAeAAIBADZgAgChDIgEAPIgTBFIAyAAIgThFIgEgQIgCgQIgCARg");
  this.shape_6.setTransform(452.2, -19.775);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#0C593C").s().p("AAvBtIAAiAIAAgZIACgYIgBAAIhXCxIghAAIAAjZIAbAAIAAB+IgBAYIgBAaIABAAIBWiwIAhAAIAADZg");
  this.shape_7.setTransform(434.725, -19.775);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#0C593C").s().p("AA0CLIAAg7IiBAAIAAjZIAbAAIAADCIBOAAIAAjCIAcAAIAADCIAWAAIAABSg");
  this.shape_8.setTransform(416.55, -16.85);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#0C593C").s().p("AgwBtIAAjZIBhAAIAAAXIhGAAIAABFIBCAAIAAAXIhCAAIAABPIBGAAIAAAXg");
  this.shape_9.setTransform(400.025, -19.775);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.f("#0C593C").s().p("AAmBtIAAjCIhMAAIAADCIgbAAIAAjZICDAAIAADZg");
  this.shape_10.setTransform(383.45, -19.775);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.f("#0C593C").s().p("AgrBTQgVgfAAg0QAAgfAJgZQAKgZASgPQATgPAagBQAaAAAVAMIgKAXQgIgFgJgDQgJgCgKAAQgTAAgLALQgMAMgGAVQgHATABAZQAAApAOAYQAPAXAZAAQALAAAKgDQAKgBAJgFIAAAYQgSAIgYAAQgnAAgVgdg");
  this.shape_11.setTransform(367.15, -19.8);
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.f("#0C593C").s().p("AgtBhQgRgPgIgZQgIgaAAgfQAAg2ATgdQAUgcAnAAQAbAAASAPQASAOAIAZQAIAaAAAfQAAAggIAZQgIAagSAPQgSAOgbAAQgbAAgSgPgAglhBQgNAXAAAqQAAArANAXQANAXAYAAQAZAAAMgXQANgXAAgrQAAgrgMgWQgNgXgZAAQgYAAgNAXg");
  this.shape_12.setTransform(343.425, -19.775);
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.f("#0C593C").s().p("AgrBTQgVgfAAg0QAAgfAJgZQAJgZATgPQASgPAbgBQAaAAAVAMIgKAXQgIgFgJgDQgJgCgKAAQgTAAgMALQgLAMgHAVQgFATgBAZQAAApAPAYQAPAXAaAAQAKAAAKgDQAKgBAJgFIAAAYQgSAIgZAAQgmAAgVgdg");
  this.shape_13.setTransform(326.7, -19.8);
  this.shape_14 = new cjs.Shape();
  this.shape_14.graphics.f("#0C593C").s().p("Ag7BtIAAjZIAbAAIAABbIAXAAQAkAAAQARQARAPAAAeQAAAegRARQgSARggAAgAggBWIAYAAQAoAAAAgpQAAgVgKgJQgLgKgUAAIgXAAg");
  this.shape_14.setTransform(305.175, -19.775);
  this.shape_15 = new cjs.Shape();
  this.shape_15.graphics.f("#0C593C").s().p("AgrBTQgVgfAAg0QAAgfAJgZQAKgZASgPQASgPAbgBQAaAAAVAMIgKAXQgIgFgJgDQgJgCgKAAQgTAAgMALQgMAMgGAVQgFATAAAZQAAApAOAYQAPAXAaAAQALAAAJgDQAKgBAJgFIAAAYQgSAIgYAAQgmAAgWgdg");
  this.shape_15.setTransform(289.55, -19.8);
  this.shape_16 = new cjs.Shape();
  this.shape_16.graphics.f("#0C593C").s().p("AgwBtIAAjZIBhAAIAAAXIhGAAIAABFIBCAAIAAAXIhCAAIAABPIBGAAIAAAXg");
  this.shape_16.setTransform(275.125, -19.775);
  this.shape_17 = new cjs.Shape();
  this.shape_17.graphics.f("#0C593C").s().p("AgNBtIAAjCIgyAAIAAgXIB/AAIAAAXIgyAAIAADCg");
  this.shape_17.setTransform(261.175, -19.775);
  this.shape_18 = new cjs.Shape();
  this.shape_18.graphics.f("#0C593C").s().p("AAvCPIAAiBIAAgZIACgYIgBAAIhXCyIghAAIAAjaIAbAAIAAB/IgBAXIgBAaIABAAIBWiwIAhAAIAADagAghhrQgLgLgCgYIAYAAQABAQAGAHQAFAHAMAAQAMAAAGgHQAGgHACgQIAXAAQgCAXgMAMQgMALgXAAQgXAAgMgLg");
  this.shape_18.setTransform(244.575, -23.125);
  this.shape_19 = new cjs.Shape();
  this.shape_19.graphics.f("#0C593C").s().p("Ag1BuIgKgDIAAgYQAJAEAKAAQAIAAAGgEQAFgDAFgJIAJgYIg7idIAcAAIAmBnIADAKIADAOIACAAIADgMIADgLIAghoIAdAAIg0CcQgIAYgIAOQgHAOgLAGQgKAHgQAAIgMgBg");
  this.shape_19.setTransform(227.875, -19.625);
  this.shape_20 = new cjs.Shape();
  this.shape_20.graphics.f("#0C593C").s().p("Ag5BtIAAjZIAvAAQAiAAASAQQAQAQAAAgQAAAggRASQgRASgkAAIgRAAIAABVgAgdABIAOAAQAXAAAKgJQALgLAAgYQAAgWgKgKQgKgKgUAAIgSAAg");
  this.shape_20.setTransform(213.8, -19.775);
  this.shape_21 = new cjs.Shape();
  this.shape_21.graphics.f("#0C593C").s().p("AAvBtIAAiAIAAgZIACgYIgBAAIhXCxIghAAIAAjZIAbAAIAAB+IgBAYIgBAaIABAAIBWiwIAhAAIAADZg");
  this.shape_21.setTransform(195.925, -19.775);
  this.shape_22 = new cjs.Shape();
  this.shape_22.graphics.f("#0C593C").s().p("AgNBtIAAjCIgyAAIAAgXIB/AAIAAAXIgyAAIAADCg");
  this.shape_22.setTransform(179.625, -19.775);
  this.shape_23 = new cjs.Shape();
  this.shape_23.graphics.f("#0C593C").s().p("Ag7BtIAAjZIAbAAIAABbIAXAAQAkAAAQARQARAPAAAeQAAAegRARQgSARggAAgAggBWIAYAAQAoAAAAgpQAAgVgKgJQgLgKgUAAIgXAAg");
  this.shape_23.setTransform(165.775, -19.775);
  this.shape_24 = new cjs.Shape();
  this.shape_24.graphics.f("#0C593C").s().p("AhKBrIAAgWQAFADAHAAQALAAAEgMQAFgMADgXIAFglIAGg1IAGg8IBhAAIAADZIgcAAIAAjBIguAAIgDAkIgEAmIgEAjIgEAbQgDAUgFAOQgFANgIAHQgJAFgOAAQgKAAgGgDg");
  this.shape_24.setTransform(147.525, -19.65);
  this.shape_25 = new cjs.Shape();
  this.shape_25.graphics.f("#0C593C").s().p("Ag1BuIgKgDIAAgYQAJAEAKAAQAIAAAGgEQAFgDAFgJIAJgYIg7idIAcAAIAmBnIADAKIADAOIACAAIADgMIADgLIAghoIAdAAIg0CcQgIAYgIAOQgHAOgLAGQgKAHgQAAIgMgBg");
  this.shape_25.setTransform(133.125, -19.625);
  this.shape_26 = new cjs.Shape();
  this.shape_26.graphics.f("#0C593C").s().p("AgrBTQgVgfAAg0QAAgfAJgZQAKgZASgPQATgPAagBQAaAAAVAMIgKAXQgIgFgJgDQgJgCgKAAQgTAAgMALQgLAMgHAVQgFATAAAZQAAApAOAYQAPAXAZAAQAMAAAJgDQAKgBAJgFIAAAYQgSAIgYAAQgmAAgWgdg");
  this.shape_26.setTransform(118.65, -19.8);
  this.shape_27 = new cjs.Shape();
  this.shape_27.graphics.f("#0C593C").s().p("AAnBtIAAhmIhOAAIAABmIgcAAIAAjZIAcAAIAABcIBOAAIAAhcIAcAAIAADZg");
  this.shape_27.setTransform(101.45, -19.775);
  this.shape_28 = new cjs.Shape();
  this.shape_28.graphics.f("#0C593C").s().p("AgtBhQgRgPgIgZQgIgaAAgfQAAg2ATgdQAUgcAnAAQAbAAASAPQASAOAIAZQAIAaAAAfQAAAggIAZQgIAagSAPQgSAOgbAAQgbAAgSgPgAglhBQgNAXAAAqQAAArANAXQANAXAYAAQAZAAAMgXQANgXAAgrQAAgrgMgWQgNgXgZAAQgYAAgNAXg");
  this.shape_28.setTransform(82.875, -19.775);
  this.shape_29 = new cjs.Shape();
  this.shape_29.graphics.f("#0C593C").s().p("AAhBtIhFhvIAABvIgcAAIAAjZIAcAAIAABpIBDhpIAeAAIhFBpIBJBwg");
  this.shape_29.setTransform(67.025, -19.775);
  this.shape_30 = new cjs.Shape();
  this.shape_30.graphics.f("#0C593C").s().p("AgtBhQgRgPgIgZQgIgaAAgfQAAg2ATgdQAUgcAnAAQAbAAASAPQASAOAIAZQAIAaAAAfQAAAggIAZQgIAagSAPQgSAOgbAAQgbAAgSgPgAglhBQgNAXAAAqQAAArANAXQANAXAYAAQAZAAAMgXQANgXAAgrQAAgrgMgWQgNgXgZAAQgYAAgNAXg");
  this.shape_30.setTransform(48.725, -19.775);
  this.shape_31 = new cjs.Shape();
  this.shape_31.graphics.f("#0C593C").s().p("Ag5BtIAAjZIAvAAQAiAAASAQQAQAQAAAgQAAAggRASQgRASglAAIgQAAIAABVgAgdABIAOAAQAXAAALgJQALgLgBgYQABgWgLgKQgKgKgUAAIgSAAg");
  this.shape_31.setTransform(32.35, -19.775);
  this.shape_32 = new cjs.Shape();
  this.shape_32.graphics.f("#0C593C").s().p("AAmBtIAAjCIhMAAIAADCIgbAAIAAjZICDAAIAADZg");
  this.shape_32.setTransform(14.9, -19.775);
  this.shape_33 = new cjs.Shape();
  this.shape_33.graphics.f("#0C593C").s().p("AgmBIQAAgOADgJQACgJAIgKQAHgJAQgNQAKgIAGgJQAHgKAAgMQAAgagVAAQgNAAgEAJQgEAJAAARIgQAAIAAgGQAAgNAFgKQAEgJAIgGQAJgFALAAQAMAAAJAFQAIAFAEAJQAEAJAAAMQAAALgDAHQgDAJgGAFIgOAPIgUAUQgGAFgCAFQgDAEgBAHIA8AAIAAAPg");
  this.shape_33.setTransform(507.675, -74.4);
  this.shape_34 = new cjs.Shape();
  this.shape_34.graphics.f("#0C593C").s().p("AgIAJIAAgSIARAAIAAASg");
  this.shape_34.setTransform(495.775, -68.15);
  this.shape_35 = new cjs.Shape();
  this.shape_35.graphics.f("#0C593C").s().p("AATA1IAAhcIglAAIAABcIgPAAIAAhqIBDAAIAABqg");
  this.shape_35.setTransform(488.55, -72.55);
  this.shape_36 = new cjs.Shape();
  this.shape_36.graphics.f("#0C593C").s().p("AgjBJIAAiOIAPAAIAAAMIAAAAQADgHAGgEQAHgEAFAAQAjAAAAA3QAAANgCAJQgBAKgEAIQgDAIgIAEQgGAFgKAAQgGAAgGgEQgGgDgEgHIAAAvgAgQgvQgEAMAAATQAAANABAIQABAJAFAHQAFAGAIAAQALAAAEgLQAFgMAAgVQAAgqgUAAQgMAAgEAMg");
  this.shape_36.setTransform(479.15, -70.875);
  this.shape_37 = new cjs.Shape();
  this.shape_37.graphics.f("#0C593C").s().p("AgUAzQgIgFgEgNQgGgMAAgVQAAgbAKgOQAJgOATAAQAnAAAAA3QAAAVgGAMQgEANgIAFQgIAFgNAAQgLAAgJgFgAgMgmQgFAEgCAKQgCAKAAAPQgBANACAKQADAJAEAFQAFAFAIAAQAJAAAEgFQAFgFADgJQABgJABgOQgBgPgCgKQgCgKgFgEQgFgFgIAAQgHAAgFAFg");
  this.shape_37.setTransform(469.35, -72.525);
  this.shape_38 = new cjs.Shape();
  this.shape_38.graphics.f("#0C593C").s().p("AASA1Igag1IgLAPIAAAmIgQAAIAAhqIAQAAIAAAyIAkgyIASAAIghAqIAiBAg");
  this.shape_38.setTransform(460.925, -72.55);
  this.shape_39 = new cjs.Shape();
  this.shape_39.graphics.f("#0C593C").s().p("AgIAPQAJgCAAgRIgJAAIAAgTIARAAIAAAXQAAAIgFAGQgEAHgIACg");
  this.shape_39.setTransform(448.875, -66.75);
  this.shape_40 = new cjs.Shape();
  this.shape_40.graphics.f("#0C593C").s().p("AgZBGQADgWAHgXQAHgVAKgUQALgUAOgTIhCAAIAAgOIBOAAIAAANQgKANgIAQQgIAPgGAQQgGAPgDASQgEAQgBARg");
  this.shape_40.setTransform(441.65, -74.25);
  this.shape_41 = new cjs.Shape();
  this.shape_41.graphics.f("#0C593C").s().p("AAHBIIAAhoIgdAAIAAgMQALAAAHgCQAFgDAFgFQAEgGABgLIAMAAIAACPg");
  this.shape_41.setTransform(431.025, -74.4);
  this.shape_42 = new cjs.Shape();
  this.shape_42.graphics.f("#0C593C").s().p("AgIAJIAAgSIARAAIAAASg");
  this.shape_42.setTransform(424.875, -68.15);
  this.shape_43 = new cjs.Shape();
  this.shape_43.graphics.f("#0C593C").s().p("AAfBEIAAgdIg9AAIAAAdIgOAAIAAgqIAJAAIAIgTQACgHABgJQACgJAAgNIAAgkIA5AAIAABdIAKAAIAAAqgAgIgXQAAAPgCAKQgDAKgGAOIAnAAIAAhQIgcAAg");
  this.shape_43.setTransform(417.475, -71.1);
  this.shape_44 = new cjs.Shape();
  this.shape_44.graphics.f("#0C593C").s().p("AgIAPQAJgCAAgRIgJAAIAAgTIARAAIAAAXQAAAIgFAGQgEAHgIACg");
  this.shape_44.setTransform(405.425, -66.75);
  this.shape_45 = new cjs.Shape();
  this.shape_45.graphics.f("#0C593C").s().p("AAUA1IAAgtIgRAAIgUAtIgRAAIAXguQgJgEgFgGQgFgJAAgKQAAgJAEgHQAEgHAGgDQAGgEAJgBIAkAAIAABqgAgKgjQgFAEAAAKQABASAQAAIASAAIAAglIgRAAQgJAAgEAFg");
  this.shape_45.setTransform(398.1, -72.55);
  this.shape_46 = new cjs.Shape();
  this.shape_46.graphics.f("#0C593C").s().p("AgkAbQAAgKACgGQADgGAGgEQAFgDALgDIASgIQADgCAAgLQABgJgEgEQgEgEgHAAQgJAAgEAFQgDAFAAAJIgOAAQAAgfAfAAQAJAAAHADQAGAEAEAGQADAGAAAIIAAA+QAAAIAGAAIADAAIAAALQgCACgFAAQgHAAgEgDQgDgDgBgKIgBAAQgDAHgHAFQgFAFgHAAQgcAAAAgdgAABABIgLAGQgFADgCAEQgDAFAAAHQAAAQAOAAQAIAAAGgGIADgEIABgFIAAgKIAAgVIgLAFg");
  this.shape_46.setTransform(390.1, -72.525);
  this.shape_47 = new cjs.Shape();
  this.shape_47.graphics.f("#0C593C").s().p("AASA1Igag1IgLAPIAAAmIgQAAIAAhqIAQAAIAAAyIAkgyIASAAIghAqIAiBAg");
  this.shape_47.setTransform(382.175, -72.55);
  this.shape_48 = new cjs.Shape();
  this.shape_48.graphics.f("#0C593C").s().p("AgUAxQgIgIgDgMQgDgMAAgQQAAg4AkAAQAQAAAIAKQAJAKAAAQIgPAAQAAgYgSAAQgLAAgFANQgEAMAAATQAAATAEALQADAMAMAAQALAAAEgHQADgHABgNIAPAAQAAARgIAMQgIALgRAAQgOAAgIgHg");
  this.shape_48.setTransform(373.125, -72.525);
  this.shape_49 = new cjs.Shape();
  this.shape_49.graphics.f("#0C593C").s().p("AgHA1IAAhcIgcAAIAAgOIBGAAIAAAOIgcAAIAABcg");
  this.shape_49.setTransform(365.2, -72.55);
  this.shape_50 = new cjs.Shape();
  this.shape_50.graphics.f("#0C593C").s().p("AgkAbQAAgKADgGQADgGAFgEQAGgDAJgDIASgIQAFgCAAgLQgBgJgDgEQgDgEgJAAQgIAAgDAFQgFAFAAAJIgNAAQAAgfAfAAQAJAAAHADQAGAEADAGQAEAGAAAIIAAA+QAAAIAFAAIAEAAIAAALQgCACgEAAQgIAAgDgDQgEgDgCgKIAAAAQgDAHgHAFQgFAFgIAAQgbAAAAgdgAABABIgMAGQgDADgEAEQgCAFAAAHQAAAQAOAAQAIAAAGgGIADgEIABgFIABgKIAAgVIgMAFg");
  this.shape_50.setTransform(357.3, -72.525);
  this.shape_51 = new cjs.Shape();
  this.shape_51.graphics.f("#0C593C").s().p("AgnA0IAAgLIAHAAQAEAAACgDQADgDABgJIABgaIAAg1IA+AAIAABqIgQAAIAAhdIggAAIAAAqQAAAZgEAOQgGANgNAAQgFAAgEgCg");
  this.shape_51.setTransform(347.65, -72.525);
  this.shape_52 = new cjs.Shape();
  this.shape_52.graphics.f("#0C593C").s().p("AAiA1IAAhqIAQAAIAABqgAgwA1IAAhqIAPAAIAAAtIAWAAQAIABAGAEQAGADAEAHQAEAHAAAJQAAAJgEAHQgDAHgIAEQgFADgIAAgAghApIAQAAQAKAAAFgFQAEgEgBgJQAAgTgRAAIgRAAg");
  this.shape_52.setTransform(337.1, -72.55);
  this.shape_53 = new cjs.Shape();
  this.shape_53.graphics.f("#0C593C").s().p("AgjBJIAAiOIAPAAIAAAMIAAAAQADgHAHgEQAGgEAFAAQAjAAAAA3QAAANgBAJQgCAKgEAIQgEAIgHAEQgGAFgKAAQgGAAgGgEQgGgDgEgHIAAAvgAgQgvQgEAMAAATQAAANACAIQABAJAEAHQAEAGAJAAQALAAAFgLQAEgMAAgVQAAgqgUAAQgMAAgEAMg");
  this.shape_53.setTransform(326.2, -70.875);
  this.shape_54 = new cjs.Shape();
  this.shape_54.graphics.f("#0C593C").s().p("AAaBIIglhHIgRAVIAAAyIgQAAIAAiPIAQAAIAABJIA0hJIAUAAIgtA8IAuBTg");
  this.shape_54.setTransform(316.5, -74.4);
  this.shape_55 = new cjs.Shape();
  this.shape_55.graphics.f("#0C593C").s().p("AgIAJIAAgSIARAAIAAASg");
  this.shape_55.setTransform(303.325, -68.15);
  this.shape_56 = new cjs.Shape();
  this.shape_56.graphics.f("#0C593C").s().p("AgnA0IAAgLIAHAAQAEAAACgDQADgDABgJIABgaIAAg1IA+AAIAABqIgQAAIAAhdIggAAIAAAqQAAAZgFAOQgEANgOAAQgGAAgDgCg");
  this.shape_56.setTransform(295.55, -72.525);
  this.shape_57 = new cjs.Shape();
  this.shape_57.graphics.f("#0C593C").s().p("AgjBGIAAgNQAFACAGAAQAHAAAEgGQAEgFAEgLIgihsIAPAAIAZBVIAAAAIAYhVIAPAAIghBrIgHATQgCAHgGAFQgHAFgKAAQgFAAgFgCg");
  this.shape_57.setTransform(286.925, -70.725);
  this.shape_58 = new cjs.Shape();
  this.shape_58.graphics.f("#0C593C").s().p("AgIAPQAJgCAAgRIgJAAIAAgTIARAAIAAAXQAAAIgFAGQgEAHgIACg");
  this.shape_58.setTransform(275.625, -66.75);
  this.shape_59 = new cjs.Shape();
  this.shape_59.graphics.f("#0C593C").s().p("AgkAbQAAgKADgGQADgGAFgEQAFgDAKgDIASgIQAFgCAAgLQgBgJgDgEQgDgEgJAAQgIAAgDAFQgFAFAAAJIgNAAQAAgfAfAAQAJAAAHADQAGAEADAGQAEAGAAAIIAAA+QAAAIAFAAIAEAAIAAALQgCACgEAAQgIAAgDgDQgEgDgCgKIAAAAQgDAHgGAFQgGAFgIAAQgbAAAAgdgAABABIgMAGQgDADgEAEQgCAFAAAHQAAAQAOAAQAIAAAGgGIADgEIABgFIABgKIAAgVIgMAFg");
  this.shape_59.setTransform(269, -72.525);
  this.shape_60 = new cjs.Shape();
  this.shape_60.graphics.f("#0C593C").s().p("AggA1IAAhqIAhAAQANABAJAGQAHAIAAALQABAKgFAHQgEAGgIACIAAABQAJABAFAHQAFAGAAALQAAAKgEAGQgDAHgGADQgGAEgHgBgAgRApIARAAQAKAAAEgFQADgEABgKQAAgJgEgFQgFgEgIAAIgSAAgAgRgIIARAAQAHAAAEgEQAEgEAAgIQAAgQgPAAIgRAAg");
  this.shape_60.setTransform(260.6, -72.55);
  this.shape_61 = new cjs.Shape();
  this.shape_61.graphics.f("#0C593C").s().p("AASA1Igag1IgLAPIAAAmIgQAAIAAhqIAQAAIAAAyIAkgyIASAAIghAqIAiBAg");
  this.shape_61.setTransform(252.325, -72.55);
  this.shape_62 = new cjs.Shape();
  this.shape_62.graphics.f("#0C593C").s().p("AgUAxQgIgIgDgMQgDgMAAgQQAAg4AkAAQAQAAAIAKQAJAKAAAQIgPAAQAAgYgSAAQgLAAgFANQgEAMAAATQAAATAEALQADAMAMAAQALAAAEgHQADgHABgNIAPAAQAAARgIAMQgIALgRAAQgOAAgIgHg");
  this.shape_62.setTransform(243.275, -72.525);
  this.shape_63 = new cjs.Shape();
  this.shape_63.graphics.f("#0C593C").s().p("AgTAzQgJgFgFgNQgEgMAAgVQAAgbAJgOQAJgOATAAQAnAAgBA3QAAAVgEAMQgFANgIAFQgJAFgMAAQgLAAgIgFgAgMgmQgFAEgCAKQgCAKAAAPQAAANACAKQABAJAGAFQAEAFAIAAQAIAAAGgFQAEgFACgJQADgJAAgOQAAgPgDgKQgCgKgFgEQgFgFgIAAQgHAAgFAFg");
  this.shape_63.setTransform(234.15, -72.525);
  this.shape_64 = new cjs.Shape();
  this.shape_64.graphics.f("#0C593C").s().p("AAsBIIAAh1IAAgKIABgJIgBAAIgCAKIgDAKIgeB0IgSAAIgeh2IgEgSIgBAAIABAKIAAAJIAAB1IgQAAIAAiPIAcAAIAcBvQACAIABAOIAAAAIADgWIAdhvIAcAAIAACPg");
  this.shape_64.setTransform(221.925, -74.4);
  this.shape_65 = new cjs.Shape();
  this.shape_65.graphics.f("#0C593C").s().p("AgIAJIAAgSIARAAIAAASg");
  this.shape_65.setTransform(207.275, -68.15);
  this.shape_66 = new cjs.Shape();
  this.shape_66.graphics.f("#0C593C").s().p("AgbA1IAAhqIA3AAIAAAOIgoAAIAABcg");
  this.shape_66.setTransform(201.975, -72.55);
  this.shape_67 = new cjs.Shape();
  this.shape_67.graphics.f("#0C593C").s().p("AgIAPQAJgCAAgRIgJAAIAAgTIARAAIAAAXQAAAIgFAGQgEAHgIACg");
  this.shape_67.setTransform(190.575, -66.75);
  this.shape_68 = new cjs.Shape();
  this.shape_68.graphics.f("#0C593C").s().p("AAMBIIAAgkIg0AAIAAgPIA1hcIAPAAIAABcIANAAIAAAPIgNAAIAAAkgAgbAVIAnAAIAAhDg");
  this.shape_68.setTransform(183.15, -74.4);
  this.shape_69 = new cjs.Shape();
  this.shape_69.graphics.f("#0C593C").s().p("AAHBIIAAhoIgdAAIAAgMQALAAAHgCQAFgDAFgFQAEgGABgLIAMAAIAACPg");
  this.shape_69.setTransform(172.725, -74.4);
  this.shape_70 = new cjs.Shape();
  this.shape_70.graphics.f("#0C593C").s().p("AgUBDQgIgGgEgJQgEgKgCgLIgBgZQAAgUACgRQADgQAJgNQAKgNARAAQAKAAAHAFQAIAEAEAIQAFAIAAAKIgQAAQgBgLgFgFQgFgEgJAAQgHAAgFAGQgEAGgDAIQgCAJgBAHIgBAUIAAAAQAEgJAHgEQAHgFAIAAQASAAAJANQAKAMAAASQAAAPgFALQgFAMgJAGQgJAGgKABQgNgBgJgGgAgVAWQAAAUAGAIQAGAJAKAAQANAAAEgKQAFgLAAgOQAAgegXABQgVAAAAAbg");
  this.shape_70.setTransform(164.175, -74.25);
  this.shape_71 = new cjs.Shape();
  this.shape_71.graphics.f("#0C593C").s().p("AAHBIIAAhoIgdAAIAAgMQALAAAHgCQAFgDAFgFQAEgGABgLIAMAAIAACPg");
  this.shape_71.setTransform(153.525, -74.4);
  this.shape_72 = new cjs.Shape();
  this.shape_72.graphics.f("#0C593C").s().p("AgmBIQAAgOADgJQACgJAIgKQAHgJAQgNQAKgIAGgJQAHgKAAgMQAAgagVAAQgNAAgEAJQgEAJAAARIgQAAIAAgGQAAgNAFgKQAEgJAIgGQAJgFALAAQAMAAAJAFQAIAFAEAJQAEAJAAAMQAAALgDAHQgDAJgGAFIgOAPIgUAUQgGAFgCAFQgDAEgBAHIA8AAIAAAPg");
  this.shape_72.setTransform(144.875, -74.4);
  this.shape_73 = new cjs.Shape();
  this.shape_73.graphics.f("#0C593C").s().p("AAHBIIAAhoIgdAAIAAgMQALAAAHgCQAFgDAFgFQAEgGABgLIAMAAIAACPg");
  this.shape_73.setTransform(134.325, -74.4);
  this.shape_74 = new cjs.Shape();
  this.shape_74.graphics.f("#0C593C").s().p("AgIAPQAJgCAAgRIgJAAIAAgTIARAAIAAAXQAAAIgFAGQgEAHgIACg");
  this.shape_74.setTransform(123.375, -66.75);
  this.shape_75 = new cjs.Shape();
  this.shape_75.graphics.f("#0C593C").s().p("AAUA1IAAgtIgRAAIgUAtIgRAAIAXguQgJgEgFgGQgFgJAAgKQAAgJAEgHQADgHAHgDQAHgEAIgBIAkAAIAABqgAgKgjQgFAEAAAKQABASAQAAIASAAIAAglIgRAAQgJAAgEAFg");
  this.shape_75.setTransform(116.05, -72.55);
  this.shape_76 = new cjs.Shape();
  this.shape_76.graphics.f("#0C593C").s().p("AAUA1IAAhQIACgMIgEAMIgiBQIgSAAIAAhqIAPAAIAABRIgCANIAEgNIAihRIASAAIAABqg");
  this.shape_76.setTransform(107.375, -72.55);
  this.shape_77 = new cjs.Shape();
  this.shape_77.graphics.f("#0C593C").s().p("AgUAxQgIgIgDgMQgDgMAAgQQAAg4AkAAQAQAAAIAKQAJAKAAAQIgPAAQAAgYgSAAQgLAAgFANQgEAMAAATQAAATAEALQADAMAMAAQALAAAEgHQADgHABgNIAPAAQAAARgIAMQgIALgRAAQgOAAgIgHg");
  this.shape_77.setTransform(98.325, -72.525);
  this.shape_78 = new cjs.Shape();
  this.shape_78.graphics.f("#0C593C").s().p("AgUAxQgIgIgDgMQgDgMAAgQQAAg4AkAAQAQAAAIAKQAJAKAAAQIgPAAQAAgYgSAAQgLAAgFANQgEAMAAATQAAATAEALQADAMAMAAQALAAAEgHQADgHABgNIAPAAQAAARgIAMQgIALgRAAQgOAAgIgHg");
  this.shape_78.setTransform(89.825, -72.525);
  this.shape_79 = new cjs.Shape();
  this.shape_79.graphics.f("#0C593C").s().p("AgTAzQgJgFgFgNQgEgMAAgVQAAgbAJgOQAJgOATAAQAnAAgBA3QAAAVgEAMQgFANgIAFQgJAFgMAAQgLAAgIgFgAgMgmQgFAEgCAKQgCAKAAAPQAAANACAKQABAJAGAFQAEAFAIAAQAIAAAGgFQAEgFACgJQADgJAAgOQAAgPgDgKQgCgKgFgEQgFgFgIAAQgHAAgFAFg");
  this.shape_79.setTransform(80.7, -72.525);
  this.shape_80 = new cjs.Shape();
  this.shape_80.graphics.f("#0C593C").s().p("AgpBIIAAiPIAoAAQAUAAALAKQAMAKAAAUQAAANgEAIQgDAJgHADQgGAFgIACQgIACgKAAIgVAAIAAA9gAgZgDIAQAAQALAAAHgCQAIgBAEgHQAEgFAAgNQAAgOgIgGQgHgGgPAAIgUAAg");
  this.shape_80.setTransform(71.025, -74.4);
  this.shape_81 = new cjs.Shape();
  this.shape_81.graphics.f("#0C593C").s().p("AgIAPQAJgCAAgRIgJAAIAAgTIARAAIAAAXQAAAHgFAIQgEAGgIADg");
  this.shape_81.setTransform(396.725, -86);
  this.shape_82 = new cjs.Shape();
  this.shape_82.graphics.f("#0C593C").s().p("AADATIATgTIgTgSIAAgQIAdAdIAAALIgdAegAgeATIATgTIgTgSIAAgQIAcAdIAAALIgcAeg");
  this.shape_82.setTransform(389.5, -92.4);
  this.shape_83 = new cjs.Shape();
  this.shape_83.graphics.f("#0C593C").s().p("AATA1IAAgxIglAAIAAAxIgPAAIAAhpIAPAAIAAAsIAlAAIAAgsIAPAAIAABpg");
  this.shape_83.setTransform(379.9, -91.8);
  this.shape_84 = new cjs.Shape();
  this.shape_84.graphics.f("#0C593C").s().p("AgTAzQgJgFgFgNQgEgMAAgVQAAgbAJgOQAKgOASAAQAmAAAAA3QAAAVgEAMQgFANgIAFQgJAFgMAAQgLAAgIgFgAgMgmQgFAEgCAKQgDAKAAAPQABANACAKQACAJAEAFQAGAFAHAAQAJAAAEgFQAGgFABgJQACgJAAgOQAAgPgCgKQgCgKgFgEQgFgFgIAAQgHAAgFAFg");
  this.shape_84.setTransform(370.3, -91.775);
  this.shape_85 = new cjs.Shape();
  this.shape_85.graphics.f("#0C593C").s().p("AgUAxQgIgIgDgMQgDgMAAgQQAAg4AkAAQAQAAAIAKQAJAKAAAQIgPAAQAAgYgSAAQgLAAgFANQgEAMAAATQAAATAEALQADAMAMAAQALAAAEgHQADgHABgNIAPAAQAAARgIAMQgIALgRAAQgOAAgIgHg");
  this.shape_85.setTransform(361.325, -91.775);
  this.shape_86 = new cjs.Shape();
  this.shape_86.graphics.f("#0C593C").s().p("AATA1IAAgxIglAAIAAAxIgPAAIAAhpIAPAAIAAAsIAlAAIAAgsIAPAAIAABpg");
  this.shape_86.setTransform(352.2, -91.8);
  this.shape_87 = new cjs.Shape();
  this.shape_87.graphics.f("#0C593C").s().p("AgTAzQgJgFgFgNQgEgMAAgVQAAgbAJgOQAJgOATAAQAmAAAAA3QAAAVgEAMQgFANgIAFQgJAFgMAAQgLAAgIgFgAgMgmQgFAEgCAKQgCAKAAAPQAAANACAKQABAJAGAFQAEAFAIAAQAIAAAGgFQAEgFACgJQADgJAAgOQAAgPgDgKQgCgKgFgEQgFgFgIAAQgHAAgFAFg");
  this.shape_87.setTransform(342.6, -91.775);
  this.shape_88 = new cjs.Shape();
  this.shape_88.graphics.f("#0C593C").s().p("AAtA1Igag0IgLAOIAAAmIgPAAIAAgmIgMgOIgaA0IgSAAIAjhAIgigpIASAAIAlAxIAAgxIAPAAIAAAxIAkgxIASAAIghApIAiBAg");
  this.shape_88.setTransform(331.35, -91.8);
  this.shape_89 = new cjs.Shape();
  this.shape_89.graphics.f("#0C593C").s().p("AApBZIAAgiIhRAAIAAAiIgPAAIAAgwIAKAAQAGgMADgNQADgNABgOIABgoIAAglIBMAAIAACBIALAAIAAAwgAgPgkQABARgCAOQgBANgEAMQgDALgEAKIA5AAIAAhyIgsAAg");
  this.shape_89.setTransform(318.9, -91.975);
  this.shape_90 = new cjs.Shape();
  this.shape_90.graphics.f("#0C593C").s().p("AgfBFQgKgFgFgKQgFgJAAgNQAAgKAEgIQADgIAGgGIARgLQgIgJgDgHQgEgHAAgJQAAgIAEgHQADgHAHgEQAHgEAIAAQAMAAAIAIQAJAIAAANQAAATgYARIAaAnQAFgOABgNIAOAAQgCAZgJAPIATAaIgTAAIgJgNQgNARgUAAQgNAAgJgFgAgdAOQgGAHAAALQAAAIAEAGQADAHAHADQAFADAJAAQALAAAMgNIgeguQgLAHgEAHgAgRg4QgEAFABAGQgBALALAPQAJgGACgGQAFgFAAgIQgBgHgDgEQgDgFgGAAQgHAAgDAEg");
  this.shape_90.setTransform(306.7, -93.475);
  this.shape_91 = new cjs.Shape();
  this.shape_91.graphics.f("#0C593C").s().p("AATA1IAAgxIglAAIAAAxIgPAAIAAhpIAPAAIAAAsIAlAAIAAgsIAPAAIAABpg");
  this.shape_91.setTransform(295.25, -91.8);
  this.shape_92 = new cjs.Shape();
  this.shape_92.graphics.f("#0C593C").s().p("AgUAzQgIgFgEgNQgGgMAAgVQAAgbAKgOQAJgOATAAQAnAAAAA3QgBAVgFAMQgEANgIAFQgIAFgNAAQgLAAgJgFgAgMgmQgFAEgCAKQgDAKABAPQAAANABAKQADAJAFAFQAEAFAIAAQAIAAAGgFQAFgFACgJQACgJAAgOQgBgPgCgKQgCgKgFgEQgFgFgIAAQgHAAgFAFg");
  this.shape_92.setTransform(285.65, -91.775);
  this.shape_93 = new cjs.Shape();
  this.shape_93.graphics.f("#0C593C").s().p("AgUAxQgIgIgDgMQgDgMAAgQQAAg4AkAAQAQAAAIAKQAJAKAAAQIgPAAQAAgYgSAAQgLAAgFANQgEAMAAATQAAATAEALQADAMAMAAQALAAAEgHQADgHABgNIAPAAQAAARgIAMQgIALgRAAQgOAAgIgHg");
  this.shape_93.setTransform(276.675, -91.775);
  this.shape_94 = new cjs.Shape();
  this.shape_94.graphics.f("#0C593C").s().p("AATA1IAAgxIglAAIAAAxIgPAAIAAhpIAPAAIAAAsIAlAAIAAgsIAPAAIAABpg");
  this.shape_94.setTransform(267.55, -91.8);
  this.shape_95 = new cjs.Shape();
  this.shape_95.graphics.f("#0C593C").s().p("AgUAzQgIgFgEgNQgFgMgBgVQAAgbAKgOQAKgOASAAQAnAAAAA3QAAAVgGAMQgEANgIAFQgIAFgNAAQgLAAgJgFgAgMgmQgFAEgCAKQgCAKgBAPQAAANACAKQACAJAFAFQAFAFAIAAQAJAAAEgFQAFgFADgJQABgJAAgOQABgPgDgKQgCgKgFgEQgFgFgIAAQgHAAgFAFg");
  this.shape_95.setTransform(257.95, -91.775);
  this.shape_96 = new cjs.Shape();
  this.shape_96.graphics.f("#0C593C").s().p("AAuA1Igbg0IgMAOIAAAmIgNAAIAAgmIgNgOIgaA0IgRAAIAhhAIgggpIASAAIAlAxIAAgxIANAAIAAAxIAmgxIASAAIghApIAiBAg");
  this.shape_96.setTransform(246.7, -91.8);
  this.shape_97 = new cjs.Shape();
  this.shape_97.graphics.f("#0C593C").s().p("AApBZIAAgiIhRAAIAAAiIgQAAIAAgwIAKAAQAHgMADgNQAEgNABgOIABgoIAAglIBLAAIAACBIAMAAIAAAwgAgOgkQAAARgCAOQgBANgDAMQgEALgEAKIA5AAIAAhyIgrAAg");
  this.shape_97.setTransform(234.25, -91.975);
  this.shape_98 = new cjs.Shape();
  this.shape_98.graphics.f("#0C593C").s().p("AACAFIAAgLIAdgcIAAAQIgTASIATATIAAARgAgfAFIAAgLIAdgcIAAAQIgTASIATATIAAARg");
  this.shape_98.setTransform(223.4, -92.4);
  this.shape_99 = new cjs.Shape();
  this.shape_99.graphics.f("#0C593C").s().p("AgYBFQgJgGgGgKQgEgKgCgNQgCgNAAgRQAAgUAEgQQADgQAKgLQAMgLASAAQAcAAAKAVQAKAVAAAgQAAAjgKAUQgJAUgdAAQgOAAgKgGgAgSg0QgHAHgDANQgCAMAAASIABAbQACAMADAIQADAIAGAEQAGAEAJAAQAKAAAFgEQAHgEADgIQADgIACgMIABgbIgBgXQgCgKgEgIQgDgIgHgEQgGgFgIAAQgMAAgGAIg");
  this.shape_99.setTransform(208, -93.625);
  this.shape_100 = new cjs.Shape();
  this.shape_100.graphics.f("#0C593C").s().p("AgYBFQgJgGgGgKQgEgKgCgNQgCgNAAgRQAAgUAEgQQADgQAKgLQAMgLASAAQAcAAAKAVQAKAVAAAgQAAAjgKAUQgJAUgdAAQgOAAgKgGgAgSg0QgHAHgDANQgCAMAAASIABAbQACAMADAIQADAIAGAEQAGAEAJAAQAKAAAFgEQAHgEADgIQADgIACgMIAAgbIAAgXQgCgKgEgIQgDgIgHgEQgGgFgIAAQgMAAgGAIg");
  this.shape_100.setTransform(196.3, -93.625);
  this.shape_101 = new cjs.Shape();
  this.shape_101.graphics.f("#0C593C").s().p("AgYBFQgJgGgGgKQgEgKgCgNQgCgNAAgRQAAgUAEgQQADgQAKgLQAMgLASAAQAcAAAKAVQAKAVAAAgQAAAjgKAUQgJAUgdAAQgOAAgKgGgAgSg0QgHAHgDANQgCAMAAASIABAbQACAMADAIQADAIAGAEQAGAEAJAAQAKAAAFgEQAHgEADgIQADgIACgMIAAgbIAAgXQgCgKgEgIQgDgIgHgEQgGgFgIAAQgMAAgGAIg");
  this.shape_101.setTransform(184.6, -93.625);
  this.shape_102 = new cjs.Shape();
  this.shape_102.graphics.f("#0C593C").s().p("AADAUIAUgUIgUgUIAAgQIAeAfIAAALIgeAggAggAUIAUgUIgUgUIAAgQIAeAfIAAALIgeAgg");
  this.shape_102.setTransform(543.125, -115.45);
  this.shape_103 = new cjs.Shape();
  this.shape_103.graphics.f("#0C593C").s().p("AAUA4IAAg1IgnAAIAAA1IgQAAIAAhvIAQAAIAAAvIAnAAIAAgvIAQAAIAABvg");
  this.shape_103.setTransform(533.3, -114.8);
  this.shape_104 = new cjs.Shape();
  this.shape_104.graphics.f("#0C593C").s().p("AgVA2QgIgGgFgNQgFgNAAgWQAAgcAKgPQAKgPATAAQAoAAAAA6QAAAWgEANQgFANgJAGQgJAFgNAAQgMAAgJgFgAgNgoQgFAEgCALQgCAKAAAQQAAAPACAJQACAKAFAFQAFAFAIAAQAJAAAFgFQAGgFACgKQACgJAAgPQAAgQgDgLQgCgKgFgEQgFgEgJAAQgHAAgGAEg");
  this.shape_104.setTransform(523.375, -114.8);
  this.shape_105 = new cjs.Shape();
  this.shape_105.graphics.f("#0C593C").s().p("AgVAzQgJgIgDgMQgCgNAAgRQAAg7AlAAQARAAAJALQAJAKAAARIgQAAQAAgZgTABQgMAAgEAMQgFANABAUQAAAUADAMQAEAMANAAQAMAAADgHQADgIABgNIAQAAQgBASgHAMQgJAMgRAAQgPAAgJgIg");
  this.shape_105.setTransform(514.1, -114.8);
  this.shape_106 = new cjs.Shape();
  this.shape_106.graphics.f("#0C593C").s().p("AAUA4IAAg1IgnAAIAAA1IgQAAIAAhvIAQAAIAAAvIAnAAIAAgvIAQAAIAABvg");
  this.shape_106.setTransform(504.8, -114.8);
  this.shape_107 = new cjs.Shape();
  this.shape_107.graphics.f("#0C593C").s().p("AgVA2QgIgGgFgNQgFgNAAgWQAAgcAKgPQAKgPATAAQAoAAAAA6QAAAWgEANQgFANgJAGQgJAFgNAAQgMAAgJgFgAgNgoQgFAEgCALQgCAKAAAQQAAAPACAJQACAKAFAFQAFAFAIAAQAJAAAFgFQAGgFACgKQACgJAAgPQAAgQgDgLQgCgKgFgEQgFgEgJAAQgHAAgGAEg");
  this.shape_107.setTransform(494.875, -114.8);
  this.shape_108 = new cjs.Shape();
  this.shape_108.graphics.f("#0C593C").s().p("AAwA4Igcg4IgMAQIAAAoIgPAAIAAgoIgMgQIgcA4IgTAAIAkhDIgjgsIATAAIAnA0IAAg0IAPAAIAAA0IAng0IATAAIgjAsIAkBDg");
  this.shape_108.setTransform(483.3, -114.8);
  this.shape_109 = new cjs.Shape();
  this.shape_109.graphics.f("#0C593C").s().p("AArBdIAAgjIhVAAIAAAjIgQAAIAAgyIAKAAQAHgMADgOQADgOABgPQACgRAAgZIAAgmIBPAAIAACHIANAAIAAAygAgPgmQAAASgCAPQgCANgDAMQgDANgFAKIA9AAIAAh4IguAAg");
  this.shape_109.setTransform(470.5, -114.975);
  this.shape_110 = new cjs.Shape();
  this.shape_110.graphics.f("#0C593C").s().p("AghBIQgKgFgFgKQgGgKAAgOQAAgLAEgIQAEgIAGgGQAHgFAKgHQgHgJgEgIQgEgIAAgJQAAgIAEgHQAEgHAHgFQAHgDAJAAQAMgBAJAJQAIAHAAAOQAAAVgZARIAcApQAFgOABgOIAPAAQgCAagJAQIAUAcIgUAAIgKgOQgNARgVAAQgOAAgKgFgAgfAOQgFAHAAAMQAAAJADAHQAEAGAGADQAHAEAJAAQAMAAALgOIgfgwQgLAHgFAHgAgSg6QgDAEAAAGQAAALALARQAIgHADgFQAFgHAAgIQAAgGgEgFQgDgFgHgBQgGABgEAFg");
  this.shape_110.setTransform(457.875, -116.55);
  this.shape_111 = new cjs.Shape();
  this.shape_111.graphics.f("#0C593C").s().p("AAUA4IAAg1IgnAAIAAA1IgQAAIAAhvIAQAAIAAAvIAnAAIAAgvIAQAAIAABvg");
  this.shape_111.setTransform(446.1, -114.8);
  this.shape_112 = new cjs.Shape();
  this.shape_112.graphics.f("#0C593C").s().p("AgVA2QgIgGgFgNQgFgNAAgWQAAgcAKgPQAKgPATAAQAoAAAAA6QAAAWgEANQgFANgJAGQgJAFgNAAQgMAAgJgFgAgNgoQgFAEgCALQgCAKAAAQQAAAPACAJQACAKAFAFQAFAFAIAAQAJAAAFgFQAGgFACgKQACgJAAgPQAAgQgDgLQgCgKgFgEQgFgEgJAAQgHAAgGAEg");
  this.shape_112.setTransform(436.175, -114.8);
  this.shape_113 = new cjs.Shape();
  this.shape_113.graphics.f("#0C593C").s().p("AgVAzQgJgIgDgMQgCgNAAgRQgBg7AmAAQARAAAJALQAJAKAAARIgQAAQAAgZgTABQgMAAgEAMQgFANABAUQAAAUADAMQAEAMANAAQALAAAEgHQADgIABgNIAQAAQAAASgIAMQgJAMgRAAQgPAAgJgIg");
  this.shape_113.setTransform(426.9, -114.8);
  this.shape_114 = new cjs.Shape();
  this.shape_114.graphics.f("#0C593C").s().p("AAUA4IAAg1IgnAAIAAA1IgQAAIAAhvIAQAAIAAAvIAnAAIAAgvIAQAAIAABvg");
  this.shape_114.setTransform(417.6, -114.8);
  this.shape_115 = new cjs.Shape();
  this.shape_115.graphics.f("#0C593C").s().p("AgVA2QgIgGgFgNQgFgNAAgWQAAgcAKgPQAKgPATAAQAoAAAAA6QAAAWgEANQgFANgJAGQgJAFgNAAQgMAAgJgFgAgNgoQgFAEgCALQgCAKAAAQQAAAPACAJQACAKAFAFQAFAFAIAAQAJAAAFgFQAGgFACgKQACgJAAgPQAAgQgDgLQgCgKgFgEQgFgEgJAAQgHAAgGAEg");
  this.shape_115.setTransform(407.675, -114.8);
  this.shape_116 = new cjs.Shape();
  this.shape_116.graphics.f("#0C593C").s().p("AAwA4Igcg4IgMAQIAAAoIgPAAIAAgoIgMgQIgcA4IgTAAIAkhDIgjgsIATAAIAnA0IAAg0IAPAAIAAA0IAng0IATAAIgjAsIAjBDg");
  this.shape_116.setTransform(396.1, -114.8);
  this.shape_117 = new cjs.Shape();
  this.shape_117.graphics.f("#0C593C").s().p("AArBdIAAgjIhVAAIAAAjIgQAAIAAgyIAKAAQAHgMADgOQADgOACgPQABgRAAgZIAAgmIBPAAIAACHIAMAAIAAAygAgPgmQAAASgCAPQgBANgEAMQgDANgFAKIA9AAIAAh4IguAAg");
  this.shape_117.setTransform(383.3, -114.975);
  this.shape_118 = new cjs.Shape();
  this.shape_118.graphics.f("#0C593C").s().p("AADAGIAAgMIAegeIAAAQIgUAUIAUAUIAAASgAggAGIAAgMIAegeIAAAQIgUAUIAUAUIAAASg");
  this.shape_118.setTransform(372.075, -115.45);
  this.shape_119 = new cjs.Shape();
  this.shape_119.graphics.f("#0C593C").s().p("AgZBJQgKgHgGgKQgEgLgDgOQgBgOAAgRQAAgVAEgRQADgRALgLQALgMAUAAQAdAAAKAWQALAXAAAhQAAAlgKAVQgKAVgeAAQgPAAgKgGgAgTg3QgHAIgDANQgCANgBATIABAdQACAMAEAIQADAIAGAEQAHAFAJAAQAKAAAHgFQAGgEAEgIQADgIABgMIABgdIgBgYQgBgLgEgIQgEgJgGgEQgHgFgJAAQgMAAgHAIg");
  this.shape_119.setTransform(356.25, -116.725);
  this.shape_120 = new cjs.Shape();
  this.shape_120.graphics.f("#0C593C").s().p("AgZBJQgKgHgGgKQgEgLgDgOQgBgOAAgRQAAgVAEgRQADgRALgLQALgMAUAAQAdAAAKAWQALAXAAAhQAAAlgKAVQgKAVgeAAQgPAAgKgGgAgTg3QgHAIgDANQgCANgBATIABAdQACAMAEAIQADAIAGAEQAHAFAJAAQAKAAAHgFQAGgEAEgIQADgIABgMIABgdIgBgYQgBgLgEgIQgEgJgGgEQgHgFgJAAQgMAAgHAIg");
  this.shape_120.setTransform(344.1, -116.725);
  this.shape_121 = new cjs.Shape();
  this.shape_121.graphics.f("#0C593C").s().p("AgZBJQgKgHgGgKQgEgLgDgOQgBgOAAgRQAAgVAEgRQADgRALgLQALgMAUAAQAdAAAKAWQALAXAAAhQAAAlgKAVQgKAVgeAAQgPAAgKgGgAgTg3QgHAIgDANQgCANgBATIABAdQACAMAEAIQADAIAGAEQAHAFAJAAQAKAAAHgFQAGgEAEgIQADgIABgMIABgdIgBgYQgBgLgEgIQgEgJgGgEQgHgFgJAAQgMAAgHAIg");
  this.shape_121.setTransform(331.95, -116.725);
  this.shape_122 = new cjs.Shape();
  this.shape_122.graphics.f("#0C593C").s().p("AghA4IAAhvIAjAAQAMAAAJAHQAJAIAAAMQAAAKgFAHQgEAHgJACIAAABQAKABAFAHQAGAHgBAMQABAJgEAHQgEAGgGAFQgHADgHAAgAgSArIASAAQALAAADgFQAEgEABgLQAAgJgFgFQgFgFgIAAIgTAAgAgSgIIARAAQAIAAAFgEQADgEAAgKQABgQgRAAIgRAAg");
  this.shape_122.setTransform(316.8, -114.8);
  this.shape_123 = new cjs.Shape();
  this.shape_123.graphics.f("#0C593C").s().p("AgHA4IAAhiIgdAAIAAgNIBJAAIAAANIgdAAIAABig");
  this.shape_123.setTransform(308.275, -114.8);
  this.shape_124 = new cjs.Shape();
  this.shape_124.graphics.f("#0C593C").s().p("AgVAzQgJgIgCgMQgDgNgBgRQAAg7AnAAQAQAAAJALQAJAKAAARIgPAAQgBgZgSABQgMAAgFAMQgFANAAAUQAAAUAFAMQADAMANAAQAMAAADgHQADgIACgNIAPAAQgBASgHAMQgIAMgSAAQgPAAgJgIg");
  this.shape_124.setTransform(300.15, -114.8);
  this.shape_125 = new cjs.Shape();
  this.shape_125.graphics.f("#0C593C").s().p("AAhBHIAAgeIhAAAIAAAeIgQAAIAAgsIAKAAQAGgLACgIIAFgRIABgYIAAglIA8AAIAABhIALAAIAAAsgAgIgZQAAARgDAKQgDALgGAOIApAAIAAhUIgdAAg");
  this.shape_125.setTransform(290.6, -113.275);
  this.shape_126 = new cjs.Shape();
  this.shape_126.graphics.f("#0C593C").s().p("AgSA2QgIgGgEgNQgFgNAAgWQABg6AiAAQAQAAAIAIQAIAIABANQACANAAARIg1AAQAAAQABAJQACAJAEAFQAEAGAJgBQASAAAAgbIAPAAQABAMgEAJQgEAJgHAGQgIAFgLAAQgMAAgIgFgAgOgjQgEAJAAAPIAlAAQAAgQgEgJQgDgIgMAAQgKAAgEAJg");
  this.shape_126.setTransform(281.15, -114.8);
  this.shape_127 = new cjs.Shape();
  this.shape_127.graphics.f("#0C593C").s().p("AglBNIAAiWIAPAAIAAANQAFgHAGgFQAHgDAFAAQAlAAAAA4QAAAOgCAKQgCALgEAIQgDAIgIAFQgHAEgKAAQgHAAgFgDQgGgEgFgHIAAAygAgRgxQgEAMAAAUQAAANACAJQAAAKAFAHQAFAGAJAAQALAAAGgMQAEgLAAgYQAAgrgVAAQgMAAgFANg");
  this.shape_127.setTransform(272.1, -113.05);
  this.shape_128 = new cjs.Shape();
  this.shape_128.graphics.f("#0C593C").s().p("AgVAzQgIgIgDgMQgEgNAAgRQABg7AmAAQAQAAAJALQAJAKgBARIgOAAQAAgZgTABQgNAAgEAMQgEANgBAUQAAAUAFAMQAEAMAMAAQALAAAEgHQAEgIABgNIAOAAQAAASgIAMQgIAMgRAAQgPAAgJgIg");
  this.shape_128.setTransform(262.6, -114.8);
  this.shape_129 = new cjs.Shape();
  this.shape_129.graphics.f("#0C593C").s().p("AAbA4IgaguIgbAuIgQAAIAig4Iggg3IAQAAIAZAqIAYgqIARAAIggA3IAhA4g");
  this.shape_129.setTransform(248.975, -114.8);
  this.shape_130 = new cjs.Shape();
  this.shape_130.graphics.f("#0C593C").s().p("AAkA4IAAhvIAQAAIAABvgAgzA4IAAhvIAQAAIAAAvIAXAAQAJAAAGAEQAHAEAEAHQAEAHAAAKQAAAKgEAGQgEAIgHAEQgGAEgJAAgAgjArIARAAQALAAAFgFQADgFAAgJQAAgUgSAAIgSAAg");
  this.shape_130.setTransform(238.075, -114.8);
  this.shape_131 = new cjs.Shape();
  this.shape_131.graphics.f("#0C593C").s().p("AAUA4IAAg1IgnAAIAAA1IgQAAIAAhvIAQAAIAAAvIAnAAIAAgvIAQAAIAABvg");
  this.shape_131.setTransform(226.65, -114.8);
  this.shape_132 = new cjs.Shape();
  this.shape_132.graphics.f("#0C593C").s().p("AAUA4IAAg1IgnAAIAAA1IgQAAIAAhvIAQAAIAAAvIAnAAIAAgvIAQAAIAABvg");
  this.shape_132.setTransform(216.8, -114.8);
  this.shape_133 = new cjs.Shape();
  this.shape_133.graphics.f("#0C593C").s().p("AgSA2QgIgGgEgNQgEgNgBgWQAAg6AjAAQAQAAAIAIQAIAIACANQACANAAARIg2AAQAAAQABAJQACAJAEAFQAEAGAIgBQASAAAAgbIARAAQgBAMgDAJQgDAJgJAGQgHAFgMAAQgLAAgIgFgAgOgjQgEAJAAAPIAlAAQAAgQgDgJQgEgIgMAAQgKAAgEAJg");
  this.shape_133.setTransform(207.4, -114.8);
  this.shape_134 = new cjs.Shape();
  this.shape_134.graphics.f("#0C593C").s().p("AghA4IAAhvIAjAAQAMAAAJAHQAJAIAAAMQAAAKgFAHQgEAHgJACIAAABQAKABAFAHQAGAHgBAMQABAJgEAHQgEAGgGAFQgHADgHAAgAgSArIASAAQALAAADgFQAEgEABgLQAAgJgFgFQgFgFgIAAIgTAAgAgSgIIARAAQAIAAAFgEQADgEAAgKQABgQgRAAIgRAAg");
  this.shape_134.setTransform(198.9, -114.8);
  this.shape_135 = new cjs.Shape();
  this.shape_135.graphics.f("#0C593C").s().p("AgHA4IAAhiIgdAAIAAgNIBJAAIAAANIgdAAIAABig");
  this.shape_135.setTransform(190.375, -114.8);
  this.shape_136 = new cjs.Shape();
  this.shape_136.graphics.f("#0C593C").s().p("AgVAzQgJgIgCgMQgDgNgBgRQAAg7AnAAQAQAAAJALQAJAKAAARIgPAAQgBgZgSABQgMAAgFAMQgFANAAAUQAAAUAFAMQADAMANAAQAMAAADgHQADgIACgNIAPAAQgBASgHAMQgIAMgSAAQgPAAgJgIg");
  this.shape_136.setTransform(182.25, -114.8);
  this.shape_137 = new cjs.Shape();
  this.shape_137.graphics.f("#0C593C").s().p("AglBNIAAiWIAPAAIAAANQAFgHAGgFQAHgDAFAAQAlAAAAA4QAAAOgCAKQgBALgFAIQgDAIgHAFQgIAEgKAAQgHAAgFgDQgGgEgFgHIAAAygAgRgxQgEAMAAAUQAAANACAJQAAAKAFAHQAFAGAJAAQALAAAGgMQAEgLAAgYQAAgrgVAAQgMAAgFANg");
  this.shape_137.setTransform(173.1, -113.05);
  this.shape_138 = new cjs.Shape();
  this.shape_138.graphics.f("#0C593C").s().p("AgmAcQAAgKADgGQADgHAGgEQAGgCAKgFIATgIQAEgCABgLQAAgKgFgEQgDgDgIAAQgKAAgDAEQgEAFAAAKIgPAAQAAghAhAAQAJAAAIAEQAHAEADAGQAEAHAAAIIAABBQAAAJAFAAIAEgBIAAAMQgCABgEAAQgJAAgDgDQgEgCgCgLIAAAAQgDAIgHAFQgGAFgIAAQgdAAAAgfgAABABIgMAHQgEACgEAFQgCAEAAAIQAAARAOABQAKAAAFgHIAEgEIABgGIABgKIAAgWIgNAFg");
  this.shape_138.setTransform(163.6, -114.8);
  this.shape_139 = new cjs.Shape();
  this.shape_139.graphics.f("#0C593C").s().p("AATA4Igbg4IgMAQIAAAoIgQAAIAAhvIAQAAIAAA0IAlg0IATAAIgiAsIAjBDg");
  this.shape_139.setTransform(155.475, -114.8);
  this.shape_140 = new cjs.Shape();
  this.shape_140.graphics.f("#0C593C").s().p("AgSA2QgIgGgEgNQgFgNABgWQgBg6AkAAQAPAAAHAIQAJAIABANQADANAAARIg2AAQAAAQACAJQABAJAEAFQAEAGAJgBQARAAABgbIAQAAQAAAMgEAJQgDAJgIAGQgIAFgLAAQgLAAgJgFgAgOgjQgEAJAAAPIAlAAQAAgQgEgJQgDgIgLAAQgLAAgEAJg");
  this.shape_140.setTransform(146, -114.8);
  this.shape_141 = new cjs.Shape();
  this.shape_141.graphics.f("#0C593C").s().p("AgpA3IAAgMIAGAAQAFAAADgDQACgDABgKIABgbIAAg3IBBAAIAABvIgQAAIAAhiIghAAIAAAsQAAAbgFAOQgGANgOAAQgFAAgEgBg");
  this.shape_141.setTransform(136.175, -114.775);
  this.shape_142 = new cjs.Shape();
  this.shape_142.graphics.f("#0C593C").s().p("AgSA2QgIgGgEgNQgFgNABgWQAAg6AjAAQAPAAAHAIQAJAIABANQACANABARIg2AAQAAAQACAJQABAJAEAFQAEAGAJgBQARAAABgbIAQAAQAAAMgEAJQgEAJgHAGQgIAFgLAAQgLAAgJgFgAgOgjQgEAJAAAPIAlAAQAAgQgEgJQgDgIgLAAQgLAAgEAJg");
  this.shape_142.setTransform(122.5, -114.8);
  this.shape_143 = new cjs.Shape();
  this.shape_143.graphics.f("#0C593C").s().p("AATA4Igbg4IgMAQIAAAoIgQAAIAAhvIAQAAIAAA0IAlg0IATAAIgiAsIAjBDg");
  this.shape_143.setTransform(114.475, -114.8);
  this.shape_144 = new cjs.Shape();
  this.shape_144.graphics.f("#0C593C").s().p("AAVBKIAAhUIACgOIgEAOIgkBUIgTAAIAAhvIAQAAIAABVIgCANIAEgNIAkhVIATAAIAABvgAgRg2QgGgHgBgMIAIAAQADAOAOAAQAHAAAEgDQAEgEACgHIAIAAQgBAMgHAHQgHAGgLAAQgKAAgHgGg");
  this.shape_144.setTransform(104.425, -116.625);
  this.shape_145 = new cjs.Shape();
  this.shape_145.graphics.f("#0C593C").s().p("AgSA2QgIgGgEgNQgFgNABgWQAAg6AjAAQAPAAAHAIQAJAIABANQACANAAARIg1AAQAAAQACAJQABAJAEAFQAEAGAJgBQASAAAAgbIAPAAQAAAMgDAJQgEAJgHAGQgIAFgLAAQgLAAgJgFgAgOgjQgEAJAAAPIAlAAQAAgQgEgJQgDgIgLAAQgLAAgEAJg");
  this.shape_145.setTransform(94.95, -114.8);
  this.shape_146 = new cjs.Shape();
  this.shape_146.graphics.f("#0C593C").s().p("AAUA4IAAg1IgnAAIAAA1IgQAAIAAhvIAQAAIAAAvIAnAAIAAgvIAQAAIAABvg");
  this.shape_146.setTransform(85.75, -114.8);
  this.shape_147 = new cjs.Shape();
  this.shape_147.graphics.f("#0C593C").s().p("AAVA4IAAhUIACgOIgEAOIgkBUIgTAAIAAhvIAQAAIAABUIgCAOIAEgOIAkhUIATAAIAABvg");
  this.shape_147.setTransform(75.775, -114.8);
  this.shape_148 = new cjs.Shape();
  this.shape_148.graphics.f("#0C593C").s().p("AgpA3IAAgMIAGAAQAFAAADgDQACgDABgKIABgbIAAg3IBBAAIAABvIgQAAIAAhiIghAAIAAAsQAAAbgFAOQgGANgOAAQgFAAgEgBg");
  this.shape_148.setTransform(65.225, -114.775);
  this.shape_149 = new cjs.Shape();
  this.shape_149.graphics.f("#0C593C").s().p("AgqBMIAAiWIAoAAQANAAAJAEQAJAFAFAIQAEAJAAALQAAANgFAIQgGAJgLADIAAABQAHABAHADQAGAFADAIQAEAIAAAKQAAAVgMALQgLAMgUAAgAgZA8IAZAAQANABAGgIQAGgGAAgPQAAgcgaAAIgYAAgAgZgKIAVAAQAIAAAFgCQAGgDADgFQADgHAAgJQAAgXgYAAIgWAAg");
  this.shape_149.setTransform(50.775, -116.75);
  this.shape_150 = new cjs.Shape();
  this.shape_150.graphics.f("#0C593C").s().p("AAAAKIgOASIgIgEIAPgTIgXgIIADgJIAXAJIAAgZIAJAAIAAAYIAXgIIADAKIgXAGIAPAUIgIAFg");
  this.shape_150.setTransform(40.05, -121.35);
  this.shape_151 = new cjs.Shape();
  this.shape_151.graphics.f("#0C593C").s().p("AAsBVIAAhrIAAgRIABgUIgBAAIglCQIgOAAIgliQIgBAAIABAUIABARIAABrIgRAAIAAiqIAZAAIAjCMIAAAAIAkiMIAZAAIAACqg");
  this.shape_151.setTransform(563.675, -48.4);
  this.shape_152 = new cjs.Shape();
  this.shape_152.graphics.f("#0C593C").s().p("AgfBVIAAiqIA/AAIAAASIgtAAIAAA3IAqAAIAAARIgqAAIAAA+IAtAAIAAASg");
  this.shape_152.setTransform(549.225, -48.4);
  this.shape_153 = new cjs.Shape();
  this.shape_153.graphics.f("#0C593C").s().p("AAeBVIAAhkIABgTIABgTIgBAAIg4CKIgVAAIAAiqIARAAIAABjIAAASIgBAVIABAAIA3iKIAVAAIAACqg");
  this.shape_153.setTransform(535.65, -48.4);
  this.shape_154 = new cjs.Shape();
  this.shape_154.graphics.f("#0C593C").s().p("AAaBVIAAhQIgyAAIAABQIgSAAIAAiqIASAAIAABJIAyAAIAAhJIASAAIAACqg");
  this.shape_154.setTransform(520.85, -48.4);
  this.shape_155 = new cjs.Shape();
  this.shape_155.graphics.f("#0C593C").s().p("AgfBVIAAiqIA/AAIAAASIgtAAIAAA3IAqAAIAAARIgqAAIAAA+IAtAAIAAASg");
  this.shape_155.setTransform(508.175, -48.4);
  this.shape_156 = new cjs.Shape();
  this.shape_156.graphics.f("#0C593C").s().p("AAaBVIAAhQIgzAAIAABQIgSAAIAAiqIASAAIAABJIAzAAIAAhJIASAAIAACqg");
  this.shape_156.setTransform(494.95, -48.4);
  this.shape_157 = new cjs.Shape();
  this.shape_157.graphics.f("#0C593C").s().p("AgfBVIAAiqIA/AAIAAASIgtAAIAAA3IAqAAIAAARIgqAAIAAA+IAtAAIAAASg");
  this.shape_157.setTransform(482.275, -48.4);
  this.shape_158 = new cjs.Shape();
  this.shape_158.graphics.f("#0C593C").s().p("AAsBVIAAhrIAAgRIABgUIgBAAIglCQIgOAAIgliQIgBAAIABAUIABARIAABrIgRAAIAAiqIAZAAIAjCMIAAAAIAkiMIAZAAIAACqg");
  this.shape_158.setTransform(467.225, -48.4);
  this.shape_159 = new cjs.Shape();
  this.shape_159.graphics.f("#0C593C").s().p("AAeBVIAAhkIABgTIABgTIgBAAIg4CKIgVAAIAAiqIARAAIAABjIAAASIgBAVIABAAIA3iKIAVAAIAACqg");
  this.shape_159.setTransform(450.7, -48.4);
  this.shape_160 = new cjs.Shape();
  this.shape_160.graphics.f("#0C593C").s().p("AgkBVIAAiqIAeAAQAWAAALANQAKANAAAZQAAAZgKANQgLAPgXAAIgLAAIAABCgAgSABIAJAAQAOAAAHgHQAHgJAAgSQAAgSgGgIQgHgHgNgBIgLAAg");
  this.shape_160.setTransform(437.225, -48.4);
  this.shape_161 = new cjs.Shape();
  this.shape_161.graphics.f("#0C593C").s().p("AAZBVIAAiXIgxAAIAACXIgSAAIAAiqIBVAAIAACqg");
  this.shape_161.setTransform(423.275, -48.4);
  this.shape_162 = new cjs.Shape();
  this.shape_162.graphics.f("#0C593C").s().p("AAlBsIAAguIhJAAIAAAuIgRAAIAAhAIAJAAQAMgjAHgmQAGgmABgpIA6AAIAACYIAOAAIAABAgAgGgrQgDAYgFAWQgFAVgGAUIAvAAIAAiFIgYAAQgBAWgDAYg");
  this.shape_162.setTransform(402.325, -46.1);
  this.shape_163 = new cjs.Shape();
  this.shape_163.graphics.f("#0C593C").s().p("AgfBVIAAiqIA/AAIAAASIgtAAIAAA3IAqAAIAAARIgqAAIAAA+IAtAAIAAASg");
  this.shape_163.setTransform(390.025, -48.4);
  this.shape_164 = new cjs.Shape();
  this.shape_164.graphics.f("#0C593C").s().p("AgkBVIAAiqIAeAAQAWAAALANQAKANAAAZQAAAZgKANQgLAPgXAAIgLAAIAABCgAgSABIAJAAQAOAAAHgHQAHgJAAgSQAAgSgGgIQgHgHgNgBIgLAAg");
  this.shape_164.setTransform(378.175, -48.4);
  this.shape_165 = new cjs.Shape();
  this.shape_165.graphics.f("#0C593C").s().p("AgfBVIAAiqIA/AAIAAASIgtAAIAAA3IAqAAIAAARIgqAAIAAA+IAtAAIAAASg");
  this.shape_165.setTransform(366.125, -48.4);
  this.shape_166 = new cjs.Shape();
  this.shape_166.graphics.f("#0C593C").s().p("AAZBVIAAiXIgxAAIAACXIgSAAIAAiqIBVAAIAACqg");
  this.shape_166.setTransform(352.675, -48.4);
  this.shape_167 = new cjs.Shape();
  this.shape_167.graphics.f("#0C593C").s().p("AgHAMQgDgEAAgIQAAgHADgEQADgEAEAAQAFAAADAEQADAEAAAHQAAAIgDAEQgDAEgFAAQgEAAgDgEg");
  this.shape_167.setTransform(335.175, -41.175);
  this.shape_168 = new cjs.Shape();
  this.shape_168.graphics.f("#0C593C").s().p("AAYBVIAAhHIgSAAIgbBHIgUAAIAghLQgLgFgHgLQgFgMAAgRQgBgyAsAAIAfAAIAACqgAgIg7QgGAHAAARQgBAhAZAAIAOAAIAAhBIgMAAQgOAAgGAIg");
  this.shape_168.setTransform(324.45, -48.4);
  this.shape_169 = new cjs.Shape();
  this.shape_169.graphics.f("#0C593C").s().p("AAeBVIAAhkIABgTIAAgTIAAAAIg4CKIgVAAIAAiqIARAAIAABjIgBASIgBAVIABAAIA4iKIAVAAIAACqg");
  this.shape_169.setTransform(311.05, -48.4);
  this.shape_170 = new cjs.Shape();
  this.shape_170.graphics.f("#0C593C").s().p("AAZBVIAAhQIgyAAIAABQIgSAAIAAiqIASAAIAABJIAyAAIAAhJIATAAIAACqg");
  this.shape_170.setTransform(296.25, -48.4);
  this.shape_171 = new cjs.Shape();
  this.shape_171.graphics.f("#0C593C").s().p("AAfBVIgLg1IgnAAIgMA1IgTAAIApiqIATAAIAoCqgAgCg0IgCALIgLA2IAfAAIgMg2IgCgMIgCgMIgCANg");
  this.shape_171.setTransform(282.7, -48.4);
  this.shape_172 = new cjs.Shape();
  this.shape_172.graphics.f("#0C593C").s().p("AgXBWQgIgCgHgEIAAgUQAGAEAJADQAIADAIAAQAcAAAAggQAAgQgJgJQgIgHgPAAIgNAAIAAgRIANAAQAdAAAAgfQAAgOgGgGQgFgHgKAAQgIAAgGADQgGAEgGAFIgIgOQAHgIAJgEQAJgEAMAAQARAAAKALQAJAMAAATQAAARgHALQgHAKgNAEIAAABQAPACAIAKQAHALAAARQAAAXgLANQgMAOgWAAQgJAAgIgCg");
  this.shape_172.setTransform(270.025, -48.4);
  this.shape_173 = new cjs.Shape();
  this.shape_173.graphics.f("#0C593C").s().p("AAfBVIgLg1IgnAAIgMA1IgSAAIAoiqIATAAIAoCqgAgCg0IgCALIgLA2IAfAAIgMg2IgCgMIgCgMIgCANg");
  this.shape_173.setTransform(257.85, -48.4);
  this.shape_174 = new cjs.Shape();
  this.shape_174.graphics.f("#0C593C").s().p("AAVBVIgshWIAABWIgSAAIAAiqIASAAIAABSIArhSIAUAAIgsBTIAuBXg");
  this.shape_174.setTransform(246.025, -48.4);
  this.shape_175 = new cjs.Shape();
  this.shape_175.graphics.f("#0C593C").s().p("AgcBMQgLgMgGgTQgFgUAAgZQAAgqAMgXQAOgWAYAAQARAAAMALQALAMAFAUQAGAUAAAYQAAAZgGAUQgFAUgLALQgMAMgRAAQgRAAgLgMgAgXgzQgIASAAAhQAAAiAIARQAIATAPgBQAQABAIgTQAIgRAAgiQAAghgIgSQgHgSgRAAQgPABgIARg");
  this.shape_175.setTransform(231.55, -48.4);
  this.shape_176 = new cjs.Shape();
  this.shape_176.graphics.f("#0C593C").s().p("AAZBVIAAiXIgxAAIAACXIgSAAIAAiqIBVAAIAACqg");
  this.shape_176.setTransform(216.675, -48.4);
  this.shape_177 = new cjs.Shape();
  this.shape_177.graphics.f("#0C593C").s().p("AgcBMQgMgMgEgTQgGgUAAgZQAAgqANgXQANgWAYAAQARAAAMALQALAMAFAUQAGAUAAAYQAAAZgGAUQgFAUgLALQgMAMgRAAQgRAAgLgMgAgYgzQgHASgBAhQABAiAHARQAIATAQgBQAQABAIgTQAIgRAAgiQAAghgIgSQgHgSgRAAQgQABgIARg");
  this.shape_177.setTransform(202.1, -48.4);
  this.shape_178 = new cjs.Shape();
  this.shape_178.graphics.f("#0C593C").s().p("AgnBVIAAiqIAiAAQAUABALAJQALALAAAVQAAAQgFAKQgHAKgKADIAAABQAMADAHAJQAGAJABATQAAAWgLAOQgLANgTgBgAgVBDIAUAAQALABAGgJQAGgIAAgPQAAgPgHgIQgGgIgMAAIgSAAgAgVgMIARAAQAMAAAGgGQAEgIAAgPQAAgagXAAIgQAAg");
  this.shape_178.setTransform(188.45, -48.4);
  this.shape_179 = new cjs.Shape();
  this.shape_179.graphics.f("#0C593C").s().p("AAeBVIAAhkIAAgTIABgTIgBAAIg3CKIgVAAIAAiqIARAAIAABjIgBASIgBAVIABAAIA4iKIAVAAIAACqg");
  this.shape_179.setTransform(174, -48.4);
  this.shape_180 = new cjs.Shape();
  this.shape_180.graphics.f("#0C593C").s().p("AgIBVIAAiXIggAAIAAgTIBRAAIAAATIggAAIAACXg");
  this.shape_180.setTransform(160.75, -48.4);
  this.shape_181 = new cjs.Shape();
  this.shape_181.graphics.f("#0C593C").s().p("AgcBMQgMgMgEgTQgGgUAAgZQAAgqAMgXQANgWAZAAQARAAAMALQALAMAGAUQAFAUAAAYQAAAZgFAUQgGAUgLALQgMAMgRAAQgRAAgLgMgAgXgzQgJASAAAhQAAAiAJARQAHATAQgBQAQABAIgTQAIgRAAgiQAAghgIgSQgIgSgQAAQgQABgHARg");
  this.shape_181.setTransform(147.7, -48.4);
  this.shape_182 = new cjs.Shape();
  this.shape_182.graphics.f("#0C593C").s().p("AgkBVIAAiqIAeAAQAWAAALANQAKANAAAZQAAAZgKANQgLAPgXAAIgLAAIAABCgAgSABIAJAAQAOAAAHgHQAHgJAAgSQAAgSgGgIQgHgHgNgBIgLAAg");
  this.shape_182.setTransform(134.425, -48.4);
  this.shape_183 = new cjs.Shape();
  this.shape_183.graphics.f("#0C593C").s().p("AAZBVIAAiXIgxAAIAACXIgSAAIAAiqIBVAAIAACqg");
  this.shape_183.setTransform(120.425, -48.4);
  this.shape_184 = new cjs.Shape();
  this.shape_184.graphics.f("#0C593C").s().p("AAYBVIAAhHIgSAAIgbBHIgUAAIAghLQgMgFgFgLQgHgMABgRQAAgyArAAIAfAAIAACqgAgIg7QgGAHAAARQgBAhAZAAIAOAAIAAhBIgMAAQgNAAgHAIg");
  this.shape_184.setTransform(99.55, -48.4);
  this.shape_185 = new cjs.Shape();
  this.shape_185.graphics.f("#0C593C").s().p("AgbBBQgOgYAAgpQAAgYAGgUQAGgUAMgMQAMgLARAAQAQAAAOAJIgHASIgLgHQgFgCgHAAQgMAAgHAJQgIAKgDAQQgEAPAAATQAAAhAJASQAKASAQAAQAHAAAGgCQAGgBAGgDIAAASQgMAHgPAAQgYAAgOgXg");
  this.shape_185.setTransform(87.675, -48.4);
  this.shape_186 = new cjs.Shape();
  this.shape_186.graphics.f("#0C593C").s().p("AgIBVIAAiXIggAAIAAgTIBRAAIAAATIggAAIAACXg");
  this.shape_186.setTransform(75.55, -48.4);
  this.shape_187 = new cjs.Shape();
  this.shape_187.graphics.f("#0C593C").s().p("AgNBCQgMgVgBgoIgYAAIAABQIgSAAIAAiqIASAAIAABJIAYAAQACgkAMgUQAMgTAVAAQAXAAANAXQAMAXAAApQAAAZgFAUQgFAUgLALQgKAMgRAAQgWAAgMgWgAgBgzQgHASAAAhQAAAiAHARQAHATAPgBQAPABAHgTQAHgRAAgiQAAghgHgSQgHgSgPAAQgPABgHARg");
  this.shape_187.setTransform(60.675, -48.4);
  this.shape_188 = new cjs.Shape();
  this.shape_188.graphics.f("#0C593C").s().p("AgfBVIAAiqIA/AAIAAASIgtAAIAAA3IAqAAIAAARIgqAAIAAA+IAtAAIAAASg");
  this.shape_188.setTransform(45.475, -48.4);
  this.shape_189 = new cjs.Shape();
  this.shape_189.graphics.f("#0C593C").s().p("AAsBVIAAhrIAAgRIABgUIgBAAIglCQIgOAAIgliQIgBAAIABAUIABARIAABrIgRAAIAAiqIAZAAIAjCMIAAAAIAkiMIAZAAIAACqg");
  this.shape_189.setTransform(30.425, -48.4);
  this.shape_190 = new cjs.Shape();
  this.shape_190.graphics.f("#0C593C").s().p("AAeBVIAAhkIAAgTIABgTIgBAAIg3CKIgVAAIAAiqIARAAIAABjIAAASIgCAVIACAAIA3iKIAVAAIAACqg");
  this.shape_190.setTransform(13.9, -48.4);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_190
   }, {
    t: this.shape_189
   }, {
    t: this.shape_188
   }, {
    t: this.shape_187
   }, {
    t: this.shape_186
   }, {
    t: this.shape_185
   }, {
    t: this.shape_184
   }, {
    t: this.shape_183
   }, {
    t: this.shape_182
   }, {
    t: this.shape_181
   }, {
    t: this.shape_180
   }, {
    t: this.shape_179
   }, {
    t: this.shape_178
   }, {
    t: this.shape_177
   }, {
    t: this.shape_176
   }, {
    t: this.shape_175
   }, {
    t: this.shape_174
   }, {
    t: this.shape_173
   }, {
    t: this.shape_172
   }, {
    t: this.shape_171
   }, {
    t: this.shape_170
   }, {
    t: this.shape_169
   }, {
    t: this.shape_168
   }, {
    t: this.shape_167
   }, {
    t: this.shape_166
   }, {
    t: this.shape_165
   }, {
    t: this.shape_164
   }, {
    t: this.shape_163
   }, {
    t: this.shape_162
   }, {
    t: this.shape_161
   }, {
    t: this.shape_160
   }, {
    t: this.shape_159
   }, {
    t: this.shape_158
   }, {
    t: this.shape_157
   }, {
    t: this.shape_156
   }, {
    t: this.shape_155
   }, {
    t: this.shape_154
   }, {
    t: this.shape_153
   }, {
    t: this.shape_152
   }, {
    t: this.shape_151
   }, {
    t: this.shape_150
   }, {
    t: this.shape_149
   }, {
    t: this.shape_148
   }, {
    t: this.shape_147
   }, {
    t: this.shape_146
   }, {
    t: this.shape_145
   }, {
    t: this.shape_144
   }, {
    t: this.shape_143
   }, {
    t: this.shape_142
   }, {
    t: this.shape_141
   }, {
    t: this.shape_140
   }, {
    t: this.shape_139
   }, {
    t: this.shape_138
   }, {
    t: this.shape_137
   }, {
    t: this.shape_136
   }, {
    t: this.shape_135
   }, {
    t: this.shape_134
   }, {
    t: this.shape_133
   }, {
    t: this.shape_132
   }, {
    t: this.shape_131
   }, {
    t: this.shape_130
   }, {
    t: this.shape_129
   }, {
    t: this.shape_128
   }, {
    t: this.shape_127
   }, {
    t: this.shape_126
   }, {
    t: this.shape_125
   }, {
    t: this.shape_124
   }, {
    t: this.shape_123
   }, {
    t: this.shape_122
   }, {
    t: this.shape_121
   }, {
    t: this.shape_120
   }, {
    t: this.shape_119
   }, {
    t: this.shape_118
   }, {
    t: this.shape_117
   }, {
    t: this.shape_116
   }, {
    t: this.shape_115
   }, {
    t: this.shape_114
   }, {
    t: this.shape_113
   }, {
    t: this.shape_112
   }, {
    t: this.shape_111
   }, {
    t: this.shape_110
   }, {
    t: this.shape_109
   }, {
    t: this.shape_108
   }, {
    t: this.shape_107
   }, {
    t: this.shape_106
   }, {
    t: this.shape_105
   }, {
    t: this.shape_104
   }, {
    t: this.shape_103
   }, {
    t: this.shape_102
   }, {
    t: this.shape_101
   }, {
    t: this.shape_100
   }, {
    t: this.shape_99
   }, {
    t: this.shape_98
   }, {
    t: this.shape_97
   }, {
    t: this.shape_96
   }, {
    t: this.shape_95
   }, {
    t: this.shape_94
   }, {
    t: this.shape_93
   }, {
    t: this.shape_92
   }, {
    t: this.shape_91
   }, {
    t: this.shape_90
   }, {
    t: this.shape_89
   }, {
    t: this.shape_88
   }, {
    t: this.shape_87
   }, {
    t: this.shape_86
   }, {
    t: this.shape_85
   }, {
    t: this.shape_84
   }, {
    t: this.shape_83
   }, {
    t: this.shape_82
   }, {
    t: this.shape_81
   }, {
    t: this.shape_80
   }, {
    t: this.shape_79
   }, {
    t: this.shape_78
   }, {
    t: this.shape_77
   }, {
    t: this.shape_76
   }, {
    t: this.shape_75
   }, {
    t: this.shape_74
   }, {
    t: this.shape_73
   }, {
    t: this.shape_72
   }, {
    t: this.shape_71
   }, {
    t: this.shape_70
   }, {
    t: this.shape_69
   }, {
    t: this.shape_68
   }, {
    t: this.shape_67
   }, {
    t: this.shape_66
   }, {
    t: this.shape_65
   }, {
    t: this.shape_64
   }, {
    t: this.shape_63
   }, {
    t: this.shape_62
   }, {
    t: this.shape_61
   }, {
    t: this.shape_60
   }, {
    t: this.shape_59
   }, {
    t: this.shape_58
   }, {
    t: this.shape_57
   }, {
    t: this.shape_56
   }, {
    t: this.shape_55
   }, {
    t: this.shape_54
   }, {
    t: this.shape_53
   }, {
    t: this.shape_52
   }, {
    t: this.shape_51
   }, {
    t: this.shape_50
   }, {
    t: this.shape_49
   }, {
    t: this.shape_48
   }, {
    t: this.shape_47
   }, {
    t: this.shape_46
   }, {
    t: this.shape_45
   }, {
    t: this.shape_44
   }, {
    t: this.shape_43
   }, {
    t: this.shape_42
   }, {
    t: this.shape_41
   }, {
    t: this.shape_40
   }, {
    t: this.shape_39
   }, {
    t: this.shape_38
   }, {
    t: this.shape_37
   }, {
    t: this.shape_36
   }, {
    t: this.shape_35
   }, {
    t: this.shape_34
   }, {
    t: this.shape_33
   }, {
    t: this.shape_32
   }, {
    t: this.shape_31
   }, {
    t: this.shape_30
   }, {
    t: this.shape_29
   }, {
    t: this.shape_28
   }, {
    t: this.shape_27
   }, {
    t: this.shape_26
   }, {
    t: this.shape_25
   }, {
    t: this.shape_24
   }, {
    t: this.shape_23
   }, {
    t: this.shape_22
   }, {
    t: this.shape_21
   }, {
    t: this.shape_20
   }, {
    t: this.shape_19
   }, {
    t: this.shape_18
   }, {
    t: this.shape_17
   }, {
    t: this.shape_16
   }, {
    t: this.shape_15
   }, {
    t: this.shape_14
   }, {
    t: this.shape_13
   }, {
    t: this.shape_12
   }, {
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
 }).prototype = getMCSymbolPrototype(lib.l3, new cjs.Rectangle(3, -130.2, 583, 132.89999999999998), null);
 (lib.l2 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#0C593C").s().p("AgEAGIAAgLIAJAAIAAALg");
  this.shape.setTransform(257.725, 25.275);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#0C593C").s().p("AATAgIAAg4IgQA4IgFAAIgQg4IAAA4IgJAAIAAg/IAOAAIAMApIABANIACgNIAMgpIAOAAIAAA/g");
  this.shape_1.setTransform(252.925, 22.65);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#0C593C").s().p("AgKAfQgEgDgDgIQgCgHAAgNQAAghATAAQAJAAAEAFQAFAFABAHQABAHAAAKIgeAAIABAOQABAFACADQADADAEAAQAKAAAAgPIAJAAQAAAGgCAGQgCAFgEADQgFADgGAAQgGAAgFgDgAgIgTQgCAFAAAIIAVAAQAAgJgCgFQgCgFgHAAQgFAAgDAGg");
  this.shape_2.setTransform(246.975, 22.625);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#0C593C").s().p("AAMAgIAAgwIABgIIgCAIIgUAwIgLAAIAAg/IAJAAIAAAvIgBAJIACgJIAUgvIALAAIAAA/g");
  this.shape_3.setTransform(241.775, 22.65);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#0C593C").s().p("AALAgIAAgeIgWAAIAAAeIgJAAIAAg/IAJAAIAAAbIAWAAIAAgbIAKAAIAAA/g");
  this.shape_4.setTransform(236.25, 22.65);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#0C593C").s().p("AgVAQQAAgFABgEQACgEADgCIAKgEIAKgEQADgBAAgHQAAgFgDgDQgCgCgEAAQgFAAgCADQgDADAAAFIgIAAQAAgTATAAQAFAAAEADQAEACACAEQACADAAAFIAAAlQAAAFADAAIACAAIAAAGIgEABQgEAAgCgCQgCgBgBgGIgBAAQgBAEgEADQgDADgFAAQgQAAAAgSgAABABIgHADIgEAFQgCADAAAEQAAAKAJAAQAFAAADgEIACgCIAAgEIABgGIAAgMIgHADg");
  this.shape_5.setTransform(231.075, 22.625);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#0C593C").s().p("AgTAgIAAg/IAUAAQAHAAAFAEQAFAEAAAHQAAAGgCAEQgDAEgEACQAFAAADAEQADAEAAAHQAAAFgCAEQgCAEgEACQgEACgEAAgAgJAZIAJAAQAGgBADgCQABgDAAgGQABgFgDgDQgDgDgFAAIgJAAgAgJgEIAJAAQAEAAADgDQACgCAAgGQAAgIgJgBIgJAAg");
  this.shape_6.setTransform(226.3, 22.65);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#0C593C").s().p("AgLAfQgGgDgCgIQgDgHAAgNQAAgPAFgJQAGgJALAAQAXAAAAAhQAAANgDAHQgDAIgFADQgFADgHAAQgGAAgFgDgAgHgWQgDACgBAGIgCAPIACAOQABAFADADQACADAFAAQAFAAADgDQADgDABgFIABgOIgBgPQgBgGgDgCQgDgDgFAAQgEAAgDADg");
  this.shape_7.setTransform(220.9, 22.625);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#0C593C").s().p("AgJAgQgFgDgCgFQgDgEgBgIIAJAAQABAGABADQABADACABQADABADAAQALAAAAgMQAAgFgCgDQgDgEgFAAIgFAAIAAgGIAFAAQAEAAACgDQADgDAAgFQAAgEgCgDQgDgDgFAAQgEAAgDADQgDADAAAFIgIAAQAAgFACgEQADgEAEgDQAEgDAFAAQAFAAAFADQAEACADADQACAEAAAFQAAAGgDAEQgDAEgFABIAAABQAEAAAFAEQADAEABAHQgBAGgCAEQgCAEgFADQgFACgFAAQgGAAgEgCg");
  this.shape_8.setTransform(215.75, 22.625);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#0C593C").s().p("AgVAQQAAgFABgEQACgEADgCIAKgEIAKgEQADgBAAgHQAAgFgDgDQgCgCgEAAQgFAAgCADQgDADAAAFIgIAAQAAgTATAAQAFAAAEADQAEACACAEQACADAAAFIAAAlQAAAFADAAIACAAIAAAGIgEABQgEAAgCgCQgCgBgBgGIgBAAQgBAEgEADQgDADgFAAQgQAAAAgSgAABABIgHADIgEAFQgCADAAAEQAAAKAJAAQAFAAADgEIACgCIAAgEIABgGIAAgMIgHADg");
  this.shape_9.setTransform(211.075, 22.625);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.f("#0C593C").s().p("AgVAsIAAhVIAJAAIAAAHIAAAAQADgEADgCQAEgDACAAQAWAAAAAhIgBANIgEALQgCAFgEACQgEADgGAAQgDAAgDgCQgEgCgDgEIAAAcgAgKgcQgBAIgBALIABAMQABAGACAEQAEADAEAAQAHAAACgGQADgHAAgNQAAgZgMAAQgHAAgDAHg");
  this.shape_10.setTransform(206, 23.625);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.f("#0C593C").s().p("AgNAoQgFgEgCgIQgCgJAAgNIABgRQABgIADgEQADgGAEgCQADgDAGgCIAJgDQADgCABgCIAHAAQgBAGgEADQgEADgJACQgFACgEAFQgFAEgBAJQAHgKAIAAQAHAAAEAEQAFADADAHQADAGAAAKQAAAKgDAJQgCAHgFADQgGAEgHAAQgHAAgGgEgAgJgFQgEAFAAALIABAOQACAFADADQADADAEABQAHAAADgHQADgGAAgNQAAgKgDgGQgDgGgHgBQgGABgDAGg");
  this.shape_11.setTransform(200.55, 21.6);
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.f("#0C593C").s().p("AgMAfQgFgDgDgIQgCgHAAgNQAAgPAGgJQAFgJALAAQAXAAAAAhQAAANgDAHQgDAIgEADQgGADgHAAQgHAAgFgDgAgHgWQgDACgCAGIgBAPIABAOQACAFADADQADADAEAAQAFAAADgDQADgDABgFIABgOIgBgPQgBgGgEgCQgDgDgEAAQgEAAgDADg");
  this.shape_12.setTransform(195.3, 22.625);
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.f("#0C593C").s().p("AgLAfQgFgDgEgIQgCgHAAgNQAAgPAFgJQAGgJALAAQAXAAAAAhQAAANgDAHQgDAIgEADQgGADgHAAQgHAAgEgDgAgHgWQgDACgBAGIgBAPIABAOQABAFACADQADADAFAAQAFAAADgDQADgDABgFIABgOIgBgPQgCgGgDgCQgDgDgEAAQgEAAgDADg");
  this.shape_13.setTransform(189.8, 22.625);
  this.shape_14 = new cjs.Shape();
  this.shape_14.graphics.f("#0C593C").s().p("AgKAgQgEgDgDgFQgCgEAAgIIAIAAQAAAGACADQABADACABQADABADAAQAMAAgBgMQAAgFgDgDQgCgEgGAAIgDAAIAAgGIADAAQAFAAACgDQADgDAAgFQAAgEgDgDQgCgDgFAAQgEAAgDADQgDADAAAFIgJAAQABgFACgEQACgEAFgDQAEgDAFAAQAFAAAEADQAFACADADQACAEAAAFQAAAGgDAEQgEAEgFABIAAABQAFAAAFAEQADAEAAAHQAAAGgCAEQgDAEgEADQgEACgHAAQgFAAgFgCg");
  this.shape_14.setTransform(184.65, 22.625);
  this.shape_15 = new cjs.Shape();
  this.shape_15.graphics.f("#0C593C").s().p("AgVAQQAAgFABgEQACgEADgCIAKgEIAKgEQADgBAAgHQAAgFgDgDQgCgCgEAAQgFAAgCADQgDADAAAFIgIAAQAAgTATAAQAFAAAEADQAEACACAEQACADAAAFIAAAlQAAAFADAAIACAAIAAAGIgEABQgEAAgCgCQgCgBgBgGIgBAAQgBAEgEADQgDADgFAAQgQAAAAgSgAABABIgHADIgEAFQgCADAAAEQAAAKAJAAQAFAAADgEIACgCIAAgEIABgGIAAgMIgHADg");
  this.shape_15.setTransform(179.975, 22.625);
  this.shape_16 = new cjs.Shape();
  this.shape_16.graphics.f("#0C593C").s().p("AgQAgIAAg/IAhAAIAAAHIgYAAIAAA4g");
  this.shape_16.setTransform(175.925, 22.65);
  this.shape_17 = new cjs.Shape();
  this.shape_17.graphics.f("#0C593C").s().p("AATAgIAAg4IgQA4IgFAAIgQg4IAAA4IgJAAIAAg/IAOAAIAMApIABANIACgNIAMgpIAOAAIAAA/g");
  this.shape_17.setTransform(167.375, 22.65);
  this.shape_18 = new cjs.Shape();
  this.shape_18.graphics.f("#0C593C").s().p("AAVAgIAAg/IAJAAIAAA/gAgdAgIAAg/IAKAAIAAAbIAMAAQAGAAADADQAEABACAEQACAEAAAGQAAAFgCAFQgCADgEACQgDADgGAAgAgTAZIAJAAQAGAAADgDQACgDAAgFQAAgMgKAAIgKAAg");
  this.shape_18.setTransform(160.225, 22.65);
  this.shape_19 = new cjs.Shape();
  this.shape_19.graphics.f("#0C593C").s().p("AALAgIAAgeIgVAAIAAAeIgJAAIAAg/IAJAAIAAAbIAVAAIAAgbIAJAAIAAA/g");
  this.shape_19.setTransform(153.85, 22.65);
  this.shape_20 = new cjs.Shape();
  this.shape_20.graphics.f("#0C593C").s().p("AALAgIAAgeIgVAAIAAAeIgJAAIAAg/IAJAAIAAAbIAVAAIAAgbIAJAAIAAA/g");
  this.shape_20.setTransform(148.35, 22.65);
  this.shape_21 = new cjs.Shape();
  this.shape_21.graphics.f("#0C593C").s().p("AgKAfQgEgDgDgIQgCgHAAgNQAAghATAAQAJAAAEAFQAFAFABAHQABAHAAAKIgeAAIABAOQABAFACADQADADAEAAQAKAAAAgPIAJAAQAAAGgCAGQgCAFgEADQgFADgGAAQgGAAgFgDgAgIgTQgCAFAAAIIAVAAQAAgJgCgFQgCgFgHAAQgFAAgDAGg");
  this.shape_21.setTransform(143.125, 22.625);
  this.shape_22 = new cjs.Shape();
  this.shape_22.graphics.f("#0C593C").s().p("AgiAgIAAg/IAKAAIAAA4IAUAAIAAg4IAJAAIAAA4IAUAAIAAg4IAKAAIAAA/g");
  this.shape_22.setTransform(136.575, 22.65);
  this.shape_23 = new cjs.Shape();
  this.shape_23.graphics.f("#0C593C").s().p("AAVAgIAAg/IAJAAIAAA/gAgdAgIAAg/IAKAAIAAAbIAMAAQAGAAADADQAEABACAEQACAEAAAGQAAAFgCAFQgCADgEACQgDADgGAAgAgTAZIAJAAQAGAAADgDQACgDAAgFQAAgMgKAAIgKAAg");
  this.shape_23.setTransform(128.725, 22.65);
  this.shape_24 = new cjs.Shape();
  this.shape_24.graphics.f("#0C593C").s().p("AgTAgIAAg/IAUAAQAIAAAFAEQAEAEAAAHQAAAGgDAEQgCAEgFACQAGAAACAEQAEAEAAAHQAAAFgDAEQgCAEgDACQgEACgEAAgAgKAZIAKAAQAGgBACgCQACgDABgGQAAgFgDgDQgDgDgFAAIgKAAgAgKgEIAKAAQAEAAACgDQADgCAAgGQAAgIgJgBIgKAAg");
  this.shape_24.setTransform(122.75, 22.65);
  this.shape_25 = new cjs.Shape();
  this.shape_25.graphics.f("#0C593C").s().p("AgMAfQgEgDgEgIQgCgHAAgNQAAgPAFgJQAGgJALAAQAXAAAAAhQAAANgDAHQgDAIgEADQgGADgHAAQgHAAgFgDgAgHgWQgDACgCAGIAAAPIAAAOQACAFACADQADADAFAAQAFAAADgDQADgDABgFIABgOIgBgPQgCgGgDgCQgDgDgEAAQgEAAgDADg");
  this.shape_25.setTransform(117.35, 22.625);
  this.shape_26 = new cjs.Shape();
  this.shape_26.graphics.f("#0C593C").s().p("AALAgIAAg4IgWAAIAAA4IgJAAIAAg/IApAAIAAA/g");
  this.shape_26.setTransform(111.85, 22.65);
  this.shape_27 = new cjs.Shape();
  this.shape_27.graphics.f("#0C593C").s().p("AAMAqIAAgvIABgIIgCAIIgUAvIgLAAIAAg/IAJAAIAAAxIgBAHIACgHIAUgxIALAAIAAA/gAgJgfQgEgDAAgHIAEAAQACAHAHABQAFAAACgCQACgCABgEIAFAAQAAAHgEADQgFAEgGAAQgFAAgEgEg");
  this.shape_27.setTransform(103.625, 21.6);
  this.shape_28 = new cjs.Shape();
  this.shape_28.graphics.f("#0C593C").s().p("AgMAfQgFgDgDgIQgCgHAAgNQAAgPAGgJQAFgJALAAQAXAAAAAhQAAANgDAHQgDAIgEADQgGADgHAAQgHAAgFgDgAgHgWQgDACgCAGIAAAPIAAAOQACAFADADQADADAEAAQAFAAADgDQADgDABgFIABgOIgBgPQgBgGgEgCQgDgDgEAAQgEAAgDADg");
  this.shape_28.setTransform(98.1, 22.625);
  this.shape_29 = new cjs.Shape();
  this.shape_29.graphics.f("#0C593C").s().p("AALAgIAAgeIgWAAIAAAeIgJAAIAAg/IAJAAIAAAbIAWAAIAAgbIAKAAIAAA/g");
  this.shape_29.setTransform(92.6, 22.65);
  this.shape_30 = new cjs.Shape();
  this.shape_30.graphics.f("#0C593C").s().p("AALAgIAAgeIgWAAIAAAeIgJAAIAAg/IAJAAIAAAbIAWAAIAAgbIAKAAIAAA/g");
  this.shape_30.setTransform(87.1, 22.65);
  this.shape_31 = new cjs.Shape();
  this.shape_31.graphics.f("#0C593C").s().p("AgVAQQAAgFABgEQACgEADgCIAKgEIAKgEQADgBAAgHQAAgFgDgDQgCgCgEAAQgFAAgCADQgDADAAAFIgIAAQAAgTATAAQAFAAAEADQAEACACAEQACADAAAFIAAAlQAAAFADAAIACAAIAAAGIgEABQgEAAgCgCQgCgBgBgGIgBAAQgBAEgEADQgDADgFAAQgQAAAAgSgAABABIgHADIgEAFQgCADAAAEQAAAKAJAAQAFAAADgEIACgCIAAgEIABgGIAAgMIgHADg");
  this.shape_31.setTransform(81.925, 22.625);
  this.shape_32 = new cjs.Shape();
  this.shape_32.graphics.f("#0C593C").s().p("AgTAgIAAg/IAUAAQAIAAAEAEQAFAEAAAHQAAAGgDAEQgCAEgEACQAEAAAEAEQADAEAAAHQAAAFgCAEQgCAEgEACQgEACgEAAgAgJAZIAJAAQAGgBADgCQACgDAAgGQgBgFgCgDQgDgDgEAAIgKAAgAgJgEIAJAAQAEAAACgDQADgCAAgGQAAgIgJgBIgJAAg");
  this.shape_32.setTransform(77.15, 22.65);
  this.shape_33 = new cjs.Shape();
  this.shape_33.graphics.f("#0C593C").s().p("AgKAgQgEgDgCgFQgDgEgBgIIAJAAQABAGABADQABADADABQACABADAAQAMAAAAgMQAAgFgDgDQgDgEgFAAIgFAAIAAgGIAFAAQAEAAACgDQADgDAAgFQAAgEgDgDQgCgDgFAAQgFAAgCADQgDADAAAFIgJAAQAAgFADgEQADgEAEgDQAEgDAFAAQAGAAAEADQAEACACADQADAEAAAFQAAAGgDAEQgDAEgGABIAAABQAGAAADAEQAFAEAAAHQgBAGgCAEQgCAEgFADQgFACgFAAQgGAAgFgCg");
  this.shape_33.setTransform(72.1, 22.625);
  this.shape_34 = new cjs.Shape();
  this.shape_34.graphics.f("#0C593C").s().p("AAVAgIAAg/IAJAAIAAA/gAgdAgIAAg/IAKAAIAAAbIAMAAQAGAAADADQAEABACAEQACAEAAAGQAAAFgCAFQgCADgEACQgDADgGAAgAgTAZIAJAAQAGAAADgDQACgDAAgFQAAgMgKAAIgKAAg");
  this.shape_34.setTransform(66.175, 22.65);
  this.shape_35 = new cjs.Shape();
  this.shape_35.graphics.f("#0C593C").s().p("AgTAgIAAg/IAUAAQAIAAAFAEQAEAEAAAHQAAAGgDAEQgCAEgFACQAGAAACAEQAEAEAAAHQAAAFgDAEQgCAEgDACQgEACgEAAgAgKAZIAKAAQAGgBACgCQACgDABgGQAAgFgDgDQgDgDgFAAIgKAAgAgKgEIAKAAQAEAAACgDQADgCAAgGQAAgIgJgBIgKAAg");
  this.shape_35.setTransform(60.2, 22.65);
  this.shape_36 = new cjs.Shape();
  this.shape_36.graphics.f("#0C593C").s().p("AgEAJQAFgCAAgJIgFAAIAAgLIAJAAIAAANQAAAEgCAFQgDAEgEABg");
  this.shape_36.setTransform(53.525, 26.125);
  this.shape_37 = new cjs.Shape();
  this.shape_37.graphics.f("#0C593C").s().p("AAMAgIAAgwIABgIIgCAIIgUAwIgLAAIAAg/IAJAAIAAAvIgBAJIACgJIAUgvIALAAIAAA/g");
  this.shape_37.setTransform(49.425, 22.65);
  this.shape_38 = new cjs.Shape();
  this.shape_38.graphics.f("#0C593C").s().p("AgXAfIAAgHIAEABQAAAAABAAQABgBAAAAQABAAAAAAQAAgBABAAIACgHIAAgQIAAgfIAlAAIAAA/IgJAAIAAg4IgTAAIAAAZQAAAPgDAIQgDAIgIAAIgFgBg");
  this.shape_38.setTransform(43.575, 22.675);
  this.shape_39 = new cjs.Shape();
  this.shape_39.graphics.f("#0C593C").s().p("AgLAfQgGgDgCgIQgDgHAAgNQAAgPAFgJQAGgJALAAQAXAAAAAhQAAANgDAHQgCAIgFADQgGADgHAAQgHAAgEgDgAgHgWQgDACgBAGIgBAPIABAOQABAFACADQADADAFAAQAFAAADgDQADgDABgFIABgOIgBgPQgCgGgDgCQgCgDgFAAQgEAAgDADg");
  this.shape_39.setTransform(38.4, 22.625);
  this.shape_40 = new cjs.Shape();
  this.shape_40.graphics.f("#0C593C").s().p("AgYArIAAhVIAqAAIAAAIIggAAIAAAdIAMAAIAKABQAFABAEADQADACADAFQACAFAAAHQAAAMgIAGQgGAGgLAAgAgOAjIALAAQAIAAAFgEQAFgDAAgJQAAgHgDgDQgCgEgFgBQgEgCgHAAIgIAAg");
  this.shape_40.setTransform(32.9, 21.525);
  this.shape_41 = new cjs.Shape();
  this.shape_41.graphics.f("#0C593C").s().p("AAAAFIgHALIgFgCIAIgLIgNgFIACgEIANAEIAAgOIAFAAIAAAOIANgEIACAFIgNAEIAIALIgEADg");
  this.shape_41.setTransform(26.925, 18.9);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_41
   }, {
    t: this.shape_40
   }, {
    t: this.shape_39
   }, {
    t: this.shape_38
   }, {
    t: this.shape_37
   }, {
    t: this.shape_36
   }, {
    t: this.shape_35
   }, {
    t: this.shape_34
   }, {
    t: this.shape_33
   }, {
    t: this.shape_32
   }, {
    t: this.shape_31
   }, {
    t: this.shape_30
   }, {
    t: this.shape_29
   }, {
    t: this.shape_28
   }, {
    t: this.shape_27
   }, {
    t: this.shape_26
   }, {
    t: this.shape_25
   }, {
    t: this.shape_24
   }, {
    t: this.shape_23
   }, {
    t: this.shape_22
   }, {
    t: this.shape_21
   }, {
    t: this.shape_20
   }, {
    t: this.shape_19
   }, {
    t: this.shape_18
   }, {
    t: this.shape_17
   }, {
    t: this.shape_16
   }, {
    t: this.shape_15
   }, {
    t: this.shape_14
   }, {
    t: this.shape_13
   }, {
    t: this.shape_12
   }, {
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
 }).prototype = getMCSymbolPrototype(lib.l2, new cjs.Rectangle(0, 13, 283, 17.4), null);
 (lib.l1_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#0C593C").s().p("AgJALIAAgVIASAAIAAAVg");
  this.shape.setTransform(506.6, -171.1);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#0C593C").s().p("AAkA7IAAhnIgeBnIgLAAIgehnIAABnIgQAAIAAh1IAaAAIAWBNIADAYIAEgYIAWhNIAaAAIAAB1g");
  this.shape_1.setTransform(497.3, -175.925);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#0C593C").s().p("AgTA4QgIgGgFgNQgEgOAAgXQAAg9AkAAQAQAAAJAJQAIAJACANQACANAAASIg4AAIABAaQACAKAEAFQAFAGAIAAQATAAAAgcIARAAQAAALgEAKQgDAKgIAFQgJAGgLAAQgMAAgJgGgAgPglQgEAKAAAQIAnAAQAAgRgEgJQgEgKgLAAQgMAAgEAKg");
  this.shape_2.setTransform(485.925, -175.925);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#0C593C").s().p("AAWA7IAAhYIACgPIgEAPIglBYIgVAAIAAh1IARAAIAABZIgCAOIAEgOIAmhZIAUAAIAAB1g");
  this.shape_3.setTransform(475.95, -175.925);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#0C593C").s().p("AAUA7IAAg3IgoAAIAAA3IgQAAIAAh1IAQAAIAAAxIAoAAIAAgxIARAAIAAB1g");
  this.shape_4.setTransform(465.35, -175.925);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#0C593C").s().p("AgoAdQAAgKADgGQADgHAGgEQAHgEALgEIATgJQAFgCAAgMQAAgKgEgEQgEgEgJAAQgJAAgEAFQgEAGAAAKIgPAAQAAgjAiAAQAKAAAHAEQAIAEADAHQAEAHAAAIIAABEQAAAKAGAAIAEgBIAAANQgDABgEAAQgJAAgDgDQgEgDgCgLIgBAAQgDAIgHAFQgGAGgJAAQgeAAAAghgAABABIgMAHQgFADgDAFQgDAFAAAIQAAASAPAAQAKAAAGgHIADgEIABgGIABgMIAAgWIgNAFg");
  this.shape_5.setTransform(455.425, -175.925);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#0C593C").s().p("AgjA7IAAh1IAlAAQANAAAJAIQAKAIAAAMQAAALgGAIQgEAHgJACIAAABQAKABAGAIQAFAHAAAMQAAAKgEAHQgEAHgGAEQgHAEgIAAgAgTAtIATAAQALAAAEgFQAEgFAAgLQAAgKgFgFQgEgFgJAAIgUAAgAgTgIIASAAQAJAAAEgFQAFgEAAgKQAAgRgRAAIgTAAg");
  this.shape_6.setTransform(446.225, -175.925);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#0C593C").s().p("AgWA4QgJgGgFgNQgFgOAAgXQAAgeAKgPQALgQAUAAQAqAAAAA9QAAAXgFAOQgFANgJAGQgJAGgOAAQgMAAgKgGgAgNgqQgGAFgCALQgDAKAAARQAAAPADAKQACALAFAFQAGAGAIAAQAKAAAFgGQAFgFADgLQACgKAAgPQAAgRgDgLQgCgKgGgFQgFgFgJAAQgIAAgFAFg");
  this.shape_7.setTransform(435.825, -175.925);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#0C593C").s().p("AgTA6QgIgFgEgJQgFgIgBgOIAQAAQABAKACAFQADAGAEACQAEADAHAAQAVAAAAgWQAAgKgGgGQgFgGgJAAIgIAAIAAgMIAIAAQAHAAAFgGQAFgGAAgJQAAgHgFgGQgEgFgJAAQgJAAgFAGQgFAFgBAKIgPAAQAAgKAFgHQAEgIAIgFQAIgFAKAAQAKAAAIAEQAHAEAFAHQAEAGAAAJQAAALgFAHQgGAIgJADQAJACAHAGQAIAIAAANQAAAKgFAIQgEAIgJAEQgIAFgMAAQgLAAgIgEg");
  this.shape_8.setTransform(425.975, -175.925);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#0C593C").s().p("AgoAdQAAgKADgGQADgHAGgEQAHgEALgEIATgJQAFgCAAgMQAAgKgEgEQgEgEgJAAQgJAAgEAFQgEAGAAAKIgPAAQAAgjAiAAQAKAAAHAEQAIAEADAHQAEAHAAAIIAABEQAAAKAGAAIAEgBIAAANQgDABgEAAQgJAAgDgDQgEgDgCgLIgBAAQgDAIgHAFQgGAGgJAAQgeAAAAghgAABABIgMAHQgFADgDAFQgDAFAAAIQAAASAPAAQAKAAAGgHIADgEIABgGIABgMIAAgWIgNAFg");
  this.shape_9.setTransform(416.925, -175.925);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.f("#0C593C").s().p("AgnBQIAAicIARAAIAAANQAEgIAHgEQAHgEAFAAQAnAAAAA8QAAAOgCAKQgCAMgEAIQgEAJgHAFQgIAEgKAAQgIAAgGgDQgGgEgFgIIAAA0gAgSg0QgEANAAAVQAAAOACAKQABAKAFAHQAFAGAJAAQAMAAAFgMQAFgNAAgXQAAgugWAAQgNAAgFANg");
  this.shape_10.setTransform(407.125, -174.075);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.f("#0C593C").s().p("AgYBJQgJgIgEgPQgEgPAAgYQAAgSACgOQADgOAFgJQAFgJAHgGQAHgFAJgDIASgGQAGgCABgFIAOAAQgCALgIAGQgJAFgOAEQgMACgHAKQgIAJgBAPQAKgSARAAQANAAAJAHQAJAGAEANQAFAMAAARQAAAVgEANQgFAOgJAHQgKAHgOAAQgPAAgJgIgAgRgKQgHAKAAATQAAAQADALQACAKAGAFQAFAGAIAAQANAAAGgMQAGgMAAgYQAAgTgHgKQgGgMgMAAQgLAAgGAMg");
  this.shape_11.setTransform(396.625, -177.825);
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.f("#0C593C").s().p("AgWA4QgJgGgFgNQgFgOAAgXQAAgeAKgPQALgQAUAAQAqAAAAA9QAAAXgFAOQgFANgJAGQgJAGgOAAQgMAAgKgGgAgNgqQgGAFgCALQgDAKAAARQAAAPADAKQACALAFAFQAGAGAIAAQAKAAAFgGQAFgFADgLQACgKAAgPQAAgRgDgLQgCgKgGgFQgFgFgJAAQgIAAgFAFg");
  this.shape_12.setTransform(386.525, -175.925);
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.f("#0C593C").s().p("AgWA4QgJgGgFgNQgFgOAAgXQAAgeAKgPQALgQAUAAQAqAAAAA9QAAAXgFAOQgFANgJAGQgJAGgOAAQgMAAgKgGgAgNgqQgGAFgCALQgDAKAAARQAAAPADAKQACALAFAFQAGAGAIAAQAKAAAFgGQAFgFADgLQACgKAAgPQAAgRgDgLQgCgKgGgFQgFgFgJAAQgIAAgFAFg");
  this.shape_13.setTransform(375.975, -175.925);
  this.shape_14 = new cjs.Shape();
  this.shape_14.graphics.f("#0C593C").s().p("AgTA6QgIgFgEgJQgFgIgBgOIAQAAQABAKACAFQADAGAEACQAEADAHAAQAVAAAAgWQAAgKgGgGQgFgGgJAAIgIAAIAAgMIAIAAQAHAAAFgGQAFgGAAgJQAAgHgFgGQgEgFgJAAQgJAAgFAGQgFAFgBAKIgPAAQAAgKAFgHQAEgIAIgFQAIgFAKAAQAKAAAIAEQAHAEAFAHQAEAGAAAJQAAALgFAHQgGAIgJADQAJACAHAGQAIAIAAANQAAAKgFAIQgEAIgJAEQgIAFgMAAQgLAAgIgEg");
  this.shape_14.setTransform(366.125, -175.925);
  this.shape_15 = new cjs.Shape();
  this.shape_15.graphics.f("#0C593C").s().p("AgoAdQAAgKADgGQADgHAGgEQAHgEALgEIATgJQAFgCAAgMQAAgKgEgEQgEgEgJAAQgJAAgEAFQgEAGAAAKIgPAAQAAgjAiAAQAKAAAHAEQAIAEADAHQAEAHAAAIIAABEQAAAKAGAAIAEgBIAAANQgDABgEAAQgJAAgDgDQgEgDgCgLIgBAAQgDAIgHAFQgGAGgJAAQgeAAAAghgAABABIgMAHQgFADgDAFQgDAFAAAIQAAASAPAAQAKAAAGgHIADgEIABgGIABgMIAAgWIgNAFg");
  this.shape_15.setTransform(357.075, -175.925);
  this.shape_16 = new cjs.Shape();
  this.shape_16.graphics.f("#0C593C").s().p("AgeA7IAAh1IA9AAIAAAOIgsAAIAABng");
  this.shape_16.setTransform(349.2, -175.925);
  this.shape_17 = new cjs.Shape();
  this.shape_17.graphics.f("#0C593C").s().p("AAjA7IAAhnIgdBnIgLAAIgehnIAABnIgQAAIAAh1IAaAAIAWBNIADAYIAEgYIAWhNIAaAAIAAB1g");
  this.shape_17.setTransform(332.6, -175.925);
  this.shape_18 = new cjs.Shape();
  this.shape_18.graphics.f("#0C593C").s().p("AAmA7IAAh1IAQAAIAAB1gAg1A7IAAh1IAQAAIAAAyIAYAAQAKAAAGAEQAHAEAFAIQAEAHAAAKQAAAKgFAIQgEAHgHAFQgGAEgKAAgAglAtIASAAQALAAAFgFQAFgFAAgKQAAgVgUAAIgTAAg");
  this.shape_18.setTransform(319.025, -175.925);
  this.shape_19 = new cjs.Shape();
  this.shape_19.graphics.f("#0C593C").s().p("AAUA7IAAg3IgoAAIAAA3IgQAAIAAh1IAQAAIAAAxIAoAAIAAgxIARAAIAAB1g");
  this.shape_19.setTransform(306.85, -175.925);
  this.shape_20 = new cjs.Shape();
  this.shape_20.graphics.f("#0C593C").s().p("AAVA7IAAg3IgpAAIAAA3IgQAAIAAh1IAQAAIAAAxIApAAIAAgxIARAAIAAB1g");
  this.shape_20.setTransform(296.3, -175.925);
  this.shape_21 = new cjs.Shape();
  this.shape_21.graphics.f("#0C593C").s().p("AgTA4QgIgGgFgNQgEgOAAgXQAAg9AkAAQAQAAAJAJQAIAJACANQACANAAASIg4AAIABAaQACAKAEAFQAFAGAIAAQATAAAAgcIARAAQAAALgEAKQgDAKgIAFQgJAGgLAAQgMAAgJgGgAgPglQgEAKAAAQIAnAAQAAgRgEgJQgEgKgLAAQgMAAgEAKg");
  this.shape_21.setTransform(286.275, -175.925);
  this.shape_22 = new cjs.Shape();
  this.shape_22.graphics.f("#0C593C").s().p("Ag+A7IAAh1IARAAIAABnIAmAAIAAhnIAQAAIAABnIAmAAIAAhnIARAAIAAB1g");
  this.shape_22.setTransform(273.8, -175.925);
  this.shape_23 = new cjs.Shape();
  this.shape_23.graphics.f("#0C593C").s().p("AAmA7IAAh1IAQAAIAAB1gAg1A7IAAh1IAQAAIAAAyIAYAAQAKAAAGAEQAHAEAFAIQAEAHAAAKQAAAKgFAIQgEAHgHAFQgGAEgKAAgAglAtIASAAQALAAAFgFQAFgFAAgKQAAgVgUAAIgTAAg");
  this.shape_23.setTransform(258.925, -175.925);
  this.shape_24 = new cjs.Shape();
  this.shape_24.graphics.f("#0C593C").s().p("AgjA7IAAh1IAlAAQANAAAJAIQAKAIAAAMQAAALgGAIQgEAHgJACIAAABQAKABAGAIQAFAHAAAMQAAAKgEAHQgEAHgGAEQgHAEgIAAgAgTAtIATAAQALAAAEgFQAEgFAAgLQAAgKgFgFQgEgFgJAAIgUAAgAgTgIIASAAQAJAAAEgFQAFgEAAgKQAAgRgRAAIgTAAg");
  this.shape_24.setTransform(247.525, -175.925);
  this.shape_25 = new cjs.Shape();
  this.shape_25.graphics.f("#0C593C").s().p("AgWA4QgJgGgFgNQgFgOAAgXQAAgeAKgPQALgQAUAAQAqAAAAA9QAAAXgFAOQgFANgJAGQgJAGgOAAQgMAAgKgGgAgNgqQgGAFgCALQgDAKAAARQAAAPADAKQACALAFAFQAGAGAIAAQAKAAAFgGQAFgFADgLQACgKAAgPQAAgRgDgLQgCgKgGgFQgFgFgJAAQgIAAgFAFg");
  this.shape_25.setTransform(237.125, -175.925);
  this.shape_26 = new cjs.Shape();
  this.shape_26.graphics.f("#0C593C").s().p("AAVA7IAAhnIgpAAIAABnIgRAAIAAh1IBKAAIAAB1g");
  this.shape_26.setTransform(226.6, -175.925);
  this.shape_27 = new cjs.Shape();
  this.shape_27.graphics.f("#0C593C").s().p("AAXBOIAAhYIABgPIgEAPIglBYIgVAAIAAh1IARAAIAABZIgCAOIAEgOIAmhZIAUAAIAAB1gAgRg5QgIgHAAgNIAIAAQAEAPAOAAQAHAAAEgDQAFgEABgIIAJAAQAAANgIAHQgHAGgMAAQgKAAgHgGg");
  this.shape_27.setTransform(210.65, -177.825);
  this.shape_28 = new cjs.Shape();
  this.shape_28.graphics.f("#0C593C").s().p("AgWA4QgJgGgFgNQgFgOAAgXQAAgeAKgPQALgQAUAAQAqAAAAA9QAAAXgFAOQgFANgJAGQgJAGgOAAQgMAAgKgGgAgNgqQgGAFgCALQgDAKAAARQAAAPADAKQACALAFAFQAGAGAIAAQAKAAAFgGQAFgFADgLQACgKAAgPQAAgRgDgLQgCgKgGgFQgFgFgJAAQgIAAgFAFg");
  this.shape_28.setTransform(200.025, -175.925);
  this.shape_29 = new cjs.Shape();
  this.shape_29.graphics.f("#0C593C").s().p("AAUA7IAAg3IgoAAIAAA3IgQAAIAAh1IAQAAIAAAxIAoAAIAAgxIARAAIAAB1g");
  this.shape_29.setTransform(189.5, -175.925);
  this.shape_30 = new cjs.Shape();
  this.shape_30.graphics.f("#0C593C").s().p("AAUA7IAAg3IgoAAIAAA3IgQAAIAAh1IAQAAIAAAxIAoAAIAAgxIARAAIAAB1g");
  this.shape_30.setTransform(178.95, -175.925);
  this.shape_31 = new cjs.Shape();
  this.shape_31.graphics.f("#0C593C").s().p("AgoAdQAAgKADgGQADgHAGgEQAHgEALgEIATgJQAFgCAAgMQAAgKgEgEQgEgEgJAAQgJAAgEAFQgEAGAAAKIgPAAQAAgjAiAAQAKAAAHAEQAIAEADAHQAEAHAAAIIAABEQAAAKAGAAIAEgBIAAANQgDABgEAAQgJAAgDgDQgEgDgCgLIgBAAQgDAIgHAFQgGAGgJAAQgeAAAAghgAABABIgMAHQgFADgDAFQgDAFAAAIQAAASAPAAQAKAAAGgHIADgEIABgGIABgMIAAgWIgNAFg");
  this.shape_31.setTransform(169.025, -175.925);
  this.shape_32 = new cjs.Shape();
  this.shape_32.graphics.f("#0C593C").s().p("AgjA7IAAh1IAlAAQANAAAJAIQAKAIAAAMQAAALgGAIQgEAHgJACIAAABQAKABAGAIQAFAHAAAMQAAAKgEAHQgEAHgGAEQgHAEgIAAgAgTAtIATAAQALAAAEgFQAEgFAAgLQAAgKgFgFQgEgFgJAAIgUAAgAgTgIIASAAQAJAAAEgFQAFgEAAgKQAAgRgRAAIgTAAg");
  this.shape_32.setTransform(159.825, -175.925);
  this.shape_33 = new cjs.Shape();
  this.shape_33.graphics.f("#0C593C").s().p("AgTA6QgIgFgEgJQgFgIgBgOIAQAAQABAKACAFQADAGAEACQAEADAHAAQAVAAAAgWQAAgKgGgGQgFgGgJAAIgIAAIAAgMIAIAAQAHAAAFgGQAFgGAAgJQAAgHgFgGQgEgFgJAAQgJAAgFAGQgFAFgBAKIgPAAQAAgKAFgHQAEgIAIgFQAIgFAKAAQAKAAAIAEQAHAEAFAHQAEAGAAAJQAAALgFAHQgGAIgJADQAJACAHAGQAIAIAAANQAAAKgFAIQgEAIgJAEQgIAFgMAAQgLAAgIgEg");
  this.shape_33.setTransform(150.125, -175.925);
  this.shape_34 = new cjs.Shape();
  this.shape_34.graphics.f("#0C593C").s().p("AAmA7IAAh1IAQAAIAAB1gAg1A7IAAh1IAQAAIAAAyIAYAAQAKAAAGAEQAHAEAFAIQAEAHAAAKQAAAKgFAIQgEAHgHAFQgGAEgKAAgAglAtIASAAQALAAAFgFQAFgFAAgKQAAgVgUAAIgTAAg");
  this.shape_34.setTransform(138.775, -175.925);
  this.shape_35 = new cjs.Shape();
  this.shape_35.graphics.f("#0C593C").s().p("AgjA7IAAh1IAlAAQANAAAJAIQAKAIAAAMQAAALgGAIQgEAHgJACIAAABQAKABAGAIQAFAHAAAMQAAAKgEAHQgEAHgGAEQgHAEgIAAgAgTAtIATAAQALAAAEgFQAEgFAAgLQAAgKgFgFQgEgFgJAAIgUAAgAgTgIIASAAQAJAAAEgFQAFgEAAgKQAAgRgRAAIgTAAg");
  this.shape_35.setTransform(127.375, -175.925);
  this.shape_36 = new cjs.Shape();
  this.shape_36.graphics.f("#0C593C").s().p("AgJAQQAKgDAAgRIgKAAIAAgVIATAAIAAAZQgBAIgEAHQgFAIgJADg");
  this.shape_36.setTransform(114.3, -169.55);
  this.shape_37 = new cjs.Shape();
  this.shape_37.graphics.f("#0C593C").s().p("AAWA7IAAhYIACgPIgDAPIgmBYIgVAAIAAh1IARAAIAABZIgCAOIAEgOIAmhZIAUAAIAAB1g");
  this.shape_37.setTransform(106.3, -175.925);
  this.shape_38 = new cjs.Shape();
  this.shape_38.graphics.f("#0C593C").s().p("AgsA5IAAgMIAHAAQAFAAADgDQADgDABgLIABgcIAAg6IBEAAIAAB1IgRAAIAAhnIgjAAIAAAtQAAAdgFAOQgGAPgPAAQgFAAgFgCg");
  this.shape_38.setTransform(95.1, -175.9);
  this.shape_39 = new cjs.Shape();
  this.shape_39.graphics.f("#0C593C").s().p("AgWA4QgJgGgFgNQgFgOAAgXQAAgeAKgPQALgQAUAAQAqAAAAA9QAAAXgFAOQgFANgJAGQgJAGgOAAQgMAAgKgGgAgNgqQgGAFgCALQgDAKAAARQAAAPADAKQACALAFAFQAGAGAIAAQAKAAAFgGQAFgFADgLQACgKAAgPQAAgRgDgLQgCgKgGgFQgFgFgJAAQgIAAgFAFg");
  this.shape_39.setTransform(85.125, -175.925);
  this.shape_40 = new cjs.Shape();
  this.shape_40.graphics.f("#0C593C").s().p("AgsBPIAAidIBOAAIAAAQIg8AAIAAAzIAVAAQAKAAAJACQAJADAHAFQAHAEAEAJQAEAJAAAOQAAAWgNALQgNALgVAAgAgaA/IAUAAQAQAAAIgGQAIgGAAgQQAAgNgEgGQgEgHgJgCQgIgDgMAAIgPAAg");
  this.shape_40.setTransform(74.625, -177.975);
  this.shape_41 = new cjs.Shape();
  this.shape_41.graphics.f("#0C593C").s().p("AAAAKIgPAUIgJgGIAQgTIgYgJIADgJIAZAJIAAgaIAKAAIAAAaIAXgJIADAKIgXAHIAPAUIgIAHg");
  this.shape_41.setTransform(63.2, -182.775);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_41
   }, {
    t: this.shape_40
   }, {
    t: this.shape_39
   }, {
    t: this.shape_38
   }, {
    t: this.shape_37
   }, {
    t: this.shape_36
   }, {
    t: this.shape_35
   }, {
    t: this.shape_34
   }, {
    t: this.shape_33
   }, {
    t: this.shape_32
   }, {
    t: this.shape_31
   }, {
    t: this.shape_30
   }, {
    t: this.shape_29
   }, {
    t: this.shape_28
   }, {
    t: this.shape_27
   }, {
    t: this.shape_26
   }, {
    t: this.shape_25
   }, {
    t: this.shape_24
   }, {
    t: this.shape_23
   }, {
    t: this.shape_22
   }, {
    t: this.shape_21
   }, {
    t: this.shape_20
   }, {
    t: this.shape_19
   }, {
    t: this.shape_18
   }, {
    t: this.shape_17
   }, {
    t: this.shape_16
   }, {
    t: this.shape_15
   }, {
    t: this.shape_14
   }, {
    t: this.shape_13
   }, {
    t: this.shape_12
   }, {
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
 }).prototype = getMCSymbolPrototype(lib.l1_1, new cjs.Rectangle(-6.4, -192, 580, 28.5), null);
 (lib.l1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#0C593C").s().p("AAVA4IAAhUIACgOIgEAOIgkBUIgTAAIAAhvIAQAAIAABUIgCAOIAEgOIAkhUIATAAIAABvg");
  this.shape.setTransform(379.075, -177.15);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#0C593C").s().p("AgpA3IAAgMIAGAAQAFAAADgDQACgDABgKIABgbIAAg3IBBAAIAABvIgQAAIAAhiIghAAIAAAsQAAAbgFAOQgGANgOAAQgFAAgEgBg");
  this.shape_1.setTransform(368.325, -177.125);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#0C593C").s().p("AgVA1QgIgFgFgNQgFgNAAgWQAAgcAKgPQAKgPATAAQAoAAAAA6QAAAWgEANQgFANgJAFQgJAGgNAAQgMAAgJgGgAgNgoQgFAEgCALQgCAKAAAQQAAAPACAJQACAKAFAFQAFAGAIgBQAJABAFgGQAGgFACgKQACgJAAgPQAAgQgDgLQgCgKgFgEQgFgEgJgBQgHABgGAEg");
  this.shape_2.setTransform(358.775, -177.15);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#0C593C").s().p("AgWBGQgJgIgEgPQgEgOAAgXQAAgRACgNQADgNAEgKQAFgIAHgFQAGgFAJgDIASgGQAGgCABgEIANAAQgDALgHAEQgIAGgOADQgLACgHAKQgHAIgBAPQAJgSARAAQALABAJAGQAIAHAFALQAEALAAARQAAATgEAOQgEANgJAGQgJAHgOAAQgOAAgIgHgAgQgKQgGAKAAASQAAAPACAKQADAKAFAGQAFAEAHAAQANAAAFgLQAGgLAAgXQAAgSgGgKQgGgLgMAAQgKAAgGALg");
  this.shape_3.setTransform(348.925, -178.95);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#0C593C").s().p("AAVA4IAAhUIACgOIgEAOIgkBUIgTAAIAAhvIAQAAIAABUIgCAOIAEgOIAkhUIATAAIAABvg");
  this.shape_4.setTransform(334.175, -177.15);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#0C593C").s().p("AAVA4IAAhUIACgOIgEAOIgkBUIgTAAIAAhvIAQAAIAABUIgCAOIAEgOIAkhUIATAAIAABvg");
  this.shape_5.setTransform(318.875, -177.15);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#0C593C").s().p("AAVA4IAAhUIACgOIgEAOIgkBUIgTAAIAAhvIAQAAIAABUIgCAOIAEgOIAkhUIATAAIAABvg");
  this.shape_6.setTransform(308.625, -177.15);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#0C593C").s().p("AAUA4IAAg0IgnAAIAAA0IgQAAIAAhvIAQAAIAAAuIAnAAIAAguIAQAAIAABvg");
  this.shape_7.setTransform(298.5, -177.15);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#0C593C").s().p("AgmAcQAAgKADgGQADgGAGgFQAGgCAKgFIATgIQAEgCAAgMQAAgJgDgEQgEgDgJgBQgIABgEAEQgEAFAAAKIgOAAQgBghAhAAQAJAAAIADQAHAEADAHQADAGABAJIAABAQgBAKAHgBIADAAIAAAMQgCACgFAAQgHgBgEgDQgEgCgCgLIAAAAQgDAIgHAEQgGAGgIAAQgdAAAAgfgAABABIgMAGQgEADgEAFQgCAFAAAHQAAARAPAAQAJABAGgHIADgEIABgGIAAgLIAAgVIgMAFg");
  this.shape_8.setTransform(289, -177.15);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#0C593C").s().p("AghA4IAAhvIAjAAQANAAAIAHQAJAIAAAMQAAAKgFAHQgEAHgJACIAAABQAKABAFAHQAGAHAAALQAAAKgEAHQgEAHgHADQgFAEgIAAgAgSArIASAAQAKAAAEgFQAFgEAAgLQgBgJgEgFQgFgFgIAAIgTAAgAgSgIIARAAQAIAAAEgEQAEgEABgKQAAgQgQAAIgSAAg");
  this.shape_9.setTransform(280.2, -177.15);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.f("#0C593C").s().p("AgVA1QgIgFgFgNQgFgNAAgWQAAgcAKgPQAKgPATAAQAoAAAAA6QAAAWgEANQgFANgJAFQgJAGgNAAQgMAAgJgGgAgNgoQgFAEgCALQgCAKAAAQQAAAPACAJQACAKAFAFQAFAGAIgBQAJABAFgGQAGgFACgKQACgJAAgPQAAgQgDgLQgCgKgFgEQgFgEgJgBQgHABgGAEg");
  this.shape_10.setTransform(270.225, -177.15);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.f("#0C593C").s().p("AgSA3QgHgEgEgIQgFgJgBgOIAPAAQAAALADAEQACAGAFACQAEACAGAAQAUAAAAgUQAAgJgFgHQgFgFgJAAIgIAAIAAgMIAIAAQAHAAAFgFQAEgGAAgJQABgHgFgEQgEgGgJAAQgIAAgFAGQgFAFgBAJIgOAAQAAgJAFgIQAEgHAHgFQAIgEAJAAQAJAAAIADQAHAEAFAHQAEAHAAAHQAAALgGAHQgFAHgJADIAAAAQAJACAIAGQAGAHAAANQAAAJgEAIQgEAHgJAFQgHAEgMAAQgKAAgIgEg");
  this.shape_11.setTransform(260.8, -177.15);
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.f("#0C593C").s().p("AgmAcQAAgKADgGQADgGAGgFQAGgCAKgFIATgIQAFgCAAgMQAAgJgFgEQgDgDgIgBQgKABgDAEQgEAFAAAKIgPAAQAAghAhAAQAKAAAHADQAHAEADAHQADAGAAAJIAABAQABAKAFgBIAEAAIAAAMQgCACgEAAQgIgBgFgDQgDgCgBgLIgBAAQgDAIgHAEQgGAGgIAAQgdAAAAgfgAABABIgLAGQgFADgEAFQgCAFAAAHQAAARAOAAQAKABAFgHIADgEIACgGIABgLIAAgVIgNAFg");
  this.shape_12.setTransform(252.15, -177.15);
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.f("#0C593C").s().p("AglBMIAAiVIAQAAIAAANQAEgHAGgEQAHgFAFAAQAlAAAAA5QAAAOgCAKQgBALgEAIQgFAIgHAFQgGAFgLgBQgHABgGgEQgFgDgFgIIAAAxgAgRgyQgEAOAAATQAAANABAJQACAKAEAGQAFAHAJAAQAMAAAEgMQAFgMAAgXQAAgrgVAAQgNAAgEAMg");
  this.shape_13.setTransform(242.8, -175.4);
  this.shape_14 = new cjs.Shape();
  this.shape_14.graphics.f("#0C593C").s().p("AgWBGQgJgIgEgPQgEgOAAgXQAAgRACgNQADgNAEgKQAFgIAHgFQAGgFAJgDIASgGQAGgCABgEIANAAQgDALgHAEQgIAGgOADQgLACgHAKQgHAIgBAPQAJgSARAAQALABAJAGQAIAHAFALQAEALAAARQAAATgEAOQgEANgJAGQgJAHgOAAQgOAAgIgHgAgQgKQgGAKAAASQAAAPACAKQADAKAFAGQAFAEAHAAQANAAAFgLQAGgLAAgXQAAgSgGgKQgGgLgMAAQgKAAgGALg");
  this.shape_14.setTransform(232.725, -178.95);
  this.shape_15 = new cjs.Shape();
  this.shape_15.graphics.f("#0C593C").s().p("AgVA1QgIgFgFgNQgFgNAAgWQAAgcAKgPQAKgPATAAQAoAAAAA6QAAAWgEANQgFANgJAFQgJAGgNAAQgMAAgJgGgAgNgoQgFAEgCALQgCAKAAAQQAAAPACAJQACAKAFAFQAFAGAIgBQAJABAFgGQAGgFACgKQACgJAAgPQAAgQgDgLQgCgKgFgEQgFgEgJgBQgHABgGAEg");
  this.shape_15.setTransform(223.075, -177.15);
  this.shape_16 = new cjs.Shape();
  this.shape_16.graphics.f("#0C593C").s().p("AgVA1QgIgFgFgNQgFgNAAgWQAAgcAKgPQAKgPATAAQAoAAAAA6QAAAWgEANQgFANgJAFQgJAGgNAAQgMAAgJgGgAgNgoQgFAEgCALQgCAKAAAQQAAAPACAJQACAKAFAFQAFAGAIgBQAJABAFgGQAGgFACgKQACgJAAgPQAAgQgDgLQgCgKgFgEQgFgEgJgBQgHABgGAEg");
  this.shape_16.setTransform(212.975, -177.15);
  this.shape_17 = new cjs.Shape();
  this.shape_17.graphics.f("#0C593C").s().p("AgSA3QgHgEgEgIQgFgJgBgOIAPAAQAAALADAEQADAGAEACQAEACAGAAQAUAAAAgUQAAgJgFgHQgFgFgJAAIgIAAIAAgMIAIAAQAHAAAFgFQAEgGAAgJQAAgHgEgEQgEgGgJAAQgJAAgEAGQgFAFgBAJIgOAAQAAgJAFgIQAEgHAHgFQAIgEAJAAQAJAAAIADQAIAEAEAHQAEAHAAAHQAAALgGAHQgFAHgJADIAAAAQAKACAGAGQAHAHAAANQAAAJgEAIQgEAHgJAFQgHAEgMAAQgKAAgIgEg");
  this.shape_17.setTransform(203.55, -177.15);
  this.shape_18 = new cjs.Shape();
  this.shape_18.graphics.f("#0C593C").s().p("AgmAcQAAgKADgGQADgGAGgFQAGgCAKgFIATgIQAFgCAAgMQgBgJgEgEQgDgDgIgBQgKABgDAEQgEAFAAAKIgPAAQABghAgAAQAKAAAHADQAHAEADAHQAEAGgBAJIAABAQABAKAFgBIAEAAIAAAMQgCACgEAAQgIgBgFgDQgDgCgBgLIgBAAQgDAIgHAEQgGAGgIAAQgdAAAAgfgAABABIgLAGQgGADgCAFQgDAFAAAHQAAARAOAAQAKABAFgHIADgEIACgGIABgLIAAgVIgNAFg");
  this.shape_18.setTransform(194.9, -177.15);
  this.shape_19 = new cjs.Shape();
  this.shape_19.graphics.f("#0C593C").s().p("AgdA4IAAhvIA7AAIAAANIgrAAIAABig");
  this.shape_19.setTransform(187.375, -177.15);
  this.shape_20 = new cjs.Shape();
  this.shape_20.graphics.f("#0C593C").s().p("AgIAQQAJgDAAgRIgJAAIAAgUIARAAIAAAYQAAAIgFAHQgEAHgIADg");
  this.shape_20.setTransform(468.425, -191.475);
  this.shape_21 = new cjs.Shape();
  this.shape_21.graphics.f("#0C593C").s().p("AAVA4IAAhUIACgOIgEAOIgkBUIgTAAIAAhvIAQAAIAABUIgCANIAEgNIAkhUIATAAIAABvg");
  this.shape_21.setTransform(460.775, -197.55);
  this.shape_22 = new cjs.Shape();
  this.shape_22.graphics.f("#0C593C").s().p("AAVA4IAAhUIACgOIgEAOIgkBUIgTAAIAAhvIAQAAIAABUIgCANIAEgNIAkhUIATAAIAABvg");
  this.shape_22.setTransform(450.525, -197.55);
  this.shape_23 = new cjs.Shape();
  this.shape_23.graphics.f("#0C593C").s().p("AgHA4IAAhhIgdAAIAAgOIBJAAIAAAOIgdAAIAABhg");
  this.shape_23.setTransform(441.575, -197.55);
  this.shape_24 = new cjs.Shape();
  this.shape_24.graphics.f("#0C593C").s().p("AgmBKIAAgPQAGADAHAAQAHAAAEgGQAFgGADgLIgjhxIAQAAIAaBYIAAAAIAZhYIAQAAIgiBwQgFANgDAHQgCAHgHAFQgGAFgLAAIgMgBg");
  this.shape_24.setTransform(433.1, -195.65);
  this.shape_25 = new cjs.Shape();
  this.shape_25.graphics.f("#0C593C").s().p("AAhBHIAAgeIhBAAIAAAeIgOAAIAAgsIAKAAQAFgLADgIIADgRIABgYIAAglIA9AAIAABhIAKAAIAAAsgAgIgZQAAARgCAKQgDALgHAOIApAAIAAhUIgdAAg");
  this.shape_25.setTransform(423.5, -196.025);
  this.shape_26 = new cjs.Shape();
  this.shape_26.graphics.f("#0C593C").s().p("AgSA3QgIgEgEgJQgEgIgBgNIAPAAQABAKACAEQACAGAFACQAEACAGABQAUAAAAgWQAAgIgFgGQgFgGgIAAIgIAAIAAgMIAHAAQAHAAAFgFQAEgGAAgJQABgHgFgFQgEgEgJgBQgIABgFAEQgFAGgBAJIgOAAQAAgJAEgHQAFgIAIgFQAHgEAJAAQAJAAAIADQAHAEAFAHQAEAGAAAIQAAALgFAHQgGAHgJACIAAABQAJACAIAGQAGAHAAANQAAAKgEAHQgFAHgHAFQgJAEgKAAQgLAAgIgEg");
  this.shape_26.setTransform(414, -197.55);
  this.shape_27 = new cjs.Shape();
  this.shape_27.graphics.f("#0C593C").s().p("AgiA4IAAhvIAjAAQANAAAKAHQAIAHAAAMQAAALgFAHQgFAHgHACIAAAAQAJACAFAHQAFAHABALQgBAKgDAHQgEAGgHAEQgFAEgIAAgAgSArIASAAQAKAAAFgEQADgGAAgKQAAgKgEgEQgFgFgIAAIgTAAgAgSgIIARAAQAIAAAEgEQAFgFAAgIQgBgRgPAAIgSAAg");
  this.shape_27.setTransform(405.5, -197.55);
  this.shape_28 = new cjs.Shape();
  this.shape_28.graphics.f("#0C593C").s().p("AAVA4IAAhUIACgOIgEAOIgkBUIgTAAIAAhvIAQAAIAABUIgCANIAEgNIAkhUIATAAIAABvg");
  this.shape_28.setTransform(390.425, -197.55);
  this.shape_29 = new cjs.Shape();
  this.shape_29.graphics.f("#0C593C").s().p("AglBMIAAiUIAPAAIAAAMQAFgIAGgDQAHgEAFgBQAlABAAA5QAAANgCAKQgCALgEAIQgEAIgGAFQgIAFgKAAQgHAAgGgEQgFgEgFgHIAAAxgAgRgyQgEANAAAUQAAANABAKQACAJAEAGQAFAHAJAAQALAAAGgMQAEgLAAgXQAAgsgVAAQgMAAgFAMg");
  this.shape_29.setTransform(380.45, -195.8);
  this.shape_30 = new cjs.Shape();
  this.shape_30.graphics.f("#0C593C").s().p("AAUA4IAAhhIgnAAIAABhIgQAAIAAhvIBHAAIAABvg");
  this.shape_30.setTransform(370.2, -197.55);
  this.shape_31 = new cjs.Shape();
  this.shape_31.graphics.f("#0C593C").s().p("AgHA4IAAhhIgdAAIAAgOIBJAAIAAAOIgdAAIAABhg");
  this.shape_31.setTransform(356.275, -197.55);
  this.shape_32 = new cjs.Shape();
  this.shape_32.graphics.f("#0C593C").s().p("AglBMIAAiUIAQAAIAAAMQAEgIAGgDQAHgEAFgBQAlABAAA5QAAANgCAKQgBALgEAIQgFAIgHAFQgGAFgLAAQgHAAgFgEQgGgEgFgHIAAAxgAgRgyQgEANAAAUQAAANACAKQABAJAEAGQAFAHAJAAQAMAAAEgMQAFgLAAgXQAAgsgVAAQgMAAgFAMg");
  this.shape_32.setTransform(347.55, -195.8);
  this.shape_33 = new cjs.Shape();
  this.shape_33.graphics.f("#0C593C").s().p("AgVA1QgIgFgFgNQgFgNAAgWQAAgcAKgPQAKgPATAAQAoAAAAA6QAAAWgEANQgFANgJAFQgJAGgNAAQgMAAgJgGgAgNgoQgFAFgCAKQgCAKAAAQQAAAOACAKQACAKAFAFQAFAGAIAAQAJAAAFgGQAGgFACgKQACgKAAgOQAAgQgDgKQgCgKgFgFQgFgFgJAAQgHAAgGAFg");
  this.shape_33.setTransform(337.225, -197.55);
  this.shape_34 = new cjs.Shape();
  this.shape_34.graphics.f("#0C593C").s().p("AgHBeIAAgxQgFAHgFAEQgGAEgIAAQgOgBgIgHQgIgJgDgNQgDgOAAgQQAAgRAEgNQADgNAIgHQAIgIAOAAQAHAAAGAEQAGAEAEAHIAAgzIAPAAIAAA0QAEgIAGgEQAGgEAHAAQATABAKAPQAIAQAAAaQAAA7glABQgHAAgFgEQgGgEgFgHIAAAxgAALgfQgDANAAASQAAAVAEANQAEAMANAAQAMAAAFgMQAFgLAAgXQAAgsgWAAQgNAAgFANgAgzAAQAAAWAGAMQAEAMANAAQAJAAAEgHQAGgHABgKQABgJAAgNQAAgSgEgNQgDgNgOAAQgXAAAAAsg");
  this.shape_34.setTransform(324.4, -197.6);
  this.shape_35 = new cjs.Shape();
  this.shape_35.graphics.f("#0C593C").s().p("AAiA4IAAhhIgdBhIgJAAIgdhhIAABhIgPAAIAAhvIAZAAIAUBJIADAWIAEgWIAVhJIAYAAIAABvg");
  this.shape_35.setTransform(310.225, -197.55);
  this.shape_36 = new cjs.Shape();
  this.shape_36.graphics.f("#0C593C").s().p("AgVA1QgIgFgFgNQgFgNAAgWQAAgcAKgPQAKgPATAAQAoAAAAA6QAAAWgEANQgFANgJAFQgJAGgNAAQgMAAgJgGgAgNgoQgFAFgCAKQgCAKAAAQQAAAOACAKQACAKAFAFQAFAGAIAAQAJAAAFgGQAGgFACgKQACgKAAgOQAAgQgDgKQgCgKgFgFQgFgFgJAAQgHAAgGAFg");
  this.shape_36.setTransform(298.825, -197.55);
  this.shape_37 = new cjs.Shape();
  this.shape_37.graphics.f("#0C593C").s().p("AATA4Igbg4IgMAQIAAAoIgQAAIAAhvIAQAAIAAA0IAlg0IATAAIgiArIAjBEg");
  this.shape_37.setTransform(289.975, -197.55);
  this.shape_38 = new cjs.Shape();
  this.shape_38.graphics.f("#0C593C").s().p("AgVAzQgIgIgEgMQgDgMABgRQgBg8AmAAQARAAAJAKQAIALAAARIgPAAQABgZgUAAQgMAAgEANQgEANAAAVQAAATADAMQAFANAMAAQAMAAADgIQAEgHAAgOIAPAAQABASgJAMQgHAMgSAAQgPAAgJgIg");
  this.shape_38.setTransform(280.4, -197.55);
  this.shape_39 = new cjs.Shape();
  this.shape_39.graphics.f("#0C593C").s().p("AAVA4IAAhUIACgOIgEAOIgkBUIgTAAIAAhvIAQAAIAABUIgCANIAEgNIAkhUIATAAIAABvg");
  this.shape_39.setTransform(270.775, -197.55);
  this.shape_40 = new cjs.Shape();
  this.shape_40.graphics.f("#0C593C").s().p("AAhBHIAAgeIhBAAIAAAeIgOAAIAAgsIAKAAQAFgLADgIIAEgRIAAgYIAAglIA9AAIAABhIAKAAIAAAsgAgIgZQAAARgCAKQgEALgGAOIApAAIAAhUIgdAAg");
  this.shape_40.setTransform(260.4, -196.025);
  this.shape_41 = new cjs.Shape();
  this.shape_41.graphics.f("#0C593C").s().p("AAVA4IAAgwIgRAAIgWAwIgSAAIAYgxQgJgDgFgIQgGgIAAgLQAAgKAEgHQAEgIAHgDQAHgEAJAAIAmAAIAABvgAgLglQgEAEAAALQAAASASAAIASAAIAAgmIgRAAQgKAAgFAFg");
  this.shape_41.setTransform(245.125, -197.55);
  this.shape_42 = new cjs.Shape();
  this.shape_42.graphics.f("#0C593C").s().p("AgVAzQgJgIgCgMQgDgMgBgRQAAg8AnAAQAQAAAJAKQAJALAAARIgPAAQgBgZgSAAQgMAAgFANQgFANAAAVQAAATAFAMQADANANAAQAMAAADgIQADgHACgOIAPAAQgBASgHAMQgIAMgSAAQgPAAgJgIg");
  this.shape_42.setTransform(236.7, -197.55);
  this.shape_43 = new cjs.Shape();
  this.shape_43.graphics.f("#0C593C").s().p("AgHA4IAAhhIgdAAIAAgOIBJAAIAAAOIgdAAIAABhg");
  this.shape_43.setTransform(228.375, -197.55);
  this.shape_44 = new cjs.Shape();
  this.shape_44.graphics.f("#0C593C").s().p("AgSA1QgIgFgEgNQgFgNAAgWQABg6AiAAQAQAAAIAIQAIAJABAMQACANAAARIg1AAQAAAQABAJQACAJAEAFQAEAFAJABQASAAAAgbIAPAAQABALgEAJQgEAKgHAEQgIAGgLAAQgMAAgIgGgAgOgjQgEAKAAAOIAlAAQAAgQgEgJQgDgJgMAAQgKAAgEAKg");
  this.shape_44.setTransform(219.95, -197.55);
  this.shape_45 = new cjs.Shape();
  this.shape_45.graphics.f("#0C593C").s().p("AgmAcQAAgKADgGQADgGAGgEQAGgEAKgDIATgJQAFgCAAgMQgBgJgEgEQgDgEgIAAQgKAAgDAFQgEAFAAAKIgPAAQABghAgAAQAKAAAHADQAHAFADAGQAEAHgBAHIAABBQABAJAFAAIAEAAIAAAMQgCABgEABQgIAAgFgDQgDgEgBgKIgBAAQgDAHgHAFQgGAGgIAAQgdAAAAgfgAABABIgLAGQgGADgCAFQgDAEAAAJQAAAQAOAAQAKAAAFgFIADgFIACgGIABgLIAAgVIgNAFg");
  this.shape_45.setTransform(211.1, -197.55);
  this.shape_46 = new cjs.Shape();
  this.shape_46.graphics.f("#0C593C").s().p("AgiA4IAAhvIAjAAQANAAAKAHQAIAHAAAMQAAALgFAHQgFAHgHACIAAAAQAJACAFAHQAFAHAAALQAAAKgDAHQgEAGgGAEQgHAEgHAAgAgSArIASAAQALAAAEgEQADgGAAgKQABgKgFgEQgFgFgIAAIgTAAgAgSgIIARAAQAIAAAFgEQADgFAAgIQAAgRgQAAIgRAAg");
  this.shape_46.setTransform(202.3, -197.55);
  this.shape_47 = new cjs.Shape();
  this.shape_47.graphics.f("#0C593C").s().p("AgSA1QgIgFgEgNQgFgNAAgWQABg6AiAAQAQAAAIAIQAHAJACAMQACANAAARIg1AAQAAAQABAJQACAJAEAFQAFAFAHABQATAAgBgbIAQAAQABALgEAJQgEAKgHAEQgIAGgMAAQgKAAgJgGgAgOgjQgEAKAAAOIAlAAQAAgQgEgJQgDgJgMAAQgKAAgEAKg");
  this.shape_47.setTransform(192.85, -197.55);
  this.shape_48 = new cjs.Shape();
  this.shape_48.graphics.f("#0C593C").s().p("AAiA4IAAhhIgdBhIgJAAIgdhhIAABhIgPAAIAAhvIAZAAIAUBJIADAWIAEgWIAVhJIAYAAIAABvg");
  this.shape_48.setTransform(182.075, -197.55);
  this.shape_49 = new cjs.Shape();
  this.shape_49.graphics.f("#0C593C").s().p("AglBKIAAgPQAFADAGAAQAIAAAFgGQAEgGADgLIgkhxIARAAIAZBYIABAAIAYhYIASAAIgkBwQgDANgEAHQgDAHgGAFQgHAFgKAAIgLgBg");
  this.shape_49.setTransform(171.15, -195.65);
  this.shape_50 = new cjs.Shape();
  this.shape_50.graphics.f("#0C593C").s().p("AgRA3QgJgEgDgJQgFgIgBgNIAPAAQAAAKADAEQADAGAEACQAEACAGABQAUAAAAgWQAAgIgFgGQgFgGgJAAIgIAAIAAgMIAIAAQAHAAAEgFQAGgGAAgJQgBgHgEgFQgEgEgJgBQgIABgGAEQgEAGAAAJIgPAAQAAgJAFgHQAEgIAHgFQAIgEAJAAQAKAAAHADQAHAEAFAHQAEAGAAAIQAAALgGAHQgFAHgJACIAAABQAKACAGAGQAHAHAAANQAAAKgEAHQgEAHgJAFQgHAEgMAAQgKAAgHgEg");
  this.shape_50.setTransform(162.4, -197.55);
  this.shape_51 = new cjs.Shape();
  this.shape_51.graphics.f("#0C593C").s().p("AgmAcQAAgKADgGQADgGAGgEQAGgEAKgDIATgJQAFgCgBgMQAAgJgDgEQgEgEgJAAQgIAAgEAFQgEAFAAAKIgOAAQAAghAgAAQAKAAAHADQAHAFADAGQADAHAAAHIAABBQAAAJAHAAIADAAIAAAMQgCABgFABQgIAAgEgDQgDgEgBgKIgBAAQgDAHgHAFQgGAGgIAAQgdAAAAgfgAABABIgLAGQgGADgCAFQgDAEAAAJQAAAQAOAAQAKAAAGgFIACgFIACgGIAAgLIAAgVIgMAFg");
  this.shape_51.setTransform(153.75, -197.55);
  this.shape_52 = new cjs.Shape();
  this.shape_52.graphics.f("#0C593C").s().p("AglBMIAAiUIAPAAIAAAMQAFgIAGgDQAHgEAFgBQAlABAAA5QAAANgCAKQgBALgFAIQgDAIgIAFQgHAFgKAAQgHAAgFgEQgGgEgFgHIAAAxgAgRgyQgEANAAAUQAAANACAKQAAAJAFAGQAFAHAJAAQALAAAGgMQAEgLAAgXQAAgsgVAAQgMAAgFAMg");
  this.shape_52.setTransform(144.4, -195.8);
  this.shape_53 = new cjs.Shape();
  this.shape_53.graphics.f("#0C593C").s().p("AAhBHIAAgeIhAAAIAAAeIgQAAIAAgsIAKAAQAGgLACgIIAEgRIACgYIAAglIA8AAIAABhIALAAIAAAsgAgIgZQAAARgDAKQgCALgHAOIApAAIAAhUIgdAAg");
  this.shape_53.setTransform(133.9, -196.025);
  this.shape_54 = new cjs.Shape();
  this.shape_54.graphics.f("#0C593C").s().p("AgVA1QgIgFgFgNQgFgNAAgWQAAgcAKgPQAKgPATAAQAoAAAAA6QAAAWgEANQgFANgJAFQgJAGgNAAQgMAAgJgGgAgNgoQgFAFgCAKQgCAKAAAQQAAAOACAKQACAKAFAFQAFAGAIAAQAJAAAFgGQAGgFACgKQACgKAAgOQAAgQgDgKQgCgKgFgFQgFgFgJAAQgHAAgGAFg");
  this.shape_54.setTransform(123.725, -197.55);
  this.shape_55 = new cjs.Shape();
  this.shape_55.graphics.f("#0C593C").s().p("AAdBLIAAiHIg5AAIAACHIgRAAIAAiWIBbAAIAACWg");
  this.shape_55.setTransform(112.525, -199.5);
  this.shape_56 = new cjs.Shape();
  this.shape_56.graphics.f("#0C593C").s().p("AAAAKIgOATIgJgGIAPgTIgWgIIADgJIAXAJIAAgZIAKAAIAAAZIAWgJIADAKIgXAHIAQATIgJAGg");
  this.shape_56.setTransform(101.3, -204.1);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_56
   }, {
    t: this.shape_55
   }, {
    t: this.shape_54
   }, {
    t: this.shape_53
   }, {
    t: this.shape_52
   }, {
    t: this.shape_51
   }, {
    t: this.shape_50
   }, {
    t: this.shape_49
   }, {
    t: this.shape_48
   }, {
    t: this.shape_47
   }, {
    t: this.shape_46
   }, {
    t: this.shape_45
   }, {
    t: this.shape_44
   }, {
    t: this.shape_43
   }, {
    t: this.shape_42
   }, {
    t: this.shape_41
   }, {
    t: this.shape_40
   }, {
    t: this.shape_39
   }, {
    t: this.shape_38
   }, {
    t: this.shape_37
   }, {
    t: this.shape_36
   }, {
    t: this.shape_35
   }, {
    t: this.shape_34
   }, {
    t: this.shape_33
   }, {
    t: this.shape_32
   }, {
    t: this.shape_31
   }, {
    t: this.shape_30
   }, {
    t: this.shape_29
   }, {
    t: this.shape_28
   }, {
    t: this.shape_27
   }, {
    t: this.shape_26
   }, {
    t: this.shape_25
   }, {
    t: this.shape_24
   }, {
    t: this.shape_23
   }, {
    t: this.shape_22
   }, {
    t: this.shape_21
   }, {
    t: this.shape_20
   }, {
    t: this.shape_19
   }, {
    t: this.shape_18
   }, {
    t: this.shape_17
   }, {
    t: this.shape_16
   }, {
    t: this.shape_15
   }, {
    t: this.shape_14
   }, {
    t: this.shape_13
   }, {
    t: this.shape_12
   }, {
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
 }).prototype = getMCSymbolPrototype(lib.l1, new cjs.Rectangle(-6.4, -213, 580, 47.80000000000001), null);
 (lib.icon03 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.icon3();
  this.instance.parent = this;
  this.instance.setTransform(0, 0, 0.667, 0.667);
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));
 }).prototype = getMCSymbolPrototype(lib.icon03, new cjs.Rectangle(0, 0, 142.8, 142.8), null);
 (lib.icon02 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.icon2();
  this.instance.parent = this;
  this.instance.setTransform(0, 0, 0.667, 0.667);
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));
 }).prototype = getMCSymbolPrototype(lib.icon02, new cjs.Rectangle(0, 0, 113.4, 114.7), null);
 (lib.icon1_1_icon1_office = function() {
  this.initialize(img.icon1_1_icon1_office);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 212, 213);
 (lib.icon1_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_icon1 = new lib.icon1_1_icon1_office();
  this.cvr_icon1.name = "cvr_icon1";
  this.cvr_icon1.parent = this;
  this.cvr_icon1.setTransform(0, 0, 0.6834905660377358, 0.6834905660377358);
  this.timeline.addTween(cjs.Tween.get(this.cvr_icon1).wait(1));
 }).prototype = getMCSymbolPrototype(lib.icon1_1, new cjs.Rectangle(0, 0, 144.9, 145.5), null);
 (lib.gr = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.lf(["rgba(217,237,141,0)", "#D9ED8D"], [0, 1], -11.6, -109.3, -11.6, -149.3).s().p("EgtTAfQMAAAg+fMBanAAAMAAAA+fg");
  this.shape.setTransform(290, 200);
  this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
 }).prototype = getMCSymbolPrototype(lib.gr, new cjs.Rectangle(0, 0, 580, 400), null);
 (lib.fish02 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.fish2();
  this.instance.parent = this;
  this.instance.setTransform(0, 0, 0.667, 0.667);
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));
 }).prototype = getMCSymbolPrototype(lib.fish02, new cjs.Rectangle(0, 0, 230.8, 177.4), null);
 (lib.fish01 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.fish1();
  this.instance.parent = this;
  this.instance.setTransform(-10, -17, 0.7514, 0.7514);
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));
 }).prototype = getMCSymbolPrototype(lib.fish01, new cjs.Rectangle(-10, -17, 257, 233.7), null);
 (lib.black_plate = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#C0DF53").s().p("EgtTAfQMAAAg+fMBanAAAMAAAA+fg");
  this.shape.setTransform(290, 200);
  this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
 }).prototype = getMCSymbolPrototype(lib.black_plate, new cjs.Rectangle(0, 0, 580, 400), null);
 (lib.bg_g = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.lf(["#C0DF53", "#D9ED8D"], [0, 1], -11.6, -109.3, -11.6, -149.3).s().p("EgtTAfQMAAAg+fMBanAAAMAAAA+fg");
  this.shape.setTransform(290, 200);
  this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
 }).prototype = getMCSymbolPrototype(lib.bg_g, new cjs.Rectangle(0, 0, 580, 400), null);
 (lib.b1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.bubble();
  this.instance.parent = this;
  this.instance.setTransform(0, 0, 0.7446, 0.7446);
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));
 }).prototype = getMCSymbolPrototype(lib.b1, new cjs.Rectangle(0, 0, 333.6, 333.6), null);
 (lib.txt04 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  var mask = new cjs.Shape();
  mask._off = true;
  mask.graphics.p("A2GScIAAl2MAsNAAAIAAF2g");
  mask.setTransform(141.4902, 117.9964);
  this.instance = new lib.t4();
  this.instance.parent = this;
  this.instance.setTransform(78, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance.alpha = 0;
  this.instance._off = true;
  var maskedShapeInstanceList = [this.instance];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(10).to({
   _off: false
  }, 0).to({
   x: 108,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(11));
  var mask_1 = new cjs.Shape();
  mask_1._off = true;
  mask_1.graphics.p("A2GPhIAAlUMAsNAAAIAAFUg");
  mask_1.setTransform(141.4902, 99.2744);
  this.instance_1 = new lib.t4();
  this.instance_1.parent = this;
  this.instance_1.setTransform(78, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance_1.alpha = 0;
  this.instance_1._off = true;
  var maskedShapeInstanceList = [this.instance_1];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(5).to({
   _off: false
  }, 0).to({
   x: 108,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(16));
  var mask_2 = new cjs.Shape();
  mask_2._off = true;
  mask_2.graphics.p("A2GM8IAAn1MAsNAAAIAAH1g");
  mask_2.setTransform(141.4902, 82.75);
  this.instance_2 = new lib.t4();
  this.instance_2.parent = this;
  this.instance_2.setTransform(78, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance_2.alpha = 0;
  var maskedShapeInstanceList = [this.instance_2];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_2).to({
   x: 108,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(21));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(32, 115.5, 251, 120.5);
 (lib.txt03 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  var mask = new cjs.Shape();
  mask._off = true;
  mask.graphics.p("A2GOCIAAmpMAsNAAAIAAGpg");
  mask.setTransform(141.4902, 89.7626);
  this.instance = new lib.t3();
  this.instance.parent = this;
  this.instance.setTransform(78, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance.alpha = 0;
  this.instance._off = true;
  var maskedShapeInstanceList = [this.instance];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(5).to({
   _off: false
  }, 0).to({
   x: 108,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(16));
  var mask_1 = new cjs.Shape();
  mask_1._off = true;
  mask_1.graphics.p("A2GKtIAAnCMAsNAAAIAAHCg");
  mask_1.setTransform(141.4902, 68.4998);
  this.instance_1 = new lib.t3();
  this.instance_1.parent = this;
  this.instance_1.setTransform(78, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance_1.alpha = 0;
  var maskedShapeInstanceList = [this.instance_1];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_1).to({
   x: 108,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(21));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(5.5, 92, 277.5, 87.6);
 (lib.txt02_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  var mask = new cjs.Shape();
  mask._off = true;
  mask.graphics.p("AAURHIAAn0MAk4AAAIAAH0g");
  mask.setTransform(238, 109.5);
  this.instance = new lib.t2_1();
  this.instance.parent = this;
  this.instance.setTransform(78, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance.alpha = 0;
  this.instance._off = true;
  var maskedShapeInstanceList = [this.instance];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(5).to({
   _off: false
  }, 0).to({
   x: 108,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(1));
  var mask_1 = new cjs.Shape();
  mask_1._off = true;
  mask_1.graphics.p("AAUNIIAAn0MAk4AAAIAAH0g");
  mask_1.setTransform(238, 84);
  this.instance_1 = new lib.t2_1();
  this.instance_1.parent = this;
  this.instance_1.setTransform(78, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance_1.alpha = 0;
  var maskedShapeInstanceList = [this.instance_1];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_1).to({
   x: 108,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(6));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(302.8, 127, 173.2, 85.1);
 (lib.txt02 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  var mask = new cjs.Shape();
  mask._off = true;
  mask.graphics.p("AsGQpIAAl2IYNAAIAAF2g");
  mask.setTransform(77.5257, 106.5454);
  this.instance = new lib.t2();
  this.instance.parent = this;
  this.instance.setTransform(78, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance.alpha = 0;
  this.instance._off = true;
  var maskedShapeInstanceList = [this.instance];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(10).to({
   _off: false
  }, 0).to({
   x: 108,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(11));
  var mask_1 = new cjs.Shape();
  mask_1._off = true;
  mask_1.graphics.p("A5NNtIAAmKMAybAAAIAAGKg");
  mask_1.setTransform(161.441, 87.7445);
  this.instance_1 = new lib.t2();
  this.instance_1.parent = this;
  this.instance_1.setTransform(78, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance_1.alpha = 0;
  this.instance_1._off = true;
  var maskedShapeInstanceList = [this.instance_1];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(5).to({
   _off: false
  }, 0).to({
   x: 108,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(16));
  var mask_2 = new cjs.Shape();
  mask_2._off = true;
  mask_2.graphics.p("A2GKoIAAnMMAsNAAAIAAHMg");
  mask_2.setTransform(141.4902, 68);
  this.instance_2 = new lib.t2();
  this.instance_2.parent = this;
  this.instance_2.setTransform(78, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance_2.alpha = 0;
  var maskedShapeInstanceList = [this.instance_2];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_2).to({
   x: 108,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(21));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(6, 90, 304.9, 123.1);
 (lib.txt01 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  var mask = new cjs.Shape();
  mask._off = true;
  mask.graphics.p("A2SORIAAn1MAsmAAAIAAH1g");
  mask.setTransform(142.7498, 91.25);
  this.instance = new lib.t1();
  this.instance.parent = this;
  this.instance.setTransform(78, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance.alpha = 0;
  this.instance._off = true;
  var maskedShapeInstanceList = [this.instance];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(5).to({
   _off: false
  }, 0).to({
   x: 108,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(21));
  var mask_1 = new cjs.Shape();
  mask_1._off = true;
  mask_1.graphics.p("A2SKRIAAnzMAsmAAAIAAHzg");
  mask_1.setTransform(142.7498, 65.75);
  this.instance_1 = new lib.t1();
  this.instance_1.parent = this;
  this.instance_1.setTransform(78, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance_1.alpha = 0;
  var maskedShapeInstanceList = [this.instance_1];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_1).to({
   x: 108,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(26));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(9, 84, 276.5, 94);
 (lib._new = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.orange();
  this.instance.parent = this;
  this.instance.setTransform(52, 52, 1, 1, 0, 0, 0, 52, 52);
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   scaleX: 1.0787,
   scaleY: 1.0787,
   x: 52.05,
   y: 52.05
  }, 12, cjs.Ease.get(1)).to({
   scaleX: 1,
   scaleY: 1,
   x: 52,
   y: 52
  }, 12, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(-6.2, -4, 126.8, 112.2);
 (lib.icon1_2 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_icon1 = new lib.icon1_1();
  this.cvr_icon1.name = "cvr_icon1";
  this.cvr_icon1.parent = this;
  this.cvr_icon1.setTransform(73.45, 72.75, 1.0813, 1.0813, 0, 0, 0, 70.7, 71);
  this.timeline.addTween(cjs.Tween.get(this.cvr_icon1).wait(1));
 }).prototype = getMCSymbolPrototype(lib.icon1_2, new cjs.Rectangle(-3, -4, 156.7, 157.4), null);
 (lib.fish02_float = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.fish02();
  this.instance.parent = this;
  this.instance.setTransform(114, 103.7, 1.097, 1.097, 0, 0, 0, 114, 103.7);
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   y: 98.75
  }, 9, cjs.Ease.get(-1)).to({
   y: 93.7
  }, 10, cjs.Ease.get(1)).to({
   y: 98.75
  }, 10, cjs.Ease.get(-1)).to({
   y: 103.7
  }, 10, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(-11, -20, 253.2, 204.7);
 (lib.bubble_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.b1();
  this.instance.parent = this;
  this.instance.setTransform(149.4, 149.4, 1, 1, 0, 0, 0, 149.4, 149.4);
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   y: 143.75
  }, 9, cjs.Ease.get(-1)).to({
   y: 137.45
  }, 10, cjs.Ease.get(1)).to({
   y: 143.45
  }, 10, cjs.Ease.get(-1)).to({
   y: 149.4
  }, 10, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(0, -11.9, 333.6, 345.5);
 (lib.fish01_float = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.bubble_1();
  this.instance.parent = this;
  this.instance.setTransform(40, 98.7, 0.0337, 0.0337, 0, 0, 0, 145.6, 154.5);
  this.instance._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(21).to({
   _off: false
  }, 0).to({
   regX: 145.9,
   regY: 153.2,
   scaleX: 0.1707,
   scaleY: 0.1707,
   x: -20,
   y: 58.7
  }, 10, cjs.Ease.get(0.5)).to({
   regX: 145.7,
   regY: 154.5,
   scaleX: 0.034,
   scaleY: 0.034,
   y: 38.7
  }, 10, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(76));
  this.instance_1 = new lib.bubble_1();
  this.instance_1.parent = this;
  this.instance_1.setTransform(40, 98.7, 0.0337, 0.0337, 0, 0, 0, 145.6, 154.5);
  this.instance_1._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(16).to({
   _off: false
  }, 0).to({
   regX: 145.9,
   regY: 153.2,
   scaleX: 0.1707,
   scaleY: 0.1707,
   x: -30,
   y: 78.7
  }, 10, cjs.Ease.get(0.5)).to({
   regX: 145.7,
   regY: 154.5,
   scaleX: 0.034,
   scaleY: 0.034,
   x: -10,
   y: 48.7
  }, 10, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(81));
  this.instance_2 = new lib.bubble_1();
  this.instance_2.parent = this;
  this.instance_2.setTransform(40, 98.7, 0.0337, 0.0337, 0, 0, 0, 145.6, 154.5);
  this.instance_2._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(11).to({
   _off: false
  }, 0).to({
   regX: 145.9,
   regY: 153.2,
   scaleX: 0.1707,
   scaleY: 0.1707,
   x: -30,
   y: 68.7
  }, 10, cjs.Ease.get(0.5)).to({
   regX: 145.7,
   regY: 154.5,
   scaleX: 0.034,
   scaleY: 0.034,
   x: -40,
   y: 28.7
  }, 10, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(86));
  this.instance_3 = new lib.bubble_1();
  this.instance_3.parent = this;
  this.instance_3.setTransform(40, 98.7, 0.0337, 0.0337, 0, 0, 0, 145.6, 154.5);
  this.instance_3._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(6).to({
   _off: false
  }, 0).to({
   regX: 145.9,
   regY: 153.2,
   scaleX: 0.1707,
   scaleY: 0.1707,
   x: -20,
   y: 58.7
  }, 10, cjs.Ease.get(0.5)).to({
   regX: 145.7,
   regY: 154.5,
   scaleX: 0.034,
   scaleY: 0.034,
   y: 38.7
  }, 10, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(91));
  this.instance_4 = new lib.fish01();
  this.instance_4.parent = this;
  this.instance_4.setTransform(114, 103.7, 1, 1, 0, 0, 0, 114, 103.7);
  this.timeline.addTween(cjs.Tween.get(this.instance_4).to({
   y: 98.7
  }, 9, cjs.Ease.get(-1)).wait(1).to({
   regX: 118.5,
   regY: 99.8,
   x: 118.5,
   y: 93.85
  }, 0).wait(1).to({
   y: 93
  }, 0).wait(1).to({
   y: 92.25
  }, 0).wait(1).to({
   regX: 114,
   regY: 103.7,
   x: 114,
   y: 95.5
  }, 0).wait(1).to({
   regX: 118.5,
   regY: 99.8,
   x: 118.5,
   y: 91.05
  }, 0).wait(1).to({
   y: 90.6
  }, 0).wait(1).to({
   y: 90.25
  }, 0).wait(1).to({
   y: 90
  }, 0).wait(1).to({
   y: 89.85
  }, 0).wait(1).to({
   regX: 114,
   regY: 103.7,
   x: 114,
   y: 93.7
  }, 0).to({
   y: 98.7
  }, 10, cjs.Ease.get(-1)).to({
   y: 103.7
  }, 10, cjs.Ease.get(1)).to({
   y: 98.7
  }, 9, cjs.Ease.get(-1)).to({
   y: 93.7
  }, 10, cjs.Ease.get(1)).to({
   y: 98.7
  }, 10, cjs.Ease.get(-1)).to({
   y: 103.7
  }, 10, cjs.Ease.get(1)).to({
   y: 98.7
  }, 9, cjs.Ease.get(-1)).to({
   y: 93.7
  }, 10, cjs.Ease.get(1)).to({
   y: 98.7
  }, 10, cjs.Ease.get(-1)).to({
   y: 103.7
  }, 10, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(-54.9, -27, 301.9, 243.7);
 (lib.content = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {
   cvr_frame1_2: 83,
   cvr_frame2_3: 178,
   "cvr_frame#3": 240,
   cvr_stay: 262,
   cvr_frame4_1: 349
  });
  this.frame_262 = function() {
   if (!this.cycle) this.cycle = 0;
   this.cycle++;
   var frames = this.duration * this.cycle + this.currentFrame;
   if (frames / createjs.Ticker.getMeasuredFPS() > 30) {
    if (this.cycle > 1) {
     _globalStop(this.stage);
    } else {
     var stopFrame = this.currentFrame;
     var tst = cjs.Tween.get(this);
     this.timeline.addTween(cjs.Tween.get(this).wait(this.duration - 1).call(function() {
      globalGotoAndStop(stopFrame);
     }));
    }
   }
  }
  this.timeline.addTween(cjs.Tween.get(this).wait(262).call(this.frame_262));
  this.instance = new lib.black_plate();
  this.instance.parent = this;
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   alpha: 0
  }, 14, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(349).to({
   _off: false
  }, 0).to({
   alpha: 1
  }, 15, cjs.Ease.get(0.99)).wait(1));
  this.instance_1 = new lib.logo();
  this.instance_1.parent = this;
  this.instance_1.setTransform(112.5, 26.1, 1, 1, 0, 0, 0, 112.5, 26.1);
  this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(180).to({
   alpha: 0
  }, 14, cjs.Ease.get(1)).wait(85).to({
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(87));
  this.instance_2 = new lib.txt04("synched", 0, false);
  this.instance_2.parent = this;
  this.instance_2.setTransform(108, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance_2._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(295).to({
   _off: false
  }, 0).wait(85));
  this.instance_3 = new lib.txt02("synched", 0, false);
  this.instance_3.parent = this;
  this.instance_3.setTransform(108, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance_3._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(105).to({
   _off: false
  }, 0).wait(75).to({
   startPosition: 34
  }, 0).to({
   alpha: 0
  }, 14, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(185));
  this.instance_4 = new lib.gr();
  this.instance_4.parent = this;
  this.instance_4.setTransform(150, 300, 1, 1, 0, 0, 0, 150, 300);
  this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(180).to({
   alpha: 0
  }, 14, cjs.Ease.get(1)).wait(85).to({
   regY: 300.1,
   y: 300.1,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(87));
  this.instance_5 = new lib.l4();
  this.instance_5.parent = this;
  this.instance_5.setTransform(149.5, 440.1, 1, 1, 0, 0, 0, 149.5, 40.1);
  this.instance_5.alpha = 0;
  this.instance_5._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(310).to({
   _off: false
  }, 0).to({
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(56));
  this.instance_6 = new lib.fish02_float();
  this.instance_6.parent = this;
  this.instance_6.setTransform(706, 227.7, 1, 1, 0, 0, 0, 114, 103.7);
  this.instance_6._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(285).to({
   _off: false
  }, 0).to({
   x: 446
  }, 14, cjs.Ease.get(1)).wait(81));
  var mask = new cjs.Shape();
  mask._off = true;
  var mask_graphics_300 = new cjs.Graphics().p("AV4L+QgTgSAAgbQAAgaATgSQASgTAbAAQAaAAASATQATASAAAaQAAAbgTASQgSATgaAAQgbAAgSgTg");
  var mask_graphics_301 = new cjs.Graphics().p("AUZMOQgqgpAAg7QAAg7AqgpQApgqA7AAQA7AAApAqQAqApAAA7QAAA7gqApQgpAqg7AAQg7AAgpgqg");
  var mask_graphics_302 = new cjs.Graphics().p("ATBMdQg/g/AAhYQAAhZA/g/QA/g/BZAAQBYAAA/A/QA/A/AABZQAABYg/A/Qg/A/hYAAQhZAAg/g/g");
  var mask_graphics_303 = new cjs.Graphics().p("ARwMrQhShSAAh1QAAh0BShTQBThSB0AAQB1AABSBSQBSBTAAB0QAAB1hSBSQhSBSh1AAQh0AAhThSg");
  var mask_graphics_304 = new cjs.Graphics().p("AQmM4QhkhlAAiOQAAiNBkhlQBlhkCNAAQCOAABlBkQBkBlAACNQAACOhkBlQhlBkiOAAQiNAAhlhkg");
  var mask_graphics_305 = new cjs.Graphics().p("APkNDQh1h1AAikQAAilB1h0QB0h1ClAAQCkAAB1B1QB0B0AAClQAACkh0B1Qh1B0ikAAQilAAh0h0g");
  var mask_graphics_306 = new cjs.Graphics().p("AOoNNQiDiDAAi5QAAi5CDiDQCDiDC5AAQC5AACDCDQCDCDAAC5QAAC5iDCDQiDCDi5AAQi5AAiDiDg");
  var mask_graphics_307 = new cjs.Graphics().p("ANzNWQiQiQAAjLQAAjLCQiQQCQiPDLAAQDLAACQCPQCQCQAADLQAADLiQCQQiQCQjLAAQjLAAiQiQg");
  var mask_graphics_308 = new cjs.Graphics().p("ANFNeQiaibAAjbQAAjbCaibQCbiZDbAAQDbAACbCZQCaCbAADbQAADbiaCbQibCajbAAQjbAAibiag");
  var mask_graphics_309 = new cjs.Graphics().p("AMfNkQikikAAjoQAAjoCkikQCkijDoAAQDoAACkCjQCkCkAADoQAADoikCkQikCkjoAAQjoAAikikg");
  var mask_graphics_310 = new cjs.Graphics().p("AL/NqQisisAAjzQAAjzCsisQCsirDzAAQDzAACsCrQCrCsAADzQAADzirCsQisCrjzAAQjzAAisirg");
  var mask_graphics_311 = new cjs.Graphics().p("ALnNuQiyiyAAj7QAAj8CyixQCxixD8AAQD7AACyCxQCyCxAAD8QAAD7iyCyQiyCyj7AAQj8AAixiyg");
  var mask_graphics_312 = new cjs.Graphics().p("ALVNxQi2i2AAkCQAAkBC2i2QC2i1EBAAQECAAC2C1QC2C2AAEBQAAECi2C2Qi2C2kCAAQkBAAi2i2g");
  var mask_graphics_313 = new cjs.Graphics().p("ALKNzQi4i5AAkFQAAkFC4i4QC5i4EFAAQEFAAC5C4QC4C4AAEFQAAEFi4C5Qi5C4kFAAQkFAAi5i4g");
  var mask_graphics_314 = new cjs.Graphics().p("ALIN0Qi5i5AAkHQAAkGC5i4QC5i5EHAAQEGAAC5C5QC5C4AAEGQAAEHi5C5Qi5C5kGAAQkHAAi5i5g");
  this.timeline.addTween(cjs.Tween.get(mask).to({
   graphics: null,
   x: 0,
   y: 0
  }).wait(300).to({
   graphics: mask_graphics_300,
   x: 150.7797,
   y: 78.4797
  }).wait(1).to({
   graphics: mask_graphics_301,
   x: 154.6891,
   y: 82.3891
  }).wait(1).to({
   graphics: mask_graphics_302,
   x: 158.3089,
   y: 86.0089
  }).wait(1).to({
   graphics: mask_graphics_303,
   x: 161.6392,
   y: 89.3392
  }).wait(1).to({
   graphics: mask_graphics_304,
   x: 164.6799,
   y: 92.3799
  }).wait(1).to({
   graphics: mask_graphics_305,
   x: 167.431,
   y: 95.131
  }).wait(1).to({
   graphics: mask_graphics_306,
   x: 169.8925,
   y: 97.5925
  }).wait(1).to({
   graphics: mask_graphics_307,
   x: 172.0644,
   y: 99.7644
  }).wait(1).to({
   graphics: mask_graphics_308,
   x: 173.9467,
   y: 101.6467
  }).wait(1).to({
   graphics: mask_graphics_309,
   x: 175.5394,
   y: 103.2394
  }).wait(1).to({
   graphics: mask_graphics_310,
   x: 176.8426,
   y: 104.5426
  }).wait(1).to({
   graphics: mask_graphics_311,
   x: 177.8561,
   y: 105.5561
  }).wait(1).to({
   graphics: mask_graphics_312,
   x: 178.5801,
   y: 106.2801
  }).wait(1).to({
   graphics: mask_graphics_313,
   x: 179.0145,
   y: 106.7145
  }).wait(1).to({
   graphics: mask_graphics_314,
   x: 179.2497,
   y: 106.9497
  }).wait(66));
  this.instance_7 = new lib.icon03();
  this.instance_7.parent = this;
  this.instance_7.setTransform(294.5, 150.75, 0.8908, 0.8908, 0, 0, 0, 70.9, 71.6);
  this.instance_7._off = true;
  var maskedShapeInstanceList = [this.instance_7];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(300).to({
   _off: false
  }, 0).wait(80));
  this.instance_8 = new lib.bubble_1();
  this.instance_8.parent = this;
  this.instance_8.setTransform(289.4, 142.45, 0.0483, 0.0483, 0, 0, 0, 153.2, 152.1);
  this.instance_8._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(295).to({
   _off: false
  }, 0).to({
   regX: 151.3,
   regY: 151.1,
   scaleX: 0.4838,
   scaleY: 0.4838
  }, 14, cjs.Ease.get(1)).wait(71));
  this.instance_9 = new lib.bubble_1();
  this.instance_9.parent = this;
  this.instance_9.setTransform(112.35, 160.3, 0.0715, 0.0715, 0, 0, 0, 151.1, 151.8);
  this.instance_9._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(290).to({
   _off: false
  }, 0).to({
   regX: 151,
   regY: 151.6,
   scaleX: 0.8333,
   scaleY: 0.8333,
   x: 112.4
  }, 14, cjs.Ease.get(1)).wait(76));
  this.instance_10 = new lib.black_plate();
  this.instance_10.parent = this;
  this.instance_10.alpha = 0;
  this.instance_10._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(277).to({
   _off: false
  }, 0).to({
   alpha: 1
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(87));
  this.instance_11 = new lib.l3();
  this.instance_11.parent = this;
  this.instance_11.setTransform(150.5, 440.1, 1, 1, 0, 0, 0, 149.5, 40.1);
  this.instance_11.alpha = 0;
  this.instance_11._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(205).to({
   _off: false
  }, 0).to({
   alpha: 1
  }, 14, cjs.Ease.get(1)).to({
   _off: true
  }, 74).wait(87));
  this.instance_12 = new lib.packshot_1();
  this.instance_12.parent = this;
  this.instance_12.setTransform(430.4, 415.7, 1, 1, 0, 0, 0, 117.4, 56.7);
  this.instance_12._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(185).to({
   _off: false
  }, 0).to({
   x: 150.4
  }, 14, cjs.Ease.get(1)).to({
   _off: true
  }, 94).wait(87));
  this.instance_13 = new lib.txt03("synched", 0, false);
  this.instance_13.parent = this;
  this.instance_13.setTransform(108, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance_13._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(195).to({
   _off: false
  }, 0).to({
   _off: true
  }, 98).wait(87));
  this.instance_14 = new lib.bubble_1();
  this.instance_14.parent = this;
  this.instance_14.setTransform(128.9, 122, 0.0466, 0.0466, 0, 0, 0, 151.2, 152.2);
  this.instance_14._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(190).to({
   _off: false
  }, 0).to({
   regX: 150.8,
   regY: 150.8,
   scaleX: 0.7719,
   scaleY: 0.7719,
   x: 128.95
  }, 13, cjs.Ease.get(1)).to({
   _off: true
  }, 90).wait(87));
  var mask_1 = new cjs.Shape();
  mask_1._off = true;
  var mask_1_graphics_200 = new cjs.Graphics().p("AY3GcQgJgKAAgNQAAgNAJgJQAJgJANAAQANAAAJAJQAJAJAAANQAAANgJAKQgJAJgNAAQgNAAgJgJg");
  var mask_1_graphics_201 = new cjs.Graphics().p("AW/GuQgmgmAAg2QAAg2AmgmQAmgmA2AAQA2AAAmAmQAmAmAAA2QAAA2gmAmQgmAmg2AAQg2AAgmgmg");
  var mask_1_graphics_202 = new cjs.Graphics().p("AVQHAQhBhBAAhcQAAhbBBhBQBBhBBcAAQBbAABBBBQBBBBAABbQAABchBBBQhBBBhbAAQhcAAhBhBg");
  var mask_1_graphics_203 = new cjs.Graphics().p("ATqHQQhZhaAAh+QAAh/BZhZQBZhYB/AAQB+AABaBYQBZBZAAB/QAAB+hZBaQhaBZh+AAQh/AAhZhZg");
  var mask_1_graphics_204 = new cjs.Graphics().p("ASNHeQhwhvAAifQAAieBwhvQBwhwCeAAQCeAABwBwQBwBvAACeQAACfhwBvQhwBwieAAQieAAhwhwg");
  var mask_1_graphics_205 = new cjs.Graphics().p("AQ4HsQiEiEAAi7QAAi6CEiFQCFiEC7AAQC7AACECEQCECFAAC6QAAC7iECEQiECEi7AAQi7AAiFiEg");
  var mask_1_graphics_206 = new cjs.Graphics().p("APtH4QiWiXAAjUQAAjUCWiXQCWiWDVAAQDVAACWCWQCXCXAADUQAADUiXCXQiWCWjVAAQjVAAiWiWg");
  var mask_1_graphics_207 = new cjs.Graphics().p("AOqICQimimAAjsQAAjqCminQCnimDrAAQDsAACmCmQCnCnAADqQAADsinCmQimCnjsAAQjrAAining");
  var mask_1_graphics_208 = new cjs.Graphics().p("ANxILQi1i0AAj/QAAj+C1i1QC0i0D/AAQD/AAC1C0QC0C1AAD+QAAD/i0C0Qi1C0j/AAQj/AAi0i0g");
  var mask_1_graphics_209 = new cjs.Graphics().p("ANAITQjAjAAAkQQAAkPDAjAQDAjAEQAAQEPAADBDAQDADAAAEPQAAEQjADAQjBDAkPAAQkQAAjAjAg");
  var mask_1_graphics_210 = new cjs.Graphics().p("AMYIZQjKjKAAkdQAAkcDKjKQDKjKEdAAQEdAADKDKQDKDKAAEcQAAEdjKDKQjKDKkdAAQkdAAjKjKg");
  var mask_1_graphics_211 = new cjs.Graphics().p("AL5IeQjRjRAAkoQAAknDRjRQDRjREoAAQEoAADRDRQDRDRAAEnQAAEojRDRQjRDRkoAAQkoAAjRjRg");
  var mask_1_graphics_212 = new cjs.Graphics().p("ALjIhQjXjWAAkwQAAkuDXjXQDWjWEwAAQEvAADXDWQDWDXAAEuQAAEwjWDWQjXDXkvAAQkwAAjWjXg");
  var mask_1_graphics_213 = new cjs.Graphics().p("ALVIkQjZjaAAk0QAAkzDZjaQDajaE0AAQE0AADaDaQDaDaAAEzQAAE0jaDaQjaDZk0AAQk0AAjajZg");
  var mask_1_graphics_214 = new cjs.Graphics().p("ALTIuQjbjbAAk2QAAk0DbjbQDbjbE1AAQE2AADbDbQDaDbAAE0QAAE2jaDbQjbDak2AAQk1AAjbjag");
  this.timeline.addTween(cjs.Tween.get(mask_1).to({
   graphics: null,
   x: 0,
   y: 0
  }).wait(200).to({
   graphics: mask_1_graphics_200,
   x: 164.4477,
   y: 42.0727
  }).wait(1).to({
   graphics: mask_1_graphics_201,
   x: 169.298,
   y: 46.8442
  }).wait(1).to({
   graphics: mask_1_graphics_202,
   x: 173.789,
   y: 51.2622
  }).wait(1).to({
   graphics: mask_1_graphics_203,
   x: 177.9207,
   y: 55.3268
  }).wait(1).to({
   graphics: mask_1_graphics_204,
   x: 181.6932,
   y: 59.0379
  }).wait(1).to({
   graphics: mask_1_graphics_205,
   x: 185.1063,
   y: 62.3956
  }).wait(1).to({
   graphics: mask_1_graphics_206,
   x: 188.1602,
   y: 65.3998
  }).wait(1).to({
   graphics: mask_1_graphics_207,
   x: 190.8548,
   y: 68.0506
  }).wait(1).to({
   graphics: mask_1_graphics_208,
   x: 193.1901,
   y: 70.348
  }).wait(1).to({
   graphics: mask_1_graphics_209,
   x: 195.1661,
   y: 72.2919
  }).wait(1).to({
   graphics: mask_1_graphics_210,
   x: 196.7829,
   y: 73.8824
  }).wait(1).to({
   graphics: mask_1_graphics_211,
   x: 198.0404,
   y: 75.1195
  }).wait(1).to({
   graphics: mask_1_graphics_212,
   x: 198.9386,
   y: 76.0031
  }).wait(1).to({
   graphics: mask_1_graphics_213,
   x: 199.4775,
   y: 76.5332
  }).wait(1).to({
   graphics: mask_1_graphics_214,
   x: 199.8439,
   y: 77.6439
  }).wait(79).to({
   graphics: null,
   x: 0,
   y: 0
  }).wait(87));
  this.instance_15 = new lib._new();
  this.instance_15.parent = this;
  this.instance_15.setTransform(331, 80.75, 1.0444, 1.0454, 0, 0, 0, 58.5, 52.2);
  this.instance_15._off = true;
  var maskedShapeInstanceList = [this.instance_15];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(200).to({
   _off: false
  }, 0).to({
   _off: true
  }, 93).wait(87));
  this.instance_16 = new lib.bubble_1();
  this.instance_16.parent = this;
  this.instance_16.setTransform(317.85, 74.05, 0.1494, 0.1494, 0, 0, 0, 154.3, 154);
  this.instance_16.alpha = 0;
  this.instance_16._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(195).to({
   _off: false
  }, 0).to({
   regX: 153.8,
   regY: 153.8,
   scaleX: 0.4176,
   scaleY: 0.4176,
   x: 317.8,
   alpha: 1
  }, 13, cjs.Ease.get(1)).to({
   _off: true
  }, 85).wait(87));
  this.instance_17 = new lib.bg_g();
  this.instance_17.parent = this;
  this.instance_17.alpha = 0;
  this.instance_17._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(180).to({
   _off: false
  }, 0).to({
   alpha: 1
  }, 14, cjs.Ease.get(1)).to({
   _off: true
  }, 99).wait(87));
  this.instance_18 = new lib.l2();
  this.instance_18.parent = this;
  this.instance_18.setTransform(148.5, 577.85, 1, 1, 0, 0, 0, 141.5, 14.8);
  this.instance_18.alpha = 0;
  this.instance_18._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(120).to({
   _off: false
  }, 0).to({
   alpha: 1
  }, 14, cjs.Ease.get(1)).to({
   _off: true
  }, 61).wait(185));
  this.instance_19 = new lib.l1_1();
  this.instance_19.parent = this;
  this.instance_19.setTransform(148.5, 577.85, 1, 1, 0, 0, 0, 141.5, 14.8);
  this.instance_19.alpha = 0;
  this.instance_19._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(115).to({
   _off: false
  }, 0).to({
   alpha: 1
  }, 14, cjs.Ease.get(1)).to({
   _off: true
  }, 66).wait(185));
  this.instance_20 = new lib.bubble_1();
  this.instance_20.parent = this;
  this.instance_20.setTransform(144.2, 127.75, 0.0395, 0.0395, 0, 0, 0, 149.5, 149.5);
  this.instance_20._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_20).wait(100).to({
   _off: false
  }, 0).to({
   regX: 149.4,
   regY: 149.4,
   scaleX: 1,
   scaleY: 1
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 80).wait(185));
  this.instance_21 = new lib.fish01_float("synched", 0, false);
  this.instance_21.parent = this;
  this.instance_21.setTransform(698, 258.7, 1, 1, 0, 0, 0, 114, 103.7);
  this.instance_21._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_21).wait(95).to({
   _off: false
  }, 0).to({
   x: 438,
   startPosition: 13
  }, 14, cjs.Ease.get(1)).to({
   _off: true
  }, 86).wait(185));
  this.instance_22 = new lib.black_plate();
  this.instance_22.parent = this;
  this.instance_22.alpha = 0;
  this.instance_22._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_22).wait(84).to({
   _off: false
  }, 0).to({
   alpha: 1
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(280));
  this.instance_23 = new lib.l1();
  this.instance_23.parent = this;
  this.instance_23.setTransform(148.5, 577.85, 1, 1, 0, 0, 0, 141.5, 14.8);
  this.instance_23.alpha = 0;
  this.instance_23._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_23).wait(40).to({
   _off: false
  }, 0).to({
   alpha: 1
  }, 14, cjs.Ease.get(1)).to({
   _off: true
  }, 46).wait(280));
  this.instance_24 = new lib.txt02_1("synched", 0, false);
  this.instance_24.parent = this;
  this.instance_24.setTransform(108, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance_24._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_24).wait(26).to({
   _off: false
  }, 0).to({
   _off: true
  }, 74).wait(280));
  this.instance_25 = new lib.txt01("synched", 0, false);
  this.instance_25.parent = this;
  this.instance_25.setTransform(108, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance_25._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_25).wait(5).to({
   _off: false
  }, 0).to({
   _off: true
  }, 95).wait(280));
  this.instance_26 = new lib.bubble_1();
  this.instance_26.parent = this;
  this.instance_26.setTransform(404.15, 172.85, 0.0424, 0.0424, 0, 0, 0, 153.3, 153.3);
  this.instance_26._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_26).wait(20).to({
   _off: false
  }, 0).to({
   regX: 151.3,
   regY: 151.5,
   scaleX: 0.4915,
   scaleY: 0.4915,
   x: 394.9,
   y: 167.1
  }, 14, cjs.Ease.get(1)).to({
   _off: true
  }, 66).wait(280));
  var mask_2 = new cjs.Shape();
  mask_2._off = true;
  var mask_2_graphics_30 = new cjs.Graphics().p("EAkTAVnQgXgXAAggQAAggAXgXQAXgWAgAAQAgAAAWAWQAXAXAAAgQAAAggXAXQgWAWggAAQggAAgXgWg");
  var mask_2_graphics_31 = new cjs.Graphics().p("EAi3AV3QgtguAAg/QAAhAAtgtQAtgtBAAAQBAAAAtAtQAtAtAABAQAAA/gtAuQgtAthAAAQhAAAgtgtg");
  var mask_2_graphics_32 = new cjs.Graphics().p("EAhiAWFQhChCAAhdQAAhdBChCQBChBBdAAQBdAABCBBQBCBCAABdQAABdhCBCQhCBChdAAQhdAAhChCg");
  var mask_2_graphics_33 = new cjs.Graphics().p("EAgUAWTQhVhVAAh4QAAh4BVhVQBVhVB4AAQB4AABVBVQBVBVAAB4QAAB4hVBVQhVBVh4AAQh4AAhVhVg");
  var mask_2_graphics_34 = new cjs.Graphics().p("AfNWfQhnhmAAiRQAAiRBnhmQBmhnCRAAQCRAABmBnQBmBmAACRQAACRhmBmQhmBniRAAQiRAAhmhng");
  var mask_2_graphics_35 = new cjs.Graphics().p("AeMWqQh2h2AAinQAAinB2h2QB2h3CnAAQCnAAB3B3QB2B2AACnQAACnh2B2Qh3B3inAAQinAAh2h3g");
  var mask_2_graphics_36 = new cjs.Graphics().p("AdSW0QiEiEAAi7QAAi7CEiFQCEiEC8AAQC7AACECEQCECFAAC7QAAC7iECEQiECFi7AAQi8AAiEiFg");
  var mask_2_graphics_37 = new cjs.Graphics().p("AcfW9QiRiRAAjMQAAjNCRiRQCRiRDNAAQDMAACRCRQCRCRAADNQAADMiRCRQiRCRjMAAQjNAAiRiRg");
  var mask_2_graphics_38 = new cjs.Graphics().p("AbzXFQicicAAjcQAAjcCcibQCbicDcAAQDcAACcCcQCcCbAADcQAADcicCcQicCbjcAAQjcAAibibg");
  var mask_2_graphics_39 = new cjs.Graphics().p("AbNXLQikikAAjpQAAjpCkilQClilDpAAQDpAAClClQCkClAADpQAADpikCkQilCljpAAQjpAAililg");
  var mask_2_graphics_40 = new cjs.Graphics().p("AavXRQisitAAjzQAAj0CsisQCsisD0AAQDzAACsCsQCsCsAAD0QAADzisCtQisCsjzAAQj0AAisisg");
  var mask_2_graphics_41 = new cjs.Graphics().p("AaXXVQiyiyAAj8QAAj8CyiyQCyiyD8AAQD8AACyCyQCyCyAAD8QAAD8iyCyQiyCyj8AAQj8AAiyiyg");
  var mask_2_graphics_42 = new cjs.Graphics().p("AaGXYQi2i2AAkCQAAkCC2i2QC2i2ECAAQEBAAC3C2QC2C2AAECQAAECi2C2Qi3C2kBAAQkCAAi2i2g");
  var mask_2_graphics_43 = new cjs.Graphics().p("AZ8XZQi5i4AAkFQAAkGC5i4QC4i5EGAAQEFAAC4C5QC5C4AAEGQAAEFi5C4Qi4C5kFAAQkGAAi4i5g");
  var mask_2_graphics_44 = new cjs.Graphics().p("AZ4XaQi6i6AAkGQAAkGC6i6QC5i5EHAAQEGAAC5C5QC6C6AAEGQAAEGi6C6Qi5C5kGAAQkHAAi5i5g");
  this.timeline.addTween(cjs.Tween.get(mask_2).to({
   graphics: null,
   x: 0,
   y: 0
  }).wait(30).to({
   graphics: mask_2_graphics_30,
   x: 245.5039,
   y: 140.5289
  }).wait(1).to({
   graphics: mask_2_graphics_31,
   x: 249.3946,
   y: 144.3617
  }).wait(1).to({
   graphics: mask_2_graphics_32,
   x: 252.9971,
   y: 147.9106
  }).wait(1).to({
   graphics: mask_2_graphics_33,
   x: 256.3114,
   y: 151.1756
  }).wait(1).to({
   graphics: mask_2_graphics_34,
   x: 259.3375,
   y: 154.1566
  }).wait(1).to({
   graphics: mask_2_graphics_35,
   x: 262.0754,
   y: 156.8538
  }).wait(1).to({
   graphics: mask_2_graphics_36,
   x: 264.5251,
   y: 159.2671
  }).wait(1).to({
   graphics: mask_2_graphics_37,
   x: 266.6866,
   y: 161.3964
  }).wait(1).to({
   graphics: mask_2_graphics_38,
   x: 268.5599,
   y: 163.2418
  }).wait(1).to({
   graphics: mask_2_graphics_39,
   x: 270.145,
   y: 164.8033
  }).wait(1).to({
   graphics: mask_2_graphics_40,
   x: 271.4419,
   y: 166.0809
  }).wait(1).to({
   graphics: mask_2_graphics_41,
   x: 272.4506,
   y: 167.0746
  }).wait(1).to({
   graphics: mask_2_graphics_42,
   x: 273.1711,
   y: 167.7844
  }).wait(1).to({
   graphics: mask_2_graphics_43,
   x: 273.6034,
   y: 168.2103
  }).wait(1).to({
   graphics: mask_2_graphics_44,
   x: 273.6796,
   y: 168.3296
  }).wait(56).to({
   graphics: null,
   x: 0,
   y: 0
  }).wait(280));
  this.instance_27 = new lib.icon02();
  this.instance_27.parent = this;
  this.instance_27.setTransform(483.7, 272.95, 1.1221, 1.1221, 0, 0, 0, 56.7, 57.4);
  this.instance_27._off = true;
  var maskedShapeInstanceList = [this.instance_27];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_27).wait(30).to({
   _off: false
  }, 0).to({
   _off: true
  }, 70).wait(280));
  this.instance_28 = new lib.bubble_1();
  this.instance_28.parent = this;
  this.instance_28.setTransform(483.25, 276.5, 0.0576, 0.0576, 0, 0, 0, 151, 151.8);
  this.instance_28._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_28).wait(25).to({
   _off: false
  }, 0).to({
   regX: 151.1,
   regY: 151.6,
   scaleX: 0.4585,
   scaleY: 0.4585,
   x: 475.25,
   y: 269
  }, 14, cjs.Ease.get(1)).to({
   _off: true
  }, 61).wait(280));
  var mask_3 = new cjs.Shape();
  mask_3._off = true;
  var mask_3_graphics_10 = new cjs.Graphics().p("AUqUfQgXgXAAggQAAggAXgWQAWgXAgAAQAgAAAXAXQAWAWAAAgQAAAggWAXQgXAWggAAQggAAgWgWg");
  var mask_3_graphics_11 = new cjs.Graphics().p("AS2UyQgzgyAAhIQAAhHAzgzQAzgzBHAAQBIAAAyAzQAzAzAABHQAABIgzAyQgyAzhIAAQhHAAgzgzg");
  var mask_3_graphics_12 = new cjs.Graphics().p("ARLVFQhNhNAAhsQAAhtBNhMQBMhNBtAAQBsAABNBNQBMBMAABtQAABshMBNQhNBMhsAAQhtAAhMhMg");
  var mask_3_graphics_13 = new cjs.Graphics().p("APoVVQhkhkAAiOQAAiOBkhlQBlhkCOAAQCOAABkBkQBlBlAACOQAACOhlBkQhkBliOAAQiOAAhlhlg");
  var mask_3_graphics_14 = new cjs.Graphics().p("AOOVlQh6h7AAitQAAisB6h7QB7h6CsAAQCtAAB7B6QB6B7AACsQAACth6B7Qh7B6itAAQisAAh7h6g");
  var mask_3_graphics_15 = new cjs.Graphics().p("AM9VyQiOiOAAjIQAAjJCOiOQCOiODJAAQDIAACOCOQCOCOAADJQAADIiOCOQiOCOjIAAQjJAAiOiOg");
  var mask_3_graphics_16 = new cjs.Graphics().p("AL0V/QifigAAjiQAAjhCfigQCgifDhAAQDiAACgCfQCfCgAADhQAADiifCgQigCfjiAAQjhAAigifg");
  var mask_3_graphics_17 = new cjs.Graphics().p("AK0WKQiviwAAj3QAAj4CvivQCvivD4AAQD3AACwCvQCvCvAAD4QAAD3ivCwQiwCvj3AAQj4AAivivg");
  var mask_3_graphics_18 = new cjs.Graphics().p("AJ8WTQi8i9AAkKQAAkLC8i9QC9i8ELAAQEKAAC9C8QC9C9AAELQAAEKi9C9Qi9C9kKAAQkLAAi9i9g");
  var mask_3_graphics_19 = new cjs.Graphics().p("AJNWbQjIjIAAkbQAAkbDIjIQDIjIEbAAQEbAADIDIQDIDIAAEbQAAEbjIDIQjIDIkbAAQkbAAjIjIg");
  var mask_3_graphics_20 = new cjs.Graphics().p("AInWiQjSjSAAkoQAAkoDSjRQDRjSEoAAQEoAADSDSQDRDRAAEoQAAEojRDSQjSDRkoAAQkoAAjRjRg");
  var mask_3_graphics_21 = new cjs.Graphics().p("AIJWnQjZjZAAkyQAAkzDZjYQDYjZEzAAQEyAADZDZQDYDYAAEzQAAEyjYDZQjZDYkyAAQkzAAjYjYg");
  var mask_3_graphics_22 = new cjs.Graphics().p("AHzWqQjejeAAk5QAAk6DejeQDejeE6AAQE5AADeDeQDeDeAAE6QAAE5jeDeQjeDek5AAQk6AAjejeg");
  var mask_3_graphics_23 = new cjs.Graphics().p("AHmWsQjhjgAAk/QAAk+DhjhQDhjhE+AAQE/AADgDhQDhDhAAE+QAAE/jhDgQjgDhk/AAQk+AAjhjhg");
  var mask_3_graphics_24 = new cjs.Graphics().p("AHkWvQjijiAAlAQAAk/DijiQDijiE/AAQFAAADiDiQDiDiAAE/QAAFAjiDiQjiDilAAAQk/AAjijig");
  this.timeline.addTween(cjs.Tween.get(mask_3).to({
   graphics: null,
   x: 0,
   y: 0
  }).wait(10).to({
   graphics: mask_3_graphics_10,
   x: 145.34,
   y: 133.34
  }).wait(1).to({
   graphics: mask_3_graphics_11,
   x: 150.1021,
   y: 138.1021
  }).wait(1).to({
   graphics: mask_3_graphics_12,
   x: 154.5115,
   y: 142.5115
  }).wait(1).to({
   graphics: mask_3_graphics_13,
   x: 158.5682,
   y: 146.5682
  }).wait(1).to({
   graphics: mask_3_graphics_14,
   x: 162.2721,
   y: 150.2721
  }).wait(1).to({
   graphics: mask_3_graphics_15,
   x: 165.6232,
   y: 153.6232
  }).wait(1).to({
   graphics: mask_3_graphics_16,
   x: 168.6216,
   y: 156.6216
  }).wait(1).to({
   graphics: mask_3_graphics_17,
   x: 171.2672,
   y: 159.2672
  }).wait(1).to({
   graphics: mask_3_graphics_18,
   x: 173.5601,
   y: 161.5601
  }).wait(1).to({
   graphics: mask_3_graphics_19,
   x: 175.5002,
   y: 163.5002
  }).wait(1).to({
   graphics: mask_3_graphics_20,
   x: 177.0876,
   y: 165.0876
  }).wait(1).to({
   graphics: mask_3_graphics_21,
   x: 178.3223,
   y: 166.3223
  }).wait(1).to({
   graphics: mask_3_graphics_22,
   x: 179.2041,
   y: 167.2041
  }).wait(1).to({
   graphics: mask_3_graphics_23,
   x: 179.7333,
   y: 167.7333
  }).wait(1).to({
   graphics: mask_3_graphics_24,
   x: 180.075,
   y: 168.075
  }).wait(76).to({
   graphics: null,
   x: 0,
   y: 0
  }).wait(280));
  this.instance_29 = new lib.icon1_2();
  this.instance_29.parent = this;
  this.instance_29.setTransform(277.2, 255.5, 1, 1, 0, 0, 0, 70.7, 71);
  this.instance_29._off = true;
  var maskedShapeInstanceList = [this.instance_29];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_29).wait(10).to({
   _off: false
  }, 0).to({
   _off: true
  }, 90).wait(280));
  this.instance_30 = new lib.bubble_1();
  this.instance_30.parent = this;
  this.instance_30.setTransform(278.05, 263.25, 0.0435, 0.0435, 0, 0, 0, 151.8, 150.7);
  this.instance_30._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_30).wait(5).to({
   _off: false
  }, 0).to({
   regX: 150.6,
   regY: 150.9,
   scaleX: 0.573,
   scaleY: 0.573,
   x: 272.25,
   y: 250.95
  }, 14, cjs.Ease.get(1)).to({
   _off: true
  }, 81).wait(280));
  this.instance_31 = new lib.bubble_1();
  this.instance_31.parent = this;
  this.instance_31.setTransform(144.2, 130.75, 0.0552, 0.0552, 0, 0, 0, 149.3, 149.3);
  this.timeline.addTween(cjs.Tween.get(this.instance_31).to({
   regX: 149.2,
   regY: 149.7,
   scaleX: 0.9203,
   scaleY: 0.9203,
   x: 144.3
  }, 14, cjs.Ease.get(1)).to({
   _off: true
  }, 86).wait(280));
  this.instance_32 = new lib.black_plate();
  this.instance_32.parent = this;
  this.timeline.addTween(cjs.Tween.get(this.instance_32).wait(380));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(-13.4, -21.6, 847.6, 615);
 (lib.toyota_580x400 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.content();
  this.instance.parent = this;
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));
  this.instance_1 = new lib.black_plate();
  this.instance_1.parent = this;
  this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(290, 200, 290, 200);
 lib.properties = {
  id: 'F3EBD96D0C6A5844AFC3B869827983E9',
  width: 580,
  height: 400,
  fps: 30,
  color: "#666666",
  opacity: 1.00,
  manifest: [{
   src: "bubble.png",
   id: "bubble"
  }, {
   src: "fish1.png",
   id: "fish1"
  }, {
   src: "fish2.png",
   id: "fish2"
  }, {
   src: "icon2.png",
   id: "icon2"
  }, {
   src: "icon3.png",
   id: "icon3"
  }, {
   src: "packshot.png",
   id: "packshot"
  }, {
   src: "t2_1_t2_office.png",
   id: "t2_1_t2_office"
  }, {
   src: "t1_t1_office.png",
   id: "t1_t1_office"
  }, {
   src: "icon1_1_icon1_office.png",
   id: "icon1_1_icon1_office"
  }, ],
  preloads: []
 };
 (lib.Stage = function(canvas) {
  createjs.Stage.call(this, canvas);
 }).prototype = p = new createjs.Stage();
 p.setAutoPlay = function(autoPlay) {
  this.tickEnabled = autoPlay;
 }
 p.play = function() {
  this.tickEnabled = true;
  this.getChildAt(0).gotoAndPlay(this.getTimelinePosition())
 }
 p.stop = function(ms) {
  if (ms) this.seek(ms);
  this.tickEnabled = false;
 }
 p.seek = function(ms) {
  this.tickEnabled = true;
  this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000);
 }
 p.getDuration = function() {
  return this.getChildAt(0).totalFrames / lib.properties.fps * 1000;
 }
 p.getTimelinePosition = function() {
  return this.getChildAt(0).currentFrame / lib.properties.fps * 1000;
 }
 an.bootcompsLoaded = an.bootcompsLoaded || [];
 if (!an.bootstrapListeners) {
  an.bootstrapListeners = [];
 }
 an.bootstrapCallback = function(fnCallback) {
  an.bootstrapListeners.push(fnCallback);
  if (an.bootcompsLoaded.length > 0) {
   for (var i = 0; i < an.bootcompsLoaded.length; ++i) {
    fnCallback(an.bootcompsLoaded[i]);
   }
  }
 };
 an.compositions = an.compositions || {};
 an.compositions['F3EBD96D0C6A5844AFC3B869827983E9'] = {
  getStage: function() {
   return exportRoot.getStage();
  },
  getLibrary: function() {
   return lib;
  },
  getSpriteSheet: function() {
   return ss;
  },
  getImages: function() {
   return img;
  }
 };
 an.compositionLoaded = function(id) {
  an.bootcompsLoaded.push(id);
  for (var j = 0; j < an.bootstrapListeners.length; j++) {
   an.bootstrapListeners[j](id);
  }
 }
 an.getComposition = function(id) {
  return an.compositions[id];
 }
 an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {
  var lastW, lastH, lastS = 1;
  window.addEventListener('resize', resizeCanvas);
  resizeCanvas();

  function resizeCanvas() {
   var w = lib.properties.width,
    h = lib.properties.height;
   var iw = window.innerWidth,
    ih = window.innerHeight;
   var pRatio = window.devicePixelRatio || 1,
    xRatio = iw / w,
    yRatio = ih / h,
    sRatio = 1;
   if (isResp) {
    if ((respDim == 'width' && lastW == iw) || (respDim == 'height' && lastH == ih)) {
     sRatio = lastS;
    } else if (!isScale) {
     if (iw < w || ih < h) sRatio = Math.min(xRatio, yRatio);
    } else if (scaleType == 1) {
     sRatio = Math.min(xRatio, yRatio);
    } else if (scaleType == 2) {
     sRatio = Math.max(xRatio, yRatio);
    }
   }
   domContainers[0].width = w * pRatio * sRatio;
   domContainers[0].height = h * pRatio * sRatio;
   domContainers.forEach(function(container) {
    container.style.width = w * sRatio + 'px';
    container.style.height = h * sRatio + 'px';
   });
   stage.scaleX = pRatio * sRatio;
   stage.scaleY = pRatio * sRatio;
   lastW = iw;
   lastH = ih;
   lastS = sRatio;
   stage.tickOnUpdate = false;
   stage.update();
   stage.tickOnUpdate = true;
  }
 }
})(createjs = createjs || {}, AdobeAn = AdobeAn || {});
var createjs, AdobeAn;