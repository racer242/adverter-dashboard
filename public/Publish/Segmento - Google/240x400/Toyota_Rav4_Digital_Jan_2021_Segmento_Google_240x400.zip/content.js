(function(cjs, an) {
 var p;
 var lib = {};
 var ss = {};
 var img = {};
 lib.ssMetadata = [];
 (lib.bg1 = function() {
  this.initialize(img.bg1);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 301, 312);
 (lib.bg2 = function() {
  this.initialize(img.bg2);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 300, 312);
 (lib.bg3 = function() {
  this.initialize(img.bg3);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 300, 314);
 (lib.bg4 = function() {
  this.initialize(img.bg4);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 301, 314);
 (lib.car = function() {
  this.initialize(img.car);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 301, 184);

 function mc_symbol_clone() {
  var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
  clone.gotoAndStop(this.currentFrame);
  clone.paused = this.paused;
  clone.framerate = this.framerate;
  return clone;
 }

 function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
  var prototype = cjs.extend(symbol, cjs.MovieClip);
  prototype.clone = mc_symbol_clone;
  prototype.nominalBounds = nominalBounds;
  prototype.frameBounds = frameBounds;
  return prototype;
 }
 (lib.t06 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#FFFFFF").s().p("AgkBOIAAgfIgTAAIAAgNIATAAIAAgQIgTAAIAAgOIATAAIAAhRIAnAAQAaAAAOANQANAMAAAWQAAAOgFAKQgHALgLAGQgMAIgSgBIgXAAIAAAQIAmAAIAAANIgmAAIAAAfgAgUAEIAXAAQAKAAAIgEQAJgDAFgIQAEgHAAgMQAAgMgEgIQgFgGgJgEQgIgDgKABIgXAAg");
  this.shape.setTransform(144.5, 109.85);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#FFFFFF").s().p("AhACSQgYgXgJglQgJgmAAgvQAAguAJgmQAKgmAXgWQAXgYApAAQAqAAAXAYQAYAWAJAmQAJAmAAAuQAAAwgJAlQgKAlgXAXQgXAWgqAAQgpAAgXgWgAguh0QgPATgGAeQgFAfABAlQgBAmAFAeQAGAfAPASQAQATAeAAQAfAAAQgTQAQgSAFggQAFgfAAgkQAAglgFgfQgGgegPgTQgQgTgfgBQgeABgQATg");
  this.shape_1.setTransform(126.225, 101.35);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#FFFFFF").s().p("AhACSQgYgXgJglQgJgmAAgvQAAguAJgmQAKgmAXgWQAXgYApAAQAqAAAXAYQAYAWAJAmQAJAmAAAuQAAAwgJAlQgKAlgXAXQgXAWgqAAQgpAAgXgWgAguh0QgPATgGAeQgFAfABAlQgBAmAFAeQAGAfAPASQAQATAeAAQAfAAAQgTQAQgSAFggQAFgfAAgkQAAglgFgfQgGgegPgTQgQgTgfgBQgeABgQATg");
  this.shape_2.setTransform(103.075, 101.35);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#FFFFFF").s().p("AhBCjICGknIiuAAIAAgeIDTAAIAAAWIiIEvg");
  this.shape_3.setTransform(79.825, 101.375);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#FFFFFF").s().p("AhSCKQA3AAAhgSQAhgRARgfQARgfADgmQgNASgWANQgVAMgdAAQgdAAgXgOQgWgNgNgXQgMgXgBgfQABgeANgZQAOgYAYgOQAYgOAfgBQAeAAAZAQQAZAQAQAfQAPAfABAuQAAAngLAjQgKAjgWAaQgWAbgjAPQgiAQgzAAgAgoh+QgRALgJARQgKARAAAWQAAAjAUAVQATAUAhAAQAaAAAXgPQAWgNALgYQgCgigLgWQgLgWgRgMQgSgLgUAAQgWABgRAJg");
  this.shape_4.setTransform(48.375, 101.225);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#FFFFFF").s().p("AAkBCIAAgZIhSAAIAAhqIALAAIAABgIA6AAIAAhgIALAAIAABgIANAAIAAAjg");
  this.shape_5.setTransform(221.3, 113.425);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#FFFFFF").s().p("AAaA1IAAgsIgUAAIgCAAIgBAAIgaAsIgNAAIAegvQgKgDgFgHQgFgIAAgKQABgOAIgIQAJgIAPAAIAeAAIAABpgAgDgoQgFACgDAEQgDAFAAAIQAAAHACAFQAEAFAFACQAEACAGAAIATAAIAAgqIgSAAQgGAAgFACg");
  this.shape_6.setTransform(210.35, 112.175);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#FFFFFF").s().p("AgTAwQgMgHgHgNQgHgMAAgQQAAgPAHgNQAHgMAMgHQANgHAPAAQAKAAAJADQAJAEAHAFIgDALQgHgGgIgDQgIgDgJAAQgMAAgKAGQgKAFgFAKQgGAKAAAMQAAANAGAJQAFAKAKAGQAKAGAMAAQAKAAAJgDQAIgEAHgFIADALQgIAGgJADQgKADgKAAQgPAAgNgHg");
  this.shape_7.setTransform(201.425, 112.175);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#FFFFFF").s().p("AgdA1IAAhpIA6AAIAAAKIgvAAIAAAmIAtAAIAAAJIgtAAIAAAmIAwAAIAAAKg");
  this.shape_8.setTransform(192.275, 112.175);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#FFFFFF").s().p("AAmA1IAAhZIgiAyIgHAAIgigyIAABZIgLAAIAAhpIANAAIAjA1IAlg1IAMAAIAABpg");
  this.shape_9.setTransform(181.875, 112.175);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.f("#FFFFFF").s().p("AghA1IAAhpIAdAAQAOAAAJAHQAIAHAAANQAAAHgDAGQgDAGgIAEQAKACAFAGQAGAHAAAKQAAAJgEAHQgEAHgHADQgHAEgLAAgAgWArIAWAAQALAAAGgFQAGgGAAgJQAAgJgGgFQgFgEgKgBIgYAAgAgWgEIATAAQAFAAAFgDQAFgDACgEQADgFAAgFQgBgJgFgEQgGgFgJAAIgSAAg");
  this.shape_10.setTransform(168.425, 112.175);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.f("#FFFFFF").s().p("AgdBFIAxiJIAKAAIgxCJg");
  this.shape_11.setTransform(157.65, 113.1);
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.f("#FFFFFF").s().p("AAjA1IgNgiIgrAAIgOAiIgLAAIAphpIALAAIApBpgAASAJIgSgwIgSAwIAkAAg");
  this.shape_12.setTransform(26.7, 112.175);
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.f("#FFFFFF").s().p("AgWAyQgJgEgFgGIAFgJIAIAHQAFADAFACQAGACAHAAQAMAAAHgGQAHgGAAgKQABgLgKgFQgJgFgRAAIAAgIQALAAAIgDQAHgDADgFQACgFAAgEQAAgJgGgEQgGgFgKAAQgHAAgIAEQgHADgEAEIgGgJQAHgFAIgDQAHgEALAAQAKAAAHAEQAHADAEAGQAEAFAAAJQAAAKgGAGQgGAHgKACQANABAGAGQAHAHABALQgBAKgEAHQgEAHgJAEQgIAEgMAAQgNAAgJgFg");
  this.shape_13.setTransform(17.75, 112.175);
  this.shape_14 = new cjs.Shape();
  this.shape_14.graphics.f("#FFFFFF").s().p("AAeAuIgLgeIglAAIgMAeIgKAAIAkhbIAJAAIAkBbgAAQAIIgQgqIgPAqIAfAAg");
  this.shape_14.setTransform(227.275, 132.575);
  this.shape_15 = new cjs.Shape();
  this.shape_15.graphics.f("#FFFFFF").s().p("AAZAuIAAhSIgyAAIAABSIgJAAIAAhbIBFAAIAABbg");
  this.shape_15.setTransform(218.675, 132.575);
  this.shape_16 = new cjs.Shape();
  this.shape_16.graphics.f("#FFFFFF").s().p("AgYAuIgHgCIACgJIAGADIAFAAQAGAAAEgDQADgDADgIIgkhGIALAAIAdA8IAbg8IAKAAIggBGIgFAMQgCAFgFADQgFADgHAAIgHgBg");
  this.shape_16.setTransform(210.5, 132.65);
  this.shape_17 = new cjs.Shape();
  this.shape_17.graphics.f("#FFFFFF").s().p("AAWAuIglgqIgJAAIAAAqIgJAAIAAhbIAJAAIAAApIAIAAIAjgpIALAAIglAtIApAug");
  this.shape_17.setTransform(203.525, 132.6);
  this.shape_18 = new cjs.Shape();
  this.shape_18.graphics.f("#FFFFFF").s().p("AAjAuIAAhbIAJAAIAABbgAgsAuIAAhbIAKAAIAAAnIAUAAQAPABAHAFQAIAHAAAMQgBAIgDAGQgDAGgHAEQgFADgLAAgAgiAmIATAAQALAAAEgFQAGgFAAgJQAAgJgGgEQgFgEgKAAIgTAAg");
  this.shape_18.setTransform(193.55, 132.575);
  this.shape_19 = new cjs.Shape();
  this.shape_19.graphics.f("#FFFFFF").s().p("AgdAuIAAhbIAaAAQAMAAAHAGQAHAHABAKQAAAHgDAFQgDAFgHAEQAJABAFAGQAEAFABAJQgBAIgDAGQgDAGgHADQgGADgJAAgAgTAmIATAAQAKAAAFgFQAFgFAAgIQAAgIgFgEQgFgEgIAAIgVAAgAgTgDIARAAQAEgBAEgCQAEgCACgEQACgEAAgFQAAgHgFgEQgFgEgIAAIgPAAg");
  this.shape_19.setTransform(184.625, 132.575);
  this.shape_20 = new cjs.Shape();
  this.shape_20.graphics.f("#FFFFFF").s().p("AgXApQgMgGgFgKQgHgMAAgNQAAgNAHgLQAFgKAMgHQALgFAMAAQAOAAALAFQAKAHAHAKQAGALAAANQAAAOgGALQgHAKgKAGQgLAGgOAAQgNAAgKgGgAgTghQgIAFgFAJQgFAIAAALQAAALAFAJQAFAIAIAFQAJAFAKAAQAMAAAIgFQAJgFAEgIQAFgJABgLQgBgLgFgIQgEgJgJgFQgIgEgMAAQgKAAgJAEg");
  this.shape_20.setTransform(172.45, 132.6);
  this.shape_21 = new cjs.Shape();
  this.shape_21.graphics.f("#FFFFFF").s().p("AgZAuIAAhbIAzAAIAAAJIgpAAIAABSg");
  this.shape_21.setTransform(164.55, 132.575);
  this.shape_22 = new cjs.Shape();
  this.shape_22.graphics.f("#FFFFFF").s().p("AgXApQgMgGgFgKQgHgMAAgNQAAgNAHgLQAFgKAMgHQAKgFANAAQAOAAALAFQAKAHAHAKQAGALAAANQAAAOgGALQgHAKgKAGQgLAGgOAAQgNAAgKgGgAgTghQgIAFgFAJQgFAIAAALQAAALAFAJQAFAIAIAFQAJAFAKAAQALAAAJgFQAJgFAEgIQAFgJABgLQgBgLgFgIQgEgJgJgFQgJgEgLAAQgKAAgJAEg");
  this.shape_22.setTransform(155.6, 132.6);
  this.shape_23 = new cjs.Shape();
  this.shape_23.graphics.f("#FFFFFF").s().p("AAaAuIAAgqIgzAAIAAAqIgKAAIAAhbIAKAAIAAAqIAzAAIAAgqIAKAAIAABbg");
  this.shape_23.setTransform(145.625, 132.575);
  this.shape_24 = new cjs.Shape();
  this.shape_24.graphics.f("#FFFFFF").s().p("AgEAuIAAhSIgaAAIAAgJIA8AAIAAAJIgZAAIAABSg");
  this.shape_24.setTransform(137.9, 132.575);
  this.shape_25 = new cjs.Shape();
  this.shape_25.graphics.f("#FFFFFF").s().p("AAeAuIgLgeIglAAIgMAeIgKAAIAkhbIAJAAIAkBbgAAQAIIgQgqIgPAqIAfAAg");
  this.shape_25.setTransform(130.775, 132.575);
  this.shape_26 = new cjs.Shape();
  this.shape_26.graphics.f("#FFFFFF").s().p("AgbAuIAAhbIAZAAQAJAAAHAEQAHADAEAGQADAHAAAIQAAAIgDAHQgEAFgHAFQgHAEgJAAIgQAAIAAAigAgSADIAPAAQAFAAAFgCQAFgCADgEQADgFAAgHQAAgHgDgEQgDgFgFgCQgFgCgFABIgPAAg");
  this.shape_26.setTransform(123.625, 132.575);
  this.shape_27 = new cjs.Shape();
  this.shape_27.graphics.f("#FFFFFF").s().p("AgdAuIAAhbIAwAAIAAAJIgnAAIAAAeIAUAAQAPABAIAFQAHAHAAAMQAAAIgEAGQgDAGgGAEQgHADgKAAgAgUAmIAUAAQAKAAAFgFQAFgFAAgJQAAgJgFgEQgHgEgIAAIgUAAg");
  this.shape_27.setTransform(116.45, 132.575);
  this.shape_28 = new cjs.Shape();
  this.shape_28.graphics.f("#FFFFFF").s().p("AgYApQgKgGgHgKQgGgMAAgNQAAgNAGgLQAHgKAKgHQALgFANAAQAOAAALAFQALAHAGAKQAGALAAANQAAAOgGALQgGAKgLAGQgLAGgOAAQgNAAgLgGgAgSghQgJAFgFAJQgFAIAAALQAAALAFAJQAFAIAJAFQAIAFAKAAQALAAAJgFQAIgFAGgIQAEgJAAgLQAAgLgEgIQgGgJgIgFQgJgEgLAAQgKAAgIAEg");
  this.shape_28.setTransform(107.05, 132.6);
  this.shape_29 = new cjs.Shape();
  this.shape_29.graphics.f("#FFFFFF").s().p("AAcA6IAAhMIg3BMIgJAAIAAhbIAKAAIAABMIA2hMIAJAAIAABbgAgOguQgEgDgBgIIAHAAQABAFADACQAEABAEAAQAGAAADgBQADgCABgFIAHAAQgBAIgFADQgGAEgIAAQgJAAgFgEg");
  this.shape_29.setTransform(94.15, 131.4);
  this.shape_30 = new cjs.Shape();
  this.shape_30.graphics.f("#FFFFFF").s().p("AgZAuIAAhbIAyAAIAAAJIgoAAIAAAhIAnAAIAAAHIgnAAIAAAhIApAAIAAAJg");
  this.shape_30.setTransform(86.125, 132.575);
  this.shape_31 = new cjs.Shape();
  this.shape_31.graphics.f("#FFFFFF").s().p("AAbAuIAAhMIg2BMIgJAAIAAhbIAJAAIAABMIA3hMIAJAAIAABbg");
  this.shape_31.setTransform(77.75, 132.575);
  this.shape_32 = new cjs.Shape();
  this.shape_32.graphics.f("#FFFFFF").s().p("AgDAuIAAhSIgaAAIAAgJIA8AAIAAAJIgaAAIAABSg");
  this.shape_32.setTransform(69.9, 132.575);
  this.shape_33 = new cjs.Shape();
  this.shape_33.graphics.f("#FFFFFF").s().p("AAaAuIAAgqIgzAAIAAAqIgKAAIAAhbIAKAAIAAAqIAzAAIAAgqIAKAAIAABbg");
  this.shape_33.setTransform(62.175, 132.575);
  this.shape_34 = new cjs.Shape();
  this.shape_34.graphics.f("#FFFFFF").s().p("AAeAuIgLgeIglAAIgMAeIgKAAIAkhbIAJAAIAkBbgAAQAIIgQgqIgPAqIAfAAg");
  this.shape_34.setTransform(53.525, 132.575);
  this.shape_35 = new cjs.Shape();
  this.shape_35.graphics.f("#FFFFFF").s().p("AgbAuIAAhbIAZAAQAJAAAHAEQAHADAEAGQADAHAAAIQAAAIgDAHQgEAFgHAFQgHAEgJAAIgQAAIAAAigAgSADIAPAAQAFAAAFgCQAFgCADgEQADgFAAgHQAAgHgDgEQgDgFgFgCQgFgCgFABIgPAAg");
  this.shape_35.setTransform(46.375, 132.575);
  this.shape_36 = new cjs.Shape();
  this.shape_36.graphics.f("#FFFFFF").s().p("AAeAuIgLgeIglAAIgMAeIgKAAIAkhbIAJAAIAkBbgAAQAIIgQgqIgPAqIAfAAg");
  this.shape_36.setTransform(38.475, 132.575);
  this.shape_37 = new cjs.Shape();
  this.shape_37.graphics.f("#FFFFFF").s().p("AgZAuIAAhbIAzAAIAAAJIgpAAIAABSg");
  this.shape_37.setTransform(31.9, 132.575);
  this.shape_38 = new cjs.Shape();
  this.shape_38.graphics.f("#FFFFFF").s().p("AgQApQgLgGgFgKQgHgLAAgOQAAgOAHgKQAFgKALgHQALgFANAAQAJAAAIACQAHADAHAFIgEAJQgFgFgHgCQgIgDgHAAQgKAAgJAEQgIAFgFAJQgFAJAAAKQAAAKAFAKQAFAIAIAFQAJAFAKAAQAJAAAHgDQAIgDAFgEIADAJQgHAFgIADQgIACgKAAQgMAAgLgGg");
  this.shape_38.setTransform(18.35, 132.6);
  this.shape_39 = new cjs.Shape();
  this.shape_39.graphics.f("#FFFFFF").s().p("AgEAyIAAhZIgcAAIAAgKIBBAAIAAAKIgbAAIAABZg");
  this.shape_39.setTransform(70.1, 71.325);
  this.shape_40 = new cjs.Shape();
  this.shape_40.graphics.f("#FFFFFF").s().p("AAeAyIAAhSIg7BSIgKAAIAAhjIAKAAIAABSIA7hSIAKAAIAABjg");
  this.shape_40.setTransform(61.75, 71.325);
  this.shape_41 = new cjs.Shape();
  this.shape_41.graphics.f("#FFFFFF").s().p("AAjA+IAAgYIhFAAIAAAYIgKAAIAAgiIAGAAQAEAAACgCQACgDACgGQACgGAAgGIAIhCIAzAAIAABZIALAAIAAAigAgPAGIgEAPQgCAGgCABIAuAAIAAhPIggAAg");
  this.shape_41.setTransform(52.1, 72.5);
  this.shape_42 = new cjs.Shape();
  this.shape_42.graphics.f("#FFFFFF").s().p("AgbAyIAAhjIA2AAIAAAKIgrAAIAAAjIApAAIAAAIIgpAAIAAAkIAsAAIAAAKg");
  this.shape_42.setTransform(44.325, 71.325);
  this.shape_43 = new cjs.Shape();
  this.shape_43.graphics.f("#FFFFFF").s().p("AgeAyIAAhjIAcAAQAKAAAHAEQAIAEAEAHQADAHAAAJQAAAIgDAHQgEAHgIAEQgHAEgKABIgRAAIAAAlgAgTADIAQAAQAFAAAGgCQAGgCADgFQADgFAAgHQAAgIgDgFQgDgEgGgCQgGgCgFAAIgQAAg");
  this.shape_43.setTransform(37.1, 71.325);
  this.shape_44 = new cjs.Shape();
  this.shape_44.graphics.f("#FFFFFF").s().p("AAYAyIgoguIgJAAIAAAuIgLAAIAAhjIALAAIAAAtIAIAAIAlgtIANAAIgpAxIAtAyg");
  this.shape_44.setTransform(29.525, 71.325);
  this.shape_45 = new cjs.Shape();
  this.shape_45.graphics.f("#FFFFFF").s().p("AgfAyIAAhjIAcAAQANAAAHAHQAJAHgBAMQAAAGgCAGQgEAGgHAEQAJABAFAGQAGAGAAAKQAAAIgEAGQgDAHgIADQgGAEgKAAgAgUApIAUAAQALgBAFgFQAGgFAAgJQAAgIgGgEQgFgFgJAAIgWAAgAgUgEIASAAQAEAAAFgCQADgDADgEQACgEABgFQgBgIgFgFQgFgEgJAAIgQAAg");
  this.shape_45.setTransform(18.15, 71.325);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_45
   }, {
    t: this.shape_44
   }, {
    t: this.shape_43
   }, {
    t: this.shape_42
   }, {
    t: this.shape_41
   }, {
    t: this.shape_40
   }, {
    t: this.shape_39
   }, {
    t: this.shape_38
   }, {
    t: this.shape_37
   }, {
    t: this.shape_36
   }, {
    t: this.shape_35
   }, {
    t: this.shape_34
   }, {
    t: this.shape_33
   }, {
    t: this.shape_32
   }, {
    t: this.shape_31
   }, {
    t: this.shape_30
   }, {
    t: this.shape_29
   }, {
    t: this.shape_28
   }, {
    t: this.shape_27
   }, {
    t: this.shape_26
   }, {
    t: this.shape_25
   }, {
    t: this.shape_24
   }, {
    t: this.shape_23
   }, {
    t: this.shape_22
   }, {
    t: this.shape_21
   }, {
    t: this.shape_20
   }, {
    t: this.shape_19
   }, {
    t: this.shape_18
   }, {
    t: this.shape_17
   }, {
    t: this.shape_16
   }, {
    t: this.shape_15
   }, {
    t: this.shape_14
   }, {
    t: this.shape_13
   }, {
    t: this.shape_12
   }, {
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
 }).prototype = getMCSymbolPrototype(lib.t06, new cjs.Rectangle(11.5, 58, 238.5, 84.6), null);
 (lib.t05 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#FFFFFF").s().p("AAlA5IgNglIgvAAIgOAlIgMAAIAshxIALAAIAsBxgAAUAKIgUg0IgTA0IAnAAg");
  this.shape.setTransform(157.725, 102.775);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#FFFFFF").s().p("AgoA5IgEgCIACgLIAEACIADABQAFAAACgEQADgEAAgHIAIhYIA+AAIAABwIgMAAIAAhlIgnAAIgHBRQgBAKgFAGQgFAFgKAAIgGAAg");
  this.shape_1.setTransform(146.95, 102.825);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#FFFFFF").s().p("AAbA5Igug0IgKAAIAAA0IgMAAIAAhxIAMAAIAAA0IAKAAIArg0IANAAIguA3IAzA6g");
  this.shape_2.setTransform(138.85, 102.775);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#FFFFFF").s().p("AgfA5IAAhxIA+AAIAAALIgyAAIAAAoIAwAAIAAAKIgwAAIAAApIAzAAIAAALg");
  this.shape_3.setTransform(129.275, 102.775);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#FFFFFF").s().p("AgFA5IAAhmIggAAIAAgLIBLAAIAAALIggAAIAABmg");
  this.shape_4.setTransform(120.975, 102.775);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#FFFFFF").s().p("AgUAzQgNgIgIgNQgHgNAAgRQAAgQAIgOQAHgNANgHQAOgHAQAAQALAAAJADQAKADAIAGIgFAMQgGgGgJgEQgJgDgJAAQgNAAgKAGQgLAGgGALQgGAKAAANQAAANAGALQAGALALAGQAKAGANAAQALAAAJgEQAJgDAHgGIADALQgIAHgKADQgKADgMAAQgQAAgNgHg");
  this.shape_5.setTransform(111.825, 102.775);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#FFFFFF").s().p("AgdAzQgOgIgHgNQgIgNAAgRQAAgQAIgNQAHgNAOgIQANgHAQAAQARAAANAHQAOAIAHANQAIANAAAQQAAARgIANQgHANgOAIQgNAHgRAAQgQAAgNgHgAgXgoQgLAGgGALQgGAKAAANQAAAOAGAKQAGALALAGQAKAGANAAQAOAAAKgGQALgGAGgLQAGgKAAgOQAAgNgGgKQgGgLgLgGQgKgGgOAAQgNAAgKAGg");
  this.shape_6.setTransform(96.075, 102.775);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#FFFFFF").s().p("AgeA5IAAhxIA9AAIAAALIgxAAIAABmg");
  this.shape_7.setTransform(86.275, 102.775);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#FFFFFF").s().p("AgdAzQgOgIgHgNQgIgNAAgRQAAgQAIgNQAHgNAOgIQANgHAQAAQARAAANAHQAOAIAHANQAIANAAAQQAAARgIANQgHANgOAIQgNAHgRAAQgQAAgNgHgAgXgoQgLAGgGALQgGAKAAANQAAAOAGAKQAGALALAGQAKAGANAAQAOAAAKgGQALgGAGgLQAGgKAAgOQAAgNgGgKQgGgLgLgGQgKgGgOAAQgNAAgKAGg");
  this.shape_8.setTransform(75.225, 102.775);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#FFFFFF").s().p("AgkA5IAAhxIAgAAQAPAAAJAIQAJAIAAANQABAIgFAGQgDAHgJAEQALACAHAHQAFAHABALQgBAJgEAIQgEAHgHAEQgJAEgKAAgAgXAuIAYAAQALAAAHgGQAFgGAAgKQAAgJgFgFQgGgFgKAAIgaAAgAgXgFIAUAAQAFAAAFgDQAFgDADgEQACgFAAgGQAAgJgFgFQgHgFgJAAIgTAAg");
  this.shape_9.setTransform(64.35, 102.775);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.f("#FFFFFF").s().p("AgdAzQgOgIgHgNQgIgNAAgRQAAgQAIgNQAHgNAOgIQANgHAQAAQARAAANAHQAOAIAHANQAIANAAAQQAAARgIANQgHANgOAIQgNAHgRAAQgQAAgNgHgAgXgoQgLAGgGALQgGAKAAANQAAAOAGAKQAGALALAGQAKAGANAAQAOAAAKgGQALgGAGgLQAGgKAAgOQAAgNgGgKQgGgLgLgGQgKgGgOAAQgNAAgKAGg");
  this.shape_10.setTransform(52.775, 102.775);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.f("#FFFFFF").s().p("AgkA5IAAhxIA7AAIAAALIgvAAIAAAmIAZAAQASAAAJAHQAJAJAAAOQAAAKgEAIQgEAHgIAFQgIAEgMAAgAgYAuIAYAAQAMAAAGgGQAHgFgBgMQAAgKgGgGQgHgFgLAAIgYAAg");
  this.shape_11.setTransform(42.05, 102.775);
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.f("#FFFFFF").s().p("AgdAzQgOgIgHgNQgIgNAAgRQAAgQAIgNQAHgNAOgIQANgHAQAAQARAAANAHQAOAIAHANQAIANAAAQQAAARgIANQgHANgOAIQgNAHgRAAQgQAAgNgHgAgXgoQgLAGgGALQgGAKAAANQAAAOAGAKQAGALALAGQAKAGANAAQAOAAAKgGQALgGAGgLQAGgKAAgOQAAgNgGgKQgGgLgLgGQgKgGgOAAQgNAAgKAGg");
  this.shape_12.setTransform(30.425, 102.775);
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.f("#FFFFFF").s().p("AgoA5IgEgCIACgLIADACIAFABQAEAAACgEQACgEABgHIAJhYIA9AAIAABwIgMAAIAAhlIgnAAIgHBRQgCAKgEAGQgFAFgJAAIgHAAg");
  this.shape_13.setTransform(18, 102.825);
  this.shape_14 = new cjs.Shape();
  this.shape_14.graphics.f("#FFFFFF").s().p("AAoA5IAAhfIgkA1IgIAAIgkg1IAABfIgMAAIAAhxIAOAAIAmA6IAng6IAOAAIAABxg");
  this.shape_14.setTransform(186.15, 78.975);
  this.shape_15 = new cjs.Shape();
  this.shape_15.graphics.f("#FFFFFF").s().p("AgdAzQgOgIgHgNQgIgNAAgRQAAgQAIgNQAHgNAOgIQANgHAQAAQARAAANAHQAOAIAHANQAIANAAAQQAAARgIANQgHANgOAIQgNAHgRAAQgQAAgNgHgAgXgoQgLAGgGALQgGAKAAANQAAAOAGAKQAGALALAGQAKAGANAAQAOAAAKgGQALgGAGgLQAGgKAAgOQAAgNgGgKQgGgLgLgGQgKgGgOAAQgNAAgKAGg");
  this.shape_15.setTransform(172.975, 78.975);
  this.shape_16 = new cjs.Shape();
  this.shape_16.graphics.f("#FFFFFF").s().p("AgjA5IAAhxIAfAAQAPAAAJAIQAJAIAAANQABAIgFAGQgDAHgJAEQAMACAFAHQAGAHABALQAAAJgFAIQgEAHgHAEQgJAEgKAAgAgXAuIAYAAQALAAAHgGQAFgGAAgKQAAgJgFgFQgHgFgJAAIgaAAgAgXgFIAUAAQAFAAAFgDQAGgDACgEQADgFAAgGQgBgJgFgFQgHgFgJAAIgTAAg");
  this.shape_16.setTransform(162.1, 78.975);
  this.shape_17 = new cjs.Shape();
  this.shape_17.graphics.f("#FFFFFF").s().p("AgfA5IAAhxIA+AAIAAALIgyAAIAAAoIAwAAIAAAKIgwAAIAAApIAzAAIAAALg");
  this.shape_17.setTransform(153.075, 78.975);
  this.shape_18 = new cjs.Shape();
  this.shape_18.graphics.f("#FFFFFF").s().p("AgiA5IAAhxIAfAAQAMAAAJAFQAIAEAEAIQAFAHAAALQAAAKgFAIQgEAHgIAFQgJAFgMAAIgTAAIAAArgAgWAEIASAAQAHAAAGgDQAGgCAEgGQADgGAAgIQAAgJgDgFQgEgGgGgCQgGgCgHAAIgSAAg");
  this.shape_18.setTransform(144.75, 78.975);
  this.shape_19 = new cjs.Shape();
  this.shape_19.graphics.f("#FFFFFF").s().p("AgeA5IAAhxIA9AAIAAALIgxAAIAABmg");
  this.shape_19.setTransform(136.775, 78.975);
  this.shape_20 = new cjs.Shape();
  this.shape_20.graphics.f("#FFFFFF").s().p("AgdAzQgOgIgHgNQgIgNAAgRQAAgQAIgNQAHgNAOgIQANgHAQAAQARAAANAHQAOAIAHANQAIANAAAQQAAARgIANQgHANgOAIQgNAHgRAAQgQAAgNgHgAgXgoQgLAGgGALQgGAKAAANQAAAOAGAKQAGALALAGQAKAGANAAQAOAAAKgGQALgGAGgLQAGgKAAgOQAAgNgGgKQgGgLgLgGQgKgGgOAAQgNAAgKAGg");
  this.shape_20.setTransform(125.725, 78.975);
  this.shape_21 = new cjs.Shape();
  this.shape_21.graphics.f("#FFFFFF").s().p("AgkA5IAAhxIA8AAIAAALIgwAAIAAAmIAYAAQATAAAJAHQAJAJAAAOQAAAKgEAIQgEAHgIAFQgIAEgNAAgAgYAuIAXAAQAMAAAHgGQAGgFAAgMQABgKgIgGQgGgFgMAAIgXAAg");
  this.shape_21.setTransform(115, 78.975);
  this.shape_22 = new cjs.Shape();
  this.shape_22.graphics.f("#FFFFFF").s().p("AgdAzQgOgIgHgNQgIgNAAgRQAAgQAIgNQAHgNAOgIQANgHAQAAQARAAANAHQAOAIAHANQAIANAAAQQAAARgIANQgHANgOAIQgNAHgRAAQgQAAgNgHgAgXgoQgLAGgGALQgGAKAAANQAAAOAGAKQAGALALAGQAKAGANAAQAOAAAKgGQALgGAGgLQAGgKAAgOQAAgNgGgKQgGgLgLgGQgKgGgOAAQgNAAgKAGg");
  this.shape_22.setTransform(103.375, 78.975);
  this.shape_23 = new cjs.Shape();
  this.shape_23.graphics.f("#FFFFFF").s().p("AgdAzQgOgIgHgNQgIgNAAgRQAAgQAIgNQAHgNAOgIQANgHAQAAQARAAANAHQAOAIAHANQAIANAAAQQAAARgIANQgHANgOAIQgNAHgRAAQgQAAgNgHgAgXgoQgLAGgGALQgGAKAAANQAAAOAGAKQAGALALAGQAKAGANAAQAOAAAKgGQALgGAGgLQAGgKAAgOQAAgNgGgKQgGgLgLgGQgKgGgOAAQgNAAgKAGg");
  this.shape_23.setTransform(90.125, 78.975);
  this.shape_24 = new cjs.Shape();
  this.shape_24.graphics.f("#FFFFFF").s().p("AgiA5IAAhxIAfAAQAMAAAIAFQAJAEAFAIQAEAHAAALQAAAKgEAIQgFAHgJAFQgIAFgMAAIgTAAIAAArgAgWAEIASAAQAHAAAGgDQAGgCAEgGQAEgGAAgIQAAgJgEgFQgEgGgGgCQgGgCgHAAIgSAAg");
  this.shape_24.setTransform(79.65, 78.975);
  this.shape_25 = new cjs.Shape();
  this.shape_25.graphics.f("#FFFFFF").s().p("AgFA5IAAhmIggAAIAAgLIBLAAIAAALIggAAIAABmg");
  this.shape_25.setTransform(71.025, 78.975);
  this.shape_26 = new cjs.Shape();
  this.shape_26.graphics.f("#FFFFFF").s().p("AAbA5Igug0IgKAAIAAA0IgMAAIAAhxIAMAAIAAA0IAKAAIArg0IANAAIguA3IAzA6g");
  this.shape_26.setTransform(63.25, 78.975);
  this.shape_27 = new cjs.Shape();
  this.shape_27.graphics.f("#FFFFFF").s().p("AgfA5IAAhxIA+AAIAAALIgyAAIAAAoIAwAAIAAAKIgwAAIAAApIAzAAIAAALg");
  this.shape_27.setTransform(53.675, 78.975);
  this.shape_28 = new cjs.Shape();
  this.shape_28.graphics.f("#FFFFFF").s().p("AgoA5IgEgCIACgLIADACIAFABQAEAAACgEQACgEABgHIAJhYIA9AAIAABwIgMAAIAAhlIgnAAIgIBRQgBAKgEAGQgFAFgJAAIgHAAg");
  this.shape_28.setTransform(43.4, 79.025);
  this.shape_29 = new cjs.Shape();
  this.shape_29.graphics.f("#FFFFFF").s().p("AgdA3QgKgDgJgHIADgLQAHAGAKAEQAJADAMAAQALAAAKgFQAKgFAGgJQAGgKABgMIg+AAIAAgKIA+AAQgBgNgGgJQgGgKgJgFQgKgFgMAAQgLAAgJADQgIADgHAGIgEgLQAHgGAKgDQAKgDAMAAQAQAAANAHQANAHAHANQAHAOAAAQQAAARgHAOQgIANgMAHQgNAHgPAAQgNAAgKgDg");
  this.shape_29.setTransform(33.625, 78.975);
  this.shape_30 = new cjs.Shape();
  this.shape_30.graphics.f("#FFFFFF").s().p("AgUAzQgNgIgIgNQgHgNAAgRQAAgQAIgOQAHgNANgHQAOgHAQAAQALAAAJADQAKADAIAGIgFAMQgGgGgJgEQgJgDgJAAQgNAAgKAGQgLAGgGALQgGAKAAANQAAANAGALQAGALALAGQAKAGANAAQALAAAJgEQAJgDAHgGIADALQgIAHgKADQgKADgMAAQgQAAgNgHg");
  this.shape_30.setTransform(19.475, 78.975);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_30
   }, {
    t: this.shape_29
   }, {
    t: this.shape_28
   }, {
    t: this.shape_27
   }, {
    t: this.shape_26
   }, {
    t: this.shape_25
   }, {
    t: this.shape_24
   }, {
    t: this.shape_23
   }, {
    t: this.shape_22
   }, {
    t: this.shape_21
   }, {
    t: this.shape_20
   }, {
    t: this.shape_19
   }, {
    t: this.shape_18
   }, {
    t: this.shape_17
   }, {
    t: this.shape_16
   }, {
    t: this.shape_15
   }, {
    t: this.shape_14
   }, {
    t: this.shape_13
   }, {
    t: this.shape_12
   }, {
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
 }).prototype = getMCSymbolPrototype(lib.t05, new cjs.Rectangle(11.5, 64, 207.5, 50.599999999999994), null);
 (lib.t04 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#FFFFFF").s().p("AAlA5IgNglIgvAAIgOAlIgMAAIAshxIALAAIAsBxgAAUAKIgUg0IgTA0IAnAAg");
  this.shape.setTransform(154.075, 102.775);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#FFFFFF").s().p("AgUAzQgNgIgIgNQgHgNAAgRQAAgQAIgOQAHgNANgHQAOgHAQAAQALAAAJADQAKADAIAGIgFAMQgGgGgJgEQgJgDgJAAQgNAAgKAGQgLAGgGALQgGAKAAANQAAANAGALQAGALALAGQAKAGANAAQALAAAJgEQAJgDAHgGIADALQgIAHgKADQgKADgMAAQgQAAgNgHg");
  this.shape_1.setTransform(143.775, 102.775);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#FFFFFF").s().p("AgfA5IAAhxIA+AAIAAALIgyAAIAAAoIAwAAIAAAKIgwAAIAAApIAzAAIAAALg");
  this.shape_2.setTransform(134.075, 102.775);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#FFFFFF").s().p("AgoA5IgEgCIACgLIAEACIADABQAFAAACgEQADgEAAgHIAIhYIA+AAIAABwIgMAAIAAhlIgnAAIgIBRQAAAKgFAGQgFAFgKAAIgGAAg");
  this.shape_3.setTransform(123.8, 102.825);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#FFFFFF").s().p("AgdAzQgOgIgHgNQgIgNAAgRQAAgQAIgNQAHgNAOgIQANgHAQAAQARAAANAHQAOAIAHANQAIANAAAQQAAARgIANQgHANgOAIQgNAHgRAAQgQAAgNgHgAgXgoQgLAGgGALQgGAKAAANQAAAOAGAKQAGALALAGQAKAGANAAQAOAAAKgGQALgGAGgLQAGgKAAgOQAAgNgGgKQgGgLgLgGQgKgGgOAAQgNAAgKAGg");
  this.shape_4.setTransform(113.025, 102.775);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#FFFFFF").s().p("AAcA5Igug0IgLAAIAAA0IgMAAIAAhxIAMAAIAAA0IAKAAIAqg0IAOAAIguA3IAzA6g");
  this.shape_5.setTransform(102.45, 102.775);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#FFFFFF").s().p("AgdAzQgOgIgHgNQgIgNAAgRQAAgQAIgNQAHgNAOgIQANgHAQAAQARAAANAHQAOAIAHANQAIANAAAQQAAARgIANQgHANgOAIQgNAHgRAAQgQAAgNgHgAgXgoQgLAGgGALQgGAKAAANQAAAOAGAKQAGALALAGQAKAGANAAQAOAAAKgGQALgGAGgLQAGgKAAgOQAAgNgGgKQgGgLgLgGQgKgGgOAAQgNAAgKAGg");
  this.shape_6.setTransform(86.825, 102.775);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#FFFFFF").s().p("AgeA5IAAhxIA9AAIAAALIgxAAIAABmg");
  this.shape_7.setTransform(77.025, 102.775);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#FFFFFF").s().p("AgdAzQgOgIgHgNQgIgNAAgRQAAgQAIgNQAHgNAOgIQANgHAQAAQARAAANAHQAOAIAHANQAIANAAAQQAAARgIANQgHANgOAIQgNAHgRAAQgQAAgNgHgAgXgoQgLAGgGALQgGAKAAANQAAAOAGAKQAGALALAGQAKAGANAAQAOAAAKgGQALgGAGgLQAGgKAAgOQAAgNgGgKQgGgLgLgGQgKgGgOAAQgNAAgKAGg");
  this.shape_8.setTransform(65.975, 102.775);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#FFFFFF").s().p("AgjA5IAAhxIAfAAQAPAAAJAIQAJAIAAANQAAAIgDAGQgEAHgJAEQAMACAFAHQAHAHAAALQAAAJgFAIQgEAHgIAEQgIAEgKAAgAgYAuIAZAAQALAAAHgGQAFgGAAgKQAAgJgFgFQgHgFgKAAIgaAAgAgYgFIAVAAQAFAAAGgDQAFgDACgEQADgFAAgGQgBgJgGgFQgFgFgLAAIgTAAg");
  this.shape_9.setTransform(55.1, 102.775);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.f("#FFFFFF").s().p("AgfA5IAAhxIA+AAIAAALIgyAAIAAAoIAwAAIAAAKIgwAAIAAApIAzAAIAAALg");
  this.shape_10.setTransform(46.075, 102.775);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.f("#FFFFFF").s().p("AgoA5IgEgCIACgLIAEACIADABQAFAAACgEQADgEAAgHIAIhYIA+AAIAABwIgMAAIAAhlIgnAAIgHBRQgBAKgFAGQgFAFgKAAIgGAAg");
  this.shape_11.setTransform(35.8, 102.825);
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.f("#FFFFFF").s().p("AgfA5IgIgDIAEgLQACACADABIAIABQAHAAAEgEQAFgEAEgIIgthXIANAAIAkBKIAhhKIANAAIgmBWIgIAOQgDAHgFADQgGAEgKAAIgJgBg");
  this.shape_12.setTransform(27.2, 102.85);
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.f("#FFFFFF").s().p("AgiA5IAAhxIAfAAQAMAAAJAFQAIAEAEAIQAFAHAAALQAAAKgFAIQgEAHgIAFQgJAFgMAAIgTAAIAAArgAgWAEIASAAQAHAAAGgDQAGgCAEgGQADgGAAgIQAAgJgDgFQgEgGgGgCQgGgCgHAAIgSAAg");
  this.shape_13.setTransform(18.65, 102.775);
  this.shape_14 = new cjs.Shape();
  this.shape_14.graphics.f("#FFFFFF").s().p("AAoA5IAAhfIgkA1IgIAAIgkg1IAABfIgMAAIAAhxIAOAAIAmA6IAng6IAOAAIAABxg");
  this.shape_14.setTransform(186.15, 78.975);
  this.shape_15 = new cjs.Shape();
  this.shape_15.graphics.f("#FFFFFF").s().p("AgdAzQgOgIgHgNQgIgNAAgRQAAgQAIgNQAHgNAOgIQANgHAQAAQARAAANAHQAOAIAHANQAIANAAAQQAAARgIANQgHANgOAIQgNAHgRAAQgQAAgNgHgAgXgoQgLAGgGALQgGAKAAANQAAAOAGAKQAGALALAGQAKAGANAAQAOAAAKgGQALgGAGgLQAGgKAAgOQAAgNgGgKQgGgLgLgGQgKgGgOAAQgNAAgKAGg");
  this.shape_15.setTransform(172.975, 78.975);
  this.shape_16 = new cjs.Shape();
  this.shape_16.graphics.f("#FFFFFF").s().p("AgjA5IAAhxIAfAAQAPAAAJAIQAJAIAAANQABAIgFAGQgDAHgJAEQAMACAFAHQAGAHABALQAAAJgFAIQgEAHgHAEQgJAEgKAAgAgXAuIAYAAQALAAAHgGQAFgGAAgKQAAgJgFgFQgHgFgJAAIgaAAgAgXgFIAUAAQAFAAAFgDQAGgDACgEQADgFAAgGQgBgJgFgFQgHgFgJAAIgTAAg");
  this.shape_16.setTransform(162.1, 78.975);
  this.shape_17 = new cjs.Shape();
  this.shape_17.graphics.f("#FFFFFF").s().p("AgfA5IAAhxIA+AAIAAALIgyAAIAAAoIAwAAIAAAKIgwAAIAAApIAzAAIAAALg");
  this.shape_17.setTransform(153.075, 78.975);
  this.shape_18 = new cjs.Shape();
  this.shape_18.graphics.f("#FFFFFF").s().p("AgiA5IAAhxIAfAAQAMAAAJAFQAIAEAEAIQAFAHAAALQAAAKgFAIQgEAHgIAFQgJAFgMAAIgTAAIAAArgAgWAEIASAAQAHAAAGgDQAGgCAEgGQADgGAAgIQAAgJgDgFQgEgGgGgCQgGgCgHAAIgSAAg");
  this.shape_18.setTransform(144.75, 78.975);
  this.shape_19 = new cjs.Shape();
  this.shape_19.graphics.f("#FFFFFF").s().p("AgeA5IAAhxIA9AAIAAALIgxAAIAABmg");
  this.shape_19.setTransform(136.775, 78.975);
  this.shape_20 = new cjs.Shape();
  this.shape_20.graphics.f("#FFFFFF").s().p("AgdAzQgOgIgHgNQgIgNAAgRQAAgQAIgNQAHgNAOgIQANgHAQAAQARAAANAHQAOAIAHANQAIANAAAQQAAARgIANQgHANgOAIQgNAHgRAAQgQAAgNgHgAgXgoQgLAGgGALQgGAKAAANQAAAOAGAKQAGALALAGQAKAGANAAQAOAAAKgGQALgGAGgLQAGgKAAgOQAAgNgGgKQgGgLgLgGQgKgGgOAAQgNAAgKAGg");
  this.shape_20.setTransform(125.725, 78.975);
  this.shape_21 = new cjs.Shape();
  this.shape_21.graphics.f("#FFFFFF").s().p("AgkA5IAAhxIA8AAIAAALIgwAAIAAAmIAYAAQATAAAJAHQAJAJAAAOQAAAKgEAIQgEAHgIAFQgIAEgNAAgAgYAuIAXAAQAMAAAHgGQAGgFAAgMQABgKgIgGQgGgFgMAAIgXAAg");
  this.shape_21.setTransform(115, 78.975);
  this.shape_22 = new cjs.Shape();
  this.shape_22.graphics.f("#FFFFFF").s().p("AgdAzQgOgIgHgNQgIgNAAgRQAAgQAIgNQAHgNAOgIQANgHAQAAQARAAANAHQAOAIAHANQAIANAAAQQAAARgIANQgHANgOAIQgNAHgRAAQgQAAgNgHgAgXgoQgLAGgGALQgGAKAAANQAAAOAGAKQAGALALAGQAKAGANAAQAOAAAKgGQALgGAGgLQAGgKAAgOQAAgNgGgKQgGgLgLgGQgKgGgOAAQgNAAgKAGg");
  this.shape_22.setTransform(103.375, 78.975);
  this.shape_23 = new cjs.Shape();
  this.shape_23.graphics.f("#FFFFFF").s().p("AgdAzQgOgIgHgNQgIgNAAgRQAAgQAIgNQAHgNAOgIQANgHAQAAQARAAANAHQAOAIAHANQAIANAAAQQAAARgIANQgHANgOAIQgNAHgRAAQgQAAgNgHgAgXgoQgLAGgGALQgGAKAAANQAAAOAGAKQAGALALAGQAKAGANAAQAOAAAKgGQALgGAGgLQAGgKAAgOQAAgNgGgKQgGgLgLgGQgKgGgOAAQgNAAgKAGg");
  this.shape_23.setTransform(90.125, 78.975);
  this.shape_24 = new cjs.Shape();
  this.shape_24.graphics.f("#FFFFFF").s().p("AgiA5IAAhxIAfAAQAMAAAIAFQAJAEAFAIQAEAHAAALQAAAKgEAIQgFAHgJAFQgIAFgMAAIgTAAIAAArgAgWAEIASAAQAHAAAGgDQAGgCAEgGQAEgGAAgIQAAgJgEgFQgEgGgGgCQgGgCgHAAIgSAAg");
  this.shape_24.setTransform(79.65, 78.975);
  this.shape_25 = new cjs.Shape();
  this.shape_25.graphics.f("#FFFFFF").s().p("AgFA5IAAhmIggAAIAAgLIBLAAIAAALIggAAIAABmg");
  this.shape_25.setTransform(71.025, 78.975);
  this.shape_26 = new cjs.Shape();
  this.shape_26.graphics.f("#FFFFFF").s().p("AAbA5Igug0IgKAAIAAA0IgMAAIAAhxIAMAAIAAA0IAKAAIArg0IANAAIguA3IAzA6g");
  this.shape_26.setTransform(63.25, 78.975);
  this.shape_27 = new cjs.Shape();
  this.shape_27.graphics.f("#FFFFFF").s().p("AgfA5IAAhxIA+AAIAAALIgyAAIAAAoIAwAAIAAAKIgwAAIAAApIAzAAIAAALg");
  this.shape_27.setTransform(53.675, 78.975);
  this.shape_28 = new cjs.Shape();
  this.shape_28.graphics.f("#FFFFFF").s().p("AgoA5IgEgCIACgLIADACIAFABQAEAAACgEQACgEABgHIAJhYIA9AAIAABwIgMAAIAAhlIgnAAIgIBRQgBAKgEAGQgFAFgJAAIgHAAg");
  this.shape_28.setTransform(43.4, 79.025);
  this.shape_29 = new cjs.Shape();
  this.shape_29.graphics.f("#FFFFFF").s().p("AgdA3QgKgDgJgHIADgLQAHAGAKAEQAJADAMAAQALAAAKgFQAKgFAGgJQAGgKABgMIg+AAIAAgKIA+AAQgBgNgGgJQgGgKgJgFQgKgFgMAAQgLAAgJADQgIADgHAGIgEgLQAHgGAKgDQAKgDAMAAQAQAAANAHQANAHAHANQAHAOAAAQQAAARgHAOQgIANgMAHQgNAHgPAAQgNAAgKgDg");
  this.shape_29.setTransform(33.625, 78.975);
  this.shape_30 = new cjs.Shape();
  this.shape_30.graphics.f("#FFFFFF").s().p("AgUAzQgNgIgIgNQgHgNAAgRQAAgQAIgOQAHgNANgHQAOgHAQAAQALAAAJADQAKADAIAGIgFAMQgGgGgJgEQgJgDgJAAQgNAAgKAGQgLAGgGALQgGAKAAANQAAANAGALQAGALALAGQAKAGANAAQALAAAJgEQAJgDAHgGIADALQgIAHgKADQgKADgMAAQgQAAgNgHg");
  this.shape_30.setTransform(19.475, 78.975);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_30
   }, {
    t: this.shape_29
   }, {
    t: this.shape_28
   }, {
    t: this.shape_27
   }, {
    t: this.shape_26
   }, {
    t: this.shape_25
   }, {
    t: this.shape_24
   }, {
    t: this.shape_23
   }, {
    t: this.shape_22
   }, {
    t: this.shape_21
   }, {
    t: this.shape_20
   }, {
    t: this.shape_19
   }, {
    t: this.shape_18
   }, {
    t: this.shape_17
   }, {
    t: this.shape_16
   }, {
    t: this.shape_15
   }, {
    t: this.shape_14
   }, {
    t: this.shape_13
   }, {
    t: this.shape_12
   }, {
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
 }).prototype = getMCSymbolPrototype(lib.t04, new cjs.Rectangle(11.5, 64, 207.5, 50.599999999999994), null);
 (lib.t03 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#FFFFFF").s().p("AAlA5IgNglIgvAAIgOAlIgMAAIAshxIALAAIAsBxgAAUAKIgUg0IgTA0IAnAAg");
  this.shape.setTransform(122.275, 126.575);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#FFFFFF").s().p("AAoBGIAAgbIhPAAIAAAbIgLAAIAAgmIAHAAQADABADgEQADgEACgFIADgPIAIhKIA7AAIAABlIANAAIAAAmgAgRAGQgCALgCAHQgDAGgCACIAzAAIAAhaIgjAAg");
  this.shape_1.setTransform(112.15, 127.9);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#FFFFFF").s().p("AAbA5IAAgwIgVAAIgCAAIgBAAIgcAwIgNAAIAfgyQgKgEgGgHQgFgIAAgLQABgPAJgJQAKgJAPAAIAgAAIAABxgAgDgrQgFACgEAFQgDAFgBAIQAAAIADAFQAEAFAFADQAFACAGAAIAUAAIAAgtIgTAAQgHAAgEACg");
  this.shape_2.setTransform(102.1, 126.575);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#FFFFFF").s().p("AgiA5IAAhxIAgAAQALAAAIAFQAJAEAFAIQAEAHAAALQAAAKgEAIQgFAHgJAFQgIAFgLAAIgUAAIAAArgAgWAEIASAAQAHAAAGgDQAGgCADgGQAFgGAAgIQAAgJgFgFQgDgGgGgCQgGgCgHAAIgSAAg");
  this.shape_3.setTransform(94.2, 126.575);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#FFFFFF").s().p("AgdAzQgOgIgHgNQgIgNAAgRQAAgQAIgNQAHgNAOgIQANgHAQAAQARAAANAHQAOAIAHANQAIANAAAQQAAARgIANQgHANgOAIQgNAHgRAAQgQAAgNgHgAgXgoQgLAGgGALQgGAKAAANQAAAOAGAKQAGALALAGQAKAGANAAQAOAAAKgGQALgGAGgLQAGgKAAgOQAAgNgGgKQgGgLgLgGQgKgGgOAAQgNAAgKAGg");
  this.shape_4.setTransform(79.475, 126.575);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#FFFFFF").s().p("AgeA5IAAhxIA9AAIAAALIgxAAIAABmg");
  this.shape_5.setTransform(69.775, 126.575);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#FFFFFF").s().p("AgdAzQgOgIgHgNQgIgNAAgRQAAgQAIgNQAHgNAOgIQANgHAQAAQARAAANAHQAOAIAHANQAIANAAAQQAAARgIANQgHANgOAIQgNAHgRAAQgQAAgNgHgAgXgoQgLAGgGALQgGAKAAANQAAAOAGAKQAGALALAGQAKAGANAAQAOAAAKgGQALgGAGgLQAGgKAAgOQAAgNgGgKQgGgLgLgGQgKgGgOAAQgNAAgKAGg");
  this.shape_6.setTransform(58.825, 126.575);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#FFFFFF").s().p("AgiA5IAAhxIAfAAQAMAAAJAFQAIAEAEAIQAFAHAAALQAAAKgFAIQgEAHgIAFQgJAFgMAAIgTAAIAAArgAgWAEIASAAQAHAAAGgDQAGgCAEgGQADgGAAgIQAAgJgDgFQgEgGgGgCQgGgCgHAAIgSAAg");
  this.shape_7.setTransform(48.45, 126.575);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#FFFFFF").s().p("AgdAzQgOgIgHgNQgIgNAAgRQAAgQAIgNQAHgNAOgIQANgHAQAAQARAAANAHQAOAIAHANQAIANAAAQQAAARgIANQgHANgOAIQgNAHgRAAQgQAAgNgHgAgXgoQgLAGgGALQgGAKAAANQAAAOAGAKQAGALALAGQAKAGANAAQAOAAAKgGQALgGAGgLQAGgKAAgOQAAgNgGgKQgGgLgLgGQgKgGgOAAQgNAAgKAGg");
  this.shape_8.setTransform(37.125, 126.575);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#FFFFFF").s().p("AgFA5IAAhmIggAAIAAgLIBLAAIAAALIggAAIAABmg");
  this.shape_9.setTransform(26.775, 126.575);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.f("#FFFFFF").s().p("AgkA5IAAhxIAgAAQAPAAAJAIQAJAIAAANQABAIgFAGQgDAHgIAEQAKACAHAHQAFAHAAALQAAAJgEAIQgEAHgHAEQgJAEgKAAgAgXAuIAXAAQAMAAAGgGQAHgGgBgKQABgJgHgFQgGgFgJAAIgaAAgAgXgFIAUAAQAGAAAEgDQAFgDADgEQACgFAAgGQAAgJgFgFQgHgFgJAAIgTAAg");
  this.shape_10.setTransform(18.8, 126.575);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.f("#FFFFFF").s().p("AAbA5IAAgwIgVAAIgBAAIgBAAIgdAwIgNAAIAfgyQgKgEgFgHQgGgIAAgLQAAgPAKgJQAJgJAQAAIAhAAIAABxgAgDgrQgGACgDAFQgEAFAAAIQAAAIAEAFQADAFAGADQAEACAGAAIAUAAIAAgtIgTAAQgGAAgFACg");
  this.shape_11.setTransform(181.05, 102.775);
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.f("#FFFFFF").s().p("AgoA5IgEgCIACgLIADACIAFABQAEAAACgEQACgEABgHIAJhYIA9AAIAABwIgMAAIAAhlIgnAAIgIBRQgBAKgEAGQgFAFgJAAIgHAAg");
  this.shape_12.setTransform(171.2, 102.825);
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.f("#FFFFFF").s().p("AAoBGIAAgbIhPAAIAAAbIgLAAIAAglIAHAAQADgBADgDQADgDACgHIADgNIAIhLIA7AAIAABmIANAAIAAAlgAgSAGQAAALgDAHQgCAHgEACIA0AAIAAhbIgjAAg");
  this.shape_13.setTransform(161.9, 104.1);
  this.shape_14 = new cjs.Shape();
  this.shape_14.graphics.f("#FFFFFF").s().p("AAiA5IAAheIhDBeIgMAAIAAhxIANAAIAABeIBCheIALAAIAABxg");
  this.shape_14.setTransform(147.85, 102.775);
  this.shape_15 = new cjs.Shape();
  this.shape_15.graphics.f("#FFFFFF").s().p("AAoA5IAAhfIgkA1IgIAAIgkg1IAABfIgLAAIAAhxIANAAIAmA6IAng6IANAAIAABxg");
  this.shape_15.setTransform(135.55, 102.775);
  this.shape_16 = new cjs.Shape();
  this.shape_16.graphics.f("#FFFFFF").s().p("AAlA5IgNglIgvAAIgOAlIgMAAIAshxIALAAIAsBxgAAUAKIgUg0IgTA0IAnAAg");
  this.shape_16.setTransform(124.125, 102.775);
  this.shape_17 = new cjs.Shape();
  this.shape_17.graphics.f("#FFFFFF").s().p("AAoBGIAAgbIhPAAIAAAbIgLAAIAAglIAHAAQADgBADgDQADgDACgHIADgNIAIhLIA6AAIAABmIAOAAIAAAlgAgSAGQgBALgCAHQgDAHgDACIA0AAIAAhbIgjAAg");
  this.shape_17.setTransform(114, 104.1);
  this.shape_18 = new cjs.Shape();
  this.shape_18.graphics.f("#FFFFFF").s().p("AgdAzQgOgIgHgNQgIgNAAgRQAAgQAIgNQAHgNAOgIQANgHAQAAQARAAANAHQAOAIAHANQAIANAAAQQAAARgIANQgHANgOAIQgNAHgRAAQgQAAgNgHgAgXgoQgLAGgGALQgGAKAAANQAAAOAGAKQAGALALAGQAKAGANAAQAOAAAKgGQALgGAGgLQAGgKAAgOQAAgNgGgKQgGgLgLgGQgKgGgOAAQgNAAgKAGg");
  this.shape_18.setTransform(102.575, 102.775);
  this.shape_19 = new cjs.Shape();
  this.shape_19.graphics.f("#FFFFFF").s().p("AgkA5IAAhxIAgAAQAPAAAJAIQAJAIAAANQABAIgFAGQgDAHgIAEQAKACAHAHQAFAHABALQgBAJgEAIQgEAHgHAEQgJAEgKAAgAgXAuIAYAAQALAAAHgGQAFgGAAgKQAAgJgFgFQgGgFgKAAIgaAAgAgXgFIAUAAQAFAAAFgDQAFgDADgEQACgFAAgGQAAgJgFgFQgHgFgJAAIgTAAg");
  this.shape_19.setTransform(91.8, 102.775);
  this.shape_20 = new cjs.Shape();
  this.shape_20.graphics.f("#FFFFFF").s().p("AgdAzQgOgIgHgNQgIgNAAgRQAAgQAIgNQAHgNAOgIQANgHAQAAQARAAANAHQAOAIAHANQAIANAAAQQAAARgIANQgHANgOAIQgNAHgRAAQgQAAgNgHgAgXgoQgLAGgGALQgGAKAAANQAAAOAGAKQAGALALAGQAKAGANAAQAOAAAKgGQALgGAGgLQAGgKAAgOQAAgNgGgKQgGgLgLgGQgKgGgOAAQgNAAgKAGg");
  this.shape_20.setTransform(80.325, 102.775);
  this.shape_21 = new cjs.Shape();
  this.shape_21.graphics.f("#FFFFFF").s().p("AAgA5IgggwIggAwIgNAAIAng5Igmg4IAOAAIAeAvIAggvIAMAAIglA4IAnA5g");
  this.shape_21.setTransform(68.925, 102.775);
  this.shape_22 = new cjs.Shape();
  this.shape_22.graphics.f("#FFFFFF").s().p("AgfA5IgIgDIAEgLQACACADABIAIABQAHAAAEgEQAFgEAEgIIgthXIANAAIAlBKIAghKIANAAIgmBWIgIAOQgDAHgFADQgGAEgKAAIgJgBg");
  this.shape_22.setTransform(59.5, 102.85);
  this.shape_23 = new cjs.Shape();
  this.shape_23.graphics.f("#FFFFFF").s().p("AAoBGIAAgbIhPAAIAAAbIgLAAIAAglIAHAAQADgBADgDQADgDACgHIADgNIAIhLIA6AAIAABmIAOAAIAAAlgAgSAGQgBALgCAHQgDAHgDACIA1AAIAAhbIgkAAg");
  this.shape_23.setTransform(49.65, 104.1);
  this.shape_24 = new cjs.Shape();
  this.shape_24.graphics.f("#FFFFFF").s().p("AgXA2QgKgFgGgHIAGgJIAJAHQAEAEAGACQAHABAHAAQANABAHgHQAIgFAAgMQAAgLgKgFQgJgGgTAAIAAgJQANAAAHgEQAIgDADgEQADgFAAgGQAAgIgHgFQgGgFgLAAQgIAAgIAEQgHADgFAFIgGgKQAHgFAIgEQAJgDALgBQAKABAIADQAIADAEAHQAEAGABAIQgBALgGAHQgGAHgLACQANACAHAGQAIAHAAAMQAAAKgFAIQgEAHgJAFQgJAEgNAAQgNAAgKgEg");
  this.shape_24.setTransform(40.275, 102.8);
  this.shape_25 = new cjs.Shape();
  this.shape_25.graphics.f("#FFFFFF").s().p("AgdAzQgOgIgHgNQgIgNAAgRQAAgQAIgNQAHgNAOgIQANgHAQAAQARAAANAHQAOAIAHANQAIANAAAQQAAARgIANQgHANgOAIQgNAHgRAAQgQAAgNgHgAgXgoQgLAGgGALQgGAKAAANQAAAOAGAKQAGALALAGQAKAGANAAQAOAAAKgGQALgGAGgLQAGgKAAgOQAAgNgGgKQgGgLgLgGQgKgGgOAAQgNAAgKAGg");
  this.shape_25.setTransform(29.575, 102.775);
  this.shape_26 = new cjs.Shape();
  this.shape_26.graphics.f("#FFFFFF").s().p("AgkA5IAAhxIAgAAQAPAAAJAIQAJAIAAANQABAIgFAGQgDAHgIAEQAKACAHAHQAFAHAAALQAAAJgEAIQgEAHgHAEQgJAEgKAAgAgXAuIAXAAQAMAAAGgGQAHgGgBgKQABgJgHgFQgGgFgJAAIgaAAgAgXgFIAUAAQAGAAAEgDQAFgDADgEQACgFAAgGQAAgJgFgFQgHgFgJAAIgTAAg");
  this.shape_26.setTransform(18.8, 102.775);
  this.shape_27 = new cjs.Shape();
  this.shape_27.graphics.f("#FFFFFF").s().p("AAiA5IAAheIhDBeIgMAAIAAhxIANAAIAABeIBCheIALAAIAABxg");
  this.shape_27.setTransform(187, 78.975);
  this.shape_28 = new cjs.Shape();
  this.shape_28.graphics.f("#FFFFFF").s().p("AAoA5IAAhfIgkA1IgIAAIgkg1IAABfIgLAAIAAhxIANAAIAmA6IAng6IANAAIAABxg");
  this.shape_28.setTransform(174.7, 78.975);
  this.shape_29 = new cjs.Shape();
  this.shape_29.graphics.f("#FFFFFF").s().p("AAqA5IAAhxIANAAIAABxgAg2A5IAAhxIAMAAIAAAxIAZAAQASAAAJAHQAJAJAAAOQAAAKgEAIQgEAHgIAFQgHAEgNAAgAgqAuIAXAAQANAAAGgGQAGgFAAgMQABgKgHgGQgGgFgNAAIgXAAg");
  this.shape_29.setTransform(161.45, 78.975);
  this.shape_30 = new cjs.Shape();
  this.shape_30.graphics.f("#FFFFFF").s().p("AAgA5IAAg0Ig/AAIAAA0IgMAAIAAhxIAMAAIAAAzIA/AAIAAgzIAMAAIAABxg");
  this.shape_30.setTransform(149.025, 78.975);
  this.shape_31 = new cjs.Shape();
  this.shape_31.graphics.f("#FFFFFF").s().p("AgkA5IAAhxIAMAAIAAAxIAYAAQATAAAJAHQAJAJAAAOQAAAKgEAIQgEAHgIAFQgIAEgNAAgAgYAuIAXAAQAMAAAHgGQAGgFAAgMQABgKgIgGQgGgFgMAAIgXAAg");
  this.shape_31.setTransform(139.3, 78.975);
  this.shape_32 = new cjs.Shape();
  this.shape_32.graphics.f("#FFFFFF").s().p("AgoA5IgEgCIACgLIAEACIADABQAFAAACgEQADgEAAgHIAIhYIA+AAIAABwIgMAAIAAhlIgnAAIgHBRQgBAKgFAGQgFAFgJAAIgHAAg");
  this.shape_32.setTransform(128.6, 79.025);
  this.shape_33 = new cjs.Shape();
  this.shape_33.graphics.f("#FFFFFF").s().p("AgfA5IAAhxIA+AAIAAALIgyAAIAAAoIAwAAIAAAKIgwAAIAAApIAzAAIAAALg");
  this.shape_33.setTransform(120.475, 78.975);
  this.shape_34 = new cjs.Shape();
  this.shape_34.graphics.f("#FFFFFF").s().p("AgFA5IAAhmIggAAIAAgLIBLAAIAAALIggAAIAABmg");
  this.shape_34.setTransform(112.275, 78.975);
  this.shape_35 = new cjs.Shape();
  this.shape_35.graphics.f("#FFFFFF").s().p("AAiA5IAAheIhDBeIgLAAIAAhxIAMAAIAABeIBCheIAMAAIAABxg");
  this.shape_35.setTransform(102.7, 78.975);
  this.shape_36 = new cjs.Shape();
  this.shape_36.graphics.f("#FFFFFF").s().p("AAgA5IAAg0Ig/AAIAAA0IgMAAIAAhxIAMAAIAAAzIA/AAIAAgzIAMAAIAABxg");
  this.shape_36.setTransform(91.225, 78.975);
  this.shape_37 = new cjs.Shape();
  this.shape_37.graphics.f("#FFFFFF").s().p("AgoA5IgEgCIACgLIAEACIADABQAFAAACgEQADgEAAgHIAIhYIA+AAIAABwIgMAAIAAhlIgnAAIgHBRQgCAKgEAGQgFAFgKAAIgGAAg");
  this.shape_37.setTransform(79.8, 79.025);
  this.shape_38 = new cjs.Shape();
  this.shape_38.graphics.f("#FFFFFF").s().p("AgdAzQgOgIgHgNQgIgNAAgRQAAgQAIgNQAHgNAOgIQANgHAQAAQARAAANAHQAOAIAHANQAIANAAAQQAAARgIANQgHANgOAIQgNAHgRAAQgQAAgNgHgAgXgoQgLAGgGALQgGAKAAANQAAAOAGAKQAGALALAGQAKAGANAAQAOAAAKgGQALgGAGgLQAGgKAAgOQAAgNgGgKQgGgLgLgGQgKgGgOAAQgNAAgKAGg");
  this.shape_38.setTransform(69.125, 78.975);
  this.shape_39 = new cjs.Shape();
  this.shape_39.graphics.f("#FFFFFF").s().p("AAfA5IAAhmIg9AAIAABmIgMAAIAAhxIBVAAIAABxg");
  this.shape_39.setTransform(56.925, 78.975);
  this.shape_40 = new cjs.Shape();
  this.shape_40.graphics.f("#FFFFFF").s().p("AgdAzQgOgIgHgNQgIgNAAgRQAAgQAIgNQAHgNAOgIQANgHAQAAQARAAANAHQAOAIAHANQAIANAAAQQAAARgIANQgHANgOAIQgNAHgRAAQgQAAgNgHgAgXgoQgLAGgGALQgGAKAAANQAAAOAGAKQAGALALAGQAKAGANAAQAOAAAKgGQALgGAGgLQAGgKAAgOQAAgNgGgKQgGgLgLgGQgKgGgOAAQgNAAgKAGg");
  this.shape_40.setTransform(44.775, 78.975);
  this.shape_41 = new cjs.Shape();
  this.shape_41.graphics.f("#FFFFFF").s().p("AAoBGIAAgaIhPAAIAAAaIgLAAIAAgmIAHAAQADABADgEQADgEACgFIADgPIAIhKIA6AAIAABlIAOAAIAAAmgAgSAGQgBALgCAHQgDAGgDACIA0AAIAAhaIgjAAg");
  this.shape_41.setTransform(33, 80.3);
  this.shape_42 = new cjs.Shape();
  this.shape_42.graphics.f("#FFFFFF").s().p("AgUAzQgNgIgIgNQgHgNAAgRQAAgQAIgOQAHgNANgHQAOgHAQAAQALAAAJADQAKADAIAGIgFAMQgGgGgJgEQgJgDgJAAQgNAAgKAGQgLAGgGALQgGAKAAANQAAANAGALQAGALALAGQAKAGANAAQALAAAJgEQAJgDAHgGIADALQgIAHgKADQgKADgMAAQgQAAgNgHg");
  this.shape_42.setTransform(19.475, 78.975);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_42
   }, {
    t: this.shape_41
   }, {
    t: this.shape_40
   }, {
    t: this.shape_39
   }, {
    t: this.shape_38
   }, {
    t: this.shape_37
   }, {
    t: this.shape_36
   }, {
    t: this.shape_35
   }, {
    t: this.shape_34
   }, {
    t: this.shape_33
   }, {
    t: this.shape_32
   }, {
    t: this.shape_31
   }, {
    t: this.shape_30
   }, {
    t: this.shape_29
   }, {
    t: this.shape_28
   }, {
    t: this.shape_27
   }, {
    t: this.shape_26
   }, {
    t: this.shape_25
   }, {
    t: this.shape_24
   }, {
    t: this.shape_23
   }, {
    t: this.shape_22
   }, {
    t: this.shape_21
   }, {
    t: this.shape_20
   }, {
    t: this.shape_19
   }, {
    t: this.shape_18
   }, {
    t: this.shape_17
   }, {
    t: this.shape_16
   }, {
    t: this.shape_15
   }, {
    t: this.shape_14
   }, {
    t: this.shape_13
   }, {
    t: this.shape_12
   }, {
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
 }).prototype = getMCSymbolPrototype(lib.t03, new cjs.Rectangle(11.5, 64, 207.5, 74.4), null);
 (lib.t02 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#FFFFFF").s().p("AgDAoIAhgoIghgnIAPAAIAhAnIghAogAgsAoIAhgoIghgnIAQAAIAgAnIggAog");
  this.shape.setTransform(218.575, 107.6);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#FFFFFF").s().p("AgZA/QgRgJgJgRQgJgQgBgVQABgVAJgQQAKgQAQgJQARgKAUAAQAOAAAMAEQAMAEAJAIIgFAOQgIgIgLgDQgLgEgMgBQgQAAgNAIQgNAHgIAOQgHANAAAQQAAAQAHAOQAIAOANAHQANAIAQgBQAOABALgFQALgFAJgGIAFANQgLAJgNAEQgMAEgOAAQgVAAgQgKg");
  this.shape_1.setTransform(206.625, 105.7);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#FFFFFF").s().p("AgOBAQgQgIgKgPQgKgPgCgTIgbAAIAABAIgPAAIAAiNIAPAAIAABAIAbAAQACgUAKgPQAKgOAQgIQAPgJAUAAQAVAAARAKQAQAJAKAQQAKAQAAAVQAAAVgKAQQgKARgQAJQgRAKgVAAQgUAAgPgJgAgIgyQgOAHgHAOQgIANAAAQQAAARAIANQAHAOAOAHQAMAIARgBQARABANgIQANgHAIgOQAHgNABgRQgBgQgHgNQgIgOgNgHQgNgIgRAAQgRAAgMAIg");
  this.shape_2.setTransform(188.675, 105.7);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#FFFFFF").s().p("AgyBHIgFgCIACgNIAEABIAGABQAFAAADgEQADgFAAgJIALhvIBNAAIAACNIgPAAIAAh/IgwAAIgKBmQgBANgGAHQgGAHgMAAIgIgBg");
  this.shape_3.setTransform(169.775, 105.775);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#FFFFFF").s().p("AAnBHIAAh/IhNAAIAAB/IgPAAIAAiNIBrAAIAACNg");
  this.shape_4.setTransform(156.925, 105.7);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#FFFFFF").s().p("AAdAoIgggoIAggnIARAAIgiAnIAiAogAgMAoIgggoIAggnIAQAAIghAnIAhAog");
  this.shape_5.setTransform(144.65, 107.6);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#FFFFFF").s().p("AAzBHIAAh3IguBDIgKAAIgthDIAAB3IgPAAIAAiNIASAAIAvBIIAxhIIARAAIAACNg");
  this.shape_6.setTransform(126.275, 105.7);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#FFFFFF").s().p("AglA/QgRgJgJgRQgJgPgBgWQABgVAJgQQAJgQARgJQARgKAUAAQAVAAARAKQAQAJALAQQAJAQAAAVQAAAVgJAQQgLARgQAJQgRAKgVAAQgVAAgQgKgAgdgyQgNAHgIAOQgHANAAAQQAAARAHANQAIAOANAHQANAIAQgBQARABAOgIQANgHAHgOQAHgNABgRQgBgQgHgNQgHgOgNgHQgOgIgRAAQgQAAgNAIg");
  this.shape_7.setTransform(109.25, 105.7);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#FFFFFF").s().p("AAiBHIg5hBIgOAAIAABBIgPAAIAAiNIAPAAIAABAIANAAIA1hAIASAAIg7BFIBBBIg");
  this.shape_8.setTransform(95.475, 105.7);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#FFFFFF").s().p("AAvBHIgRguIg7AAIgRAuIgQAAIA4iNIAOAAIA2CNgAAZAMIgZhBIgYBBIAxAAg");
  this.shape_9.setTransform(81.8, 105.7);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.f("#FFFFFF").s().p("AAoBHIAAhAIhPAAIAABAIgPAAIAAiNIAPAAIAABAIBPAAIAAhAIAPAAIAACNg");
  this.shape_10.setTransform(67.825, 105.7);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.f("#FFFFFF").s().p("AgeBDQgMgGgHgHIAIgMIAKAJQAGAEAIACQAIADAJAAQAQAAAJgIQAKgHAAgOQAAgPgMgGQgMgHgYAAIAAgLQARgBAJgEQAKgEADgGQAEgGAAgGQgBgMgHgGQgIgFgNgBQgLAAgKAFQgJAEgHAGIgGgMQAIgGALgGQALgEANAAQANAAAKAEQAJAFAGAIQAGAHgBALQAAANgHAJQgJAIgNADQAQADAJAIQAKAJAAAPQAAANgGAJQgGAKgLAFQgLAFgQAAQgRAAgNgGg");
  this.shape_11.setTransform(54.45, 105.7);
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.f("#FFFFFF").s().p("AglA/QgQgJgKgRQgJgPgBgWQABgVAJgQQAKgQAQgJQARgKAUAAQAVAAARAKQAQAJAKAQQAKAQAAAVQAAAVgKAQQgKARgQAJQgRAKgVAAQgVAAgQgKgAgdgyQgOAHgHAOQgIANAAAQQAAARAIANQAHAOAOAHQANAIAQgBQASABAMgIQAOgHAHgOQAIgNAAgRQAAgQgIgNQgHgOgOgHQgMgIgSAAQgQAAgNAIg");
  this.shape_12.setTransform(35.5, 105.7);
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.f("#FFFFFF").s().p("AgZA/QgRgJgJgRQgJgQgBgVQABgVAJgQQAKgQAQgJQARgKAUAAQAOAAAMAEQAMAEAJAIIgFAOQgIgIgLgDQgLgEgMgBQgQAAgNAIQgNAHgIAOQgHANAAAQQAAAQAHAOQAIAOANAHQANAIAQgBQAOABALgFQALgFAJgGIAFANQgLAJgNAEQgMAEgOAAQgVAAgQgKg");
  this.shape_13.setTransform(19.975, 105.7);
  this.shape_14 = new cjs.Shape();
  this.shape_14.graphics.f("#FFFFFF").s().p("AgGBHIAAh/IgoAAIAAgOIBdAAIAAAOIgnAAIAAB/g");
  this.shape_14.setTransform(109.325, 83.2);
  this.shape_15 = new cjs.Shape();
  this.shape_15.graphics.f("#FFFFFF").s().p("AgrBHIAAiNIAoAAQAOAAALAGQALAFAFAJQAGALAAANQAAAMgGAKQgFAJgLAGQgLAHgOAAIgZAAIAAA1gAgcAFIAXAAQAJAAAHgEQAIgDAFgHQAEgHAAgKQAAgMgEgGQgFgHgIgDQgHgDgJAAIgXAAg");
  this.shape_15.setTransform(99.175, 83.2);
  this.shape_16 = new cjs.Shape();
  this.shape_16.graphics.f("#FFFFFF").s().p("AglA/QgQgJgKgRQgKgPAAgWQAAgVAKgQQAKgQAQgJQARgKAUAAQAWAAAQAKQARAJAKAQQAJAQAAAVQAAAVgJAQQgKARgRAJQgQAKgWAAQgUAAgRgKgAgdgyQgOAHgHAOQgIANAAAQQAAARAIANQAHAOAOAHQANAIAQgBQASABAMgIQANgHAIgOQAHgNABgRQgBgQgHgNQgIgOgNgHQgMgIgSAAQgQAAgNAIg");
  this.shape_16.setTransform(84.35, 83.2);
  this.shape_17 = new cjs.Shape();
  this.shape_17.graphics.f("#FFFFFF").s().p("AgGBJIAAgOQgUgCgQgGQgPgIgIgNQgJgMAAgSQAAgRAJgMQAIgNAPgIQAQgGAUgCIAAgOIANAAIAAAOQAUABAQAIQAOAHAJANQAJAMAAARQAAASgJAMQgJANgOAHQgQAIgUABIAAAOgAAHAuQAQgCAMgFQALgGAIgJQAGgLAAgNQAAgNgGgKQgIgJgLgGQgMgFgQgCgAgigmQgMAGgHAJQgHAKAAANQAAANAHALQAHAJAMAGQAMAGAQABIAAhbQgQABgMAGg");
  this.shape_17.setTransform(67.45, 83.2);
  this.shape_18 = new cjs.Shape();
  this.shape_18.graphics.f("#FFFFFF").s().p("AAzBHIAAh3IguBDIgKAAIgthDIAAB3IgPAAIAAiNIASAAIAvBIIAxhIIARAAIAACNg");
  this.shape_18.setTransform(50.625, 83.2);
  this.shape_19 = new cjs.Shape();
  this.shape_19.graphics.f("#FFFFFF").s().p("AglA/QgQgJgKgRQgJgPgBgWQABgVAJgQQAKgQAQgJQARgKAUAAQAVAAARAKQAQAJAKAQQAKAQAAAVQAAAVgKAQQgKARgQAJQgRAKgVAAQgUAAgRgKgAgdgyQgOAHgHAOQgIANAAAQQAAARAIANQAHAOAOAHQANAIAQgBQASABAMgIQANgHAIgOQAIgNAAgRQAAgQgIgNQgIgOgNgHQgMgIgSAAQgQAAgNAIg");
  this.shape_19.setTransform(33.6, 83.2);
  this.shape_20 = new cjs.Shape();
  this.shape_20.graphics.f("#FFFFFF").s().p("AAiBHIg5hBIgOAAIAABBIgPAAIAAiNIAPAAIAABAIANAAIA1hAIASAAIg7BFIBBBIg");
  this.shape_20.setTransform(19.825, 83.2);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_20
   }, {
    t: this.shape_19
   }, {
    t: this.shape_18
   }, {
    t: this.shape_17
   }, {
    t: this.shape_16
   }, {
    t: this.shape_15
   }, {
    t: this.shape_14
   }, {
    t: this.shape_13
   }, {
    t: this.shape_12
   }, {
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
 }).prototype = getMCSymbolPrototype(lib.t02, new cjs.Rectangle(10.5, 65, 218.5, 55), null);
 (lib.t01 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#FFFFFF").s().p("AgnBHIAAiNIBNAAIAAANIg+AAIAAAzIA8AAIAAAMIg8AAIAAAzIBAAAIAAAOg");
  this.shape.setTransform(60.625, 40.7);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#FFFFFF").s().p("AgmBHIAAiNIAPAAIAAB/IA+AAIAAAOg");
  this.shape_1.setTransform(50.875, 40.7);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#FFFFFF").s().p("AgGBHIAAg5IgzhUIAQAAIAqBGIAphGIAQAAIgzBUIAAA5g");
  this.shape_2.setTransform(39.7, 40.7);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#FFFFFF").s().p("AgGBHIAAiAIgoAAIAAgNIBdAAIAAANIgnAAIAACAg");
  this.shape_3.setTransform(29.275, 40.7);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#FFFFFF").s().p("AgYBFQgLgDgJgHIAEgPQAIAHALAEQAKAEALAAQAOABAIgHQAIgGAAgNQAAgIgEgFQgEgFgHgEIgQgHQgLgDgJgEQgJgFgGgIQgFgHAAgMQAAgMAGgIQAFgJAKgFQALgEANAAQAKAAAJADQAKACAIAEIgEAOQgHgEgJgDQgKgCgIgBQgNABgIAGQgIAGAAALQAAAIAEAFQAEAFAHADIAPAIIAUAHQAKAEAFAHQAGAIAAANQAAANgGAJQgGAJgKAEQgKAFgNAAQgMAAgMgEg");
  this.shape_4.setTransform(18.8, 40.7);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#FFFFFF").s().p("AAOBHIAAggIg/AAIAAgJIBEhkIAKAAIAABgIAVAAIAAANIgVAAIAAAggAggAaIAuAAIAAhFg");
  this.shape_5.setTransform(136.8, 20.2);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#FFFFFF").s().p("AgHBHIg2iNIARAAIAtB7IAth7IAQAAIg2CNg");
  this.shape_6.setTransform(125.5, 20.2);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#FFFFFF").s().p("AAvBHIgSguIg5AAIgSAuIgPAAIA2iNIAPAAIA3CNgAAZAMIgZhBIgYBBIAxAAg");
  this.shape_7.setTransform(113.25, 20.2);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#FFFFFF").s().p("AAgBHIgmg8IgDAAIgZAAIAAA8IgPAAIAAiNIAqAAQATAAAMALQAMALABATQgBAOgHAKQgIAJgNAFIApA+gAgiAAIAZAAQAHAAAGgDQAIgDAFgHQAEgFAAgLQAAgKgEgGQgFgGgHgDQgGgDgIAAIgZAAg");
  this.shape_8.setTransform(101.55, 20.2);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#FFFFFF").s().p("AAvBHIgSguIg6AAIgRAuIgPAAIA3iNIAOAAIA3CNgAAZAMIgZhBIgYBBIAxAAg");
  this.shape_9.setTransform(83.9, 20.2);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.f("#FFFFFF").s().p("AgGBHIAAh/IgoAAIAAgOIBdAAIAAAOIgnAAIAAB/g");
  this.shape_10.setTransform(72.675, 20.2);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.f("#FFFFFF").s().p("AglA/QgQgJgKgRQgJgPgBgWQABgVAJgQQAKgQAQgJQARgKAUAAQAVAAARAKQAQAJAKAQQAKAQAAAVQAAAVgKAQQgKARgQAJQgRAKgVAAQgVAAgQgKgAgdgyQgOAHgHAOQgIANAAAQQAAARAIANQAHAOAOAHQANAIAQgBQASABAMgIQAOgHAHgOQAIgNAAgRQAAgQgIgNQgHgOgOgHQgMgIgSAAQgQAAgNAIg");
  this.shape_11.setTransform(59.35, 20.2);
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.f("#FFFFFF").s().p("AgGBHIAAg5IgzhUIARAAIApBGIAphGIAQAAIgzBUIAAA5g");
  this.shape_12.setTransform(45.45, 20.2);
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.f("#FFFFFF").s().p("AglA/QgQgJgKgRQgKgPAAgWQAAgVAKgQQAKgQAQgJQARgKAUAAQAWAAAQAKQAQAJALAQQAJAQAAAVQAAAVgJAQQgLARgQAJQgQAKgWAAQgVAAgQgKgAgdgyQgNAHgIAOQgHANgBAQQABARAHANQAIAOANAHQANAIAQgBQARABAOgIQAMgHAIgOQAIgNAAgRQAAgQgIgNQgIgOgMgHQgOgIgRAAQgQAAgNAIg");
  this.shape_13.setTransform(31.5, 20.2);
  this.shape_14 = new cjs.Shape();
  this.shape_14.graphics.f("#FFFFFF").s().p("AgGBHIAAh/IgoAAIAAgOIBdAAIAAAOIgnAAIAAB/g");
  this.shape_14.setTransform(18.225, 20.2);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_14
   }, {
    t: this.shape_13
   }, {
    t: this.shape_12
   }, {
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
 }).prototype = getMCSymbolPrototype(lib.t01, new cjs.Rectangle(11, 2, 181.5, 53), null);
 (lib.snoska2 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#FFFFFF").s().p("AgWAZIgCgBIABgGIACAAIACABQABAAABAAQAAgBABAAQAAAAABAAQAAgBABAAQABgCABgFIAEgiIAhAAIAAAxIgHAAIAAgrIgUAAIgEAeQAAAHgDADQgDADgGAAIgEAAg");
  this.shape.setTransform(43.125, 373.175);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#FFFFFF").s().p("AAQAkIAAgnIgfAnIgHAAIAAgxIAHAAIAAAnIAfgnIAHAAIAAAxgAgKgZQgEgEAAgGIAFAAQAAAEADACQADACADAAQAEAAADgCQACgCAAgEIAGAAQAAAGgEAEQgEADgHAAQgGAAgEgDg");
  this.shape_1.setTransform(37.675, 372.025);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#FFFFFF").s().p("AgQAWQgEgEAAgHQAAgFADgEQAEgCAHgCQAHgCANAAIAAgBQAAgGgDgEQgEgEgHAAIgGABIgFADIgEACIgCgGIAIgEQAFgCAFAAQAKAAAFAFQAFAFAAAKIAAAeIgHAAIAAgJQgCAEgFADQgFADgFAAQgJAAgEgEgAgCACQgGAAgDADQgCADAAADQAAAEADADQADACAFAAQADAAAEgBIAHgFQACgEAAgFIAAgFIgQACg");
  this.shape_2.setTransform(31.825, 373.15);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#FFFFFF").s().p("AgDAZIAAgrIgQAAIAAgGIAnAAIAAAGIgRAAIAAArg");
  this.shape_3.setTransform(27.125, 373.15);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#FFFFFF").s().p("AgMAfQgIgEgFgIQgFgJAAgKQAAgKAFgIQAFgIAIgFQAIgEAKAAQAHAAAGABQAGACAFAFIgDAHQgEgEgFgCQgGgCgGAAQgHAAgHADQgGAEgEAHQgEAGAAAIQAAAJAEAGQAEAGAGAFQAHADAHAAQAHABAGgDQAFgCAFgEIACAHQgGAEgGADQgGABgHAAQgKABgIgGg");
  this.shape_4.setTransform(21.625, 372.1);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#FFFFFF").s().p("AAAAFIgGALIgFgEIAIgKIgNgCIADgHIAMAFIgBgNIAGAAIgCANIANgFIACAHIgNACIAJAKIgGAEg");
  this.shape_5.setTransform(13.975, 370.125);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
 }).prototype = getMCSymbolPrototype(lib.snoska2, new cjs.Rectangle(10, 362, 229.8, 18.30000000000001), null);
 (lib.snoska = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#FFFFFF").s().p("AgBAUIAQgUIgQgTIAHAAIARATIgRAUgAgWAUIARgUIgRgTIAIAAIAQATIgQAUg");
  this.shape.setTransform(92.425, 384.3);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#FFFFFF").s().p("AALAZIgVgXIgCAAIAAAXIgHAAIAAgxIAHAAIAAAVIADAAIATgVIAJAAIgXAXIAYAag");
  this.shape_1.setTransform(88.125, 384.4);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#FFFFFF").s().p("AAOAZIAAgWIgbAAIAAAWIgHAAIAAgxIAHAAIAAAVIAbAAIAAgVIAHAAIAAAxg");
  this.shape_2.setTransform(82.475, 384.4);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#FFFFFF").s().p("AgQAWQgEgEAAgHQAAgFADgEQAEgCAHgCQAHgCANAAIAAgBQAAgGgDgEQgEgEgHAAIgGABIgFADIgEACIgCgGIAIgEQAFgCAFAAQAKAAAFAFQAFAFAAAKIAAAeIgHAAIAAgJQgCAEgFADQgFADgFAAQgJAAgEgEgAgCACQgGAAgDADQgCADAAADQAAAEADADQADACAFAAQADAAAEgBIAHgFQACgEAAgFIAAgFIgQACg");
  this.shape_3.setTransform(76.775, 384.4);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#FFFFFF").s().p("AgWAkIAAhHIAlAAIAAAIIgeAAIAAAXIAPAAQAMAAAFAEQAGAGAAAJQAAAGgDAFQgCAEgFADQgFACgIABgAgPAdIAPAAQAHAAAEgEQAEgEABgGQgBgHgEgEQgFgDgGAAIgPAAg");
  this.shape_4.setTransform(71.6, 383.35);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#FFFFFF").s().p("AgQAWQgEgEAAgHQAAgFADgEQAEgCAHgCQAHgCANAAIAAgBQAAgGgDgEQgEgEgHAAIgGABIgFADIgEACIgCgGIAIgEQAFgCAFAAQAKAAAFAFQAFAFAAAKIAAAeIgHAAIAAgJQgCAEgFADQgFADgFAAQgJAAgEgEgAgCACQgGAAgDADQgCADAAADQAAAEADADQADACAFAAQADAAAEgBIAHgFQACgEAAgFIAAgFIgQACg");
  this.shape_5.setTransform(63.375, 384.4);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#FFFFFF").s().p("AgDAZIAAgrIgQAAIAAgGIAnAAIAAAGIgRAAIAAArg");
  this.shape_6.setTransform(58.675, 384.4);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#FFFFFF").s().p("AgNAWQgGgCgDgHQgDgFAAgIQAAgHADgGQADgFAGgEQAGgDAHAAQAIAAAGADQAGAEADAFQADAGAAAHQAAAIgDAFQgDAHgGACQgGAEgIAAQgHAAgGgEgAgJgQQgEACgDAEQgCAFAAAFQAAAGACAEQADAFAEACQAEACAFABQAGgBAEgCQAEgCADgFQACgEAAgGQAAgFgCgFQgDgEgEgCQgEgDgGAAQgFAAgEADg");
  this.shape_7.setTransform(53.625, 384.4);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#FFFFFF").s().p("AAQAkIAAgnIgfAnIgHAAIAAgxIAHAAIAAAnIAfgnIAHAAIAAAxgAgKgZQgEgEAAgGIAFAAQAAAEADACQADACADAAQAEAAADgCQACgCAAgEIAGAAQAAAGgEAEQgEADgHAAQgGAAgEgDg");
  this.shape_8.setTransform(47.675, 383.275);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#FFFFFF").s().p("AgNAWQgGgCgDgHQgDgFAAgIQAAgHADgGQADgFAGgEQAGgDAHAAQAIAAAGADQAGAEADAFQADAGAAAHQAAAIgDAFQgDAHgGACQgGAEgIAAQgHAAgGgEgAgJgQQgEACgDAEQgCAFAAAFQAAAGACAEQADAFAEACQAEACAFABQAGgBAEgCQAEgCADgFQACgEAAgGQAAgFgCgFQgDgEgEgCQgEgDgGAAQgFAAgEADg");
  this.shape_9.setTransform(41.675, 384.4);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.f("#FFFFFF").s().p("AgDAkIAAg/IgUAAIAAgIIAuAAIAAAIIgTAAIAAA/g");
  this.shape_10.setTransform(36.3, 383.35);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.f("#FFFFFF").s().p("AAOAUIgPgUIAPgTIAJAAIgRATIARAUgAgFAUIgRgUIARgTIAHAAIgQATIAQAUg");
  this.shape_11.setTransform(31.475, 384.3);
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.f("#FFFFFF").s().p("AgSAfQgIgEgFgIQgFgJAAgKQAAgJAFgJQAFgIAIgFQAIgEAKAAQAKAAAJAEQAIAFAFAIQAFAJAAAJQAAAKgFAJQgFAIgIAEQgJAGgKgBQgKABgIgGgAgOgZQgGAEgFAHQgDAGAAAIQAAAJADAGQAFAGAGAFQAGADAIAAQAIAAAHgDQAHgFADgGQAEgGAAgJQAAgIgEgGQgDgHgHgEQgHgDgIAAQgIAAgGADg");
  this.shape_12.setTransform(22.65, 383.35);
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.f("#FFFFFF").s().p("AAXAkIgIgYIgdAAIgJAYIgHAAIAbhHIAHAAIAbBHgAAMAGIgMggIgMAgIAYAAg");
  this.shape_13.setTransform(15.325, 383.35);
  this.shape_14 = new cjs.Shape();
  this.shape_14.graphics.f("#FFFFFF").s().p("AANAZIAAgVIgMAAIgNAVIgHAAIAOgWQgFgBgDgCQgDgEAAgFQAAgFACgEQACgDAEgBQAEgCAEAAIAUAAIAAAxgAgGgQQgDACAAAFQAAAEADACQACADAFAAIAMAAIAAgTIgMAAQgFAAgCADg");
  this.shape_14.setTransform(198.025, 373.125);
  this.shape_15 = new cjs.Shape();
  this.shape_15.graphics.f("#FFFFFF").s().p("AgIAWQgGgCgDgHQgDgFAAgIQAAgHADgGQADgFAGgEQAFgDAHAAQAFAAAEACIAIADIgCAGQgDgCgEgBQgDgCgFAAQgFAAgEADQgEACgCAEQgDAFAAAFQAAAGADAEQACAFAEACQAEACAEABIAJgCIAIgEIABAGQgCADgGABQgEACgGAAQgGAAgFgEg");
  this.shape_15.setTransform(193.45, 373.15);
  this.shape_16 = new cjs.Shape();
  this.shape_16.graphics.f("#FFFFFF").s().p("AgDAZIAAgrIgQAAIAAgGIAnAAIAAAGIgRAAIAAArg");
  this.shape_16.setTransform(188.875, 373.15);
  this.shape_17 = new cjs.Shape();
  this.shape_17.graphics.f("#FFFFFF").s().p("AgLAWQgGgDgDgGQgDgGAAgHQAAgGADgHQADgFAGgEQAGgDAFAAQAIAAAFADQAFADADAGQADAGAAAHIAAABIgoAAQAAAIAGAFQAFAGAHAAQAGAAAFgCQAEgDADgDIADAHQgDADgGACQgGACgGAAQgHAAgGgEgAARgEQgBgFgCgDQgCgDgEgCQgDgCgFAAQgCAAgEACQgEABgCAEQgDADgBAFIAhAAIAAAAg");
  this.shape_17.setTransform(184.1, 373.15);
  this.shape_18 = new cjs.Shape();
  this.shape_18.graphics.f("#FFFFFF").s().p("AANAZIAAgVIgMAAIgNAVIgHAAIAOgWQgFgBgDgCQgDgEAAgFQAAgFACgEQACgDAEgBQAEgCAEAAIAUAAIAAAxgAgGgQQgDACAAAFQAAAEADACQACADAFAAIAMAAIAAgTIgMAAQgFAAgCADg");
  this.shape_18.setTransform(178.675, 373.125);
  this.shape_19 = new cjs.Shape();
  this.shape_19.graphics.f("#FFFFFF").s().p("AgWAZIgCgBIABgGIACAAIACABQABAAABAAQAAgBABAAQAAAAABAAQAAgBABAAQABgCABgFIAEgiIAhAAIAAAxIgHAAIAAgrIgUAAIgEAeQAAAHgDADQgDADgGAAIgEAAg");
  this.shape_19.setTransform(173.225, 373.175);
  this.shape_20 = new cjs.Shape();
  this.shape_20.graphics.f("#FFFFFF").s().p("AgTAZIAAgxIASAAQAIAAAEADQAFADAAAGQAAAFgDADQgCACgEABQAGABADACQADADABAGQgBAFgCADQgCADgEABQgEACgFAAgAgMAUIANAAQAFgBADgCQADgCAAgEQAAgFgDgCQgDgDgGABIgMAAgAgMgDIALAAIAGgBIADgDIABgEQAAgEgDgBQgDgCgEgBIgLAAg");
  this.shape_20.setTransform(168.525, 373.15);
  this.shape_21 = new cjs.Shape();
  this.shape_21.graphics.f("#FFFFFF").s().p("AgDAZIAAgrIgQAAIAAgGIAnAAIAAAGIgRAAIAAArg");
  this.shape_21.setTransform(163.675, 373.15);
  this.shape_22 = new cjs.Shape();
  this.shape_22.graphics.f("#FFFFFF").s().p("AgJAWQgFgCgEgHQgCgFAAgIQAAgHACgGQAEgFAFgEQAHgDAGAAQAFAAAFACIAHADIgDAGQgCgCgEgBQgDgCgFAAQgEAAgEADQgFACgCAEQgDAFABAFQgBAGADAEQACAFAEACQAEACAFABIAJgCIAHgEIACAGQgDADgFABQgFACgGAAQgGAAgGgEg");
  this.shape_22.setTransform(159.2, 373.15);
  this.shape_23 = new cjs.Shape();
  this.shape_23.graphics.f("#FFFFFF").s().p("AgLAWQgGgDgDgGQgDgGAAgHQAAgGADgHQAEgFAFgEQAGgDAFAAQAIAAAFADQAGADACAGQADAGAAAHIAAABIgoAAQABAIAFAFQAFAGAHAAQAGAAAFgCQAEgDADgDIADAHQgEADgFACQgGACgGAAQgHAAgGgEgAARgEQAAgFgDgDQgCgDgEgCQgDgCgFAAQgDAAgDACQgEABgCAEQgDADgBAFIAhAAIAAAAg");
  this.shape_23.setTransform(154.05, 373.15);
  this.shape_24 = new cjs.Shape();
  this.shape_24.graphics.f("#FFFFFF").s().p("AAgAgIAAgOIhGAAIAAgxIAHAAIAAArIAYAAIAAgrIAHAAIAAArIAYAAIAAgrIAHAAIAAArIAIAAIAAAUg");
  this.shape_24.setTransform(147.375, 373.875);
  this.shape_25 = new cjs.Shape();
  this.shape_25.graphics.f("#FFFFFF").s().p("AgTAkIgDgBIABgGIACAAIABAAQAFAAADgCQADgCACgGIAEgHIgWgvIAHAAIARAmIAQgmIAHAAIgYA4QgCAIgEADQgEAEgHAAIgCAAg");
  this.shape_25.setTransform(140.45, 374.225);
  this.shape_26 = new cjs.Shape();
  this.shape_26.graphics.f("#FFFFFF").s().p("AgJAWQgFgCgEgHQgDgFAAgIQAAgHADgGQAEgFAFgEQAHgDAGAAQAFAAAFACIAHADIgDAGQgCgCgEgBQgDgCgFAAQgEAAgEADQgFACgCAEQgDAFABAFQgBAGADAEQACAFAEACQAEACAFABIAJgCIAHgEIACAGQgDADgFABQgFACgGAAQgGAAgGgEg");
  this.shape_26.setTransform(135.8, 373.15);
  this.shape_27 = new cjs.Shape();
  this.shape_27.graphics.f("#FFFFFF").s().p("AgNAWQgGgCgDgHQgDgFAAgIQAAgHADgGQADgFAGgEQAGgDAHAAQAIAAAGADQAGAEADAFQADAGAAAHQAAAIgDAFQgDAHgGACQgGAEgIAAQgHAAgGgEgAgJgQQgEACgDAEQgCAFAAAFQAAAGACAEQADAFAEACQAEACAFABQAGgBAEgCQAEgCADgFQACgEAAgGQAAgFgCgFQgDgEgEgCQgEgDgGAAQgFAAgEADg");
  this.shape_27.setTransform(130.375, 373.15);
  this.shape_28 = new cjs.Shape();
  this.shape_28.graphics.f("#FFFFFF").s().p("AgLAWQgGgDgDgGQgDgGAAgHQAAgGADgHQADgFAGgEQAFgDAHAAQAGAAAGADQAFADADAGQADAGAAAHIAAABIgoAAQAAAIAFAFQAGAGAIAAQAFAAAFgCQAFgDADgDIABAHQgDADgFACQgGACgGAAQgHAAgGgEgAARgEQAAgFgDgDQgCgDgDgCQgEgCgEAAQgDAAgEACQgEABgDAEQgCADAAAFIAgAAIAAAAg");
  this.shape_28.setTransform(122.5, 373.15);
  this.shape_29 = new cjs.Shape();
  this.shape_29.graphics.f("#FFFFFF").s().p("AAQAZIAAgnIgfAnIgHAAIAAgxIAHAAIAAAnIAfgnIAHAAIAAAxg");
  this.shape_29.setTransform(116.775, 373.15);
  this.shape_30 = new cjs.Shape();
  this.shape_30.graphics.f("#FFFFFF").s().p("AAOAZIAAgWIgbAAIAAAWIgHAAIAAgxIAHAAIAAAVIAbAAIAAgVIAHAAIAAAxg");
  this.shape_30.setTransform(110.825, 373.15);
  this.shape_31 = new cjs.Shape();
  this.shape_31.graphics.f("#FFFFFF").s().p("AgQAWQgEgEAAgHQAAgFADgEQAEgCAHgCQAHgCANAAIAAgBQAAgGgDgEQgEgEgHAAIgGABIgFADIgEACIgCgGIAIgEQAFgCAFAAQAKAAAFAFQAFAFAAAKIAAAeIgHAAIAAgJQgCAEgFADQgFADgFAAQgJAAgEgEgAgCACQgGAAgDADQgCADAAADQAAAEADADQADACAFAAQADAAAEgBIAHgFQACgEAAgFIAAgFIgQACg");
  this.shape_31.setTransform(105.125, 373.15);
  this.shape_32 = new cjs.Shape();
  this.shape_32.graphics.f("#FFFFFF").s().p("AgTAZIAAgxIASAAQAIAAAEADQAFADAAAGQAAAFgDADQgCACgEABQAGABADACQADADABAGQgBAFgCADQgCADgEABQgEACgFAAgAgMAUIANAAQAFgBADgCQADgCAAgEQAAgFgDgCQgDgDgGABIgMAAgAgMgDIALAAIAGgBIADgDIABgEQAAgEgDgBQgDgCgEgBIgLAAg");
  this.shape_32.setTransform(100.275, 373.15);
  this.shape_33 = new cjs.Shape();
  this.shape_33.graphics.f("#FFFFFF").s().p("AgNAWQgGgCgDgHQgDgFAAgIQAAgHADgGQADgFAGgEQAGgDAHAAQAIAAAGADQAGAEADAFQADAGAAAHQAAAIgDAFQgDAHgGACQgGAEgIAAQgHAAgGgEgAgJgQQgEACgDAEQgCAFAAAFQAAAGACAEQADAFAEACQAEACAFABQAGgBAEgCQAEgCADgFQACgEAAgGQAAgFgCgFQgDgEgEgCQgEgDgGAAQgFAAgEADg");
  this.shape_33.setTransform(94.575, 373.15);
  this.shape_34 = new cjs.Shape();
  this.shape_34.graphics.f("#FFFFFF").s().p("AgDAZIAAgrIgQAAIAAgGIAnAAIAAAGIgRAAIAAArg");
  this.shape_34.setTransform(89.525, 373.15);
  this.shape_35 = new cjs.Shape();
  this.shape_35.graphics.f("#FFFFFF").s().p("AAQAZIAAgnIgfAnIgHAAIAAgxIAHAAIAAAnIAfgnIAHAAIAAAxg");
  this.shape_35.setTransform(84.425, 373.15);
  this.shape_36 = new cjs.Shape();
  this.shape_36.graphics.f("#FFFFFF").s().p("AAVAgIAAgOIgpAAIAAAOIgGAAIAAgUIACAAQAEAAACgDQACgEABgGIAEgeIAfAAIAAArIAIAAIAAAUgAgIAAIgBAHQgCADgCACIAZAAIAAglIgRAAg");
  this.shape_36.setTransform(78.5, 373.875);
  this.shape_37 = new cjs.Shape();
  this.shape_37.graphics.f("#FFFFFF").s().p("AgLAWQgGgDgDgGQgDgGAAgHQAAgGADgHQAEgFAFgEQAGgDAFAAQAIAAAFADQAGADACAGQADAGAAAHIAAABIgoAAQABAIAFAFQAFAGAHAAQAGAAAFgCQAEgDADgDIADAHQgEADgFACQgGACgGAAQgHAAgGgEgAARgEQgBgFgCgDQgCgDgEgCQgDgCgFAAQgDAAgDACQgEABgCAEQgDADgBAFIAhAAIAAAAg");
  this.shape_37.setTransform(73.05, 373.15);
  this.shape_38 = new cjs.Shape();
  this.shape_38.graphics.f("#FFFFFF").s().p("AgYAkIAAhGIAHAAIAAAKQADgGAFgDQAFgCAFAAQAHAAAGADQAFAEADAFQADAGAAAIQAAAIgDAEQgDAGgGADQgFAEgHAAIgHgBIgGgEIgFgGIAAAfgAgJgaQgEACgCAEQgDAFAAAGQAAAGACADQADAFAEACQAEACAFABQAFgBAEgCQAEgCADgFQACgDAAgGQAAgFgCgFQgCgFgEgCQgEgDgGAAQgEAAgFADg");
  this.shape_38.setTransform(67.475, 374.15);
  this.shape_39 = new cjs.Shape();
  this.shape_39.graphics.f("#FFFFFF").s().p("AARAkIgcghIgHAAIAAAhIgHAAIAAhHIAHAAIAAAhIAGAAIAaghIAJAAIgcAjIAfAkg");
  this.shape_39.setTransform(61.675, 372.1);
  this.shape_40 = new cjs.Shape();
  this.shape_40.graphics.f("#FFFFFF").s().p("AAAAFIgGALIgFgEIAIgKIgNgCIADgHIAMAFIgBgNIAGAAIgCANIANgFIACAHIgNACIAJAKIgGAEg");
  this.shape_40.setTransform(54.075, 370.125);
  this.shape_41 = new cjs.Shape();
  this.shape_41.graphics.f("#FFFFFF").s().p("AAAAFIgGALIgFgEIAIgKIgNgCIADgHIAMAFIgBgNIAGAAIgCANIANgFIACAHIgNACIAJAKIgGAEg");
  this.shape_41.setTransform(50.425, 370.125);
  this.shape_42 = new cjs.Shape();
  this.shape_42.graphics.f("#FFFFFF").s().p("AgWAZIgCgBIABgGIACAAIACABQABAAABAAQAAgBABAAQAAAAABAAQAAgBABAAQABgCABgFIAEgiIAhAAIAAAxIgHAAIAAgrIgUAAIgEAeQAAAHgDADQgDADgGAAIgEAAg");
  this.shape_42.setTransform(43.125, 373.175);
  this.shape_43 = new cjs.Shape();
  this.shape_43.graphics.f("#FFFFFF").s().p("AAQAkIAAgnIgfAnIgHAAIAAgxIAHAAIAAAnIAfgnIAHAAIAAAxgAgKgZQgEgEAAgGIAFAAQAAAEADACQADACADAAQAEAAADgCQACgCAAgEIAGAAQAAAGgEAEQgEADgHAAQgGAAgEgDg");
  this.shape_43.setTransform(37.675, 372.025);
  this.shape_44 = new cjs.Shape();
  this.shape_44.graphics.f("#FFFFFF").s().p("AgQAWQgEgEAAgHQAAgFADgEQAEgCAHgCQAHgCANAAIAAgBQAAgGgDgEQgEgEgHAAIgGABIgFADIgEACIgCgGIAIgEQAFgCAFAAQAKAAAFAFQAFAFAAAKIAAAeIgHAAIAAgJQgCAEgFADQgFADgFAAQgJAAgEgEgAgCACQgGAAgDADQgCADAAADQAAAEADADQADACAFAAQADAAAEgBIAHgFQACgEAAgFIAAgFIgQACg");
  this.shape_44.setTransform(31.825, 373.15);
  this.shape_45 = new cjs.Shape();
  this.shape_45.graphics.f("#FFFFFF").s().p("AgDAZIAAgrIgQAAIAAgGIAnAAIAAAGIgRAAIAAArg");
  this.shape_45.setTransform(27.125, 373.15);
  this.shape_46 = new cjs.Shape();
  this.shape_46.graphics.f("#FFFFFF").s().p("AgMAfQgIgEgFgIQgFgJAAgKQAAgKAFgIQAFgIAIgFQAIgEAKAAQAHAAAGABQAGACAFAFIgDAHQgEgEgFgCQgGgCgGAAQgHAAgHADQgGAEgEAHQgEAGAAAIQAAAJAEAGQAEAGAGAFQAHADAHAAQAHABAGgDQAFgCAFgEIACAHQgGAEgGADQgGABgHAAQgKABgIgGg");
  this.shape_46.setTransform(21.625, 372.1);
  this.shape_47 = new cjs.Shape();
  this.shape_47.graphics.f("#FFFFFF").s().p("AAAAFIgGALIgFgEIAIgKIgNgCIADgHIAMAFIgBgNIAGAAIgCANIANgFIACAHIgNACIAJAKIgGAEg");
  this.shape_47.setTransform(13.975, 370.125);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_47
   }, {
    t: this.shape_46
   }, {
    t: this.shape_45
   }, {
    t: this.shape_44
   }, {
    t: this.shape_43
   }, {
    t: this.shape_42
   }, {
    t: this.shape_41
   }, {
    t: this.shape_40
   }, {
    t: this.shape_39
   }, {
    t: this.shape_38
   }, {
    t: this.shape_37
   }, {
    t: this.shape_36
   }, {
    t: this.shape_35
   }, {
    t: this.shape_34
   }, {
    t: this.shape_33
   }, {
    t: this.shape_32
   }, {
    t: this.shape_31
   }, {
    t: this.shape_30
   }, {
    t: this.shape_29
   }, {
    t: this.shape_28
   }, {
    t: this.shape_27
   }, {
    t: this.shape_26
   }, {
    t: this.shape_25
   }, {
    t: this.shape_24
   }, {
    t: this.shape_23
   }, {
    t: this.shape_22
   }, {
    t: this.shape_21
   }, {
    t: this.shape_20
   }, {
    t: this.shape_19
   }, {
    t: this.shape_18
   }, {
    t: this.shape_17
   }, {
    t: this.shape_16
   }, {
    t: this.shape_15
   }, {
    t: this.shape_14
   }, {
    t: this.shape_13
   }, {
    t: this.shape_12
   }, {
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
 }).prototype = getMCSymbolPrototype(lib.snoska, new cjs.Rectangle(10, 362, 229.8, 29.5), null);
 (lib.red_line = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#FF0022").s().p("AyvAPIAAgdMAlfAAAIAAAdg");
  this.shape.setTransform(120, 1.5);
  this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
 }).prototype = getMCSymbolPrototype(lib.red_line, new cjs.Rectangle(0, 0, 240, 3), null);
 (lib.logo_s = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#FFFFFF").s().p("AiNBbQg6gmAAg1QAAg1A6glQA7gmBSAAQBTAAA6AmQA7AlAAA1QAAA1g7AmQg6AmhTAAQhSAAg7gmgACUg9QAAAbgrASQgZALgfAFIAAAEQAAAwgOAiQgJAUgLAIQA8gEAtgeQAZgQANgXQANgWABgXQgBgYgMgUQgEgJgHgHIAAADgAifgwQgLAUAAAYQAAAXAMAWQAOAXAYAQQAaARAdAJQAYAGAaACQgLgIgIgUQgPgiAAgwIAAgEQgegFgZgLQgsgSAAgbIAAgCIgLAPgAgVAzQAJAWAMAAQAMAAAJgWQAJgVAAgdQgOABgQAAQgPAAgPgBQABAdAIAVgAgVg5QgEAMgCAPIAbABIAdgBQgDgPgFgMQgJgXgMAAQgMAAgJAXgAAjhMQAIAUAEAYQATgEAQgFQAhgMAAgRQAAgRghgMQgNgFgPgDIgNgCIgmgCIgDAAIgDAAIgtADIgJACIgXAHQgiAMAAARQAAARAiAMQAQAGASADQAEgYAIgUQAPghATAAQAVAAAOAhg");
  this.shape.setTransform(20, 12.925);
  this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
 }).prototype = getMCSymbolPrototype(lib.logo_s, new cjs.Rectangle(0, 0, 40, 25.9), null);
 (lib.legal_01_d1 = function() {
  this.initialize(img.legal_01_d1);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 215, 915);
 (lib.legal_01 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_d1 = new lib.legal_01_d1();
  this.cvr_d1.name = "cvr_d1";
  this.cvr_d1.parent = this;
  this.cvr_d1.setTransform(13, 50, 0.5, 0.5);
  this.initialize(mode, startPosition, loop, {
   cvr_frame01: 65,
   cvr_frame02: 195,
   cvr_frame03: 325
  });
  this.frame_start = function() {
   globalStop(false);
   this.gotoAndPlay(1);
  }
  this.frame_finish = function() {
   globalStop(true)
   this.stop()
  }
  this.timeline.addTween(cjs.Tween.get(this).call(this.frame_start).wait(390).call(this.frame_finish).wait(1));
  this.timeline.addTween(cjs.Tween.get(this.cvr_d1).to({
   alpha: 0
  }, 0).to({
   alpha: 1
  }, 5).wait(120).to({
   alpha: 0
  }, 5).to({
   y: -280
  }, 0).to({
   alpha: 1
  }, 5).wait(120).to({
   alpha: 0
  }, 5).to({
   y: -610
  }, 0).to({
   alpha: 1
  }, 5).wait(120).to({
   alpha: 0
  }, 5).to({
   y: -940
  }, 0).wait(1));
  var mask_cvr_d1 = new cjs.Shape();
  mask_cvr_d1._off = true;
  mask_cvr_d1.graphics.p("AnzH0IAAvnIPnAAIAAPng");
  mask_cvr_d1.setTransform(122.25, 215, 2.185, 3.3);
  this.cvr_d1.mask = mask_cvr_d1
  this.timeline.addTween(cjs.Tween.get(this.cvr_d1).wait(1));
 }).prototype = getMCSymbolPrototype(lib.legal_01, new cjs.Rectangle(11, 48, 218.5, 339.7), null);
 (lib.car_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.car();
  this.instance.parent = this;
  this.instance.setTransform(52, 2, 0.667, 0.667);
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));
 }).prototype = getMCSymbolPrototype(lib.car_1, new cjs.Rectangle(52, 2, 200.8, 122.7), null);
 (lib.black_plate = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#282830").s().p("AyvfQMAAAg+fMAlfAAAMAAAA+fg");
  this.shape.setTransform(120, 200);
  this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
 }).prototype = getMCSymbolPrototype(lib.black_plate, new cjs.Rectangle(0, 0, 240, 400), null);
 (lib.bg4_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.bg4();
  this.instance.parent = this;
  this.instance.setTransform(40, 0, 0.667, 0.667);
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));
 }).prototype = getMCSymbolPrototype(lib.bg4_1, new cjs.Rectangle(40, 0, 200.8, 209.5), null);
 (lib.bg3_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.bg3();
  this.instance.parent = this;
  this.instance.setTransform(40, 0, 0.667, 0.667);
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));
 }).prototype = getMCSymbolPrototype(lib.bg3_1, new cjs.Rectangle(40, 0, 200.1, 209.5), null);
 (lib.bg2_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.bg2();
  this.instance.parent = this;
  this.instance.setTransform(40, 0, 0.667, 0.667);
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));
 }).prototype = getMCSymbolPrototype(lib.bg2_1, new cjs.Rectangle(40, 0, 200.1, 208.1), null);
 (lib.bg1_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.bg1();
  this.instance.parent = this;
  this.instance.setTransform(40, 0, 0.6667, 0.6667);
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));
 }).prototype = getMCSymbolPrototype(lib.bg1_1, new cjs.Rectangle(40, 0, 200.7, 208), null);
 (lib.bg_01 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#282830").s().p("AyvfQMAAAg+fMAlfAAAMAAAA+fg");
  this.shape.setTransform(120, 200);
  this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
 }).prototype = getMCSymbolPrototype(lib.bg_01, new cjs.Rectangle(0, 0, 240, 400), null);
 (lib.arrows2 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  var mask = new cjs.Shape();
  mask._off = true;
  var mask_graphics_0 = new cjs.Graphics().p("ApSDSIAAgXISlAAIAAAXg");
  var mask_graphics_1 = new cjs.Graphics().p("ApSDSIAAgzISlAAIAAAzg");
  var mask_graphics_2 = new cjs.Graphics().p("ApSDSIAAhQISlAAIAABQg");
  var mask_graphics_3 = new cjs.Graphics().p("ApSDSIAAhsISlAAIAABsg");
  var mask_graphics_4 = new cjs.Graphics().p("ApSDRIAAiIISlAAIAACIg");
  var mask_graphics_5 = new cjs.Graphics().p("ApSDRIAAikISlAAIAACkg");
  var mask_graphics_6 = new cjs.Graphics().p("ApSDRIAAjBISlAAIAADBg");
  var mask_graphics_7 = new cjs.Graphics().p("ApSDRIAAjcISlAAIAADcg");
  var mask_graphics_8 = new cjs.Graphics().p("ApSDRIAAj5ISlAAIAAD5g");
  var mask_graphics_9 = new cjs.Graphics().p("ApSDRIAAkVISlAAIAAEVg");
  var mask_graphics_10 = new cjs.Graphics().p("ApSDRIAAkyISlAAIAAEyg");
  var mask_graphics_11 = new cjs.Graphics().p("ApSDRIAAlOISlAAIAAFOg");
  var mask_graphics_12 = new cjs.Graphics().p("ApSDRIAAlrISlAAIAAFrg");
  var mask_graphics_13 = new cjs.Graphics().p("ApSDRIAAmHISlAAIAAGHg");
  var mask_graphics_14 = new cjs.Graphics().p("ApSDSIAAmjISlAAIAAGjg");
  this.timeline.addTween(cjs.Tween.get(mask).to({
   graphics: mask_graphics_0,
   x: 59.5001,
   y: 20.9837
  }).wait(1).to({
   graphics: mask_graphics_1,
   x: 59.5001,
   y: 20.9744
  }).wait(1).to({
   graphics: mask_graphics_2,
   x: 59.5001,
   y: 20.965
  }).wait(1).to({
   graphics: mask_graphics_3,
   x: 59.5001,
   y: 20.9557
  }).wait(1).to({
   graphics: mask_graphics_4,
   x: 59.5001,
   y: 20.9464
  }).wait(1).to({
   graphics: mask_graphics_5,
   x: 59.5001,
   y: 20.937
  }).wait(1).to({
   graphics: mask_graphics_6,
   x: 59.5001,
   y: 20.9277
  }).wait(1).to({
   graphics: mask_graphics_7,
   x: 59.5001,
   y: 20.9183
  }).wait(1).to({
   graphics: mask_graphics_8,
   x: 59.5001,
   y: 20.909
  }).wait(1).to({
   graphics: mask_graphics_9,
   x: 59.5001,
   y: 20.8996
  }).wait(1).to({
   graphics: mask_graphics_10,
   x: 59.5001,
   y: 20.8903
  }).wait(1).to({
   graphics: mask_graphics_11,
   x: 59.5001,
   y: 20.8809
  }).wait(1).to({
   graphics: mask_graphics_12,
   x: 59.5001,
   y: 20.8716
  }).wait(1).to({
   graphics: mask_graphics_13,
   x: 59.5001,
   y: 20.8623
  }).wait(1).to({
   graphics: mask_graphics_14,
   x: 59.5001,
   y: 20.9999
  }).wait(1));
  this.shape = new cjs.Shape();
  this.shape.graphics.lf(["rgba(255,0,34,0.008)", "#FF0022"], [0, 0.741], -3.9, 21.3, -3.9, -17.5).s().p("AksCdQEGgwBeghQB6gqBjg3QAxgbAZgUIhmADIEniFIgNB9IhSADQgjAeg6AkQhzBIhwAfQh8AijTAeQi0AZidALg");
  this.shape.setTransform(54.375, 19.875);
  var maskedShapeInstanceList = [this.shape];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask;
  }
  this.timeline.addTween(cjs.Tween.get(this.shape).wait(15));
  var mask_1 = new cjs.Shape();
  mask_1._off = true;
  var mask_1_graphics_0 = new cjs.Graphics().p("AnvCcIOYnHIBHCQIuYHHg");
  var mask_1_graphics_1 = new cjs.Graphics().p("An5CJIOZnHIBaC2IuZHHg");
  var mask_1_graphics_2 = new cjs.Graphics().p("AoCB1IOYnHIBtDeIuYHHg");
  var mask_1_graphics_3 = new cjs.Graphics().p("AoMBiIOYnHICBEEIuYHHg");
  var mask_1_graphics_4 = new cjs.Graphics().p("AoWBOIOZnHICUEsIuZHHg");
  var mask_1_graphics_5 = new cjs.Graphics().p("AofA7IOYnHICnFSIuYHHg");
  var mask_1_graphics_6 = new cjs.Graphics().p("AopAnIOYnHIC7F6IuYHHg");
  var mask_1_graphics_7 = new cjs.Graphics().p("AozAUIOZnHIDOGgIuZHHg");
  var mask_1_graphics_8 = new cjs.Graphics().p("Ao8AAIOYnHIDhHHIuYHIg");
  var mask_1_graphics_9 = new cjs.Graphics().p("ApGgSIOYnIID1HtIuYHIg");
  var mask_1_graphics_10 = new cjs.Graphics().p("ApQgmIOZnIIEIIVIuZHIg");
  var mask_1_graphics_11 = new cjs.Graphics().p("ApZg5IOYnIIEbI7IuYHIg");
  var mask_1_graphics_12 = new cjs.Graphics().p("ApjhNIOYnIIEvJjIuYHIg");
  var mask_1_graphics_13 = new cjs.Graphics().p("ApthhIOZnHIFCKJIuZHIg");
  var mask_1_graphics_14 = new cjs.Graphics().p("Ap2h0IOYnIIFVKxIuYHIg");
  this.timeline.addTween(cjs.Tween.get(mask_1).to({
   graphics: mask_1_graphics_0,
   x: 49.5348,
   y: 27.9526
  }).wait(1).to({
   graphics: mask_1_graphics_1,
   x: 50.4961,
   y: 29.9052
  }).wait(1).to({
   graphics: mask_1_graphics_2,
   x: 51.4574,
   y: 31.8578
  }).wait(1).to({
   graphics: mask_1_graphics_3,
   x: 52.4187,
   y: 33.8105
  }).wait(1).to({
   graphics: mask_1_graphics_4,
   x: 53.38,
   y: 35.7631
  }).wait(1).to({
   graphics: mask_1_graphics_5,
   x: 54.3413,
   y: 37.7157
  }).wait(1).to({
   graphics: mask_1_graphics_6,
   x: 55.3026,
   y: 39.6683
  }).wait(1).to({
   graphics: mask_1_graphics_7,
   x: 56.2639,
   y: 41.6209
  }).wait(1).to({
   graphics: mask_1_graphics_8,
   x: 57.2252,
   y: 43.5735
  }).wait(1).to({
   graphics: mask_1_graphics_9,
   x: 58.1865,
   y: 45.5261
  }).wait(1).to({
   graphics: mask_1_graphics_10,
   x: 59.1478,
   y: 47.4787
  }).wait(1).to({
   graphics: mask_1_graphics_11,
   x: 60.1091,
   y: 49.4313
  }).wait(1).to({
   graphics: mask_1_graphics_12,
   x: 61.0704,
   y: 51.384
  }).wait(1).to({
   graphics: mask_1_graphics_13,
   x: 62.0317,
   y: 53.3366
  }).wait(1).to({
   graphics: mask_1_graphics_14,
   x: 63.0511,
   y: 55.1746
  }).wait(1));
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.lf(["rgba(255,0,34,0)", "#FF0022"], [0, 0.678], -7.5, -18.4, 7.1, 22.3).s().p("AEmAcQh2gPkygYQi3gOicgDIh3AAQBMgNDhgLQDvgMBPAIQCDAOBxAXQA4AMAeAIIA8gRICoBIIl3AFg");
  this.shape_1.setTransform(60.375, 51.4488);
  var maskedShapeInstanceList = [this.shape_1];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
  }
  this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(15));
  var mask_2 = new cjs.Shape();
  mask_2._off = true;
  var mask_2_graphics_0 = new cjs.Graphics().p("ApgEBIS4igIAJBGIy4Cfg");
  var mask_2_graphics_1 = new cjs.Graphics().p("AplDfIS5ifIASCJIy5Cfg");
  var mask_2_graphics_2 = new cjs.Graphics().p("AppDAIS5ifIAaDHIy5Cfg");
  var mask_2_graphics_3 = new cjs.Graphics().p("AptCkIS5ifIAiEAIy5Cfg");
  var mask_2_graphics_4 = new cjs.Graphics().p("ApwCKIS5ifIAoE0Iy5Cfg");
  var mask_2_graphics_5 = new cjs.Graphics().p("ApzByIS4ieIAvFjIy4Cfg");
  var mask_2_graphics_6 = new cjs.Graphics().p("Ap2BdIS5ieIA0GNIy5Cfg");
  var mask_2_graphics_7 = new cjs.Graphics().p("Ap4BKIS4ieIA5GzIy4Cfg");
  var mask_2_graphics_8 = new cjs.Graphics().p("Ap7A6IS5ieIA+HTIy5Cfg");
  var mask_2_graphics_9 = new cjs.Graphics().p("Ap8AtIS4ieIBBHuIy4Cfg");
  var mask_2_graphics_10 = new cjs.Graphics().p("Ap+AhIS5ieIBEIFIy5Cfg");
  var mask_2_graphics_11 = new cjs.Graphics().p("Ap/AZIS5ieIBGIWIy5Cfg");
  var mask_2_graphics_12 = new cjs.Graphics().p("AqAATIS5ifIBIIjIy5Cfg");
  var mask_2_graphics_13 = new cjs.Graphics().p("AqAAPIS4ieIBJIqIy4Cfg");
  var mask_2_graphics_14 = new cjs.Graphics().p("AqAANIS4ifIBJItIy4Cfg");
  this.timeline.addTween(cjs.Tween.get(mask_2).to({
   graphics: mask_2_graphics_0,
   x: 58.2841,
   y: 32.5868
  }).wait(1).to({
   graphics: mask_2_graphics_1,
   x: 58.7305,
   y: 35.9647
  }).wait(1).to({
   graphics: mask_2_graphics_2,
   x: 59.1438,
   y: 39.0923
  }).wait(1).to({
   graphics: mask_2_graphics_3,
   x: 59.5241,
   y: 41.9696
  }).wait(1).to({
   graphics: mask_2_graphics_4,
   x: 59.8713,
   y: 44.5968
  }).wait(1).to({
   graphics: mask_2_graphics_5,
   x: 60.1854,
   y: 46.9737
  }).wait(1).to({
   graphics: mask_2_graphics_6,
   x: 60.4665,
   y: 49.1004
  }).wait(1).to({
   graphics: mask_2_graphics_7,
   x: 60.7145,
   y: 50.977
  }).wait(1).to({
   graphics: mask_2_graphics_8,
   x: 60.9294,
   y: 52.6033
  }).wait(1).to({
   graphics: mask_2_graphics_9,
   x: 61.1113,
   y: 53.9794
  }).wait(1).to({
   graphics: mask_2_graphics_10,
   x: 61.2601,
   y: 55.1054
  }).wait(1).to({
   graphics: mask_2_graphics_11,
   x: 61.3758,
   y: 55.9811
  }).wait(1).to({
   graphics: mask_2_graphics_12,
   x: 61.4585,
   y: 56.6066
  }).wait(1).to({
   graphics: mask_2_graphics_13,
   x: 61.5081,
   y: 56.9819
  }).wait(1).to({
   graphics: mask_2_graphics_14,
   x: 61.4953,
   y: 56.9952
  }).wait(1));
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.lf(["rgba(255,0,34,0)", "#FF0022"], [0, 0.533], -4.8, -26.1, 3.4, 24.2).s().p("ACqB5IBQgPQgFgXgigiQhDhDiQg3Qijg+hYgVQhJgShkgGIFXgtIBcAoQBoAyA6AyQA5AyA+BFQAfAjAUAZIBSgDIgvCHg");
  this.shape_2.setTransform(54.5, 78.875);
  var maskedShapeInstanceList = [this.shape_2];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
  }
  this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(15));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(0, 0, 119.3, 101.5);
 (lib.arrow3 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.lf(["rgba(255,0,39,0)", "#FF0027"], [0, 0.486], -14.6, 38.5, 14.6, -38.4).s().p("AilEpQBYhHAmg5QAvhIANg9IAMheQAHgwATgsQATgrAbggIA8hGIgogPIBzgtIAIBcIgrgRIgaAZQgeAggYAhQgaAlgNAjQgKAfgGAxQgIBIgLAjQgVBFgvAzQgyA2hJAzQhBAtgpARQAkgYAtgjg");
  this.shape.setTransform(24.75, 35.625);
  this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
 }).prototype = getMCSymbolPrototype(lib.arrow3, new cjs.Rectangle(0, 0, 49.5, 71.3), null);
 (lib.arrow1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.lf(["rgba(255,0,34,0)", "#FF0022"], [0, 1], 0, 130.3, 0, -124).s().p("ABJTWQEjmfgWlzQgVlekqk8Qi8jJhJkhQgtiwAFioIiHAAIDAi/IDAC/IiIAAQgECVAoCgQBCELCpC1QCXChBQDDQBODCgBDOQgCDQhTDEQhYDLioCog");
  this.shape.setTransform(41.3756, 124.025);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.lf(["rgba(255,0,34,0)", "#FF0022"], [0, 1], 0, 130.3, 0, -124).s().p("ABJTWQEjmfgWlzQgVlekqk8Qi8jJhJkhQgtiwAFioIiHAAIDAi/IDAC/IiIAAQgECVAoCgQBCELCpC1QCXChBQDDQBODCgBDOQgCDQhTDEQhYDLioCog");
  this.shape_1.setTransform(121.3756, 124.025);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.lf(["rgba(255,0,34,0)", "#FF0022"], [0, 1], 0, 130.3, 0, -124).s().p("ABJTWQEjmfgWlzQgVlekqk8Qi8jJhJkhQgtiwAFioIiHAAIDAi/IDAC/IiIAAQgECVAoCgQBCELCpC1QCXChBQDDQBODCgBDOQgCDQhTDEQhYDLioCog");
  this.shape_2.setTransform(206.3756, 124.025);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
 }).prototype = getMCSymbolPrototype(lib.arrow1, new cjs.Rectangle(0, 0, 247.8, 248.1), null);
 (lib.txt06 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  var mask = new cjs.Shape();
  mask._off = true;
  mask.graphics.p("AyvGVIAAjpMAlfAAAIAADpg");
  mask.setTransform(120.0035, 40.4873);
  this.instance = new lib.t06();
  this.instance.parent = this;
  this.instance.setTransform(70.7, 22.3, 1, 1, 0, 0, 0, 90.7, 22.3);
  this.instance.alpha = 0;
  var maskedShapeInstanceList = [this.instance];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({
   regX: 122.7,
   regY: 101.8,
   x: 105.5,
   y: 101.8,
   alpha: 0.1378
  }, 0).wait(1).to({
   x: 108.05,
   alpha: 0.2653
  }, 0).wait(1).to({
   x: 110.4,
   alpha: 0.3827
  }, 0).wait(1).to({
   x: 112.5,
   alpha: 0.4898
  }, 0).wait(1).to({
   x: 114.45,
   alpha: 0.5867
  }, 0).wait(1).to({
   x: 116.2,
   alpha: 0.6735
  }, 0).wait(1).to({
   x: 117.7,
   alpha: 0.75
  }, 0).wait(1).to({
   x: 119.05,
   alpha: 0.8163
  }, 0).wait(1).to({
   x: 120.15,
   alpha: 0.8724
  }, 0).wait(1).to({
   x: 121.1,
   alpha: 0.9184
  }, 0).wait(1).to({
   x: 121.8,
   alpha: 0.9541
  }, 0).wait(1).to({
   x: 122.3,
   alpha: 0.9796
  }, 0).wait(1).to({
   x: 122.6,
   alpha: 0.9949
  }, 0).wait(1).to({
   regX: 90.7,
   regY: 22.3,
   x: 90.7,
   y: 22.3,
   alpha: 1
  }, 0).wait(21));
  var mask_1 = new cjs.Shape();
  mask_1._off = true;
  mask_1.graphics.p("AyvJmIAAmkMAlfAAAIAAGkg");
  mask_1.setTransform(120.0035, 61.3761);
  this.instance_1 = new lib.t06();
  this.instance_1.parent = this;
  this.instance_1.setTransform(70.7, 22.3, 1, 1, 0, 0, 0, 90.7, 22.3);
  this.instance_1.alpha = 0;
  this.instance_1._off = true;
  var maskedShapeInstanceList = [this.instance_1];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(5).to({
   _off: false
  }, 0).wait(1).to({
   regX: 122.7,
   regY: 101.8,
   x: 105.5,
   y: 101.8,
   alpha: 0.1378
  }, 0).wait(1).to({
   x: 108.05,
   alpha: 0.2653
  }, 0).wait(1).to({
   x: 110.4,
   alpha: 0.3827
  }, 0).wait(1).to({
   x: 112.5,
   alpha: 0.4898
  }, 0).wait(1).to({
   x: 114.45,
   alpha: 0.5867
  }, 0).wait(1).to({
   x: 116.2,
   alpha: 0.6735
  }, 0).wait(1).to({
   x: 117.7,
   alpha: 0.75
  }, 0).wait(1).to({
   x: 119.05,
   alpha: 0.8163
  }, 0).wait(1).to({
   x: 120.15,
   alpha: 0.8724
  }, 0).wait(1).to({
   x: 121.1,
   alpha: 0.9184
  }, 0).wait(1).to({
   x: 121.8,
   alpha: 0.9541
  }, 0).wait(1).to({
   x: 122.3,
   alpha: 0.9796
  }, 0).wait(1).to({
   x: 122.6,
   alpha: 0.9949
  }, 0).wait(1).to({
   regX: 90.7,
   regY: 22.3,
   x: 90.7,
   y: 22.3,
   alpha: 1
  }, 0).wait(16));
  var mask_2 = new cjs.Shape();
  mask_2._off = true;
  mask_2.graphics.p("AyvLbIAAjpMAlfAAAIAADpg");
  mask_2.setTransform(120.0035, 73.1373);
  this.instance_2 = new lib.t06();
  this.instance_2.parent = this;
  this.instance_2.setTransform(70.7, 22.3, 1, 1, 0, 0, 0, 90.7, 22.3);
  this.instance_2.alpha = 0;
  this.instance_2._off = true;
  var maskedShapeInstanceList = [this.instance_2];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(10).to({
   _off: false
  }, 0).wait(1).to({
   regX: 122.7,
   regY: 101.8,
   x: 105.5,
   y: 101.8,
   alpha: 0.1378
  }, 0).wait(1).to({
   x: 108.05,
   alpha: 0.2653
  }, 0).wait(1).to({
   x: 110.4,
   alpha: 0.3827
  }, 0).wait(1).to({
   x: 112.5,
   alpha: 0.4898
  }, 0).wait(1).to({
   x: 114.45,
   alpha: 0.5867
  }, 0).wait(1).to({
   x: 116.2,
   alpha: 0.6735
  }, 0).wait(1).to({
   x: 117.7,
   alpha: 0.75
  }, 0).wait(1).to({
   x: 119.05,
   alpha: 0.8163
  }, 0).wait(1).to({
   x: 120.15,
   alpha: 0.8724
  }, 0).wait(1).to({
   x: 121.1,
   alpha: 0.9184
  }, 0).wait(1).to({
   x: 121.8,
   alpha: 0.9541
  }, 0).wait(1).to({
   x: 122.3,
   alpha: 0.9796
  }, 0).wait(1).to({
   x: 122.6,
   alpha: 0.9949
  }, 0).wait(1).to({
   regX: 90.7,
   regY: 22.3,
   x: 90.7,
   y: 22.3,
   alpha: 1
  }, 0).wait(11));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(0, 58, 240, 84.6);
 (lib.txt05 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  var mask = new cjs.Shape();
  mask._off = true;
  mask.graphics.p("AyvHCIAAjpMAlfAAAIAADpg");
  mask.setTransform(120.0035, 44.9873);
  this.instance = new lib.t05();
  this.instance.parent = this;
  this.instance.setTransform(70.7, 22.3, 1, 1, 0, 0, 0, 90.7, 22.3);
  this.instance.alpha = 0;
  var maskedShapeInstanceList = [this.instance];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({
   regX: 102.5,
   regY: 90.9,
   x: 85.3,
   y: 90.9,
   alpha: 0.1378
  }, 0).wait(1).to({
   x: 87.85,
   alpha: 0.2653
  }, 0).wait(1).to({
   x: 90.2,
   alpha: 0.3827
  }, 0).wait(1).to({
   x: 92.3,
   alpha: 0.4898
  }, 0).wait(1).to({
   x: 94.25,
   alpha: 0.5867
  }, 0).wait(1).to({
   x: 96,
   alpha: 0.6735
  }, 0).wait(1).to({
   x: 97.5,
   alpha: 0.75
  }, 0).wait(1).to({
   x: 98.85,
   alpha: 0.8163
  }, 0).wait(1).to({
   x: 99.95,
   alpha: 0.8724
  }, 0).wait(1).to({
   x: 100.9,
   alpha: 0.9184
  }, 0).wait(1).to({
   x: 101.6,
   alpha: 0.9541
  }, 0).wait(1).to({
   x: 102.1,
   alpha: 0.9796
  }, 0).wait(1).to({
   x: 102.4,
   alpha: 0.9949
  }, 0).wait(1).to({
   regX: 90.7,
   regY: 22.3,
   x: 90.7,
   y: 22.3,
   alpha: 1
  }, 0).wait(21));
  var mask_1 = new cjs.Shape();
  mask_1._off = true;
  mask_1.graphics.p("AyvLBIAAn+MAlfAAAIAAH+g");
  mask_1.setTransform(120.0035, 70.5268);
  this.instance_1 = new lib.t05();
  this.instance_1.parent = this;
  this.instance_1.setTransform(70.7, 22.3, 1, 1, 0, 0, 0, 90.7, 22.3);
  this.instance_1.alpha = 0;
  this.instance_1._off = true;
  var maskedShapeInstanceList = [this.instance_1];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(5).to({
   _off: false
  }, 0).wait(1).to({
   regX: 102.5,
   regY: 90.9,
   x: 85.3,
   y: 90.9,
   alpha: 0.1378
  }, 0).wait(1).to({
   x: 87.85,
   alpha: 0.2653
  }, 0).wait(1).to({
   x: 90.2,
   alpha: 0.3827
  }, 0).wait(1).to({
   x: 92.3,
   alpha: 0.4898
  }, 0).wait(1).to({
   x: 94.25,
   alpha: 0.5867
  }, 0).wait(1).to({
   x: 96,
   alpha: 0.6735
  }, 0).wait(1).to({
   x: 97.5,
   alpha: 0.75
  }, 0).wait(1).to({
   x: 98.85,
   alpha: 0.8163
  }, 0).wait(1).to({
   x: 99.95,
   alpha: 0.8724
  }, 0).wait(1).to({
   x: 100.9,
   alpha: 0.9184
  }, 0).wait(1).to({
   x: 101.6,
   alpha: 0.9541
  }, 0).wait(1).to({
   x: 102.1,
   alpha: 0.9796
  }, 0).wait(1).to({
   x: 102.4,
   alpha: 0.9949
  }, 0).wait(1).to({
   regX: 90.7,
   regY: 22.3,
   x: 90.7,
   y: 22.3,
   alpha: 1
  }, 0).wait(16));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(0, 66.7, 219, 47.89999999999999);
 (lib.txt04 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  var mask = new cjs.Shape();
  mask._off = true;
  mask.graphics.p("AyvHCIAAjpMAlfAAAIAADpg");
  mask.setTransform(120.0035, 44.9873);
  this.instance = new lib.t04();
  this.instance.parent = this;
  this.instance.setTransform(70.7, 22.3, 1, 1, 0, 0, 0, 90.7, 22.3);
  this.instance.alpha = 0;
  var maskedShapeInstanceList = [this.instance];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({
   regX: 103,
   regY: 90.9,
   x: 85.8,
   y: 90.9,
   alpha: 0.1378
  }, 0).wait(1).to({
   x: 88.35,
   alpha: 0.2653
  }, 0).wait(1).to({
   x: 90.7,
   alpha: 0.3827
  }, 0).wait(1).to({
   x: 92.8,
   alpha: 0.4898
  }, 0).wait(1).to({
   x: 94.75,
   alpha: 0.5867
  }, 0).wait(1).to({
   x: 96.5,
   alpha: 0.6735
  }, 0).wait(1).to({
   x: 98,
   alpha: 0.75
  }, 0).wait(1).to({
   x: 99.35,
   alpha: 0.8163
  }, 0).wait(1).to({
   x: 100.45,
   alpha: 0.8724
  }, 0).wait(1).to({
   x: 101.4,
   alpha: 0.9184
  }, 0).wait(1).to({
   x: 102.1,
   alpha: 0.9541
  }, 0).wait(1).to({
   x: 102.6,
   alpha: 0.9796
  }, 0).wait(1).to({
   x: 102.9,
   alpha: 0.9949
  }, 0).wait(1).to({
   regX: 90.7,
   regY: 22.3,
   x: 90.7,
   y: 22.3,
   alpha: 1
  }, 0).wait(21));
  var mask_1 = new cjs.Shape();
  mask_1._off = true;
  mask_1.graphics.p("AyvI2IAAjpMAlfAAAIAADpg");
  mask_1.setTransform(120.0035, 56.6373);
  this.instance_1 = new lib.t04();
  this.instance_1.parent = this;
  this.instance_1.setTransform(70.7, 22.3, 1, 1, 0, 0, 0, 90.7, 22.3);
  this.instance_1.alpha = 0;
  this.instance_1._off = true;
  var maskedShapeInstanceList = [this.instance_1];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(5).to({
   _off: false
  }, 0).wait(1).to({
   regX: 103,
   regY: 90.9,
   x: 85.8,
   y: 90.9,
   alpha: 0.1378
  }, 0).wait(1).to({
   x: 88.35,
   alpha: 0.2653
  }, 0).wait(1).to({
   x: 90.7,
   alpha: 0.3827
  }, 0).wait(1).to({
   x: 92.8,
   alpha: 0.4898
  }, 0).wait(1).to({
   x: 94.75,
   alpha: 0.5867
  }, 0).wait(1).to({
   x: 96.5,
   alpha: 0.6735
  }, 0).wait(1).to({
   x: 98,
   alpha: 0.75
  }, 0).wait(1).to({
   x: 99.35,
   alpha: 0.8163
  }, 0).wait(1).to({
   x: 100.45,
   alpha: 0.8724
  }, 0).wait(1).to({
   x: 101.4,
   alpha: 0.9184
  }, 0).wait(1).to({
   x: 102.1,
   alpha: 0.9541
  }, 0).wait(1).to({
   x: 102.6,
   alpha: 0.9796
  }, 0).wait(1).to({
   x: 102.9,
   alpha: 0.9949
  }, 0).wait(1).to({
   regX: 90.7,
   regY: 22.3,
   x: 90.7,
   y: 22.3,
   alpha: 1
  }, 0).wait(16));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(0, 66.7, 219, 46.599999999999994);
 (lib.txt03 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  var mask = new cjs.Shape();
  mask._off = true;
  mask.graphics.p("AyvHCIAAjpMAlfAAAIAADpg");
  mask.setTransform(120.0035, 44.9873);
  this.instance = new lib.t03();
  this.instance.parent = this;
  this.instance.setTransform(70.7, 22.3, 1, 1, 0, 0, 0, 90.7, 22.3);
  this.instance.alpha = 0;
  var maskedShapeInstanceList = [this.instance];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({
   regX: 103.1,
   regY: 104,
   x: 85.9,
   y: 104,
   alpha: 0.1378
  }, 0).wait(1).to({
   x: 88.45,
   alpha: 0.2653
  }, 0).wait(1).to({
   x: 90.8,
   alpha: 0.3827
  }, 0).wait(1).to({
   x: 92.9,
   alpha: 0.4898
  }, 0).wait(1).to({
   x: 94.85,
   alpha: 0.5867
  }, 0).wait(1).to({
   x: 96.6,
   alpha: 0.6735
  }, 0).wait(1).to({
   x: 98.1,
   alpha: 0.75
  }, 0).wait(1).to({
   x: 99.45,
   alpha: 0.8163
  }, 0).wait(1).to({
   x: 100.55,
   alpha: 0.8724
  }, 0).wait(1).to({
   x: 101.5,
   alpha: 0.9184
  }, 0).wait(1).to({
   x: 102.2,
   alpha: 0.9541
  }, 0).wait(1).to({
   x: 102.7,
   alpha: 0.9796
  }, 0).wait(1).to({
   x: 103,
   alpha: 0.9949
  }, 0).wait(1).to({
   regX: 90.7,
   regY: 22.3,
   x: 90.7,
   y: 22.3,
   alpha: 1
  }, 0).wait(21));
  var mask_1 = new cjs.Shape();
  mask_1._off = true;
  mask_1.graphics.p("AyvI2IAAjpMAlfAAAIAADpg");
  mask_1.setTransform(120.0035, 56.6373);
  this.instance_1 = new lib.t03();
  this.instance_1.parent = this;
  this.instance_1.setTransform(70.7, 22.3, 1, 1, 0, 0, 0, 90.7, 22.3);
  this.instance_1.alpha = 0;
  this.instance_1._off = true;
  var maskedShapeInstanceList = [this.instance_1];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(5).to({
   _off: false
  }, 0).wait(1).to({
   regX: 103.1,
   regY: 104,
   x: 85.9,
   y: 104,
   alpha: 0.1378
  }, 0).wait(1).to({
   x: 88.45,
   alpha: 0.2653
  }, 0).wait(1).to({
   x: 90.8,
   alpha: 0.3827
  }, 0).wait(1).to({
   x: 92.9,
   alpha: 0.4898
  }, 0).wait(1).to({
   x: 94.85,
   alpha: 0.5867
  }, 0).wait(1).to({
   x: 96.6,
   alpha: 0.6735
  }, 0).wait(1).to({
   x: 98.1,
   alpha: 0.75
  }, 0).wait(1).to({
   x: 99.45,
   alpha: 0.8163
  }, 0).wait(1).to({
   x: 100.55,
   alpha: 0.8724
  }, 0).wait(1).to({
   x: 101.5,
   alpha: 0.9184
  }, 0).wait(1).to({
   x: 102.2,
   alpha: 0.9541
  }, 0).wait(1).to({
   x: 102.7,
   alpha: 0.9796
  }, 0).wait(1).to({
   x: 103,
   alpha: 0.9949
  }, 0).wait(1).to({
   regX: 90.7,
   regY: 22.3,
   x: 90.7,
   y: 22.3,
   alpha: 1
  }, 0).wait(16));
  var mask_2 = new cjs.Shape();
  mask_2._off = true;
  mask_2.graphics.p("AyvKrIAAjpMAlfAAAIAADpg");
  mask_2.setTransform(120.0035, 68.2873);
  this.instance_2 = new lib.t03();
  this.instance_2.parent = this;
  this.instance_2.setTransform(70.7, 22.3, 1, 1, 0, 0, 0, 90.7, 22.3);
  this.instance_2.alpha = 0;
  this.instance_2._off = true;
  var maskedShapeInstanceList = [this.instance_2];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(10).to({
   _off: false
  }, 0).wait(1).to({
   regX: 103.1,
   regY: 104,
   x: 85.9,
   y: 104,
   alpha: 0.1378
  }, 0).wait(1).to({
   x: 88.45,
   alpha: 0.2653
  }, 0).wait(1).to({
   x: 90.8,
   alpha: 0.3827
  }, 0).wait(1).to({
   x: 92.9,
   alpha: 0.4898
  }, 0).wait(1).to({
   x: 94.85,
   alpha: 0.5867
  }, 0).wait(1).to({
   x: 96.6,
   alpha: 0.6735
  }, 0).wait(1).to({
   x: 98.1,
   alpha: 0.75
  }, 0).wait(1).to({
   x: 99.45,
   alpha: 0.8163
  }, 0).wait(1).to({
   x: 100.55,
   alpha: 0.8724
  }, 0).wait(1).to({
   x: 101.5,
   alpha: 0.9184
  }, 0).wait(1).to({
   x: 102.2,
   alpha: 0.9541
  }, 0).wait(1).to({
   x: 102.7,
   alpha: 0.9796
  }, 0).wait(1).to({
   x: 103,
   alpha: 0.9949
  }, 0).wait(1).to({
   regX: 90.7,
   regY: 22.3,
   x: 90.7,
   y: 22.3,
   alpha: 1
  }, 0).wait(11));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(0, 66.7, 219, 69.89999999999999);
 (lib.txt02 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  var mask = new cjs.Shape();
  mask._off = true;
  mask.graphics.p("AyvHWIAAkEMAlfAAAIAAEEg");
  mask.setTransform(120.0035, 46.9663);
  this.instance = new lib.t02();
  this.instance.parent = this;
  this.instance.setTransform(70.7, 22.3, 1, 1, 0, 0, 0, 90.7, 22.3);
  this.instance.alpha = 0;
  var maskedShapeInstanceList = [this.instance];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({
   regX: 118.5,
   regY: 94.4,
   x: 101.3,
   y: 94.4,
   alpha: 0.1378
  }, 0).wait(1).to({
   x: 103.85,
   alpha: 0.2653
  }, 0).wait(1).to({
   x: 106.2,
   alpha: 0.3827
  }, 0).wait(1).to({
   x: 108.3,
   alpha: 0.4898
  }, 0).wait(1).to({
   x: 110.25,
   alpha: 0.5867
  }, 0).wait(1).to({
   x: 112,
   alpha: 0.6735
  }, 0).wait(1).to({
   x: 113.5,
   alpha: 0.75
  }, 0).wait(1).to({
   x: 114.85,
   alpha: 0.8163
  }, 0).wait(1).to({
   x: 115.95,
   alpha: 0.8724
  }, 0).wait(1).to({
   x: 116.9,
   alpha: 0.9184
  }, 0).wait(1).to({
   x: 117.6,
   alpha: 0.9541
  }, 0).wait(1).to({
   x: 118.1,
   alpha: 0.9796
  }, 0).wait(1).to({
   x: 118.4,
   alpha: 0.9949
  }, 0).wait(1).to({
   regX: 90.7,
   regY: 22.3,
   x: 90.7,
   y: 22.3,
   alpha: 1
  }, 0).wait(21));
  var mask_1 = new cjs.Shape();
  mask_1._off = true;
  mask_1.graphics.p("AyvJYIAAkEMAlfAAAIAAEEg");
  mask_1.setTransform(120.0035, 59.9663);
  this.instance_1 = new lib.t02();
  this.instance_1.parent = this;
  this.instance_1.setTransform(70.7, 22.3, 1, 1, 0, 0, 0, 90.7, 22.3);
  this.instance_1.alpha = 0;
  this.instance_1._off = true;
  var maskedShapeInstanceList = [this.instance_1];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(5).to({
   _off: false
  }, 0).wait(1).to({
   regX: 118.5,
   regY: 94.4,
   x: 101.3,
   y: 94.4,
   alpha: 0.1378
  }, 0).wait(1).to({
   x: 103.85,
   alpha: 0.2653
  }, 0).wait(1).to({
   x: 106.2,
   alpha: 0.3827
  }, 0).wait(1).to({
   x: 108.3,
   alpha: 0.4898
  }, 0).wait(1).to({
   x: 110.25,
   alpha: 0.5867
  }, 0).wait(1).to({
   x: 112,
   alpha: 0.6735
  }, 0).wait(1).to({
   x: 113.5,
   alpha: 0.75
  }, 0).wait(1).to({
   x: 114.85,
   alpha: 0.8163
  }, 0).wait(1).to({
   x: 115.95,
   alpha: 0.8724
  }, 0).wait(1).to({
   x: 116.9,
   alpha: 0.9184
  }, 0).wait(1).to({
   x: 117.6,
   alpha: 0.9541
  }, 0).wait(1).to({
   x: 118.1,
   alpha: 0.9796
  }, 0).wait(1).to({
   x: 118.4,
   alpha: 0.9949
  }, 0).wait(1).to({
   regX: 90.7,
   regY: 22.3,
   x: 90.7,
   y: 22.3,
   alpha: 1
  }, 0).wait(16));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(0, 68, 229, 52);
 (lib.txt01 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  var mask = new cjs.Shape();
  mask._off = true;
  mask.graphics.p("AvQCgIAAk1IehAAIAAE1g");
  mask.setTransform(97.6929, 16.0113);
  this.instance = new lib.t01();
  this.instance.parent = this;
  this.instance.setTransform(70.7, 22.3, 1, 1, 0, 0, 0, 90.7, 22.3);
  this.instance.alpha = 0;
  var maskedShapeInstanceList = [this.instance];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({
   regX: 77.7,
   regY: 30.4,
   x: 60.5,
   y: 30.4,
   alpha: 0.1378
  }, 0).wait(1).to({
   x: 63.05,
   alpha: 0.2653
  }, 0).wait(1).to({
   x: 65.4,
   alpha: 0.3827
  }, 0).wait(1).to({
   x: 67.5,
   alpha: 0.4898
  }, 0).wait(1).to({
   x: 69.45,
   alpha: 0.5867
  }, 0).wait(1).to({
   x: 71.2,
   alpha: 0.6735
  }, 0).wait(1).to({
   x: 72.7,
   alpha: 0.75
  }, 0).wait(1).to({
   x: 74.05,
   alpha: 0.8163
  }, 0).wait(1).to({
   x: 75.15,
   alpha: 0.8724
  }, 0).wait(1).to({
   x: 76.1,
   alpha: 0.9184
  }, 0).wait(1).to({
   x: 76.8,
   alpha: 0.9541
  }, 0).wait(1).to({
   x: 77.3,
   alpha: 0.9796
  }, 0).wait(1).to({
   x: 77.6,
   alpha: 0.9949
  }, 0).wait(1).to({
   regX: 90.7,
   regY: 22.3,
   x: 90.7,
   y: 22.3,
   alpha: 1
  }, 0).wait(16));
  var mask_1 = new cjs.Shape();
  mask_1._off = true;
  mask_1.graphics.p("AvQElIAAkNIehAAIAAENg");
  mask_1.setTransform(97.6929, 29.3081);
  this.instance_1 = new lib.t01();
  this.instance_1.parent = this;
  this.instance_1.setTransform(70.7, 22.3, 1, 1, 0, 0, 0, 90.7, 22.3);
  this.instance_1.alpha = 0;
  this.instance_1._off = true;
  var maskedShapeInstanceList = [this.instance_1];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(4).to({
   _off: false
  }, 0).wait(1).to({
   regX: 77.7,
   regY: 30.4,
   x: 60.5,
   y: 30.4,
   alpha: 0.1378
  }, 0).wait(1).to({
   x: 63.05,
   alpha: 0.2653
  }, 0).wait(1).to({
   x: 65.4,
   alpha: 0.3827
  }, 0).wait(1).to({
   x: 67.5,
   alpha: 0.4898
  }, 0).wait(1).to({
   x: 69.45,
   alpha: 0.5867
  }, 0).wait(1).to({
   x: 71.2,
   alpha: 0.6735
  }, 0).wait(1).to({
   x: 72.7,
   alpha: 0.75
  }, 0).wait(1).to({
   x: 74.05,
   alpha: 0.8163
  }, 0).wait(1).to({
   x: 75.15,
   alpha: 0.8724
  }, 0).wait(1).to({
   x: 76.1,
   alpha: 0.9184
  }, 0).wait(1).to({
   x: 76.8,
   alpha: 0.9541
  }, 0).wait(1).to({
   x: 77.3,
   alpha: 0.9796
  }, 0).wait(1).to({
   x: 77.6,
   alpha: 0.9949
  }, 0).wait(1).to({
   regX: 90.7,
   regY: 22.3,
   x: 90.7,
   y: 22.3,
   alpha: 1
  }, 0).wait(12));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(0, 2, 192.5, 53);
 (lib.arrows3 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  var mask = new cjs.Shape();
  mask._off = true;
  var mask_graphics_0 = new cjs.Graphics().p("AqsC/IAPg2IVKF+IgPA2g");
  var mask_graphics_1 = new cjs.Graphics().p("Aq7C/IAuikIVJF+IguCkg");
  var mask_graphics_2 = new cjs.Graphics().p("ArKC/IBLkIIVKF8IhLEKg");
  var mask_graphics_3 = new cjs.Graphics().p("ArXC/IBllmIVKF8IhlFog");
  var mask_graphics_4 = new cjs.Graphics().p("ArjC/IB9m8IVKF9Ih9G9g");
  var mask_graphics_5 = new cjs.Graphics().p("AruC/ICToJIVKF9IiTIKg");
  var mask_graphics_6 = new cjs.Graphics().p("Ar4C/ICnpOIVKF9IinJPg");
  var mask_graphics_7 = new cjs.Graphics().p("AsAC/IC4qLIVJF9Ii4KMg");
  var mask_graphics_8 = new cjs.Graphics().p("AsIC/IDHrAIVKF9IjHLBg");
  var mask_graphics_9 = new cjs.Graphics().p("AsOC/IDTrtIVKF9IjTLug");
  var mask_graphics_10 = new cjs.Graphics().p("AsTDLIDesSIVJF9IjeMSg");
  var mask_graphics_11 = new cjs.Graphics().p("AsXDZIDmsvIVJF+IjmMvg");
  var mask_graphics_12 = new cjs.Graphics().p("AsaDjIDrtDIVKF+IjrNDg");
  var mask_graphics_13 = new cjs.Graphics().p("AscDpIDvtPIVKF+IjvNPg");
  var mask_graphics_14 = new cjs.Graphics().p("AscDrIDwtTIVJF+IjwNTg");
  this.timeline.addTween(cjs.Tween.get(mask).to({
   graphics: mask_graphics_0,
   x: 67.0739,
   y: 57.2651
  }).wait(1).to({
   graphics: mask_graphics_1,
   x: 68.6053,
   y: 57.2656
  }).wait(1).to({
   graphics: mask_graphics_2,
   x: 70.0234,
   y: 57.2661
  }).wait(1).to({
   graphics: mask_graphics_3,
   x: 71.3279,
   y: 57.2665
  }).wait(1).to({
   graphics: mask_graphics_4,
   x: 72.5191,
   y: 57.2669
  }).wait(1).to({
   graphics: mask_graphics_5,
   x: 73.5968,
   y: 57.2673
  }).wait(1).to({
   graphics: mask_graphics_6,
   x: 74.561,
   y: 57.2676
  }).wait(1).to({
   graphics: mask_graphics_7,
   x: 75.4118,
   y: 57.2679
  }).wait(1).to({
   graphics: mask_graphics_8,
   x: 76.1492,
   y: 57.2681
  }).wait(1).to({
   graphics: mask_graphics_9,
   x: 76.7731,
   y: 57.2683
  }).wait(1).to({
   graphics: mask_graphics_10,
   x: 77.2836,
   y: 56.1081
  }).wait(1).to({
   graphics: mask_graphics_11,
   x: 77.6807,
   y: 54.6825
  }).wait(1).to({
   graphics: mask_graphics_12,
   x: 77.9643,
   y: 53.6643
  }).wait(1).to({
   graphics: mask_graphics_13,
   x: 78.1344,
   y: 53.0533
  }).wait(1).to({
   graphics: mask_graphics_14,
   x: 78.3266,
   y: 52.8879
  }).wait(1));
  this.instance = new lib.arrow3();
  this.instance.parent = this;
  this.instance.setTransform(122.8, 63.85, 1, 1, 0, 0, 0, 24.8, 35.6);
  this.instance_1 = new lib.arrow3();
  this.instance_1.parent = this;
  this.instance_1.setTransform(98.05, 56.35, 1, 1, 0, 0, 0, 24.8, 35.6);
  this.instance_2 = new lib.arrow3();
  this.instance_2.parent = this;
  this.instance_2.setTransform(73.3, 49.1, 1, 1, 0, 0, 0, 24.8, 35.6);
  this.instance_3 = new lib.arrow3();
  this.instance_3.parent = this;
  this.instance_3.setTransform(49.3, 41.85, 1, 1, 0, 0, 0, 24.8, 35.6);
  this.instance_4 = new lib.arrow3();
  this.instance_4.parent = this;
  this.instance_4.setTransform(24.8, 35.6, 1, 1, 0, 0, 0, 24.8, 35.6);
  var maskedShapeInstanceList = [this.instance, this.instance_1, this.instance_2, this.instance_3, this.instance_4];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask;
  }
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.instance_4
   }, {
    t: this.instance_3
   }, {
    t: this.instance_2
   }, {
    t: this.instance_1
   }, {
    t: this.instance
   }]
  }).wait(15));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(0, 0, 147.5, 99.5);
 (lib.arrow = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  var mask = new cjs.Shape();
  mask._off = true;
  var mask_graphics_0 = new cjs.Graphics().p("EAOCB62IAAkQMAt5AAAIAAEQg");
  var mask_graphics_1 = new cjs.Graphics().p("EAOCB62IAAmNMAt5AAAIAAGNg");
  var mask_graphics_2 = new cjs.Graphics().p("EAOCB63IAAoKMAt5AAAIAAIKg");
  var mask_graphics_3 = new cjs.Graphics().p("EAOCB63IAAqHMAt5AAAIAAKHg");
  var mask_graphics_4 = new cjs.Graphics().p("EAOCB63IAAsDMAt5AAAIAAMDg");
  var mask_graphics_5 = new cjs.Graphics().p("EAOCB63IAAuAMAt5AAAIAAOAg");
  var mask_graphics_6 = new cjs.Graphics().p("EAOCB63IAAv8MAt5AAAIAAP8g");
  var mask_graphics_7 = new cjs.Graphics().p("EAOCB64IAAx6MAt5AAAIAAR6g");
  var mask_graphics_8 = new cjs.Graphics().p("EAOCB64IAAz3MAt5AAAIAAT3g");
  var mask_graphics_9 = new cjs.Graphics().p("EAOCB64IAA1zMAt5AAAIAAVzg");
  var mask_graphics_10 = new cjs.Graphics().p("EAOCB64IAA3wMAt5AAAIAAXwg");
  var mask_graphics_11 = new cjs.Graphics().p("EAOCB65IAA5tMAt5AAAIAAZtg");
  var mask_graphics_12 = new cjs.Graphics().p("EAOCB65IAA7qMAt5AAAIAAbqg");
  var mask_graphics_13 = new cjs.Graphics().p("EAOCB65IAA9mMAt5AAAIAAdmg");
  var mask_graphics_14 = new cjs.Graphics().p("EAOCB65IAA/jMAt5AAAIAAfjg");
  var mask_graphics_15 = new cjs.Graphics().p("EAOCB65MAAAghfMAt5AAAMAAAAhfg");
  var mask_graphics_16 = new cjs.Graphics().p("EAOCB66MAAAgjdMAt5AAAMAAAAjdg");
  var mask_graphics_17 = new cjs.Graphics().p("EAOCB66MAAAglZMAt5AAAMAAAAlZg");
  var mask_graphics_18 = new cjs.Graphics().p("EAOCB66MAAAgnWMAt5AAAMAAAAnWg");
  var mask_graphics_19 = new cjs.Graphics().p("EAOCB66MAAAgpTMAt5AAAMAAAApTg");
  var mask_graphics_20 = new cjs.Graphics().p("EAOCB66MAAAgrPMAt5AAAMAAAArPg");
  var mask_graphics_21 = new cjs.Graphics().p("EAOCB61MAAAgtMMAt5AAAMAAAAtMg");
  this.timeline.addTween(cjs.Tween.get(mask).to({
   graphics: mask_graphics_0,
   x: 383.5248,
   y: 786.2192
  }).wait(1).to({
   graphics: mask_graphics_1,
   x: 383.5248,
   y: 786.2406
  }).wait(1).to({
   graphics: mask_graphics_2,
   x: 383.5248,
   y: 786.2619
  }).wait(1).to({
   graphics: mask_graphics_3,
   x: 383.5248,
   y: 786.2832
  }).wait(1).to({
   graphics: mask_graphics_4,
   x: 383.5248,
   y: 786.3045
  }).wait(1).to({
   graphics: mask_graphics_5,
   x: 383.5248,
   y: 786.3259
  }).wait(1).to({
   graphics: mask_graphics_6,
   x: 383.5248,
   y: 786.3472
  }).wait(1).to({
   graphics: mask_graphics_7,
   x: 383.5248,
   y: 786.3685
  }).wait(1).to({
   graphics: mask_graphics_8,
   x: 383.5248,
   y: 786.3899
  }).wait(1).to({
   graphics: mask_graphics_9,
   x: 383.5248,
   y: 786.4112
  }).wait(1).to({
   graphics: mask_graphics_10,
   x: 383.5248,
   y: 786.4325
  }).wait(1).to({
   graphics: mask_graphics_11,
   x: 383.5248,
   y: 786.4538
  }).wait(1).to({
   graphics: mask_graphics_12,
   x: 383.5248,
   y: 786.4752
  }).wait(1).to({
   graphics: mask_graphics_13,
   x: 383.5248,
   y: 786.4965
  }).wait(1).to({
   graphics: mask_graphics_14,
   x: 383.5248,
   y: 786.5178
  }).wait(1).to({
   graphics: mask_graphics_15,
   x: 383.5248,
   y: 786.5391
  }).wait(1).to({
   graphics: mask_graphics_16,
   x: 383.5248,
   y: 786.5605
  }).wait(1).to({
   graphics: mask_graphics_17,
   x: 383.5248,
   y: 786.5818
  }).wait(1).to({
   graphics: mask_graphics_18,
   x: 383.5248,
   y: 786.6031
  }).wait(1).to({
   graphics: mask_graphics_19,
   x: 383.5248,
   y: 786.6245
  }).wait(1).to({
   graphics: mask_graphics_20,
   x: 383.5248,
   y: 786.6458
  }).wait(1).to({
   graphics: mask_graphics_21,
   x: 383.5248,
   y: 786.0887
  }).wait(1));
  this.instance = new lib.arrow1();
  this.instance.parent = this;
  this.instance.setTransform(608.8, 1421.5, 1, 1, 0, 0, 0, 123.9, 124);
  var maskedShapeInstanceList = [this.instance];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(22));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(484.9, 1297.5, 247.80000000000007, 248.0999999999999);
 (lib.content = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {
   cvr_frame1: 69,
   cvr_frame2_1: 184,
   cvr_frame3_2: 273,
   cvr_frame4_2: 354,
   "cvr_frame#5_1": 430,
   cvr_stay: 440
  });
  this.frame_440 = function() {
   if (!this.cycle) this.cycle = 0;
   this.cycle++;
   var frames = this.duration * this.cycle + this.currentFrame;
   if (frames / createjs.Ticker.getMeasuredFPS() > 30) {
    if (this.cycle > 1) {
     _globalStop(this.stage);
    } else {
     var stopFrame = this.currentFrame;
     var tst = cjs.Tween.get(this);
     this.timeline.addTween(cjs.Tween.get(this).wait(this.duration - 1).call(function() {
      globalGotoAndStop(stopFrame);
     }));
    }
   }
  }
  this.timeline.addTween(cjs.Tween.get(this).wait(440).call(this.frame_440));
  this.instance = new lib.logo_s();
  this.instance.parent = this;
  this.instance.setTransform(187, 13);
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(465));
  this.instance_1 = new lib.legal_01();
  this.instance_1.parent = this;
  this.instance_1.setTransform(120, 200, 1, 1, 0, 0, 0, 120, 200);
  this.instance_1._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(459).to({
   _off: false
  }, 0).to({
   _off: true
  }, 1).wait(5));
  this.instance_2 = new lib.black_plate();
  this.instance_2.parent = this;
  this.timeline.addTween(cjs.Tween.get(this.instance_2).to({
   alpha: 0
  }, 14, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(434).to({
   _off: false
  }, 0).to({
   alpha: 1
  }, 10, cjs.Ease.get(1)).wait(6));
  this.instance_3 = new lib.snoska2("synched", 0, false);
  this.instance_3.parent = this;
  this.instance_3.alpha = 0;
  this.instance_3._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(24).to({
   _off: false
  }, 0).to({
   alpha: 1
  }, 15, cjs.Ease.get(1)).wait(335).to({
   startPosition: 0
  }, 0).to({
   alpha: 0
  }, 14, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(76));
  this.instance_4 = new lib.snoska("synched", 0, false);
  this.instance_4.parent = this;
  this.instance_4.alpha = 0;
  this.instance_4._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(374).to({
   _off: false
  }, 0).to({
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(77));
  this.instance_5 = new lib.txt06("synched", 0, false);
  this.instance_5.parent = this;
  this.instance_5._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(374).to({
   _off: false
  }, 0).wait(91));
  this.instance_6 = new lib.txt05("synched", 0, false);
  this.instance_6.parent = this;
  this.instance_6._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(289).to({
   _off: false
  }, 0).wait(70).to({
   startPosition: 34
  }, 0).to({
   alpha: 0
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(90));
  this.instance_7 = new lib.txt04("synched", 0, false);
  this.instance_7.parent = this;
  this.instance_7._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(209).to({
   _off: false
  }, 0).wait(65).to({
   startPosition: 34
  }, 0).to({
   alpha: 0
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(175));
  this.instance_8 = new lib.txt03("synched", 0, false);
  this.instance_8.parent = this;
  this.instance_8._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(119).to({
   _off: false
  }, 0).wait(75).to({
   startPosition: 34
  }, 0).to({
   alpha: 0
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(255));
  this.instance_9 = new lib.txt02("synched", 0, false);
  this.instance_9.parent = this;
  this.instance_9._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(24).to({
   _off: false
  }, 0).wait(80).to({
   startPosition: 34
  }, 0).to({
   alpha: 0
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(345));
  this.instance_10 = new lib.arrow("synched", 0, false);
  this.instance_10.parent = this;
  this.instance_10.setTransform(10.55, 28.55, 0.23, 0.23, 0, 0, 0, 41.6, 124.2);
  this.instance_10._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(226).to({
   _off: false
  }, 0).wait(48).to({
   mode: "single",
   startPosition: 21
  }, 0).to({
   alpha: 0
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(175));
  this.instance_11 = new lib.arrows3("synched", 0, false);
  this.instance_11.parent = this;
  this.instance_11.setTransform(180.8, 237.8, 1, 1, 0, 0, 0, 73.8, 49.8);
  this.instance_11._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(306).to({
   _off: false
  }, 0).wait(53).to({
   startPosition: 14
  }, 0).to({
   alpha: 0
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(90));
  this.instance_12 = new lib.arrows2("synched", 0, false);
  this.instance_12.parent = this;
  this.instance_12.setTransform(175.85, 257.05, 1, 1, 0, 0, 0, 59.6, 50.8);
  this.instance_12._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(137).to({
   _off: false
  }, 0).wait(57).to({
   startPosition: 14
  }, 0).to({
   alpha: 0
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(255));
  this.instance_13 = new lib.txt01("synched", 0, false);
  this.instance_13.parent = this;
  this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(465));
  this.instance_14 = new lib.car_1();
  this.instance_14.parent = this;
  this.instance_14.setTransform(87.2, 271, 1, 1, 0, 0, 0, 120.2, 75);
  this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(104).to({
   alpha: 0
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(345));
  this.instance_15 = new lib.red_line();
  this.instance_15.parent = this;
  this.instance_15.setTransform(-101, 350.5, 1, 1, 0, 0, 180, 100, 1.5);
  this.instance_15._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(10).to({
   _off: false
  }, 0).to({
   x: -31
  }, 30, cjs.Ease.get(1)).wait(425));
  this.instance_16 = new lib.red_line();
  this.instance_16.parent = this;
  this.instance_16.setTransform(340, 153.5, 1, 1, 0, 0, 0, 100, 1.5);
  this.instance_16._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(10).to({
   _off: false
  }, 0).to({
   x: 140
  }, 30, cjs.Ease.get(1)).wait(425));
  var mask = new cjs.Shape();
  mask._off = true;
  var mask_graphics_0 = new cjs.Graphics().p("AxLcSMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_119 = new cjs.Graphics().p("AhKcSMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_120 = new cjs.Graphics().p("AhNcSMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_121 = new cjs.Graphics().p("AhUcSMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_122 = new cjs.Graphics().p("AhhcSMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_123 = new cjs.Graphics().p("AhycSMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_124 = new cjs.Graphics().p("AiJcSMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_125 = new cjs.Graphics().p("AilcSMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_126 = new cjs.Graphics().p("AjGcSMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_127 = new cjs.Graphics().p("AjrcSMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_128 = new cjs.Graphics().p("AkWcSMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_129 = new cjs.Graphics().p("AlGcTMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_130 = new cjs.Graphics().p("Al7cTMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_131 = new cjs.Graphics().p("Am1cTMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_132 = new cjs.Graphics().p("An0cTMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_133 = new cjs.Graphics().p("Ao4cSMAAAggpMAomAAAMAAAAgpg");
  var mask_graphics_134 = new cjs.Graphics().p("Ap5cSMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_135 = new cjs.Graphics().p("Aq1cSMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_136 = new cjs.Graphics().p("ArtcSMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_137 = new cjs.Graphics().p("AshcSMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_138 = new cjs.Graphics().p("AtQcRMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_139 = new cjs.Graphics().p("At8cRMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_140 = new cjs.Graphics().p("AujcRMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_141 = new cjs.Graphics().p("AvGcRMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_142 = new cjs.Graphics().p("AvlcRMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_143 = new cjs.Graphics().p("AwAcRMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_144 = new cjs.Graphics().p("AwXcRMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_145 = new cjs.Graphics().p("AwqcRMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_146 = new cjs.Graphics().p("Aw4cRMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_147 = new cjs.Graphics().p("AxDcRMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_148 = new cjs.Graphics().p("AxJcRMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_149 = new cjs.Graphics().p("AxLcSMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_209 = new cjs.Graphics().p("AhKcSMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_210 = new cjs.Graphics().p("AhNcSMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_211 = new cjs.Graphics().p("AhUcSMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_212 = new cjs.Graphics().p("AhhcSMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_213 = new cjs.Graphics().p("AhycSMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_214 = new cjs.Graphics().p("AiJcSMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_215 = new cjs.Graphics().p("AilcSMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_216 = new cjs.Graphics().p("AjGcSMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_217 = new cjs.Graphics().p("AjrcSMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_218 = new cjs.Graphics().p("AkWcSMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_219 = new cjs.Graphics().p("AlGcTMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_220 = new cjs.Graphics().p("Al7cTMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_221 = new cjs.Graphics().p("Am1cTMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_222 = new cjs.Graphics().p("An0cTMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_223 = new cjs.Graphics().p("Ao4cSMAAAggpMAomAAAMAAAAgpg");
  var mask_graphics_224 = new cjs.Graphics().p("Ap5cSMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_225 = new cjs.Graphics().p("Aq1cSMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_226 = new cjs.Graphics().p("ArtcSMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_227 = new cjs.Graphics().p("AshcSMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_228 = new cjs.Graphics().p("AtQcRMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_229 = new cjs.Graphics().p("At8cRMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_230 = new cjs.Graphics().p("AujcRMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_231 = new cjs.Graphics().p("AvGcRMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_232 = new cjs.Graphics().p("AvlcRMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_233 = new cjs.Graphics().p("AwAcRMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_234 = new cjs.Graphics().p("AwXcRMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_235 = new cjs.Graphics().p("AwqcRMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_236 = new cjs.Graphics().p("Aw4cRMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_237 = new cjs.Graphics().p("AxDcRMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_238 = new cjs.Graphics().p("AxJcRMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_239 = new cjs.Graphics().p("AxLcSMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_289 = new cjs.Graphics().p("AhKcSMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_290 = new cjs.Graphics().p("AhNcSMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_291 = new cjs.Graphics().p("AhUcSMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_292 = new cjs.Graphics().p("AhhcSMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_293 = new cjs.Graphics().p("AhycSMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_294 = new cjs.Graphics().p("AiJcSMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_295 = new cjs.Graphics().p("AilcSMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_296 = new cjs.Graphics().p("AjGcSMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_297 = new cjs.Graphics().p("AjrcSMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_298 = new cjs.Graphics().p("AkWcSMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_299 = new cjs.Graphics().p("AlGcTMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_300 = new cjs.Graphics().p("Al7cTMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_301 = new cjs.Graphics().p("Am1cTMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_302 = new cjs.Graphics().p("An0cTMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_303 = new cjs.Graphics().p("Ao4cSMAAAggpMAomAAAMAAAAgpg");
  var mask_graphics_304 = new cjs.Graphics().p("Ap5cSMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_305 = new cjs.Graphics().p("Aq1cSMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_306 = new cjs.Graphics().p("ArtcSMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_307 = new cjs.Graphics().p("AshcSMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_308 = new cjs.Graphics().p("AtQcRMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_309 = new cjs.Graphics().p("At8cRMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_310 = new cjs.Graphics().p("AujcRMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_311 = new cjs.Graphics().p("AvGcRMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_312 = new cjs.Graphics().p("AvlcRMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_313 = new cjs.Graphics().p("AwAcRMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_314 = new cjs.Graphics().p("AwXcRMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_315 = new cjs.Graphics().p("AwqcRMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_316 = new cjs.Graphics().p("Aw4cRMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_317 = new cjs.Graphics().p("AxDcRMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_318 = new cjs.Graphics().p("AxJcRMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_319 = new cjs.Graphics().p("AxLcSMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_374 = new cjs.Graphics().p("AhKcSMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_375 = new cjs.Graphics().p("AhNcSMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_376 = new cjs.Graphics().p("AhUcSMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_377 = new cjs.Graphics().p("AhhcSMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_378 = new cjs.Graphics().p("AhycSMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_379 = new cjs.Graphics().p("AiJcSMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_380 = new cjs.Graphics().p("AilcSMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_381 = new cjs.Graphics().p("AjGcSMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_382 = new cjs.Graphics().p("AjrcSMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_383 = new cjs.Graphics().p("AkWcSMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_384 = new cjs.Graphics().p("AlGcTMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_385 = new cjs.Graphics().p("Al7cTMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_386 = new cjs.Graphics().p("Am1cTMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_387 = new cjs.Graphics().p("An0cTMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_388 = new cjs.Graphics().p("Ao4cSMAAAggpMAomAAAMAAAAgpg");
  var mask_graphics_389 = new cjs.Graphics().p("AqLcSMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_390 = new cjs.Graphics().p("ArYcSMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_391 = new cjs.Graphics().p("AsgcSMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_392 = new cjs.Graphics().p("AticSMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_393 = new cjs.Graphics().p("AufcRMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_394 = new cjs.Graphics().p("AvXcRMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_395 = new cjs.Graphics().p("AwKcRMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_396 = new cjs.Graphics().p("Aw3cRMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_397 = new cjs.Graphics().p("AxfcRMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_398 = new cjs.Graphics().p("AyBcRMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_399 = new cjs.Graphics().p("AyfcRMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_400 = new cjs.Graphics().p("Ay2cRMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_401 = new cjs.Graphics().p("AzJcRMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_402 = new cjs.Graphics().p("AzWcRMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_403 = new cjs.Graphics().p("AzecRMAAAggpMAonAAAMAAAAgpg");
  var mask_graphics_404 = new cjs.Graphics().p("AzhcSMAAAggpMAonAAAMAAAAgpg");
  this.timeline.addTween(cjs.Tween.get(mask).to({
   graphics: mask_graphics_0,
   x: 149.9988,
   y: 181.0029
  }).wait(119).to({
   graphics: mask_graphics_119,
   x: 252.4988,
   y: 181.0029
  }).wait(1).to({
   graphics: mask_graphics_120,
   x: 252.2465,
   y: 181.0034
  }).wait(1).to({
   graphics: mask_graphics_121,
   x: 251.4895,
   y: 181.0049
  }).wait(1).to({
   graphics: mask_graphics_122,
   x: 250.2279,
   y: 181.0074
  }).wait(1).to({
   graphics: mask_graphics_123,
   x: 248.4617,
   y: 181.011
  }).wait(1).to({
   graphics: mask_graphics_124,
   x: 246.1908,
   y: 181.0155
  }).wait(1).to({
   graphics: mask_graphics_125,
   x: 243.4153,
   y: 181.0211
  }).wait(1).to({
   graphics: mask_graphics_126,
   x: 240.1351,
   y: 181.0277
  }).wait(1).to({
   graphics: mask_graphics_127,
   x: 236.3503,
   y: 181.0352
  }).wait(1).to({
   graphics: mask_graphics_128,
   x: 232.0609,
   y: 181.0438
  }).wait(1).to({
   graphics: mask_graphics_129,
   x: 227.2669,
   y: 181.0535
  }).wait(1).to({
   graphics: mask_graphics_130,
   x: 221.9681,
   y: 181.0641
  }).wait(1).to({
   graphics: mask_graphics_131,
   x: 216.1648,
   y: 181.0757
  }).wait(1).to({
   graphics: mask_graphics_132,
   x: 209.8568,
   y: 181.0884
  }).wait(1).to({
   graphics: mask_graphics_133,
   x: 203.0442,
   y: 180.9975
  }).wait(1).to({
   graphics: mask_graphics_134,
   x: 196.6207,
   y: 180.9855
  }).wait(1).to({
   graphics: mask_graphics_135,
   x: 190.6117,
   y: 180.9743
  }).wait(1).to({
   graphics: mask_graphics_136,
   x: 185.017,
   y: 180.9638
  }).wait(1).to({
   graphics: mask_graphics_137,
   x: 179.8368,
   y: 180.9541
  }).wait(1).to({
   graphics: mask_graphics_138,
   x: 175.071,
   y: 180.9452
  }).wait(1).to({
   graphics: mask_graphics_139,
   x: 170.7196,
   y: 180.9371
  }).wait(1).to({
   graphics: mask_graphics_140,
   x: 166.7827,
   y: 180.9297
  }).wait(1).to({
   graphics: mask_graphics_141,
   x: 163.2601,
   y: 180.9232
  }).wait(1).to({
   graphics: mask_graphics_142,
   x: 160.152,
   y: 180.9173
  }).wait(1).to({
   graphics: mask_graphics_143,
   x: 157.4583,
   y: 180.9123
  }).wait(1).to({
   graphics: mask_graphics_144,
   x: 155.179,
   y: 180.908
  }).wait(1).to({
   graphics: mask_graphics_145,
   x: 153.3141,
   y: 180.9046
  }).wait(1).to({
   graphics: mask_graphics_146,
   x: 151.8637,
   y: 180.9019
  }).wait(1).to({
   graphics: mask_graphics_147,
   x: 150.8276,
   y: 180.8999
  }).wait(1).to({
   graphics: mask_graphics_148,
   x: 150.206,
   y: 180.8988
  }).wait(1).to({
   graphics: mask_graphics_149,
   x: 149.9988,
   y: 181.0029
  }).wait(60).to({
   graphics: mask_graphics_209,
   x: 252.4988,
   y: 181.0029
  }).wait(1).to({
   graphics: mask_graphics_210,
   x: 252.2465,
   y: 181.0034
  }).wait(1).to({
   graphics: mask_graphics_211,
   x: 251.4895,
   y: 181.0049
  }).wait(1).to({
   graphics: mask_graphics_212,
   x: 250.2279,
   y: 181.0074
  }).wait(1).to({
   graphics: mask_graphics_213,
   x: 248.4617,
   y: 181.011
  }).wait(1).to({
   graphics: mask_graphics_214,
   x: 246.1908,
   y: 181.0155
  }).wait(1).to({
   graphics: mask_graphics_215,
   x: 243.4153,
   y: 181.0211
  }).wait(1).to({
   graphics: mask_graphics_216,
   x: 240.1351,
   y: 181.0277
  }).wait(1).to({
   graphics: mask_graphics_217,
   x: 236.3503,
   y: 181.0352
  }).wait(1).to({
   graphics: mask_graphics_218,
   x: 232.0609,
   y: 181.0438
  }).wait(1).to({
   graphics: mask_graphics_219,
   x: 227.2669,
   y: 181.0535
  }).wait(1).to({
   graphics: mask_graphics_220,
   x: 221.9681,
   y: 181.0641
  }).wait(1).to({
   graphics: mask_graphics_221,
   x: 216.1648,
   y: 181.0757
  }).wait(1).to({
   graphics: mask_graphics_222,
   x: 209.8568,
   y: 181.0884
  }).wait(1).to({
   graphics: mask_graphics_223,
   x: 203.0442,
   y: 180.9975
  }).wait(1).to({
   graphics: mask_graphics_224,
   x: 196.6207,
   y: 180.9855
  }).wait(1).to({
   graphics: mask_graphics_225,
   x: 190.6117,
   y: 180.9743
  }).wait(1).to({
   graphics: mask_graphics_226,
   x: 185.017,
   y: 180.9638
  }).wait(1).to({
   graphics: mask_graphics_227,
   x: 179.8368,
   y: 180.9541
  }).wait(1).to({
   graphics: mask_graphics_228,
   x: 175.071,
   y: 180.9452
  }).wait(1).to({
   graphics: mask_graphics_229,
   x: 170.7196,
   y: 180.9371
  }).wait(1).to({
   graphics: mask_graphics_230,
   x: 166.7827,
   y: 180.9297
  }).wait(1).to({
   graphics: mask_graphics_231,
   x: 163.2601,
   y: 180.9232
  }).wait(1).to({
   graphics: mask_graphics_232,
   x: 160.152,
   y: 180.9173
  }).wait(1).to({
   graphics: mask_graphics_233,
   x: 157.4583,
   y: 180.9123
  }).wait(1).to({
   graphics: mask_graphics_234,
   x: 155.179,
   y: 180.908
  }).wait(1).to({
   graphics: mask_graphics_235,
   x: 153.3141,
   y: 180.9046
  }).wait(1).to({
   graphics: mask_graphics_236,
   x: 151.8637,
   y: 180.9019
  }).wait(1).to({
   graphics: mask_graphics_237,
   x: 150.8276,
   y: 180.8999
  }).wait(1).to({
   graphics: mask_graphics_238,
   x: 150.206,
   y: 180.8988
  }).wait(1).to({
   graphics: mask_graphics_239,
   x: 149.9988,
   y: 181.0029
  }).wait(50).to({
   graphics: mask_graphics_289,
   x: 252.4988,
   y: 181.0029
  }).wait(1).to({
   graphics: mask_graphics_290,
   x: 252.2465,
   y: 181.0034
  }).wait(1).to({
   graphics: mask_graphics_291,
   x: 251.4895,
   y: 181.0049
  }).wait(1).to({
   graphics: mask_graphics_292,
   x: 250.2279,
   y: 181.0074
  }).wait(1).to({
   graphics: mask_graphics_293,
   x: 248.4617,
   y: 181.011
  }).wait(1).to({
   graphics: mask_graphics_294,
   x: 246.1908,
   y: 181.0155
  }).wait(1).to({
   graphics: mask_graphics_295,
   x: 243.4153,
   y: 181.0211
  }).wait(1).to({
   graphics: mask_graphics_296,
   x: 240.1351,
   y: 181.0277
  }).wait(1).to({
   graphics: mask_graphics_297,
   x: 236.3503,
   y: 181.0352
  }).wait(1).to({
   graphics: mask_graphics_298,
   x: 232.0609,
   y: 181.0438
  }).wait(1).to({
   graphics: mask_graphics_299,
   x: 227.2669,
   y: 181.0535
  }).wait(1).to({
   graphics: mask_graphics_300,
   x: 221.9681,
   y: 181.0641
  }).wait(1).to({
   graphics: mask_graphics_301,
   x: 216.1648,
   y: 181.0757
  }).wait(1).to({
   graphics: mask_graphics_302,
   x: 209.8568,
   y: 181.0884
  }).wait(1).to({
   graphics: mask_graphics_303,
   x: 203.0442,
   y: 180.9975
  }).wait(1).to({
   graphics: mask_graphics_304,
   x: 196.6207,
   y: 180.9855
  }).wait(1).to({
   graphics: mask_graphics_305,
   x: 190.6117,
   y: 180.9743
  }).wait(1).to({
   graphics: mask_graphics_306,
   x: 185.017,
   y: 180.9638
  }).wait(1).to({
   graphics: mask_graphics_307,
   x: 179.8368,
   y: 180.9541
  }).wait(1).to({
   graphics: mask_graphics_308,
   x: 175.071,
   y: 180.9452
  }).wait(1).to({
   graphics: mask_graphics_309,
   x: 170.7196,
   y: 180.9371
  }).wait(1).to({
   graphics: mask_graphics_310,
   x: 166.7827,
   y: 180.9297
  }).wait(1).to({
   graphics: mask_graphics_311,
   x: 163.2601,
   y: 180.9232
  }).wait(1).to({
   graphics: mask_graphics_312,
   x: 160.152,
   y: 180.9173
  }).wait(1).to({
   graphics: mask_graphics_313,
   x: 157.4583,
   y: 180.9123
  }).wait(1).to({
   graphics: mask_graphics_314,
   x: 155.179,
   y: 180.908
  }).wait(1).to({
   graphics: mask_graphics_315,
   x: 153.3141,
   y: 180.9046
  }).wait(1).to({
   graphics: mask_graphics_316,
   x: 151.8637,
   y: 180.9019
  }).wait(1).to({
   graphics: mask_graphics_317,
   x: 150.8276,
   y: 180.8999
  }).wait(1).to({
   graphics: mask_graphics_318,
   x: 150.206,
   y: 180.8988
  }).wait(1).to({
   graphics: mask_graphics_319,
   x: 149.9988,
   y: 181.0029
  }).wait(55).to({
   graphics: mask_graphics_374,
   x: 252.4988,
   y: 181.0029
  }).wait(1).to({
   graphics: mask_graphics_375,
   x: 252.2465,
   y: 181.0034
  }).wait(1).to({
   graphics: mask_graphics_376,
   x: 251.4895,
   y: 181.0049
  }).wait(1).to({
   graphics: mask_graphics_377,
   x: 250.2279,
   y: 181.0074
  }).wait(1).to({
   graphics: mask_graphics_378,
   x: 248.4617,
   y: 181.011
  }).wait(1).to({
   graphics: mask_graphics_379,
   x: 246.1908,
   y: 181.0155
  }).wait(1).to({
   graphics: mask_graphics_380,
   x: 243.4153,
   y: 181.0211
  }).wait(1).to({
   graphics: mask_graphics_381,
   x: 240.1351,
   y: 181.0277
  }).wait(1).to({
   graphics: mask_graphics_382,
   x: 236.3503,
   y: 181.0352
  }).wait(1).to({
   graphics: mask_graphics_383,
   x: 232.0609,
   y: 181.0438
  }).wait(1).to({
   graphics: mask_graphics_384,
   x: 227.2669,
   y: 181.0535
  }).wait(1).to({
   graphics: mask_graphics_385,
   x: 221.9681,
   y: 181.0641
  }).wait(1).to({
   graphics: mask_graphics_386,
   x: 216.1648,
   y: 181.0757
  }).wait(1).to({
   graphics: mask_graphics_387,
   x: 209.8568,
   y: 181.0884
  }).wait(1).to({
   graphics: mask_graphics_388,
   x: 203.0442,
   y: 180.9975
  }).wait(1).to({
   graphics: mask_graphics_389,
   x: 194.8043,
   y: 180.9855
  }).wait(1).to({
   graphics: mask_graphics_390,
   x: 187.0961,
   y: 180.9743
  }).wait(1).to({
   graphics: mask_graphics_391,
   x: 179.9194,
   y: 180.9638
  }).wait(1).to({
   graphics: mask_graphics_392,
   x: 173.2743,
   y: 180.9541
  }).wait(1).to({
   graphics: mask_graphics_393,
   x: 167.1609,
   y: 180.9452
  }).wait(1).to({
   graphics: mask_graphics_394,
   x: 161.579,
   y: 180.9371
  }).wait(1).to({
   graphics: mask_graphics_395,
   x: 156.5288,
   y: 180.9297
  }).wait(1).to({
   graphics: mask_graphics_396,
   x: 152.0101,
   y: 180.9232
  }).wait(1).to({
   graphics: mask_graphics_397,
   x: 148.0231,
   y: 180.9173
  }).wait(1).to({
   graphics: mask_graphics_398,
   x: 144.5677,
   y: 180.9123
  }).wait(1).to({
   graphics: mask_graphics_399,
   x: 141.6438,
   y: 180.908
  }).wait(1).to({
   graphics: mask_graphics_400,
   x: 139.2516,
   y: 180.9046
  }).wait(1).to({
   graphics: mask_graphics_401,
   x: 137.391,
   y: 180.9019
  }).wait(1).to({
   graphics: mask_graphics_402,
   x: 136.062,
   y: 180.8999
  }).wait(1).to({
   graphics: mask_graphics_403,
   x: 135.2646,
   y: 180.8988
  }).wait(1).to({
   graphics: mask_graphics_404,
   x: 134.9988,
   y: 181.0029
  }).wait(61));
  this.instance_17 = new lib.bg1_1();
  this.instance_17.parent = this;
  this.instance_17.setTransform(150, 351, 1, 1, 0, 0, 0, 150, 197);
  var maskedShapeInstanceList = [this.instance_17];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(104).to({
   alpha: 0
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(345));
  this.instance_18 = new lib.bg2_1();
  this.instance_18.parent = this;
  this.instance_18.setTransform(150, 351, 1, 1, 0, 0, 0, 150, 197);
  this.instance_18._off = true;
  var maskedShapeInstanceList = [this.instance_18];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(119).to({
   _off: false
  }, 0).wait(75).to({
   alpha: 0
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(255));
  this.instance_19 = new lib.bg3_1();
  this.instance_19.parent = this;
  this.instance_19.setTransform(150, 351, 1, 1, 0, 0, 0, 150, 197);
  this.instance_19._off = true;
  var maskedShapeInstanceList = [this.instance_19];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(209).to({
   _off: false
  }, 0).wait(65).to({
   alpha: 0
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(175));
  this.instance_20 = new lib.bg4_1();
  this.instance_20.parent = this;
  this.instance_20.setTransform(150, 351, 1, 1, 0, 0, 0, 150, 197);
  this.instance_20._off = true;
  var maskedShapeInstanceList = [this.instance_20];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_20).wait(289).to({
   _off: false
  }, 0).wait(70).to({
   alpha: 0
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(90));
  this.instance_21 = new lib.car_1();
  this.instance_21.parent = this;
  this.instance_21.setTransform(87.2, 271, 1, 1, 0, 0, 0, 120.2, 75);
  this.instance_21._off = true;
  var maskedShapeInstanceList = [this.instance_21];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_21).wait(374).to({
   _off: false
  }, 0).wait(91));
  this.instance_22 = new lib.bg1_1();
  this.instance_22.parent = this;
  this.instance_22.setTransform(150, 351, 1, 1, 0, 0, 0, 150, 197);
  this.instance_22._off = true;
  var maskedShapeInstanceList = [this.instance_22];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_22).wait(374).to({
   _off: false
  }, 0).wait(91));
  this.instance_23 = new lib.bg_01();
  this.instance_23.parent = this;
  this.instance_23.setTransform(120, 200, 1, 1, 0, 0, 0, 120, 200);
  this.timeline.addTween(cjs.Tween.get(this.instance_23).wait(465));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(-241, 0, 721, 400);
 (lib.toyota_240x400 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.content();
  this.instance.parent = this;
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));
  this.instance_1 = new lib.black_plate();
  this.instance_1.parent = this;
  this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(111, 200, 189, 200);
 lib.properties = {
  id: '1E4D562F91EE4B408F0AC49B20246D76',
  width: 240,
  height: 400,
  fps: 24,
  color: "#FFFFFF",
  opacity: 1.00,
  manifest: [{
   src: "bg1.jpg",
   id: "bg1"
  }, {
   src: "bg2.jpg",
   id: "bg2"
  }, {
   src: "bg3.jpg",
   id: "bg3"
  }, {
   src: "bg4.jpg",
   id: "bg4"
  }, {
   src: "car.png",
   id: "car"
  }, {
   src: "legal_01_d1.png",
   id: "legal_01_d1"
  }, ],
  preloads: []
 };
 (lib.Stage = function(canvas) {
  createjs.Stage.call(this, canvas);
 }).prototype = p = new createjs.Stage();
 p.setAutoPlay = function(autoPlay) {
  this.tickEnabled = autoPlay;
 }
 p.play = function() {
  this.tickEnabled = true;
  this.getChildAt(0).gotoAndPlay(this.getTimelinePosition())
 }
 p.stop = function(ms) {
  if (ms) this.seek(ms);
  this.tickEnabled = false;
 }
 p.seek = function(ms) {
  this.tickEnabled = true;
  this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000);
 }
 p.getDuration = function() {
  return this.getChildAt(0).totalFrames / lib.properties.fps * 1000;
 }
 p.getTimelinePosition = function() {
  return this.getChildAt(0).currentFrame / lib.properties.fps * 1000;
 }
 an.bootcompsLoaded = an.bootcompsLoaded || [];
 if (!an.bootstrapListeners) {
  an.bootstrapListeners = [];
 }
 an.bootstrapCallback = function(fnCallback) {
  an.bootstrapListeners.push(fnCallback);
  if (an.bootcompsLoaded.length > 0) {
   for (var i = 0; i < an.bootcompsLoaded.length; ++i) {
    fnCallback(an.bootcompsLoaded[i]);
   }
  }
 };
 an.compositions = an.compositions || {};
 an.compositions['1E4D562F91EE4B408F0AC49B20246D76'] = {
  getStage: function() {
   return exportRoot.getStage();
  },
  getLibrary: function() {
   return lib;
  },
  getSpriteSheet: function() {
   return ss;
  },
  getImages: function() {
   return img;
  }
 };
 an.compositionLoaded = function(id) {
  an.bootcompsLoaded.push(id);
  for (var j = 0; j < an.bootstrapListeners.length; j++) {
   an.bootstrapListeners[j](id);
  }
 }
 an.getComposition = function(id) {
  return an.compositions[id];
 }
 an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {
  var lastW, lastH, lastS = 1;
  window.addEventListener('resize', resizeCanvas);
  resizeCanvas();

  function resizeCanvas() {
   var w = lib.properties.width,
    h = lib.properties.height;
   var iw = window.innerWidth,
    ih = window.innerHeight;
   var pRatio = window.devicePixelRatio || 1,
    xRatio = iw / w,
    yRatio = ih / h,
    sRatio = 1;
   if (isResp) {
    if ((respDim == 'width' && lastW == iw) || (respDim == 'height' && lastH == ih)) {
     sRatio = lastS;
    } else if (!isScale) {
     if (iw < w || ih < h) sRatio = Math.min(xRatio, yRatio);
    } else if (scaleType == 1) {
     sRatio = Math.min(xRatio, yRatio);
    } else if (scaleType == 2) {
     sRatio = Math.max(xRatio, yRatio);
    }
   }
   domContainers[0].width = w * pRatio * sRatio;
   domContainers[0].height = h * pRatio * sRatio;
   domContainers.forEach(function(container) {
    container.style.width = w * sRatio + 'px';
    container.style.height = h * sRatio + 'px';
   });
   stage.scaleX = pRatio * sRatio;
   stage.scaleY = pRatio * sRatio;
   lastW = iw;
   lastH = ih;
   lastS = sRatio;
   stage.tickOnUpdate = false;
   stage.update();
   stage.tickOnUpdate = true;
  }
 }
})(createjs = createjs || {}, AdobeAn = AdobeAn || {});
var createjs, AdobeAn;