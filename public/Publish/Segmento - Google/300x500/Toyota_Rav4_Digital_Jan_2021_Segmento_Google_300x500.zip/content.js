(function(cjs, an) {
 var p;
 var lib = {};
 var ss = {};
 var img = {};
 lib.ssMetadata = [];
 (lib.bg1 = function() {
  this.initialize(img.bg1);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 375, 391);
 (lib.bg2 = function() {
  this.initialize(img.bg2);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 375, 391);
 (lib.bg3 = function() {
  this.initialize(img.bg3);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 375, 391);
 (lib.bg4 = function() {
  this.initialize(img.bg4);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 375, 391);
 (lib.car = function() {
  this.initialize(img.car);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 377, 230);

 function mc_symbol_clone() {
  var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
  clone.gotoAndStop(this.currentFrame);
  clone.paused = this.paused;
  clone.framerate = this.framerate;
  return clone;
 }

 function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
  var prototype = cjs.extend(symbol, cjs.MovieClip);
  prototype.clone = mc_symbol_clone;
  prototype.nominalBounds = nominalBounds;
  prototype.frameBounds = frameBounds;
  return prototype;
 }
 (lib.t06 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#FFFFFF").s().p("AgsBcIAAgkIgWAAIAAgQIAWAAIAAgSIgWAAIAAgRIAWAAIAAhgIAwAAQAfAAAQAPQAPAOABAbQAAAPgIAOQgHAMgNAIQgOAIgVAAIgcAAIAAASIAsAAIAAAQIgsAAIAAAkgAgYAFIAbAAQANAAAJgFQAKgEAGgJQAGgJAAgNQAAgPgGgIQgGgJgKgEQgJgDgNAAIgbAAg");
  this.shape.setTransform(180.675, 141.125);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#FFFFFF").s().p("AhAC/QgZgQgOgcQgPgdgFglQgGgmABgqQgBgpAGgmQAGglAOgeQAOgdAZgQQAagRAmAAQAnAAAaARQAZAQAOAdQAOAeAGAlQAGAmgBApQABAqgGAmQgGAlgOAdQgPAcgZAQQgZARgnAAQgnAAgZgRgAgyikQgUAPgLAZQgKAZgEAhQgDAgAAAjQgBAwAIApQAHAoAVAZQAWAYApABQAggBAUgOQAUgPAKgZQAKgZAEggQADggAAgjQABgwgIgpQgHgpgWgYQgVgZgqgBQgfAAgTAPg");
  this.shape_1.setTransform(156.5248, 129.325);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#FFFFFF").s().p("AhAC/QgZgQgOgcQgPgdgFglQgGgmABgqQgBgpAGgmQAGglAOgeQAOgdAZgQQAagRAmAAQAnAAAaARQAZAQAOAdQAOAeAGAlQAGAmgBApQABAqgGAmQgGAlgOAdQgPAcgZAQQgZARgnAAQgnAAgZgRgAgyikQgUAPgLAZQgKAZgEAhQgDAgAAAjQgBAwAIApQAHAoAVAZQAWAYApABQAggBAUgOQAUgPAKgZQAKgZAEggQADggAAgjQABgwgIgpQgHgpgWgYQgVgZgqgBQgfAAgTAPg");
  this.shape_2.setTransform(128.1748, 129.325);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#FFFFFF").s().p("AhLDKICrl3IjgAAIAAgcIEBAAIAAAVIisF+g");
  this.shape_3.setTransform(99.625, 129.325);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#FFFFFF").s().p("AhiC0QBHAAArgZQArgZAUgqQAVgpADgyQgRAZgcARQgcARgnAAQgkAAgbgRQgcgQgQgdQgPgdgBgnQABgkARgeQARgdAdgSQAdgSAmAAQAjAAAeATQAfAUATAmQASAmABA4QgBAwgLArQgMArgbAiQgbAigqATQgqATg+AAgAg2ikQgWANgNAYQgNAXAAAeQAAAvAbAbQAaAdArAAQAlAAAegVQAdgTAOghQgCgtgPgdQgPgegWgPQgYgPgbAAQgfAAgWAOg");
  this.shape_4.setTransform(60.45, 129.125);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#FFFFFF").s().p("AAsBPIAAgeIhjAAIAAh/IANAAIAABzIBGAAIAAhzIAOAAIAABzIAOAAIAAAqg");
  this.shape_5.setTransform(277.025, 145.1);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#FFFFFF").s().p("AAfBAIAAg2IgYAAIgBAAIgCAAIggA2IgQAAIAkg4QgLgEgGgJQgGgJAAgMQAAgRALgKQAKgKASAAIAkAAIAAB/gAgDgwQgHACgDAFQgFAGAAAJQABAJADAGQAEAGAGADQAFACAHAAIAXAAIAAgzIgWAAQgHAAgFADg");
  this.shape_6.setTransform(263.5, 143.6);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#FFFFFF").s().p("AgXA5QgOgIgJgPQgIgPAAgTQAAgTAIgOQAJgPAOgIQAPgJASAAQANAAALAEQAKAEAKAGIgGANQgHgGgKgEQgKgEgLAAQgOAAgMAHQgMAHgGALQgHAMAAAPQAAAPAHAMQAHAMALAHQANAHANAAQANAAAKgEQALgEAHgHIAEANQgKAHgKAEQgMAEgNAAQgSgBgPgIg");
  this.shape_7.setTransform(252.4, 143.625);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#FFFFFF").s().p("AgjBAIAAh/IBFAAIAAAMIg3AAIAAAuIA2AAIAAALIg2AAIAAAuIA5AAIAAAMg");
  this.shape_8.setTransform(240.975, 143.6);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#FFFFFF").s().p("AAuBAIAAhrIgqA8IgIAAIgog8IAABrIgOAAIAAh/IAPAAIArBBIAshBIAPAAIAAB/g");
  this.shape_9.setTransform(228.1, 143.6);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.f("#FFFFFF").s().p("AgoBAIAAh/IAjAAQARAAALAJQAKAJAAAPQAAAIgEAHQgEAIgKAFQAMACAHAIQAHAIAAAMQAAALgFAIQgEAIgJAFQgJAEgMAAgAgbA0IAbAAQAOAAAGgHQAHgGABgMQgBgKgGgGQgHgGgLABIgeAAgAgbgFIAYAAQAGgBAFgDQAGgDADgFQADgFAAgHQAAgKgHgGQgHgGgLAAIgWAAg");
  this.shape_10.setTransform(211.125, 143.6);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.f("#FFFFFF").s().p("AgjBTIA7ilIAMAAIg8Clg");
  this.shape_11.setTransform(197.3, 144.725);
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.f("#FFFFFF").s().p("AAqBAIgPgpIg1AAIgQApIgNAAIAxh/IANAAIAxB/gAAWALIgWg6IgWA6IAsAAg");
  this.shape_12.setTransform(34.5, 143.6);
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.f("#FFFFFF").s().p("AgaA8QgLgFgHgHIAHgLIAJAIQAFAEAIACQAGACAJABQAOgBAIgGQAKgHgBgMQABgNgMgGQgKgGgWAAIAAgLQAPAAAIgEQAKgDACgGQAEgFAAgGQgBgKgGgFQgIgGgMAAQgKAAgHAEQgJAEgGAFIgGgKQAHgGAKgFQAJgEANAAQAMAAAIAEQAJAEAFAHQAFAHAAAKQAAAMgIAIQgGAHgNADQAPACAJAHQAHAIABAOQAAALgGAJQgEAIgLAFQgKAFgOAAQgQAAgKgGg");
  this.shape_13.setTransform(23.6, 143.625);
  this.shape_14 = new cjs.Shape();
  this.shape_14.graphics.f("#FFFFFF").s().p("AAlA5IgNglIgvAAIgOAlIgMAAIAshxIALAAIAsBxgAAUAKIgUg0IgTA0IAnAAg");
  this.shape_14.setTransform(284.625, 176.975);
  this.shape_15 = new cjs.Shape();
  this.shape_15.graphics.f("#FFFFFF").s().p("AAfA5IAAhmIg9AAIAABmIgMAAIAAhxIBVAAIAABxg");
  this.shape_15.setTransform(273.875, 176.975);
  this.shape_16 = new cjs.Shape();
  this.shape_16.graphics.f("#FFFFFF").s().p("AgfA5IgIgCIADgLQADABADABIAIABQAHAAAEgEQAFgEAEgJIgthXIANAAIAlBLIAghLIANAAIgmBXIgIAPQgDAFgFAEQgGADgKAAIgJAAg");
  this.shape_16.setTransform(263.7, 177.05);
  this.shape_17 = new cjs.Shape();
  this.shape_17.graphics.f("#FFFFFF").s().p("AAbA5Igug0IgKAAIAAA0IgMAAIAAhxIAMAAIAAA0IAKAAIArg0IANAAIguA3IAzA6g");
  this.shape_17.setTransform(254.95, 176.975);
  this.shape_18 = new cjs.Shape();
  this.shape_18.graphics.f("#FFFFFF").s().p("AAqA5IAAhxIANAAIAABxgAg2A5IAAhxIAMAAIAAAxIAaAAQARAAAJAHQAJAJAAAOQAAAKgEAIQgEAHgIAFQgHAEgMAAgAgqAuIAXAAQAOAAAFgGQAGgFAAgMQABgKgHgGQgGgFgNAAIgXAAg");
  this.shape_18.setTransform(242.55, 176.975);
  this.shape_19 = new cjs.Shape();
  this.shape_19.graphics.f("#FFFFFF").s().p("AgjA5IAAhxIAfAAQAPAAAJAIQAJAIAAANQABAIgFAGQgDAHgJAEQAMACAFAHQAGAHABALQAAAJgFAIQgEAHgHAEQgJAEgKAAgAgXAuIAYAAQALAAAHgGQAFgGAAgKQAAgJgFgFQgHgFgJAAIgaAAgAgXgFIAUAAQAFAAAFgDQAGgDACgEQADgFAAgGQgBgJgFgFQgHgFgKAAIgSAAg");
  this.shape_19.setTransform(231.4, 176.975);
  this.shape_20 = new cjs.Shape();
  this.shape_20.graphics.f("#FFFFFF").s().p("AgdAzQgOgIgHgNQgIgNAAgRQAAgQAIgNQAHgNAOgIQANgHAQAAQARAAANAHQAOAIAHANQAIANAAAQQAAARgIANQgHANgOAIQgNAHgRAAQgQAAgNgHgAgXgoQgLAGgGALQgGAKAAANQAAAOAGAKQAGALALAGQAKAGANAAQAOAAAKgGQALgGAGgLQAGgKAAgOQAAgNgGgKQgGgLgLgGQgKgGgOAAQgNAAgKAGg");
  this.shape_20.setTransform(216.125, 176.975);
  this.shape_21 = new cjs.Shape();
  this.shape_21.graphics.f("#FFFFFF").s().p("AgeA5IAAhxIA9AAIAAALIgxAAIAABmg");
  this.shape_21.setTransform(206.225, 176.975);
  this.shape_22 = new cjs.Shape();
  this.shape_22.graphics.f("#FFFFFF").s().p("AgdAzQgOgIgHgNQgIgNAAgRQAAgQAIgNQAHgNAOgIQANgHAQAAQARAAANAHQAOAIAHANQAIANAAAQQAAARgIANQgHANgOAIQgNAHgRAAQgQAAgNgHgAgXgoQgLAGgGALQgGAKAAANQAAAOAGAKQAGALALAGQAKAGANAAQAOAAAKgGQALgGAGgLQAGgKAAgOQAAgNgGgKQgGgLgLgGQgKgGgOAAQgNAAgKAGg");
  this.shape_22.setTransform(195.075, 176.975);
  this.shape_23 = new cjs.Shape();
  this.shape_23.graphics.f("#FFFFFF").s().p("AAgA5IAAg0Ig/AAIAAA0IgMAAIAAhxIAMAAIAAAzIA/AAIAAgzIAMAAIAABxg");
  this.shape_23.setTransform(182.625, 176.975);
  this.shape_24 = new cjs.Shape();
  this.shape_24.graphics.f("#FFFFFF").s().p("AgFA5IAAhmIggAAIAAgLIBLAAIAAALIggAAIAABmg");
  this.shape_24.setTransform(172.975, 176.975);
  this.shape_25 = new cjs.Shape();
  this.shape_25.graphics.f("#FFFFFF").s().p("AAlA5IgNglIgvAAIgOAlIgMAAIAshxIALAAIAsBxgAAUAKIgUg0IgTA0IAnAAg");
  this.shape_25.setTransform(164.075, 176.975);
  this.shape_26 = new cjs.Shape();
  this.shape_26.graphics.f("#FFFFFF").s().p("AgiA5IAAhxIAgAAQALAAAIAFQAJAEAFAIQAEAHAAALQAAAKgEAIQgFAHgJAFQgIAFgLAAIgUAAIAAArgAgWAEIASAAQAHAAAGgDQAGgCADgGQAFgGAAgIQAAgJgFgFQgDgGgGgCQgGgCgHAAIgSAAg");
  this.shape_26.setTransform(155.15, 176.975);
  this.shape_27 = new cjs.Shape();
  this.shape_27.graphics.f("#FFFFFF").s().p("AgkA5IAAhxIA8AAIAAALIgwAAIAAAmIAYAAQATAAAJAHQAJAJAAAOQAAAKgEAIQgEAHgIAFQgIAEgNAAgAgYAuIAXAAQAMAAAHgGQAGgFAAgMQABgKgIgGQgGgFgMAAIgXAAg");
  this.shape_27.setTransform(146.15, 176.975);
  this.shape_28 = new cjs.Shape();
  this.shape_28.graphics.f("#FFFFFF").s().p("AgdAzQgOgIgHgNQgIgNAAgRQAAgQAIgNQAHgNAOgIQANgHAQAAQARAAANAHQAOAIAHANQAIANAAAQQAAARgIANQgHANgOAIQgNAHgRAAQgQAAgNgHgAgXgoQgLAGgGALQgGAKAAANQAAAOAGAKQAGALALAGQAKAGANAAQAOAAAKgGQALgGAGgLQAGgKAAgOQAAgNgGgKQgGgLgLgGQgKgGgOAAQgNAAgKAGg");
  this.shape_28.setTransform(134.425, 176.975);
  this.shape_29 = new cjs.Shape();
  this.shape_29.graphics.f("#FFFFFF").s().p("AAiBHIAAheIhDBeIgMAAIAAhwIANAAIAABeIBCheIALAAIAABwgAgRg5QgGgEAAgJIAJAAQAAAFAEADQAFACAFAAQAHAAAEgDQAEgCABgFIAIAAQgBAJgGAEQgHAFgKAAQgKAAgHgFg");
  this.shape_29.setTransform(118.25, 175.525);
  this.shape_30 = new cjs.Shape();
  this.shape_30.graphics.f("#FFFFFF").s().p("AgfA5IAAhxIA+AAIAAALIgyAAIAAAoIAwAAIAAAKIgwAAIAAApIAzAAIAAALg");
  this.shape_30.setTransform(108.225, 176.975);
  this.shape_31 = new cjs.Shape();
  this.shape_31.graphics.f("#FFFFFF").s().p("AAiA5IAAheIhDBeIgMAAIAAhxIAMAAIAABeIBEheIAKAAIAABxg");
  this.shape_31.setTransform(97.8, 176.975);
  this.shape_32 = new cjs.Shape();
  this.shape_32.graphics.f("#FFFFFF").s().p("AgFA5IAAhmIggAAIAAgLIBLAAIAAALIggAAIAABmg");
  this.shape_32.setTransform(88.025, 176.975);
  this.shape_33 = new cjs.Shape();
  this.shape_33.graphics.f("#FFFFFF").s().p("AAgA5IAAg0Ig/AAIAAA0IgMAAIAAhxIAMAAIAAAzIA/AAIAAgzIAMAAIAABxg");
  this.shape_33.setTransform(78.375, 176.975);
  this.shape_34 = new cjs.Shape();
  this.shape_34.graphics.f("#FFFFFF").s().p("AAlA5IgNglIgvAAIgOAlIgMAAIAshxIALAAIAsBxgAAUAKIgUg0IgTA0IAnAAg");
  this.shape_34.setTransform(67.575, 176.975);
  this.shape_35 = new cjs.Shape();
  this.shape_35.graphics.f("#FFFFFF").s().p("AgiA5IAAhxIAgAAQALAAAIAFQAJAEAFAIQAEAHAAALQAAAKgEAIQgFAHgJAFQgIAFgLAAIgUAAIAAArgAgWAEIASAAQAHAAAGgDQAGgCADgGQAFgGAAgIQAAgJgFgFQgDgGgGgCQgGgCgHAAIgSAAg");
  this.shape_35.setTransform(58.65, 176.975);
  this.shape_36 = new cjs.Shape();
  this.shape_36.graphics.f("#FFFFFF").s().p("AAlA5IgNglIgvAAIgOAlIgMAAIAshxIALAAIAsBxgAAUAKIgUg0IgTA0IAnAAg");
  this.shape_36.setTransform(48.775, 176.975);
  this.shape_37 = new cjs.Shape();
  this.shape_37.graphics.f("#FFFFFF").s().p("AgeA5IAAhxIA9AAIAAALIgxAAIAABmg");
  this.shape_37.setTransform(40.525, 176.975);
  this.shape_38 = new cjs.Shape();
  this.shape_38.graphics.f("#FFFFFF").s().p("AgUAzQgNgIgIgNQgHgNAAgRQAAgQAIgOQAHgNANgHQAOgHAQAAQALAAAJADQAKADAIAGIgFAMQgGgGgJgEQgJgDgJAAQgNAAgKAGQgLAGgGALQgGAKAAANQAAANAGALQAGALALAGQAKAGANAAQALAAAJgEQAJgDAHgGIADALQgIAHgKADQgKADgMAAQgQAAgNgHg");
  this.shape_38.setTransform(23.475, 176.975);
  this.shape_39 = new cjs.Shape();
  this.shape_39.graphics.f("#FFFFFF").s().p("AgFA5IAAhmIggAAIAAgLIBLAAIAAALIggAAIAABmg");
  this.shape_39.setTransform(85.675, 88.975);
  this.shape_40 = new cjs.Shape();
  this.shape_40.graphics.f("#FFFFFF").s().p("AAiA5IAAheIhDBeIgMAAIAAhxIANAAIAABeIBCheIAMAAIAABxg");
  this.shape_40.setTransform(75.6, 88.975);
  this.shape_41 = new cjs.Shape();
  this.shape_41.graphics.f("#FFFFFF").s().p("AAoBGIAAgaIhPAAIAAAaIgLAAIAAgmIAHAAQADAAADgDQADgEACgFIADgPIAIhKIA7AAIAABlIANAAIAAAmgAgRAGQgBALgDAHQgCAGgDACIA0AAIAAhaIgkAAg");
  this.shape_41.setTransform(64.1, 90.3);
  this.shape_42 = new cjs.Shape();
  this.shape_42.graphics.f("#FFFFFF").s().p("AgfA5IAAhxIA+AAIAAALIgyAAIAAAoIAwAAIAAAKIgwAAIAAApIAzAAIAAALg");
  this.shape_42.setTransform(54.725, 88.975);
  this.shape_43 = new cjs.Shape();
  this.shape_43.graphics.f("#FFFFFF").s().p("AgiA5IAAhxIAfAAQAMAAAJAFQAIAEAEAIQAFAHAAALQAAAKgFAIQgEAHgIAFQgJAFgMAAIgTAAIAAArgAgWAEIASAAQAHAAAGgDQAGgCAEgGQADgGAAgIQAAgJgDgFQgEgGgGgCQgGgCgHAAIgSAAg");
  this.shape_43.setTransform(46, 88.975);
  this.shape_44 = new cjs.Shape();
  this.shape_44.graphics.f("#FFFFFF").s().p("AAbA5Igtg0IgLAAIAAA0IgMAAIAAhxIAMAAIAAA0IAKAAIArg0IANAAIguA3IAzA6g");
  this.shape_44.setTransform(36.85, 88.975);
  this.shape_45 = new cjs.Shape();
  this.shape_45.graphics.f("#FFFFFF").s().p("AgjA5IAAhxIAfAAQAPAAAJAIQAJAIAAANQABAIgEAGQgEAHgJAEQAMACAFAHQAHAHAAALQAAAJgFAIQgEAHgIAEQgHAEgMAAgAgYAuIAZAAQALAAAHgGQAFgGABgKQgBgJgFgFQgHgFgKAAIgaAAgAgYgFIAVAAQAFAAAGgDQAFgDACgEQACgFABgGQAAgJgHgFQgFgFgLAAIgTAAg");
  this.shape_45.setTransform(22.8, 88.975);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_45
   }, {
    t: this.shape_44
   }, {
    t: this.shape_43
   }, {
    t: this.shape_42
   }, {
    t: this.shape_41
   }, {
    t: this.shape_40
   }, {
    t: this.shape_39
   }, {
    t: this.shape_38
   }, {
    t: this.shape_37
   }, {
    t: this.shape_36
   }, {
    t: this.shape_35
   }, {
    t: this.shape_34
   }, {
    t: this.shape_33
   }, {
    t: this.shape_32
   }, {
    t: this.shape_31
   }, {
    t: this.shape_30
   }, {
    t: this.shape_29
   }, {
    t: this.shape_28
   }, {
    t: this.shape_27
   }, {
    t: this.shape_26
   }, {
    t: this.shape_25
   }, {
    t: this.shape_24
   }, {
    t: this.shape_23
   }, {
    t: this.shape_22
   }, {
    t: this.shape_21
   }, {
    t: this.shape_20
   }, {
    t: this.shape_19
   }, {
    t: this.shape_18
   }, {
    t: this.shape_17
   }, {
    t: this.shape_16
   }, {
    t: this.shape_15
   }, {
    t: this.shape_14
   }, {
    t: this.shape_13
   }, {
    t: this.shape_12
   }, {
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
 }).prototype = getMCSymbolPrototype(lib.t06, new cjs.Rectangle(15.5, 74, 279.5, 114.80000000000001), null);
 (lib.t05 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#FFFFFF").s().p("AAsBDIgQgrIg3AAIgRArIgOAAIA0iGIANAAIA0CGgAAYAMIgYg+IgXA+IAvAAg");
  this.shape.setTransform(196.125, 128.55);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#FFFFFF").s().p("AgwBDIgEgBIACgNIAEABIAFABQAFAAADgEQADgEAAgJIAKhpIBKAAIAACGIgPAAIAAh5IguAAIgJBgQgBANgGAGQgGAHgLAAIgIgBg");
  this.shape_1.setTransform(182.8, 128.625);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#FFFFFF").s().p("AAgBDIg2g9IgMAAIAAA9IgPAAIAAiFIAPAAIAAA8IALAAIAzg8IARAAIg4BBIA9BEg");
  this.shape_2.setTransform(172.65, 128.575);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#FFFFFF").s().p("AglBDIAAiGIBJAAIAAAOIg6AAIAAAvIA5AAIAAAMIg5AAIAAAxIA8AAIAAAMg");
  this.shape_3.setTransform(160.725, 128.55);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#FFFFFF").s().p("AgGBDIAAh4IgmAAIAAgOIBZAAIAAAOIgmAAIAAB4g");
  this.shape_4.setTransform(150.375, 128.55);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#FFFFFF").s().p("AgYA9QgPgKgJgPQgKgQABgUQgBgUAKgPQAIgPARgKQAPgIAUgBQANABALAEQAMADAJAIIgGANQgHgHgLgEQgKgDgLAAQgQAAgMAGQgMAIgIAMQgGANgBAPQABAQAGAMQAIANAMAHQAMAIAQAAQANAAAKgEQALgFAIgHIAFAOQgLAIgMADQgLAEgOABQgTgBgQgIg");
  this.shape_5.setTransform(138.95, 128.55);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#FFFFFF").s().p("AgjA9QgQgKgJgPQgJgPAAgVQAAgUAJgPQAJgPAQgKQAQgIATgBQAUABAQAJQAQAIAJAQQAJAPAAAUQAAAUgJAQQgJAPgQAKQgQAIgUABQgTgBgQgIgAgcgwQgMAIgHANQgIAMAAAPQAAAQAIAMQAHANAMAHQANAIAPAAQAQAAANgIQAMgHAHgNQAIgMAAgQQAAgPgIgMQgHgNgMgIQgNgHgQAAQgPAAgNAHg");
  this.shape_6.setTransform(119.225, 128.55);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#FFFFFF").s().p("AgkBDIAAiGIBJAAIAAAOIg7AAIAAB4g");
  this.shape_7.setTransform(107.025, 128.55);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#FFFFFF").s().p("AgjA9QgQgKgJgPQgJgPAAgVQAAgUAJgPQAJgPAQgKQAQgIATgBQAUABAQAJQAQAIAJAQQAJAPAAAUQAAAUgJAQQgJAPgQAKQgQAIgUABQgTgBgQgIgAgcgwQgMAIgHANQgIAMAAAPQAAAQAIAMQAHANAMAHQANAIAPAAQAQAAANgIQAMgHAHgNQAIgMAAgQQAAgPgIgMQgHgNgMgIQgNgHgQAAQgPAAgNAHg");
  this.shape_8.setTransform(93.375, 128.55);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#FFFFFF").s().p("AgrBDIAAiGIAmAAQASABALAJQALAKAAAPQAAAJgFAIQgEAIgKAFQANACAHAIQAHAJABAMQgBAMgFAIQgEAJgKAFQgJAEgNAAgAgcA3IAdAAQAOAAAGgHQAIgHAAgMQAAgLgHgHQgHgFgMgBIgfAAgAgcgGIAYAAQAHAAAGgDQAGgDADgGQADgGAAgHQAAgKgIgHQgGgGgNAAIgWAAg");
  this.shape_9.setTransform(79.95, 128.55);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.f("#FFFFFF").s().p("AgjA9QgQgKgJgPQgJgPAAgVQAAgUAJgPQAJgPAQgKQAQgIATgBQAUABAQAJQAQAIAJAQQAJAPAAAUQAAAUgJAQQgJAPgQAKQgQAIgUABQgTgBgQgIgAgcgwQgMAIgHANQgIAMAAAPQAAAQAIAMQAHANAMAHQANAIAPAAQAQAAANgIQAMgHAHgNQAIgMAAgQQAAgPgIgMQgHgNgMgIQgNgHgQAAQgPAAgNAHg");
  this.shape_10.setTransform(65.675, 128.55);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.f("#FFFFFF").s().p("AgrBDIAAiGIBHAAIAAAOIg5AAIAAAsIAdAAQAXAAAKAKQALAKAAARQAAAMgFAIQgFAJgJAGQgKAEgPAAgAgdA3IAcAAQAPAAAIgHQAHgHAAgNQAAgNgIgGQgIgGgOgBIgcAAg");
  this.shape_11.setTransform(52.45, 128.55);
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.f("#FFFFFF").s().p("AgjA9QgQgKgJgPQgJgPAAgVQAAgUAJgPQAJgPAQgKQAQgIATgBQAUABAQAJQAQAIAJAQQAJAPAAAUQAAAUgJAQQgJAPgQAKQgQAIgUABQgTgBgQgIgAgcgwQgMAIgHANQgIAMAAAPQAAAQAIAMQAHANAMAHQANAIAPAAQAQAAANgIQAMgHAHgNQAIgMAAgQQAAgPgIgMQgHgNgMgIQgNgHgQAAQgPAAgNAHg");
  this.shape_12.setTransform(38.125, 128.55);
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.f("#FFFFFF").s().p("AgwBDIgFgBIADgNIAEABIAFABQAFAAADgEQACgEABgJIAKhpIBJAAIAACGIgOAAIAAh5IguAAIgKBgQAAANgGAGQgFAHgMAAIgIgBg");
  this.shape_13.setTransform(22.85, 128.625);
  this.shape_14 = new cjs.Shape();
  this.shape_14.graphics.f("#FFFFFF").s().p("AAwBDIAAhxIgsBAIgJAAIgrhAIAABxIgNAAIAAiGIAQAAIAtBFIAvhFIAQAAIAACGg");
  this.shape_14.setTransform(231.5, 99.45);
  this.shape_15 = new cjs.Shape();
  this.shape_15.graphics.f("#FFFFFF").s().p("AgjA8QgQgIgJgQQgJgPAAgVQAAgUAJgPQAJgQAQgIQAQgJATAAQAUAAAQAJQAQAJAJAPQAJAPAAAUQAAAUgJAQQgJAQgQAIQgQAKgUgBQgTABgQgKgAgcgwQgMAIgHAMQgIANAAAPQAAAQAIANQAHAMAMAIQANAGAPABQAQgBANgGQAMgIAHgMQAIgNAAgQQAAgPgIgNQgHgMgMgIQgNgHgQAAQgPAAgNAHg");
  this.shape_15.setTransform(215.325, 99.45);
  this.shape_16 = new cjs.Shape();
  this.shape_16.graphics.f("#FFFFFF").s().p("AgqBDIAAiGIAlAAQASABALAJQALAJAAAQQAAAJgFAIQgEAHgKAGQANACAHAIQAHAJABANQgBALgFAJQgEAIgKAEQgJAGgNgBgAgcA3IAdAAQAOAAAGgHQAIgHAAgMQAAgLgHgGQgHgGgMgBIgfAAgAgcgFIAYAAQAHgBAGgDQAGgEADgFQADgGAAgHQAAgKgIgHQgGgGgNAAIgWAAg");
  this.shape_16.setTransform(201.9, 99.45);
  this.shape_17 = new cjs.Shape();
  this.shape_17.graphics.f("#FFFFFF").s().p("AglBDIAAiGIBJAAIAAANIg6AAIAAAxIA5AAIAAALIg5AAIAAAxIA8AAIAAAMg");
  this.shape_17.setTransform(190.625, 99.45);
  this.shape_18 = new cjs.Shape();
  this.shape_18.graphics.f("#FFFFFF").s().p("AgpBDIAAiGIAmAAQAOABAKAFQAKAFAFAJQAGAJgBANQABAMgGAJQgFAJgKAGQgKAGgOAAIgXAAIAAAygAgaAFIAVAAQAJgBAHgDQAHgCAEgIQAFgGAAgKQAAgLgFgGQgEgHgHgCQgHgDgJAAIgVAAg");
  this.shape_18.setTransform(180.2, 99.45);
  this.shape_19 = new cjs.Shape();
  this.shape_19.graphics.f("#FFFFFF").s().p("AgkBDIAAiGIBJAAIAAANIg7AAIAAB5g");
  this.shape_19.setTransform(170.175, 99.45);
  this.shape_20 = new cjs.Shape();
  this.shape_20.graphics.f("#FFFFFF").s().p("AgjA8QgQgIgJgQQgJgPAAgVQAAgUAJgPQAJgQAQgIQAQgJATAAQAUAAAQAJQAQAJAJAPQAJAPAAAUQAAAUgJAQQgJAQgQAIQgQAKgUgBQgTABgQgKgAgcgwQgMAIgHAMQgIANAAAPQAAAQAIANQAHAMAMAIQANAGAPABQAQgBANgGQAMgIAHgMQAIgNAAgQQAAgPgIgNQgHgMgMgIQgNgHgQAAQgPAAgNAHg");
  this.shape_20.setTransform(156.525, 99.45);
  this.shape_21 = new cjs.Shape();
  this.shape_21.graphics.f("#FFFFFF").s().p("AgrBDIAAiGIBHAAIAAANIg5AAIAAAtIAeAAQAVABALAJQALAJAAASQAAAMgFAJQgFAJgJAEQgKAGgOgBgAgdA3IAdAAQAOAAAHgHQAIgHAAgNQAAgNgIgGQgIgGgNAAIgdAAg");
  this.shape_21.setTransform(143.3, 99.45);
  this.shape_22 = new cjs.Shape();
  this.shape_22.graphics.f("#FFFFFF").s().p("AgjA8QgQgIgJgQQgJgPAAgVQAAgUAJgPQAJgQAQgIQAQgJATAAQAUAAAQAJQAQAJAJAPQAJAPAAAUQAAAUgJAQQgJAQgQAIQgQAKgUgBQgTABgQgKgAgcgwQgMAIgHAMQgIANAAAPQAAAQAIANQAHAMAMAIQANAGAPABQAQgBANgGQAMgIAHgMQAIgNAAgQQAAgPgIgNQgHgMgMgIQgNgHgQAAQgPAAgNAHg");
  this.shape_22.setTransform(128.975, 99.45);
  this.shape_23 = new cjs.Shape();
  this.shape_23.graphics.f("#FFFFFF").s().p("AgjA8QgQgIgJgQQgJgPAAgVQAAgUAJgPQAJgQAQgIQAQgJATAAQAUAAAQAJQAQAJAJAPQAJAPAAAUQAAAUgJAQQgJAQgQAIQgQAKgUgBQgTABgQgKgAgcgwQgMAIgHAMQgIANAAAPQAAAQAIANQAHAMAMAIQANAGAPABQAQgBANgGQAMgIAHgMQAIgNAAgQQAAgPgIgNQgHgMgMgIQgNgHgQAAQgPAAgNAHg");
  this.shape_23.setTransform(112.725, 99.45);
  this.shape_24 = new cjs.Shape();
  this.shape_24.graphics.f("#FFFFFF").s().p("AgpBDIAAiGIAmAAQAOABAKAFQAKAFAFAJQAGAJgBANQABAMgGAJQgFAJgKAGQgKAGgOAAIgXAAIAAAygAgaAFIAVAAQAJgBAHgDQAHgCAEgIQAFgGAAgKQAAgLgFgGQgEgHgHgCQgHgDgJAAIgVAAg");
  this.shape_24.setTransform(99.75, 99.45);
  this.shape_25 = new cjs.Shape();
  this.shape_25.graphics.f("#FFFFFF").s().p("AgGBDIAAh5IgmAAIAAgNIBZAAIAAANIgmAAIAAB5g");
  this.shape_25.setTransform(89.025, 99.45);
  this.shape_26 = new cjs.Shape();
  this.shape_26.graphics.f("#FFFFFF").s().p("AAhBDIg3g9IgNAAIAAA9IgOAAIAAiFIAOAAIAAA8IAMAAIAzg8IAQAAIg3BBIA9BEg");
  this.shape_26.setTransform(79.25, 99.475);
  this.shape_27 = new cjs.Shape();
  this.shape_27.graphics.f("#FFFFFF").s().p("AglBDIAAiGIBJAAIAAANIg6AAIAAAxIA5AAIAAALIg5AAIAAAxIA8AAIAAAMg");
  this.shape_27.setTransform(67.325, 99.45);
  this.shape_28 = new cjs.Shape();
  this.shape_28.graphics.f("#FFFFFF").s().p("AgvBDIgGgBIADgNIAEABIAFABQAFAAACgEQAEgEAAgJIAKhpIBJAAIAACGIgOAAIAAh5IguAAIgKBgQgBANgFAGQgFAHgMAAIgHgBg");
  this.shape_28.setTransform(54.6, 99.525);
  this.shape_29 = new cjs.Shape();
  this.shape_29.graphics.f("#FFFFFF").s().p("AgjBCQgMgFgKgHIAEgNQAIAGALAFQALAEAOAAQAOAAALgGQAMgGAHgLQAHgLACgPIhKAAIAAgMIBKAAQgBgPgHgLQgHgLgMgHQgLgGgPAAQgMAAgLAEQgLAEgIAHIgEgNQAJgHALgFQAMgDAOAAQATAAAPAJQAQAIAJAQQAIAPABAUQgBAVgIAQQgKAPgPAIQgPAKgRgBQgQAAgMgDg");
  this.shape_29.setTransform(42.45, 99.45);
  this.shape_30 = new cjs.Shape();
  this.shape_30.graphics.f("#FFFFFF").s().p("AgYA8QgQgIgJgQQgIgQgBgUQABgTAIgQQAKgQAPgIQAQgJATAAQANAAAMADQALAFAJAGIgEAOQgIgHgLgDQgKgFgMAAQgPABgMAGQgMAIgHAMQgIANAAAPQAAAQAIANQAHAMAMAIQAMAGAPABQANAAALgFQALgEAIgHIAEAOQgKAHgLAFQgMADgOAAQgTABgQgKg");
  this.shape_30.setTransform(24.6, 99.45);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_30
   }, {
    t: this.shape_29
   }, {
    t: this.shape_28
   }, {
    t: this.shape_27
   }, {
    t: this.shape_26
   }, {
    t: this.shape_25
   }, {
    t: this.shape_24
   }, {
    t: this.shape_23
   }, {
    t: this.shape_22
   }, {
    t: this.shape_21
   }, {
    t: this.shape_20
   }, {
    t: this.shape_19
   }, {
    t: this.shape_18
   }, {
    t: this.shape_17
   }, {
    t: this.shape_16
   }, {
    t: this.shape_15
   }, {
    t: this.shape_14
   }, {
    t: this.shape_13
   }, {
    t: this.shape_12
   }, {
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
 }).prototype = getMCSymbolPrototype(lib.t05, new cjs.Rectangle(15.5, 82, 255.5, 60.19999999999999), null);
 (lib.t04 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#FFFFFF").s().p("AAsBDIgQgrIg3AAIgRArIgOAAIA0iGIANAAIA0CGgAAYAMIgYg+IgXA+IAvAAg");
  this.shape.setTransform(191.875, 128.55);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#FFFFFF").s().p("AgYA9QgPgKgKgPQgJgQABgUQgBgUAJgPQAKgPAQgKQAPgIAUgBQANABALAEQALADAKAIIgGANQgIgHgKgEQgKgDgLAAQgQAAgMAGQgMAIgIAMQgGANgBAPQABAQAGAMQAIANAMAHQAMAIAQAAQANAAAKgEQALgFAIgHIAEAOQgKAIgLADQgMAEgOABQgTgBgQgIg");
  this.shape_1.setTransform(179.1, 128.55);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#FFFFFF").s().p("AglBDIAAiGIBJAAIAAAOIg6AAIAAAvIA5AAIAAAMIg5AAIAAAxIA8AAIAAAMg");
  this.shape_2.setTransform(167.025, 128.55);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#FFFFFF").s().p("AgvBDIgGgBIADgNIAEABIAFABQAFAAACgEQADgEABgJIAKhpIBKAAIAACGIgPAAIAAh5IguAAIgJBgQgCANgFAGQgGAHgLAAIgHgBg");
  this.shape_3.setTransform(154.3, 128.625);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#FFFFFF").s().p("AgjA9QgQgKgJgPQgJgPAAgVQAAgUAJgPQAJgPAQgKQAQgIATgBQAUABAQAJQAQAIAJAQQAJAPAAAUQAAAUgJAQQgJAPgQAKQgQAIgUABQgTgBgQgIgAgcgwQgMAIgHANQgIAMAAAPQAAAQAIAMQAHANAMAHQANAIAPAAQAQAAANgIQAMgHAHgNQAIgMAAgQQAAgPgIgMQgHgNgMgIQgNgHgQAAQgPAAgNAHg");
  this.shape_4.setTransform(140.975, 128.55);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#FFFFFF").s().p("AAgBDIg2g9IgMAAIAAA9IgPAAIAAiFIAPAAIAAA8IALAAIAzg8IARAAIg4BBIA9BEg");
  this.shape_5.setTransform(127.9, 128.575);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#FFFFFF").s().p("AgjA9QgQgKgJgPQgJgPAAgVQAAgUAJgPQAJgPAQgKQAQgIATgBQAUABAQAJQAQAIAJAQQAJAPAAAUQAAAUgJAQQgJAPgQAKQgQAIgUABQgTgBgQgIgAgcgwQgMAIgHANQgIAMAAAPQAAAQAIAMQAHANAMAHQANAIAPAAQAQAAANgIQAMgHAHgNQAIgMAAgQQAAgPgIgMQgHgNgMgIQgNgHgQAAQgPAAgNAHg");
  this.shape_6.setTransform(108.325, 128.55);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#FFFFFF").s().p("AgkBDIAAiGIBJAAIAAAOIg7AAIAAB4g");
  this.shape_7.setTransform(96.125, 128.55);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#FFFFFF").s().p("AgjA9QgQgKgJgPQgJgPAAgVQAAgUAJgPQAJgPAQgKQAQgIATgBQAUABAQAJQAQAIAJAQQAJAPAAAUQAAAUgJAQQgJAPgQAKQgQAIgUABQgTgBgQgIgAgcgwQgMAIgHANQgIAMAAAPQAAAQAIAMQAHANAMAHQANAIAPAAQAQAAANgIQAMgHAHgNQAIgMAAgQQAAgPgIgMQgHgNgMgIQgNgHgQAAQgPAAgNAHg");
  this.shape_8.setTransform(82.475, 128.55);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#FFFFFF").s().p("AgqBDIAAiGIAlAAQASABALAJQALAKAAAPQgBAJgEAIQgEAIgKAFQANACAHAIQAHAJABAMQgBAMgEAIQgFAJgKAFQgJAEgNAAgAgcA3IAdAAQAOAAAGgHQAIgHAAgMQAAgLgHgHQgHgFgMgBIgfAAgAgcgGIAYAAQAHAAAGgDQAGgDADgGQADgGAAgHQAAgKgIgHQgGgGgNAAIgWAAg");
  this.shape_9.setTransform(69.05, 128.55);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.f("#FFFFFF").s().p("AglBDIAAiGIBJAAIAAAOIg6AAIAAAvIA5AAIAAAMIg5AAIAAAxIA8AAIAAAMg");
  this.shape_10.setTransform(57.775, 128.55);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.f("#FFFFFF").s().p("AgvBDIgGgBIADgNIAEABIAFABQAFAAACgEQADgEABgJIAKhpIBJAAIAACGIgOAAIAAh5IguAAIgKBgQgBANgFAGQgGAHgLAAIgHgBg");
  this.shape_11.setTransform(45.05, 128.625);
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.f("#FFFFFF").s().p("AgkBDIgKgDIAEgMIAHADIAJAAQAIAAAGgEQAFgFAEgKIg1hoIAQAAIArBZIAnhZIAPAAIguBoIgIARQgEAHgHAEQgGAFgLAAIgLgCg");
  this.shape_12.setTransform(34.275, 128.65);
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.f("#FFFFFF").s().p("AgpBDIAAiGIAmAAQAOAAAKAGQAKAFAFAJQAGAKgBAMQABALgGAKQgFAJgKAGQgKAGgOAAIgXAAIAAAygAgaAEIAVAAQAJABAHgEQAHgDAEgGQAFgHAAgKQAAgLgFgGQgEgHgHgCQgHgDgJAAIgVAAg");
  this.shape_13.setTransform(23.6, 128.55);
  this.shape_14 = new cjs.Shape();
  this.shape_14.graphics.f("#FFFFFF").s().p("AAwBDIAAhxIgsBAIgJAAIgrhAIAABxIgNAAIAAiGIAQAAIAtBFIAvhFIAQAAIAACGg");
  this.shape_14.setTransform(231.5, 99.45);
  this.shape_15 = new cjs.Shape();
  this.shape_15.graphics.f("#FFFFFF").s().p("AgjA8QgQgIgJgQQgJgPAAgVQAAgUAJgPQAJgQAQgIQAQgJATAAQAUAAAQAJQAQAJAJAPQAJAPAAAUQAAAUgJAQQgJAQgQAIQgQAKgUgBQgTABgQgKgAgcgwQgMAIgHAMQgIANAAAPQAAAQAIANQAHAMAMAIQANAGAPABQAQgBANgGQAMgIAHgMQAIgNAAgQQAAgPgIgNQgHgMgMgIQgNgHgQAAQgPAAgNAHg");
  this.shape_15.setTransform(215.325, 99.45);
  this.shape_16 = new cjs.Shape();
  this.shape_16.graphics.f("#FFFFFF").s().p("AgqBDIAAiGIAlAAQASABALAJQALAJAAAQQAAAJgFAIQgEAHgKAGQANACAHAIQAHAJABANQgBALgFAJQgEAIgKAEQgJAGgNgBgAgcA3IAdAAQAOAAAGgHQAIgHAAgMQAAgLgHgGQgHgGgMgBIgfAAgAgcgFIAYAAQAHgBAGgDQAGgEADgFQADgGAAgHQAAgKgIgHQgGgGgNAAIgWAAg");
  this.shape_16.setTransform(201.9, 99.45);
  this.shape_17 = new cjs.Shape();
  this.shape_17.graphics.f("#FFFFFF").s().p("AglBDIAAiGIBJAAIAAANIg6AAIAAAxIA5AAIAAALIg5AAIAAAxIA8AAIAAAMg");
  this.shape_17.setTransform(190.625, 99.45);
  this.shape_18 = new cjs.Shape();
  this.shape_18.graphics.f("#FFFFFF").s().p("AgpBDIAAiGIAmAAQAOABAKAFQAKAFAFAJQAGAJgBANQABAMgGAJQgFAJgKAGQgKAGgOAAIgXAAIAAAygAgaAFIAVAAQAJgBAHgDQAHgCAEgIQAFgGAAgKQAAgLgFgGQgEgHgHgCQgHgDgJAAIgVAAg");
  this.shape_18.setTransform(180.2, 99.45);
  this.shape_19 = new cjs.Shape();
  this.shape_19.graphics.f("#FFFFFF").s().p("AgkBDIAAiGIBJAAIAAANIg7AAIAAB5g");
  this.shape_19.setTransform(170.175, 99.45);
  this.shape_20 = new cjs.Shape();
  this.shape_20.graphics.f("#FFFFFF").s().p("AgjA8QgQgIgJgQQgJgPAAgVQAAgUAJgPQAJgQAQgIQAQgJATAAQAUAAAQAJQAQAJAJAPQAJAPAAAUQAAAUgJAQQgJAQgQAIQgQAKgUgBQgTABgQgKgAgcgwQgMAIgHAMQgIANAAAPQAAAQAIANQAHAMAMAIQANAGAPABQAQgBANgGQAMgIAHgMQAIgNAAgQQAAgPgIgNQgHgMgMgIQgNgHgQAAQgPAAgNAHg");
  this.shape_20.setTransform(156.525, 99.45);
  this.shape_21 = new cjs.Shape();
  this.shape_21.graphics.f("#FFFFFF").s().p("AgrBDIAAiGIBHAAIAAANIg5AAIAAAtIAeAAQAVABALAJQALAJAAASQAAAMgFAJQgFAJgJAEQgKAGgOgBgAgdA3IAdAAQAOAAAHgHQAIgHAAgNQAAgNgIgGQgIgGgNAAIgdAAg");
  this.shape_21.setTransform(143.3, 99.45);
  this.shape_22 = new cjs.Shape();
  this.shape_22.graphics.f("#FFFFFF").s().p("AgjA8QgQgIgJgQQgJgPAAgVQAAgUAJgPQAJgQAQgIQAQgJATAAQAUAAAQAJQAQAJAJAPQAJAPAAAUQAAAUgJAQQgJAQgQAIQgQAKgUgBQgTABgQgKgAgcgwQgMAIgHAMQgIANAAAPQAAAQAIANQAHAMAMAIQANAGAPABQAQgBANgGQAMgIAHgMQAIgNAAgQQAAgPgIgNQgHgMgMgIQgNgHgQAAQgPAAgNAHg");
  this.shape_22.setTransform(128.975, 99.45);
  this.shape_23 = new cjs.Shape();
  this.shape_23.graphics.f("#FFFFFF").s().p("AgjA8QgQgIgJgQQgJgPAAgVQAAgUAJgPQAJgQAQgIQAQgJATAAQAUAAAQAJQAQAJAJAPQAJAPAAAUQAAAUgJAQQgJAQgQAIQgQAKgUgBQgTABgQgKgAgcgwQgMAIgHAMQgIANAAAPQAAAQAIANQAHAMAMAIQANAGAPABQAQgBANgGQAMgIAHgMQAIgNAAgQQAAgPgIgNQgHgMgMgIQgNgHgQAAQgPAAgNAHg");
  this.shape_23.setTransform(112.725, 99.45);
  this.shape_24 = new cjs.Shape();
  this.shape_24.graphics.f("#FFFFFF").s().p("AgpBDIAAiGIAmAAQAOABAKAFQAKAFAFAJQAGAJgBANQABAMgGAJQgFAJgKAGQgKAGgOAAIgXAAIAAAygAgaAFIAVAAQAJgBAHgDQAHgCAEgIQAFgGAAgKQAAgLgFgGQgEgHgHgCQgHgDgJAAIgVAAg");
  this.shape_24.setTransform(99.75, 99.45);
  this.shape_25 = new cjs.Shape();
  this.shape_25.graphics.f("#FFFFFF").s().p("AgGBDIAAh5IgmAAIAAgNIBZAAIAAANIgmAAIAAB5g");
  this.shape_25.setTransform(89.025, 99.45);
  this.shape_26 = new cjs.Shape();
  this.shape_26.graphics.f("#FFFFFF").s().p("AAhBDIg3g9IgNAAIAAA9IgOAAIAAiFIAOAAIAAA8IAMAAIAzg8IAQAAIg3BBIA9BEg");
  this.shape_26.setTransform(79.25, 99.475);
  this.shape_27 = new cjs.Shape();
  this.shape_27.graphics.f("#FFFFFF").s().p("AglBDIAAiGIBJAAIAAANIg6AAIAAAxIA5AAIAAALIg5AAIAAAxIA8AAIAAAMg");
  this.shape_27.setTransform(67.325, 99.45);
  this.shape_28 = new cjs.Shape();
  this.shape_28.graphics.f("#FFFFFF").s().p("AgvBDIgGgBIADgNIAEABIAFABQAFAAACgEQAEgEAAgJIAKhpIBJAAIAACGIgOAAIAAh5IguAAIgKBgQgBANgFAGQgFAHgMAAIgHgBg");
  this.shape_28.setTransform(54.6, 99.525);
  this.shape_29 = new cjs.Shape();
  this.shape_29.graphics.f("#FFFFFF").s().p("AgjBCQgMgFgKgHIAEgNQAIAGALAFQALAEAOAAQAOAAALgGQAMgGAHgLQAHgLACgPIhKAAIAAgMIBKAAQgBgPgHgLQgHgLgMgHQgLgGgPAAQgMAAgLAEQgLAEgIAHIgEgNQAJgHALgFQAMgDAOAAQATAAAPAJQAQAIAJAQQAIAPABAUQgBAVgIAQQgKAPgPAIQgPAKgRgBQgQAAgMgDg");
  this.shape_29.setTransform(42.45, 99.45);
  this.shape_30 = new cjs.Shape();
  this.shape_30.graphics.f("#FFFFFF").s().p("AgYA8QgQgIgJgQQgIgQgBgUQABgTAIgQQAKgQAPgIQAQgJATAAQANAAAMADQALAFAJAGIgEAOQgIgHgLgDQgKgFgMAAQgPABgMAGQgMAIgHAMQgIANAAAPQAAAQAIANQAHAMAMAIQAMAGAPABQANAAALgFQALgEAIgHIAEAOQgKAHgLAFQgMADgOAAQgTABgQgKg");
  this.shape_30.setTransform(24.6, 99.45);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_30
   }, {
    t: this.shape_29
   }, {
    t: this.shape_28
   }, {
    t: this.shape_27
   }, {
    t: this.shape_26
   }, {
    t: this.shape_25
   }, {
    t: this.shape_24
   }, {
    t: this.shape_23
   }, {
    t: this.shape_22
   }, {
    t: this.shape_21
   }, {
    t: this.shape_20
   }, {
    t: this.shape_19
   }, {
    t: this.shape_18
   }, {
    t: this.shape_17
   }, {
    t: this.shape_16
   }, {
    t: this.shape_15
   }, {
    t: this.shape_14
   }, {
    t: this.shape_13
   }, {
    t: this.shape_12
   }, {
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
 }).prototype = getMCSymbolPrototype(lib.t04, new cjs.Rectangle(15.5, 82, 255.5, 60.19999999999999), null);
 (lib.t03 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#FFFFFF").s().p("AAsBEIgQgsIg3AAIgRAsIgOAAIA0iGIANAAIA0CGgAAYAMIgYg+IgXA+IAvAAg");
  this.shape.setTransform(152.625, 157.65);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#FFFFFF").s().p("AAwBTIAAgfIheAAIAAAfIgNAAIAAgsIAIAAQAEAAADgEQADgFADgHQACgHABgJIAKhZIBGAAIAAB5IAPAAIAAAsgAgVAHQgBANgDAJQgDAIgEACIA/AAIAAhsIgrAAg");
  this.shape_1.setTransform(140.025, 159.225);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#FFFFFF").s().p("AAhBEIAAg5IgaAAIgBAAIgCAAIghA5IgRAAIAlg8QgMgFgGgIQgGgKgBgNQABgSALgKQAMgKASAAIAnAAIAACGgAgEg0QgGADgEAGQgFAGAAAKQABAJADAHQAEAGAHADQAFACAHAAIAZAAIAAg2IgYAAQgHAAgGACg");
  this.shape_2.setTransform(127.6, 157.65);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#FFFFFF").s().p("AgpBEIAAiGIAmAAQAOgBAKAGQAKAFAFAJQAGAKgBAMQABALgGAKQgFAJgKAGQgKAGgOAAIgXAAIAAAzgAgaAFIAVAAQAJAAAHgEQAHgCAEgIQAFgGAAgKQAAgLgFgGQgEgHgHgCQgHgDgJAAIgVAAg");
  this.shape_3.setTransform(117.65, 157.65);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#FFFFFF").s().p("AgjA9QgQgKgJgPQgJgPAAgVQAAgUAJgPQAJgPAQgKQAQgIATgBQAUABAQAJQAQAJAJAPQAJAPAAAUQAAAUgJAQQgJAPgQAKQgQAJgUAAQgTAAgQgJgAgcgvQgMAGgHAOQgIAMAAAPQAAAQAIAMQAHANAMAIQANAGAPABQAQgBANgGQAMgIAHgNQAIgMAAgQQAAgPgIgMQgHgOgMgGQgNgIgQAAQgPAAgNAIg");
  this.shape_4.setTransform(99.125, 157.65);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#FFFFFF").s().p("AgkBEIAAiGIBJAAIAAAMIg7AAIAAB6g");
  this.shape_5.setTransform(87.025, 157.65);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#FFFFFF").s().p("AgjA9QgQgKgJgPQgJgPAAgVQAAgUAJgPQAJgPAQgKQAQgIATgBQAUABAQAJQAQAJAJAPQAJAPAAAUQAAAUgJAQQgJAPgQAKQgQAJgUAAQgTAAgQgJgAgcgvQgMAGgHAOQgIAMAAAPQAAAQAIAMQAHANAMAIQANAGAPABQAQgBANgGQAMgIAHgNQAIgMAAgQQAAgPgIgMQgHgOgMgGQgNgIgQAAQgPAAgNAIg");
  this.shape_6.setTransform(73.475, 157.65);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#FFFFFF").s().p("AgpBEIAAiGIAmAAQAOgBAKAGQAKAFAFAJQAGAKgBAMQABALgGAKQgFAJgKAGQgKAGgOAAIgXAAIAAAzgAgaAFIAVAAQAJAAAHgEQAHgCAEgIQAFgGAAgKQAAgLgFgGQgEgHgHgCQgHgDgJAAIgVAAg");
  this.shape_7.setTransform(60.6, 157.65);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#FFFFFF").s().p("AgjA9QgQgKgJgPQgJgPAAgVQAAgUAJgPQAJgPAQgKQAQgIATgBQAUABAQAJQAQAJAJAPQAJAPAAAUQAAAUgJAQQgJAPgQAKQgQAJgUAAQgTAAgQgJgAgcgvQgMAGgHAOQgIAMAAAPQAAAQAIAMQAHANAMAIQANAGAPABQAQgBANgGQAMgIAHgNQAIgMAAgQQAAgPgIgMQgHgOgMgGQgNgIgQAAQgPAAgNAIg");
  this.shape_8.setTransform(46.625, 157.65);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#FFFFFF").s().p("AgGBEIAAh6IgmAAIAAgMIBZAAIAAAMIgmAAIAAB6g");
  this.shape_9.setTransform(33.825, 157.65);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.f("#FFFFFF").s().p("AgrBEIAAiGIAmAAQASAAALAJQALAKAAAPQAAAJgFAIQgEAHgKAGQANACAHAIQAHAIABANQAAAMgGAJQgEAIgKAEQgJAFgNABgAgcA3IAdAAQAOAAAGgHQAIgHAAgMQAAgLgHgHQgHgFgMAAIgfAAgAgcgGIAYAAQAHAAAGgDQAGgEADgFQADgGAAgHQAAgLgIgFQgGgHgNAAIgWAAg");
  this.shape_10.setTransform(23.8, 157.65);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.f("#FFFFFF").s().p("AAhBDIAAg4IgaAAIgBAAIgCAAIghA4IgRAAIAlg7QgMgFgGgIQgGgKgBgNQABgRALgLQAMgKASgBIAnAAIAACGgAgEg0QgGADgEAGQgFAGAAAKQABAJADAGQAEAHAHACQAFADAHAAIAZAAIAAg2IgYAAQgHAAgGACg");
  this.shape_11.setTransform(225.25, 128.55);
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.f("#FFFFFF").s().p("AgvBDIgGgBIADgNIAEABIAFABQAFAAACgEQAEgEAAgJIAKhpIBJAAIAACGIgOAAIAAh5IguAAIgKBgQgBANgFAGQgFAHgMAAIgHgBg");
  this.shape_12.setTransform(213, 128.625);
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.f("#FFFFFF").s().p("AAwBTIAAgfIheAAIAAAfIgNAAIAAgsIAIAAQAEAAADgEQADgFADgHQACgHABgJIAKhZIBGAAIAAB5IAPAAIAAAsgAgVAHQgBANgDAJQgDAIgEACIA/AAIAAhsIgrAAg");
  this.shape_13.setTransform(201.375, 130.125);
  this.shape_14 = new cjs.Shape();
  this.shape_14.graphics.f("#FFFFFF").s().p("AAoBDIAAhvIhQBvIgNAAIAAiGIAOAAIAABwIBQhwIANAAIAACGg");
  this.shape_14.setTransform(183.625, 128.55);
  this.shape_15 = new cjs.Shape();
  this.shape_15.graphics.f("#FFFFFF").s().p("AAwBDIAAhwIgrA/IgJAAIgrg/IAABwIgPAAIAAiGIARAAIAtBFIAuhFIAQAAIAACGg");
  this.shape_15.setTransform(168.45, 128.55);
  this.shape_16 = new cjs.Shape();
  this.shape_16.graphics.f("#FFFFFF").s().p("AAsBDIgQgrIg3AAIgRArIgOAAIA0iGIANAAIA0CGgAAYAMIgYg+IgXA+IAvAAg");
  this.shape_16.setTransform(154.325, 128.55);
  this.shape_17 = new cjs.Shape();
  this.shape_17.graphics.f("#FFFFFF").s().p("AAwBTIAAgfIheAAIAAAfIgNAAIAAgsIAIAAQAEAAADgEQADgFADgHQACgHABgJIAKhZIBGAAIAAB5IAPAAIAAAsgAgVAHQgBANgDAJQgDAIgEACIA/AAIAAhsIgrAAg");
  this.shape_17.setTransform(141.725, 130.125);
  this.shape_18 = new cjs.Shape();
  this.shape_18.graphics.f("#FFFFFF").s().p("AgjA9QgQgKgJgPQgJgPAAgVQAAgUAJgPQAJgPAQgKQAQgIATgBQAUABAQAJQAQAIAJAQQAJAPAAAUQAAAUgJAQQgJAPgQAKQgQAIgUABQgTgBgQgIgAgcgwQgMAIgHANQgIAMAAAPQAAAQAIAMQAHANAMAHQANAIAPAAQAQAAANgIQAMgHAHgNQAIgMAAgQQAAgPgIgMQgHgNgMgIQgNgHgQAAQgPAAgNAHg");
  this.shape_18.setTransform(127.625, 128.55);
  this.shape_19 = new cjs.Shape();
  this.shape_19.graphics.f("#FFFFFF").s().p("AgqBDIAAiGIAlAAQATABAKAJQAKAKAAAPQAAAJgDAIQgFAIgKAFQANACAHAIQAHAJAAAMQAAAMgEAIQgGAJgJAFQgJAEgNAAgAgcA3IAdAAQANAAAIgHQAHgHAAgMQAAgLgHgHQgHgFgMgBIgfAAgAgcgGIAYAAQAHAAAGgDQAFgDAEgGQADgGAAgHQAAgKgHgHQgIgGgMAAIgWAAg");
  this.shape_19.setTransform(114.3, 128.55);
  this.shape_20 = new cjs.Shape();
  this.shape_20.graphics.f("#FFFFFF").s().p("AgjA9QgQgKgJgPQgJgPAAgVQAAgUAJgPQAJgPAQgKQAQgIATgBQAUABAQAJQAQAIAJAQQAJAPAAAUQAAAUgJAQQgJAPgQAKQgQAIgUABQgTgBgQgIgAgcgwQgMAIgHANQgIAMAAAPQAAAQAIAMQAHANAMAHQANAIAPAAQAQAAANgIQAMgHAHgNQAIgMAAgQQAAgPgIgMQgHgNgMgIQgNgHgQAAQgPAAgNAHg");
  this.shape_20.setTransform(100.125, 128.55);
  this.shape_21 = new cjs.Shape();
  this.shape_21.graphics.f("#FFFFFF").s().p("AAmBDIgmg5IgmA5IgPAAIAuhDIgthDIAQAAIAkA3IAmg3IAOAAIgtBDIAwBDg");
  this.shape_21.setTransform(86.05, 128.55);
  this.shape_22 = new cjs.Shape();
  this.shape_22.graphics.f("#FFFFFF").s().p("AgkBDIgKgDIAEgMIAHADIAJAAQAIAAAGgEQAFgFAEgKIg1hoIAQAAIArBZIAnhZIAPAAIguBoIgIARQgEAHgHAEQgGAFgLAAIgLgCg");
  this.shape_22.setTransform(74.275, 128.65);
  this.shape_23 = new cjs.Shape();
  this.shape_23.graphics.f("#FFFFFF").s().p("AAwBTIAAgfIheAAIAAAfIgNAAIAAgsIAIAAQAEAAADgEQADgFADgHQACgHABgJIAKhZIBGAAIAAB5IAPAAIAAAsgAgVAHQgBANgDAJQgDAIgEACIA/AAIAAhsIgrAAg");
  this.shape_23.setTransform(62.025, 130.125);
  this.shape_24 = new cjs.Shape();
  this.shape_24.graphics.f("#FFFFFF").s().p("AgcBAQgLgFgHgIIAHgMIAKAJQAFAEAIACQAHADAJgBQAPABAJgIQAJgGAAgOQAAgNgLgGQgMgHgWAAIAAgLQAPAAAJgEQAJgEAEgGQADgGAAgGQAAgKgIgGQgHgGgNABQgKAAgJADQgJAEgGAGIgGgLQAHgHALgEQAKgEANgBQAMABAKAEQAJAEAFAIQAFAHAAAKQAAANgIAIQgHAIgNADQAQACAJAIQAIAIAAAOQAAANgFAIQgGAKgKAEQgLAFgPABQgQAAgMgGg");
  this.shape_24.setTransform(50.375, 128.55);
  this.shape_25 = new cjs.Shape();
  this.shape_25.graphics.f("#FFFFFF").s().p("AgjA9QgQgKgJgPQgJgPAAgVQAAgUAJgPQAJgPAQgKQAQgIATgBQAUABAQAJQAQAIAJAQQAJAPAAAUQAAAUgJAQQgJAPgQAKQgQAIgUABQgTgBgQgIgAgcgwQgMAIgHANQgIAMAAAPQAAAQAIAMQAHANAMAHQANAIAPAAQAQAAANgIQAMgHAHgNQAIgMAAgQQAAgPgIgMQgHgNgMgIQgNgHgQAAQgPAAgNAHg");
  this.shape_25.setTransform(37.125, 128.55);
  this.shape_26 = new cjs.Shape();
  this.shape_26.graphics.f("#FFFFFF").s().p("AgrBDIAAiGIAmAAQASABALAJQALAKAAAPQAAAJgFAIQgEAIgKAFQANACAHAIQAHAJABAMQAAAMgGAIQgEAJgKAFQgJAEgNAAgAgcA3IAdAAQAOAAAGgHQAIgHAAgMQAAgLgHgHQgHgFgMgBIgfAAgAgcgGIAYAAQAHAAAGgDQAGgDADgGQADgGAAgHQAAgKgIgHQgGgGgNAAIgWAAg");
  this.shape_26.setTransform(23.8, 128.55);
  this.shape_27 = new cjs.Shape();
  this.shape_27.graphics.f("#FFFFFF").s().p("AAoBDIAAhvIhQBvIgNAAIAAiGIAOAAIAABwIBQhwIANAAIAACGg");
  this.shape_27.setTransform(232.225, 99.45);
  this.shape_28 = new cjs.Shape();
  this.shape_28.graphics.f("#FFFFFF").s().p("AAwBDIAAhxIgrBAIgJAAIgrhAIAABxIgPAAIAAiGIARAAIAtBFIAuhFIAQAAIAACGg");
  this.shape_28.setTransform(217.05, 99.45);
  this.shape_29 = new cjs.Shape();
  this.shape_29.graphics.f("#FFFFFF").s().p("AAzBDIAAiGIAOAAIAACGgAhABDIAAiGIAOAAIAAA6IAeAAQAVABALAJQALAJAAASQAAAMgFAJQgFAJgJAEQgJAGgPgBgAgyA3IAcAAQAQAAAGgHQAIgHAAgNQAAgNgIgGQgHgGgPAAIgcAAg");
  this.shape_29.setTransform(200.775, 99.45);
  this.shape_30 = new cjs.Shape();
  this.shape_30.graphics.f("#FFFFFF").s().p("AAmBDIAAg9IhLAAIAAA9IgOAAIAAiGIAOAAIAAA+IBLAAIAAg+IAOAAIAACGg");
  this.shape_30.setTransform(185.5, 99.45);
  this.shape_31 = new cjs.Shape();
  this.shape_31.graphics.f("#FFFFFF").s().p("AgrBDIAAiGIAOAAIAAA6IAeAAQAVABALAJQALAJAAASQAAAMgFAJQgFAJgJAEQgKAGgOgBgAgdA3IAdAAQAOAAAHgHQAIgHAAgNQAAgNgIgGQgIgGgNAAIgdAAg");
  this.shape_31.setTransform(173.45, 99.45);
  this.shape_32 = new cjs.Shape();
  this.shape_32.graphics.f("#FFFFFF").s().p("AgwBDIgEgBIACgNIAEABIAFABQAFAAADgEQADgEAAgJIAKhpIBJAAIAACGIgOAAIAAh5IguAAIgJBgQgCANgFAGQgFAHgMAAIgIgBg");
  this.shape_32.setTransform(160.2, 99.525);
  this.shape_33 = new cjs.Shape();
  this.shape_33.graphics.f("#FFFFFF").s().p("AglBDIAAiGIBJAAIAAANIg6AAIAAAxIA5AAIAAALIg5AAIAAAxIA8AAIAAAMg");
  this.shape_33.setTransform(149.975, 99.45);
  this.shape_34 = new cjs.Shape();
  this.shape_34.graphics.f("#FFFFFF").s().p("AgGBDIAAh5IgmAAIAAgNIBZAAIAAANIgmAAIAAB5g");
  this.shape_34.setTransform(139.725, 99.45);
  this.shape_35 = new cjs.Shape();
  this.shape_35.graphics.f("#FFFFFF").s().p("AAoBDIAAhvIhQBvIgNAAIAAiGIAOAAIAABwIBQhwIANAAIAACGg");
  this.shape_35.setTransform(127.775, 99.45);
  this.shape_36 = new cjs.Shape();
  this.shape_36.graphics.f("#FFFFFF").s().p("AAmBDIAAg9IhLAAIAAA9IgOAAIAAiGIAOAAIAAA+IBLAAIAAg+IAPAAIAACGg");
  this.shape_36.setTransform(113.6, 99.45);
  this.shape_37 = new cjs.Shape();
  this.shape_37.graphics.f("#FFFFFF").s().p("AgvBDIgGgBIADgNIAEABIAFABQAFAAACgEQADgEABgJIAKhpIBJAAIAACGIgOAAIAAh5IguAAIgKBgQgBANgFAGQgGAHgLAAIgHgBg");
  this.shape_37.setTransform(99.5, 99.525);
  this.shape_38 = new cjs.Shape();
  this.shape_38.graphics.f("#FFFFFF").s().p("AgjA8QgQgIgJgQQgJgPAAgVQAAgUAJgPQAJgQAQgIQAQgJATAAQAUAAAQAJQAQAJAJAPQAJAPAAAUQAAAUgJAQQgJAQgQAIQgQAKgUgBQgTABgQgKgAgcgwQgMAIgHAMQgIANAAAPQAAAQAIANQAHAMAMAIQANAGAPABQAQgBANgGQAMgIAHgMQAIgNAAgQQAAgPgIgNQgHgMgMgIQgNgHgQAAQgPAAgNAHg");
  this.shape_38.setTransform(86.275, 99.45);
  this.shape_39 = new cjs.Shape();
  this.shape_39.graphics.f("#FFFFFF").s().p("AAlBDIAAh5IhJAAIAAB5IgPAAIAAiGIBnAAIAACGg");
  this.shape_39.setTransform(71.25, 99.45);
  this.shape_40 = new cjs.Shape();
  this.shape_40.graphics.f("#FFFFFF").s().p("AgjA8QgQgIgJgQQgJgPAAgVQAAgUAJgPQAJgQAQgIQAQgJATAAQAUAAAQAJQAQAJAJAPQAJAPAAAUQAAAUgJAQQgJAQgQAIQgQAKgUgBQgTABgQgKgAgcgwQgMAIgHAMQgIANAAAPQAAAQAIANQAHAMAMAIQANAGAPABQAQgBANgGQAMgIAHgMQAIgNAAgQQAAgPgIgNQgHgMgMgIQgNgHgQAAQgPAAgNAHg");
  this.shape_40.setTransform(56.275, 99.45);
  this.shape_41 = new cjs.Shape();
  this.shape_41.graphics.f("#FFFFFF").s().p("AAwBTIAAgfIheAAIAAAfIgNAAIAAgsIAIAAQAEAAADgEQADgFADgHQACgHABgJIAKhZIBGAAIAAB5IAPAAIAAAsgAgVAHQgBANgDAJQgDAIgEACIA/AAIAAhsIgrAAg");
  this.shape_41.setTransform(41.725, 101.025);
  this.shape_42 = new cjs.Shape();
  this.shape_42.graphics.f("#FFFFFF").s().p("AgYA8QgQgIgJgQQgIgQgBgUQABgTAIgQQAKgQAPgIQAQgJATAAQANAAAMADQALAFAJAGIgEAOQgIgHgLgDQgKgFgMAAQgPABgMAGQgMAIgHAMQgIANAAAPQAAAQAIANQAHAMAMAIQAMAGAPABQANAAALgFQALgEAIgHIAEAOQgKAHgLAFQgMADgOAAQgTABgQgKg");
  this.shape_42.setTransform(24.6, 99.45);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_42
   }, {
    t: this.shape_41
   }, {
    t: this.shape_40
   }, {
    t: this.shape_39
   }, {
    t: this.shape_38
   }, {
    t: this.shape_37
   }, {
    t: this.shape_36
   }, {
    t: this.shape_35
   }, {
    t: this.shape_34
   }, {
    t: this.shape_33
   }, {
    t: this.shape_32
   }, {
    t: this.shape_31
   }, {
    t: this.shape_30
   }, {
    t: this.shape_29
   }, {
    t: this.shape_28
   }, {
    t: this.shape_27
   }, {
    t: this.shape_26
   }, {
    t: this.shape_25
   }, {
    t: this.shape_24
   }, {
    t: this.shape_23
   }, {
    t: this.shape_22
   }, {
    t: this.shape_21
   }, {
    t: this.shape_20
   }, {
    t: this.shape_19
   }, {
    t: this.shape_18
   }, {
    t: this.shape_17
   }, {
    t: this.shape_16
   }, {
    t: this.shape_15
   }, {
    t: this.shape_14
   }, {
    t: this.shape_13
   }, {
    t: this.shape_12
   }, {
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
 }).prototype = getMCSymbolPrototype(lib.t03, new cjs.Rectangle(15.5, 82, 249.5, 89.30000000000001), null);
 (lib.t02 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#FFFFFF").s().p("AgEAyIAqgyIgqgxIAUAAIApAxIgpAygAg4AyIArgyIgrgxIAVAAIAoAxIgoAyg");
  this.shape.setTransform(273.075, 134.35);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#FFFFFF").s().p("AgfBPQgVgLgMgVQgMgVAAgaQAAgaAMgVQAMgUAVgMQAUgLAaAAQARAAAQAFQAOAFAMAJIgGASQgLgJgOgFQgNgFgPAAQgVAAgPAJQgRAKgJAQQgKAQAAAVQAAAVAKAQQAJARARAKQAPAJAVAAQARAAAPgFQAOgGAKgJIAGASQgOAKgPAFQgQAFgSAAQgZAAgUgMg");
  this.shape_1.setTransform(258.2, 131.975);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#FFFFFF").s().p("AgSBRQgUgLgNgTQgMgSgCgZIgiAAIAABRIgSAAIAAixIASAAIAABQIAiAAQACgYANgTQAMgSAUgLQATgKAZAAQAbAAAUAMQAVALAMAVQAMAUAAAaQAAAagMAVQgMAVgVALQgUAMgbAAQgZAAgTgKgAgLg/QgQAKgKAQQgJARAAAUQAAAVAJARQAKAQAQAKQAQAJAVAAQAVAAARgJQAQgKAKgQQAJgRAAgVQAAgUgJgRQgKgQgQgKQgRgJgVgBQgVABgQAJg");
  this.shape_2.setTransform(235.775, 131.975);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#FFFFFF").s().p("Ag/BYIgGgCIADgRIAFADIAHABQAHAAADgGQADgFABgMIAOiLIBgAAIAACxIgTAAIAAigIg9AAIgMCAQgBAQgIAJQgHAIgPABIgKgCg");
  this.shape_3.setTransform(212.125, 132.075);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#FFFFFF").s().p("AAxBZIAAigIhhAAIAACgIgTAAIAAixICHAAIAACxg");
  this.shape_4.setTransform(196.125, 131.975);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#FFFFFF").s().p("AAkAyIgogyIAogxIAVAAIgrAxIArAygAgPAyIgpgyIApgxIAUAAIgqAxIAqAyg");
  this.shape_5.setTransform(180.725, 134.35);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#FFFFFF").s().p("ABABZIAAiWIg6BVIgMAAIg4hVIAACWIgTAAIAAixIAVAAIA8BaIA9haIAVAAIAACxg");
  this.shape_6.setTransform(157.8, 131.975);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#FFFFFF").s().p("AguBPQgWgLgMgVQgMgUABgbQgBgaAMgUQAMgVAWgLQAUgMAaAAQAbAAAUAMQAVALAMAVQAMAUAAAaQAAAagMAVQgMAVgVALQgUAMgbAAQgaAAgUgMgAglg/QgRAKgJAQQgKARAAAUQAAAVAKARQAJAQARAKQARAJAUAAQAVAAAQgJQARgKAJgQQAKgRAAgVQAAgUgKgRQgJgQgRgKQgQgJgVgBQgUABgRAJg");
  this.shape_7.setTransform(136.5, 131.975);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#FFFFFF").s().p("AArBYIhIhQIgRAAIAABQIgTAAIAAiwIATAAIAABQIAPAAIBEhQIAVAAIhIBXIBQBZg");
  this.shape_8.setTransform(119.25, 132);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#FFFFFF").s().p("AA6BZIgVg6IhJAAIgWA6IgTAAIBEixIATAAIBECxgAAfAQIgfhSIgeBSIA9AAg");
  this.shape_9.setTransform(102.175, 131.975);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.f("#FFFFFF").s().p("AAyBZIAAhRIhjAAIAABRIgTAAIAAixIATAAIAABQIBjAAIAAhQIATAAIAACxg");
  this.shape_10.setTransform(84.75, 131.975);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.f("#FFFFFF").s().p("AglBUQgPgHgJgKIAJgPQAGAFAHAFQAIAGAJADQAKADAMAAQAUAAAMgJQAMgJAAgSQAAgRgPgJQgPgJgfABIAAgPQAVAAAMgGQAMgFAFgHQAEgIAAgIQAAgNgKgIQgKgHgRgBQgNAAgMAFQgMAGgIAHIgIgPQAKgIANgFQAOgHARAAQAQABANAFQAMAGAHAJQAGAKAAAOQAAAQgKALQgKAKgQAFQAUACAMAKQALAMAAATQAAAPgHAMQgHAMgOAHQgOAGgUAAQgWAAgPgHg");
  this.shape_11.setTransform(67.975, 132);
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.f("#FFFFFF").s().p("AguBPQgWgLgMgVQgMgUABgbQgBgaAMgUQAMgVAWgLQAUgMAaAAQAbAAAUAMQAVALAMAVQAMAUAAAaQAAAagMAVQgMAVgVALQgUAMgbAAQgaAAgUgMgAglg/QgRAKgJAQQgKARAAAUQAAAVAKARQAJAQARAKQARAJAUAAQAVAAAQgJQARgKAJgQQAKgRAAgVQAAgUgKgRQgJgQgRgKQgQgJgVgBQgUABgRAJg");
  this.shape_12.setTransform(44.25, 131.975);
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.f("#FFFFFF").s().p("AgfBPQgVgLgMgVQgMgVAAgaQAAgaAMgVQAMgUAVgMQAUgLAaAAQARAAAQAFQAOAFAMAJIgGASQgLgJgOgFQgNgFgPAAQgVAAgQAJQgQAKgKAQQgIAQgBAVQABAVAIAQQAKARAQAKQAQAJAVAAQARAAAPgFQAOgGALgJIAFASQgOAKgPAFQgPAFgTAAQgZAAgUgMg");
  this.shape_13.setTransform(24.85, 131.975);
  this.shape_14 = new cjs.Shape();
  this.shape_14.graphics.f("#FFFFFF").s().p("AgIBZIAAigIgyAAIAAgRIB1AAIAAARIgxAAIAACgg");
  this.shape_14.setTransform(136.6, 104.325);
  this.shape_15 = new cjs.Shape();
  this.shape_15.graphics.f("#FFFFFF").s().p("Ag1BZIAAixIAwAAQATAAAOAHQAMAHAIAMQAGAMABARQgBAPgGANQgIALgMAIQgOAIgTAAIgeAAIAABDgAgjAGIAdAAQALAAAJgFQAJgDAGgJQAGgJAAgNQAAgOgGgJQgGgIgJgEQgJgDgLAAIgdAAg");
  this.shape_15.setTransform(123.85, 104.325);
  this.shape_16 = new cjs.Shape();
  this.shape_16.graphics.f("#FFFFFF").s().p("AgvBPQgVgLgLgVQgMgUgBgbQABgaAMgUQALgVAVgLQAWgMAZAAQAaAAAWAMQAUALAMAVQAMAUABAaQgBAagMAVQgMAVgUALQgWAMgaAAQgaAAgVgMgAglg/QgQAKgKAQQgKARAAAUQAAAVAKARQAKAQAQAKQAQAJAVAAQAVAAARgJQAQgKAKgQQAJgRABgVQgBgUgJgRQgKgQgQgKQgRgJgVgBQgVABgQAJg");
  this.shape_16.setTransform(105.3, 104.325);
  this.shape_17 = new cjs.Shape();
  this.shape_17.graphics.f("#FFFFFF").s().p("AgHBcIAAgTQgagBgSgJQgUgJgLgQQgKgQgBgWQABgVAKgQQALgQAUgJQASgJAagBIAAgTIAQAAIAAATQAZABATAJQATAJALAQQALAQAAAVQAAAWgLAQQgLAPgTAKQgTAJgZABIAAATgAAJA6QAUgCAOgHQAPgHAJgNQAJgMAAgRQAAgQgJgMQgJgMgPgIQgOgHgUgBgAgqgwQgPAIgJAMQgIAMAAAQQAAARAIAMQAJANAPAHQAPAHAUACIAAhyQgUABgPAHg");
  this.shape_17.setTransform(84.15, 104.325);
  this.shape_18 = new cjs.Shape();
  this.shape_18.graphics.f("#FFFFFF").s().p("ABABZIAAiWIg6BVIgMAAIg4hVIAACWIgTAAIAAixIAVAAIA8BaIA9haIAVAAIAACxg");
  this.shape_18.setTransform(63.2, 104.325);
  this.shape_19 = new cjs.Shape();
  this.shape_19.graphics.f("#FFFFFF").s().p("AguBPQgWgLgMgVQgMgUABgbQgBgaAMgUQAMgVAWgLQAUgMAaAAQAbAAAUAMQAVALAMAVQAMAUAAAaQAAAagMAVQgMAVgVALQgUAMgbAAQgaAAgUgMgAglg/QgRAKgJAQQgJARAAAUQAAAVAJARQAJAQARAKQARAJAUAAQAVAAAQgJQARgKAJgQQAKgRAAgVQAAgUgKgRQgJgQgRgKQgQgJgVgBQgUABgRAJg");
  this.shape_19.setTransform(41.9, 104.325);
  this.shape_20 = new cjs.Shape();
  this.shape_20.graphics.f("#FFFFFF").s().p("AArBZIhIhRIgRAAIAABRIgTAAIAAixIATAAIAABRIAQAAIBChRIAXAAIhJBXIBQBag");
  this.shape_20.setTransform(24.65, 104.35);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_20
   }, {
    t: this.shape_19
   }, {
    t: this.shape_18
   }, {
    t: this.shape_17
   }, {
    t: this.shape_16
   }, {
    t: this.shape_15
   }, {
    t: this.shape_14
   }, {
    t: this.shape_13
   }, {
    t: this.shape_12
   }, {
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
 }).prototype = getMCSymbolPrototype(lib.t02, new cjs.Rectangle(13.5, 82, 274.5, 67.30000000000001), null);
 (lib.t01 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#FFFFFF").s().p("AgwBZIAAixIBgAAIAAARIhOAAIAAA/IBLAAIAAAQIhLAAIAABAIBQAAIAAARg");
  this.shape.setTransform(75.5, 50.975);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#FFFFFF").s().p("AgwBZIAAixIASAAIAACgIBPAAIAAARg");
  this.shape_1.setTransform(63.35, 50.975);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#FFFFFF").s().p("AgIBZIAAhHIg/hqIAUAAIA0BYIA0hYIAUAAIg/BqIAABHg");
  this.shape_2.setTransform(49.35, 50.975);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#FFFFFF").s().p("AgIBZIAAigIgyAAIAAgRIB1AAIAAARIgxAAIAACgg");
  this.shape_3.setTransform(36.35, 50.975);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#FFFFFF").s().p("AgeBXQgPgFgKgIIAEgSQALAIAOAFQANAFAOABQAQAAALgJQAKgIAAgQQAAgJgGgGQgEgHgJgEIgUgJQgOgEgLgGQgMgFgGgKQgHgKgBgOQAAgPAIgLQAHgKAMgHQAOgFAPgBQANABAMADQANADAIAFIgEASQgJgFgLgEQgLgDgMgBQgQABgKAHQgJAJgBAOQAAAJAFAGQAFAHAJAFIATAIIAZAJQAMAGAHAJQAHAJAAAQQAAAQgHALQgIAMgMAFQgNAHgQAAQgQgBgOgEg");
  this.shape_4.setTransform(23.25, 50.95);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#FFFFFF").s().p("AASBZIAAgoIhPAAIAAgMIBUh9IANAAIAAB5IAaAAIAAAQIgaAAIAAAogAgpAhIA7AAIAAhYg");
  this.shape_5.setTransform(170.625, 25.325);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#FFFFFF").s().p("AgJBZIhDixIAUAAIA4CaIA6iaIATAAIhDCxg");
  this.shape_6.setTransform(156.5, 25.325);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#FFFFFF").s().p("AA6BZIgVg6IhJAAIgWA6IgTAAIBEixIATAAIBECxgAAfAQIgfhSIgeBSIA9AAg");
  this.shape_7.setTransform(141.225, 25.325);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#FFFFFF").s().p("AAoBZIgwhKIgEAAIgeAAIAABKIgTAAIAAixIAzAAQAZABAPANQAPANAAAYQAAARgJANQgKAMgQAGIA0BOgAgqAAIAeAAQAKAAAIgEQAJgEAFgIQAGgIAAgMQAAgNgGgIQgFgIgJgDQgIgDgKAAIgeAAg");
  this.shape_8.setTransform(126.675, 25.325);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#FFFFFF").s().p("AA6BZIgVg6IhJAAIgWA6IgTAAIBEixIATAAIBECxgAAfAQIgfhSIgeBSIA9AAg");
  this.shape_9.setTransform(104.625, 25.325);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.f("#FFFFFF").s().p("AgIBZIAAigIgyAAIAAgRIB1AAIAAARIgxAAIAACgg");
  this.shape_10.setTransform(90.6, 25.325);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.f("#FFFFFF").s().p("AguBPQgWgLgMgVQgMgUABgbQgBgaAMgUQAMgVAWgLQAUgMAaAAQAbAAAUAMQAVALAMAVQAMAUAAAaQAAAagMAVQgMAVgVALQgUAMgbAAQgaAAgUgMgAglg/QgRAKgJAQQgJARgBAUQABAVAJARQAJAQARAKQARAJAUAAQAVAAAQgJQARgKAJgQQAKgRAAgVQAAgUgKgRQgJgQgRgKQgQgJgVgBQgUABgRAJg");
  this.shape_11.setTransform(73.95, 25.325);
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.f("#FFFFFF").s().p("AgIBZIAAhHIg/hqIAUAAIA0BYIA0hYIAUAAIg/BqIAABHg");
  this.shape_12.setTransform(56.55, 25.325);
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.f("#FFFFFF").s().p("AgvBPQgVgLgLgVQgMgUgBgbQABgaAMgUQALgVAVgLQAWgMAZAAQAaAAAWAMQAUALAMAVQAMAUABAaQgBAagMAVQgMAVgUALQgWAMgaAAQgaAAgVgMgAglg/QgQAKgKAQQgKARAAAUQAAAVAKARQAKAQAQAKQAQAJAVAAQAVAAARgJQAQgKAKgQQAJgRABgVQgBgUgJgRQgKgQgQgKQgRgJgVgBQgVABgQAJg");
  this.shape_13.setTransform(39.15, 25.325);
  this.shape_14 = new cjs.Shape();
  this.shape_14.graphics.f("#FFFFFF").s().p("AgIBZIAAigIgyAAIAAgRIB1AAIAAARIgxAAIAACgg");
  this.shape_14.setTransform(22.55, 25.325);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_14
   }, {
    t: this.shape_13
   }, {
    t: this.shape_12
   }, {
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
 }).prototype = getMCSymbolPrototype(lib.t01, new cjs.Rectangle(14, 3, 181.5, 65.3), null);
 (lib.snoska2 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#FFFFFF").s().p("AgWAZIgCgBIABgGIACAAIACABQABAAABAAQAAgBABAAQAAAAABAAQAAgBABAAQABgCABgFIAEgiIAhAAIAAAxIgHAAIAAgrIgUAAIgEAeQAAAHgDADQgDADgGAAIgEAAg");
  this.shape.setTransform(43.125, 473.175);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#FFFFFF").s().p("AAQAkIAAgnIgfAnIgHAAIAAgxIAHAAIAAAnIAfgnIAHAAIAAAxgAgKgZQgEgEAAgGIAFAAQAAAEADACQADACADAAQAEAAADgCQACgCAAgEIAGAAQAAAGgEAEQgEADgHAAQgGAAgEgDg");
  this.shape_1.setTransform(37.675, 472.025);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#FFFFFF").s().p("AgQAWQgEgEAAgHQAAgFADgEQAEgDAHgBQAHgCANAAIAAgBQAAgGgDgEQgEgEgHAAIgGABIgFADIgEACIgCgGIAIgFQAFgBAFAAQAKAAAFAFQAFAEAAALIAAAeIgHAAIAAgJQgCAEgFADQgFADgFAAQgJAAgEgEgAgCACQgGABgDACQgCACAAAEQAAAEADADQADACAFAAQADAAAEgBIAHgFQACgDAAgGIAAgFIgQACg");
  this.shape_2.setTransform(31.825, 473.15);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#FFFFFF").s().p("AgDAZIAAgrIgQAAIAAgGIAnAAIAAAGIgRAAIAAArg");
  this.shape_3.setTransform(27.125, 473.15);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#FFFFFF").s().p("AgMAgQgIgFgFgIQgFgJAAgKQAAgKAFgIQAFgIAIgFQAIgEAKgBQAHAAAGACQAGADAFAEIgDAHQgEgEgFgCQgGgDgGABQgHAAgHADQgGAEgEAHQgEAGAAAIQAAAJAEAGQAEAHAGAEQAHADAHAAQAHAAAGgCQAFgCAFgEIACAHQgGAFgGACQgGABgHAAQgKAAgIgEg");
  this.shape_4.setTransform(21.625, 472.1);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#FFFFFF").s().p("AAAAFIgGALIgFgEIAIgKIgNgCIADgHIAMAFIgBgNIAGAAIgCANIANgFIACAHIgNACIAJAKIgGAEg");
  this.shape_5.setTransform(13.975, 470.125);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
 }).prototype = getMCSymbolPrototype(lib.snoska2, new cjs.Rectangle(10, 462, 229.8, 18.30000000000001), null);
 (lib.snoska = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#FFFFFF").s().p("AgBAUIAQgUIgQgTIAHAAIARATIgRAUgAgWAUIARgUIgRgTIAIAAIAQATIgQAUg");
  this.shape.setTransform(92.425, 484.3);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#FFFFFF").s().p("AALAZIgVgXIgCAAIAAAXIgHAAIAAgxIAHAAIAAAVIADAAIATgVIAJAAIgXAYIAYAZg");
  this.shape_1.setTransform(88.125, 484.4);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#FFFFFF").s().p("AAOAZIAAgXIgbAAIAAAXIgHAAIAAgxIAHAAIAAAVIAbAAIAAgVIAHAAIAAAxg");
  this.shape_2.setTransform(82.475, 484.4);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#FFFFFF").s().p("AgQAWQgEgEAAgHQAAgFADgEQAEgDAHgBQAHgCANAAIAAgBQAAgGgDgEQgEgEgHAAIgGABIgFADIgEACIgCgGIAIgFQAFgBAFAAQAKAAAFAFQAFAEAAALIAAAeIgHAAIAAgJQgCAEgFADQgFADgFAAQgJAAgEgEgAgCACQgGABgDACQgCACAAAEQAAAEADADQADACAFAAQADAAAEgBIAHgFQACgDAAgGIAAgFIgQACg");
  this.shape_3.setTransform(76.775, 484.4);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#FFFFFF").s().p("AgWAjIAAhGIAlAAIAAAIIgeAAIAAAXIAPAAQAMAAAFAEQAGAFAAAKQAAAGgDAFQgCAEgFADQgFACgIAAgAgPAdIAPAAQAHAAAEgEQAEgEABgGQgBgHgEgDQgFgEgGAAIgPAAg");
  this.shape_4.setTransform(71.6, 483.35);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#FFFFFF").s().p("AgQAWQgEgEAAgHQAAgFADgEQAEgDAHgBQAHgCANAAIAAgBQAAgGgDgEQgEgEgHAAIgGABIgFADIgEACIgCgGIAIgFQAFgBAFAAQAKAAAFAFQAFAEAAALIAAAeIgHAAIAAgJQgCAEgFADQgFADgFAAQgJAAgEgEgAgCACQgGABgDACQgCACAAAEQAAAEADADQADACAFAAQADAAAEgBIAHgFQACgDAAgGIAAgFIgQACg");
  this.shape_5.setTransform(63.375, 484.4);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#FFFFFF").s().p("AgDAZIAAgrIgQAAIAAgGIAnAAIAAAGIgRAAIAAArg");
  this.shape_6.setTransform(58.675, 484.4);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#FFFFFF").s().p("AgNAWQgGgCgDgHQgDgFAAgIQAAgHADgGQADgFAGgEQAGgDAHAAQAIAAAGADQAGAEADAFQADAGAAAHQAAAIgDAFQgDAHgGACQgGAEgIAAQgHAAgGgEgAgJgQQgEADgDAEQgCAEAAAFQAAAGACAEQADAFAEACQAEACAFABQAGgBAEgCQAEgCADgFQACgEAAgGQAAgFgCgEQgDgEgEgDQgEgCgGAAQgFAAgEACg");
  this.shape_7.setTransform(53.625, 484.4);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#FFFFFF").s().p("AAQAkIAAgnIgfAnIgHAAIAAgxIAHAAIAAAnIAfgnIAHAAIAAAxgAgKgZQgEgEAAgGIAFAAQAAAEADACQADACADAAQAEAAADgCQACgCAAgEIAGAAQAAAGgEAEQgEADgHAAQgGAAgEgDg");
  this.shape_8.setTransform(47.675, 483.275);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#FFFFFF").s().p("AgNAWQgGgCgDgHQgDgFAAgIQAAgHADgGQADgFAGgEQAGgDAHAAQAIAAAGADQAGAEADAFQADAGAAAHQAAAIgDAFQgDAHgGACQgGAEgIAAQgHAAgGgEgAgJgQQgEADgDAEQgCAEAAAFQAAAGACAEQADAFAEACQAEACAFABQAGgBAEgCQAEgCADgFQACgEAAgGQAAgFgCgEQgDgEgEgDQgEgCgGAAQgFAAgEACg");
  this.shape_9.setTransform(41.675, 484.4);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.f("#FFFFFF").s().p("AgDAjIAAg+IgUAAIAAgIIAuAAIAAAIIgTAAIAAA+g");
  this.shape_10.setTransform(36.3, 483.35);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.f("#FFFFFF").s().p("AAOAUIgPgUIAPgTIAJAAIgRATIARAUgAgFAUIgRgUIARgTIAHAAIgQATIAQAUg");
  this.shape_11.setTransform(31.475, 484.3);
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.f("#FFFFFF").s().p("AgSAgQgIgFgFgIQgFgJAAgKQAAgJAFgJQAFgIAIgFQAIgEAKgBQAKAAAJAGQAIAEAFAIQAFAJAAAJQAAAKgFAJQgFAIgIAFQgJAEgKAAQgKAAgIgEgAgOgZQgGAEgFAHQgDAGAAAIQAAAJADAGQAFAHAGAEQAGADAIAAQAIAAAHgDQAHgEADgHQAEgGAAgJQAAgIgEgGQgDgHgHgEQgHgDgIAAQgIAAgGADg");
  this.shape_12.setTransform(22.65, 483.35);
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.f("#FFFFFF").s().p("AAXAjIgIgXIgdAAIgJAXIgHAAIAbhGIAHAAIAbBGgAAMAGIgMggIgMAgIAYAAg");
  this.shape_13.setTransform(15.325, 483.35);
  this.shape_14 = new cjs.Shape();
  this.shape_14.graphics.f("#FFFFFF").s().p("AANAZIAAgVIgMAAIgNAVIgHAAIAOgWQgFgBgDgCQgDgEAAgFQAAgFACgEQACgDAEgBQAEgCAEAAIAUAAIAAAxgAgGgQQgDACAAAFQAAAEADACQACADAFAAIAMAAIAAgTIgMAAQgFAAgCADg");
  this.shape_14.setTransform(198.025, 473.125);
  this.shape_15 = new cjs.Shape();
  this.shape_15.graphics.f("#FFFFFF").s().p("AgIAWQgGgCgDgHQgDgFAAgIQAAgHADgGQADgFAGgEQAFgDAHAAQAFAAAEABIAIAEIgCAGQgDgCgEgBQgDgBgFAAQgFAAgEACQgEADgCAEQgDAEAAAFQAAAGADAEQACAFAEACQAEACAEABIAJgCIAIgEIABAGQgCADgGABQgEACgGAAQgGAAgFgEg");
  this.shape_15.setTransform(193.45, 473.15);
  this.shape_16 = new cjs.Shape();
  this.shape_16.graphics.f("#FFFFFF").s().p("AgDAZIAAgrIgQAAIAAgGIAnAAIAAAGIgRAAIAAArg");
  this.shape_16.setTransform(188.875, 473.15);
  this.shape_17 = new cjs.Shape();
  this.shape_17.graphics.f("#FFFFFF").s().p("AgLAWQgGgDgDgGQgDgGAAgHQAAgGADgHQADgFAGgEQAGgDAFAAQAIAAAFADQAFADADAGQADAGAAAHIAAABIgoAAQAAAIAGAFQAFAGAHAAQAGAAAFgCQAEgCADgEIADAHQgDADgGACQgGACgGAAQgHAAgGgEgAARgEQgBgFgCgDQgCgDgEgCQgDgCgFAAQgCAAgEACQgEACgCADQgDADgBAFIAhAAIAAAAg");
  this.shape_17.setTransform(184.1, 473.15);
  this.shape_18 = new cjs.Shape();
  this.shape_18.graphics.f("#FFFFFF").s().p("AANAZIAAgVIgMAAIgNAVIgHAAIAOgWQgFgBgDgCQgDgEAAgFQAAgFACgEQACgDAEgBQAEgCAEAAIAUAAIAAAxgAgGgQQgDACAAAFQAAAEADACQACADAFAAIAMAAIAAgTIgMAAQgFAAgCADg");
  this.shape_18.setTransform(178.675, 473.125);
  this.shape_19 = new cjs.Shape();
  this.shape_19.graphics.f("#FFFFFF").s().p("AgWAZIgCgBIABgGIACAAIACABQABAAABAAQAAgBABAAQAAAAABAAQAAgBABAAQABgCABgFIAEgiIAhAAIAAAxIgHAAIAAgrIgUAAIgEAeQAAAHgDADQgDADgGAAIgEAAg");
  this.shape_19.setTransform(173.225, 473.175);
  this.shape_20 = new cjs.Shape();
  this.shape_20.graphics.f("#FFFFFF").s().p("AgTAZIAAgxIASAAQAIAAAEADQAFADAAAGQAAAEgDADQgCADgEACQAGAAADACQADADABAGQgBAFgCADQgCADgEABQgEACgFAAgAgMAUIANAAQAFgBADgCQADgDAAgDQAAgFgDgCQgDgDgGABIgMAAgAgMgDIALAAIAGgBIADgDIABgEQAAgEgDgBQgDgCgEAAIgLAAg");
  this.shape_20.setTransform(168.525, 473.15);
  this.shape_21 = new cjs.Shape();
  this.shape_21.graphics.f("#FFFFFF").s().p("AgDAZIAAgrIgQAAIAAgGIAnAAIAAAGIgRAAIAAArg");
  this.shape_21.setTransform(163.675, 473.15);
  this.shape_22 = new cjs.Shape();
  this.shape_22.graphics.f("#FFFFFF").s().p("AgJAWQgFgCgEgHQgCgFAAgIQAAgHACgGQAEgFAFgEQAHgDAGAAQAFAAAFABIAHAEIgDAGQgCgCgEgBQgDgBgFAAQgEAAgEACQgFADgCAEQgDAEABAFQgBAGADAEQACAFAEACQAEACAFABIAJgCIAHgEIACAGQgDADgFABQgFACgGAAQgGAAgGgEg");
  this.shape_22.setTransform(159.2, 473.15);
  this.shape_23 = new cjs.Shape();
  this.shape_23.graphics.f("#FFFFFF").s().p("AgLAWQgGgDgDgGQgDgGAAgHQAAgGADgHQAEgFAFgEQAGgDAFAAQAIAAAFADQAGADACAGQADAGAAAHIAAABIgoAAQABAIAFAFQAFAGAHAAQAGAAAFgCQAEgCADgEIADAHQgEADgFACQgGACgGAAQgHAAgGgEgAARgEQAAgFgDgDQgCgDgEgCQgDgCgFAAQgDAAgDACQgEACgCADQgDADgBAFIAhAAIAAAAg");
  this.shape_23.setTransform(154.05, 473.15);
  this.shape_24 = new cjs.Shape();
  this.shape_24.graphics.f("#FFFFFF").s().p("AAgAgIAAgOIhGAAIAAgxIAHAAIAAArIAYAAIAAgrIAHAAIAAArIAYAAIAAgrIAHAAIAAArIAIAAIAAAUg");
  this.shape_24.setTransform(147.375, 473.875);
  this.shape_25 = new cjs.Shape();
  this.shape_25.graphics.f("#FFFFFF").s().p("AgTAkIgDgBIABgGIACAAIABAAQAFAAADgCQADgCACgGIAEgHIgWgvIAHAAIARAmIAQgmIAHAAIgYA4QgCAIgEADQgEAEgHAAIgCAAg");
  this.shape_25.setTransform(140.45, 474.225);
  this.shape_26 = new cjs.Shape();
  this.shape_26.graphics.f("#FFFFFF").s().p("AgJAWQgFgCgEgHQgDgFAAgIQAAgHADgGQAEgFAFgEQAHgDAGAAQAFAAAFABIAHAEIgDAGQgCgCgEgBQgDgBgFAAQgEAAgEACQgFADgCAEQgDAEABAFQgBAGADAEQACAFAEACQAEACAFABIAJgCIAHgEIACAGQgDADgFABQgFACgGAAQgGAAgGgEg");
  this.shape_26.setTransform(135.8, 473.15);
  this.shape_27 = new cjs.Shape();
  this.shape_27.graphics.f("#FFFFFF").s().p("AgNAWQgGgCgDgHQgDgFAAgIQAAgHADgGQADgFAGgEQAGgDAHAAQAIAAAGADQAGAEADAFQADAGAAAHQAAAIgDAFQgDAHgGACQgGAEgIAAQgHAAgGgEgAgJgQQgEADgDAEQgCAEAAAFQAAAGACAEQADAFAEACQAEACAFABQAGgBAEgCQAEgCADgFQACgEAAgGQAAgFgCgEQgDgEgEgDQgEgCgGAAQgFAAgEACg");
  this.shape_27.setTransform(130.375, 473.15);
  this.shape_28 = new cjs.Shape();
  this.shape_28.graphics.f("#FFFFFF").s().p("AgLAWQgGgDgDgGQgDgGAAgHQAAgGADgHQADgFAGgEQAFgDAHAAQAGAAAGADQAFADADAGQADAGAAAHIAAABIgoAAQAAAIAFAFQAGAGAIAAQAFAAAFgCQAFgCADgEIABAHQgDADgFACQgGACgGAAQgHAAgGgEgAARgEQAAgFgDgDQgCgDgDgCQgEgCgEAAQgDAAgEACQgEACgDADQgCADAAAFIAgAAIAAAAg");
  this.shape_28.setTransform(122.5, 473.15);
  this.shape_29 = new cjs.Shape();
  this.shape_29.graphics.f("#FFFFFF").s().p("AAQAZIAAgnIgfAnIgHAAIAAgxIAHAAIAAAnIAfgnIAHAAIAAAxg");
  this.shape_29.setTransform(116.775, 473.15);
  this.shape_30 = new cjs.Shape();
  this.shape_30.graphics.f("#FFFFFF").s().p("AAOAZIAAgXIgbAAIAAAXIgHAAIAAgxIAHAAIAAAVIAbAAIAAgVIAHAAIAAAxg");
  this.shape_30.setTransform(110.825, 473.15);
  this.shape_31 = new cjs.Shape();
  this.shape_31.graphics.f("#FFFFFF").s().p("AgQAWQgEgEAAgHQAAgFADgEQAEgDAHgBQAHgCANAAIAAgBQAAgGgDgEQgEgEgHAAIgGABIgFADIgEACIgCgGIAIgFQAFgBAFAAQAKAAAFAFQAFAEAAALIAAAeIgHAAIAAgJQgCAEgFADQgFADgFAAQgJAAgEgEgAgCACQgGABgDACQgCACAAAEQAAAEADADQADACAFAAQADAAAEgBIAHgFQACgDAAgGIAAgFIgQACg");
  this.shape_31.setTransform(105.125, 473.15);
  this.shape_32 = new cjs.Shape();
  this.shape_32.graphics.f("#FFFFFF").s().p("AgTAZIAAgxIASAAQAIAAAEADQAFADAAAGQAAAEgDADQgCADgEACQAGAAADACQADADABAGQgBAFgCADQgCADgEABQgEACgFAAgAgMAUIANAAQAFgBADgCQADgDAAgDQAAgFgDgCQgDgDgGABIgMAAgAgMgDIALAAIAGgBIADgDIABgEQAAgEgDgBQgDgCgEAAIgLAAg");
  this.shape_32.setTransform(100.275, 473.15);
  this.shape_33 = new cjs.Shape();
  this.shape_33.graphics.f("#FFFFFF").s().p("AgNAWQgGgCgDgHQgDgFAAgIQAAgHADgGQADgFAGgEQAGgDAHAAQAIAAAGADQAGAEADAFQADAGAAAHQAAAIgDAFQgDAHgGACQgGAEgIAAQgHAAgGgEgAgJgQQgEADgDAEQgCAEAAAFQAAAGACAEQADAFAEACQAEACAFABQAGgBAEgCQAEgCADgFQACgEAAgGQAAgFgCgEQgDgEgEgDQgEgCgGAAQgFAAgEACg");
  this.shape_33.setTransform(94.575, 473.15);
  this.shape_34 = new cjs.Shape();
  this.shape_34.graphics.f("#FFFFFF").s().p("AgDAZIAAgrIgQAAIAAgGIAnAAIAAAGIgRAAIAAArg");
  this.shape_34.setTransform(89.525, 473.15);
  this.shape_35 = new cjs.Shape();
  this.shape_35.graphics.f("#FFFFFF").s().p("AAQAZIAAgnIgfAnIgHAAIAAgxIAHAAIAAAnIAfgnIAHAAIAAAxg");
  this.shape_35.setTransform(84.425, 473.15);
  this.shape_36 = new cjs.Shape();
  this.shape_36.graphics.f("#FFFFFF").s().p("AAVAgIAAgOIgpAAIAAAOIgGAAIAAgUIACAAQAEAAACgDQACgEABgGIAEgeIAfAAIAAArIAIAAIAAAUgAgIAAIgBAHQgCADgCACIAZAAIAAglIgRAAg");
  this.shape_36.setTransform(78.5, 473.875);
  this.shape_37 = new cjs.Shape();
  this.shape_37.graphics.f("#FFFFFF").s().p("AgLAWQgGgDgDgGQgDgGAAgHQAAgGADgHQAEgFAFgEQAGgDAFAAQAIAAAFADQAGADACAGQADAGAAAHIAAABIgoAAQABAIAFAFQAFAGAHAAQAGAAAFgCQAEgCADgEIADAHQgEADgFACQgGACgGAAQgHAAgGgEgAARgEQgBgFgCgDQgCgDgEgCQgDgCgFAAQgDAAgDACQgEACgCADQgDADgBAFIAhAAIAAAAg");
  this.shape_37.setTransform(73.05, 473.15);
  this.shape_38 = new cjs.Shape();
  this.shape_38.graphics.f("#FFFFFF").s().p("AgYAkIAAhGIAHAAIAAAKQADgGAFgDQAFgCAFAAQAHAAAGADQAFAEADAFQADAGAAAIQAAAIgDAEQgDAGgGADQgFAEgHAAIgHgBIgGgEIgFgGIAAAfgAgJgaQgEADgCAEQgDAEAAAGQAAAGACADQADAFAEACQAEACAFABQAFgBAEgCQAEgCADgFQACgDAAgGQAAgGgCgEQgCgEgEgDQgEgCgGAAQgEAAgFACg");
  this.shape_38.setTransform(67.475, 474.15);
  this.shape_39 = new cjs.Shape();
  this.shape_39.graphics.f("#FFFFFF").s().p("AARAjIgcggIgHAAIAAAgIgHAAIAAhGIAHAAIAAAhIAGAAIAaghIAJAAIgcAjIAfAjg");
  this.shape_39.setTransform(61.675, 472.1);
  this.shape_40 = new cjs.Shape();
  this.shape_40.graphics.f("#FFFFFF").s().p("AAAAFIgGALIgFgEIAIgKIgNgCIADgHIAMAFIgBgNIAGAAIgCANIANgFIACAHIgNACIAJAKIgGAEg");
  this.shape_40.setTransform(54.075, 470.125);
  this.shape_41 = new cjs.Shape();
  this.shape_41.graphics.f("#FFFFFF").s().p("AAAAFIgGALIgFgEIAIgKIgNgCIADgHIAMAFIgBgNIAGAAIgCANIANgFIACAHIgNACIAJAKIgGAEg");
  this.shape_41.setTransform(50.425, 470.125);
  this.shape_42 = new cjs.Shape();
  this.shape_42.graphics.f("#FFFFFF").s().p("AgWAZIgCgBIABgGIACAAIACABQABAAABAAQAAgBABAAQAAAAABAAQAAgBABAAQABgCABgFIAEgiIAhAAIAAAxIgHAAIAAgrIgUAAIgEAeQAAAHgDADQgDADgGAAIgEAAg");
  this.shape_42.setTransform(43.125, 473.175);
  this.shape_43 = new cjs.Shape();
  this.shape_43.graphics.f("#FFFFFF").s().p("AAQAkIAAgnIgfAnIgHAAIAAgxIAHAAIAAAnIAfgnIAHAAIAAAxgAgKgZQgEgEAAgGIAFAAQAAAEADACQADACADAAQAEAAADgCQACgCAAgEIAGAAQAAAGgEAEQgEADgHAAQgGAAgEgDg");
  this.shape_43.setTransform(37.675, 472.025);
  this.shape_44 = new cjs.Shape();
  this.shape_44.graphics.f("#FFFFFF").s().p("AgQAWQgEgEAAgHQAAgFADgEQAEgDAHgBQAHgCANAAIAAgBQAAgGgDgEQgEgEgHAAIgGABIgFADIgEACIgCgGIAIgFQAFgBAFAAQAKAAAFAFQAFAEAAALIAAAeIgHAAIAAgJQgCAEgFADQgFADgFAAQgJAAgEgEgAgCACQgGABgDACQgCACAAAEQAAAEADADQADACAFAAQADAAAEgBIAHgFQACgDAAgGIAAgFIgQACg");
  this.shape_44.setTransform(31.825, 473.15);
  this.shape_45 = new cjs.Shape();
  this.shape_45.graphics.f("#FFFFFF").s().p("AgDAZIAAgrIgQAAIAAgGIAnAAIAAAGIgRAAIAAArg");
  this.shape_45.setTransform(27.125, 473.15);
  this.shape_46 = new cjs.Shape();
  this.shape_46.graphics.f("#FFFFFF").s().p("AgMAgQgIgFgFgIQgFgJAAgKQAAgKAFgIQAFgIAIgFQAIgEAKgBQAHAAAGACQAGADAFAEIgDAHQgEgEgFgCQgGgDgGABQgHAAgHADQgGAEgEAHQgEAGAAAIQAAAJAEAGQAEAHAGAEQAHADAHAAQAHAAAGgCQAFgCAFgEIACAHQgGAFgGACQgGABgHAAQgKAAgIgEg");
  this.shape_46.setTransform(21.625, 472.1);
  this.shape_47 = new cjs.Shape();
  this.shape_47.graphics.f("#FFFFFF").s().p("AAAAFIgGALIgFgEIAIgKIgNgCIADgHIAMAFIgBgNIAGAAIgCANIANgFIACAHIgNACIAJAKIgGAEg");
  this.shape_47.setTransform(13.975, 470.125);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_47
   }, {
    t: this.shape_46
   }, {
    t: this.shape_45
   }, {
    t: this.shape_44
   }, {
    t: this.shape_43
   }, {
    t: this.shape_42
   }, {
    t: this.shape_41
   }, {
    t: this.shape_40
   }, {
    t: this.shape_39
   }, {
    t: this.shape_38
   }, {
    t: this.shape_37
   }, {
    t: this.shape_36
   }, {
    t: this.shape_35
   }, {
    t: this.shape_34
   }, {
    t: this.shape_33
   }, {
    t: this.shape_32
   }, {
    t: this.shape_31
   }, {
    t: this.shape_30
   }, {
    t: this.shape_29
   }, {
    t: this.shape_28
   }, {
    t: this.shape_27
   }, {
    t: this.shape_26
   }, {
    t: this.shape_25
   }, {
    t: this.shape_24
   }, {
    t: this.shape_23
   }, {
    t: this.shape_22
   }, {
    t: this.shape_21
   }, {
    t: this.shape_20
   }, {
    t: this.shape_19
   }, {
    t: this.shape_18
   }, {
    t: this.shape_17
   }, {
    t: this.shape_16
   }, {
    t: this.shape_15
   }, {
    t: this.shape_14
   }, {
    t: this.shape_13
   }, {
    t: this.shape_12
   }, {
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
 }).prototype = getMCSymbolPrototype(lib.snoska, new cjs.Rectangle(10, 462, 229.8, 29.5), null);
 (lib.red_line = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#FF0022").s().p("AyvAPIAAgdMAlfAAAIAAAdg");
  this.shape.setTransform(120, 1.5);
  this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
 }).prototype = getMCSymbolPrototype(lib.red_line, new cjs.Rectangle(0, 0, 240, 3), null);
 (lib.logo_s = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#FFFFFF").s().p("AiNBbQg6gmAAg1QAAg1A6glQA7gmBSAAQBTAAA6AmQA7AlAAA1QAAA1g7AmQg6AmhTAAQhSAAg7gmgACUg9QAAAbgrASQgZALgfAFIAAAEQAAAwgOAiQgJAUgLAIQA8gEAtgeQAZgQANgXQANgWABgXQgBgYgMgUQgEgJgHgHIAAADgAifgwQgLAUAAAYQAAAXAMAWQAOAXAYAQQAaARAdAJQAYAGAaACQgLgIgIgUQgPgiAAgwIAAgEQgegFgZgLQgsgSAAgbIAAgCIgLAPgAgVAzQAJAWAMAAQAMAAAJgWQAJgVAAgdQgOABgQAAQgPAAgPgBQABAdAIAVgAgVg5QgEAMgCAPIAbABIAdgBQgDgPgFgMQgJgXgMAAQgMAAgJAXgAAjhMQAIAUAEAYQATgEAQgFQAhgMAAgRQAAgRghgMQgNgFgPgDIgNgCIgmgCIgDAAIgDAAIgtADIgJACIgXAHQgiAMAAARQAAARAiAMQAQAGASADQAEgYAIgUQAPghATAAQAVAAAOAhg");
  this.shape.setTransform(20, 12.925);
  this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
 }).prototype = getMCSymbolPrototype(lib.logo_s, new cjs.Rectangle(0, 0, 40, 25.9), null);
 (lib.legal_01_d1 = function() {
  this.initialize(img.legal_01_d1);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 267, 705);
 (lib.legal_01 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_d1 = new lib.legal_01_d1();
  this.cvr_d1.name = "cvr_d1";
  this.cvr_d1.parent = this;
  this.cvr_d1.setTransform(17, 64, 0.5, 0.5);
  this.initialize(mode, startPosition, loop, {
   cvr_frame01: 65,
   cvr_frame02: 195
  });
  this.frame_start = function() {
   globalStop(false);
   this.gotoAndPlay(1);
  }
  this.frame_finish = function() {
   globalStop(true)
   this.stop()
  }
  this.timeline.addTween(cjs.Tween.get(this).call(this.frame_start).wait(260).call(this.frame_finish).wait(1));
  this.timeline.addTween(cjs.Tween.get(this.cvr_d1).to({
   alpha: 0
  }, 0).to({
   alpha: 1
  }, 5).wait(120).to({
   alpha: 0
  }, 5).to({
   y: -341
  }, 0).to({
   alpha: 1
  }, 5).wait(120).to({
   alpha: 0
  }, 5).to({
   y: -746
  }, 0).wait(1));
  var mask_cvr_d1 = new cjs.Shape();
  mask_cvr_d1._off = true;
  mask_cvr_d1.graphics.p("AnzH0IAAvnIPnAAIAAPng");
  mask_cvr_d1.setTransform(152.5, 266.5, 2.71, 4.05);
  this.cvr_d1.mask = mask_cvr_d1
  this.timeline.addTween(cjs.Tween.get(this.cvr_d1).wait(1));
 }).prototype = getMCSymbolPrototype(lib.legal_01, new cjs.Rectangle(15, 62, 271, 417), null);
 (lib.car_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.car();
  this.instance.parent = this;
  this.instance.setTransform(0, 0, 0.667, 0.667);
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));
 }).prototype = getMCSymbolPrototype(lib.car_1, new cjs.Rectangle(0, 0, 251.5, 153.4), null);
 (lib.black_plate = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#282830").s().p("EgXbAnEMAAAhOHMAu3AAAMAAABOHg");
  this.shape.setTransform(150, 250);
  this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
 }).prototype = getMCSymbolPrototype(lib.black_plate, new cjs.Rectangle(0, 0, 300, 500), null);
 (lib.bg4_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.bg4();
  this.instance.parent = this;
  this.instance.setTransform(0, 0, 0.667, 0.667);
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));
 }).prototype = getMCSymbolPrototype(lib.bg4_1, new cjs.Rectangle(0, 0, 250.1, 260.8), null);
 (lib.bg3_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.bg3();
  this.instance.parent = this;
  this.instance.setTransform(0, 0, 0.667, 0.667);
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));
 }).prototype = getMCSymbolPrototype(lib.bg3_1, new cjs.Rectangle(0, 0, 250.1, 260.8), null);
 (lib.bg2_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.bg2();
  this.instance.parent = this;
  this.instance.setTransform(0, 0, 0.667, 0.667);
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));
 }).prototype = getMCSymbolPrototype(lib.bg2_1, new cjs.Rectangle(0, 0, 250.1, 260.8), null);
 (lib.bg1_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.bg1();
  this.instance.parent = this;
  this.instance.setTransform(0, 0, 0.6667, 0.6667);
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));
 }).prototype = getMCSymbolPrototype(lib.bg1_1, new cjs.Rectangle(0, 0, 250, 260.7), null);
 (lib.bg_01 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#282830").s().p("AyvfQMAAAg+fMAlfAAAMAAAA+fg");
  this.shape.setTransform(120, 200);
  this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
 }).prototype = getMCSymbolPrototype(lib.bg_01, new cjs.Rectangle(0, 0, 240, 400), null);
 (lib.arrows2 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  var mask = new cjs.Shape();
  mask._off = true;
  var mask_graphics_0 = new cjs.Graphics().p("ApSDSIAAgXISlAAIAAAXg");
  var mask_graphics_1 = new cjs.Graphics().p("ApSDSIAAgzISlAAIAAAzg");
  var mask_graphics_2 = new cjs.Graphics().p("ApSDSIAAhQISlAAIAABQg");
  var mask_graphics_3 = new cjs.Graphics().p("ApSDSIAAhsISlAAIAABsg");
  var mask_graphics_4 = new cjs.Graphics().p("ApSDRIAAiIISlAAIAACIg");
  var mask_graphics_5 = new cjs.Graphics().p("ApSDRIAAikISlAAIAACkg");
  var mask_graphics_6 = new cjs.Graphics().p("ApSDRIAAjBISlAAIAADBg");
  var mask_graphics_7 = new cjs.Graphics().p("ApSDRIAAjcISlAAIAADcg");
  var mask_graphics_8 = new cjs.Graphics().p("ApSDRIAAj5ISlAAIAAD5g");
  var mask_graphics_9 = new cjs.Graphics().p("ApSDRIAAkVISlAAIAAEVg");
  var mask_graphics_10 = new cjs.Graphics().p("ApSDRIAAkyISlAAIAAEyg");
  var mask_graphics_11 = new cjs.Graphics().p("ApSDRIAAlOISlAAIAAFOg");
  var mask_graphics_12 = new cjs.Graphics().p("ApSDRIAAlrISlAAIAAFrg");
  var mask_graphics_13 = new cjs.Graphics().p("ApSDRIAAmHISlAAIAAGHg");
  var mask_graphics_14 = new cjs.Graphics().p("ApSDSIAAmjISlAAIAAGjg");
  this.timeline.addTween(cjs.Tween.get(mask).to({
   graphics: mask_graphics_0,
   x: 59.5001,
   y: 20.9837
  }).wait(1).to({
   graphics: mask_graphics_1,
   x: 59.5001,
   y: 20.9744
  }).wait(1).to({
   graphics: mask_graphics_2,
   x: 59.5001,
   y: 20.965
  }).wait(1).to({
   graphics: mask_graphics_3,
   x: 59.5001,
   y: 20.9557
  }).wait(1).to({
   graphics: mask_graphics_4,
   x: 59.5001,
   y: 20.9464
  }).wait(1).to({
   graphics: mask_graphics_5,
   x: 59.5001,
   y: 20.937
  }).wait(1).to({
   graphics: mask_graphics_6,
   x: 59.5001,
   y: 20.9277
  }).wait(1).to({
   graphics: mask_graphics_7,
   x: 59.5001,
   y: 20.9183
  }).wait(1).to({
   graphics: mask_graphics_8,
   x: 59.5001,
   y: 20.909
  }).wait(1).to({
   graphics: mask_graphics_9,
   x: 59.5001,
   y: 20.8996
  }).wait(1).to({
   graphics: mask_graphics_10,
   x: 59.5001,
   y: 20.8903
  }).wait(1).to({
   graphics: mask_graphics_11,
   x: 59.5001,
   y: 20.8809
  }).wait(1).to({
   graphics: mask_graphics_12,
   x: 59.5001,
   y: 20.8716
  }).wait(1).to({
   graphics: mask_graphics_13,
   x: 59.5001,
   y: 20.8623
  }).wait(1).to({
   graphics: mask_graphics_14,
   x: 59.5001,
   y: 20.9999
  }).wait(1));
  this.shape = new cjs.Shape();
  this.shape.graphics.lf(["rgba(255,0,34,0.008)", "#FF0022"], [0, 0.741], -3.9, 21.3, -3.9, -17.5).s().p("AksCdQEGgwBeghQB6gqBjg3QAxgbAZgUIhmADIEniFIgNB9IhSADQgjAeg6AkQhzBIhwAfQh8AijTAeQi0AZidALg");
  this.shape.setTransform(54.375, 19.875);
  var maskedShapeInstanceList = [this.shape];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask;
  }
  this.timeline.addTween(cjs.Tween.get(this.shape).wait(15));
  var mask_1 = new cjs.Shape();
  mask_1._off = true;
  var mask_1_graphics_0 = new cjs.Graphics().p("AnvCcIOYnHIBHCQIuYHHg");
  var mask_1_graphics_1 = new cjs.Graphics().p("An5CJIOZnHIBaC2IuZHHg");
  var mask_1_graphics_2 = new cjs.Graphics().p("AoCB1IOYnHIBtDeIuYHHg");
  var mask_1_graphics_3 = new cjs.Graphics().p("AoMBiIOYnHICBEEIuYHHg");
  var mask_1_graphics_4 = new cjs.Graphics().p("AoWBOIOZnHICUEsIuZHHg");
  var mask_1_graphics_5 = new cjs.Graphics().p("AofA7IOYnHICnFSIuYHHg");
  var mask_1_graphics_6 = new cjs.Graphics().p("AopAnIOYnHIC7F6IuYHHg");
  var mask_1_graphics_7 = new cjs.Graphics().p("AozAUIOZnHIDOGgIuZHHg");
  var mask_1_graphics_8 = new cjs.Graphics().p("Ao8AAIOYnHIDhHHIuYHIg");
  var mask_1_graphics_9 = new cjs.Graphics().p("ApGgSIOYnIID1HtIuYHIg");
  var mask_1_graphics_10 = new cjs.Graphics().p("ApQgmIOZnIIEIIVIuZHIg");
  var mask_1_graphics_11 = new cjs.Graphics().p("ApZg5IOYnIIEbI7IuYHIg");
  var mask_1_graphics_12 = new cjs.Graphics().p("ApjhNIOYnIIEvJjIuYHIg");
  var mask_1_graphics_13 = new cjs.Graphics().p("ApthhIOZnHIFCKJIuZHIg");
  var mask_1_graphics_14 = new cjs.Graphics().p("Ap2h0IOYnIIFVKxIuYHIg");
  this.timeline.addTween(cjs.Tween.get(mask_1).to({
   graphics: mask_1_graphics_0,
   x: 49.5348,
   y: 27.9526
  }).wait(1).to({
   graphics: mask_1_graphics_1,
   x: 50.4961,
   y: 29.9052
  }).wait(1).to({
   graphics: mask_1_graphics_2,
   x: 51.4574,
   y: 31.8578
  }).wait(1).to({
   graphics: mask_1_graphics_3,
   x: 52.4187,
   y: 33.8105
  }).wait(1).to({
   graphics: mask_1_graphics_4,
   x: 53.38,
   y: 35.7631
  }).wait(1).to({
   graphics: mask_1_graphics_5,
   x: 54.3413,
   y: 37.7157
  }).wait(1).to({
   graphics: mask_1_graphics_6,
   x: 55.3026,
   y: 39.6683
  }).wait(1).to({
   graphics: mask_1_graphics_7,
   x: 56.2639,
   y: 41.6209
  }).wait(1).to({
   graphics: mask_1_graphics_8,
   x: 57.2252,
   y: 43.5735
  }).wait(1).to({
   graphics: mask_1_graphics_9,
   x: 58.1865,
   y: 45.5261
  }).wait(1).to({
   graphics: mask_1_graphics_10,
   x: 59.1478,
   y: 47.4787
  }).wait(1).to({
   graphics: mask_1_graphics_11,
   x: 60.1091,
   y: 49.4313
  }).wait(1).to({
   graphics: mask_1_graphics_12,
   x: 61.0704,
   y: 51.384
  }).wait(1).to({
   graphics: mask_1_graphics_13,
   x: 62.0317,
   y: 53.3366
  }).wait(1).to({
   graphics: mask_1_graphics_14,
   x: 63.0511,
   y: 55.1746
  }).wait(1));
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.lf(["rgba(255,0,34,0)", "#FF0022"], [0, 0.678], -7.5, -18.4, 7.1, 22.3).s().p("AEmAcQh2gPkygYQi3gOicgDIh3AAQBMgNDhgLQDvgMBPAIQCDAOBxAXQA4AMAeAIIA8gRICoBIIl3AFg");
  this.shape_1.setTransform(60.375, 51.4488);
  var maskedShapeInstanceList = [this.shape_1];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
  }
  this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(15));
  var mask_2 = new cjs.Shape();
  mask_2._off = true;
  var mask_2_graphics_0 = new cjs.Graphics().p("ApgEBIS4igIAJBGIy4Cfg");
  var mask_2_graphics_1 = new cjs.Graphics().p("AplDfIS5ifIASCJIy5Cfg");
  var mask_2_graphics_2 = new cjs.Graphics().p("AppDAIS5ifIAaDHIy5Cfg");
  var mask_2_graphics_3 = new cjs.Graphics().p("AptCkIS5ifIAiEAIy5Cfg");
  var mask_2_graphics_4 = new cjs.Graphics().p("ApwCKIS5ifIAoE0Iy5Cfg");
  var mask_2_graphics_5 = new cjs.Graphics().p("ApzByIS4ieIAvFjIy4Cfg");
  var mask_2_graphics_6 = new cjs.Graphics().p("Ap2BdIS5ieIA0GNIy5Cfg");
  var mask_2_graphics_7 = new cjs.Graphics().p("Ap4BKIS4ieIA5GzIy4Cfg");
  var mask_2_graphics_8 = new cjs.Graphics().p("Ap7A6IS5ieIA+HTIy5Cfg");
  var mask_2_graphics_9 = new cjs.Graphics().p("Ap8AtIS4ieIBBHuIy4Cfg");
  var mask_2_graphics_10 = new cjs.Graphics().p("Ap+AhIS5ieIBEIFIy5Cfg");
  var mask_2_graphics_11 = new cjs.Graphics().p("Ap/AZIS5ieIBGIWIy5Cfg");
  var mask_2_graphics_12 = new cjs.Graphics().p("AqAATIS5ifIBIIjIy5Cfg");
  var mask_2_graphics_13 = new cjs.Graphics().p("AqAAPIS4ieIBJIqIy4Cfg");
  var mask_2_graphics_14 = new cjs.Graphics().p("AqAANIS4ifIBJItIy4Cfg");
  this.timeline.addTween(cjs.Tween.get(mask_2).to({
   graphics: mask_2_graphics_0,
   x: 58.2841,
   y: 32.5868
  }).wait(1).to({
   graphics: mask_2_graphics_1,
   x: 58.7305,
   y: 35.9647
  }).wait(1).to({
   graphics: mask_2_graphics_2,
   x: 59.1438,
   y: 39.0923
  }).wait(1).to({
   graphics: mask_2_graphics_3,
   x: 59.5241,
   y: 41.9696
  }).wait(1).to({
   graphics: mask_2_graphics_4,
   x: 59.8713,
   y: 44.5968
  }).wait(1).to({
   graphics: mask_2_graphics_5,
   x: 60.1854,
   y: 46.9737
  }).wait(1).to({
   graphics: mask_2_graphics_6,
   x: 60.4665,
   y: 49.1004
  }).wait(1).to({
   graphics: mask_2_graphics_7,
   x: 60.7145,
   y: 50.977
  }).wait(1).to({
   graphics: mask_2_graphics_8,
   x: 60.9294,
   y: 52.6033
  }).wait(1).to({
   graphics: mask_2_graphics_9,
   x: 61.1113,
   y: 53.9794
  }).wait(1).to({
   graphics: mask_2_graphics_10,
   x: 61.2601,
   y: 55.1054
  }).wait(1).to({
   graphics: mask_2_graphics_11,
   x: 61.3758,
   y: 55.9811
  }).wait(1).to({
   graphics: mask_2_graphics_12,
   x: 61.4585,
   y: 56.6066
  }).wait(1).to({
   graphics: mask_2_graphics_13,
   x: 61.5081,
   y: 56.9819
  }).wait(1).to({
   graphics: mask_2_graphics_14,
   x: 61.4953,
   y: 56.9952
  }).wait(1));
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.lf(["rgba(255,0,34,0)", "#FF0022"], [0, 0.533], -4.8, -26.1, 3.4, 24.2).s().p("ACqB5IBQgPQgFgXgigiQhDhDiQg3Qijg+hYgVQhJgShkgGIFXgtIBcAoQBoAyA6AyQA5AyA+BFQAfAjAUAZIBSgDIgvCHg");
  this.shape_2.setTransform(54.5, 78.875);
  var maskedShapeInstanceList = [this.shape_2];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
  }
  this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(15));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(0, 0, 119.3, 101.5);
 (lib.arrow3 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.lf(["rgba(255,0,39,0)", "#FF0027"], [0, 0.486], -14.6, 38.5, 14.6, -38.4).s().p("AilEpQBYhHAmg5QAvhIANg9IAMheQAHgwATgsQATgrAbggIA8hGIgogPIBzgtIAIBcIgrgRIgaAZQgeAggYAhQgaAlgNAjQgKAfgGAxQgIBIgLAjQgVBFgvAzQgyA2hJAzQhBAtgpARQAkgYAtgjg");
  this.shape.setTransform(24.75, 35.625);
  this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
 }).prototype = getMCSymbolPrototype(lib.arrow3, new cjs.Rectangle(0, 0, 49.5, 71.3), null);
 (lib.arrow1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.lf(["rgba(255,0,34,0)", "#FF0022"], [0, 1], 0, 130.3, 0, -124).s().p("ABJTWQEjmfgWlzQgVlekqk8Qi8jJhJkhQgtiwAFioIiHAAIDAi/IDAC/IiIAAQgECVAoCgQBCELCpC1QCXChBQDDQBODCgBDOQgCDQhTDEQhYDLioCog");
  this.shape.setTransform(41.3756, 124.025);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.lf(["rgba(255,0,34,0)", "#FF0022"], [0, 1], 0, 130.3, 0, -124).s().p("ABJTWQEjmfgWlzQgVlekqk8Qi8jJhJkhQgtiwAFioIiHAAIDAi/IDAC/IiIAAQgECVAoCgQBCELCpC1QCXChBQDDQBODCgBDOQgCDQhTDEQhYDLioCog");
  this.shape_1.setTransform(121.3756, 124.025);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.lf(["rgba(255,0,34,0)", "#FF0022"], [0, 1], 0, 130.3, 0, -124).s().p("ABJTWQEjmfgWlzQgVlekqk8Qi8jJhJkhQgtiwAFioIiHAAIDAi/IDAC/IiIAAQgECVAoCgQBCELCpC1QCXChBQDDQBODCgBDOQgCDQhTDEQhYDLioCog");
  this.shape_2.setTransform(206.3756, 124.025);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
 }).prototype = getMCSymbolPrototype(lib.arrow1, new cjs.Rectangle(0, 0, 247.8, 248.1), null);
 (lib.txt06 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  var mask = new cjs.Shape();
  mask._off = true;
  mask.graphics.p("A3bIJIAAklMAu3AAAIAAElg");
  mask.setTransform(150.0057, 52.1131);
  this.instance = new lib.t06();
  this.instance.parent = this;
  this.instance.setTransform(70.7, 22.3, 1, 1, 0, 0, 0, 90.7, 22.3);
  this.instance.alpha = 0;
  var maskedShapeInstanceList = [this.instance];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({
   regX: 154.1,
   regY: 133.1,
   x: 136.9,
   y: 133.1,
   alpha: 0.1378
  }, 0).wait(1).to({
   x: 139.45,
   alpha: 0.2653
  }, 0).wait(1).to({
   x: 141.8,
   alpha: 0.3827
  }, 0).wait(1).to({
   x: 143.9,
   alpha: 0.4898
  }, 0).wait(1).to({
   x: 145.85,
   alpha: 0.5867
  }, 0).wait(1).to({
   x: 147.6,
   alpha: 0.6735
  }, 0).wait(1).to({
   x: 149.1,
   alpha: 0.75
  }, 0).wait(1).to({
   x: 150.45,
   alpha: 0.8163
  }, 0).wait(1).to({
   x: 151.55,
   alpha: 0.8724
  }, 0).wait(1).to({
   x: 152.5,
   alpha: 0.9184
  }, 0).wait(1).to({
   x: 153.2,
   alpha: 0.9541
  }, 0).wait(1).to({
   x: 153.7,
   alpha: 0.9796
  }, 0).wait(1).to({
   x: 154,
   alpha: 0.9949
  }, 0).wait(1).to({
   regX: 90.7,
   regY: 22.3,
   x: 90.7,
   y: 22.3,
   alpha: 1
  }, 0).wait(21));
  var mask_1 = new cjs.Shape();
  mask_1._off = true;
  mask_1.graphics.p("A3bMPIAAoPMAu3AAAIAAIPg");
  mask_1.setTransform(150.0057, 78.2983);
  this.instance_1 = new lib.t06();
  this.instance_1.parent = this;
  this.instance_1.setTransform(70.7, 22.3, 1, 1, 0, 0, 0, 90.7, 22.3);
  this.instance_1.alpha = 0;
  this.instance_1._off = true;
  var maskedShapeInstanceList = [this.instance_1];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(5).to({
   _off: false
  }, 0).wait(1).to({
   regX: 154.1,
   regY: 133.1,
   x: 136.9,
   y: 133.1,
   alpha: 0.1378
  }, 0).wait(1).to({
   x: 139.45,
   alpha: 0.2653
  }, 0).wait(1).to({
   x: 141.8,
   alpha: 0.3827
  }, 0).wait(1).to({
   x: 143.9,
   alpha: 0.4898
  }, 0).wait(1).to({
   x: 145.85,
   alpha: 0.5867
  }, 0).wait(1).to({
   x: 147.6,
   alpha: 0.6735
  }, 0).wait(1).to({
   x: 149.1,
   alpha: 0.75
  }, 0).wait(1).to({
   x: 150.45,
   alpha: 0.8163
  }, 0).wait(1).to({
   x: 151.55,
   alpha: 0.8724
  }, 0).wait(1).to({
   x: 152.5,
   alpha: 0.9184
  }, 0).wait(1).to({
   x: 153.2,
   alpha: 0.9541
  }, 0).wait(1).to({
   x: 153.7,
   alpha: 0.9796
  }, 0).wait(1).to({
   x: 154,
   alpha: 0.9949
  }, 0).wait(1).to({
   regX: 90.7,
   regY: 22.3,
   x: 90.7,
   y: 22.3,
   alpha: 1
  }, 0).wait(16));
  var mask_2 = new cjs.Shape();
  mask_2._off = true;
  mask_2.graphics.p("A3bO0IAAlKMAu3AAAIAAFKg");
  mask_2.setTransform(150.0057, 94.8114);
  this.instance_2 = new lib.t06();
  this.instance_2.parent = this;
  this.instance_2.setTransform(70.7, 22.3, 1, 1, 0, 0, 0, 90.7, 22.3);
  this.instance_2.alpha = 0;
  this.instance_2._off = true;
  var maskedShapeInstanceList = [this.instance_2];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(10).to({
   _off: false
  }, 0).wait(1).to({
   regX: 154.1,
   regY: 133.1,
   x: 136.9,
   y: 133.1,
   alpha: 0.1378
  }, 0).wait(1).to({
   x: 139.45,
   alpha: 0.2653
  }, 0).wait(1).to({
   x: 141.8,
   alpha: 0.3827
  }, 0).wait(1).to({
   x: 143.9,
   alpha: 0.4898
  }, 0).wait(1).to({
   x: 145.85,
   alpha: 0.5867
  }, 0).wait(1).to({
   x: 147.6,
   alpha: 0.6735
  }, 0).wait(1).to({
   x: 149.1,
   alpha: 0.75
  }, 0).wait(1).to({
   x: 150.45,
   alpha: 0.8163
  }, 0).wait(1).to({
   x: 151.55,
   alpha: 0.8724
  }, 0).wait(1).to({
   x: 152.5,
   alpha: 0.9184
  }, 0).wait(1).to({
   x: 153.2,
   alpha: 0.9541
  }, 0).wait(1).to({
   x: 153.7,
   alpha: 0.9796
  }, 0).wait(1).to({
   x: 154,
   alpha: 0.9949
  }, 0).wait(1).to({
   regX: 90.7,
   regY: 22.3,
   x: 90.7,
   y: 22.3,
   alpha: 1
  }, 0).wait(11));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(0, 75, 295, 113.80000000000001);
 (lib.txt05 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  var mask = new cjs.Shape();
  mask._off = true;
  mask.graphics.p("A0EIrIAAj6MAoJAAAIAAD6g");
  mask.setTransform(128.5, 55.4584);
  this.instance = new lib.t05();
  this.instance.parent = this;
  this.instance.setTransform(70.7, 22.3, 1, 1, 0, 0, 0, 90.7, 22.3);
  this.instance.alpha = 0;
  var maskedShapeInstanceList = [this.instance];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({
   regX: 127.6,
   regY: 114,
   x: 110.4,
   y: 114,
   alpha: 0.1378
  }, 0).wait(1).to({
   x: 112.95,
   alpha: 0.2653
  }, 0).wait(1).to({
   x: 115.3,
   alpha: 0.3827
  }, 0).wait(1).to({
   x: 117.4,
   alpha: 0.4898
  }, 0).wait(1).to({
   x: 119.35,
   alpha: 0.5867
  }, 0).wait(1).to({
   x: 121.1,
   alpha: 0.6735
  }, 0).wait(1).to({
   x: 122.6,
   alpha: 0.75
  }, 0).wait(1).to({
   x: 123.95,
   alpha: 0.8163
  }, 0).wait(1).to({
   x: 125.05,
   alpha: 0.8724
  }, 0).wait(1).to({
   x: 126,
   alpha: 0.9184
  }, 0).wait(1).to({
   x: 126.7,
   alpha: 0.9541
  }, 0).wait(1).to({
   x: 127.2,
   alpha: 0.9796
  }, 0).wait(1).to({
   x: 127.5,
   alpha: 0.9949
  }, 0).wait(1).to({
   regX: 90.7,
   regY: 22.3,
   x: 90.7,
   y: 22.3,
   alpha: 1
  }, 0).wait(21));
  var mask_1 = new cjs.Shape();
  mask_1._off = true;
  mask_1.graphics.p("A0EM8IAAohMAoJAAAIAAIhg");
  mask_1.setTransform(128.5, 82.8213);
  this.instance_1 = new lib.t05();
  this.instance_1.parent = this;
  this.instance_1.setTransform(70.7, 22.3, 1, 1, 0, 0, 0, 90.7, 22.3);
  this.instance_1.alpha = 0;
  this.instance_1._off = true;
  var maskedShapeInstanceList = [this.instance_1];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(5).to({
   _off: false
  }, 0).wait(1).to({
   regX: 127.6,
   regY: 114,
   x: 110.4,
   y: 114,
   alpha: 0.1378
  }, 0).wait(1).to({
   x: 112.95,
   alpha: 0.2653
  }, 0).wait(1).to({
   x: 115.3,
   alpha: 0.3827
  }, 0).wait(1).to({
   x: 117.4,
   alpha: 0.4898
  }, 0).wait(1).to({
   x: 119.35,
   alpha: 0.5867
  }, 0).wait(1).to({
   x: 121.1,
   alpha: 0.6735
  }, 0).wait(1).to({
   x: 122.6,
   alpha: 0.75
  }, 0).wait(1).to({
   x: 123.95,
   alpha: 0.8163
  }, 0).wait(1).to({
   x: 125.05,
   alpha: 0.8724
  }, 0).wait(1).to({
   x: 126,
   alpha: 0.9184
  }, 0).wait(1).to({
   x: 126.7,
   alpha: 0.9541
  }, 0).wait(1).to({
   x: 127.2,
   alpha: 0.9796
  }, 0).wait(1).to({
   x: 127.5,
   alpha: 0.9949
  }, 0).wait(1).to({
   regX: 90.7,
   regY: 22.3,
   x: 90.7,
   y: 22.3,
   alpha: 1
  }, 0).wait(16));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(0, 86, 257, 56.19999999999999);
 (lib.txt04 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  var mask = new cjs.Shape();
  mask._off = true;
  mask.graphics.p("A2aI3IAAkXMAs1AAAIAAEXg");
  mask.setTransform(143.5116, 56.6569);
  this.instance = new lib.t04();
  this.instance.parent = this;
  this.instance.setTransform(70.7, 22.3, 1, 1, 0, 0, 0, 90.7, 22.3);
  this.instance.alpha = 0;
  var maskedShapeInstanceList = [this.instance];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({
   regX: 128.3,
   regY: 114,
   x: 111.1,
   y: 114,
   alpha: 0.1378
  }, 0).wait(1).to({
   x: 113.65,
   alpha: 0.2653
  }, 0).wait(1).to({
   x: 116,
   alpha: 0.3827
  }, 0).wait(1).to({
   x: 118.1,
   alpha: 0.4898
  }, 0).wait(1).to({
   x: 120.05,
   alpha: 0.5867
  }, 0).wait(1).to({
   x: 121.8,
   alpha: 0.6735
  }, 0).wait(1).to({
   x: 123.3,
   alpha: 0.75
  }, 0).wait(1).to({
   x: 124.65,
   alpha: 0.8163
  }, 0).wait(1).to({
   x: 125.75,
   alpha: 0.8724
  }, 0).wait(1).to({
   x: 126.7,
   alpha: 0.9184
  }, 0).wait(1).to({
   x: 127.4,
   alpha: 0.9541
  }, 0).wait(1).to({
   x: 127.9,
   alpha: 0.9796
  }, 0).wait(1).to({
   x: 128.2,
   alpha: 0.9949
  }, 0).wait(1).to({
   regX: 90.7,
   regY: 22.3,
   x: 90.7,
   y: 22.3,
   alpha: 1
  }, 0).wait(21));
  var mask_1 = new cjs.Shape();
  mask_1._off = true;
  mask_1.graphics.p("A2aLCIAAkWMAs1AAAIAAEWg");
  mask_1.setTransform(143.5116, 70.6319);
  this.instance_1 = new lib.t04();
  this.instance_1.parent = this;
  this.instance_1.setTransform(70.7, 22.3, 1, 1, 0, 0, 0, 90.7, 22.3);
  this.instance_1.alpha = 0;
  this.instance_1._off = true;
  var maskedShapeInstanceList = [this.instance_1];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(5).to({
   _off: false
  }, 0).wait(1).to({
   regX: 128.3,
   regY: 114,
   x: 111.1,
   y: 114,
   alpha: 0.1378
  }, 0).wait(1).to({
   x: 113.65,
   alpha: 0.2653
  }, 0).wait(1).to({
   x: 116,
   alpha: 0.3827
  }, 0).wait(1).to({
   x: 118.1,
   alpha: 0.4898
  }, 0).wait(1).to({
   x: 120.05,
   alpha: 0.5867
  }, 0).wait(1).to({
   x: 121.8,
   alpha: 0.6735
  }, 0).wait(1).to({
   x: 123.3,
   alpha: 0.75
  }, 0).wait(1).to({
   x: 124.65,
   alpha: 0.8163
  }, 0).wait(1).to({
   x: 125.75,
   alpha: 0.8724
  }, 0).wait(1).to({
   x: 126.7,
   alpha: 0.9184
  }, 0).wait(1).to({
   x: 127.4,
   alpha: 0.9541
  }, 0).wait(1).to({
   x: 127.9,
   alpha: 0.9796
  }, 0).wait(1).to({
   x: 128.2,
   alpha: 0.9949
  }, 0).wait(1).to({
   regX: 90.7,
   regY: 22.3,
   x: 90.7,
   y: 22.3,
   alpha: 1
  }, 0).wait(16));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(0, 85.5, 271, 55.80000000000001);
 (lib.txt03 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  var mask = new cjs.Shape();
  mask._off = true;
  mask.graphics.p("A2LI8IAAkUMAsXAAAIAAEUg");
  mask.setTransform(141.993, 57.1817);
  this.instance = new lib.t03();
  this.instance.parent = this;
  this.instance.setTransform(70.7, 22.3, 1, 1, 0, 0, 0, 90.7, 22.3);
  this.instance.alpha = 0;
  var maskedShapeInstanceList = [this.instance];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({
   regX: 128.2,
   regY: 130,
   x: 111,
   y: 130,
   alpha: 0.1378
  }, 0).wait(1).to({
   x: 113.55,
   alpha: 0.2653
  }, 0).wait(1).to({
   x: 115.9,
   alpha: 0.3827
  }, 0).wait(1).to({
   x: 118,
   alpha: 0.4898
  }, 0).wait(1).to({
   x: 119.95,
   alpha: 0.5867
  }, 0).wait(1).to({
   x: 121.7,
   alpha: 0.6735
  }, 0).wait(1).to({
   x: 123.2,
   alpha: 0.75
  }, 0).wait(1).to({
   x: 124.55,
   alpha: 0.8163
  }, 0).wait(1).to({
   x: 125.65,
   alpha: 0.8724
  }, 0).wait(1).to({
   x: 126.6,
   alpha: 0.9184
  }, 0).wait(1).to({
   x: 127.3,
   alpha: 0.9541
  }, 0).wait(1).to({
   x: 127.8,
   alpha: 0.9796
  }, 0).wait(1).to({
   x: 128.1,
   alpha: 0.9949
  }, 0).wait(1).to({
   regX: 90.7,
   regY: 22.3,
   x: 90.7,
   y: 22.3,
   alpha: 1
  }, 0).wait(21));
  var mask_1 = new cjs.Shape();
  mask_1._off = true;
  mask_1.graphics.p("A2LLGIAAkUMAsXAAAIAAEUg");
  mask_1.setTransform(141.993, 70.9567);
  this.instance_1 = new lib.t03();
  this.instance_1.parent = this;
  this.instance_1.setTransform(70.7, 22.3, 1, 1, 0, 0, 0, 90.7, 22.3);
  this.instance_1.alpha = 0;
  this.instance_1._off = true;
  var maskedShapeInstanceList = [this.instance_1];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(5).to({
   _off: false
  }, 0).wait(1).to({
   regX: 128.2,
   regY: 130,
   x: 111,
   y: 130,
   alpha: 0.1378
  }, 0).wait(1).to({
   x: 113.55,
   alpha: 0.2653
  }, 0).wait(1).to({
   x: 115.9,
   alpha: 0.3827
  }, 0).wait(1).to({
   x: 118,
   alpha: 0.4898
  }, 0).wait(1).to({
   x: 119.95,
   alpha: 0.5867
  }, 0).wait(1).to({
   x: 121.7,
   alpha: 0.6735
  }, 0).wait(1).to({
   x: 123.2,
   alpha: 0.75
  }, 0).wait(1).to({
   x: 124.55,
   alpha: 0.8163
  }, 0).wait(1).to({
   x: 125.65,
   alpha: 0.8724
  }, 0).wait(1).to({
   x: 126.6,
   alpha: 0.9184
  }, 0).wait(1).to({
   x: 127.3,
   alpha: 0.9541
  }, 0).wait(1).to({
   x: 127.8,
   alpha: 0.9796
  }, 0).wait(1).to({
   x: 128.1,
   alpha: 0.9949
  }, 0).wait(1).to({
   regX: 90.7,
   regY: 22.3,
   x: 90.7,
   y: 22.3,
   alpha: 1
  }, 0).wait(16));
  var mask_2 = new cjs.Shape();
  mask_2._off = true;
  mask_2.graphics.p("A2LNPIAAkTMAsXAAAIAAETg");
  mask_2.setTransform(141.993, 84.7317);
  this.instance_2 = new lib.t03();
  this.instance_2.parent = this;
  this.instance_2.setTransform(70.7, 22.3, 1, 1, 0, 0, 0, 90.7, 22.3);
  this.instance_2.alpha = 0;
  this.instance_2._off = true;
  var maskedShapeInstanceList = [this.instance_2];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(10).to({
   _off: false
  }, 0).wait(1).to({
   regX: 128.2,
   regY: 130,
   x: 111,
   y: 130,
   alpha: 0.1378
  }, 0).wait(1).to({
   x: 113.55,
   alpha: 0.2653
  }, 0).wait(1).to({
   x: 115.9,
   alpha: 0.3827
  }, 0).wait(1).to({
   x: 118,
   alpha: 0.4898
  }, 0).wait(1).to({
   x: 119.95,
   alpha: 0.5867
  }, 0).wait(1).to({
   x: 121.7,
   alpha: 0.6735
  }, 0).wait(1).to({
   x: 123.2,
   alpha: 0.75
  }, 0).wait(1).to({
   x: 124.55,
   alpha: 0.8163
  }, 0).wait(1).to({
   x: 125.65,
   alpha: 0.8724
  }, 0).wait(1).to({
   x: 126.6,
   alpha: 0.9184
  }, 0).wait(1).to({
   x: 127.3,
   alpha: 0.9541
  }, 0).wait(1).to({
   x: 127.8,
   alpha: 0.9796
  }, 0).wait(1).to({
   x: 128.1,
   alpha: 0.9949
  }, 0).wait(1).to({
   regX: 90.7,
   regY: 22.3,
   x: 90.7,
   y: 22.3,
   alpha: 1
  }, 0).wait(11));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(0, 86.8, 265, 82.7);
 (lib.txt02 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  var mask = new cjs.Shape();
  mask._off = true;
  mask.graphics.p("A2LJNIAAk0MAsXAAAIAAE0g");
  mask.setTransform(141.996, 58.9051);
  this.instance = new lib.t02();
  this.instance.parent = this;
  this.instance.setTransform(70.7, 22.3, 1, 1, 0, 0, 0, 90.7, 22.3);
  this.instance.alpha = 0;
  var maskedShapeInstanceList = [this.instance];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({
   regX: 147.9,
   regY: 118.2,
   x: 130.7,
   y: 118.2,
   alpha: 0.1378
  }, 0).wait(1).to({
   x: 133.25,
   alpha: 0.2653
  }, 0).wait(1).to({
   x: 135.6,
   alpha: 0.3827
  }, 0).wait(1).to({
   x: 137.7,
   alpha: 0.4898
  }, 0).wait(1).to({
   x: 139.65,
   alpha: 0.5867
  }, 0).wait(1).to({
   x: 141.4,
   alpha: 0.6735
  }, 0).wait(1).to({
   x: 142.9,
   alpha: 0.75
  }, 0).wait(1).to({
   x: 144.25,
   alpha: 0.8163
  }, 0).wait(1).to({
   x: 145.35,
   alpha: 0.8724
  }, 0).wait(1).to({
   x: 146.3,
   alpha: 0.9184
  }, 0).wait(1).to({
   x: 147,
   alpha: 0.9541
  }, 0).wait(1).to({
   x: 147.5,
   alpha: 0.9796
  }, 0).wait(1).to({
   x: 147.8,
   alpha: 0.9949
  }, 0).wait(1).to({
   regX: 90.7,
   regY: 22.3,
   x: 90.7,
   y: 22.3,
   alpha: 1
  }, 0).wait(21));
  var mask_1 = new cjs.Shape();
  mask_1._off = true;
  mask_1.graphics.p("A2LLnIAAk0MAsXAAAIAAE0g");
  mask_1.setTransform(141.996, 74.2801);
  this.instance_1 = new lib.t02();
  this.instance_1.parent = this;
  this.instance_1.setTransform(70.7, 22.3, 1, 1, 0, 0, 0, 90.7, 22.3);
  this.instance_1.alpha = 0;
  this.instance_1._off = true;
  var maskedShapeInstanceList = [this.instance_1];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(5).to({
   _off: false
  }, 0).wait(1).to({
   regX: 147.9,
   regY: 118.2,
   x: 130.7,
   y: 118.2,
   alpha: 0.1378
  }, 0).wait(1).to({
   x: 133.25,
   alpha: 0.2653
  }, 0).wait(1).to({
   x: 135.6,
   alpha: 0.3827
  }, 0).wait(1).to({
   x: 137.7,
   alpha: 0.4898
  }, 0).wait(1).to({
   x: 139.65,
   alpha: 0.5867
  }, 0).wait(1).to({
   x: 141.4,
   alpha: 0.6735
  }, 0).wait(1).to({
   x: 142.9,
   alpha: 0.75
  }, 0).wait(1).to({
   x: 144.25,
   alpha: 0.8163
  }, 0).wait(1).to({
   x: 145.35,
   alpha: 0.8724
  }, 0).wait(1).to({
   x: 146.3,
   alpha: 0.9184
  }, 0).wait(1).to({
   x: 147,
   alpha: 0.9541
  }, 0).wait(1).to({
   x: 147.5,
   alpha: 0.9796
  }, 0).wait(1).to({
   x: 147.8,
   alpha: 0.9949
  }, 0).wait(1).to({
   regX: 90.7,
   regY: 22.3,
   x: 90.7,
   y: 22.3,
   alpha: 1
  }, 0).wait(16));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(0, 87.1, 284, 61.5);
 (lib.txt01 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  var mask = new cjs.Shape();
  mask._off = true;
  mask.graphics.p("AyWDCIAAl5MAktAAAIAAF5g");
  mask.setTransform(117.511, 19.3673);
  this.instance = new lib.t01();
  this.instance.parent = this;
  this.instance.setTransform(70.7, 22.3, 1, 1, 0, 0, 0, 90.7, 22.3);
  this.instance.alpha = 0;
  var maskedShapeInstanceList = [this.instance];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({
   regX: 96.8,
   regY: 38.1,
   x: 79.6,
   y: 38.1,
   alpha: 0.1378
  }, 0).wait(1).to({
   x: 82.15,
   alpha: 0.2653
  }, 0).wait(1).to({
   x: 84.5,
   alpha: 0.3827
  }, 0).wait(1).to({
   x: 86.6,
   alpha: 0.4898
  }, 0).wait(1).to({
   x: 88.55,
   alpha: 0.5867
  }, 0).wait(1).to({
   x: 90.3,
   alpha: 0.6735
  }, 0).wait(1).to({
   x: 91.8,
   alpha: 0.75
  }, 0).wait(1).to({
   x: 93.15,
   alpha: 0.8163
  }, 0).wait(1).to({
   x: 94.25,
   alpha: 0.8724
  }, 0).wait(1).to({
   x: 95.2,
   alpha: 0.9184
  }, 0).wait(1).to({
   x: 95.9,
   alpha: 0.9541
  }, 0).wait(1).to({
   x: 96.4,
   alpha: 0.9796
  }, 0).wait(1).to({
   x: 96.7,
   alpha: 0.9949
  }, 0).wait(1).to({
   regX: 90.7,
   regY: 22.3,
   x: 90.7,
   y: 22.3,
   alpha: 1
  }, 0).wait(16));
  var mask_1 = new cjs.Shape();
  mask_1._off = true;
  mask_1.graphics.p("AyWFkIAAlHMAktAAAIAAFHg");
  mask_1.setTransform(117.511, 35.6089);
  this.instance_1 = new lib.t01();
  this.instance_1.parent = this;
  this.instance_1.setTransform(70.7, 22.3, 1, 1, 0, 0, 0, 90.7, 22.3);
  this.instance_1.alpha = 0;
  this.instance_1._off = true;
  var maskedShapeInstanceList = [this.instance_1];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(4).to({
   _off: false
  }, 0).wait(1).to({
   regX: 96.8,
   regY: 38.1,
   x: 79.6,
   y: 38.1,
   alpha: 0.1378
  }, 0).wait(1).to({
   x: 82.15,
   alpha: 0.2653
  }, 0).wait(1).to({
   x: 84.5,
   alpha: 0.3827
  }, 0).wait(1).to({
   x: 86.6,
   alpha: 0.4898
  }, 0).wait(1).to({
   x: 88.55,
   alpha: 0.5867
  }, 0).wait(1).to({
   x: 90.3,
   alpha: 0.6735
  }, 0).wait(1).to({
   x: 91.8,
   alpha: 0.75
  }, 0).wait(1).to({
   x: 93.15,
   alpha: 0.8163
  }, 0).wait(1).to({
   x: 94.25,
   alpha: 0.8724
  }, 0).wait(1).to({
   x: 95.2,
   alpha: 0.9184
  }, 0).wait(1).to({
   x: 95.9,
   alpha: 0.9541
  }, 0).wait(1).to({
   x: 96.4,
   alpha: 0.9796
  }, 0).wait(1).to({
   x: 96.7,
   alpha: 0.9949
  }, 0).wait(1).to({
   regX: 90.7,
   regY: 22.3,
   x: 90.7,
   y: 22.3,
   alpha: 1
  }, 0).wait(12));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(0, 3, 195.5, 65.3);
 (lib.arrows3 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  var mask = new cjs.Shape();
  mask._off = true;
  var mask_graphics_0 = new cjs.Graphics().p("AqsC/IAPg2IVKF+IgPA2g");
  var mask_graphics_1 = new cjs.Graphics().p("Aq7C/IAuikIVJF+IguCkg");
  var mask_graphics_2 = new cjs.Graphics().p("ArKC/IBLkIIVKF8IhLEKg");
  var mask_graphics_3 = new cjs.Graphics().p("ArXC/IBllmIVKF8IhlFog");
  var mask_graphics_4 = new cjs.Graphics().p("ArjC/IB9m8IVKF9Ih9G9g");
  var mask_graphics_5 = new cjs.Graphics().p("AruC/ICToJIVKF9IiTIKg");
  var mask_graphics_6 = new cjs.Graphics().p("Ar4C/ICnpOIVKF9IinJPg");
  var mask_graphics_7 = new cjs.Graphics().p("AsAC/IC4qLIVJF9Ii4KMg");
  var mask_graphics_8 = new cjs.Graphics().p("AsIC/IDHrAIVKF9IjHLBg");
  var mask_graphics_9 = new cjs.Graphics().p("AsOC/IDTrtIVKF9IjTLug");
  var mask_graphics_10 = new cjs.Graphics().p("AsTDLIDesSIVJF9IjeMSg");
  var mask_graphics_11 = new cjs.Graphics().p("AsXDZIDmsvIVJF+IjmMvg");
  var mask_graphics_12 = new cjs.Graphics().p("AsaDjIDrtDIVKF+IjrNDg");
  var mask_graphics_13 = new cjs.Graphics().p("AscDpIDvtPIVKF+IjvNPg");
  var mask_graphics_14 = new cjs.Graphics().p("AscDrIDwtTIVJF+IjwNTg");
  this.timeline.addTween(cjs.Tween.get(mask).to({
   graphics: mask_graphics_0,
   x: 67.0739,
   y: 57.2651
  }).wait(1).to({
   graphics: mask_graphics_1,
   x: 68.6053,
   y: 57.2656
  }).wait(1).to({
   graphics: mask_graphics_2,
   x: 70.0234,
   y: 57.2661
  }).wait(1).to({
   graphics: mask_graphics_3,
   x: 71.3279,
   y: 57.2665
  }).wait(1).to({
   graphics: mask_graphics_4,
   x: 72.5191,
   y: 57.2669
  }).wait(1).to({
   graphics: mask_graphics_5,
   x: 73.5968,
   y: 57.2673
  }).wait(1).to({
   graphics: mask_graphics_6,
   x: 74.561,
   y: 57.2676
  }).wait(1).to({
   graphics: mask_graphics_7,
   x: 75.4118,
   y: 57.2679
  }).wait(1).to({
   graphics: mask_graphics_8,
   x: 76.1492,
   y: 57.2681
  }).wait(1).to({
   graphics: mask_graphics_9,
   x: 76.7731,
   y: 57.2683
  }).wait(1).to({
   graphics: mask_graphics_10,
   x: 77.2836,
   y: 56.1081
  }).wait(1).to({
   graphics: mask_graphics_11,
   x: 77.6807,
   y: 54.6825
  }).wait(1).to({
   graphics: mask_graphics_12,
   x: 77.9643,
   y: 53.6643
  }).wait(1).to({
   graphics: mask_graphics_13,
   x: 78.1344,
   y: 53.0533
  }).wait(1).to({
   graphics: mask_graphics_14,
   x: 78.3266,
   y: 52.8879
  }).wait(1));
  this.instance = new lib.arrow3();
  this.instance.parent = this;
  this.instance.setTransform(122.8, 63.85, 1, 1, 0, 0, 0, 24.8, 35.6);
  this.instance_1 = new lib.arrow3();
  this.instance_1.parent = this;
  this.instance_1.setTransform(98.05, 56.35, 1, 1, 0, 0, 0, 24.8, 35.6);
  this.instance_2 = new lib.arrow3();
  this.instance_2.parent = this;
  this.instance_2.setTransform(73.3, 49.1, 1, 1, 0, 0, 0, 24.8, 35.6);
  this.instance_3 = new lib.arrow3();
  this.instance_3.parent = this;
  this.instance_3.setTransform(49.3, 41.85, 1, 1, 0, 0, 0, 24.8, 35.6);
  this.instance_4 = new lib.arrow3();
  this.instance_4.parent = this;
  this.instance_4.setTransform(24.8, 35.6, 1, 1, 0, 0, 0, 24.8, 35.6);
  var maskedShapeInstanceList = [this.instance, this.instance_1, this.instance_2, this.instance_3, this.instance_4];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask;
  }
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.instance_4
   }, {
    t: this.instance_3
   }, {
    t: this.instance_2
   }, {
    t: this.instance_1
   }, {
    t: this.instance
   }]
  }).wait(15));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(0, 0, 147.5, 99.5);
 (lib.arrow = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  var mask = new cjs.Shape();
  mask._off = true;
  var mask_graphics_0 = new cjs.Graphics().p("EAOCB62IAAkQMAt5AAAIAAEQg");
  var mask_graphics_1 = new cjs.Graphics().p("EAOCB62IAAmNMAt5AAAIAAGNg");
  var mask_graphics_2 = new cjs.Graphics().p("EAOCB63IAAoKMAt5AAAIAAIKg");
  var mask_graphics_3 = new cjs.Graphics().p("EAOCB63IAAqHMAt5AAAIAAKHg");
  var mask_graphics_4 = new cjs.Graphics().p("EAOCB63IAAsDMAt5AAAIAAMDg");
  var mask_graphics_5 = new cjs.Graphics().p("EAOCB63IAAuAMAt5AAAIAAOAg");
  var mask_graphics_6 = new cjs.Graphics().p("EAOCB63IAAv8MAt5AAAIAAP8g");
  var mask_graphics_7 = new cjs.Graphics().p("EAOCB64IAAx6MAt5AAAIAAR6g");
  var mask_graphics_8 = new cjs.Graphics().p("EAOCB64IAAz3MAt5AAAIAAT3g");
  var mask_graphics_9 = new cjs.Graphics().p("EAOCB64IAA1zMAt5AAAIAAVzg");
  var mask_graphics_10 = new cjs.Graphics().p("EAOCB64IAA3wMAt5AAAIAAXwg");
  var mask_graphics_11 = new cjs.Graphics().p("EAOCB65IAA5tMAt5AAAIAAZtg");
  var mask_graphics_12 = new cjs.Graphics().p("EAOCB65IAA7qMAt5AAAIAAbqg");
  var mask_graphics_13 = new cjs.Graphics().p("EAOCB65IAA9mMAt5AAAIAAdmg");
  var mask_graphics_14 = new cjs.Graphics().p("EAOCB65IAA/jMAt5AAAIAAfjg");
  var mask_graphics_15 = new cjs.Graphics().p("EAOCB65MAAAghfMAt5AAAMAAAAhfg");
  var mask_graphics_16 = new cjs.Graphics().p("EAOCB66MAAAgjdMAt5AAAMAAAAjdg");
  var mask_graphics_17 = new cjs.Graphics().p("EAOCB66MAAAglZMAt5AAAMAAAAlZg");
  var mask_graphics_18 = new cjs.Graphics().p("EAOCB66MAAAgnWMAt5AAAMAAAAnWg");
  var mask_graphics_19 = new cjs.Graphics().p("EAOCB66MAAAgpTMAt5AAAMAAAApTg");
  var mask_graphics_20 = new cjs.Graphics().p("EAOCB66MAAAgrPMAt5AAAMAAAArPg");
  var mask_graphics_21 = new cjs.Graphics().p("EAOCB61MAAAgtMMAt5AAAMAAAAtMg");
  this.timeline.addTween(cjs.Tween.get(mask).to({
   graphics: mask_graphics_0,
   x: 383.5248,
   y: 786.2192
  }).wait(1).to({
   graphics: mask_graphics_1,
   x: 383.5248,
   y: 786.2406
  }).wait(1).to({
   graphics: mask_graphics_2,
   x: 383.5248,
   y: 786.2619
  }).wait(1).to({
   graphics: mask_graphics_3,
   x: 383.5248,
   y: 786.2832
  }).wait(1).to({
   graphics: mask_graphics_4,
   x: 383.5248,
   y: 786.3045
  }).wait(1).to({
   graphics: mask_graphics_5,
   x: 383.5248,
   y: 786.3259
  }).wait(1).to({
   graphics: mask_graphics_6,
   x: 383.5248,
   y: 786.3472
  }).wait(1).to({
   graphics: mask_graphics_7,
   x: 383.5248,
   y: 786.3685
  }).wait(1).to({
   graphics: mask_graphics_8,
   x: 383.5248,
   y: 786.3899
  }).wait(1).to({
   graphics: mask_graphics_9,
   x: 383.5248,
   y: 786.4112
  }).wait(1).to({
   graphics: mask_graphics_10,
   x: 383.5248,
   y: 786.4325
  }).wait(1).to({
   graphics: mask_graphics_11,
   x: 383.5248,
   y: 786.4538
  }).wait(1).to({
   graphics: mask_graphics_12,
   x: 383.5248,
   y: 786.4752
  }).wait(1).to({
   graphics: mask_graphics_13,
   x: 383.5248,
   y: 786.4965
  }).wait(1).to({
   graphics: mask_graphics_14,
   x: 383.5248,
   y: 786.5178
  }).wait(1).to({
   graphics: mask_graphics_15,
   x: 383.5248,
   y: 786.5391
  }).wait(1).to({
   graphics: mask_graphics_16,
   x: 383.5248,
   y: 786.5605
  }).wait(1).to({
   graphics: mask_graphics_17,
   x: 383.5248,
   y: 786.5818
  }).wait(1).to({
   graphics: mask_graphics_18,
   x: 383.5248,
   y: 786.6031
  }).wait(1).to({
   graphics: mask_graphics_19,
   x: 383.5248,
   y: 786.6245
  }).wait(1).to({
   graphics: mask_graphics_20,
   x: 383.5248,
   y: 786.6458
  }).wait(1).to({
   graphics: mask_graphics_21,
   x: 383.5248,
   y: 786.0887
  }).wait(1));
  this.instance = new lib.arrow1();
  this.instance.parent = this;
  this.instance.setTransform(608.8, 1421.5, 1, 1, 0, 0, 0, 123.9, 124);
  var maskedShapeInstanceList = [this.instance];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(22));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(484.9, 1297.5, 247.80000000000007, 248.0999999999999);
 (lib.content = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {
   cvr_frame1: 69,
   cvr_frame2_1: 184,
   cvr_frame3_2: 273,
   cvr_frame4_2: 354,
   "cvr_frame#5_1": 430,
   cvr_stay: 440
  });
  this.frame_440 = function() {
   if (!this.cycle) this.cycle = 0;
   this.cycle++;
   var frames = this.duration * this.cycle + this.currentFrame;
   if (frames / createjs.Ticker.getMeasuredFPS() > 30) {
    if (this.cycle > 1) {
     _globalStop(this.stage);
    } else {
     var stopFrame = this.currentFrame;
     var tst = cjs.Tween.get(this);
     this.timeline.addTween(cjs.Tween.get(this).wait(this.duration - 1).call(function() {
      globalGotoAndStop(stopFrame);
     }));
    }
   }
  }
  this.timeline.addTween(cjs.Tween.get(this).wait(440).call(this.frame_440));
  this.instance = new lib.logo_s();
  this.instance.parent = this;
  this.instance.setTransform(232.9, 16.1, 1.25, 1.2476, 0, 0, 0, -0.1, 0.1);
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(465));
  this.instance_1 = new lib.legal_01();
  this.instance_1.parent = this;
  this.instance_1.setTransform(120, 200, 1, 1, 0, 0, 0, 120, 200);
  this.instance_1._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(459).to({
   _off: false
  }, 0).to({
   _off: true
  }, 1).wait(5));
  this.instance_2 = new lib.black_plate();
  this.instance_2.parent = this;
  this.timeline.addTween(cjs.Tween.get(this.instance_2).to({
   alpha: 0
  }, 14, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(434).to({
   _off: false
  }, 0).to({
   alpha: 1
  }, 10, cjs.Ease.get(1)).wait(6));
  this.instance_3 = new lib.snoska2("synched", 0, false);
  this.instance_3.parent = this;
  this.instance_3.alpha = 0;
  this.instance_3._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(24).to({
   _off: false
  }, 0).to({
   alpha: 1
  }, 15, cjs.Ease.get(1)).wait(335).to({
   startPosition: 0
  }, 0).to({
   alpha: 0
  }, 14, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(76));
  this.instance_4 = new lib.snoska("synched", 0, false);
  this.instance_4.parent = this;
  this.instance_4.alpha = 0;
  this.instance_4._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(374).to({
   _off: false
  }, 0).to({
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(77));
  this.instance_5 = new lib.txt06("synched", 0, false);
  this.instance_5.parent = this;
  this.instance_5._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(374).to({
   _off: false
  }, 0).wait(91));
  this.instance_6 = new lib.txt05("synched", 0, false);
  this.instance_6.parent = this;
  this.instance_6._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(289).to({
   _off: false
  }, 0).wait(70).to({
   startPosition: 34
  }, 0).to({
   alpha: 0
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(90));
  this.instance_7 = new lib.txt04("synched", 0, false);
  this.instance_7.parent = this;
  this.instance_7._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(209).to({
   _off: false
  }, 0).wait(65).to({
   startPosition: 34
  }, 0).to({
   alpha: 0
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(175));
  this.instance_8 = new lib.txt03("synched", 0, false);
  this.instance_8.parent = this;
  this.instance_8._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(119).to({
   _off: false
  }, 0).wait(75).to({
   startPosition: 34
  }, 0).to({
   alpha: 0
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(255));
  this.instance_9 = new lib.txt02("synched", 0, false);
  this.instance_9.parent = this;
  this.instance_9._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(24).to({
   _off: false
  }, 0).wait(80).to({
   startPosition: 34
  }, 0).to({
   alpha: 0
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(345));
  this.instance_10 = new lib.arrow("synched", 0, false);
  this.instance_10.parent = this;
  this.instance_10.setTransform(16.25, 56.65, 0.2821, 0.2819, 0, 0, 0, 39.9, 126.1);
  this.instance_10._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(226).to({
   _off: false
  }, 0).wait(48).to({
   mode: "single",
   startPosition: 21
  }, 0).to({
   alpha: 0
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(175));
  this.instance_11 = new lib.arrows3("synched", 0, false);
  this.instance_11.parent = this;
  this.instance_11.setTransform(227.35, 311.65, 1.2746, 1.275, 0, 0, 0, 74.9, 50.8);
  this.instance_11._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(306).to({
   _off: false
  }, 0).wait(53).to({
   startPosition: 14
  }, 0).to({
   alpha: 0
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(90));
  this.instance_12 = new lib.arrows2("synched", 0, false);
  this.instance_12.parent = this;
  this.instance_12.setTransform(221.95, 334.05, 1.2161, 1.2164, 0, 0, 0, 60.6, 51.6);
  this.instance_12._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(137).to({
   _off: false
  }, 0).wait(57).to({
   startPosition: 14
  }, 0).to({
   alpha: 0
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(255));
  this.instance_13 = new lib.txt01("synched", 0, false);
  this.instance_13.parent = this;
  this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(465));
  this.instance_14 = new lib.car_1();
  this.instance_14.parent = this;
  this.instance_14.setTransform(144.2, 335, 1, 1, 0, 0, 0, 120.2, 75);
  this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(104).to({
   alpha: 0
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(345));
  this.instance_15 = new lib.red_line();
  this.instance_15.parent = this;
  this.instance_15.setTransform(-83, 449.5, 1, 1, 0, 0, 180, 100, 1.5);
  this.instance_15._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(10).to({
   _off: false
  }, 0).to({
   x: -13
  }, 30, cjs.Ease.get(1)).wait(425));
  this.instance_16 = new lib.red_line();
  this.instance_16.parent = this;
  this.instance_16.setTransform(404.15, 203.5, 1.0417, 1, 0, 0, 0, 100, 1.5);
  this.instance_16._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(10).to({
   _off: false
  }, 0).to({
   regX: 99.9,
   x: 154
  }, 30, cjs.Ease.get(1)).wait(425));
  var mask = new cjs.Shape();
  mask._off = true;
  var mask_graphics_0 = new cjs.Graphics().p("EgQZAkQMAAAgpFMAonAAAMAAAApFg");
  var mask_graphics_119 = new cjs.Graphics().p("EADDAkQMAAAgpFMAooAAAMAAAApFg");
  var mask_graphics_120 = new cjs.Graphics().p("EADAAkQMAAAgpFMAooAAAMAAAApFg");
  var mask_graphics_121 = new cjs.Graphics().p("EAC3AkQMAAAgpFMAooAAAMAAAApFg");
  var mask_graphics_122 = new cjs.Graphics().p("EACnAkQMAAAgpFMAooAAAMAAAApFg");
  var mask_graphics_123 = new cjs.Graphics().p("EACSAkQMAAAgpFMAooAAAMAAAApFg");
  var mask_graphics_124 = new cjs.Graphics().p("EAB2AkQMAAAgpFMAooAAAMAAAApFg");
  var mask_graphics_125 = new cjs.Graphics().p("EABUAkQMAAAgpFMAooAAAMAAAApFg");
  var mask_graphics_126 = new cjs.Graphics().p("EAAsAkQMAAAgpFMAooAAAMAAAApFg");
  var mask_graphics_127 = new cjs.Graphics().p("EgABAkQMAAAgpEMAonAAAMAAAApEg");
  var mask_graphics_128 = new cjs.Graphics().p("EgA2AkQMAAAgpEMAonAAAMAAAApEg");
  var mask_graphics_129 = new cjs.Graphics().p("EgBwAkRMAAAgpFMAonAAAMAAAApFg");
  var mask_graphics_130 = new cjs.Graphics().p("EgCxAkRMAAAgpFMAonAAAMAAAApFg");
  var mask_graphics_131 = new cjs.Graphics().p("EgD4AkRMAAAgpFMAonAAAMAAAApFg");
  var mask_graphics_132 = new cjs.Graphics().p("EgFFAkRMAAAgpFMAonAAAMAAAApFg");
  var mask_graphics_133 = new cjs.Graphics().p("EgGYAkQMAAAgpFMAomAAAMAAAApFg");
  var mask_graphics_134 = new cjs.Graphics().p("EgHmAkQMAAAgpFMAonAAAMAAAApFg");
  var mask_graphics_135 = new cjs.Graphics().p("EgIvAkQMAAAgpFMAonAAAMAAAApFg");
  var mask_graphics_136 = new cjs.Graphics().p("EgJyAkPMAAAgpEMAonAAAMAAAApEg");
  var mask_graphics_137 = new cjs.Graphics().p("EgKxAkPMAAAgpEMAonAAAMAAAApEg");
  var mask_graphics_138 = new cjs.Graphics().p("EgLqAkPMAAAgpFMAonAAAMAAAApFg");
  var mask_graphics_139 = new cjs.Graphics().p("EgMfAkPMAAAgpFMAonAAAMAAAApFg");
  var mask_graphics_140 = new cjs.Graphics().p("EgNOAkPMAAAgpFMAonAAAMAAAApFg");
  var mask_graphics_141 = new cjs.Graphics().p("EgN5AkPMAAAgpFMAonAAAMAAAApFg");
  var mask_graphics_142 = new cjs.Graphics().p("EgOeAkPMAAAgpFMAonAAAMAAAApFg");
  var mask_graphics_143 = new cjs.Graphics().p("EgO/AkPMAAAgpFMAonAAAMAAAApFg");
  var mask_graphics_144 = new cjs.Graphics().p("EgPaAkPMAAAgpFMAonAAAMAAAApFg");
  var mask_graphics_145 = new cjs.Graphics().p("EgPxAkPMAAAgpFMAonAAAMAAAApFg");
  var mask_graphics_146 = new cjs.Graphics().p("EgQCAkPMAAAgpFMAonAAAMAAAApFg");
  var mask_graphics_147 = new cjs.Graphics().p("EgQPAkPMAAAgpFMAonAAAMAAAApFg");
  var mask_graphics_148 = new cjs.Graphics().p("EgQWAkPMAAAgpFMAomAAAMAAAApFg");
  var mask_graphics_149 = new cjs.Graphics().p("EgQZAkQMAAAgpFMAonAAAMAAAApFg");
  var mask_graphics_209 = new cjs.Graphics().p("EADDAkQMAAAgpFMAooAAAMAAAApFg");
  var mask_graphics_210 = new cjs.Graphics().p("EADAAkQMAAAgpFMAooAAAMAAAApFg");
  var mask_graphics_211 = new cjs.Graphics().p("EAC3AkQMAAAgpFMAooAAAMAAAApFg");
  var mask_graphics_212 = new cjs.Graphics().p("EACnAkQMAAAgpFMAooAAAMAAAApFg");
  var mask_graphics_213 = new cjs.Graphics().p("EACSAkQMAAAgpFMAooAAAMAAAApFg");
  var mask_graphics_214 = new cjs.Graphics().p("EAB2AkQMAAAgpFMAooAAAMAAAApFg");
  var mask_graphics_215 = new cjs.Graphics().p("EABUAkQMAAAgpFMAooAAAMAAAApFg");
  var mask_graphics_216 = new cjs.Graphics().p("EAAsAkQMAAAgpFMAooAAAMAAAApFg");
  var mask_graphics_217 = new cjs.Graphics().p("EgABAkQMAAAgpEMAonAAAMAAAApEg");
  var mask_graphics_218 = new cjs.Graphics().p("EgA2AkQMAAAgpEMAonAAAMAAAApEg");
  var mask_graphics_219 = new cjs.Graphics().p("EgBwAkRMAAAgpFMAonAAAMAAAApFg");
  var mask_graphics_220 = new cjs.Graphics().p("EgCxAkRMAAAgpFMAonAAAMAAAApFg");
  var mask_graphics_221 = new cjs.Graphics().p("EgD4AkRMAAAgpFMAonAAAMAAAApFg");
  var mask_graphics_222 = new cjs.Graphics().p("EgFFAkRMAAAgpFMAonAAAMAAAApFg");
  var mask_graphics_223 = new cjs.Graphics().p("EgGYAkQMAAAgpFMAomAAAMAAAApFg");
  var mask_graphics_224 = new cjs.Graphics().p("EgHmAkQMAAAgpFMAonAAAMAAAApFg");
  var mask_graphics_225 = new cjs.Graphics().p("EgIvAkQMAAAgpFMAonAAAMAAAApFg");
  var mask_graphics_226 = new cjs.Graphics().p("EgJyAkPMAAAgpEMAonAAAMAAAApEg");
  var mask_graphics_227 = new cjs.Graphics().p("EgKxAkPMAAAgpEMAonAAAMAAAApEg");
  var mask_graphics_228 = new cjs.Graphics().p("EgLqAkPMAAAgpFMAonAAAMAAAApFg");
  var mask_graphics_229 = new cjs.Graphics().p("EgMfAkPMAAAgpFMAonAAAMAAAApFg");
  var mask_graphics_230 = new cjs.Graphics().p("EgNOAkPMAAAgpFMAonAAAMAAAApFg");
  var mask_graphics_231 = new cjs.Graphics().p("EgN5AkPMAAAgpFMAonAAAMAAAApFg");
  var mask_graphics_232 = new cjs.Graphics().p("EgOeAkPMAAAgpFMAonAAAMAAAApFg");
  var mask_graphics_233 = new cjs.Graphics().p("EgO/AkPMAAAgpFMAonAAAMAAAApFg");
  var mask_graphics_234 = new cjs.Graphics().p("EgPaAkPMAAAgpFMAonAAAMAAAApFg");
  var mask_graphics_235 = new cjs.Graphics().p("EgPxAkPMAAAgpFMAonAAAMAAAApFg");
  var mask_graphics_236 = new cjs.Graphics().p("EgQCAkPMAAAgpFMAonAAAMAAAApFg");
  var mask_graphics_237 = new cjs.Graphics().p("EgQPAkPMAAAgpFMAonAAAMAAAApFg");
  var mask_graphics_238 = new cjs.Graphics().p("EgQWAkPMAAAgpFMAomAAAMAAAApFg");
  var mask_graphics_239 = new cjs.Graphics().p("EgQZAkQMAAAgpFMAonAAAMAAAApFg");
  var mask_graphics_289 = new cjs.Graphics().p("EADDAkQMAAAgpFMAooAAAMAAAApFg");
  var mask_graphics_290 = new cjs.Graphics().p("EADAAkQMAAAgpFMAooAAAMAAAApFg");
  var mask_graphics_291 = new cjs.Graphics().p("EAC3AkQMAAAgpFMAooAAAMAAAApFg");
  var mask_graphics_292 = new cjs.Graphics().p("EACnAkQMAAAgpFMAooAAAMAAAApFg");
  var mask_graphics_293 = new cjs.Graphics().p("EACSAkQMAAAgpFMAooAAAMAAAApFg");
  var mask_graphics_294 = new cjs.Graphics().p("EAB2AkQMAAAgpFMAooAAAMAAAApFg");
  var mask_graphics_295 = new cjs.Graphics().p("EABUAkQMAAAgpFMAooAAAMAAAApFg");
  var mask_graphics_296 = new cjs.Graphics().p("EAAsAkQMAAAgpFMAooAAAMAAAApFg");
  var mask_graphics_297 = new cjs.Graphics().p("EgABAkQMAAAgpEMAonAAAMAAAApEg");
  var mask_graphics_298 = new cjs.Graphics().p("EgA2AkQMAAAgpEMAonAAAMAAAApEg");
  var mask_graphics_299 = new cjs.Graphics().p("EgBwAkRMAAAgpFMAonAAAMAAAApFg");
  var mask_graphics_300 = new cjs.Graphics().p("EgCxAkRMAAAgpFMAonAAAMAAAApFg");
  var mask_graphics_301 = new cjs.Graphics().p("EgD4AkRMAAAgpFMAonAAAMAAAApFg");
  var mask_graphics_302 = new cjs.Graphics().p("EgFFAkRMAAAgpFMAonAAAMAAAApFg");
  var mask_graphics_303 = new cjs.Graphics().p("EgGYAkQMAAAgpFMAomAAAMAAAApFg");
  var mask_graphics_304 = new cjs.Graphics().p("EgHmAkQMAAAgpFMAonAAAMAAAApFg");
  var mask_graphics_305 = new cjs.Graphics().p("EgIvAkQMAAAgpFMAonAAAMAAAApFg");
  var mask_graphics_306 = new cjs.Graphics().p("EgJyAkPMAAAgpEMAonAAAMAAAApEg");
  var mask_graphics_307 = new cjs.Graphics().p("EgKxAkPMAAAgpEMAonAAAMAAAApEg");
  var mask_graphics_308 = new cjs.Graphics().p("EgLqAkPMAAAgpFMAonAAAMAAAApFg");
  var mask_graphics_309 = new cjs.Graphics().p("EgMfAkPMAAAgpFMAonAAAMAAAApFg");
  var mask_graphics_310 = new cjs.Graphics().p("EgNOAkPMAAAgpFMAonAAAMAAAApFg");
  var mask_graphics_311 = new cjs.Graphics().p("EgN5AkPMAAAgpFMAonAAAMAAAApFg");
  var mask_graphics_312 = new cjs.Graphics().p("EgOeAkPMAAAgpFMAonAAAMAAAApFg");
  var mask_graphics_313 = new cjs.Graphics().p("EgO/AkPMAAAgpFMAonAAAMAAAApFg");
  var mask_graphics_314 = new cjs.Graphics().p("EgPaAkPMAAAgpFMAonAAAMAAAApFg");
  var mask_graphics_315 = new cjs.Graphics().p("EgPxAkPMAAAgpFMAonAAAMAAAApFg");
  var mask_graphics_316 = new cjs.Graphics().p("EgQCAkPMAAAgpFMAonAAAMAAAApFg");
  var mask_graphics_317 = new cjs.Graphics().p("EgQPAkPMAAAgpFMAonAAAMAAAApFg");
  var mask_graphics_318 = new cjs.Graphics().p("EgQWAkPMAAAgpFMAomAAAMAAAApFg");
  var mask_graphics_319 = new cjs.Graphics().p("EgQZAkQMAAAgpFMAonAAAMAAAApFg");
  var mask_graphics_374 = new cjs.Graphics().p("EADDAkQMAAAgpFMAooAAAMAAAApFg");
  var mask_graphics_375 = new cjs.Graphics().p("EADAAkQMAAAgpFMAooAAAMAAAApFg");
  var mask_graphics_376 = new cjs.Graphics().p("EAC3AkQMAAAgpFMAooAAAMAAAApFg");
  var mask_graphics_377 = new cjs.Graphics().p("EACnAkQMAAAgpFMAooAAAMAAAApFg");
  var mask_graphics_378 = new cjs.Graphics().p("EACSAkQMAAAgpFMAooAAAMAAAApFg");
  var mask_graphics_379 = new cjs.Graphics().p("EAB2AkQMAAAgpFMAooAAAMAAAApFg");
  var mask_graphics_380 = new cjs.Graphics().p("EABUAkQMAAAgpFMAooAAAMAAAApFg");
  var mask_graphics_381 = new cjs.Graphics().p("EAAsAkQMAAAgpFMAooAAAMAAAApFg");
  var mask_graphics_382 = new cjs.Graphics().p("EgABAkQMAAAgpEMAonAAAMAAAApEg");
  var mask_graphics_383 = new cjs.Graphics().p("EgA2AkQMAAAgpEMAonAAAMAAAApEg");
  var mask_graphics_384 = new cjs.Graphics().p("EgBwAkRMAAAgpFMAonAAAMAAAApFg");
  var mask_graphics_385 = new cjs.Graphics().p("EgCxAkRMAAAgpFMAonAAAMAAAApFg");
  var mask_graphics_386 = new cjs.Graphics().p("EgD4AkRMAAAgpFMAonAAAMAAAApFg");
  var mask_graphics_387 = new cjs.Graphics().p("EgFFAkRMAAAgpFMAonAAAMAAAApFg");
  var mask_graphics_388 = new cjs.Graphics().p("EgGYAkQMAAAgpFMAomAAAMAAAApFg");
  var mask_graphics_389 = new cjs.Graphics().p("EgIFAkQMAAAgpFMApAAAAMAAAApFg");
  var mask_graphics_390 = new cjs.Graphics().p("EgJqAkQMAAAgpFMApYAAAMAAAApFg");
  var mask_graphics_391 = new cjs.Graphics().p("EgLJAkPMAAAgpEMApuAAAMAAAApEg");
  var mask_graphics_392 = new cjs.Graphics().p("EgMgAkPMAAAgpEMAqCAAAMAAAApEg");
  var mask_graphics_393 = new cjs.Graphics().p("EgNxAkPMAAAgpFMAqWAAAMAAAApFg");
  var mask_graphics_394 = new cjs.Graphics().p("EgO6AkPMAAAgpFMAqnAAAMAAAApFg");
  var mask_graphics_395 = new cjs.Graphics().p("EgP9AkPMAAAgpFMAq3AAAMAAAApFg");
  var mask_graphics_396 = new cjs.Graphics().p("EgQ4AkPMAAAgpFMArEAAAMAAAApFg");
  var mask_graphics_397 = new cjs.Graphics().p("EgRtAkPMAAAgpFMArRAAAMAAAApFg");
  var mask_graphics_398 = new cjs.Graphics().p("EgSaAkPMAAAgpFMArbAAAMAAAApFg");
  var mask_graphics_399 = new cjs.Graphics().p("EgTBAkPMAAAgpFMArlAAAMAAAApFg");
  var mask_graphics_400 = new cjs.Graphics().p("EgTgAkPMAAAgpFMArrAAAMAAAApFg");
  var mask_graphics_401 = new cjs.Graphics().p("EgT5AkPMAAAgpFMAryAAAMAAAApFg");
  var mask_graphics_402 = new cjs.Graphics().p("EgUKAkPMAAAgpFMAr1AAAMAAAApFg");
  var mask_graphics_403 = new cjs.Graphics().p("EgUVAkPMAAAgpFMAr4AAAMAAAApFg");
  var mask_graphics_404 = new cjs.Graphics().p("EgUaAkQMAAAgpFMAr5AAAMAAAApFg");
  this.timeline.addTween(cjs.Tween.get(mask).to({
   graphics: mask_graphics_0,
   x: 154.9988,
   y: 231.9953
  }).wait(119).to({
   graphics: mask_graphics_119,
   x: 279.4988,
   y: 231.9953
  }).wait(1).to({
   graphics: mask_graphics_120,
   x: 279.1903,
   y: 231.9959
  }).wait(1).to({
   graphics: mask_graphics_121,
   x: 278.265,
   y: 231.9978
  }).wait(1).to({
   graphics: mask_graphics_122,
   x: 276.7228,
   y: 232.0009
  }).wait(1).to({
   graphics: mask_graphics_123,
   x: 274.5637,
   y: 232.0053
  }).wait(1).to({
   graphics: mask_graphics_124,
   x: 271.7877,
   y: 232.011
  }).wait(1).to({
   graphics: mask_graphics_125,
   x: 268.3949,
   y: 232.0179
  }).wait(1).to({
   graphics: mask_graphics_126,
   x: 264.3851,
   y: 232.0261
  }).wait(1).to({
   graphics: mask_graphics_127,
   x: 259.7585,
   y: 232.0355
  }).wait(1).to({
   graphics: mask_graphics_128,
   x: 254.515,
   y: 232.0462
  }).wait(1).to({
   graphics: mask_graphics_129,
   x: 248.6546,
   y: 232.0581
  }).wait(1).to({
   graphics: mask_graphics_130,
   x: 242.1773,
   y: 232.0713
  }).wait(1).to({
   graphics: mask_graphics_131,
   x: 235.0832,
   y: 232.0857
  }).wait(1).to({
   graphics: mask_graphics_132,
   x: 227.3721,
   y: 232.1014
  }).wait(1).to({
   graphics: mask_graphics_133,
   x: 219.0442,
   y: 231.9869
  }).wait(1).to({
   graphics: mask_graphics_134,
   x: 211.2887,
   y: 231.972
  }).wait(1).to({
   graphics: mask_graphics_135,
   x: 204.0336,
   y: 231.958
  }).wait(1).to({
   graphics: mask_graphics_136,
   x: 197.2788,
   y: 231.9451
  }).wait(1).to({
   graphics: mask_graphics_137,
   x: 191.0243,
   y: 231.933
  }).wait(1).to({
   graphics: mask_graphics_138,
   x: 185.2702,
   y: 231.922
  }).wait(1).to({
   graphics: mask_graphics_139,
   x: 180.0165,
   y: 231.9119
  }).wait(1).to({
   graphics: mask_graphics_140,
   x: 175.2632,
   y: 231.9027
  }).wait(1).to({
   graphics: mask_graphics_141,
   x: 171.0101,
   y: 231.8946
  }).wait(1).to({
   graphics: mask_graphics_142,
   x: 167.2575,
   y: 231.8874
  }).wait(1).to({
   graphics: mask_graphics_143,
   x: 164.0052,
   y: 231.8811
  }).wait(1).to({
   graphics: mask_graphics_144,
   x: 161.2532,
   y: 231.8758
  }).wait(1).to({
   graphics: mask_graphics_145,
   x: 159.0016,
   y: 231.8715
  }).wait(1).to({
   graphics: mask_graphics_146,
   x: 157.2504,
   y: 231.8681
  }).wait(1).to({
   graphics: mask_graphics_147,
   x: 155.9995,
   y: 231.8657
  }).wait(1).to({
   graphics: mask_graphics_148,
   x: 155.249,
   y: 231.8643
  }).wait(1).to({
   graphics: mask_graphics_149,
   x: 154.9988,
   y: 231.9953
  }).wait(60).to({
   graphics: mask_graphics_209,
   x: 279.4988,
   y: 231.9953
  }).wait(1).to({
   graphics: mask_graphics_210,
   x: 279.1903,
   y: 231.9959
  }).wait(1).to({
   graphics: mask_graphics_211,
   x: 278.265,
   y: 231.9978
  }).wait(1).to({
   graphics: mask_graphics_212,
   x: 276.7228,
   y: 232.0009
  }).wait(1).to({
   graphics: mask_graphics_213,
   x: 274.5637,
   y: 232.0053
  }).wait(1).to({
   graphics: mask_graphics_214,
   x: 271.7877,
   y: 232.011
  }).wait(1).to({
   graphics: mask_graphics_215,
   x: 268.3949,
   y: 232.0179
  }).wait(1).to({
   graphics: mask_graphics_216,
   x: 264.3851,
   y: 232.0261
  }).wait(1).to({
   graphics: mask_graphics_217,
   x: 259.7585,
   y: 232.0355
  }).wait(1).to({
   graphics: mask_graphics_218,
   x: 254.515,
   y: 232.0462
  }).wait(1).to({
   graphics: mask_graphics_219,
   x: 248.6546,
   y: 232.0581
  }).wait(1).to({
   graphics: mask_graphics_220,
   x: 242.1773,
   y: 232.0713
  }).wait(1).to({
   graphics: mask_graphics_221,
   x: 235.0832,
   y: 232.0857
  }).wait(1).to({
   graphics: mask_graphics_222,
   x: 227.3721,
   y: 232.1014
  }).wait(1).to({
   graphics: mask_graphics_223,
   x: 219.0442,
   y: 231.9869
  }).wait(1).to({
   graphics: mask_graphics_224,
   x: 211.2887,
   y: 231.972
  }).wait(1).to({
   graphics: mask_graphics_225,
   x: 204.0336,
   y: 231.958
  }).wait(1).to({
   graphics: mask_graphics_226,
   x: 197.2788,
   y: 231.9451
  }).wait(1).to({
   graphics: mask_graphics_227,
   x: 191.0243,
   y: 231.933
  }).wait(1).to({
   graphics: mask_graphics_228,
   x: 185.2702,
   y: 231.922
  }).wait(1).to({
   graphics: mask_graphics_229,
   x: 180.0165,
   y: 231.9119
  }).wait(1).to({
   graphics: mask_graphics_230,
   x: 175.2632,
   y: 231.9027
  }).wait(1).to({
   graphics: mask_graphics_231,
   x: 171.0101,
   y: 231.8946
  }).wait(1).to({
   graphics: mask_graphics_232,
   x: 167.2575,
   y: 231.8874
  }).wait(1).to({
   graphics: mask_graphics_233,
   x: 164.0052,
   y: 231.8811
  }).wait(1).to({
   graphics: mask_graphics_234,
   x: 161.2532,
   y: 231.8758
  }).wait(1).to({
   graphics: mask_graphics_235,
   x: 159.0016,
   y: 231.8715
  }).wait(1).to({
   graphics: mask_graphics_236,
   x: 157.2504,
   y: 231.8681
  }).wait(1).to({
   graphics: mask_graphics_237,
   x: 155.9995,
   y: 231.8657
  }).wait(1).to({
   graphics: mask_graphics_238,
   x: 155.249,
   y: 231.8643
  }).wait(1).to({
   graphics: mask_graphics_239,
   x: 154.9988,
   y: 231.9953
  }).wait(50).to({
   graphics: mask_graphics_289,
   x: 279.4988,
   y: 231.9953
  }).wait(1).to({
   graphics: mask_graphics_290,
   x: 279.1903,
   y: 231.9959
  }).wait(1).to({
   graphics: mask_graphics_291,
   x: 278.265,
   y: 231.9978
  }).wait(1).to({
   graphics: mask_graphics_292,
   x: 276.7228,
   y: 232.0009
  }).wait(1).to({
   graphics: mask_graphics_293,
   x: 274.5637,
   y: 232.0053
  }).wait(1).to({
   graphics: mask_graphics_294,
   x: 271.7877,
   y: 232.011
  }).wait(1).to({
   graphics: mask_graphics_295,
   x: 268.3949,
   y: 232.0179
  }).wait(1).to({
   graphics: mask_graphics_296,
   x: 264.3851,
   y: 232.0261
  }).wait(1).to({
   graphics: mask_graphics_297,
   x: 259.7585,
   y: 232.0355
  }).wait(1).to({
   graphics: mask_graphics_298,
   x: 254.515,
   y: 232.0462
  }).wait(1).to({
   graphics: mask_graphics_299,
   x: 248.6546,
   y: 232.0581
  }).wait(1).to({
   graphics: mask_graphics_300,
   x: 242.1773,
   y: 232.0713
  }).wait(1).to({
   graphics: mask_graphics_301,
   x: 235.0832,
   y: 232.0857
  }).wait(1).to({
   graphics: mask_graphics_302,
   x: 227.3721,
   y: 232.1014
  }).wait(1).to({
   graphics: mask_graphics_303,
   x: 219.0442,
   y: 231.9869
  }).wait(1).to({
   graphics: mask_graphics_304,
   x: 211.2887,
   y: 231.972
  }).wait(1).to({
   graphics: mask_graphics_305,
   x: 204.0336,
   y: 231.958
  }).wait(1).to({
   graphics: mask_graphics_306,
   x: 197.2788,
   y: 231.9451
  }).wait(1).to({
   graphics: mask_graphics_307,
   x: 191.0243,
   y: 231.933
  }).wait(1).to({
   graphics: mask_graphics_308,
   x: 185.2702,
   y: 231.922
  }).wait(1).to({
   graphics: mask_graphics_309,
   x: 180.0165,
   y: 231.9119
  }).wait(1).to({
   graphics: mask_graphics_310,
   x: 175.2632,
   y: 231.9027
  }).wait(1).to({
   graphics: mask_graphics_311,
   x: 171.0101,
   y: 231.8946
  }).wait(1).to({
   graphics: mask_graphics_312,
   x: 167.2575,
   y: 231.8874
  }).wait(1).to({
   graphics: mask_graphics_313,
   x: 164.0052,
   y: 231.8811
  }).wait(1).to({
   graphics: mask_graphics_314,
   x: 161.2532,
   y: 231.8758
  }).wait(1).to({
   graphics: mask_graphics_315,
   x: 159.0016,
   y: 231.8715
  }).wait(1).to({
   graphics: mask_graphics_316,
   x: 157.2504,
   y: 231.8681
  }).wait(1).to({
   graphics: mask_graphics_317,
   x: 155.9995,
   y: 231.8657
  }).wait(1).to({
   graphics: mask_graphics_318,
   x: 155.249,
   y: 231.8643
  }).wait(1).to({
   graphics: mask_graphics_319,
   x: 154.9988,
   y: 231.9953
  }).wait(55).to({
   graphics: mask_graphics_374,
   x: 279.4988,
   y: 231.9953
  }).wait(1).to({
   graphics: mask_graphics_375,
   x: 279.1903,
   y: 231.9959
  }).wait(1).to({
   graphics: mask_graphics_376,
   x: 278.265,
   y: 231.9978
  }).wait(1).to({
   graphics: mask_graphics_377,
   x: 276.7228,
   y: 232.0009
  }).wait(1).to({
   graphics: mask_graphics_378,
   x: 274.5637,
   y: 232.0053
  }).wait(1).to({
   graphics: mask_graphics_379,
   x: 271.7877,
   y: 232.011
  }).wait(1).to({
   graphics: mask_graphics_380,
   x: 268.3949,
   y: 232.0179
  }).wait(1).to({
   graphics: mask_graphics_381,
   x: 264.3851,
   y: 232.0261
  }).wait(1).to({
   graphics: mask_graphics_382,
   x: 259.7585,
   y: 232.0355
  }).wait(1).to({
   graphics: mask_graphics_383,
   x: 254.515,
   y: 232.0462
  }).wait(1).to({
   graphics: mask_graphics_384,
   x: 248.6546,
   y: 232.0581
  }).wait(1).to({
   graphics: mask_graphics_385,
   x: 242.1773,
   y: 232.0713
  }).wait(1).to({
   graphics: mask_graphics_386,
   x: 235.0832,
   y: 232.0857
  }).wait(1).to({
   graphics: mask_graphics_387,
   x: 227.3721,
   y: 232.1014
  }).wait(1).to({
   graphics: mask_graphics_388,
   x: 219.0442,
   y: 231.9869
  }).wait(1).to({
   graphics: mask_graphics_389,
   x: 210.7395,
   y: 231.972
  }).wait(1).to({
   graphics: mask_graphics_390,
   x: 202.9706,
   y: 231.958
  }).wait(1).to({
   graphics: mask_graphics_391,
   x: 195.7375,
   y: 231.9451
  }).wait(1).to({
   graphics: mask_graphics_392,
   x: 189.0401,
   y: 231.933
  }).wait(1).to({
   graphics: mask_graphics_393,
   x: 182.8786,
   y: 231.922
  }).wait(1).to({
   graphics: mask_graphics_394,
   x: 177.2528,
   y: 231.9119
  }).wait(1).to({
   graphics: mask_graphics_395,
   x: 172.1628,
   y: 231.9027
  }).wait(1).to({
   graphics: mask_graphics_396,
   x: 167.6087,
   y: 231.8946
  }).wait(1).to({
   graphics: mask_graphics_397,
   x: 163.5902,
   y: 231.8874
  }).wait(1).to({
   graphics: mask_graphics_398,
   x: 160.1076,
   y: 231.8811
  }).wait(1).to({
   graphics: mask_graphics_399,
   x: 157.1608,
   y: 231.8758
  }).wait(1).to({
   graphics: mask_graphics_400,
   x: 154.7498,
   y: 231.8715
  }).wait(1).to({
   graphics: mask_graphics_401,
   x: 152.8745,
   y: 231.8681
  }).wait(1).to({
   graphics: mask_graphics_402,
   x: 151.535,
   y: 231.8657
  }).wait(1).to({
   graphics: mask_graphics_403,
   x: 150.7314,
   y: 231.8643
  }).wait(1).to({
   graphics: mask_graphics_404,
   x: 150.323,
   y: 231.9953
  }).wait(61));
  this.instance_17 = new lib.bg1_1();
  this.instance_17.parent = this;
  this.instance_17.setTransform(200, 401, 1, 1, 0, 0, 0, 150, 197);
  var maskedShapeInstanceList = [this.instance_17];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(104).to({
   alpha: 0
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(345));
  this.instance_18 = new lib.bg2_1();
  this.instance_18.parent = this;
  this.instance_18.setTransform(200, 401, 1, 1, 0, 0, 0, 150, 197);
  this.instance_18._off = true;
  var maskedShapeInstanceList = [this.instance_18];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(119).to({
   _off: false
  }, 0).wait(75).to({
   alpha: 0
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(255));
  this.instance_19 = new lib.bg3_1();
  this.instance_19.parent = this;
  this.instance_19.setTransform(200, 401, 1, 1, 0, 0, 0, 150, 197);
  this.instance_19._off = true;
  var maskedShapeInstanceList = [this.instance_19];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(209).to({
   _off: false
  }, 0).wait(65).to({
   alpha: 0
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(175));
  this.instance_20 = new lib.bg4_1();
  this.instance_20.parent = this;
  this.instance_20.setTransform(200, 401, 1, 1, 0, 0, 0, 150, 197);
  this.instance_20._off = true;
  var maskedShapeInstanceList = [this.instance_20];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_20).wait(289).to({
   _off: false
  }, 0).wait(70).to({
   alpha: 0
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(90));
  this.instance_21 = new lib.car_1();
  this.instance_21.parent = this;
  this.instance_21.setTransform(144.2, 335, 1, 1, 0, 0, 0, 120.2, 75);
  this.instance_21._off = true;
  var maskedShapeInstanceList = [this.instance_21];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_21).wait(374).to({
   _off: false
  }, 0).wait(91));
  this.instance_22 = new lib.bg1_1();
  this.instance_22.parent = this;
  this.instance_22.setTransform(200, 401, 1, 1, 0, 0, 0, 150, 197);
  this.instance_22._off = true;
  var maskedShapeInstanceList = [this.instance_22];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_22).wait(374).to({
   _off: false
  }, 0).wait(91));
  this.instance_23 = new lib.bg_01();
  this.instance_23.parent = this;
  this.instance_23.setTransform(120, 200, 1, 1, 0, 0, 0, 120, 200);
  this.timeline.addTween(cjs.Tween.get(this.instance_23).wait(465));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(-223, 0, 773, 500);
 (lib.toyota_300x500 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.content();
  this.instance.parent = this;
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));
  this.instance_1 = new lib.black_plate();
  this.instance_1.parent = this;
  this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(144, 250, 166, 250);
 lib.properties = {
  id: '1E4D562F91EE4B408F0AC49B20246D76',
  width: 300,
  height: 500,
  fps: 24,
  color: "#FFFFFF",
  opacity: 1.00,
  manifest: [{
   src: "bg1.jpg",
   id: "bg1"
  }, {
   src: "bg2.jpg",
   id: "bg2"
  }, {
   src: "bg3.jpg",
   id: "bg3"
  }, {
   src: "bg4.jpg",
   id: "bg4"
  }, {
   src: "car.png",
   id: "car"
  }, {
   src: "legal_01_d1.png",
   id: "legal_01_d1"
  }, ],
  preloads: []
 };
 (lib.Stage = function(canvas) {
  createjs.Stage.call(this, canvas);
 }).prototype = p = new createjs.Stage();
 p.setAutoPlay = function(autoPlay) {
  this.tickEnabled = autoPlay;
 }
 p.play = function() {
  this.tickEnabled = true;
  this.getChildAt(0).gotoAndPlay(this.getTimelinePosition())
 }
 p.stop = function(ms) {
  if (ms) this.seek(ms);
  this.tickEnabled = false;
 }
 p.seek = function(ms) {
  this.tickEnabled = true;
  this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000);
 }
 p.getDuration = function() {
  return this.getChildAt(0).totalFrames / lib.properties.fps * 1000;
 }
 p.getTimelinePosition = function() {
  return this.getChildAt(0).currentFrame / lib.properties.fps * 1000;
 }
 an.bootcompsLoaded = an.bootcompsLoaded || [];
 if (!an.bootstrapListeners) {
  an.bootstrapListeners = [];
 }
 an.bootstrapCallback = function(fnCallback) {
  an.bootstrapListeners.push(fnCallback);
  if (an.bootcompsLoaded.length > 0) {
   for (var i = 0; i < an.bootcompsLoaded.length; ++i) {
    fnCallback(an.bootcompsLoaded[i]);
   }
  }
 };
 an.compositions = an.compositions || {};
 an.compositions['1E4D562F91EE4B408F0AC49B20246D76'] = {
  getStage: function() {
   return exportRoot.getStage();
  },
  getLibrary: function() {
   return lib;
  },
  getSpriteSheet: function() {
   return ss;
  },
  getImages: function() {
   return img;
  }
 };
 an.compositionLoaded = function(id) {
  an.bootcompsLoaded.push(id);
  for (var j = 0; j < an.bootstrapListeners.length; j++) {
   an.bootstrapListeners[j](id);
  }
 }
 an.getComposition = function(id) {
  return an.compositions[id];
 }
 an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {
  var lastW, lastH, lastS = 1;
  window.addEventListener('resize', resizeCanvas);
  resizeCanvas();

  function resizeCanvas() {
   var w = lib.properties.width,
    h = lib.properties.height;
   var iw = window.innerWidth,
    ih = window.innerHeight;
   var pRatio = window.devicePixelRatio || 1,
    xRatio = iw / w,
    yRatio = ih / h,
    sRatio = 1;
   if (isResp) {
    if ((respDim == 'width' && lastW == iw) || (respDim == 'height' && lastH == ih)) {
     sRatio = lastS;
    } else if (!isScale) {
     if (iw < w || ih < h) sRatio = Math.min(xRatio, yRatio);
    } else if (scaleType == 1) {
     sRatio = Math.min(xRatio, yRatio);
    } else if (scaleType == 2) {
     sRatio = Math.max(xRatio, yRatio);
    }
   }
   domContainers[0].width = w * pRatio * sRatio;
   domContainers[0].height = h * pRatio * sRatio;
   domContainers.forEach(function(container) {
    container.style.width = w * sRatio + 'px';
    container.style.height = h * sRatio + 'px';
   });
   stage.scaleX = pRatio * sRatio;
   stage.scaleY = pRatio * sRatio;
   lastW = iw;
   lastH = ih;
   lastS = sRatio;
   stage.tickOnUpdate = false;
   stage.update();
   stage.tickOnUpdate = true;
  }
 }
})(createjs = createjs || {}, AdobeAn = AdobeAn || {});
var createjs, AdobeAn;