(function(cjs, an) {
 var p;
 var lib = {};
 var ss = {};
 var img = {};
 lib.ssMetadata = [];
 (lib.bubble = function() {
  this.initialize(img.bubble);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 448, 448);
 (lib.fish1 = function() {
  this.initialize(img.fish1);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 342, 311);
 (lib.fish2 = function() {
  this.initialize(img.fish2);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 346, 266);
 (lib.icon3 = function() {
  this.initialize(img.icon3);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 214, 214);
 (lib.packshot = function() {
  this.initialize(img.packshot);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 352, 170);

 function mc_symbol_clone() {
  var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
  clone.gotoAndStop(this.currentFrame);
  clone.paused = this.paused;
  clone.framerate = this.framerate;
  return clone;
 }

 function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
  var prototype = cjs.extend(symbol, cjs.MovieClip);
  prototype.clone = mc_symbol_clone;
  prototype.nominalBounds = nominalBounds;
  prototype.frameBounds = frameBounds;
  return prototype;
 }
 (lib.t4 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#0C593C").s().p("AAAAKIgJARIgIgGIAKgRIgQgGIADgKIAQAHIAAgVIAJAAIAAAVIAQgHIACAKIgPAGIAKARIgIAGg");
  this.shape.setTransform(285.5, 162.45);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#0C593C").s().p("AgmCDQgSgGgNgSQgLgPgDgQQgFgRAAgSIArAAIABAQQACAIAEAIQAFAMAJAFQAIAGAIABIAKABIAOgBQAHgCAHgGQAJgHADgKQADgJgBgJIgBgKQAAgGgDgHQgEgGgHgEQgFgFgIgBIgNgBIgWAAIAAgmIATAAIALgBQAGgBAGgDQAEgEAFgGQAEgIAAgLQAAgLgDgIQgEgHgEgFQgIgFgGgBQgHgDgEABQgGgBgHADQgIABgHAGQgIAHgDAJQgDAKAAAJIgrAAIABgQQACgKADgLQAEgKAFgJQANgPASgGQATgHAWAAIARACQAKABALAFQAKADAKAIQAKAJAEAKQAEAKABAKQACAKgBAGQABAJgDANQgDALgKALIgIAIQgFADgHABIAAACQAJACAGACIAKAHQAHAGAGAOQAGANAAAVQAAAWgIAPQgIAPgKAIQgIAHgPAFQgPAFgZABQgVAAgRgHg");
  this.shape_1.setTransform(272.85, 174.85);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#0C593C").s().p("AA2CCIgQg3IhLAAIgQA3IgsAAIBNkCIAoAAIBPECgAAdAkIgdhuIgbBuIA4AAg");
  this.shape_2.setTransform(252.75, 174.85);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#0C593C").s().p("AhSCCIAAkCIBTAAQATgBAQAFQARAEAMAPQALAOAEAPQADAQAAAMQgBAXgGAQQgGAOgJAJQgNAMgQAFQgQAEgPgBIgnAAIAABggAgmgEIAiAAQAHABAJgCQAJgCAHgIQAEgEADgHQADgIAAgMQAAgLgDgIQgCgHgEgFQgIgIgJgCQgJgCgGAAIgjAAg");
  this.shape_3.setTransform(233.6281, 174.8475);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#0C593C").s().p("AgmBiQgIgBgHgEQgIgFgHgLQgHgMAAgUQAAgJACgIQACgJAFgHQAFgHAGgFQAHgDAIgDQAIgDAKgBIAagGIAIgBQAFgCADgCIABgFIABgKQAAgIgCgHQgCgHgFgFQgFgDgEgCIgHgBQgLABgGAFQgGAFgCAFIgDAJIgBAKIgnAAQAAgIACgLQADgKAFgJQAHgMALgFQAKgGAKgCQALgCAJAAQAIAAANACQANADAMAIQAMAKAEANQAEAOAAAQIAABLIABAOIABAFQACADADAAIAGABIAAAfIgJAAIgMABQgEAAgGgBQgFgCgFgEQgEgDgCgFQgDgEgBgFIAAAAQgEAHgEAEIgGAFQgHAFgIADQgJADgLAAIgOgCgAATAHIgDABIgHADIgIADIgMADQgGABgDACQgIAFgCAGQgDAGAAAHIABAJQABAGAFAEIAGAFQAEABAEABQAGAAAGgDQAFgEAGgHQAGgJADgMQACgNAAgKIAAgHIgDACg");
  this.shape_4.setTransform(205.225, 178.25);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#0C593C").s().p("AgVBkQgLgCgKgGQgNgJgHgPQgHgPgBgRIAnAAQAAAFACAHQABAGAEAFQAGAIAHACQAGACAFAAIAIgBQAFgBAFgEQAFgDADgGQADgGAAgKQAAgFgCgGQgBgFgGgFQgFgDgGgBIgJgBIgPAAIAAgdIAMAAIAHgBQAFgBAFgDQAGgEACgHIABgLQAAgIgCgFQgCgFgEgDQgEgFgEgBIgIgBQgFAAgGACQgFACgFAIQgDAGgBAGIgBAKIgnAAQABgNAEgMQAEgMAHgJQALgLAOgEQAOgEALAAQALABANADQAOADALAKQAHAIAEAKQAFALAAAMQAAAJgDAIQgDAHgGAGQgEAFgDACIgHACIAAACQAFABAGABQAFADAGAHQAGAGACAHQACAIAAAIQAAANgDAKQgEAJgFAHQgFAGgFAEQgLAJgOACQgNACgLABIgVgCg");
  this.shape_5.setTransform(187.875, 178.4);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#0C593C").s().p("AgmBiQgIgBgHgEQgIgFgHgLQgHgMAAgUQAAgIACgJQACgJAFgHQAFgHAGgFQAHgDAIgDQAIgDAKgCIAagEIAIgCQAFgBADgDIABgFIABgKQAAgIgCgHQgCgHgFgFQgFgDgEgBIgHgBQgLAAgGAFQgGAFgCAFIgDAJIgBALIgnAAQAAgKACgKQADgJAFgKQAHgMALgFQAKgGAKgCQALgCAJAAQAIAAANADQANACAMAJQAMAJAEANQAEANAAASIAABKIABAOIABAEQACAEADABIAGAAIAAAfIgJAAIgMAAQgEABgGgBQgFgBgFgFQgEgDgCgEQgDgFgBgFIAAAAQgEAGgEAFIgGAFQgHAFgIADQgJADgLAAIgOgCgAATAHIgDABIgHAEIgIACIgMACQgGACgDADQgIAEgCAGQgDAGAAAHIABAJQABAFAFAFIAGAFQAEACAEgBQAGABAGgDQAFgDAGgIQAGgKADgMQACgMAAgKIAAgHIgDACg");
  this.shape_6.setTransform(291.375, 141.2);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#0C593C").s().p("AhDBeIgIgBIAAgeQALACAGgDQAHgEADgGQADgFACgJQACgJABgRIAAgsIAAg+IB0AAIAAC7IgpAAIAAicIgkAAIAAAjIgBAeIAAATIgBALQgCAUgGALQgFAMgGAGQgHAGgKAEQgJAEgMAAIgHgBg");
  this.shape_7.setTransform(272.725, 141.425);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#0C593C").s().p("AgoCAIgMgBIAAgeIAGABIAIABQAJAAAFgHQAGgFADgMIAFgQIhFi7IAsAAIAqCIIABAAIAhiIIAnAAIg5DLIgGASQgDALgHAKQgHAIgJAEQgIADgLAAIgMgBg");
  this.shape_8.setTransform(257.1, 144.85);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#0C593C").s().p("AACBlIgQgBQgJgCgKgFQgKgGgJgLQgKgMgFgSQgGgTAAgbQgBgIACgNQABgOAFgPQAEgPAKgMQAMgOAOgFQAOgFAMAAQAMAAAOAEQAOAEANANQAJAKAFANQAFANABANIgmAAIgDgNQgCgGgDgGQgEgGgGgEQgGgEgIAAQgIAAgGAFQgGAEgEAJQgEAJgCAJIgDATIAAAPQgBAMACANQACANAFAMQAGALAHAFQAHAFAHAAQAJAAAGgFQAGgFADgIQAEgJABgIIACgLIAmAAQgBALgEAOQgEANgIAMQgMAQgPAFQgNAGgNAAIgCgBg");
  this.shape_9.setTransform(240.6188, 141.3521);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.f("#0C593C").s().p("AAeBeIAAicIg7AAIAACcIgoAAIAAi7ICLAAIAAC7g");
  this.shape_10.setTransform(222.525, 141.35);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.f("#0C593C").s().p("AgmBiQgIgBgHgEQgIgFgHgLQgHgMAAgUQAAgIACgJQACgJAFgHQAFgHAGgFQAHgDAIgDQAIgDAKgCIAagEIAIgCQAFgBADgDIABgFIABgKQAAgIgCgHQgCgHgFgFQgFgDgEgBIgHgBQgLAAgGAFQgGAFgCAFIgDAJIgBALIgnAAQAAgKACgKQADgJAFgKQAHgMALgFQAKgGAKgCQALgCAJAAQAIAAANADQANACAMAJQAMAJAEANQAEANAAASIAABKIABAOIABAEQACAEADABIAGAAIAAAfIgJAAIgMAAQgEABgGgBQgFgBgFgFQgEgDgCgEQgDgFgBgFIAAAAQgEAGgEAFIgGAFQgHAFgIADQgJADgLAAIgOgCgAATAHIgDABIgHAEIgIACIgMACQgGACgDADQgIAEgCAGQgDAGAAAHIABAJQABAFAFAFIAGAFQAEACAEgBQAGABAGgDQAFgDAGgIQAGgKADgMQACgMAAgKIAAgHIgDACg");
  this.shape_11.setTransform(204.575, 141.2);
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.f("#0C593C").s().p("AAYBeIg0hbIAABbIgoAAIAAi7IAoAAIAABOIAxhOIAtAAIg+BXIBBBkg");
  this.shape_12.setTransform(188.875, 141.35);
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.f("#0C593C").s().p("AA2CBIgQg2IhLAAIgQA2IgsAAIBNkBIAoAAIBPEBgAAcAkIgchuIgbBuIA3AAg");
  this.shape_13.setTransform(257.7, 100.75);
  this.shape_14 = new cjs.Shape();
  this.shape_14.graphics.f("#0C593C").s().p("AApCBIAAh0IhSAAIAAB0IgrAAIAAkBIArAAIAABnIBSAAIAAhnIAsAAIAAEBg");
  this.shape_14.setTransform(236.725, 100.75);
  this.shape_15 = new cjs.Shape();
  this.shape_15.graphics.f("#0C593C").s().p("ABHCfIAAg7IiOAAIAAA7IglAAIgChiIATAAIAIgOIALgbQAFgRAFgWIADgbIADgdIABgbIAAg4ICKAAIAADbIAcAAIgBBigAgQhYIgBAkQgBASgCAQQgFAWgFAUQgHAUgIARIBUAAIAAi0Ig3AAg");
  this.shape_15.setTransform(214.25, 103.675);
  this.shape_16 = new cjs.Shape();
  this.shape_16.graphics.f("#0C593C").s().p("AgeCGQgQgFgQgOQgWgUgJgeQgJgdAAgkQAAgiAJgeQAJgeAWgUQAQgOAQgFQAQgDAOAAQAPAAAQADQAQAFAQAOQAWAUAJAeQAJAeAAAiQAAAkgJAdQgJAegWAUQgQAOgQAFQgQADgPAAQgOAAgQgDgAASBfQAJgDAKgLQAHgLAFgOQAEgOACgOQACgPAAgNQAAgMgCgOQgCgPgEgOQgFgOgHgLQgKgLgJgDQgKgDgIAAQgIAAgJADQgJADgKALQgIALgEAOQgFAOgCAPIgBAaIABAcQACAOAFAOQAEAOAIALQAKALAJADQAJADAIAAQAIAAAKgDg");
  this.shape_16.setTransform(191.4237, 100.75);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_16
   }, {
    t: this.shape_15
   }, {
    t: this.shape_14
   }, {
    t: this.shape_13
   }, {
    t: this.shape_12
   }, {
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
 }).prototype = getMCSymbolPrototype(lib.t4, new cjs.Rectangle(177.8, 77.2, 371.49999999999994, 123.2), null);
 (lib.t3 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#0C593C").s().p("AgUB+IAAgxIApAAIAAAxgAgLAwIgJhWIAAhXIApAAIAABXIgJBWg");
  this.shape.setTransform(344.75, 157.85);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#0C593C").s().p("AgUBhQgLgCgKgGQgMgJgIgOQgHgPAAgRIAlAAIACAMQACAHAEAFQAFAHAHACQAGACAFAAIAHgBQAFgBAFgEQAFgDADgGQADgFAAgKIgBgLQgCgFgGgFQgFgDgFgBQgFgBgEABIgPAAIAAgdIAMAAIAHgBQAFgBAEgDQAGgEACgGQACgGgBgFQAAgHgCgFQgCgGgDgDQgEgEgEgBIgIgBQgFAAgFACQgGACgFAHQgDAGgBAGIAAAJIgmAAQAAgMAEgMQAEgMAHgIQALgLAOgDQANgEALAAQAKAAAOADQANADALALQAHAHAEAKQAEAKAAAMQAAAJgDAHQgCAIgGAGQgEAEgEACIgHADIAAABQAFAAAGACQAGADAFAGQAGAHACAHQACAHAAAIQAAANgDAJQgEAJgFAHQgEAGgFADQgLAJgNACQgNADgLgBIgEABQgIAAgIgCg");
  this.shape_1.setTransform(330.825, 161.3019);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#0C593C").s().p("AglBgQgIgCgGgEQgJgEgGgMQgHgLAAgTQAAgJACgIQACgIAFgHQAFgHAGgFQAGgDAIgDIASgEIAZgFIAIgCQAFgBACgDIACgEIABgKQAAgIgCgHQgCgHgGgEQgEgEgEgBIgHgBQgKABgGAFQgGAEgCAFIgDAKIgBAJIgmAAQAAgJACgJQADgKAFgJQAHgLAKgGQAKgGAKgCIAUgBQAHAAANACQAMACAMAJQALAJAEANQAFANgBAQIAABJIABANIABAFQACADADABIAGAAIAAAeIgJAAIgLABIgKgBQgFgBgFgEQgEgDgCgFIgDgJIgBAAIgHAKIgGAGQgHAFgHACQgJADgLAAIgOgBgAATAHIgDABIgIADIgHACIgMADIgIAEQgIAEgCAGQgDAGAAAHIABAIQABAGAFAEQACADAEACQADACAFAAQAFAAAGgDQAFgDAGgIQAGgJACgMQADgMAAgKIAAgGIgDACg");
  this.shape_2.setTransform(314.075, 161.175);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#0C593C").s().p("Ag1BcIAAi2IBrAAIAAAdIhDAAIAACZg");
  this.shape_3.setTransform(299.7, 161.3);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#0C593C").s().p("AABBiQgLABgOgEQgOgFgNgOQgIgJgHgSQgHgSAAgdIABgWQABgNAFgOQAEgOAKgMQAMgPAPgFQAPgFALAAQAPAAAPAGQAPAGAMASQAIANAEATQAEATAAAcIhpAAQgBALADAMQADANAGAJQAGAIAHACQAGADAEAAQAFAAAHgCQAGgCAGgIIAFgJIACgKIAmAAQgCAMgFALQgFALgHAHQgMANgPADQgMAEgKAAIgDgBgAgMhAQgGADgDAFQgGAJgCAKQgDALAAAIIBBAAIAAgIIgCgNQgCgHgDgGQgFgJgHgEQgGgDgHAAQgHAAgGAEg");
  this.shape_4.setTransform(283.025, 161.3009);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#0C593C").s().p("AhBBcIgIgBIAAgeQAKADAHgEQAGgDAEgHQACgEACgJIADgZIAAgrIAAg8IBxAAIAAC2IgoAAIAAiZIgjAAIAAAjIAAAdIgBATIgBAKQgCATgFAMQgGALgGAFQgGAHgJADQgKAEgLAAIgHAAg");
  this.shape_5.setTransform(264.375, 161.375);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#0C593C").s().p("AAgBcIAAiCIg8CCIgqAAIAAi2IAnAAIAACBIA8iBIAqAAIAAC2g");
  this.shape_6.setTransform(247.425, 161.3);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#0C593C").s().p("AgTBcIAAiZIgwAAIAAgdICHAAIAAAdIgwAAIAACZg");
  this.shape_7.setTransform(230.85, 161.3);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#0C593C").s().p("AgmBXQgRgKgJgWQgGgNgDgOQgCgOAAgOQAAgNACgOQADgOAGgNQAJgVARgLQAQgMAWABQAXgBARAMQAQALAKAVQAFANADAOQACAOAAANQAAAOgCAOQgDAOgFANQgKAWgQAKQgRAMgXAAQgWAAgQgMgAgPg+QgGAEgFAKQgDAHgBAJIgDASIAAAOIAAAPIADASQABAJADAHQAFAJAGAGQAHAFAIAAQAKAAAGgFQAHgGAEgJQADgHACgJIACgSIABgPIgBgOIgCgSIgFgQQgEgKgHgEQgGgGgKAAQgIAAgHAGg");
  this.shape_8.setTransform(214.575, 161.3);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#0C593C").s().p("ABFB+IAAirIACgbIgCAAIg0DGIghAAIg0jGIgCAAIACAbIAACrIgqAAIAAj7IA8AAIAyC+IAzi+IA8AAIAAD7g");
  this.shape_9.setTransform(191.625, 157.85);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.f("#0C593C").s().p("AABBiQgLABgOgEQgOgFgNgOQgIgJgHgSQgHgSAAgdIABgWQABgNAFgOQAEgOAKgMQAMgPAPgFQAPgFALAAQAPAAAPAGQAPAGAMASQAIANAEATQAEATAAAcIhpAAQgBALADAMQADANAGAJQAGAIAHACQAGADAEAAQAFAAAHgCQAGgCAGgIIAFgJIACgKIAmAAQgCAMgFALQgFALgHAHQgMANgPADQgMAEgKAAIgDgBgAgMhAQgGADgDAFQgGAJgCAKQgDALAAAIIBBAAIAAgIIgCgNQgCgHgDgGQgFgJgHgEQgGgDgHAAQgHAAgGAEg");
  this.shape_10.setTransform(357.375, 122.4509);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.f("#0C593C").s().p("AgTBbIAAiYIgwAAIAAgdICIAAIAAAdIgyAAIAACYg");
  this.shape_11.setTransform(341.35, 122.45);
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.f("#0C593C").s().p("AAgB+IAAiCIg8CCIgqAAIAAi2IAnAAIAACCIA8iCIAqAAIAAC2gAgThMQgIgDgEgDIgHgFQgFgFgGgKQgFgIgDgPIAhAAIABAJQACAFADADQAEAGAFABQAFADAEAAQAEAAAGgDQAFgBAEgGQADgDACgFIABgJIAhAAQgDAPgFAIQgGAKgFAFIgHAFQgFADgHADQgIACgMAAQgLAAgIgCg");
  this.shape_12.setTransform(324.775, 119);
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.f("#0C593C").s().p("AglBgQgIgCgGgEQgJgEgGgMQgHgLAAgTQAAgJACgIQACgIAFgHQAFgHAGgFQAGgDAIgDIASgEIAZgFIAIgCQAFgBACgDIACgEIABgKQAAgIgCgHQgCgHgGgEQgEgEgEgBIgHgBQgKABgGAFQgGAEgCAFIgDAKIgBAJIgmAAQAAgJACgJQADgKAFgJQAHgLAKgGQAKgGAKgCIAUgBQAHAAANACQAMACAMAJQALAJAEANQAFANgBAQIAABJIABANIABAFQACADADABIAGAAIAAAeIgJAAIgLABIgKgBQgFgBgFgEQgEgDgCgFIgDgJIgBAAIgHAKIgGAGQgHAFgHACQgJADgLAAIgOgBgAATAHIgDABIgIADIgHACIgMADIgIAEQgIAEgCAGQgDAGAAAHIABAIQABAGAFAEQACADAEACQADACAFAAQAFAAAGgDQAFgDAGgIQAGgJACgMQADgMAAgKIAAgGIgDACg");
  this.shape_13.setTransform(306.675, 122.325);
  this.shape_14 = new cjs.Shape();
  this.shape_14.graphics.f("#0C593C").s().p("AA2BbIAAhzIABgSIgBAAIgmCFIgfAAIgmiFIgCAAIACASIAABzIgmAAIAAi1IAzAAIAoCHIApiHIAzAAIAAC1g");
  this.shape_14.setTransform(286.35, 122.45);
  this.shape_15 = new cjs.Shape();
  this.shape_15.graphics.f("#0C593C").s().p("AAgBbIAAiBIg8CBIgqAAIAAi1IAnAAIAACBIA8iBIAqAAIAAC1g");
  this.shape_15.setTransform(265.275, 122.45);
  this.shape_16 = new cjs.Shape();
  this.shape_16.graphics.f("#0C593C").s().p("AAcBbIAAhRIg2AAIAABRIgoAAIAAi1IAoAAIAABIIA2AAIAAhIIAnAAIAAC1g");
  this.shape_16.setTransform(246.8, 122.45);
  this.shape_17 = new cjs.Shape();
  this.shape_17.graphics.f("#0C593C").s().p("AAgBbIAAiBIg8CBIgqAAIAAi1IAnAAIAACBIA8iBIAqAAIAAC1g");
  this.shape_17.setTransform(228.275, 122.45);
  this.shape_18 = new cjs.Shape();
  this.shape_18.graphics.f("#0C593C").s().p("AhLCAIAAj4IAkAAIAAASIABAAIAHgJIAIgHQAGgEAHgCQAIgDAJAAQANAAAMAFQAMAFAKANQAKANAFAQQAFAPABANQABAMAAAFIgCAVQgBALgDAMQgDALgGAKQgEAJgIAHQgIAIgKAFQgLAFgNAAQgHAAgHgCQgHgCgGgEIgJgIIgGgIIgBAAIAABTgAAJAlQAHgEAHgKQAEgHAEgMQADgLAAgUIgBgWQgBgMgFgMQgGgPgJgFQgIgFgGAAQgGAAgIAFQgJAFgGAPQgFALgBAMIgCAWIABAPIADARQADAKAFAJQAGAJAGAEQAGAEAHgBQAEABAHgDg");
  this.shape_18.setTransform(209.6563, 125.425);
  this.shape_19 = new cjs.Shape();
  this.shape_19.graphics.f("#0C593C").s().p("AAoB+IAAjVIhPAAIAADVIgqAAIAAj7ICjAAIAAD7g");
  this.shape_19.setTransform(188.725, 119);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_19
   }, {
    t: this.shape_18
   }, {
    t: this.shape_17
   }, {
    t: this.shape_16
   }, {
    t: this.shape_15
   }, {
    t: this.shape_14
   }, {
    t: this.shape_13
   }, {
    t: this.shape_12
   }, {
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
 }).prototype = getMCSymbolPrototype(lib.t3, new cjs.Rectangle(176, 96, 269, 86.69999999999999), null);
 (lib.t2 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#0C593C").s().p("AAAAKIgKASIgHgGIAKgSIgQgGIACgKIARAHIAAgWIAJAAIAAAWIARgHIACAKIgQAGIAKASIgHAGg");
  this.shape.setTransform(277.325, 185.575);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#0C593C").s().p("AAhBeIAAiFIg9CFIgsAAIAAi7IAoAAIAACFIA9iFIAsAAIAAC7g");
  this.shape_1.setTransform(261.975, 199.2);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#0C593C").s().p("AhDBeIgIgBIAAgeQALACAGgDQAHgEADgGQADgFACgJQACgJABgRIAAgsIAAg+IB0AAIAAC7IgpAAIAAicIgkAAIAAAjIgBAeIAAATIgBALQgCAUgGALQgFAMgGAGQgHAGgKAEQgJAEgMAAIgHgBg");
  this.shape_2.setTransform(244.275, 199.275);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#0C593C").s().p("AgnBaQgSgMgJgWQgHgMgCgPQgDgPAAgOQAAgNADgPQACgOAHgNQAJgXASgLQAQgMAXABQAXgBASAMQAQALAKAXQAGANADAOQADAPAAANQAAAOgDAPQgDAPgGAMQgKAWgQAMQgSALgXAAQgXAAgQgLgAgQhAQgGAFgFAKQgDAHgBAJQgDAJAAAJIgBAPIABAQQAAAIADAKQABAJADAHQAFAKAGAFQAHAGAJAAQAJAAAHgGQAHgFAEgKQAEgHACgJIACgSIAAgQIAAgPIgCgSQgCgJgEgHQgEgKgHgFQgHgGgJAAQgJAAgHAGg");
  this.shape_3.setTransform(229.2, 199.2);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#0C593C").s().p("AgZCJQgLgFgHgFQgIgHgFgGQgLgNgFgRQgFgRgBgRIgBgeQAAgcACgUQACgSACgMIAFgRQAFgNAJgLQAJgLAOgGQAKgEALgCIAXgEQAOgBAEgEQAFgEAAgEIAeAAIgCAMIgEAKQgGAOgLAGQgLAGgPACQgOACgLAEQgNAEgJAHQgKAJgFAPIgDAOIgBANIgBAKIACAAIAFgNQAEgHAFgHQAIgJALgGQAKgFAOAAQAOAAALAFQALAFAIAIQAJALAGANQAGANADAOQADAOAAAPQAAASgFATQgFATgLAQQgNAPgPAHQgPAGgQAAQgOAAgLgDgAgMgWQgHADgHANQgGALgCAOQgCANAAAKQAAAJACAOQACANAGAMQAGANAIADQAHAFAFgBQAHAAAHgEQAIgFAGgMQAGgLABgNQACgOAAgJIgBgPIgCgTQgCgIgEgHQgFgLgHgEQgHgFgHAAIgBAAQgFAAgIAFg");
  this.shape_4.setTransform(212.2523, 195.3);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#0C593C").s().p("AAhBeIAAiFIg9CFIgsAAIAAi7IAoAAIAACFIA9iFIAsAAIAAC7g");
  this.shape_5.setTransform(187.475, 199.2);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#0C593C").s().p("AAhBeIAAiFIg9CFIgsAAIAAi7IAoAAIAACGIA9iGIAsAAIAAC7g");
  this.shape_6.setTransform(411.825, 161.15);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#0C593C").s().p("AAhBeIAAiFIg9CFIgsAAIAAi7IAoAAIAACGIA9iGIAsAAIAAC7g");
  this.shape_7.setTransform(394.375, 161.15);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#0C593C").s().p("AAcBeIAAhUIg3AAIAABUIgpAAIAAi7IApAAIAABKIA3AAIAAhKIApAAIAAC7g");
  this.shape_8.setTransform(377.375, 161.15);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#0C593C").s().p("AgmBiQgIgBgHgEQgIgFgHgLQgHgMAAgUQAAgIACgJQACgJAFgHQAFgHAGgFQAHgDAIgDQAIgDAKgCIAagEIAIgCQAFgBADgDIABgFIABgKQAAgIgCgHQgCgHgFgFQgFgDgEgBIgHgBQgLAAgGAFQgGAFgCAFIgDAJIgBALIgnAAQAAgKACgKQADgJAFgKQAHgMALgFQAKgGAKgCQALgCAJAAQAIAAANADQANACAMAJQAMAJAEANQAEANAAASIAABKIABAOIABAEQACAEADABIAGAAIAAAfIgJAAIgMAAQgEABgGgBQgFgBgFgFQgEgDgCgEQgDgFgBgFIAAAAQgEAGgEAFIgGAFQgHAFgIADQgJADgLAAIgOgCgAATAHIgDABIgHAEIgIACIgMACQgGACgDADQgIAEgCAGQgDAGAAAHIABAJQABAFAFAFIAGAFQAEACAEgBQAGABAGgDQAFgDAGgIQAGgKADgMQACgMAAgKIAAgHIgDACg");
  this.shape_9.setTransform(361.275, 161);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.f("#0C593C").s().p("AhDBeIAAi7IBRAAQAKAAAJACQAJACAIAHQAIAIADAKQADAJgBAIQAAAIgCAJQgDAHgFAGQgGAHgEACIgJAEIAAACIALACIAKAHQAGAFADAIQAFAJAAAOQgBAPgEAKQgEAJgGAEQgGAFgJAEQgLAEgPAAgAgbA/IAaAAIAIgBQAGgBAEgCQAEgCADgFQADgFAAgIQAAgIgDgFQgBgFgEgDQgFgEgHgCIgKAAIgYAAgAgbgRIAWAAIAJgBQAGgCAEgDQAFgEACgFIABgJQAAgGgBgFQgDgEgFgEIgGgCIgIAAIgaAAg");
  this.shape_10.setTransform(345.85, 161.15);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.f("#0C593C").s().p("AgnBaQgRgLgKgXQgGgNgDgOQgCgOAAgPQAAgNACgPQADgOAGgNQAKgXARgLQAQgLAXAAQAXAAASALQARALAJAXQAGANADAOQACAPAAANQAAAPgCAOQgDAOgGANQgJAXgRALQgSALgXAAQgXAAgQgLgAgQhAQgGAFgFAKQgDAHgBAJIgDASIgBAPIABAQIADASQABAJADAIQAFAJAGAFQAHAGAJAAQAJAAAHgGQAHgFAEgJQAEgIACgJIACgSIAAgQIAAgPIgCgSQgCgJgEgHQgEgKgHgFQgHgGgJAAQgJAAgHAGg");
  this.shape_11.setTransform(329.2, 161.15);
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.f("#0C593C").s().p("AgVBkQgLgCgKgHQgNgIgHgPQgHgPgBgSIAnAAQAAAGACAHQABAGAEAGQAGAHAHACQAGACAFAAIAIgBQAFgBAFgEQAFgDADgGQADgGAAgJQAAgFgCgHQgBgFgGgFQgFgDgGgBIgJgBIgPAAIAAgdIAMAAIAHgBQAFgBAFgDQAGgEACgGIABgMQAAgHgCgGQgCgFgEgDQgEgEgEgCIgIgBQgFAAgGACQgFACgFAIQgDAGgBAGIgBAKIgnAAQABgNAEgNQAEgMAHgIQALgLAOgEQAOgEALABQALAAANACQAOADALAMQAHAGAEALQAFALAAAMQAAAJgDAHQgDAIgGAHQgEAEgDACIgHADIAAABQAFAAAGACQAFADAGAGQAGAIACAHQACAGAAAJQAAAOgDAJQgEAKgFAGQgFAHgFADQgLAIgOADQgNACgLAAIgVgBg");
  this.shape_12.setTransform(313.125, 161.15);
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.f("#0C593C").s().p("AgmBiQgIgBgHgEQgIgFgHgLQgHgMAAgUQAAgIACgJQACgJAFgHQAFgHAGgFQAHgDAIgDQAIgDAKgCIAagEIAIgCQAFgBADgDIABgFIABgKQAAgIgCgHQgCgHgFgFQgFgDgEgBIgHgBQgLAAgGAFQgGAFgCAFIgDAJIgBALIgnAAQAAgKACgKQADgJAFgKQAHgMALgFQAKgGAKgCQALgCAJAAQAIAAANADQANACAMAJQAMAJAEANQAEANAAASIAABKIABAOIABAEQACAEADABIAGAAIAAAfIgJAAIgMAAQgEABgGgBQgFgBgFgFQgEgDgCgEQgDgFgBgFIAAAAQgEAGgEAFIgGAFQgHAFgIADQgJADgLAAIgOgCgAATAHIgDABIgHAEIgIACIgMACQgGACgDADQgIAEgCAGQgDAGAAAHIABAJQABAFAFAFIAGAFQAEACAEgBQAGABAGgDQAFgDAGgIQAGgKADgMQACgMAAgKIAAgHIgDACg");
  this.shape_13.setTransform(297.975, 161);
  this.shape_14 = new cjs.Shape();
  this.shape_14.graphics.f("#0C593C").s().p("AhNCEIAAkAIAmAAIAAATIABAAQACgEAEgFQAEgEAEgDQAGgEAIgDQAIgCAJgBQAOAAAMAGQAMAFAKANQALAOAFAPQAFAQABANIABASIgBAWIgFAXQgDAMgGAKQgFAJgHAIQgIAIgLAEQgLAGgOAAQgHAAgHgCQgHgCgGgEQgFgEgEgEIgHgJIgBAAIAABWgAgRhgQgIAGgHAOQgEAMgCAMQgCANABAKIAAAPQABAJACAJQADAKAFAJQAGAKAHADQAGAEAHAAQAEABAHgEQAIgCAGgLQAFgHAEgNQADgLAAgVIgBgXQgBgMgFgMQgHgPgIgGQgIgFgHABIgBgBQgGAAgIAFg");
  this.shape_14.setTransform(281.625, 164.2);
  this.shape_15 = new cjs.Shape();
  this.shape_15.graphics.f("#0C593C").s().p("AgZCJQgLgEgHgGQgIgHgFgGQgLgNgFgRQgFgQgBgSIgBgeQAAgcACgTQACgTACgMIAFgRQAFgOAJgKQAJgLAOgGQAKgEALgCIAXgDQAOgCAEgEQAFgEAAgFIAeAAIgCANIgEAKQgGAOgLAGQgLAGgPACQgOACgLAEQgNADgJAJQgKAHgFAQIgDAOIgBANIgBAKIACAAIAFgNQAEgIAFgGQAIgJALgGQAKgFAOgBQAOABALAFQALAGAIAHQAJAKAGAOQAGANADAOQADAPAAAOQAAASgFATQgFATgLAPQgNARgPAGQgPAHgQgBQgOAAgLgDgAgMgXQgHAFgHAMQgGALgCAOQgCANAAAKQAAAJACAOQACAMAGANQAGAMAIAFQAHADAFAAQAHAAAHgEQAIgEAGgMQAGgMABgNQACgOAAgJIgBgPIgCgSQgCgJgEgHQgFgLgHgFQgHgEgHABIgBgBQgFAAgIAEg");
  this.shape_15.setTransform(263.8523, 157.25);
  this.shape_16 = new cjs.Shape();
  this.shape_16.graphics.f("#0C593C").s().p("AgnBaQgRgLgKgXQgGgNgDgOQgCgOAAgPQAAgNACgPQADgOAGgNQAKgXARgLQAQgLAXAAQAXAAASALQARALAJAXQAGANADAOQACAPAAANQAAAPgCAOQgDAOgGANQgJAXgRALQgSALgXAAQgXAAgQgLgAgPhAQgHAFgFAKQgDAHgBAJIgDASIgBAPIABAQIADASQABAJADAIQAFAJAHAFQAGAGAJAAQAKAAAGgGQAHgFAEgJQADgIADgJIACgSIAAgQIAAgPIgCgSQgDgJgDgHQgEgKgHgFQgGgGgKAAQgJAAgGAGg");
  this.shape_16.setTransform(246.5, 161.15);
  this.shape_17 = new cjs.Shape();
  this.shape_17.graphics.f("#0C593C").s().p("AgoBaQgQgLgLgXQgFgNgDgOQgCgOgBgPQABgNACgPQADgOAFgNQALgXAQgLQARgLAXAAQAXAAARALQARALAKAXQAGANACAOQADAPAAANQAAAPgDAOQgCAOgGANQgKAXgRALQgRALgXAAQgXAAgRgLgAgPhAQgHAFgEAKQgEAHgCAJIgCASIAAAPIAAAQIACASQACAJAEAIQAEAJAHAFQAGAGAJAAQAKAAAGgGQAHgFAEgJQADgIACgJIADgSIABgQIgBgPIgDgSQgCgJgDgHQgEgKgHgFQgGgGgKAAQgJAAgGAGg");
  this.shape_17.setTransform(229.7, 161.15);
  this.shape_18 = new cjs.Shape();
  this.shape_18.graphics.f("#0C593C").s().p("AgVBkQgLgCgKgHQgNgIgHgPQgHgPgBgSIAnAAQAAAGACAHQABAGAEAGQAGAHAHACQAGACAFAAIAIgBQAFgBAFgEQAFgDADgGQADgGAAgJQAAgFgCgHQgBgFgGgFQgFgDgGgBIgJgBIgPAAIAAgdIAMAAIAHgBQAFgBAFgDQAGgEACgGIABgMQAAgHgCgGQgCgFgEgDQgEgEgEgCIgIgBQgFAAgGACQgFACgFAIQgDAGgBAGIgBAKIgnAAQABgNAEgNQAEgMAHgIQALgLAOgEQAOgEALABQALAAANACQAOADALAMQAHAGAEALQAFALAAAMQAAAJgDAHQgDAIgGAHQgEAEgDACIgHADIAAABQAFAAAGACQAFADAGAGQAGAIACAHQACAGAAAJQAAAOgDAJQgEAKgFAGQgFAHgFADQgLAIgOADQgNACgLAAIgVgBg");
  this.shape_18.setTransform(213.625, 161.15);
  this.shape_19 = new cjs.Shape();
  this.shape_19.graphics.f("#0C593C").s().p("AgmBiQgIgBgHgEQgIgFgHgLQgHgMAAgUQAAgIACgJQACgJAFgHQAFgHAGgFQAHgDAIgDQAIgDAKgCIAagEIAIgCQAFgBADgDIABgFIABgKQAAgIgCgHQgCgHgFgFQgFgDgEgBIgHgBQgLAAgGAFQgGAFgCAFIgDAJIgBALIgnAAQAAgKACgKQADgJAFgKQAHgMALgFQAKgGAKgCQALgCAJAAQAIAAANADQANACAMAJQAMAJAEANQAEANAAASIAABKIABAOIABAEQACAEADABIAGAAIAAAfIgJAAIgMAAQgEABgGgBQgFgBgFgFQgEgDgCgEQgDgFgBgFIAAAAQgEAGgEAFIgGAFQgHAFgIADQgJADgLAAIgOgCgAATAHIgDABIgHAEIgIACIgMACQgGACgDADQgIAEgCAGQgDAGAAAHIABAJQABAFAFAFIAGAFQAEACAEgBQAGABAGgDQAFgDAGgIQAGgKADgMQACgMAAgKIAAgHIgDACg");
  this.shape_19.setTransform(198.475, 161);
  this.shape_20 = new cjs.Shape();
  this.shape_20.graphics.f("#0C593C").s().p("Ag2BeIAAi7IBuAAIAAAfIhGAAIAACcg");
  this.shape_20.setTransform(185.7, 161.15);
  this.shape_21 = new cjs.Shape();
  this.shape_21.graphics.f("#0C593C").s().p("AgTAdIAHgCQAEgCAEgGQADgHAAgMIAAgDIgSAAIAAgyIAnAAIAAAzQAAALgCAMQgDALgKAKQgFAFgGADQgGADgHABg");
  this.shape_21.setTransform(355.8792, 132.925);
  this.shape_22 = new cjs.Shape();
  this.shape_22.graphics.f("#0C593C").s().p("AAhBeIAAiFIg9CFIgsAAIAAi7IAoAAIAACGIA9iGIAsAAIAAC7g");
  this.shape_22.setTransform(342.725, 123.1);
  this.shape_23 = new cjs.Shape();
  this.shape_23.graphics.f("#0C593C").s().p("AAhBeIAAiFIg9CFIgsAAIAAi7IAoAAIAACGIA9iGIAsAAIAAC7g");
  this.shape_23.setTransform(325.275, 123.1);
  this.shape_24 = new cjs.Shape();
  this.shape_24.graphics.f("#0C593C").s().p("AgTBeIAAidIgyAAIAAgeICLAAIAAAeIgyAAIAACdg");
  this.shape_24.setTransform(310.275, 123.1);
  this.shape_25 = new cjs.Shape();
  this.shape_25.graphics.f("#0C593C").s().p("AgpCAIgKgCIAAgdIAGAAIAGABQAKABAFgHQAGgGADgKIAFgRIhFi7IAsAAIApCIIACAAIAhiIIAnAAIg5DMIgFASQgEAKgIAKQgGAIgIADQgJAEgMAAIgMgBg");
  this.shape_25.setTransform(296.75, 126.6);
  this.shape_26 = new cjs.Shape();
  this.shape_26.graphics.f("#0C593C").s().p("AA5B3IAAgyIhxAAIAAAyIgjAAIgDhQIAVAAIAHgQIAGgTQAHgYACgWQACgWAAgVIAAghIB1AAIAACdIAbAAIgDBQgAgNhAIgBAYIgDAZQgCAOgEANQgFAOgFANIA9AAIAAh+IgpAAg");
  this.shape_26.setTransform(280.725, 125.55);
  this.shape_27 = new cjs.Shape();
  this.shape_27.graphics.f("#0C593C").s().p("AgVBkQgLgCgKgHQgNgIgHgPQgHgPgBgSIAnAAQAAAGACAHQABAHAEAFQAGAHAHACQAGACAFAAIAIgBQAFgBAFgDQAFgEADgGQADgGAAgJQAAgGgCgFQgBgHgGgEQgFgDgGgBIgJgBIgPAAIAAgdIAMAAIAHgBQAFgBAFgDQAGgFACgFIABgMQAAgIgCgFQgCgGgEgDQgEgDgEgBIgIgCQgFAAgGACQgFADgFAHQgDAGgBAGIgBAJIgnAAQABgMAEgNQAEgMAHgIQALgLAOgEQAOgDALgBQALAAANADQAOAEALALQAHAHAEAKQAFALAAAMQAAAJgDAHQgDAIgGAHQgEAEgDACIgHADIAAABQAFABAGABQAFADAGAGQAGAHACAIQACAGAAAJQAAANgDAKQgEAJgFAHQgFAGgFAEQgLAIgOADQgNADgLAAIgVgCg");
  this.shape_27.setTransform(264.475, 123.1);
  this.shape_28 = new cjs.Shape();
  this.shape_28.graphics.f("#0C593C").s().p("AhEBeIAAi7IBRAAQAKAAAKACQAJACAIAHQAJAIACAJQACAKAAAIQAAAJgCAIQgCAHgGAGQgFAHgFACIgJAEIAAACIAMACIAJAHQAFAFAEAJQAEAIABAOQAAAPgFAKQgFAJgFAEQgFAGgLADQgKAEgPAAgAgbA/IAaAAIAJgBQAFAAAEgDQAEgCADgFQACgFABgIQgBgIgBgFQgCgFgEgDQgFgEgHgBIgKgBIgYAAgAgbgSIAWAAIAJgBQAFgBAFgDQAFgEABgFIACgJQAAgFgCgGQgCgEgFgDIgGgDIgIgBIgaAAg");
  this.shape_28.setTransform(249.7, 123.1);
  this.shape_29 = new cjs.Shape();
  this.shape_29.graphics.f("#0C593C").s().p("AAhBeIAAiFIg9CFIgsAAIAAi7IAoAAIAACGIA9iGIAsAAIAAC7g");
  this.shape_29.setTransform(225.625, 123.1);
  this.shape_30 = new cjs.Shape();
  this.shape_30.graphics.f("#0C593C").s().p("AhNCEIAAkAIAmAAIAAATIABAAIAGgJQAEgEAEgDQAGgEAIgDQAIgDAJAAQAOAAAMAFQAMAGAKANQALAOAFAPQAFARABAMIABATIgBAVIgFAXQgDAMgGAKQgFAJgHAIQgIAIgLAEQgLAGgOAAQgHAAgHgCQgHgCgGgEQgFgEgEgEIgHgJIgBAAIAABWgAgRhgQgIAGgHAPQgEALgCAMQgCANABAKIAAAQQABAIACAJQADAKAFAJQAGAKAHADQAGAFAHAAQAEAAAHgEQAIgDAGgKQAFgHAEgNQADgLAAgVIgBgXQgBgLgFgNQgHgPgIgGQgIgFgHABIgBgBQgGAAgIAFg");
  this.shape_30.setTransform(208.525, 126.15);
  this.shape_31 = new cjs.Shape();
  this.shape_31.graphics.f("#0C593C").s().p("AApCBIAAjaIhRAAIAADaIgsAAIAAkCICpAAIAAECg");
  this.shape_31.setTransform(189.025, 119.55);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_31
   }, {
    t: this.shape_30
   }, {
    t: this.shape_29
   }, {
    t: this.shape_28
   }, {
    t: this.shape_27
   }, {
    t: this.shape_26
   }, {
    t: this.shape_25
   }, {
    t: this.shape_24
   }, {
    t: this.shape_23
   }, {
    t: this.shape_22
   }, {
    t: this.shape_21
   }, {
    t: this.shape_20
   }, {
    t: this.shape_19
   }, {
    t: this.shape_18
   }, {
    t: this.shape_17
   }, {
    t: this.shape_16
   }, {
    t: this.shape_15
   }, {
    t: this.shape_14
   }, {
    t: this.shape_13
   }, {
    t: this.shape_12
   }, {
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
 }).prototype = getMCSymbolPrototype(lib.t2, new cjs.Rectangle(176, 96, 365, 125.19999999999999), null);
 (lib.packshot_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.packshot();
  this.instance.parent = this;
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));
 }).prototype = getMCSymbolPrototype(lib.packshot_1, new cjs.Rectangle(0, 0, 352, 170), null);
 (lib.orange = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#0C593C").s().p("AAAANIgLAUIgKgIIAMgUIgTgHIADgMIAUAHIAAgZIALAAIAAAZIAUgHIADAMIgUAHIANAUIgKAIg");
  this.shape.setTransform(106.25, 40.75);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#FFFFFF").s().p("AgNBUIAAghIAcAAIAAAhgAgHAfIgGg4IAAg6IAcAAIAAA6IgHA4g");
  this.shape_1.setTransform(99.8, 54);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#FFFFFF").s().p("AAjBUIgKgjIgxAAIgKAjIgdAAIAzinIAaAAIAyCngAATAXIgThHIgRBHIAkAAg");
  this.shape_2.setTransform(90.825, 54);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#FFFFFF").s().p("AAXBUIgyhUIAABUIgdAAIAAinIAdAAIAABIIAvhIIAgAAIg1BOIA6BZg");
  this.shape_3.setTransform(79.7, 54);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#FFFFFF").s().p("AAbBUIAAhMIg1AAIAABMIgcAAIAAinIAcAAIAABDIA1AAIAAhDIAcAAIAACng");
  this.shape_4.setTransform(65.975, 54);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#FFFFFF").s().p("AAcBUIAAh6Ig4B6IgcAAIAAinIAdAAIAAB6IA4h6IAcAAIAACng");
  this.shape_5.setTransform(52.25, 54);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#FFFFFF").s().p("Ag3BUIAAinIA/AAQAHAAAJACQAIACAHAIQAHAHACAIQACAIAAAHQAAAHgCAHQgCAHgGAHIgFAFIgIADIAAABIAJADIAIAFQAEAEAEAIQADAIAAANQABAIgDAJQgCAKgJAJQgGAFgGADQgHACgGABIgLAAgAgaA7IAaAAIALgBQAFgBAEgEQAEgEABgFIABgKIgBgJQgBgFgEgEQgEgEgFgBQgFgCgGABIgaAAgAgagOIAaAAIAHgBQAFgBAEgEIADgGQACgDAAgGIgBgIQgBgFgDgDQgDgEgFgBQgEgCgFAAIgZAAg");
  this.shape_6.setTransform(39.0042, 53.9958);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#FFFFFF").s().p("AAABZQgJAAgKgDQgLgDgKgIQgOgNgGgUQgGgTAAgXQAAgWAGgTQAGgUAOgNQAKgIALgDQAKgDAJAAQAKAAAKADQALADAKAIQAOANAGAUQAGATAAAWQAAAXgGATQgGAUgOANQgKAIgLADQgIADgJAAIgDAAgAAMA9QAGgCAGgHQAFgHADgIQADgJABgKIABgSIgBgRQgBgKgDgJQgDgIgFgHQgGgHgGgCQgGgDgGAAQgEAAgGADQgHACgGAHQgFAHgDAIQgDAJgBAKIgBARIABASQABAKADAJQADAIAFAHQAGAHAHACQAGADAEAAQAGAAAGgDg");
  this.shape_7.setTransform(25.075, 54);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#FFFFFF").s().p("AAbBUIAAhMIg1AAIAABMIgcAAIAAinIAcAAIAABDIA1AAIAAhDIAcAAIAACng");
  this.shape_8.setTransform(11.175, 54);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#E07E22").s().p("AlvFvQiYiXAAjYQAAjXCYiYQCZiYDWAAQDXAACZCYQCYCYAADXQAADYiYCXQiZCZjXAAQjWAAiZiZg");
  this.shape_9.setTransform(52, 52);
  this.timeline.addTween(cjs.Tween.get(this.shape_9).wait(1));
 }).prototype = getMCSymbolPrototype(lib.orange, new cjs.Rectangle(0, 0, 124.3, 104), null);
 (lib.logo = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#FFFFFF").s().p("AgjAxIAShhIA1AAIgCAPIgkAAIgFAZIAiAAIgDANIgiAAIgFAdIAmAAIgDAPg");
  this.shape.setTransform(918.7514, 55.4807, 0.9439, 0.9436);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#FFFFFF").s().p("AgZAxIAQhSIgbAAIADgPIBGAAIgDAPIgbAAIgPBSg");
  this.shape_1.setTransform(911.9787, 55.4807, 0.9439, 0.9436);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#FFFFFF").s().p("AglAxIAShfQAIgCAPAAQAQAAAJAGQAJAIAAAMQAAARgNAIQgLAJgSAAIgJAAIgHAlgAgFgiIgGAhIAJABQAKAAAGgGQAHgGAAgIQAAgPgRAAg");
  this.shape_2.setTransform(903.554, 55.4571, 0.9439, 0.9436);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#FFFFFF").s().p("AgjAmQgJgLAAgRQAAgbARgSQAPgOATAAQATAAAKAMQAJAKAAASQAAAcgRARQgNAOgVAAQgSAAgLgMgAgRgUQgJAOAAAPQAAAbAWAAIABAAQAMAAAKgPQAJgOAAgPQAAgbgXAAQgNAAgJAPg");
  this.shape_3.setTransform(894.681, 55.4807, 0.9439, 0.9436);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#FFFFFF").s().p("AgRA1IABgJQgNgDgIgJQgLgKABgQQAAgYAQgOQAOgMARAAIACgIIAQAAIgCAJQAOACAJAJQAJAKABARQAAAXgQAOQgNAMgUAAIgBAJgAACAgQANgBAIgKQAJgLAAgQQAAgWgSgDgAgVgVQgJALAAAPQAAALAEAHQAGAHAHABIAMg/QgLABgJAKg");
  this.shape_4.setTransform(884.3685, 55.4807, 0.9439, 0.9436);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#005942").s().p("AhzBhQgggkAOg9QAPg5AtglQAugkA6AAQA4AAAdAiQAgAlgOA7QgQA/gyAkQgtAfg2AAQg3AAgdghgAgkg2QgXAXgIAiQgKAoATAXQAOAQAXAAQAdAAAZgYQAagZAJgjQAEgRgCgQQgCgUgKgMQgMgNgXAAQgiAAgZAag");
  this.shape_5.setTransform(762.1781, 33.1912, 0.9075, 0.8978);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#80BC1E").s().p("AguA0QgPgRAIgjQACAZAOAJQAOAJASgIQAsgVALhLQAHAKAAATQAAAKgDAMIgCAIQgFAMgGAKQgLATgRAMQgPALgSAAQgRAAgJgKg");
  this.shape_6.setTransform(762.1426, 33.7299, 0.9075, 0.8978);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#80BC1E").s().p("AhNBxQgZgVAAgnIAAgJIA3AAIAAAEQAAATAMAKQALALAUgBQASAAALgKQAMgLABgWQAAgHgEgGQgDgGgFgCIgMgEQgGgCgIAAIgSAAIAIgpIALAAIAPgDQAJgBAGgEQAGgEAEgHQAFgIAAgKQAAgZggAAQgPAAgMAIQgLAHgFAVIg3AAQAEgYAJgQQAJgQAOgJQAPgKASgEQASgFAVABQAWgBAPAGQAOAEAKAKQAKAJAEAMQAEAKAAAQQAAAKgDAJQgEALgFAHQgEAGgJAHQgIAGgHACQAPACAKAOQAKAOAAAVQAAAXgHARQgJARgOAMQgOALgUAHQgTAFgXAAQgtAAgYgVg");
  this.shape_7.setTransform(913.7359, 32.7015, 0.9075, 0.8978);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#80BC1E").s().p("AhGCBQgNgFgJgKQgJgIgEgNQgEgKAAgPQAAgmAVgWQAWgUAngHIAkgEQAPgBALgEQALgDAEgGQAFgGAAgNQAAgKgEgFQgEgHgFgDQgGgDgGgBIgNgBQgPgBgMAKQgNAIgDAUIg4AAQADgZAKgPQAJgPAOgLQAQgLAQgDQAQgFASABQANAAASACQAOACAPAIQAOAHAIANQAJAOgBAVQAAARgEAaIgUBlIgCAjQAAAHACAIIg8AAIAAgZQgMAQgRAIQgRAHgTAAQgRABgOgGgAATAPIgZACIgRAEQgJADgFAEQgFADgEAJQgEAHAAAMQAAAPAKAGQAKAIAMAAQAOAAAJgFQAJgGAHgIQAEgFAGgNQAEgLACgKIAGgZQgMAJgMABg");
  this.shape_8.setTransform(892.7091, 32.7015, 0.9075, 0.8978);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#80BC1E").s().p("AhnCAIAvj/ICgAAIgKA1IhkAAIglDKg");
  this.shape_9.setTransform(874.3277, 32.7239, 0.9075, 0.8978);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.f("#005942").s().p("AgrB8QgUgIgPgTQgPgSgGgYQgIgZAAgdQAAgdAIgYQAHgZAPgRQAPgSAUgLQAUgLAYABQAagBAUAMQAUALANATQAOAVAGAXQAHAZAAAbIgBANIibAAQABAiANAQQAOAPAZAAQARAAANgLQAOgKADgMIA0AAQgNAugaATQgaAVglgBQgYAAgVgKgAgXhLQgJAHgFAHQgGAJgCAJQgCAGgBALIBgAAQgEgcgLgNQgLgOgWAAQgNAAgKAGg");
  this.shape_10.setTransform(853.2509, 32.7015, 0.9075, 0.8978);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.f("#005942").s().p("AhXCBIgagEIAAg2IAJACIAKAAQAOAAAHgPIADgKIADgaQACgWAAggQABgYAAhJICyAAIAAD/Ig7AAIAAjKIg9AAIgBBDIgDAxQgCASgDASQgFAQgEAHQgHAOgNAIQgOAJgUAAg");
  this.shape_11.setTransform(829.0887, 32.9035, 0.9075, 0.8978);
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.f("#005942").s().p("AAuCAIAAisIhRCsIhDAAIAAj/IA5AAIAACsIBRisIBDAAIAAD/g");
  this.shape_12.setTransform(806.2197, 32.7239, 0.9075, 0.8978);
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.f("#005942").s().p("AgdCAIAAjKIhHAAIAAg1IDJAAIAAA1IhHAAIAADKg");
  this.shape_13.setTransform(784.3716, 32.7239, 0.9075, 0.8978);
  this.shape_14 = new cjs.Shape();
  this.shape_14.graphics.f("#005942").s().p("ABkCwIAAj5IgBAAIhJD5IgzAAIhJj2IgBAAIAAD2Ig+AAIAAlgIBdAAIBFDyIABAAIBDjyIBdAAIAAFgg");
  this.shape_14.setTransform(733.5061, 28.3469, 0.9075, 0.8978);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_14
   }, {
    t: this.shape_13
   }, {
    t: this.shape_12
   }, {
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
  this.shape_15 = new cjs.Shape();
  this.shape_15.graphics.lf(["#FFFFFF", "#F27E20"], [0.612, 0.765], -162.7, -0.2, 143.8, -0.2).s().p("AsmBPQlugIkQiSIgEgDMAtRAAAIAAADIAACag");
  this.shape_15.setTransform(824.925, 54.825);
  this.timeline.addTween(cjs.Tween.get(this.shape_15).wait(1));
  this.shape_16 = new cjs.Shape();
  this.shape_16.graphics.f("#FFFFFF").s().p("Ay3DsQkgidi4k6MA0fAAAIAAHVMgtHAAAIAEACg");
  this.shape_16.setTransform(801.8, 23.925);
  this.timeline.addTween(cjs.Tween.get(this.shape_16).wait(1));
 }).prototype = getMCSymbolPrototype(lib.logo, new cjs.Rectangle(633.8, 0.3, 336.1, 62.400000000000006), null);
 (lib.l3 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#0C593C").s().p("AAyBOIAAhiIABgPIABgSIgBAAIgrCDIgRAAIgpiDIgCAAIACASIAAAQIAABhIgTAAIAAibIAdAAIAoB+IAAAAIAph+IAdAAIAACbg");
  this.shape.setTransform(953.8, 23.425);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#0C593C").s().p("AggBFQgNgKgGgTQgGgSAAgWQAAgmAOgVQAPgUAcAAQAUAAANALQANAKAGASQAGASAAAWQAAAXgGASQgGASgNAKQgNALgUAAQgUAAgMgLgAgbguQgJAQAAAeQAAAfAJAQQAJAQASAAQATAAAJgQQAJgQAAgfQAAgegJgQQgJgQgTAAQgSAAgJAQg");
  this.shape_1.setTransform(938.025, 23.425);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#0C593C").s().p("AgJBOIAAiKIglAAIAAgRIBdAAIAAARIglAAIAACKg");
  this.shape_2.setTransform(926.075, 23.425);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#0C593C").s().p("AgfA7QgQgVAAgmQAAgWAHgRQAHgTANgKQAOgLATAAQAUAAAPAJIgHAPQgGgDgHgCQgHgCgHAAQgOAAgIAIQgJAJgEAPQgFANAAASQAAAcALASQALARASAAQAIgBAIgCIANgDIAAAQQgNAGgSAAQgbAAgQgVg");
  this.shape_3.setTransform(915.775, 23.4);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#0C593C").s().p("AAjBOIAAhbIAAgSIABgRIgBAAIhAB+IgYAAIAAibIATAAIAABaIAAARIgBASIABAAIA/h9IAZAAIAACbg");
  this.shape_4.setTransform(902.65, 23.425);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#0C593C").s().p("Ag2BMIAAgQQADACAGAAQAIAAADgIQADgIADgRIADgaIAEgmIAFgrIBHAAIAACbIgUAAIAAiJIgiAAIgCAZIgDAbIgDAYIgCAUQgEAPgDAJQgEAKgFAEQgHAFgLAAQgGAAgFgDg");
  this.shape_5.setTransform(888.15, 23.525);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#0C593C").s().p("AAkBOIgNgxIgtAAIgNAxIgWAAIAuibIAWAAIAvCbgAgCgwIgCALIgOAxIAkAAIgOgxIgCgLIgCgLIgCALg");
  this.shape_6.setTransform(876.875, 23.425);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#0C593C").s().p("AAjBOIAAhbIAAgSIABgRIgBAAIhAB+IgYAAIAAibIATAAIAABaIAAARIgBASIABAAIA/h9IAZAAIAACbg");
  this.shape_7.setTransform(863.95, 23.425);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#0C593C").s().p("AAmBjIAAgqIheAAIAAibIAUAAIAACKIA4AAIAAiKIAVAAIAACKIAQAAIAAA7g");
  this.shape_8.setTransform(850.55, 25.525);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#0C593C").s().p("AgjBOIAAibIBHAAIAAARIgzAAIAAAxIAwAAIAAAQIgwAAIAAA4IAzAAIAAARg");
  this.shape_9.setTransform(838.325, 23.425);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.f("#0C593C").s().p("AAdBOIAAiKIg5AAIAACKIgUAAIAAibIBhAAIAACbg");
  this.shape_10.setTransform(825.975, 23.425);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.f("#0C593C").s().p("AgfA7QgQgVAAgmQAAgWAHgRQAHgTANgKQAOgLATAAQAUAAAPAJIgHAPQgGgDgHgCQgHgCgHAAQgOAAgIAIQgJAJgEAPQgFANAAASQAAAcALASQALARASAAQAIgBAIgCIANgDIAAAQQgNAGgSAAQgbAAgQgVg");
  this.shape_11.setTransform(813.875, 23.4);
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.f("#0C593C").s().p("AggBFQgNgKgGgTQgGgSAAgWQAAgmAOgVQAPgUAcAAQAUAAANALQANAKAGASQAGASAAAWQAAAXgGASQgGASgNAKQgNALgUAAQgUAAgMgLgAgbguQgJAQAAAeQAAAfAJAQQAJAQASAAQATAAAJgQQAJgQAAgfQAAgegJgQQgJgQgTAAQgSAAgJAQg");
  this.shape_12.setTransform(796.275, 23.425);
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.f("#0C593C").s().p("AgfA7QgQgVAAgmQAAgWAHgRQAHgTANgKQAOgLATAAQAUAAAPAJIgHAPQgGgDgHgCQgHgCgHAAQgOAAgIAIQgJAJgEAPQgFANAAASQAAAcALASQALARASAAQAIgBAIgCIANgDIAAAQQgNAGgSAAQgbAAgQgVg");
  this.shape_13.setTransform(783.875, 23.4);
  this.shape_14 = new cjs.Shape();
  this.shape_14.graphics.f("#0C593C").s().p("AgrBOIAAibIAUAAIAABBIARAAQAaAAAMAMQAMAKAAAWQAAAVgNANQgNAMgXAAgAgXA9IARAAQAeAAAAgdQAAgPgIgHQgIgGgPAAIgQAAg");
  this.shape_14.setTransform(767.925, 23.425);
  this.shape_15 = new cjs.Shape();
  this.shape_15.graphics.f("#0C593C").s().p("AgfA7QgQgVAAgmQAAgWAHgRQAHgTANgKQAOgLATAAQAUAAAPAJIgHAPQgGgDgHgCQgHgCgHAAQgOAAgIAIQgJAJgEAPQgFANAAASQAAAcALASQALARASAAQAIgBAIgCIANgDIAAAQQgNAGgSAAQgbAAgQgVg");
  this.shape_15.setTransform(756.325, 23.4);
  this.shape_16 = new cjs.Shape();
  this.shape_16.graphics.f("#0C593C").s().p("AgjBOIAAibIBHAAIAAARIgzAAIAAAxIAwAAIAAAQIgwAAIAAA4IAzAAIAAARg");
  this.shape_16.setTransform(745.625, 23.425);
  this.shape_17 = new cjs.Shape();
  this.shape_17.graphics.f("#0C593C").s().p("AgJBOIAAiKIglAAIAAgRIBdAAIAAARIglAAIAACKg");
  this.shape_17.setTransform(735.275, 23.425);
  this.shape_18 = new cjs.Shape();
  this.shape_18.graphics.f("#0C593C").s().p("AAiBmIAAhdIAAgRIACgQIgBAAIhAB+IgYAAIAAibIATAAIAABZIAAARIgBATIABAAIBAh9IAYAAIAACbgAgYhMQgJgIgBgRIARAAQABAMAFAFQAEAEAIAAQAJAAAFgEQAEgFABgMIARAAQgBARgJAIQgIAIgSAAQgQAAgJgIg");
  this.shape_18.setTransform(722.95, 21.05);
  this.shape_19 = new cjs.Shape();
  this.shape_19.graphics.f("#0C593C").s().p("AgmBOIgIgCIAAgRQAGADAIAAQAGAAAEgDQAEgCADgGQADgGAEgMIgshvIAWAAIAcBJIACAHIABAKIABAAIADgJIACgHIAYhKIAWAAIgnBvQgFARgHAKQgFAKgHAEQgJAFgLAAIgIgBg");
  this.shape_19.setTransform(710.6, 23.525);
  this.shape_20 = new cjs.Shape();
  this.shape_20.graphics.f("#0C593C").s().p("AgpBOIAAibIAiAAQAZAAANAMQAMALgBAXQABAXgMAMQgNANgbAAIgMAAIAAA9gAgVABIAKAAQARAAAIgHQAIgHAAgRQAAgQgIgHQgHgHgPAAIgNAAg");
  this.shape_20.setTransform(700.1, 23.425);
  this.shape_21 = new cjs.Shape();
  this.shape_21.graphics.f("#0C593C").s().p("AAiBOIAAhbIAAgSIACgRIgBAAIhAB+IgYAAIAAibIATAAIAABaIAAARIgBASIABAAIA/h9IAZAAIAACbg");
  this.shape_21.setTransform(686.85, 23.425);
  this.shape_22 = new cjs.Shape();
  this.shape_22.graphics.f("#0C593C").s().p("AgJBOIAAiKIglAAIAAgRIBdAAIAAARIglAAIAACKg");
  this.shape_22.setTransform(674.775, 23.425);
  this.shape_23 = new cjs.Shape();
  this.shape_23.graphics.f("#0C593C").s().p("AgrBOIAAibIAUAAIAABBIARAAQAaAAAMAMQAMAKAAAWQAAAVgNANQgNAMgXAAgAgXA9IARAAQAeAAAAgdQAAgPgIgHQgIgGgPAAIgQAAg");
  this.shape_23.setTransform(664.525, 23.425);
  this.shape_24 = new cjs.Shape();
  this.shape_24.graphics.f("#0C593C").s().p("Ag2BMIAAgQQADACAGAAQAIAAADgIQADgIADgRIADgaIAEgmIAFgrIBHAAIAACbIgUAAIAAiJIgiAAIgCAZIgDAbIgDAYIgCAUQgEAPgDAJQgEAKgFAEQgHAFgLAAQgGAAgFgDg");
  this.shape_24.setTransform(651, 23.525);
  this.shape_25 = new cjs.Shape();
  this.shape_25.graphics.f("#0C593C").s().p("AgnBOIgHgCIAAgRQAGADAIAAQAGAAAEgDQAEgCADgGQADgGAEgMIgrhvIAVAAIAbBJIADAHIACAKIABAAIACgJIACgHIAYhKIAVAAIgmBvQgFARgHAKQgFAKgIAEQgIAFgLAAIgJgBg");
  this.shape_25.setTransform(640.35, 23.525);
  this.shape_26 = new cjs.Shape();
  this.shape_26.graphics.f("#0C593C").s().p("AgfA7QgQgVAAgmQAAgWAHgRQAHgTANgKQAOgLATAAQAUAAAPAJIgHAPQgGgDgHgCQgHgCgHAAQgOAAgIAIQgJAJgEAPQgFANAAASQAAAcALASQALARASAAQAIgBAIgCIANgDIAAAQQgNAGgSAAQgbAAgQgVg");
  this.shape_26.setTransform(629.575, 23.4);
  this.shape_27 = new cjs.Shape();
  this.shape_27.graphics.f("#0C593C").s().p("AAdBOIAAhJIg5AAIAABJIgVAAIAAibIAVAAIAABCIA5AAIAAhCIAUAAIAACbg");
  this.shape_27.setTransform(616.9, 23.425);
  this.shape_28 = new cjs.Shape();
  this.shape_28.graphics.f("#0C593C").s().p("AggBFQgNgKgGgTQgGgSAAgWQAAgmAOgVQAPgUAcAAQAUAAANALQANAKAGASQAGASAAAWQAAAXgGASQgGASgNAKQgNALgUAAQgUAAgMgLgAgbguQgJAQAAAeQAAAfAJAQQAJAQASAAQATAAAJgQQAJgQAAgfQAAgegJgQQgJgQgTAAQgSAAgJAQg");
  this.shape_28.setTransform(603.125, 23.425);
  this.shape_29 = new cjs.Shape();
  this.shape_29.graphics.f("#0C593C").s().p("AAYBOIgzhPIAABPIgUAAIAAibIAUAAIAABLIAyhLIAWAAIgyBLIA1BQg");
  this.shape_29.setTransform(591.375, 23.425);
  this.shape_30 = new cjs.Shape();
  this.shape_30.graphics.f("#0C593C").s().p("AggBFQgNgKgGgTQgGgSAAgWQAAgmAOgVQAPgUAcAAQAUAAANALQANAKAGASQAGASAAAWQAAAXgGASQgGASgNAKQgNALgUAAQgUAAgMgLgAgbguQgJAQAAAeQAAAfAJAQQAJAQASAAQATAAAJgQQAJgQAAgfQAAgegJgQQgJgQgTAAQgSAAgJAQg");
  this.shape_30.setTransform(577.825, 23.425);
  this.shape_31 = new cjs.Shape();
  this.shape_31.graphics.f("#0C593C").s().p("AgpBOIAAibIAiAAQAZAAANAMQAMALgBAXQABAXgMAMQgNANgbAAIgNAAIAAA9gAgWABIALAAQARAAAIgHQAIgHAAgRQAAgQgIgHQgHgHgPAAIgOAAg");
  this.shape_31.setTransform(565.65, 23.425);
  this.shape_32 = new cjs.Shape();
  this.shape_32.graphics.f("#0C593C").s().p("AAdBOIAAiKIg5AAIAACKIgUAAIAAibIBhAAIAACbg");
  this.shape_32.setTransform(552.675, 23.425);
  this.shape_33 = new cjs.Shape();
  this.shape_33.graphics.f("#0C593C").s().p("AAyBOIAAhiIABgPIAAgSIAAAAIgrCDIgRAAIgpiDIgCAAIACASIAAAQIAABhIgTAAIAAibIAdAAIAoB+IAAAAIAph+IAdAAIAACbg");
  this.shape_33.setTransform(532.6, 23.425);
  this.shape_34 = new cjs.Shape();
  this.shape_34.graphics.f("#0C593C").s().p("AgjBOIAAibIBHAAIAAARIgzAAIAAAxIAwAAIAAAQIgwAAIAAA4IAzAAIAAARg");
  this.shape_34.setTransform(519.075, 23.425);
  this.shape_35 = new cjs.Shape();
  this.shape_35.graphics.f("#0C593C").s().p("AAiBOIAAhbIAAgSIACgRIgBAAIhAB+IgYAAIAAibIATAAIAABaIAAARIgBASIABAAIBAh9IAYAAIAACbg");
  this.shape_35.setTransform(506.5, 23.425);
  this.shape_36 = new cjs.Shape();
  this.shape_36.graphics.f("#0C593C").s().p("AAeBOIAAhJIg6AAIAABJIgUAAIAAibIAUAAIAABCIA6AAIAAhCIAUAAIAACbg");
  this.shape_36.setTransform(492.55, 23.425);
  this.shape_37 = new cjs.Shape();
  this.shape_37.graphics.f("#0C593C").s().p("AgjBOIAAibIBHAAIAAARIgzAAIAAAxIAwAAIAAAQIgwAAIAAA4IAzAAIAAARg");
  this.shape_37.setTransform(481.125, 23.425);
  this.shape_38 = new cjs.Shape();
  this.shape_38.graphics.f("#0C593C").s().p("AAdBOIAAhJIg5AAIAABJIgUAAIAAibIAUAAIAABCIA5AAIAAhCIAVAAIAACbg");
  this.shape_38.setTransform(468.95, 23.425);
  this.shape_39 = new cjs.Shape();
  this.shape_39.graphics.f("#0C593C").s().p("AgjBOIAAibIBHAAIAAARIgzAAIAAAxIAwAAIAAAQIgwAAIAAA4IAzAAIAAARg");
  this.shape_39.setTransform(457.525, 23.425);
  this.shape_40 = new cjs.Shape();
  this.shape_40.graphics.f("#0C593C").s().p("AAyBOIAAhiIAAgPIABgSIgBAAIgqCDIgQAAIgqiDIgBAAIABASIAAAQIAABhIgTAAIAAibIAdAAIAoB+IAAAAIAph+IAdAAIAACbg");
  this.shape_40.setTransform(443.35, 23.425);
  this.shape_41 = new cjs.Shape();
  this.shape_41.graphics.f("#0C593C").s().p("AAjBOIAAhbIAAgSIABgRIgBAAIhAB+IgYAAIAAibIATAAIAABaIAAARIgBASIABAAIA/h9IAZAAIAACbg");
  this.shape_41.setTransform(427.35, 23.425);
  this.shape_42 = new cjs.Shape();
  this.shape_42.graphics.f("#0C593C").s().p("AgpBOIAAibIAiAAQAZAAAMAMQAMALAAAXQAAAXgMAMQgMANgaAAIgOAAIAAA9gAgWABIALAAQARAAAIgHQAIgHAAgRQAAgQgIgHQgHgHgPAAIgOAAg");
  this.shape_42.setTransform(415, 23.425);
  this.shape_43 = new cjs.Shape();
  this.shape_43.graphics.f("#0C593C").s().p("AAdBOIAAiKIg5AAIAACKIgUAAIAAibIBhAAIAACbg");
  this.shape_43.setTransform(402.025, 23.425);
  this.shape_44 = new cjs.Shape();
  this.shape_44.graphics.f("#0C593C").s().p("AArBjIAAgqIhVAAIAAAqIgTAAIAAg7IALAAQANggAIgiQAIgjABglIBCAAIAACKIAQAAIAAA7gAgHgnQgDAWgGATQgGAUgHASIA3AAIAAh5IgcAAQgBAVgEAVg");
  this.shape_44.setTransform(379.4, 25.525);
  this.shape_45 = new cjs.Shape();
  this.shape_45.graphics.f("#0C593C").s().p("AgjBOIAAibIBHAAIAAARIgzAAIAAAxIAwAAIAAAQIgwAAIAAA4IAzAAIAAARg");
  this.shape_45.setTransform(368.425, 23.425);
  this.shape_46 = new cjs.Shape();
  this.shape_46.graphics.f("#0C593C").s().p("AgpBOIAAibIAiAAQAZAAAMAMQAMALAAAXQAAAXgMAMQgMANgaAAIgOAAIAAA9gAgWABIALAAQARAAAIgHQAIgHAAgRQAAgQgIgHQgHgHgPAAIgOAAg");
  this.shape_46.setTransform(357.85, 23.425);
  this.shape_47 = new cjs.Shape();
  this.shape_47.graphics.f("#0C593C").s().p("AgjBOIAAibIBHAAIAAARIgzAAIAAAxIAwAAIAAAQIgwAAIAAA4IAzAAIAAARg");
  this.shape_47.setTransform(347.075, 23.425);
  this.shape_48 = new cjs.Shape();
  this.shape_48.graphics.f("#0C593C").s().p("AAdBOIAAiKIg5AAIAACKIgUAAIAAibIBhAAIAACbg");
  this.shape_48.setTransform(334.725, 23.425);
  this.shape_49 = new cjs.Shape();
  this.shape_49.graphics.f("#0C593C").s().p("AgJAKQgDgDAAgHQAAgGADgDQAEgEAFAAQAGAAADADQAEADAAAHQAAAHgEAEQgDADgGAAQgFAAgEgEg");
  this.shape_49.setTransform(316.075, 30);
  this.shape_50 = new cjs.Shape();
  this.shape_50.graphics.f("#0C593C").s().p("AAbBOIAAhBIgUAAIgfBBIgXAAIAkhFQgNgEgGgKQgIgLAAgQQAAgtAyAAIAkAAIAACbgAgKg2QgHAHAAAPQAAAeAdAAIAPAAIAAg7IgOAAQgOAAgJAHg");
  this.shape_50.setTransform(306.8, 23.425);
  this.shape_51 = new cjs.Shape();
  this.shape_51.graphics.f("#0C593C").s().p("AAiBOIAAhbIAAgSIACgRIgBAAIhAB+IgYAAIAAibIATAAIAABaIAAARIgBASIABAAIA/h9IAZAAIAACbg");
  this.shape_51.setTransform(294.45, 23.425);
  this.shape_52 = new cjs.Shape();
  this.shape_52.graphics.f("#0C593C").s().p("AAdBOIAAhJIg5AAIAABJIgUAAIAAibIAUAAIAABCIA5AAIAAhCIAVAAIAACbg");
  this.shape_52.setTransform(280.5, 23.425);
  this.shape_53 = new cjs.Shape();
  this.shape_53.graphics.f("#0C593C").s().p("AAkBOIgNgxIgtAAIgNAxIgWAAIAuibIAWAAIAvCbgAgCgwIgCALIgOAxIAkAAIgOgxIgCgLIgCgLIgCALg");
  this.shape_53.setTransform(268.025, 23.425);
  this.shape_54 = new cjs.Shape();
  this.shape_54.graphics.f("#0C593C").s().p("AgaBOQgKgCgIgDIAAgSQAHAEAKACQAKADAJAAQAgAAAAgeQAAgPgKgHQgJgHgSAAIgPAAIAAgPIAPAAQAiAAAAgdQAAgMgHgGQgGgGgLAAQgKAAgHAEQgHADgGAEIgJgNQAIgHAKgDQAKgEANAAQAUAAALALQAMAKAAARQAAAPgJAKQgIAKgPADIAAABQARACAJAJQAJAKAAAQQAAAUgNANQgNAMgZAAQgLAAgJgCg");
  this.shape_54.setTransform(256.525, 23.425);
  this.shape_55 = new cjs.Shape();
  this.shape_55.graphics.f("#0C593C").s().p("AAkBOIgNgxIgtAAIgNAxIgWAAIAuibIAWAAIAvCbgAgCgwIgCALIgOAxIAkAAIgOgxIgCgLIgCgLIgCALg");
  this.shape_55.setTransform(245.575, 23.425);
  this.shape_56 = new cjs.Shape();
  this.shape_56.graphics.f("#0C593C").s().p("AAYBOIgzhPIAABPIgUAAIAAibIAUAAIAABLIAyhLIAWAAIgyBLIA1BQg");
  this.shape_56.setTransform(235.075, 23.425);
  this.shape_57 = new cjs.Shape();
  this.shape_57.graphics.f("#0C593C").s().p("AggBFQgNgKgGgTQgGgSAAgWQAAgmAOgVQAPgUAcAAQAUAAANALQANAKAGASQAGASAAAWQAAAXgGASQgGASgNAKQgNALgUAAQgUAAgMgLgAgbguQgJAQAAAeQAAAfAJAQQAJAQASAAQATAAAJgQQAJgQAAgfQAAgegJgQQgJgQgTAAQgSAAgJAQg");
  this.shape_57.setTransform(221.525, 23.425);
  this.shape_58 = new cjs.Shape();
  this.shape_58.graphics.f("#0C593C").s().p("AAdBOIAAiKIg5AAIAACKIgUAAIAAibIBhAAIAACbg");
  this.shape_58.setTransform(207.525, 23.425);
  this.shape_59 = new cjs.Shape();
  this.shape_59.graphics.f("#0C593C").s().p("AggBFQgNgKgGgTQgGgSAAgWQAAgmAOgVQAPgUAcAAQAUAAANALQANAKAGASQAGASAAAWQAAAXgGASQgGASgNAKQgNALgUAAQgUAAgMgLgAgbguQgJAQAAAeQAAAfAJAQQAJAQASAAQATAAAJgQQAJgQAAgfQAAgegJgQQgJgQgTAAQgSAAgJAQg");
  this.shape_59.setTransform(193.875, 23.425);
  this.shape_60 = new cjs.Shape();
  this.shape_60.graphics.f("#0C593C").s().p("AgtBOIAAibIAoAAQAWAAANAJQAMAKAAATQAAAPgGAJQgHAJgMACIAAABQAOADAIAIQAHAJAAAQQAAAVgMAMQgMAMgWAAgAgZA+IAYAAQANAAAGgIQAHgIAAgOQAAgNgHgHQgHgHgOAAIgWAAgAgZgKIAVAAQAOAAAFgHQAHgHAAgNQAAgYgbAAIgUAAg");
  this.shape_60.setTransform(181.25, 23.425);
  this.shape_61 = new cjs.Shape();
  this.shape_61.graphics.f("#0C593C").s().p("AAjBOIAAhbIAAgSIABgRIgBAAIhAB+IgYAAIAAibIAUAAIAABaIAAARIgCASIABAAIA/h9IAZAAIAACbg");
  this.shape_61.setTransform(167.7, 23.425);
  this.shape_62 = new cjs.Shape();
  this.shape_62.graphics.f("#0C593C").s().p("AgJBOIAAiKIglAAIAAgRIBdAAIAAARIglAAIAACKg");
  this.shape_62.setTransform(155.575, 23.425);
  this.shape_63 = new cjs.Shape();
  this.shape_63.graphics.f("#0C593C").s().p("AggBFQgNgKgGgTQgGgSAAgWQAAgmAOgVQAPgUAcAAQAUAAANALQANAKAGASQAGASAAAWQAAAXgGASQgGASgNAKQgNALgUAAQgUAAgMgLgAgbguQgJAQAAAeQAAAfAJAQQAJAQASAAQATAAAJgQQAJgQAAgfQAAgegJgQQgJgQgTAAQgSAAgJAQg");
  this.shape_63.setTransform(143.675, 23.425);
  this.shape_64 = new cjs.Shape();
  this.shape_64.graphics.f("#0C593C").s().p("AgpBOIAAibIAiAAQAZAAANAMQALALAAAXQAAAXgLAMQgNANgaAAIgOAAIAAA9gAgWABIALAAQARAAAIgHQAIgHAAgRQAAgQgIgHQgHgHgPAAIgOAAg");
  this.shape_64.setTransform(131.5, 23.425);
  this.shape_65 = new cjs.Shape();
  this.shape_65.graphics.f("#0C593C").s().p("AAdBOIAAiKIg5AAIAACKIgUAAIAAibIBhAAIAACbg");
  this.shape_65.setTransform(118.525, 23.425);
  this.shape_66 = new cjs.Shape();
  this.shape_66.graphics.f("#0C593C").s().p("AAcBOIAAhBIgVAAIgfBBIgXAAIAkhFQgMgEgIgKQgGgLgBgQQABgtAxAAIAkAAIAACbgAgKg2QgHAHAAAPQAAAeAdAAIAQAAIAAg7IgPAAQgPAAgIAHg");
  this.shape_66.setTransform(95.95, 23.425);
  this.shape_67 = new cjs.Shape();
  this.shape_67.graphics.f("#0C593C").s().p("AgfA7QgQgVAAgmQAAgWAHgRQAHgTANgKQAOgLATAAQAUAAAPAJIgHAPQgGgDgHgCQgHgCgHAAQgOAAgIAIQgJAJgEAPQgFANAAASQAAAcALASQALARASAAQAIgBAIgCIANgDIAAAQQgNAGgSAAQgbAAgQgVg");
  this.shape_67.setTransform(85.425, 23.4);
  this.shape_68 = new cjs.Shape();
  this.shape_68.graphics.f("#0C593C").s().p("AgJBOIAAiKIglAAIAAgRIBdAAIAAARIglAAIAACKg");
  this.shape_68.setTransform(74.525, 23.425);
  this.shape_69 = new cjs.Shape();
  this.shape_69.graphics.f("#0C593C").s().p("AgPA8QgOgTgBgkIgcAAIAABJIgUAAIAAibIAUAAIAABCIAcAAQACghAOgRQAOgSAYAAQAaAAAOAVQAPAVAAAlQAAAXgGASQgGASgMAKQgMALgTAAQgZAAgOgUgAgBguQgIAQAAAeQAAAfAIAQQAHAQARAAQASAAAIgQQAIgQAAgfQAAgegIgQQgIgQgRAAQgSAAgHAQg");
  this.shape_69.setTransform(60.575, 23.425);
  this.shape_70 = new cjs.Shape();
  this.shape_70.graphics.f("#0C593C").s().p("AgjBOIAAibIBHAAIAAARIgzAAIAAAxIAwAAIAAAQIgwAAIAAA4IAzAAIAAARg");
  this.shape_70.setTransform(46.175, 23.425);
  this.shape_71 = new cjs.Shape();
  this.shape_71.graphics.f("#0C593C").s().p("AAyBOIAAhiIABgPIABgSIgBAAIgrCDIgRAAIgqiDIgBAAIABASIABAQIAABhIgTAAIAAibIAdAAIAoB+IAAAAIAph+IAdAAIAACbg");
  this.shape_71.setTransform(32, 23.425);
  this.shape_72 = new cjs.Shape();
  this.shape_72.graphics.f("#0C593C").s().p("AAjBOIAAhbIAAgSIABgRIgBAAIhAB+IgYAAIAAibIATAAIAABaIAAARIgBASIABAAIA/h9IAZAAIAACbg");
  this.shape_72.setTransform(16.05, 23.425);
  this.shape_73 = new cjs.Shape();
  this.shape_73.graphics.f("#0C593C").s().p("AgWAyQAAgJABgHQACgGAEgHQAFgGAJgJQAGgGAEgGQAEgHAAgJQAAgRgNAAQgHAAgDAGQgCAGAAAMIgJAAIAAgFQAAgIACgHQADgHAFgDQAFgEAGAAQAHAAAGADQAFAEACAGQADAGAAAJQAAAHgCAGQgCAFgEAEIgIAKIgMAOQgEAEgBADIgCAIIAjAAIAAAKg");
  this.shape_73.setTransform(706.325, 6.275);
  this.shape_74 = new cjs.Shape();
  this.shape_74.graphics.f("#0C593C").s().p("AgEAHIAAgNIAJAAIAAANg");
  this.shape_74.setTransform(698.075, 10.625);
  this.shape_75 = new cjs.Shape();
  this.shape_75.graphics.f("#0C593C").s().p("AALAlIAAhAIgWAAIAABAIgJAAIAAhJIAoAAIAABJg");
  this.shape_75.setTransform(693.2, 7.575);
  this.shape_76 = new cjs.Shape();
  this.shape_76.graphics.f("#0C593C").s().p("AgUAzIAAhjIAIAAIAAAIIABAAQACgEADgEQAEgCACAAQAWAAAAAmIgBAPIgEANQgCAFgEADQgEAEgGAAQgDgBgDgCQgEgCgCgFIAAAhgAgJggQgDAIABANIAAAOQABAHACAEQAEAEAEABQAHgBACgHQADgIAAgPQAAgdgMAAQgHAAgCAJg");
  this.shape_76.setTransform(686.95, 8.75);
  this.shape_77 = new cjs.Shape();
  this.shape_77.graphics.f("#0C593C").s().p("AgMAkQgEgEgEgJQgCgJAAgOQAAgSAGgKQAFgKALAAQAXAAAAAmQAAAPgDAIQgDAJgEAEQgGADgHAAQgGAAgGgDgAgHgaQgDADgCAHIgBARIABAQQACAGADAEQACADAFAAQAFAAADgDQADgEABgGQACgHgBgJQABgLgCgHQgBgGgEgDQgDgDgEAAQgEAAgDADg");
  this.shape_77.setTransform(680.5, 7.575);
  this.shape_78 = new cjs.Shape();
  this.shape_78.graphics.f("#0C593C").s().p("AALAlIgPglIgHALIAAAaIgJAAIAAhJIAJAAIAAAiIAVgiIALAAIgUAdIAUAsg");
  this.shape_78.setTransform(674.875, 7.575);
  this.shape_79 = new cjs.Shape();
  this.shape_79.graphics.f("#0C593C").s().p("AgEALQAFgDAAgKIgFAAIAAgNIAJAAIAAAPQAAAGgCAEQgDAFgEABg");
  this.shape_79.setTransform(666.525, 11.6);
  this.shape_80 = new cjs.Shape();
  this.shape_80.graphics.f("#0C593C").s().p("AgOAxQABgQAEgPQAEgQAGgNQAGgOAJgNIgnAAIAAgKIAvAAIAAAJQgGAJgFALIgJAVIgFAXIgDAYg");
  this.shape_80.setTransform(661.625, 6.375);
  this.shape_81 = new cjs.Shape();
  this.shape_81.graphics.f("#0C593C").s().p("AAFAyIAAhIIgSAAIAAgJQAHAAAEgBQADgCADgEQACgEAAgHIAIAAIAABjg");
  this.shape_81.setTransform(654.65, 6.275);
  this.shape_82 = new cjs.Shape();
  this.shape_82.graphics.f("#0C593C").s().p("AgEAHIAAgNIAJAAIAAANg");
  this.shape_82.setTransform(650.375, 10.625);
  this.shape_83 = new cjs.Shape();
  this.shape_83.graphics.f("#0C593C").s().p("AATAvIAAgUIglAAIAAAUIgIAAIAAgdIAFAAIAFgNIACgLIABgQIAAgYIAiAAIAABAIAGAAIAAAdgAgEgRQAAALgCAHIgFARIAXAAIAAg3IgQAAg");
  this.shape_83.setTransform(645.375, 8.6);
  this.shape_84 = new cjs.Shape();
  this.shape_84.graphics.f("#0C593C").s().p("AgEALQAFgDAAgKIgFAAIAAgNIAJAAIAAAPQAAAGgCAEQgDAFgEABg");
  this.shape_84.setTransform(636.975, 11.6);
  this.shape_85 = new cjs.Shape();
  this.shape_85.graphics.f("#0C593C").s().p("AALAlIAAgfIgJAAIgMAfIgKAAIANggQgFgDgDgEQgDgGAAgHQAAgGADgFQABgFAFgDQAEgCAFAAIAVAAIAABJgAgGgYQgDADABAGQgBANAKAAIAKAAIAAgaIgJAAQgGAAgCAEg");
  this.shape_85.setTransform(632.1, 7.575);
  this.shape_86 = new cjs.Shape();
  this.shape_86.graphics.f("#0C593C").s().p("AgVATQAAgHABgEQACgEADgDQAEgCAGgCIAKgGQADgBAAgIQAAgGgCgDQgDgCgEAAQgFAAgCADQgDADAAAHIgIAAQAAgWATAAQAFAAAEACQAEADACAEQACAEAAAGIAAArQAAAGADAAIACgBIAAAIIgDABQgFAAgCgCQgCgCgBgHIgBAAQgBAFgEAEQgDADgFAAQgQAAAAgUgAABABIgHAEIgEAFQgCADAAAFQAAAMAJAAQAFAAADgFIACgCIAAgEIABgHIAAgOIgHADg");
  this.shape_86.setTransform(626.725, 7.575);
  this.shape_87 = new cjs.Shape();
  this.shape_87.graphics.f("#0C593C").s().p("AALAlIgPglIgHALIAAAaIgJAAIAAhJIAJAAIAAAiIAVgiIALAAIgUAdIAUAsg");
  this.shape_87.setTransform(621.375, 7.575);
  this.shape_88 = new cjs.Shape();
  this.shape_88.graphics.f("#0C593C").s().p("AgLAiQgFgFgCgJQgCgIAAgLQAAgnAWAAQAJAAAFAHQAFAHAAALIgJAAQAAgQgLAAQgGAAgDAIQgCAJAAANQAAANACAIQACAIAHAAQAHAAACgFQACgFAAgJIAJAAQAAAMgFAIQgEAIgKAAQgJAAgEgFg");
  this.shape_88.setTransform(615.375, 7.575);
  this.shape_89 = new cjs.Shape();
  this.shape_89.graphics.f("#0C593C").s().p("AgEAlIAAhAIgQAAIAAgJIApAAIAAAJIgRAAIAABAg");
  this.shape_89.setTransform(610.075, 7.575);
  this.shape_90 = new cjs.Shape();
  this.shape_90.graphics.f("#0C593C").s().p("AgVATQAAgHABgEQACgEADgDQAEgCAGgCIAKgGQADgBAAgIQAAgGgCgDQgDgCgEAAQgFAAgCADQgDADAAAHIgIAAQAAgWATAAQAFAAAEACQAEADACAEQACAEAAAGIAAArQAAAGADAAIACgBIAAAIIgDABQgFAAgCgCQgCgCgBgHIgBAAQgBAFgEAEQgDADgFAAQgQAAAAgUgAABABIgHAEIgEAFQgCADAAAFQAAAMAJAAQAFAAADgFIACgCIAAgEIABgHIAAgOIgHADg");
  this.shape_90.setTransform(604.725, 7.575);
  this.shape_91 = new cjs.Shape();
  this.shape_91.graphics.f("#0C593C").s().p("AgXAlIAAgJIAEAAQAAAAABAAQABAAAAAAQABAAAAgBQAAAAABAAIACgJIAAgSIAAgkIAlAAIAABJIgJAAIAAhAIgTAAIAAAcQAAASgDAJQgDAJgIAAIgFAAg");
  this.shape_91.setTransform(598.425, 7.6);
  this.shape_92 = new cjs.Shape();
  this.shape_92.graphics.f("#0C593C").s().p("AAVAlIAAhJIAJAAIAABJgAgdAlIAAhJIAKAAIAAAfIANAAQAFAAADADQAEACACAFQACAFAAAGQAAAGgCAFQgCAFgEADQgDACgFAAgAgTAdIAJAAQAGAAADgEQACgDAAgGQAAgNgKAAIgKAAg");
  this.shape_92.setTransform(591.475, 7.575);
  this.shape_93 = new cjs.Shape();
  this.shape_93.graphics.f("#0C593C").s().p("AgUAzIAAhjIAIAAIAAAIIABAAQACgEADgEQAEgCACAAQAWAAAAAmIgBAPIgEANQgCAFgEADQgEAEgGAAQgDgBgDgCQgEgCgCgFIAAAhgAgJggQgDAIABANIAAAOQABAHACAEQAEAEAEABQAHgBACgHQADgIAAgPQAAgdgMAAQgHAAgCAJg");
  this.shape_93.setTransform(584.35, 8.75);
  this.shape_94 = new cjs.Shape();
  this.shape_94.graphics.f("#0C593C").s().p("AAQAyIgWgxIgKAOIAAAjIgKAAIAAhjIAKAAIAAAyIAegyIAMAAIgaAqIAbA5g");
  this.shape_94.setTransform(578, 6.275);
  this.shape_95 = new cjs.Shape();
  this.shape_95.graphics.f("#0C593C").s().p("AgEAHIAAgNIAJAAIAAANg");
  this.shape_95.setTransform(568.925, 10.625);
  this.shape_96 = new cjs.Shape();
  this.shape_96.graphics.f("#0C593C").s().p("AgXAlIAAgJIAEAAQAAAAABAAQAAAAABAAQAAAAABgBQAAAAABAAIACgJIAAgSIAAgkIAlAAIAABJIgJAAIAAhAIgTAAIAAAcQAAASgDAJQgDAJgIAAIgFAAg");
  this.shape_96.setTransform(563.725, 7.6);
  this.shape_97 = new cjs.Shape();
  this.shape_97.graphics.f("#0C593C").s().p("AgVAwIAAgJQADACAEAAQAEAAADgEQACgEACgHIgUhLIAJAAIAOA7IABAAIAOg7IAJAAIgUBKIgEANQgBAFgEAEQgDADgGAAQgEAAgDgCg");
  this.shape_97.setTransform(557.975, 8.85);
  this.shape_98 = new cjs.Shape();
  this.shape_98.graphics.f("#0C593C").s().p("AgEALQAFgDAAgKIgFAAIAAgNIAJAAIAAAPQAAAGgCAEQgDAFgEABg");
  this.shape_98.setTransform(550.075, 11.6);
  this.shape_99 = new cjs.Shape();
  this.shape_99.graphics.f("#0C593C").s().p("AgVATQAAgHABgEQACgEADgDQAEgCAGgCIAKgGQADgBAAgIQAAgGgCgDQgDgCgEAAQgFAAgCADQgDADAAAHIgIAAQAAgWATAAQAFAAAEACQAEADACAEQACAEAAAGIAAArQAAAGADAAIACgBIAAAIIgDABQgFAAgCgCQgCgCgBgHIgBAAQgBAFgEAEQgDADgFAAQgQAAAAgUgAABABIgHAEIgEAFQgCADAAAFQAAAMAJAAQAFAAADgFIACgCIAAgEIABgHIAAgOIgHADg");
  this.shape_99.setTransform(545.575, 7.575);
  this.shape_100 = new cjs.Shape();
  this.shape_100.graphics.f("#0C593C").s().p("AgTAlIAAhJIAUAAQAHAAAFAEQAGAFgBAIQAAAHgCAFQgDAFgEABQAFABADAFQADAEAAAIQAAAGgCAFQgCAEgEADQgEACgEAAgAgJAdIAJAAQAGAAADgEQABgDAAgHQABgGgDgDQgDgDgFAAIgJAAgAgJgFIAJAAQAEAAADgDQACgDAAgGQAAgLgJAAIgJAAg");
  this.shape_100.setTransform(539.95, 7.575);
  this.shape_101 = new cjs.Shape();
  this.shape_101.graphics.f("#0C593C").s().p("AALAlIgPglIgHALIAAAaIgJAAIAAhJIAJAAIAAAiIAVgiIALAAIgUAdIAUAsg");
  this.shape_101.setTransform(534.425, 7.575);
  this.shape_102 = new cjs.Shape();
  this.shape_102.graphics.f("#0C593C").s().p("AgLAiQgFgFgCgJQgCgIAAgLQAAgnAWAAQAJAAAFAHQAFAHAAALIgJAAQAAgQgLAAQgGAAgDAIQgCAJAAANQAAANACAIQACAIAHAAQAHAAACgFQACgFAAgJIAJAAQAAAMgFAIQgEAIgKAAQgJAAgEgFg");
  this.shape_102.setTransform(528.375, 7.575);
  this.shape_103 = new cjs.Shape();
  this.shape_103.graphics.f("#0C593C").s().p("AgMAkQgEgEgEgJQgCgJAAgOQAAgSAFgKQAGgKALAAQAXAAAAAmQAAAPgDAIQgDAJgEAEQgGADgHAAQgHAAgFgDgAgHgaQgDADgCAHIAAARIAAAQQACAGADAEQACADAFAAQAFAAADgDQADgEABgGQABgHABgJQgBgLgBgHQgCgGgDgDQgDgDgEAAQgEAAgDADg");
  this.shape_103.setTransform(522.35, 7.575);
  this.shape_104 = new cjs.Shape();
  this.shape_104.graphics.f("#0C593C").s().p("AAbAyIAAhSIAAgGIAAgGIgCAHIgBAGIgSBRIgLAAIgShSIgCgMIgBAAIAAAGIABAHIAABRIgKAAIAAhjIARAAIARBNIABAPIACgPIARhNIARAAIAABjg");
  this.shape_104.setTransform(514.375, 6.275);
  this.shape_105 = new cjs.Shape();
  this.shape_105.graphics.f("#0C593C").s().p("AgEAHIAAgNIAJAAIAAANg");
  this.shape_105.setTransform(504.475, 10.625);
  this.shape_106 = new cjs.Shape();
  this.shape_106.graphics.f("#0C593C").s().p("AgQAlIAAhJIAhAAIAAAJIgYAAIAABAg");
  this.shape_106.setTransform(500.75, 7.575);
  this.shape_107 = new cjs.Shape();
  this.shape_107.graphics.f("#0C593C").s().p("AgEALQAFgDAAgKIgFAAIAAgNIAJAAIAAAPQAAAGgCAEQgDAFgEABg");
  this.shape_107.setTransform(492.775, 11.6);
  this.shape_108 = new cjs.Shape();
  this.shape_108.graphics.f("#0C593C").s().p("AAHAyIAAgZIgfAAIAAgKIAghAIAJAAIAABAIAIAAIAAAKIgIAAIAAAZgAgQAPIAXAAIAAgvg");
  this.shape_108.setTransform(487.75, 6.275);
  this.shape_109 = new cjs.Shape();
  this.shape_109.graphics.f("#0C593C").s().p("AAEAyIAAhIIgRAAIAAgJQAHAAAEgBQADgCACgEQADgEABgHIAHAAIAABjg");
  this.shape_109.setTransform(480.9, 6.275);
  this.shape_110 = new cjs.Shape();
  this.shape_110.graphics.f("#0C593C").s().p("AgMAvQgEgEgDgHQgCgGgBgIIgBgRQAAgOABgMQACgMAGgIQAFgJALAAQAFAAAFADQAEADADAFQACAGABAHIgKAAQAAgIgEgDQgDgDgFAAQgDAAgDAEQgEAEgBAGIgBALIgBAOQACgGAFgDQADgEAFAAQAKAAAGAJQAGAIAAANQAAALgDAIQgDAIgFAEQgFAEgHAAQgIAAgFgEgAgMAQQAAANADAGQAEAGAGAAQAHAAADgHQADgHAAgKQAAgUgOAAQgNAAABATg");
  this.shape_110.setTransform(475.2, 6.375);
  this.shape_111 = new cjs.Shape();
  this.shape_111.graphics.f("#0C593C").s().p("AAEAyIAAhIIgRAAIAAgJQAHAAAEgBQADgCACgEQADgEAAgHIAIAAIAABjg");
  this.shape_111.setTransform(468.2, 6.275);
  this.shape_112 = new cjs.Shape();
  this.shape_112.graphics.f("#0C593C").s().p("AgWAyQAAgJABgHQACgGAEgHQAFgGAJgJQAGgGAEgGQAEgHAAgJQAAgRgNAAQgHAAgDAGQgCAGAAAMIgJAAIAAgFQAAgIACgHQADgHAFgDQAFgEAGAAQAHAAAGADQAFAEACAGQADAGAAAJQAAAHgCAGQgCAFgEAEIgIAKIgMAOQgEAEgBADIgCAIIAjAAIAAAKg");
  this.shape_112.setTransform(462.425, 6.275);
  this.shape_113 = new cjs.Shape();
  this.shape_113.graphics.f("#0C593C").s().p("AAEAyIAAhIIgRAAIAAgJQAHAAAEgBQADgCADgEQACgEAAgHIAIAAIAABjg");
  this.shape_113.setTransform(455.5, 6.275);
  this.shape_114 = new cjs.Shape();
  this.shape_114.graphics.f("#0C593C").s().p("AgEALQAFgDAAgKIgFAAIAAgNIAJAAIAAAPQAAAGgCAEQgDAFgEABg");
  this.shape_114.setTransform(447.825, 11.6);
  this.shape_115 = new cjs.Shape();
  this.shape_115.graphics.f("#0C593C").s().p("AAMAlIAAgfIgKAAIgMAfIgKAAIAOggQgGgDgDgEQgDgGAAgHQAAgGADgFQABgFAEgDQAFgCAFAAIAVAAIAABJgAgGgYQgCADAAAGQAAANAKAAIAKAAIAAgaIgKAAQgFAAgDAEg");
  this.shape_115.setTransform(442.9, 7.575);
  this.shape_116 = new cjs.Shape();
  this.shape_116.graphics.f("#0C593C").s().p("AAMAlIAAg3IABgJIgCAJIgUA3IgLAAIAAhJIAJAAIAAA3IgBAJIACgJIAUg3IALAAIAABJg");
  this.shape_116.setTransform(437.125, 7.575);
  this.shape_117 = new cjs.Shape();
  this.shape_117.graphics.f("#0C593C").s().p("AgLAiQgFgFgCgJQgCgIAAgLQAAgnAWAAQAJAAAFAHQAFAHAAALIgJAAQAAgQgLAAQgGAAgDAIQgCAJAAANQAAANACAIQACAIAHAAQAHAAACgFQACgFAAgJIAJAAQAAAMgFAIQgEAIgKAAQgJAAgEgFg");
  this.shape_117.setTransform(431.125, 7.575);
  this.shape_118 = new cjs.Shape();
  this.shape_118.graphics.f("#0C593C").s().p("AgLAiQgFgFgCgJQgCgIAAgLQAAgnAWAAQAJAAAFAHQAFAHAAALIgJAAQAAgQgLAAQgGAAgDAIQgCAJAAANQAAANACAIQACAIAHAAQAHAAACgFQACgFAAgJIAJAAQAAAMgFAIQgEAIgKAAQgJAAgEgFg");
  this.shape_118.setTransform(425.475, 7.575);
  this.shape_119 = new cjs.Shape();
  this.shape_119.graphics.f("#0C593C").s().p("AgLAkQgGgEgCgJQgDgJAAgOQAAgSAFgKQAGgKALAAQAXAAAAAmQAAAPgDAIQgCAJgGAEQgFADgHAAQgHAAgEgDgAgHgaQgDADgBAHIgBARIABAQQABAGADAEQACADAFAAQAFAAADgDQADgEABgGQACgHAAgJQAAgLgCgHQgBgGgDgDQgDgDgFAAQgEAAgDADg");
  this.shape_119.setTransform(419.45, 7.575);
  this.shape_120 = new cjs.Shape();
  this.shape_120.graphics.f("#0C593C").s().p("AgYAyIAAhjIAYAAQALAAAHAHQAHAHAAAOQAAAJgCAFQgCAGgEADQgEADgEABQgGACgFAAIgNAAIAAAqgAgPgBIAKAAQAGAAAFgCQAEgBACgEQADgFAAgIQAAgKgFgEQgFgEgHAAIgNAAg");
  this.shape_120.setTransform(413.05, 6.275);
  this.shape_121 = new cjs.Shape();
  this.shape_121.graphics.f("#0C593C").s().p("AgEALQAFgDAAgKIgFAAIAAgNIAJAAIAAAPQAAAGgCAEQgDAFgEABg");
  this.shape_121.setTransform(404.125, 11.6);
  this.shape_122 = new cjs.Shape();
  this.shape_122.graphics.f("#0C593C").s().p("AACAOIALgOIgLgNIAAgLIARAVIAAAHIgRAVgAgSAOIAMgOIgMgNIAAgLIARAVIAAAHIgRAVg");
  this.shape_122.setTransform(399.25, 7.125);
  this.shape_123 = new cjs.Shape();
  this.shape_123.graphics.f("#0C593C").s().p("AALAlIAAgjIgVAAIAAAjIgJAAIAAhJIAJAAIAAAfIAVAAIAAgfIAJAAIAABJg");
  this.shape_123.setTransform(392.9, 7.575);
  this.shape_124 = new cjs.Shape();
  this.shape_124.graphics.f("#0C593C").s().p("AgMAkQgFgEgDgJQgCgJAAgOQAAgSAGgKQAFgKALAAQAXAAAAAmQAAAPgDAIQgDAJgEAEQgGADgHAAQgHAAgFgDgAgHgaQgDADgCAHIgBARIABAQQACAGADAEQADADAEAAQAFAAADgDQADgEABgGQABgHAAgJQAAgLgBgHQgBgGgEgDQgDgDgEAAQgEAAgDADg");
  this.shape_124.setTransform(386.55, 7.575);
  this.shape_125 = new cjs.Shape();
  this.shape_125.graphics.f("#0C593C").s().p("AgLAiQgFgFgCgJQgCgIAAgLQAAgnAWAAQAJAAAFAHQAFAHAAALIgJAAQAAgQgLAAQgGAAgDAIQgCAJAAANQAAANACAIQACAIAHAAQAHAAACgFQACgFAAgJIAJAAQAAAMgFAIQgEAIgKAAQgJAAgEgFg");
  this.shape_125.setTransform(380.575, 7.575);
  this.shape_126 = new cjs.Shape();
  this.shape_126.graphics.f("#0C593C").s().p("AALAlIAAgjIgVAAIAAAjIgJAAIAAhJIAJAAIAAAfIAVAAIAAgfIAJAAIAABJg");
  this.shape_126.setTransform(374.55, 7.575);
  this.shape_127 = new cjs.Shape();
  this.shape_127.graphics.f("#0C593C").s().p("AgMAkQgEgEgEgJQgCgJAAgOQAAgSAGgKQAFgKALAAQAXAAAAAmQAAAPgDAIQgDAJgFAEQgFADgHAAQgGAAgGgDgAgHgaQgDADgCAHIgBARIABAQQACAGADAEQACADAFAAQAFAAADgDQADgEABgGQACgHgBgJQABgLgCgHQgBgGgEgDQgDgDgEAAQgEAAgDADg");
  this.shape_127.setTransform(368.2, 7.575);
  this.shape_128 = new cjs.Shape();
  this.shape_128.graphics.f("#0C593C").s().p("AAbAlIgQglIgGALIAAAaIgJAAIAAgaIgHgLIgQAlIgKAAIAUgsIgUgdIALAAIAWAiIAAgiIAJAAIAAAiIAWgiIAKAAIgTAdIAUAsg");
  this.shape_128.setTransform(360.875, 7.575);
  this.shape_129 = new cjs.Shape();
  this.shape_129.graphics.f("#0C593C").s().p("AAYA+IAAgXIgwAAIAAAXIgJAAIAAgiIAGAAQAEgIABgIQADgJAAgLIABgcIAAgZIAtAAIAABZIAHAAIAAAigAgJgZIgBAWIgCARQgCAIgDAGIAiAAIAAhPIgaAAg");
  this.shape_129.setTransform(352.8, 7.45);
  this.shape_130 = new cjs.Shape();
  this.shape_130.graphics.f("#0C593C").s().p("AgSAwQgGgEgDgGQgDgHAAgJQAAgHACgFQACgGAEgEIAKgHQgFgHgCgFQgCgFAAgGQAAgGACgEQACgFAEgDQAEgCAFAAQAHAAAFAFQAFAFAAAJQAAAOgOAMIAQAbIADgTIAJAAQgBARgGAKIALATIgLAAIgFgJQgIALgMAAQgHABgGgEgAgRAKQgDAEAAAIQAAAGACAEQACAFAEACQADADAFgBQAHAAAHgJIgSggQgGAEgDAGgAgKgnQgCADAAAFQAAAHAHALQAFgEABgEQACgEAAgGQAAgEgCgEQgBgCgEAAQgDAAgDACg");
  this.shape_130.setTransform(344.875, 6.4);
  this.shape_131 = new cjs.Shape();
  this.shape_131.graphics.f("#0C593C").s().p("AALAlIAAgjIgVAAIAAAjIgJAAIAAhJIAJAAIAAAfIAVAAIAAgfIAJAAIAABJg");
  this.shape_131.setTransform(337.45, 7.575);
  this.shape_132 = new cjs.Shape();
  this.shape_132.graphics.f("#0C593C").s().p("AgLAkQgFgEgEgJQgCgJAAgOQAAgSAFgKQAGgKALAAQAXAAAAAmQAAAPgDAIQgDAJgEAEQgGADgHAAQgHAAgEgDgAgHgaQgDADgBAHIgBARIABAQQABAGADAEQACADAFAAQAFAAADgDQADgEABgGQABgHABgJQgBgLgBgHQgCgGgDgDQgDgDgEAAQgEAAgDADg");
  this.shape_132.setTransform(331.1, 7.575);
  this.shape_133 = new cjs.Shape();
  this.shape_133.graphics.f("#0C593C").s().p("AgLAiQgFgFgCgJQgCgIAAgLQAAgnAWAAQAJAAAFAHQAFAHAAALIgJAAQAAgQgLAAQgGAAgDAIQgCAJAAANQAAANACAIQACAIAHAAQAHAAACgFQACgFAAgJIAJAAQAAAMgFAIQgEAIgKAAQgJAAgEgFg");
  this.shape_133.setTransform(325.125, 7.575);
  this.shape_134 = new cjs.Shape();
  this.shape_134.graphics.f("#0C593C").s().p("AALAlIAAgjIgVAAIAAAjIgJAAIAAhJIAJAAIAAAfIAVAAIAAgfIAJAAIAABJg");
  this.shape_134.setTransform(319.1, 7.575);
  this.shape_135 = new cjs.Shape();
  this.shape_135.graphics.f("#0C593C").s().p("AgMAkQgFgEgDgJQgCgJAAgOQAAgSAGgKQAFgKALAAQAXAAAAAmQAAAPgDAIQgDAJgEAEQgGADgHAAQgHAAgFgDgAgHgaQgDADgCAHIgBARIABAQQACAGADAEQADADAEAAQAFAAADgDQADgEABgGQABgHABgJQgBgLgBgHQgBgGgEgDQgDgDgEAAQgEAAgDADg");
  this.shape_135.setTransform(312.75, 7.575);
  this.shape_136 = new cjs.Shape();
  this.shape_136.graphics.f("#0C593C").s().p("AAbAlIgQglIgGALIAAAaIgJAAIAAgaIgHgLIgQAlIgKAAIAUgsIgUgdIALAAIAWAiIAAgiIAJAAIAAAiIAWgiIAKAAIgTAdIAUAsg");
  this.shape_136.setTransform(305.425, 7.575);
  this.shape_137 = new cjs.Shape();
  this.shape_137.graphics.f("#0C593C").s().p("AAZA+IAAgXIgxAAIAAAXIgJAAIAAgiIAGAAQAEgIABgIQADgJAAgLIABgcIAAgZIAtAAIAABZIAHAAIAAAigAgIgZIgBAWIgDARQgCAIgDAGIAiAAIAAhPIgZAAg");
  this.shape_137.setTransform(297.4, 7.45);
  this.shape_138 = new cjs.Shape();
  this.shape_138.graphics.f("#0C593C").s().p("AABAEIAAgHIASgVIAAALIgMANIAMAOIAAALgAgSAEIAAgHIARgVIAAALIgLANIALAOIAAALg");
  this.shape_138.setTransform(290.3, 7.125);
  this.shape_139 = new cjs.Shape();
  this.shape_139.graphics.f("#0C593C").s().p("AgOAxQgFgFgDgHQgDgIgCgIIgBgVQAAgOADgLQACgLAFgIQAHgIALABQARAAAFAOQAGAPABAWQgBAZgGAOQgFANgRAAQgIAAgGgDgAgLgkQgEAFgBAJQgCAJAAAMIABASIADAOQACAGADADQAEACAFAAQAFAAAFgCQADgDACgGQACgFAAgJIACgSIgCgRIgDgMQgCgGgDgDQgEgCgFAAQgGgBgFAGg");
  this.shape_139.setTransform(279.9, 6.3);
  this.shape_140 = new cjs.Shape();
  this.shape_140.graphics.f("#0C593C").s().p("AgOAxQgGgFgDgHQgDgIgBgIIAAgVQAAgOABgLQADgLAFgIQAHgIALABQARAAAGAOQAFAPAAAWQAAAZgFAOQgGANgRAAQgJAAgFgDgAgKgkQgFAFgBAJQgBAJgBAMIABASIACAOQACAGAFADQADACAFAAQAGAAADgCQAEgDACgGQACgFAAgJIABgSIgBgRIgCgMQgCgGgEgDQgEgCgFAAQgHgBgDAGg");
  this.shape_140.setTransform(272.3, 6.3);
  this.shape_141 = new cjs.Shape();
  this.shape_141.graphics.f("#0C593C").s().p("AgOAxQgGgFgCgHQgDgIgBgIIgCgVQABgOACgLQABgLAHgIQAGgIALABQARAAAFAOQAHAPAAAWQAAAZgHAOQgFANgRAAQgJAAgFgDgAgLgkQgEAFgBAJQgBAJAAAMIAAASIADAOQABAGAFADQADACAFAAQAGAAAEgCQADgDACgGQACgFABgJIABgSIgBgRIgEgMQgCgGgDgDQgEgCgFAAQgGgBgFAGg");
  this.shape_141.setTransform(264.7, 6.3);
  this.shape_142 = new cjs.Shape();
  this.shape_142.graphics.f("#0C593C").s().p("AABAOIAMgOIgMgNIAAgLIASAVIAAAHIgSAVgAgSAOIALgOIgLgNIAAgLIARAVIAAAHIgRAVg");
  this.shape_142.setTransform(647.05, -5.925);
  this.shape_143 = new cjs.Shape();
  this.shape_143.graphics.f("#0C593C").s().p("AALAlIAAgjIgWAAIAAAjIgJAAIAAhJIAJAAIAAAfIAWAAIAAgfIAKAAIAABJg");
  this.shape_143.setTransform(640.7, -5.475);
  this.shape_144 = new cjs.Shape();
  this.shape_144.graphics.f("#0C593C").s().p("AgMAkQgEgEgDgJQgDgJAAgOQAAgSAGgKQAFgKALAAQAXAAAAAmQAAAPgDAIQgDAJgFAEQgFADgHAAQgGAAgGgDgAgHgaQgDADgCAHIgBARIABAQQACAGADAEQADADAEAAQAFAAADgDQADgEABgGQABgHAAgJQAAgLgBgHQgBgGgDgDQgEgDgEAAQgEAAgDADg");
  this.shape_144.setTransform(634.35, -5.475);
  this.shape_145 = new cjs.Shape();
  this.shape_145.graphics.f("#0C593C").s().p("AgLAiQgFgFgCgJQgCgIAAgLQAAgnAWAAQAJAAAFAHQAFAHAAALIgJAAQAAgQgLAAQgGAAgDAIQgCAJAAANQAAANACAIQACAIAHAAQAHAAACgFQACgFAAgJIAJAAQAAAMgFAIQgEAIgKAAQgJAAgEgFg");
  this.shape_145.setTransform(628.375, -5.475);
  this.shape_146 = new cjs.Shape();
  this.shape_146.graphics.f("#0C593C").s().p("AALAlIAAgjIgWAAIAAAjIgJAAIAAhJIAJAAIAAAfIAWAAIAAgfIAKAAIAABJg");
  this.shape_146.setTransform(622.35, -5.475);
  this.shape_147 = new cjs.Shape();
  this.shape_147.graphics.f("#0C593C").s().p("AgLAkQgGgEgCgJQgDgJAAgOQAAgSAFgKQAGgKALAAQAXAAAAAmQAAAPgDAIQgDAJgFAEQgFADgHAAQgGAAgFgDgAgHgaQgDADgBAHIgCARIACAQQABAGADAEQADADAEAAQAFAAADgDQADgEABgGQABgHAAgJQAAgLgBgHQgBgGgDgDQgDgDgFAAQgEAAgDADg");
  this.shape_147.setTransform(616, -5.475);
  this.shape_148 = new cjs.Shape();
  this.shape_148.graphics.f("#0C593C").s().p("AAbAlIgQglIgGALIAAAaIgJAAIAAgaIgHgLIgQAlIgKAAIAUgsIgUgdIALAAIAWAiIAAgiIAJAAIAAAiIAWgiIAKAAIgTAdIAUAsg");
  this.shape_148.setTransform(608.675, -5.475);
  this.shape_149 = new cjs.Shape();
  this.shape_149.graphics.f("#0C593C").s().p("AAZA+IAAgXIgxAAIAAAXIgJAAIAAgiIAGAAQAEgIABgIQACgJABgLIABgcIAAgZIAtAAIAABZIAHAAIAAAigAgIgZIgBAWIgDARQgCAIgDAGIAiAAIAAhPIgZAAg");
  this.shape_149.setTransform(600.6, -5.6);
  this.shape_150 = new cjs.Shape();
  this.shape_150.graphics.f("#0C593C").s().p("AgSAwQgGgEgDgGQgDgHAAgJQAAgHACgFQACgGAEgEIAKgHQgFgHgCgFQgCgFAAgGQAAgGACgEQACgFAEgDQAEgCAFAAQAHAAAFAFQAFAFAAAJQAAAOgOAMIAQAaIADgSIAJAAQgBARgGAKIALATIgLAAIgFgJQgIALgMAAQgHABgGgEgAgRAKQgDAEAAAIQAAAGACAEQACAFAEACQADADAFgBQAHAAAHgJIgSggQgGAEgDAGgAgKgnQgCADAAAFQAAAHAHALQAFgEABgEQACgEAAgGQAAgEgCgEQgBgCgEAAQgDAAgDACg");
  this.shape_150.setTransform(592.725, -6.65);
  this.shape_151 = new cjs.Shape();
  this.shape_151.graphics.f("#0C593C").s().p("AALAlIAAgjIgVAAIAAAjIgJAAIAAhJIAJAAIAAAfIAVAAIAAgfIAJAAIAABJg");
  this.shape_151.setTransform(585.3, -5.475);
  this.shape_152 = new cjs.Shape();
  this.shape_152.graphics.f("#0C593C").s().p("AgLAkQgFgEgEgJQgCgJAAgOQAAgSAFgKQAGgKALAAQAXAAAAAmQAAAPgDAIQgCAJgFAEQgGADgHAAQgHAAgEgDgAgHgaQgDADgBAHIgBARIABAQQABAGADAEQACADAFAAQAFAAADgDQADgEABgGQABgHABgJQgBgLgBgHQgCgGgDgDQgDgDgEAAQgEAAgDADg");
  this.shape_152.setTransform(578.95, -5.475);
  this.shape_153 = new cjs.Shape();
  this.shape_153.graphics.f("#0C593C").s().p("AgLAiQgFgFgCgJQgCgIAAgLQAAgnAWAAQAJAAAFAHQAFAHAAALIgJAAQAAgQgLAAQgGAAgDAIQgCAJAAANQAAANACAIQACAIAHAAQAHAAACgFQACgFAAgJIAJAAQAAAMgFAIQgEAIgKAAQgJAAgEgFg");
  this.shape_153.setTransform(572.975, -5.475);
  this.shape_154 = new cjs.Shape();
  this.shape_154.graphics.f("#0C593C").s().p("AALAlIAAgjIgVAAIAAAjIgJAAIAAhJIAJAAIAAAfIAVAAIAAgfIAJAAIAABJg");
  this.shape_154.setTransform(566.95, -5.475);
  this.shape_155 = new cjs.Shape();
  this.shape_155.graphics.f("#0C593C").s().p("AgMAkQgEgEgEgJQgCgJAAgOQAAgSAFgKQAGgKALAAQAXAAAAAmQAAAPgDAIQgDAJgEAEQgGADgHAAQgHAAgFgDgAgHgaQgDADgCAHIAAARIAAAQQACAGADAEQACADAFAAQAFAAADgDQADgEABgGQABgHABgJQgBgLgBgHQgCgGgDgDQgDgDgEAAQgEAAgDADg");
  this.shape_155.setTransform(560.6, -5.475);
  this.shape_156 = new cjs.Shape();
  this.shape_156.graphics.f("#0C593C").s().p("AAbAlIgQglIgGALIAAAaIgJAAIAAgaIgHgLIgQAlIgKAAIAUgsIgUgdIALAAIAWAiIAAgiIAJAAIAAAiIAWgiIAKAAIgTAdIAUAsg");
  this.shape_156.setTransform(553.275, -5.475);
  this.shape_157 = new cjs.Shape();
  this.shape_157.graphics.f("#0C593C").s().p("AAYA+IAAgXIgwAAIAAAXIgJAAIAAgiIAGAAQAEgIACgIQACgJAAgLIABgcIAAgZIAtAAIAABZIAHAAIAAAigAgJgZIgBAWIgCARQgCAIgDAGIAiAAIAAhPIgaAAg");
  this.shape_157.setTransform(545.2, -5.6);
  this.shape_158 = new cjs.Shape();
  this.shape_158.graphics.f("#0C593C").s().p("AACAEIAAgHIARgVIAAALIgMANIAMAOIAAALgAgSAEIAAgHIARgVIAAALIgLANIALAOIAAALg");
  this.shape_158.setTransform(538.1, -5.925);
  this.shape_159 = new cjs.Shape();
  this.shape_159.graphics.f("#0C593C").s().p("AgOAxQgGgFgDgHQgCgIgBgIIgBgVQAAgOACgLQABgLAHgIQAGgIALABQARAAAFAOQAHAPgBAWQABAZgHAOQgFANgRAAQgIAAgGgDgAgKgkQgEAFgCAJQgCAJABAMIAAASIACAOQACAGAFADQADACAFAAQAGAAAEgCQADgDACgGQACgFABgJIABgSIgBgRIgEgMQgBgGgEgDQgEgCgFAAQgHgBgDAGg");
  this.shape_159.setTransform(527.7, -6.75);
  this.shape_160 = new cjs.Shape();
  this.shape_160.graphics.f("#0C593C").s().p("AgOAxQgFgFgDgHQgEgIgBgIIgBgVQAAgOACgLQADgLAFgIQAHgIALABQARAAAGAOQAFAPABAWQgBAZgFAOQgGANgRAAQgIAAgGgDgAgLgkQgDAFgCAJQgCAJAAAMIABASIADAOQACAGADADQAEACAFAAQAFAAAEgCQAEgDACgGQACgFAAgJIABgSIgBgRIgDgMQgCgGgDgDQgEgCgFAAQgHgBgEAGg");
  this.shape_160.setTransform(520.1, -6.75);
  this.shape_161 = new cjs.Shape();
  this.shape_161.graphics.f("#0C593C").s().p("AgOAxQgFgFgEgHQgCgIgBgIIgBgVQAAgOACgLQABgLAHgIQAGgIALABQARAAAFAOQAHAPgBAWQABAZgHAOQgFANgRAAQgIAAgGgDgAgKgkQgFAFgBAJQgCAJABAMIAAASIACAOQADAGAEADQADACAFAAQAGAAAEgCQADgDACgGQACgFABgJIAAgSIAAgRIgDgMQgDgGgDgDQgEgCgFAAQgHgBgDAGg");
  this.shape_161.setTransform(512.5, -6.75);
  this.shape_162 = new cjs.Shape();
  this.shape_162.graphics.f("#0C593C").s().p("AgTAlIAAhJIAUAAQAIAAAEAEQAGAFAAAIQAAAHgDAFQgDAFgEABQAFABADAFQADAEAAAIQAAAGgCAFQgCAEgEADQgEACgEAAgAgJAdIAJAAQAGAAADgEQABgDAAgHQAAgGgCgDQgDgDgEAAIgKAAgAgJgFIAJAAQAEAAADgDQACgDAAgGQAAgLgJAAIgJAAg");
  this.shape_162.setTransform(502.5, -5.475);
  this.shape_163 = new cjs.Shape();
  this.shape_163.graphics.f("#0C593C").s().p("AgEAlIAAhAIgQAAIAAgJIApAAIAAAJIgRAAIAABAg");
  this.shape_163.setTransform(496.925, -5.475);
  this.shape_164 = new cjs.Shape();
  this.shape_164.graphics.f("#0C593C").s().p("AgLAiQgFgFgCgJQgCgIAAgLQAAgnAWAAQAJAAAFAHQAFAHAAALIgJAAQAAgQgLAAQgGAAgDAIQgCAJAAANQAAANACAIQACAIAHAAQAHAAACgFQACgFAAgJIAJAAQAAAMgFAIQgEAIgKAAQgJAAgEgFg");
  this.shape_164.setTransform(491.625, -5.475);
  this.shape_165 = new cjs.Shape();
  this.shape_165.graphics.f("#0C593C").s().p("AATAvIAAgUIglAAIAAAUIgIAAIAAgdIAFAAIAFgNIACgLIABgQIAAgYIAiAAIAABAIAGAAIAAAdgAgEgRQAAALgCAHIgFARIAXAAIAAg3IgQAAg");
  this.shape_165.setTransform(485.475, -4.45);
  this.shape_166 = new cjs.Shape();
  this.shape_166.graphics.f("#0C593C").s().p("AgKAkQgEgEgDgJQgCgJAAgOQAAgmATAAQAJAAAEAFQAFAGABAIIABAUIgeAAIABAQQABAGACAEQADADAEAAQAKAAAAgSIAJAAQAAAIgCAGQgCAGgEAEQgFADgGAAQgGAAgFgDgAgIgXQgCAGAAAKIAVAAQAAgLgCgFQgCgGgHAAQgFAAgDAGg");
  this.shape_166.setTransform(479.375, -5.475);
  this.shape_167 = new cjs.Shape();
  this.shape_167.graphics.f("#0C593C").s().p("AgVAzIAAhjIAJAAIAAAIIAAAAQACgEAEgEQAEgCADAAQAUAAAAAmIAAAPIgDANQgDAFgEADQgEAEgFAAQgFgBgCgCQgEgCgDgFIAAAhgAgJghQgCAJgBANIABAOQABAHADAEQACAEAFABQAGgBAEgHQACgIAAgPQAAgdgMAAQgHAAgCAIg");
  this.shape_167.setTransform(473.5, -4.3);
  this.shape_168 = new cjs.Shape();
  this.shape_168.graphics.f("#0C593C").s().p("AgLAiQgFgFgCgJQgCgIAAgLQAAgnAWAAQAJAAAFAHQAFAHAAALIgJAAQAAgQgLAAQgGAAgDAIQgCAJAAANQAAANACAIQACAIAHAAQAHAAACgFQACgFAAgJIAJAAQAAAMgFAIQgEAIgKAAQgJAAgEgFg");
  this.shape_168.setTransform(467.425, -5.475);
  this.shape_169 = new cjs.Shape();
  this.shape_169.graphics.f("#0C593C").s().p("AAPAlIgOgeIgPAeIgJAAIATglIgTgkIAKAAIAOAcIANgcIAKAAIgTAkIATAlg");
  this.shape_169.setTransform(458.3, -5.475);
  this.shape_170 = new cjs.Shape();
  this.shape_170.graphics.f("#0C593C").s().p("AAVAlIAAhJIAJAAIAABJgAgdAlIAAhJIAKAAIAAAfIANAAQAFAAADADQAEACACAFQACAFAAAGQAAAGgCAFQgCAFgEADQgDACgFAAgAgTAdIAJAAQAGAAADgEQACgDAAgGQAAgNgKAAIgKAAg");
  this.shape_170.setTransform(451.425, -5.475);
  this.shape_171 = new cjs.Shape();
  this.shape_171.graphics.f("#0C593C").s().p("AALAlIAAgjIgVAAIAAAjIgJAAIAAhJIAJAAIAAAfIAVAAIAAgfIAJAAIAABJg");
  this.shape_171.setTransform(444.2, -5.475);
  this.shape_172 = new cjs.Shape();
  this.shape_172.graphics.f("#0C593C").s().p("AALAlIAAgjIgWAAIAAAjIgJAAIAAhJIAJAAIAAAfIAWAAIAAgfIAKAAIAABJg");
  this.shape_172.setTransform(437.85, -5.475);
  this.shape_173 = new cjs.Shape();
  this.shape_173.graphics.f("#0C593C").s().p("AgKAkQgEgEgDgJQgCgJAAgOQAAgmATAAQAJAAAEAFQAFAGABAIIABAUIgeAAIABAQQABAGACAEQADADAEAAQAKAAAAgSIAJAAQAAAIgCAGQgCAGgEAEQgFADgGAAQgGAAgFgDgAgIgXQgCAGAAAKIAVAAQAAgLgCgFQgCgGgHAAQgFAAgDAGg");
  this.shape_173.setTransform(431.825, -5.475);
  this.shape_174 = new cjs.Shape();
  this.shape_174.graphics.f("#0C593C").s().p("AgTAlIAAhJIAUAAQAIAAAEAEQAFAFABAIQAAAHgEAFQgCAFgEABQAFABACAFQAEAEAAAIQAAAGgCAFQgDAEgDADQgEACgEAAgAgKAdIAKAAQAGAAADgEQACgDAAgHQgBgGgCgDQgDgDgEAAIgLAAgAgKgFIAKAAQAEAAACgDQADgDAAgGQAAgLgJAAIgKAAg");
  this.shape_174.setTransform(426.25, -5.475);
  this.shape_175 = new cjs.Shape();
  this.shape_175.graphics.f("#0C593C").s().p("AgEAlIAAhAIgQAAIAAgJIApAAIAAAJIgRAAIAABAg");
  this.shape_175.setTransform(420.675, -5.475);
  this.shape_176 = new cjs.Shape();
  this.shape_176.graphics.f("#0C593C").s().p("AgLAiQgFgFgCgJQgCgIAAgLQAAgnAWAAQAJAAAFAHQAFAHAAALIgJAAQAAgQgLAAQgGAAgDAIQgCAJAAANQAAANACAIQACAIAHAAQAHAAACgFQACgFAAgJIAJAAQAAAMgFAIQgEAIgKAAQgJAAgEgFg");
  this.shape_176.setTransform(415.375, -5.475);
  this.shape_177 = new cjs.Shape();
  this.shape_177.graphics.f("#0C593C").s().p("AgUAzIAAhjIAIAAIAAAIIABAAQABgEAEgEQAEgCACAAQAWAAgBAmIgBAPIgCANQgDAFgEADQgEAEgGAAQgEgBgDgCQgDgCgCgFIAAAhgAgJghQgCAJAAANIAAAOQABAHADAEQADAEAEABQAGgBADgHQADgIAAgPQAAgdgMAAQgHAAgCAIg");
  this.shape_177.setTransform(409.45, -4.3);
  this.shape_178 = new cjs.Shape();
  this.shape_178.graphics.f("#0C593C").s().p("AgVATQAAgHABgEQACgEADgDQAEgCAGgCIAKgGQADgBAAgIQAAgGgCgDQgDgCgEAAQgFAAgCADQgDADAAAHIgIAAQAAgWATAAQAFAAAEACQAEADACAEQACAEAAAGIAAArQAAAGADAAIACgBIAAAIIgDABQgFAAgCgCQgCgCgBgHIgBAAQgBAFgEAEQgDADgFAAQgQAAAAgUgAABABIgHAEIgEAFQgCADAAAFQAAAMAJAAQAFAAADgFIACgCIAAgEIABgHIAAgOIgHADg");
  this.shape_178.setTransform(403.375, -5.475);
  this.shape_179 = new cjs.Shape();
  this.shape_179.graphics.f("#0C593C").s().p("AALAlIgPglIgHALIAAAaIgJAAIAAhJIAJAAIAAAiIAVgiIALAAIgUAdIAUAsg");
  this.shape_179.setTransform(398.075, -5.475);
  this.shape_180 = new cjs.Shape();
  this.shape_180.graphics.f("#0C593C").s().p("AgKAkQgEgEgDgJQgCgJAAgOQAAgmATAAQAJAAAEAFQAFAGABAIIABAUIgeAAIABAQQABAGACAEQADADAEAAQAKAAAAgSIAJAAQAAAIgCAGQgCAGgEAEQgFADgGAAQgGAAgFgDgAgIgXQgCAGAAAKIAVAAQAAgLgCgFQgCgGgHAAQgFAAgDAGg");
  this.shape_180.setTransform(392.025, -5.475);
  this.shape_181 = new cjs.Shape();
  this.shape_181.graphics.f("#0C593C").s().p("AgXAkIAAgIIAEAAQAAAAABAAQABAAAAAAQABAAAAgBQAAAAABAAIACgJIAAgSIAAgkIAlAAIAABJIgJAAIAAhAIgTAAIAAAcQAAASgDAJQgDAJgIAAIgFgBg");
  this.shape_181.setTransform(385.725, -5.45);
  this.shape_182 = new cjs.Shape();
  this.shape_182.graphics.f("#0C593C").s().p("AgKAkQgEgEgDgJQgCgJAAgOQAAgmATAAQAJAAAEAFQAFAGABAIIABAUIgeAAIABAQQABAGACAEQADADAEAAQAKAAAAgSIAJAAQAAAIgCAGQgCAGgEAEQgFADgGAAQgGAAgFgDgAgIgXQgCAGAAAKIAVAAQAAgLgCgFQgCgGgHAAQgFAAgDAGg");
  this.shape_182.setTransform(376.575, -5.475);
  this.shape_183 = new cjs.Shape();
  this.shape_183.graphics.f("#0C593C").s().p("AALAlIgPglIgHALIAAAaIgJAAIAAhJIAJAAIAAAiIAVgiIALAAIgUAdIAUAsg");
  this.shape_183.setTransform(371.275, -5.475);
  this.shape_184 = new cjs.Shape();
  this.shape_184.graphics.f("#0C593C").s().p("AAMAxIAAg3IABgJIgCAJIgUA3IgLAAIAAhJIAJAAIAAA4IgBAIIACgIIAUg4IALAAIAABJgAgJgkQgEgEAAgIIAEAAQACAJAHAAQAFAAACgCQACgCABgFIAFAAQAAAIgEAEQgEAEgHAAQgFAAgEgEg");
  this.shape_184.setTransform(364.875, -6.675);
  this.shape_185 = new cjs.Shape();
  this.shape_185.graphics.f("#0C593C").s().p("AgKAkQgEgEgDgJQgCgJAAgOQAAgmATAAQAJAAAEAFQAFAGABAIIABAUIgeAAIABAQQABAGACAEQADADAEAAQAKAAAAgSIAJAAQAAAIgCAGQgCAGgEAEQgFADgGAAQgGAAgFgDgAgIgXQgCAGAAAKIAVAAQAAgLgCgFQgCgGgHAAQgFAAgDAGg");
  this.shape_185.setTransform(358.825, -5.475);
  this.shape_186 = new cjs.Shape();
  this.shape_186.graphics.f("#0C593C").s().p("AALAlIAAgjIgVAAIAAAjIgJAAIAAhJIAJAAIAAAfIAVAAIAAgfIAJAAIAABJg");
  this.shape_186.setTransform(352.85, -5.475);
  this.shape_187 = new cjs.Shape();
  this.shape_187.graphics.f("#0C593C").s().p("AAMAlIAAg3IABgJIgCAJIgUA3IgLAAIAAhJIAJAAIAAA3IgBAJIACgJIAUg3IALAAIAABJg");
  this.shape_187.setTransform(346.475, -5.475);
  this.shape_188 = new cjs.Shape();
  this.shape_188.graphics.f("#0C593C").s().p("AgXAkIAAgIIAEAAQAAAAABAAQABAAAAAAQAAAAABgBQAAAAABAAIACgJIAAgSIAAgkIAlAAIAABJIgJAAIAAhAIgTAAIAAAcQAAASgDAJQgDAJgIAAIgFgBg");
  this.shape_188.setTransform(339.775, -5.45);
  this.shape_189 = new cjs.Shape();
  this.shape_189.graphics.f("#0C593C").s().p("AgYAyIAAhjIAYAAQAGAAAFADQAGADADAFQACAGAAAIQAAAIgDAGQgEAGgFACIAAAAQADABAEACQADADACAFQACAGABAGQAAAOgHAIQgGAHgMAAgAgOAoIAOAAQAHAAAEgEQADgFAAgKQAAgSgOAAIgOAAgAgOgGIAMAAQAEAAADgCQAEgCABgDQACgEAAgGQAAgQgNAAIgNAAg");
  this.shape_189.setTransform(330.15, -6.775);
  this.shape_190 = new cjs.Shape();
  this.shape_190.graphics.f("#0C593C").s().p("AAAAGIgHANIgFgEIAIgMIgNgFIACgGIANAGIAAgRIAFAAIAAARIANgGIACAHIgNAEIAJAMIgFAFg");
  this.shape_190.setTransform(323.325, -9.825);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_190
   }, {
    t: this.shape_189
   }, {
    t: this.shape_188
   }, {
    t: this.shape_187
   }, {
    t: this.shape_186
   }, {
    t: this.shape_185
   }, {
    t: this.shape_184
   }, {
    t: this.shape_183
   }, {
    t: this.shape_182
   }, {
    t: this.shape_181
   }, {
    t: this.shape_180
   }, {
    t: this.shape_179
   }, {
    t: this.shape_178
   }, {
    t: this.shape_177
   }, {
    t: this.shape_176
   }, {
    t: this.shape_175
   }, {
    t: this.shape_174
   }, {
    t: this.shape_173
   }, {
    t: this.shape_172
   }, {
    t: this.shape_171
   }, {
    t: this.shape_170
   }, {
    t: this.shape_169
   }, {
    t: this.shape_168
   }, {
    t: this.shape_167
   }, {
    t: this.shape_166
   }, {
    t: this.shape_165
   }, {
    t: this.shape_164
   }, {
    t: this.shape_163
   }, {
    t: this.shape_162
   }, {
    t: this.shape_161
   }, {
    t: this.shape_160
   }, {
    t: this.shape_159
   }, {
    t: this.shape_158
   }, {
    t: this.shape_157
   }, {
    t: this.shape_156
   }, {
    t: this.shape_155
   }, {
    t: this.shape_154
   }, {
    t: this.shape_153
   }, {
    t: this.shape_152
   }, {
    t: this.shape_151
   }, {
    t: this.shape_150
   }, {
    t: this.shape_149
   }, {
    t: this.shape_148
   }, {
    t: this.shape_147
   }, {
    t: this.shape_146
   }, {
    t: this.shape_145
   }, {
    t: this.shape_144
   }, {
    t: this.shape_143
   }, {
    t: this.shape_142
   }, {
    t: this.shape_141
   }, {
    t: this.shape_140
   }, {
    t: this.shape_139
   }, {
    t: this.shape_138
   }, {
    t: this.shape_137
   }, {
    t: this.shape_136
   }, {
    t: this.shape_135
   }, {
    t: this.shape_134
   }, {
    t: this.shape_133
   }, {
    t: this.shape_132
   }, {
    t: this.shape_131
   }, {
    t: this.shape_130
   }, {
    t: this.shape_129
   }, {
    t: this.shape_128
   }, {
    t: this.shape_127
   }, {
    t: this.shape_126
   }, {
    t: this.shape_125
   }, {
    t: this.shape_124
   }, {
    t: this.shape_123
   }, {
    t: this.shape_122
   }, {
    t: this.shape_121
   }, {
    t: this.shape_120
   }, {
    t: this.shape_119
   }, {
    t: this.shape_118
   }, {
    t: this.shape_117
   }, {
    t: this.shape_116
   }, {
    t: this.shape_115
   }, {
    t: this.shape_114
   }, {
    t: this.shape_113
   }, {
    t: this.shape_112
   }, {
    t: this.shape_111
   }, {
    t: this.shape_110
   }, {
    t: this.shape_109
   }, {
    t: this.shape_108
   }, {
    t: this.shape_107
   }, {
    t: this.shape_106
   }, {
    t: this.shape_105
   }, {
    t: this.shape_104
   }, {
    t: this.shape_103
   }, {
    t: this.shape_102
   }, {
    t: this.shape_101
   }, {
    t: this.shape_100
   }, {
    t: this.shape_99
   }, {
    t: this.shape_98
   }, {
    t: this.shape_97
   }, {
    t: this.shape_96
   }, {
    t: this.shape_95
   }, {
    t: this.shape_94
   }, {
    t: this.shape_93
   }, {
    t: this.shape_92
   }, {
    t: this.shape_91
   }, {
    t: this.shape_90
   }, {
    t: this.shape_89
   }, {
    t: this.shape_88
   }, {
    t: this.shape_87
   }, {
    t: this.shape_86
   }, {
    t: this.shape_85
   }, {
    t: this.shape_84
   }, {
    t: this.shape_83
   }, {
    t: this.shape_82
   }, {
    t: this.shape_81
   }, {
    t: this.shape_80
   }, {
    t: this.shape_79
   }, {
    t: this.shape_78
   }, {
    t: this.shape_77
   }, {
    t: this.shape_76
   }, {
    t: this.shape_75
   }, {
    t: this.shape_74
   }, {
    t: this.shape_73
   }, {
    t: this.shape_72
   }, {
    t: this.shape_71
   }, {
    t: this.shape_70
   }, {
    t: this.shape_69
   }, {
    t: this.shape_68
   }, {
    t: this.shape_67
   }, {
    t: this.shape_66
   }, {
    t: this.shape_65
   }, {
    t: this.shape_64
   }, {
    t: this.shape_63
   }, {
    t: this.shape_62
   }, {
    t: this.shape_61
   }, {
    t: this.shape_60
   }, {
    t: this.shape_59
   }, {
    t: this.shape_58
   }, {
    t: this.shape_57
   }, {
    t: this.shape_56
   }, {
    t: this.shape_55
   }, {
    t: this.shape_54
   }, {
    t: this.shape_53
   }, {
    t: this.shape_52
   }, {
    t: this.shape_51
   }, {
    t: this.shape_50
   }, {
    t: this.shape_49
   }, {
    t: this.shape_48
   }, {
    t: this.shape_47
   }, {
    t: this.shape_46
   }, {
    t: this.shape_45
   }, {
    t: this.shape_44
   }, {
    t: this.shape_43
   }, {
    t: this.shape_42
   }, {
    t: this.shape_41
   }, {
    t: this.shape_40
   }, {
    t: this.shape_39
   }, {
    t: this.shape_38
   }, {
    t: this.shape_37
   }, {
    t: this.shape_36
   }, {
    t: this.shape_35
   }, {
    t: this.shape_34
   }, {
    t: this.shape_33
   }, {
    t: this.shape_32
   }, {
    t: this.shape_31
   }, {
    t: this.shape_30
   }, {
    t: this.shape_29
   }, {
    t: this.shape_28
   }, {
    t: this.shape_27
   }, {
    t: this.shape_26
   }, {
    t: this.shape_25
   }, {
    t: this.shape_24
   }, {
    t: this.shape_23
   }, {
    t: this.shape_22
   }, {
    t: this.shape_21
   }, {
    t: this.shape_20
   }, {
    t: this.shape_19
   }, {
    t: this.shape_18
   }, {
    t: this.shape_17
   }, {
    t: this.shape_16
   }, {
    t: this.shape_15
   }, {
    t: this.shape_14
   }, {
    t: this.shape_13
   }, {
    t: this.shape_12
   }, {
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
  this.shape_191 = new cjs.Shape();
  this.shape_191.graphics.f("rgba(216,247,139,0.698)").s().p("EhLxAD6IAAnzMCXjAAAIAAHzg");
  this.shape_191.setTransform(485, 10);
  this.timeline.addTween(cjs.Tween.get(this.shape_191).wait(1));
 }).prototype = getMCSymbolPrototype(lib.l3, new cjs.Rectangle(0, -17, 970.5, 56.8), null);
 (lib.l1_3 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#0C593C").s().p("AgEAGIAAgLIAJAAIAAALg");
  this.shape.setTransform(819.9, 4.6);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#0C593C").s().p("AAMAiIAAggIgXAAIAAAgIgKAAIAAhDIAKAAIAAAcIAXAAIAAgcIAKAAIAABDg");
  this.shape_1.setTransform(815.4, 1.85);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#0C593C").s().p("AgMAgQgFgEgDgHQgDgIAAgNQAAgQAGgJQAGgJALAAQAYAAAAAiQAAANgDAIQgDAIgFADQgGADgHAAQgHAAgFgDgAgHgYQgDADgCAGQgBAGAAAKQAAAIABAGQACAGADADQACADAFAAQAGAAADgDQADgDABgGIABgOQAAgKgCgGQgBgGgDgDQgDgCgFAAQgEAAgDACg");
  this.shape_2.setTransform(809.4, 1.875);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#0C593C").s().p("AALAiIgQgiIgGAKIAAAYIgLAAIAAhDIALAAIAAAgIAVggIALAAIgUAaIAVApg");
  this.shape_3.setTransform(804.1, 1.85);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#0C593C").s().p("AANAiIAAgyIABgJIgDAJIgUAyIgMAAIAAhDIAKAAIAAAyIgBAJIACgJIAUgyIAMAAIAABDg");
  this.shape_4.setTransform(798, 1.85);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#0C593C").s().p("AgEAiIAAg7IgRAAIAAgIIArAAIAAAIIgRAAIAAA7g");
  this.shape_5.setTransform(792.7, 1.85);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#0C593C").s().p("AgKAgQgFgEgDgHQgCgIAAgNQAAgiAUAAQAJAAAFAFQAFAFABAHQABAIAAAKIgfAAIAAAOQABAGADADQACADAFAAQALAAAAgQIAJAAQAAAHgCAFQgCAGgFADQgEADgHAAQgGAAgFgDgAgIgVQgCAGAAAJIAVAAQAAgKgCgFQgCgFgHAAQgGAAgCAFg");
  this.shape_6.setTransform(787.675, 1.875);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#0C593C").s().p("AAUAiIAAg6IgRA6IgFAAIgRg6IAAA6IgJAAIAAhDIAOAAIANArIABAPIACgPIAMgrIAPAAIAABDg");
  this.shape_7.setTransform(781.275, 1.85);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#0C593C").s().p("AANAiIAAgyIAAgJIgBAJIgWAyIgLAAIAAhDIAJAAIAAAyIgBAJIACgJIAWgyIALAAIAABDg");
  this.shape_8.setTransform(774.45, 1.85);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#0C593C").s().p("AgMAeQgFgEgCgIQgCgHAAgKQAAgjAXAAQAJAAAGAGQAFAHAAAJIgJAAQAAgOgLAAQgHAAgDAHQgDAIAAAMQAAALADAIQACAHAHAAQAHAAACgEQACgFABgIIAJAAQAAALgFAHQgFAHgKAAQgJAAgFgFg");
  this.shape_9.setTransform(768.725, 1.875);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.f("#0C593C").s().p("AgdAEIAAgHIA7AAIAAAHg");
  this.shape_10.setTransform(760.05, 1.475);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.f("#0C593C").s().p("AgMAgQgFgEgDgHQgDgIAAgNQAAgQAGgJQAGgJALAAQAYAAAAAiQAAANgDAIQgCAIgGADQgFADgIAAQgHAAgFgDgAgHgYQgDADgCAGQgBAGAAAKQAAAIABAGQABAGAEADQADADAEAAQAFAAADgDQAEgDABgGIABgOQAAgKgBgGQgCgGgDgDQgDgCgFAAQgEAAgDACg");
  this.shape_11.setTransform(751.05, 1.875);
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.f("#0C593C").s().p("AgTAiIAAhDIAUAAQAIAAAFAFQAFAFAAAGQAAAHgCAEQgEAEgEACIAAAAQAGAAADAFQACADAAAIQAAAFgBAEQgDAEgEADQgDACgFAAgAgKAaIAKAAQAHgBACgCQACgDAAgGQAAgFgCgDQgEgEgEAAIgLAAgAgKgEIAKAAQAFAAACgDQACgDABgFQgBgKgJAAIgKAAg");
  this.shape_12.setTransform(745.5, 1.85);
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.f("#0C593C").s().p("AgEAiIAAg7IgRAAIAAgIIArAAIAAAIIgRAAIAAA7g");
  this.shape_13.setTransform(740.35, 1.85);
  this.shape_14 = new cjs.Shape();
  this.shape_14.graphics.f("#0C593C").s().p("AgMAeQgFgEgCgIQgCgHAAgKQAAgjAXAAQAJAAAGAGQAFAHAAAJIgJAAQAAgOgLAAQgHAAgDAHQgDAIAAAMQAAALADAIQACAHAHAAQAHAAACgEQACgFABgIIAJAAQAAALgFAHQgFAHgKAAQgJAAgFgFg");
  this.shape_14.setTransform(735.375, 1.875);
  this.shape_15 = new cjs.Shape();
  this.shape_15.graphics.f("#0C593C").s().p("AgKAgQgFgEgDgHQgCgIAAgNQAAgiAUAAQAJAAAFAFQAFAFABAHQABAIAAAKIgfAAIAAAOQABAGADADQACADAFAAQALAAAAgQIAJAAQAAAHgCAFQgCAGgFADQgEADgHAAQgGAAgFgDgAgIgVQgCAGAAAJIAVAAQAAgKgCgFQgCgFgHAAQgGAAgCAFg");
  this.shape_15.setTransform(729.975, 1.875);
  this.shape_16 = new cjs.Shape();
  this.shape_16.graphics.f("#0C593C").s().p("AAfArIAAgSIhFAAIAAhDIAJAAIAAA7IAWAAIAAg7IAJAAIAAA7IAVAAIAAg7IAKAAIAAA7IAGAAIAAAag");
  this.shape_16.setTransform(723.175, 2.75);
  this.shape_17 = new cjs.Shape();
  this.shape_17.graphics.f("#0C593C").s().p("AgKAgQgFgEgDgHQgCgIAAgNQAAgiAUAAQAJAAAFAFQAFAFABAHQABAIAAAKIgfAAIAAAOQABAGADADQACADAFAAQALAAAAgQIAJAAQAAAHgCAFQgCAGgFADQgEADgHAAQgGAAgFgDgAgIgVQgCAGAAAJIAVAAQAAgKgCgFQgCgFgHAAQgGAAgCAFg");
  this.shape_17.setTransform(715.625, 1.875);
  this.shape_18 = new cjs.Shape();
  this.shape_18.graphics.f("#0C593C").s().p("AgUAiIAAhDIAVAAQAIAAAFAFQAFAFAAAGQAAAHgDAEQgDAEgEACIAAAAQAFAAADAFQAEADAAAIQAAAFgDAEQgCAEgDADQgFACgDAAgAgKAaIAKAAQAGgBADgCQACgDAAgGQAAgFgDgDQgCgEgGAAIgKAAgAgKgEIAKAAQAEAAADgDQACgDAAgFQAAgKgJAAIgKAAg");
  this.shape_18.setTransform(710.45, 1.85);
  this.shape_19 = new cjs.Shape();
  this.shape_19.graphics.f("#0C593C").s().p("AgKAgQgFgEgDgHQgCgIAAgNQAAgiAUAAQAJAAAFAFQAFAFABAHQABAIAAAKIgfAAIAAAOQABAGADADQACADAFAAQALAAAAgQIAJAAQAAAHgCAFQgCAGgFADQgEADgHAAQgGAAgFgDgAgIgVQgCAGAAAJIAVAAQAAgKgCgFQgCgFgHAAQgGAAgCAFg");
  this.shape_19.setTransform(701.825, 1.875);
  this.shape_20 = new cjs.Shape();
  this.shape_20.graphics.f("#0C593C").s().p("AgKAgQgFgEgDgHQgCgIAAgNQAAgiAUAAQAJAAAFAFQAFAFABAHQABAIAAAKIgfAAIAAAOQABAGADADQACADAFAAQALAAAAgQIAJAAQAAAHgCAFQgCAGgFADQgEADgHAAQgGAAgFgDgAgIgVQgCAGAAAJIAVAAQAAgKgCgFQgCgFgHAAQgGAAgCAFg");
  this.shape_20.setTransform(696.475, 1.875);
  this.shape_21 = new cjs.Shape();
  this.shape_21.graphics.f("#0C593C").s().p("AAfArIAAgSIhFAAIAAhDIAJAAIAAA7IAWAAIAAg7IAJAAIAAA7IAVAAIAAg7IAKAAIAAA7IAGAAIAAAag");
  this.shape_21.setTransform(689.675, 2.75);
  this.shape_22 = new cjs.Shape();
  this.shape_22.graphics.f("#0C593C").s().p("AgGAbQgGgHAAgSIgMAAIAAAfIgJAAIAAhCIAJAAIAAAcIAMAAQgBgNAHgIQAGgIAKAAQAMAAAHAIQAFAJAAAQQAAANgCAIQgEAIgFAEQgFADgIAAQgKAAgGgIgAADgYQgDADgBAGQgBAHgBAJQAAAMADAHQADAHAHAAQAIAAAEgHQACgGAAgNQABgOgEgHQgDgGgIAAQgEAAgDACg");
  this.shape_22.setTransform(680.85, 1.875);
  this.shape_23 = new cjs.Shape();
  this.shape_23.graphics.f("#0C593C").s().p("AgWAsIAAgIQADABAEAAQAFAAACgDQADgEACgHIgVhDIAKAAIAOA1IABAAIAOg1IAKAAIgUBCIgFANQgBAEgEADQgEADgGAAIgHgBg");
  this.shape_23.setTransform(673.725, 3);
  this.shape_24 = new cjs.Shape();
  this.shape_24.graphics.f("#0C593C").s().p("AgUAiIAAhDIAVAAQAIAAAFAFQAFAFAAAGQAAAHgDAEQgDAEgEACIAAAAQAFAAADAFQAEADAAAIQAAAFgDAEQgCAEgDADQgFACgDAAgAgKAaIAKAAQAGgBADgCQACgDAAgGQAAgFgDgDQgCgEgGAAIgKAAgAgKgEIAKAAQAEAAADgDQACgDAAgFQAAgKgJAAIgKAAg");
  this.shape_24.setTransform(668.6, 1.85);
  this.shape_25 = new cjs.Shape();
  this.shape_25.graphics.f("#0C593C").s().p("AgEAiIAAg7IgRAAIAAgIIArAAIAAAIIgRAAIAAA7g");
  this.shape_25.setTransform(663.45, 1.85);
  this.shape_26 = new cjs.Shape();
  this.shape_26.graphics.f("#0C593C").s().p("AgMAeQgFgEgCgIQgCgHAAgKQAAgjAXAAQAJAAAGAGQAFAHAAAJIgJAAQAAgOgLAAQgHAAgDAHQgDAIAAAMQAAALADAIQACAHAHAAQAHAAACgEQACgFABgIIAJAAQAAALgFAHQgFAHgKAAQgJAAgFgFg");
  this.shape_26.setTransform(658.475, 1.875);
  this.shape_27 = new cjs.Shape();
  this.shape_27.graphics.f("#0C593C").s().p("AANAsIAAgxIABgJIgCAJIgWAxIgLAAIAAhCIAKAAIAAAyIgBAIIABgIIAVgyIAMAAIAABCgAgKggQgDgEgBgHIAFAAQACAIAHAAQAEAAADgCQACgCABgEIAFAAQAAAHgEAEQgEAEgHAAQgGAAgEgEg");
  this.shape_27.setTransform(652.75, 0.775);
  this.shape_28 = new cjs.Shape();
  this.shape_28.graphics.f("#0C593C").s().p("AgKAgQgFgEgDgHQgCgIAAgNQAAgiAUAAQAJAAAFAFQAFAFABAHQABAIAAAKIgfAAIAAAOQABAGADADQACADAFAAQALAAAAgQIAJAAQAAAHgCAFQgCAGgFADQgEADgHAAQgGAAgFgDgAgIgVQgCAGAAAJIAVAAQAAgKgCgFQgCgFgHAAQgGAAgCAFg");
  this.shape_28.setTransform(646.975, 1.875);
  this.shape_29 = new cjs.Shape();
  this.shape_29.graphics.f("#0C593C").s().p("AAaA3IAAgUIgzAAIAAAUIgJAAIAAgdIAGAAQAEgIACgIQACgIABgJIAAgZIAAgWIAvAAIAABQIAHAAIAAAdgAgJgWIgBAUIgDAOQgBAHgDAHIAjAAIAAhHIgbAAg");
  this.shape_29.setTransform(640.575, 1.75);
  this.shape_30 = new cjs.Shape();
  this.shape_30.graphics.f("#0C593C").s().p("AgFAGIAAgLIAKAAIAAALg");
  this.shape_30.setTransform(629.3, 4.6);
  this.shape_31 = new cjs.Shape();
  this.shape_31.graphics.f("#0C593C").s().p("AgYAhIAAgIIAEABQAAAAABAAQAAgBABAAQAAAAABAAQAAgBABAAQABgCABgGIABgQIAAghIAmAAIAABCIgJAAIAAg6IgUAAIAAAaQAAAQgDAIQgDAJgJAAIgFgBg");
  this.shape_31.setTransform(624.475, 1.875);
  this.shape_32 = new cjs.Shape();
  this.shape_32.graphics.f("#0C593C").s().p("AgWAsIAAgIQADABAEAAQAFAAACgDQADgEACgHIgVhDIAKAAIAOA1IABAAIAOg1IAKAAIgUBCIgFANQgBAEgEADQgEADgGAAIgHgBg");
  this.shape_32.setTransform(619.025, 3);
  this.shape_33 = new cjs.Shape();
  this.shape_33.graphics.f("#0C593C").s().p("AgMAeQgFgEgCgIQgCgHAAgKQAAgjAXAAQAJAAAGAGQAFAHAAAJIgJAAQAAgOgLAAQgHAAgDAHQgDAIAAAMQAAALADAIQACAHAHAAQAHAAACgEQACgFABgIIAJAAQAAALgFAHQgFAHgKAAQgJAAgFgFg");
  this.shape_33.setTransform(613.775, 1.875);
  this.shape_34 = new cjs.Shape();
  this.shape_34.graphics.f("#0C593C").s().p("AAMAiIAAg7IgXAAIAAA7IgJAAIAAhDIAqAAIAABDg");
  this.shape_34.setTransform(608.1, 1.85);
  this.shape_35 = new cjs.Shape();
  this.shape_35.graphics.f("#0C593C").s().p("AgWARQAAgGACgEQABgEAEgCIAKgEIAKgFQADgBAAgHQAAgGgCgCQgCgCgFAAQgFAAgDADQgCADAAAFIgIAAQAAgTATAAQAFAAAEACQAFACACAEQACAEAAAFIAAAmQAAAFADAAIACAAIAAAHIgEABQgEAAgDgCQgCgBgBgHIAAAAQgCAFgEADQgDADgFAAQgRAAAAgSgAABAAIgHAEQgDACgBADQgCADAAAEQAAAKAJAAQAFAAADgDIACgDIABgDIAAgHIAAgMIgHACg");
  this.shape_35.setTransform(602.425, 1.875);
  this.shape_36 = new cjs.Shape();
  this.shape_36.graphics.f("#0C593C").s().p("AALAiIgQgiIgHAKIAAAYIgKAAIAAhDIAKAAIAAAgIAWggIALAAIgUAaIAVApg");
  this.shape_36.setTransform(597.45, 1.85);
  this.shape_37 = new cjs.Shape();
  this.shape_37.graphics.f("#0C593C").s().p("AgKAgQgFgEgDgHQgCgIAAgNQAAgiAUAAQAJAAAFAFQAFAFABAHQABAIAAAKIgfAAIAAAOQABAGADADQACADAFAAQALAAAAgQIAJAAQAAAHgCAFQgCAGgFADQgEADgHAAQgGAAgFgDgAgIgVQgCAGAAAJIAVAAQAAgKgCgFQgCgFgHAAQgGAAgCAFg");
  this.shape_37.setTransform(588.675, 1.875);
  this.shape_38 = new cjs.Shape();
  this.shape_38.graphics.f("#0C593C").s().p("AAUAiIAAg6IgRA6IgFAAIgRg6IAAA6IgJAAIAAhDIAOAAIANArIABAPIACgPIAMgrIAPAAIAABDg");
  this.shape_38.setTransform(582.275, 1.85);
  this.shape_39 = new cjs.Shape();
  this.shape_39.graphics.f("#0C593C").s().p("AgWAuIAAhYIAKAAIAAAHQACgEAEgDQAEgCADAAQAWAAAAAhIgBAOQgBAGgDAFQgCAFgEADQgFADgGAAQgDAAgEgDQgDgCgDgEIAAAegAgKgdQgCAHAAANIABAMQAAAGADAEQADAEAFAAQAHAAADgHQADgIAAgNQAAgZgNAAQgHgBgDAIg");
  this.shape_39.setTransform(575.625, 2.9);
  this.shape_40 = new cjs.Shape();
  this.shape_40.graphics.f("#0C593C").s().p("AgMAgQgFgEgDgHQgDgIAAgNQAAgQAGgJQAGgJALAAQAYAAAAAiQAAANgDAIQgCAIgGADQgGADgHAAQgGAAgGgDgAgHgYQgDADgBAGQgCAGAAAKQAAAIACAGQABAGACADQAEADAEAAQAFAAADgDQADgDACgGIABgOQAAgKgBgGQgCgGgDgDQgDgCgFAAQgEAAgDACg");
  this.shape_40.setTransform(569.5, 1.875);
  this.shape_41 = new cjs.Shape();
  this.shape_41.graphics.f("#0C593C").s().p("AgEA4IAAgdQgDAEgDACQgEADgEAAQgJAAgEgFQgFgFgCgIQgCgIABgKQAAgKACgHQABgIAGgEQAFgFAHAAQAEAAAEACQAEADACAEIAAgeIAJAAIAAAeQACgEADgCQAEgDAEAAQAMAAAFAJQAFAKABAPQgBAkgVAAQgFAAgDgDQgDgCgDgEIAAAdgAAHgSQgDAIABAKQgBANADAHQADAIAHAAQAIAAACgIQAEgHAAgNQAAgagOAAQgIAAgCAIgAgdAAQAAANACAHQADAIAHAAQAGAAADgFQADgEABgFIAAgOQAAgKgCgIQgCgIgJAAQgNAAABAag");
  this.shape_41.setTransform(561.85, 1.825);
  this.shape_42 = new cjs.Shape();
  this.shape_42.graphics.f("#0C593C").s().p("AgTAiIAAhDIAUAAQAIAAAFAFQAFAFAAAGQAAAHgCAEQgDAEgFACIAAAAQAGAAADAFQACADAAAIQAAAFgCAEQgCAEgEADQgDACgFAAgAgKAaIAKAAQAHgBACgCQACgDAAgGQAAgFgCgDQgEgEgEAAIgLAAgAgKgEIAKAAQAFAAACgDQACgDAAgFQABgKgKAAIgKAAg");
  this.shape_42.setTransform(551.65, 1.85);
  this.shape_43 = new cjs.Shape();
  this.shape_43.graphics.f("#0C593C").s().p("AgKAgQgFgEgDgHQgCgIAAgNQAAgiAUAAQAJAAAFAFQAFAFABAHQABAIAAAKIgfAAIAAAOQABAGADADQACADAFAAQALAAAAgQIAJAAQAAAHgCAFQgCAGgFADQgEADgHAAQgGAAgFgDgAgIgVQgCAGAAAJIAVAAQAAgKgCgFQgCgFgHAAQgGAAgCAFg");
  this.shape_43.setTransform(543.025, 1.875);
  this.shape_44 = new cjs.Shape();
  this.shape_44.graphics.f("#0C593C").s().p("AALAiIgPgiIgIAKIAAAYIgJAAIAAhDIAJAAIAAAgIAXggIALAAIgVAaIAWApg");
  this.shape_44.setTransform(538.1, 1.85);
  this.shape_45 = new cjs.Shape();
  this.shape_45.graphics.f("#0C593C").s().p("AAMAiIAAggIgXAAIAAAgIgJAAIAAhDIAJAAIAAAcIAXAAIAAgcIAKAAIAABDg");
  this.shape_45.setTransform(532.05, 1.85);
  this.shape_46 = new cjs.Shape();
  this.shape_46.graphics.f("#0C593C").s().p("AAVAiIAAhDIAKAAIAABDgAgeAiIAAhDIAJAAIAAAdIAOAAQAGAAADADQAEABACAFQADAEAAAGQAAAFgDAFQgCAEgEACQgDACgGABgAgVAaIAKAAQAHgBADgCQACgDAAgGQAAgMgLAAIgLAAg");
  this.shape_46.setTransform(525.15, 1.85);
  this.shape_47 = new cjs.Shape();
  this.shape_47.graphics.f("#0C593C").s().p("AgWAuIAAhYIAKAAIAAAHQACgEAEgDQAEgCADAAQAWAAAAAhIgBAOQgBAGgDAFQgCAFgEADQgFADgGAAQgDAAgEgDQgDgCgDgEIAAAegAgKgdQgCAHAAANIABAMQAAAGADAEQADAEAFAAQAHAAADgHQADgIAAgNQAAgZgNAAQgHgBgDAIg");
  this.shape_47.setTransform(518.325, 2.9);
  this.shape_48 = new cjs.Shape();
  this.shape_48.graphics.f("#0C593C").s().p("AgWARQAAgGACgEQABgEAEgCIAKgEIAKgFQADgBAAgHQAAgGgCgCQgCgCgFAAQgFAAgDADQgCADAAAFIgIAAQAAgTATAAQAFAAAEACQAFACACAEQACAEAAAFIAAAmQAAAFADAAIACAAIAAAHIgEABQgEAAgDgCQgCgBgBgHIAAAAQgCAFgEADQgDADgFAAQgRAAAAgSgAABAAIgHAEQgDACgBADQgCADAAAEQAAAKAJAAQAFAAADgDIACgDIABgDIAAgHIAAgMIgHACg");
  this.shape_48.setTransform(509.525, 1.875);
  this.shape_49 = new cjs.Shape();
  this.shape_49.graphics.f("#0C593C").s().p("AAMAiIAAggIgXAAIAAAgIgKAAIAAhDIAKAAIAAAcIAXAAIAAgcIAJAAIAABDg");
  this.shape_49.setTransform(503.85, 1.85);
  this.shape_50 = new cjs.Shape();
  this.shape_50.graphics.f("#0C593C").s().p("AAQAiIgPgcIgQAcIgJAAIAUgiIgUghIAKAAIAPAaIAOgaIAKAAIgTAhIAUAig");
  this.shape_50.setTransform(492.15, 1.85);
  this.shape_51 = new cjs.Shape();
  this.shape_51.graphics.f("#0C593C").s().p("AAVAiIAAhDIAKAAIAABDgAgeAiIAAhDIAKAAIAAAdIANAAQAFAAADADQAFABACAFQADAEgBAGQABAFgDAFQgCAEgFACQgDACgFABgAgUAaIAKAAQAGgBADgCQABgDAAgGQAAgMgKAAIgKAAg");
  this.shape_51.setTransform(485.6, 1.85);
  this.shape_52 = new cjs.Shape();
  this.shape_52.graphics.f("#0C593C").s().p("AAMAiIAAggIgXAAIAAAgIgKAAIAAhDIAKAAIAAAcIAXAAIAAgcIAJAAIAABDg");
  this.shape_52.setTransform(478.65, 1.85);
  this.shape_53 = new cjs.Shape();
  this.shape_53.graphics.f("#0C593C").s().p("AAMAiIAAggIgXAAIAAAgIgJAAIAAhDIAJAAIAAAcIAXAAIAAgcIAKAAIAABDg");
  this.shape_53.setTransform(472.65, 1.85);
  this.shape_54 = new cjs.Shape();
  this.shape_54.graphics.f("#0C593C").s().p("AgKAgQgFgEgDgHQgCgIAAgNQAAgiAUAAQAJAAAFAFQAFAFABAHQABAIAAAKIgfAAIAAAOQABAGADADQACADAFAAQALAAAAgQIAJAAQAAAHgCAFQgCAGgFADQgEADgHAAQgGAAgFgDgAgIgVQgCAGAAAJIAVAAQAAgKgCgFQgCgFgHAAQgGAAgCAFg");
  this.shape_54.setTransform(466.925, 1.875);
  this.shape_55 = new cjs.Shape();
  this.shape_55.graphics.f("#0C593C").s().p("AgYAhIAAgIIAEABQAAAAABAAQABgBAAAAQABAAAAAAQAAgBABAAQABgCABgGIABgQIAAghIAmAAIAABCIgJAAIAAg6IgUAAIAAAaQAAAQgDAIQgDAJgJAAIgFgBg");
  this.shape_55.setTransform(460.975, 1.875);
  this.shape_56 = new cjs.Shape();
  this.shape_56.graphics.f("#0C593C").s().p("AgUAiIAAhDIAVAAQAIAAAFAFQAFAFAAAGQAAAHgDAEQgDAEgEACIAAAAQAFAAADAFQAEADAAAIQAAAFgDAEQgCAEgDADQgFACgDAAgAgKAaIAKAAQAGgBADgCQACgDAAgGQAAgFgDgDQgCgEgGAAIgKAAgAgKgEIAKAAQAEAAADgDQACgDAAgFQAAgKgJAAIgKAAg");
  this.shape_56.setTransform(455.75, 1.85);
  this.shape_57 = new cjs.Shape();
  this.shape_57.graphics.f("#0C593C").s().p("AgWARQAAgGACgEQABgEAEgCIAKgEIAKgFQADgBAAgHQAAgGgCgCQgCgCgFAAQgFAAgDADQgCADAAAFIgIAAQAAgTATAAQAFAAAEACQAFACACAEQACAEAAAFIAAAmQAAAFADAAIACAAIAAAHIgEABQgEAAgDgCQgCgBgBgHIAAAAQgCAFgEADQgDADgFAAQgRAAAAgSgAABAAIgHAEQgDACgBADQgCADAAAEQAAAKAJAAQAFAAADgDIACgDIABgDIAAgHIAAgMIgHACg");
  this.shape_57.setTransform(450.175, 1.875);
  this.shape_58 = new cjs.Shape();
  this.shape_58.graphics.f("#0C593C").s().p("AgEAiIAAg7IgRAAIAAgIIArAAIAAAIIgRAAIAAA7g");
  this.shape_58.setTransform(445.25, 1.85);
  this.shape_59 = new cjs.Shape();
  this.shape_59.graphics.f("#0C593C").s().p("AgMAeQgFgEgCgIQgCgHAAgKQAAgjAXAAQAJAAAGAGQAFAHAAAJIgJAAQAAgOgLAAQgHAAgDAHQgDAIAAAMQAAALADAIQACAHAHAAQAHAAACgEQACgFABgIIAJAAQAAALgFAHQgFAHgKAAQgJAAgFgFg");
  this.shape_59.setTransform(440.275, 1.875);
  this.shape_60 = new cjs.Shape();
  this.shape_60.graphics.f("#0C593C").s().p("AATArIAAgSIgmAAIAAASIgJAAIAAgaIAHAAIAEgMIADgKIABgOIAAgXIAjAAIAAA7IAGAAIAAAagAgEgOQAAAKgCAFQgCAGgDAKIAYAAIAAgzIgRAAg");
  this.shape_60.setTransform(434.5, 2.75);
  this.shape_61 = new cjs.Shape();
  this.shape_61.graphics.f("#0C593C").s().p("AgKAgQgFgEgDgHQgCgIAAgNQAAgiAUAAQAJAAAFAFQAFAFABAHQABAIAAAKIgfAAIAAAOQABAGADADQACADAFAAQALAAAAgQIAJAAQAAAHgCAFQgCAGgFADQgEADgHAAQgGAAgFgDgAgIgVQgCAGAAAJIAVAAQAAgKgCgFQgCgFgHAAQgGAAgCAFg");
  this.shape_61.setTransform(428.725, 1.875);
  this.shape_62 = new cjs.Shape();
  this.shape_62.graphics.f("#0C593C").s().p("AgWAuIAAhYIAKAAIAAAHQACgEAEgDQAEgCADAAQAWAAAAAhIgBAOQgBAGgDAFQgCAFgEADQgFADgGAAQgDAAgEgDQgDgCgDgEIAAAegAgKgdQgCAHAAANIABAMQAAAGADAEQADAEAFAAQAHAAADgHQADgIAAgNQAAgZgNAAQgHgBgDAIg");
  this.shape_62.setTransform(423.225, 2.9);
  this.shape_63 = new cjs.Shape();
  this.shape_63.graphics.f("#0C593C").s().p("AAMAiIAAg7IgXAAIAAA7IgJAAIAAhDIApAAIAABDg");
  this.shape_63.setTransform(417.1, 1.85);
  this.shape_64 = new cjs.Shape();
  this.shape_64.graphics.f("#0C593C").s().p("AgFAJQAFgBABgKIgGAAIAAgMIAKAAIAAAOQAAAFgCAEQgDAEgFACg");
  this.shape_64.setTransform(409.6, 5.475);
  this.shape_65 = new cjs.Shape();
  this.shape_65.graphics.f("#0C593C").s().p("AgUAiIAAhDIAVAAQAIAAAFAFQAFAFAAAGQAAAHgDAEQgDAEgEACIAAAAQAGAAADAFQADADAAAIQAAAFgCAEQgDAEgEADQgEACgEAAgAgKAaIAKAAQAHgBACgCQACgDAAgGQAAgFgCgDQgEgEgEAAIgLAAgAgKgEIAKAAQAEAAADgDQADgDAAgFQgBgKgJAAIgKAAg");
  this.shape_65.setTransform(405.55, 1.85);
  this.shape_66 = new cjs.Shape();
  this.shape_66.graphics.f("#0C593C").s().p("AgEAiIAAg7IgRAAIAAgIIArAAIAAAIIgRAAIAAA7g");
  this.shape_66.setTransform(400.4, 1.85);
  this.shape_67 = new cjs.Shape();
  this.shape_67.graphics.f("#0C593C").s().p("AgMAeQgFgEgCgIQgCgHAAgKQAAgjAXAAQAJAAAGAGQAFAHAAAJIgJAAQAAgOgLAAQgHAAgDAHQgDAIAAAMQAAALADAIQACAHAHAAQAHAAACgEQACgFABgIIAJAAQAAALgFAHQgFAHgKAAQgJAAgFgFg");
  this.shape_67.setTransform(395.425, 1.875);
  this.shape_68 = new cjs.Shape();
  this.shape_68.graphics.f("#0C593C").s().p("AATArIAAgSIglAAIAAASIgJAAIAAgaIAFAAIAFgMIACgKIABgOIAAgXIAkAAIAAA7IAGAAIAAAagAgFgOQAAAKgBAFQgBAGgEAKIAXAAIAAgzIgRAAg");
  this.shape_68.setTransform(389.65, 2.75);
  this.shape_69 = new cjs.Shape();
  this.shape_69.graphics.f("#0C593C").s().p("AgKAgQgFgEgDgHQgCgIAAgNQAAgiAUAAQAJAAAFAFQAFAFABAHQABAIAAAKIgfAAIAAAOQABAGADADQACADAFAAQALAAAAgQIAJAAQAAAHgCAFQgCAGgFADQgEADgHAAQgGAAgFgDgAgIgVQgCAGAAAJIAVAAQAAgKgCgFQgCgFgHAAQgGAAgCAFg");
  this.shape_69.setTransform(383.875, 1.875);
  this.shape_70 = new cjs.Shape();
  this.shape_70.graphics.f("#0C593C").s().p("AgWAuIAAhYIAKAAIAAAHQACgEAEgDQAEgCADAAQAWAAAAAhIgBAOQgBAGgDAFQgCAFgEADQgFADgGAAQgDAAgEgDQgDgCgDgEIAAAegAgKgdQgCAHAAANIABAMQAAAGADAEQADAEAFAAQAHAAADgHQADgIAAgNQAAgZgNAAQgHgBgDAIg");
  this.shape_70.setTransform(378.375, 2.9);
  this.shape_71 = new cjs.Shape();
  this.shape_71.graphics.f("#0C593C").s().p("AgMAeQgFgEgCgIQgCgHAAgKQAAgjAXAAQAJAAAGAGQAFAHAAAJIgJAAQAAgOgLAAQgHAAgDAHQgDAIAAAMQAAALADAIQACAHAHAAQAHAAACgEQACgFABgIIAJAAQAAALgFAHQgFAHgKAAQgJAAgFgFg");
  this.shape_71.setTransform(372.575, 1.875);
  this.shape_72 = new cjs.Shape();
  this.shape_72.graphics.f("#0C593C").s().p("AAQAiIgQgcIgPAcIgKAAIAVgiIgUghIALAAIAOAaIAOgaIAKAAIgTAhIAUAig");
  this.shape_72.setTransform(364.2, 1.85);
  this.shape_73 = new cjs.Shape();
  this.shape_73.graphics.f("#0C593C").s().p("AAVAiIAAhDIAKAAIAABDgAgeAiIAAhDIAKAAIAAAdIANAAQAFAAAEADQAEABACAFQADAEAAAGQAAAFgDAFQgCAEgEACQgEACgFABgAgUAaIAJAAQAHgBADgCQABgDAAgGQABgMgLAAIgKAAg");
  this.shape_73.setTransform(357.65, 1.85);
  this.shape_74 = new cjs.Shape();
  this.shape_74.graphics.f("#0C593C").s().p("AAMAiIAAggIgXAAIAAAgIgJAAIAAhDIAJAAIAAAcIAXAAIAAgcIAKAAIAABDg");
  this.shape_74.setTransform(350.7, 1.85);
  this.shape_75 = new cjs.Shape();
  this.shape_75.graphics.f("#0C593C").s().p("AAMAiIAAggIgXAAIAAAgIgKAAIAAhDIAKAAIAAAcIAXAAIAAgcIAKAAIAABDg");
  this.shape_75.setTransform(344.7, 1.85);
  this.shape_76 = new cjs.Shape();
  this.shape_76.graphics.f("#0C593C").s().p("AgMAgQgFgEgDgHQgDgIAAgNQAAgQAGgJQAGgJALAAQAYAAAAAiQAAANgDAIQgDAIgFADQgGADgHAAQgHAAgFgDgAgHgYQgDADgCAGQgBAGAAAKQAAAIABAGQACAGADADQADADAEAAQAGAAADgDQADgDABgGIABgOQAAgKgCgGQgBgGgDgDQgDgCgFAAQgEAAgDACg");
  this.shape_76.setTransform(338.7, 1.875);
  this.shape_77 = new cjs.Shape();
  this.shape_77.graphics.f("#0C593C").s().p("AgRAiIAAhDIAjAAIAAAIIgZAAIAAA7g");
  this.shape_77.setTransform(333.875, 1.85);
  this.shape_78 = new cjs.Shape();
  this.shape_78.graphics.f("#0C593C").s().p("AgMAgQgFgEgDgHQgDgIAAgNQAAgQAGgJQAGgJALAAQAYAAAAAiQAAANgDAIQgDAIgFADQgGADgHAAQgGAAgGgDgAgHgYQgDADgCAGQgBAGAAAKQAAAIABAGQACAGADADQADADAEAAQAFAAAEgDQADgDABgGIABgOQAAgKgCgGQgBgGgDgDQgDgCgFAAQgEAAgDACg");
  this.shape_78.setTransform(328.25, 1.875);
  this.shape_79 = new cjs.Shape();
  this.shape_79.graphics.f("#0C593C").s().p("AgWAuIAAhYIAKAAIAAAHQACgEAEgDQAEgCADAAQAWAAAAAhIgBAOQgBAGgDAFQgCAFgEADQgFADgGAAQgDAAgEgDQgDgCgDgEIAAAegAgKgdQgCAHAAANIABAMQAAAGADAEQADAEAFAAQAHAAADgHQADgIAAgNQAAgZgNAAQgHgBgDAIg");
  this.shape_79.setTransform(322.375, 2.9);
  this.shape_80 = new cjs.Shape();
  this.shape_80.graphics.f("#0C593C").s().p("AgEAiIAAg7IgRAAIAAgIIArAAIAAAIIgRAAIAAA7g");
  this.shape_80.setTransform(317, 1.85);
  this.shape_81 = new cjs.Shape();
  this.shape_81.graphics.f("#0C593C").s().p("AgKAgQgFgEgDgHQgCgIAAgNQAAgiAUAAQAJAAAFAFQAFAFABAHQABAIAAAKIgfAAIAAAOQABAGADADQACADAFAAQALAAAAgQIAJAAQAAAHgCAFQgCAGgFADQgEADgHAAQgGAAgFgDgAgIgVQgCAGAAAJIAVAAQAAgKgCgFQgCgFgHAAQgGAAgCAFg");
  this.shape_81.setTransform(311.975, 1.875);
  this.shape_82 = new cjs.Shape();
  this.shape_82.graphics.f("#0C593C").s().p("AgUAiIAAhDIAVAAQAIAAAFAFQAFAFAAAGQAAAHgDAEQgDAEgEACIAAAAQAFAAADAFQAEADAAAIQAAAFgDAEQgCAEgDADQgFACgDAAgAgKAaIAKAAQAGgBADgCQACgDAAgGQAAgFgDgDQgCgEgGAAIgKAAgAgKgEIAKAAQAEAAADgDQACgDAAgFQAAgKgJAAIgKAAg");
  this.shape_82.setTransform(306.8, 1.85);
  this.shape_83 = new cjs.Shape();
  this.shape_83.graphics.f("#0C593C").s().p("AgEAiIAAg7IgRAAIAAgIIArAAIAAAIIgRAAIAAA7g");
  this.shape_83.setTransform(298.65, 1.85);
  this.shape_84 = new cjs.Shape();
  this.shape_84.graphics.f("#0C593C").s().p("AgMAgQgFgEgDgHQgDgIAAgNQAAgQAGgJQAGgJALAAQAYAAAAAiQAAANgDAIQgDAIgFADQgGADgHAAQgHAAgFgDgAgHgYQgDADgBAGQgCAGAAAKQAAAIACAGQABAGACADQADADAFAAQAGAAADgDQADgDABgGIABgOQAAgKgCgGQgBgGgDgDQgDgCgFAAQgEAAgDACg");
  this.shape_84.setTransform(293.35, 1.875);
  this.shape_85 = new cjs.Shape();
  this.shape_85.graphics.f("#0C593C").s().p("AgKAgQgFgEgDgHQgCgIAAgNQAAgiAUAAQAJAAAFAFQAFAFABAHQABAIAAAKIgfAAIAAAOQABAGADADQACADAFAAQALAAAAgQIAJAAQAAAHgCAFQgCAGgFADQgEADgHAAQgGAAgFgDgAgIgVQgCAGAAAJIAVAAQAAgKgCgFQgCgFgHAAQgGAAgCAFg");
  this.shape_85.setTransform(284.625, 1.875);
  this.shape_86 = new cjs.Shape();
  this.shape_86.graphics.f("#0C593C").s().p("AAMAiIAAgyIABgJIgCAJIgUAyIgMAAIAAhDIAKAAIAAAyIgCAJIADgJIAUgyIAMAAIAABDg");
  this.shape_86.setTransform(278.95, 1.85);
  this.shape_87 = new cjs.Shape();
  this.shape_87.graphics.f("#0C593C").s().p("AAKAiIAAggIgNABQgIABgEgEQgFgFABgHIAAgVIAJAAIAAATQAAAGADACQABACAGABIAKgBIAAgdIAKAAIAABDg");
  this.shape_87.setTransform(273, 1.85);
  this.shape_88 = new cjs.Shape();
  this.shape_88.graphics.f("#0C593C").s().p("AANAiIAAgyIABgJIgCAJIgWAyIgLAAIAAhDIAKAAIAAAyIgBAJIABgJIAVgyIAMAAIAABDg");
  this.shape_88.setTransform(267.1, 1.85);
  this.shape_89 = new cjs.Shape();
  this.shape_89.graphics.f("#0C593C").s().p("AgYAhIAAgIIAEABQAAAAABAAQABgBAAAAQABAAAAAAQAAgBABAAQABgCABgGIABgQIAAghIAmAAIAABCIgJAAIAAg6IgUAAIAAAaQAAAQgDAIQgDAJgJAAIgFgBg");
  this.shape_89.setTransform(260.725, 1.875);
  this.shape_90 = new cjs.Shape();
  this.shape_90.graphics.f("#0C593C").s().p("AgEAiIAAg7IgRAAIAAgIIArAAIAAAIIgRAAIAAA7g");
  this.shape_90.setTransform(255.8, 1.85);
  this.shape_91 = new cjs.Shape();
  this.shape_91.graphics.f("#0C593C").s().p("AgMAgQgFgEgDgHQgDgIAAgNQAAgQAGgJQAGgJALAAQAYAAAAAiQAAANgDAIQgDAIgFADQgGADgHAAQgHAAgFgDgAgHgYQgDADgCAGQgBAGAAAKQAAAIABAGQACAGADADQADADAEAAQAGAAADgDQADgDABgGIABgOQAAgKgCgGQgBgGgDgDQgDgCgFAAQgEAAgDACg");
  this.shape_91.setTransform(250.5, 1.875);
  this.shape_92 = new cjs.Shape();
  this.shape_92.graphics.f("#0C593C").s().p("AgTAiIAAhDIAUAAQAIAAAFAFQAFAFAAAGQAAAHgCAEQgEAEgEACIAAAAQAGAAADAFQACADAAAIQAAAFgBAEQgDAEgEADQgDACgFAAgAgKAaIAKAAQAHgBACgCQACgDAAgGQAAgFgCgDQgDgEgFAAIgLAAgAgKgEIAKAAQAFAAACgDQACgDABgFQAAgKgKAAIgKAAg");
  this.shape_92.setTransform(241.95, 1.85);
  this.shape_93 = new cjs.Shape();
  this.shape_93.graphics.f("#0C593C").s().p("AgEAJQAEgBAAgKIgEAAIAAgMIAKAAIAAAOQAAAFgDAEQgDAEgEACg");
  this.shape_93.setTransform(231.55, 5.475);
  this.shape_94 = new cjs.Shape();
  this.shape_94.graphics.f("#0C593C").s().p("AgNArQgGgFgDgHQgCgHgBgIIgBgQQAAgMACgKQACgLAGgGQAHgHAKAAQAIAAAHAEQAFAEADAGQADAHAAAIIgKAAQAAgUgQAAQgKAAgEALQgDAKAAAPIABAOIACAMQACAGADADQAEAEAFAAQAGAAADgDQADgDACgGIACgOIAKAAQgBAMgCAHQgCAIgGAEQgFAEgKAAQgIAAgGgEg");
  this.shape_94.setTransform(226.75, 0.725);
  this.shape_95 = new cjs.Shape();
  this.shape_95.graphics.f("#0C593C").s().p("AgfAtIAAgJIAEABQAFgBACgEQACgEAAgJIABgZIAAgmIAxAAIAABZIgKAAIAAhQIgdAAIAAAjIgBARIgBANQgCAIgEADQgDAFgHAAIgGgBg");
  this.shape_95.setTransform(219.2, 0.75);
  this.shape_96 = new cjs.Shape();
  this.shape_96.graphics.f("#0C593C").s().p("AgZAtIAAhZIAZAAQAMAAAHAGQAHAGAAANQAAAIgCAFQgCAFgEACQgEAEgFABQgFABgGAAIgNAAIAAAmgAgPgBIAKAAQAGAAAFgBQAFgBACgFQADgDAAgIQAAgJgFgDQgFgEgIAAIgNAAg");
  this.shape_96.setTransform(212.825, 0.7);
  this.shape_97 = new cjs.Shape();
  this.shape_97.graphics.f("#0C593C").s().p("AgWAtIAAhZIAtAAIAAAJIgjAAIAABQg");
  this.shape_97.setTransform(206.675, 0.7);
  this.shape_98 = new cjs.Shape();
  this.shape_98.graphics.f("#0C593C").s().p("AAUAiIAAg6IgRA6IgFAAIgRg6IAAA6IgJAAIAAhDIAOAAIANArIABAPIACgPIAMgrIAPAAIAABDg");
  this.shape_98.setTransform(196.575, 1.85);
  this.shape_99 = new cjs.Shape();
  this.shape_99.graphics.f("#0C593C").s().p("AAVAiIAAhDIAKAAIAABDgAgeAiIAAhDIAJAAIAAAdIAOAAQAFAAAEADQAEABACAFQADAEAAAGQAAAFgDAFQgCAEgEACQgEACgFABgAgVAaIAKAAQAHgBADgCQABgDAAgGQABgMgLAAIgLAAg");
  this.shape_99.setTransform(188.9, 1.85);
  this.shape_100 = new cjs.Shape();
  this.shape_100.graphics.f("#0C593C").s().p("AAMAiIAAggIgXAAIAAAgIgJAAIAAhDIAJAAIAAAcIAXAAIAAgcIAKAAIAABDg");
  this.shape_100.setTransform(181.95, 1.85);
  this.shape_101 = new cjs.Shape();
  this.shape_101.graphics.f("#0C593C").s().p("AAMAiIAAggIgXAAIAAAgIgKAAIAAhDIAKAAIAAAcIAXAAIAAgcIAKAAIAABDg");
  this.shape_101.setTransform(175.95, 1.85);
  this.shape_102 = new cjs.Shape();
  this.shape_102.graphics.f("#0C593C").s().p("AgWARQAAgGACgEQABgEAEgCIAKgEIAKgFQADgBAAgHQAAgGgCgCQgCgCgFAAQgFAAgDADQgCADAAAFIgIAAQAAgTATAAQAFAAAEACQAFACACAEQACAEAAAFIAAAmQAAAFADAAIACAAIAAAHIgEABQgEAAgDgCQgCgBgBgHIAAAAQgCAFgEADQgDADgFAAQgRAAAAgSgAABAAIgHAEQgDACgBADQgCADAAAEQAAAKAJAAQAFAAADgDIACgDIABgDIAAgHIAAgMIgHACg");
  this.shape_102.setTransform(170.275, 1.875);
  this.shape_103 = new cjs.Shape();
  this.shape_103.graphics.f("#0C593C").s().p("AATArIAAgSIgmAAIAAASIgJAAIAAgaIAHAAIAEgMIADgKIABgOIAAgXIAjAAIAAA7IAGAAIAAAagAgEgOQAAAKgCAFQgCAGgDAKIAYAAIAAgzIgRAAg");
  this.shape_103.setTransform(164.5, 2.75);
  this.shape_104 = new cjs.Shape();
  this.shape_104.graphics.f("#0C593C").s().p("AgMAgQgFgEgDgHQgDgIAAgNQAAgQAGgJQAGgJALAAQAYAAAAAiQAAANgDAIQgDAIgFADQgGADgHAAQgGAAgGgDgAgHgYQgDADgCAGQgBAGAAAKQAAAIABAGQACAGADADQADADAEAAQAFAAAEgDQADgDABgGIABgOQAAgKgCgGQgBgGgDgDQgDgCgFAAQgEAAgDACg");
  this.shape_104.setTransform(155.45, 1.875);
  this.shape_105 = new cjs.Shape();
  this.shape_105.graphics.f("#0C593C").s().p("AARAtIAAhQIghAAIAABQIgKAAIAAhZIA1AAIAABZg");
  this.shape_105.setTransform(148.775, 0.7);
  this.shape_106 = new cjs.Shape();
  this.shape_106.graphics.f("#0C593C").s().p("AgFAGIAAgLIAKAAIAAALg");
  this.shape_106.setTransform(849, -7.35);
  this.shape_107 = new cjs.Shape();
  this.shape_107.graphics.f("#0C593C").s().p("AgKAgQgFgEgDgHQgCgIAAgNQAAgiAUAAQAJAAAFAFQAFAFABAHQABAIAAAKIgfAAIAAAOQABAGADADQACADAFAAQALAAAAgQIAJAAQAAAHgCAFQgCAGgFADQgEADgHAAQgGAAgFgDgAgIgVQgCAGAAAJIAVAAQAAgKgCgFQgCgFgHAAQgGAAgCAFg");
  this.shape_107.setTransform(844.775, -10.075);
  this.shape_108 = new cjs.Shape();
  this.shape_108.graphics.f("#0C593C").s().p("AgEAhIAAg6IgRAAIAAgHIArAAIAAAHIgRAAIAAA6g");
  this.shape_108.setTransform(839.9, -10.1);
  this.shape_109 = new cjs.Shape();
  this.shape_109.graphics.f("#0C593C").s().p("AgWAtIAAhYIAKAAIAAAIQACgEAEgDQAEgDADABQAWgBAAAjIgBANQgBAGgDAGQgCAFgEACQgFADgGAAQgDAAgEgDQgDgBgDgFIAAAdgAgKgdQgCAIAAAMIABAMQAAAGADAEQADAEAFAAQAHAAADgHQADgHAAgNQAAgagNAAQgHAAgDAHg");
  this.shape_109.setTransform(834.725, -9.05);
  this.shape_110 = new cjs.Shape();
  this.shape_110.graphics.f("#0C593C").s().p("AgMAgQgFgEgDgHQgDgIAAgNQAAgQAGgJQAGgJALAAQAYAAAAAiQAAANgDAIQgDAIgFADQgGADgHAAQgGAAgGgDgAgHgYQgDADgBAGQgCAGAAAKQAAAIACAGQABAGACADQADADAFAAQAFAAADgDQADgDACgGIABgOQAAgKgBgGQgCgGgDgDQgDgCgFAAQgEAAgDACg");
  this.shape_110.setTransform(828.6, -10.075);
  this.shape_111 = new cjs.Shape();
  this.shape_111.graphics.f("#0C593C").s().p("AgEAtIAAgLIgCAAQgJAAgIgDQgHgEgFgIQgEgIAAgLQAAgLAEgJQAFgHAIgEQAHgDAJAAIACAAIAAgKIAJAAIAAAKIACAAQAJAAAIADQAHAEAEAHQAFAJAAALQAAALgFAIQgEAIgHAEQgIADgJAAIgCAAIAAALgAAFAZIACAAQAHAAAFgDQAFgDACgGQAEgFAAgJQgBgMgFgGQgGgHgLABIgCAAgAgSgXQgFADgDAGQgDAGAAAHQAAAJADAFQADAGAFADQAFADAHAAIACAAIAAgyIgCAAQgHAAgFACg");
  this.shape_111.setTransform(821.15, -11.25);
  this.shape_112 = new cjs.Shape();
  this.shape_112.graphics.f("#0C593C").s().p("AgKAhQgFgDgDgFQgCgFAAgIIAJAAIABAJQACADADACQACABADAAQAMAAAAgMQAAgGgDgDQgDgEgFAAIgEAAIAAgHIADAAQAFAAACgDQADgDAAgFQAAgEgDgDQgCgDgFAAQgEAAgEADQgCADAAAFIgKAAQABgFACgEQADgFAEgDQAFgCAFAAQAGAAAEACQAEACADAEQACAEAAAEQAAAHgDAEQgDAEgFACIAAAAQAFABAEADQAFAFAAAHQAAAGgDAFQgCAEgFADQgFACgHAAQgFAAgFgCg");
  this.shape_112.setTransform(811.15, -10.075);
  this.shape_113 = new cjs.Shape();
  this.shape_113.graphics.f("#0C593C").s().p("AgWARQAAgGACgEQABgEAEgCIAKgEIAKgFQADgBAAgHQAAgGgCgCQgCgCgFAAQgFAAgDADQgCADAAAFIgIAAQAAgTATAAQAFAAAEACQAFACACAEQACAEAAAFIAAAmQAAAFADAAIACAAIAAAHIgEABQgEAAgDgCQgCgBgBgHIAAAAQgCAFgEADQgDADgFAAQgRAAAAgSgAABAAIgHAEQgDACgBADQgCADAAAEQAAAKAJAAQAFAAADgDIACgDIABgDIAAgHIAAgMIgHACg");
  this.shape_113.setTransform(805.975, -10.075);
  this.shape_114 = new cjs.Shape();
  this.shape_114.graphics.f("#0C593C").s().p("AgRAhIAAhBIAjAAIAAAHIgZAAIAAA6g");
  this.shape_114.setTransform(801.475, -10.1);
  this.shape_115 = new cjs.Shape();
  this.shape_115.graphics.f("#0C593C").s().p("AgKAgQgFgEgDgHQgCgIAAgNQAAgiAUAAQAJAAAFAFQAFAFABAHQABAIAAAKIgfAAIAAAOQABAGADADQACADAFAAQALAAAAgQIAJAAQAAAHgCAFQgCAGgFADQgEADgHAAQgGAAgFgDgAgIgVQgCAGAAAJIAVAAQAAgKgCgFQgCgFgHAAQgGAAgCAFg");
  this.shape_115.setTransform(796.125, -10.075);
  this.shape_116 = new cjs.Shape();
  this.shape_116.graphics.f("#0C593C").s().p("AgYAhIAAgIIAEABQAAAAABAAQAAAAABgBQAAAAABAAQAAgBABAAQABgCABgGIABgQIAAghIAmAAIAABCIgJAAIAAg6IgUAAIAAAaQAAAQgDAIQgDAJgJAAIgFgBg");
  this.shape_116.setTransform(790.175, -10.075);
  this.shape_117 = new cjs.Shape();
  this.shape_117.graphics.f("#0C593C").s().p("AANAhIAAgxIAAgJIgBAJIgWAxIgLAAIAAhBIAJAAIAAAxIgBAIIACgIIAWgxIALAAIAABBg");
  this.shape_117.setTransform(784.45, -10.1);
  this.shape_118 = new cjs.Shape();
  this.shape_118.graphics.f("#0C593C").s().p("AgEAhIAAg6IgRAAIAAgHIArAAIAAAHIgRAAIAAA6g");
  this.shape_118.setTransform(779.15, -10.1);
  this.shape_119 = new cjs.Shape();
  this.shape_119.graphics.f("#0C593C").s().p("AgMAgQgFgEgDgHQgDgIAAgNQAAgQAGgJQAGgJALAAQAYAAAAAiQAAANgDAIQgDAIgFADQgGADgHAAQgHAAgFgDgAgHgYQgDADgCAGQgBAGAAAKQAAAIABAGQACAGADADQADADAEAAQAGAAADgDQADgDABgGIABgOQAAgKgCgGQgBgGgDgDQgDgCgFAAQgEAAgDACg");
  this.shape_119.setTransform(773.85, -10.075);
  this.shape_120 = new cjs.Shape();
  this.shape_120.graphics.f("#0C593C").s().p("AAbAtIAAhJIABgGIAAgGIgBAAIgBAHIgCAFIgSBJIgLAAIgThKIgDgLIAAAAIAAAHIAAAFIAABJIgKAAIAAhZIASAAIASBFIABAOIACgOIAShFIASAAIAABZg");
  this.shape_120.setTransform(766.175, -11.25);
  this.shape_121 = new cjs.Shape();
  this.shape_121.graphics.f("#0C593C").s().p("AgWARQAAgGACgEQABgEAEgCIAKgEIAKgFQADgBAAgHQAAgGgCgCQgCgCgFAAQgFAAgDADQgCADAAAFIgIAAQAAgTATAAQAFAAAEACQAFACACAEQACAEAAAFIAAAmQAAAFADAAIACAAIAAAHIgEABQgEAAgDgCQgCgBgBgHIAAAAQgCAFgEADQgDADgFAAQgRAAAAgSgAABAAIgHAEQgDACgBADQgCADAAAEQAAAKAJAAQAFAAADgDIACgDIABgDIAAgHIAAgMIgHACg");
  this.shape_121.setTransform(755.825, -10.075);
  this.shape_122 = new cjs.Shape();
  this.shape_122.graphics.f("#0C593C").s().p("AgEAhIAAg6IgRAAIAAgHIArAAIAAAHIgRAAIAAA6g");
  this.shape_122.setTransform(750.9, -10.1);
  this.shape_123 = new cjs.Shape();
  this.shape_123.graphics.f("#0C593C").s().p("AgWARQAAgGACgEQABgEAEgCIAKgEIAKgFQADgBAAgHQAAgGgCgCQgCgCgFAAQgFAAgDADQgCADAAAFIgIAAQAAgTATAAQAFAAAEACQAFACACAEQACAEAAAFIAAAmQAAAFADAAIACAAIAAAHIgEABQgEAAgDgCQgCgBgBgHIAAAAQgCAFgEADQgDADgFAAQgRAAAAgSgAABAAIgHAEQgDACgBADQgCADAAAEQAAAKAJAAQAFAAADgDIACgDIABgDIAAgHIAAgMIgHACg");
  this.shape_123.setTransform(745.925, -10.075);
  this.shape_124 = new cjs.Shape();
  this.shape_124.graphics.f("#0C593C").s().p("AgWAtIAAhYIAKAAIAAAIQACgEAEgDQAEgDADABQAWgBAAAjIgBANQgBAGgDAGQgCAFgEACQgFADgGAAQgDAAgEgDQgDgBgDgFIAAAdgAgKgdQgCAIAAAMIABAMQAAAGADAEQADAEAFAAQAHAAADgHQADgHAAgNQAAgagNAAQgHAAgDAHg");
  this.shape_124.setTransform(740.375, -9.05);
  this.shape_125 = new cjs.Shape();
  this.shape_125.graphics.f("#0C593C").s().p("AgWARQAAgGACgEQABgEAEgCIAKgEIAKgFQADgBAAgHQAAgGgCgCQgCgCgFAAQgFAAgDADQgCADAAAFIgIAAQAAgTATAAQAFAAAEACQAFACACAEQACAEAAAFIAAAmQAAAFADAAIACAAIAAAHIgEABQgEAAgDgCQgCgBgBgHIAAAAQgCAFgEADQgDADgFAAQgRAAAAgSgAABAAIgHAEQgDACgBADQgCADAAAEQAAAKAJAAQAFAAADgDIACgDIABgDIAAgHIAAgMIgHACg");
  this.shape_125.setTransform(734.575, -10.075);
  this.shape_126 = new cjs.Shape();
  this.shape_126.graphics.f("#0C593C").s().p("AAMAhIAAg6IgXAAIAAA6IgJAAIAAhBIAqAAIAABBg");
  this.shape_126.setTransform(728.9, -10.1);
  this.shape_127 = new cjs.Shape();
  this.shape_127.graphics.f("#0C593C").s().p("AgKAgQgFgEgDgHQgCgIAAgNQAAgiAUAAQAJAAAFAFQAFAFABAHQABAIAAAKIgfAAIAAAOQABAGADADQACADAFAAQALAAAAgQIAJAAQAAAHgCAFQgCAGgFADQgEADgHAAQgGAAgFgDgAgIgVQgCAGAAAJIAVAAQAAgKgCgFQgCgFgHAAQgGAAgCAFg");
  this.shape_127.setTransform(723.175, -10.075);
  this.shape_128 = new cjs.Shape();
  this.shape_128.graphics.f("#0C593C").s().p("AgWAtIAAhYIAKAAIAAAIQACgEAEgDQAEgDADABQAWgBAAAjIgBANQgBAGgDAGQgCAFgEACQgFADgGAAQgDAAgEgDQgDgBgDgFIAAAdgAgKgdQgCAIAAAMIABAMQAAAGADAEQADAEAFAAQAHAAADgHQADgHAAgNQAAgagNAAQgHAAgDAHg");
  this.shape_128.setTransform(717.675, -9.05);
  this.shape_129 = new cjs.Shape();
  this.shape_129.graphics.f("#0C593C").s().p("AAMAhIAAg6IgXAAIAAA6IgKAAIAAhBIArAAIAABBg");
  this.shape_129.setTransform(711.55, -10.1);
  this.shape_130 = new cjs.Shape();
  this.shape_130.graphics.f("#0C593C").s().p("AgGAbQgGgHAAgSIgMAAIAAAfIgJAAIAAhCIAJAAIAAAcIAMAAQgBgNAHgIQAGgIAKAAQAMAAAHAIQAFAJAAAQQAAANgCAIQgEAIgFAEQgFADgIAAQgKAAgGgIgAADgYQgDADgBAGQgBAHgBAJQAAAMADAHQADAHAHAAQAIAAAEgHQACgGAAgNQABgOgEgHQgDgGgIAAQgEAAgDACg");
  this.shape_130.setTransform(701.55, -10.075);
  this.shape_131 = new cjs.Shape();
  this.shape_131.graphics.f("#0C593C").s().p("AANAhIAAgxIABgJIgCAJIgWAxIgLAAIAAhBIAKAAIAAAxIgBAIIABgIIAVgxIAMAAIAABBg");
  this.shape_131.setTransform(694.15, -10.1);
  this.shape_132 = new cjs.Shape();
  this.shape_132.graphics.f("#0C593C").s().p("AAMAhIAAgeIgXAAIAAAeIgJAAIAAhBIAJAAIAAAcIAXAAIAAgcIAJAAIAABBg");
  this.shape_132.setTransform(688.1, -10.1);
  this.shape_133 = new cjs.Shape();
  this.shape_133.graphics.f("#0C593C").s().p("AgKAgQgFgEgDgHQgCgIAAgNQAAgiAUAAQAJAAAFAFQAFAFABAHQABAIAAAKIgfAAIAAAOQABAGADADQACADAFAAQALAAAAgQIAJAAQAAAHgCAFQgCAGgFADQgEADgHAAQgGAAgFgDgAgIgVQgCAGAAAJIAVAAQAAgKgCgFQgCgFgHAAQgGAAgCAFg");
  this.shape_133.setTransform(682.375, -10.075);
  this.shape_134 = new cjs.Shape();
  this.shape_134.graphics.f("#0C593C").s().p("AAMAhIAAgeIgXAAIAAAeIgJAAIAAhBIAJAAIAAAcIAXAAIAAgcIAJAAIAABBg");
  this.shape_134.setTransform(676.75, -10.1);
  this.shape_135 = new cjs.Shape();
  this.shape_135.graphics.f("#0C593C").s().p("AgKAgQgFgEgDgHQgCgIAAgNQAAgiAUAAQAJAAAFAFQAFAFABAHQABAIAAAKIgfAAIAAAOQABAGADADQACADAFAAQALAAAAgQIAJAAQAAAHgCAFQgCAGgFADQgEADgHAAQgGAAgFgDgAgIgVQgCAGAAAJIAVAAQAAgKgCgFQgCgFgHAAQgGAAgCAFg");
  this.shape_135.setTransform(671.025, -10.075);
  this.shape_136 = new cjs.Shape();
  this.shape_136.graphics.f("#0C593C").s().p("AAUAhIAAg5IgRA5IgFAAIgRg5IAAA5IgJAAIAAhBIAOAAIANAqIABAOIACgOIAMgqIAPAAIAABBg");
  this.shape_136.setTransform(664.625, -10.1);
  this.shape_137 = new cjs.Shape();
  this.shape_137.graphics.f("#0C593C").s().p("AANAhIAAgxIABgJIgCAJIgWAxIgLAAIAAhBIAJAAIAAAxIAAAIIABgIIAWgxIALAAIAABBg");
  this.shape_137.setTransform(657.8, -10.1);
  this.shape_138 = new cjs.Shape();
  this.shape_138.graphics.f("#0C593C").s().p("AgWAtIAAhYIAKAAIAAAIQACgEAEgDQAEgDADABQAWgBAAAjIgBANQgBAGgDAGQgCAFgEACQgFADgGAAQgDAAgEgDQgDgBgDgFIAAAdgAgKgdQgCAIAAAMIABAMQAAAGADAEQADAEAFAAQAHAAADgHQADgHAAgNQAAgagNAAQgHAAgDAHg");
  this.shape_138.setTransform(651.875, -9.05);
  this.shape_139 = new cjs.Shape();
  this.shape_139.graphics.f("#0C593C").s().p("AAMAhIAAg6IgXAAIAAA6IgKAAIAAhBIArAAIAABBg");
  this.shape_139.setTransform(645.75, -10.1);
  this.shape_140 = new cjs.Shape();
  this.shape_140.graphics.f("#0C593C").s().p("AgWAsIAAgJQADACAEAAQAFAAACgDQADgEACgHIgVhDIAKAAIAOA0IABAAIAOg0IAKAAIgUBDIgFAMQgBAEgEADQgEADgGAAIgHgBg");
  this.shape_140.setTransform(636.975, -8.95);
  this.shape_141 = new cjs.Shape();
  this.shape_141.graphics.f("#0C593C").s().p("AAUAhIAAg5IgRA5IgFAAIgRg5IAAA5IgJAAIAAhBIAOAAIANAqIABAOIACgOIAMgqIAPAAIAABBg");
  this.shape_141.setTransform(630.625, -10.1);
  this.shape_142 = new cjs.Shape();
  this.shape_142.graphics.f("#0C593C").s().p("AgMAgQgFgEgDgHQgDgIAAgNQAAgQAGgJQAGgJALAAQAYAAAAAiQAAANgDAIQgDAIgFADQgGADgHAAQgGAAgGgDgAgHgYQgDADgBAGQgCAGAAAKQAAAIACAGQABAGACADQADADAFAAQAFAAADgDQADgDACgGIABgOQAAgKgBgGQgCgGgDgDQgDgCgFAAQgEAAgDACg");
  this.shape_142.setTransform(623.85, -10.075);
  this.shape_143 = new cjs.Shape();
  this.shape_143.graphics.f("#0C593C").s().p("AALAhIgPghIgHAKIAAAXIgKAAIAAhBIAKAAIAAAfIAVgfIAMAAIgVAZIAWAog");
  this.shape_143.setTransform(618.55, -10.1);
  this.shape_144 = new cjs.Shape();
  this.shape_144.graphics.f("#0C593C").s().p("AgMAeQgFgEgCgIQgCgHAAgKQAAgjAXAAQAJAAAGAGQAFAHAAAJIgJAAQAAgOgLAAQgHAAgDAHQgDAIAAAMQAAALADAIQACAHAHAAQAHAAACgEQACgFABgIIAJAAQAAALgFAHQgFAHgKAAQgJAAgFgFg");
  this.shape_144.setTransform(612.825, -10.075);
  this.shape_145 = new cjs.Shape();
  this.shape_145.graphics.f("#0C593C").s().p("AAMAhIAAgeIgXAAIAAAeIgKAAIAAhBIAKAAIAAAcIAXAAIAAgcIAJAAIAABBg");
  this.shape_145.setTransform(607.15, -10.1);
  this.shape_146 = new cjs.Shape();
  this.shape_146.graphics.f("#0C593C").s().p("AANAhIAAgxIABgJIgCAJIgWAxIgLAAIAAhBIAJAAIAAAxIAAAIIABgIIAWgxIALAAIAABBg");
  this.shape_146.setTransform(601.1, -10.1);
  this.shape_147 = new cjs.Shape();
  this.shape_147.graphics.f("#0C593C").s().p("AAQAqIAAgSIgoAAIAAhBIAKAAIAAA5IAXAAIAAg5IAJAAIAAA5IAHAAIAAAag");
  this.shape_147.setTransform(595.225, -9.2);
  this.shape_148 = new cjs.Shape();
  this.shape_148.graphics.f("#0C593C").s().p("AANAhIAAgxIABgJIgCAJIgWAxIgLAAIAAhBIAKAAIAAAxIgBAIIACgIIAUgxIAMAAIAABBg");
  this.shape_148.setTransform(588.85, -10.1);
  this.shape_149 = new cjs.Shape();
  this.shape_149.graphics.f("#0C593C").s().p("AATAqIAAgSIglAAIAAASIgJAAIAAgaIAFAAIAGgLIABgKIABgOIAAgWIAkAAIAAA5IAGAAIAAAagAgFgOQAAAJgBAGQgBAGgEAJIAXAAIAAgyIgRAAg");
  this.shape_149.setTransform(582.7, -9.2);
  this.shape_150 = new cjs.Shape();
  this.shape_150.graphics.f("#0C593C").s().p("AgKAgQgFgEgDgHQgCgIAAgNQAAgiAUAAQAJAAAFAFQAFAFABAHQABAIAAAKIgfAAIAAAOQABAGADADQACADAFAAQALAAAAgQIAJAAQAAAHgCAFQgCAGgFADQgEADgHAAQgGAAgFgDgAgIgVQgCAGAAAJIAVAAQAAgKgCgFQgCgFgHAAQgGAAgCAFg");
  this.shape_150.setTransform(576.925, -10.075);
  this.shape_151 = new cjs.Shape();
  this.shape_151.graphics.f("#0C593C").s().p("AAUAhIAAg5IgRA5IgFAAIgRg5IAAA5IgJAAIAAhBIAOAAIANAqIABAOIACgOIAMgqIAPAAIAABBg");
  this.shape_151.setTransform(570.525, -10.1);
  this.shape_152 = new cjs.Shape();
  this.shape_152.graphics.f("#0C593C").s().p("AgMAgQgFgEgDgHQgDgIAAgNQAAgQAGgJQAGgJALAAQAYAAAAAiQAAANgDAIQgDAIgFADQgFADgIAAQgHAAgFgDgAgHgYQgDADgBAGQgCAGAAAKQAAAIACAGQABAGACADQADADAFAAQAGAAACgDQADgDACgGIABgOQAAgKgCgGQgBgGgDgDQgDgCgFAAQgEAAgDACg");
  this.shape_152.setTransform(560.75, -10.075);
  this.shape_153 = new cjs.Shape();
  this.shape_153.graphics.f("#0C593C").s().p("AAMAhIAAg6IgXAAIAAA6IgKAAIAAhBIArAAIAABBg");
  this.shape_153.setTransform(554.75, -10.1);
  this.shape_154 = new cjs.Shape();
  this.shape_154.graphics.f("#0C593C").s().p("AAMAhIAAgxIABgJIgCAJIgUAxIgMAAIAAhBIAJAAIAAAxIgBAIIADgIIAUgxIAMAAIAABBg");
  this.shape_154.setTransform(545.7, -10.1);
  this.shape_155 = new cjs.Shape();
  this.shape_155.graphics.f("#0C593C").s().p("AAMAhIAAgxIACgJIgDAJIgUAxIgMAAIAAhBIAKAAIAAAxIgBAIIACgIIAUgxIAMAAIAABBg");
  this.shape_155.setTransform(539.6, -10.1);
  this.shape_156 = new cjs.Shape();
  this.shape_156.graphics.f("#0C593C").s().p("AAQAqIAAgSIgoAAIAAhBIAKAAIAAA5IAXAAIAAg5IAJAAIAAA5IAHAAIAAAag");
  this.shape_156.setTransform(533.725, -9.2);
  this.shape_157 = new cjs.Shape();
  this.shape_157.graphics.f("#0C593C").s().p("AALAhIgPghIgHAKIAAAXIgKAAIAAhBIAKAAIAAAfIAVgfIAMAAIgVAZIAWAog");
  this.shape_157.setTransform(528.1, -10.1);
  this.shape_158 = new cjs.Shape();
  this.shape_158.graphics.f("#0C593C").s().p("AgWAsIAAgJQADACAEAAQAFAAACgDQADgEACgHIgVhDIAKAAIAOA0IABAAIAOg0IAKAAIgUBDIgFAMQgBAEgEADQgEADgGAAIgHgBg");
  this.shape_158.setTransform(522.275, -8.95);
  this.shape_159 = new cjs.Shape();
  this.shape_159.graphics.f("#0C593C").s().p("AgWAtIAAhYIAKAAIAAAIQACgEAEgDQAEgDADABQAWgBAAAjIgBANQgBAGgDAGQgCAFgEACQgFADgGAAQgDAAgEgDQgDgBgDgFIAAAdgAgKgdQgCAIAAAMIABAMQAAAGADAEQADAEAFAAQAHAAADgHQADgHAAgNQAAgagNAAQgHAAgDAHg");
  this.shape_159.setTransform(516.825, -9.05);
  this.shape_160 = new cjs.Shape();
  this.shape_160.graphics.f("#0C593C").s().p("AgEAhIAAg6IgRAAIAAgHIArAAIAAAHIgRAAIAAA6g");
  this.shape_160.setTransform(511.45, -10.1);
  this.shape_161 = new cjs.Shape();
  this.shape_161.graphics.f("#0C593C").s().p("AgMAeQgFgEgCgIQgCgHAAgKQAAgjAXAAQAJAAAGAGQAFAHAAAJIgJAAQAAgOgLAAQgHAAgDAHQgDAIAAAMQAAALADAIQACAHAHAAQAHAAACgEQACgFABgIIAJAAQAAALgFAHQgFAHgKAAQgJAAgFgFg");
  this.shape_161.setTransform(506.475, -10.075);
  this.shape_162 = new cjs.Shape();
  this.shape_162.graphics.f("#0C593C").s().p("AAMAhIAAgeIgXAAIAAAeIgJAAIAAhBIAJAAIAAAcIAXAAIAAgcIAJAAIAABBg");
  this.shape_162.setTransform(500.8, -10.1);
  this.shape_163 = new cjs.Shape();
  this.shape_163.graphics.f("#0C593C").s().p("AAMAhIAAgxIABgJIgCAJIgUAxIgMAAIAAhBIAJAAIAAAxIgBAIIACgIIAWgxIALAAIAABBg");
  this.shape_163.setTransform(494.75, -10.1);
  this.shape_164 = new cjs.Shape();
  this.shape_164.graphics.f("#0C593C").s().p("AAMAhIAAgxIABgJIgBAJIgWAxIgLAAIAAhBIAJAAIAAAxIgBAIIACgIIAWgxIALAAIAABBg");
  this.shape_164.setTransform(485.65, -10.1);
  this.shape_165 = new cjs.Shape();
  this.shape_165.graphics.f("#0C593C").s().p("AAUAhIAAg5IgRA5IgFAAIgRg5IAAA5IgJAAIAAhBIAOAAIANAqIABAOIACgOIAMgqIAPAAIAABBg");
  this.shape_165.setTransform(478.825, -10.1);
  this.shape_166 = new cjs.Shape();
  this.shape_166.graphics.f("#0C593C").s().p("AAVAhIAAhBIAKAAIAABBgAgeAhIAAhBIAJAAIAAAcIAOAAQAGAAADACQAEACACAFQADAEAAAGQAAAFgDAEQgCAFgEACQgDACgGAAgAgVAZIAKAAQAHABADgDQACgDAAgGQAAgMgLABIgLAAg");
  this.shape_166.setTransform(471.15, -10.1);
  this.shape_167 = new cjs.Shape();
  this.shape_167.graphics.f("#0C593C").s().p("AAMAhIAAgeIgXAAIAAAeIgJAAIAAhBIAJAAIAAAcIAXAAIAAgcIAKAAIAABBg");
  this.shape_167.setTransform(464.2, -10.1);
  this.shape_168 = new cjs.Shape();
  this.shape_168.graphics.f("#0C593C").s().p("AAMAhIAAgeIgXAAIAAAeIgKAAIAAhBIAKAAIAAAcIAXAAIAAgcIAKAAIAABBg");
  this.shape_168.setTransform(458.2, -10.1);
  this.shape_169 = new cjs.Shape();
  this.shape_169.graphics.f("#0C593C").s().p("AgWARQAAgGACgEQABgEAEgCIAKgEIAKgFQADgBAAgHQAAgGgCgCQgCgCgFAAQgFAAgDADQgCADAAAFIgIAAQAAgTATAAQAFAAAEACQAFACACAEQACAEAAAFIAAAmQAAAFADAAIACAAIAAAHIgEABQgEAAgDgCQgCgBgBgHIAAAAQgCAFgEADQgDADgFAAQgRAAAAgSgAABAAIgHAEQgDACgBADQgCADAAAEQAAAKAJAAQAFAAADgDIACgDIABgDIAAgHIAAgMIgHACg");
  this.shape_169.setTransform(452.525, -10.075);
  this.shape_170 = new cjs.Shape();
  this.shape_170.graphics.f("#0C593C").s().p("AAUAqIAAgSIgnAAIAAASIgJAAIAAgaIAHAAIAEgLIADgKIABgOIAAgWIAjAAIAAA5IAHAAIAAAagAgEgOQgBAJgBAGQgCAGgEAJIAZAAIAAgyIgRAAg");
  this.shape_170.setTransform(446.75, -9.2);
  this.shape_171 = new cjs.Shape();
  this.shape_171.graphics.f("#0C593C").s().p("AgMAeQgFgEgCgIQgCgHAAgKQAAgjAXAAQAJAAAGAGQAFAHAAAJIgJAAQAAgOgLAAQgHAAgDAHQgDAIAAAMQAAALADAIQACAHAHAAQAHAAACgEQACgFABgIIAJAAQAAALgFAHQgFAHgKAAQgJAAgFgFg");
  this.shape_171.setTransform(438.025, -10.075);
  this.shape_172 = new cjs.Shape();
  this.shape_172.graphics.f("#0C593C").s().p("AANAhIAAgxIAAgJIgBAJIgWAxIgLAAIAAhBIAJAAIAAAxIgBAIIACgIIAWgxIALAAIAABBg");
  this.shape_172.setTransform(429.3, -10.1);
  this.shape_173 = new cjs.Shape();
  this.shape_173.graphics.f("#0C593C").s().p("AAMAhIAAgxIABgJIgBAJIgVAxIgMAAIAAhBIAJAAIAAAxIgBAIIACgIIAWgxIALAAIAABBg");
  this.shape_173.setTransform(423.2, -10.1);
  this.shape_174 = new cjs.Shape();
  this.shape_174.graphics.f("#0C593C").s().p("AgUAhIAAhBIAVAAQAIgBAFAFQAFAFAAAGQAAAHgDAEQgDAEgEABIAAABQAFAAADAFQAEADAAAHQAAAGgCAEQgDAEgDADQgEABgFAAgAgKAZIAKAAQAGABADgDQACgDAAgGQAAgFgDgDQgDgDgEAAIgLAAgAgKgEIAKAAQAEAAADgDQADgDAAgFQAAgKgKAAIgKAAg");
  this.shape_174.setTransform(417.6, -10.1);
  this.shape_175 = new cjs.Shape();
  this.shape_175.graphics.f("#0C593C").s().p("AgEAhIAAg6IgRAAIAAgHIArAAIAAAHIgRAAIAAA6g");
  this.shape_175.setTransform(412.45, -10.1);
  this.shape_176 = new cjs.Shape();
  this.shape_176.graphics.f("#0C593C").s().p("AgMAeQgFgEgCgIQgCgHAAgKQAAgjAXAAQAJAAAGAGQAFAHAAAJIgJAAQAAgOgLAAQgHAAgDAHQgDAIAAAMQAAALADAIQACAHAHAAQAHAAACgEQACgFABgIIAJAAQAAALgFAHQgFAHgKAAQgJAAgFgFg");
  this.shape_176.setTransform(407.475, -10.075);
  this.shape_177 = new cjs.Shape();
  this.shape_177.graphics.f("#0C593C").s().p("AgEAhIAAg6IgRAAIAAgHIArAAIAAAHIgRAAIAAA6g");
  this.shape_177.setTransform(402.55, -10.1);
  this.shape_178 = new cjs.Shape();
  this.shape_178.graphics.f("#0C593C").s().p("AgKAgQgFgEgDgHQgCgIAAgNQAAgiAUAAQAJAAAFAFQAFAFABAHQABAIAAAKIgfAAIAAAOQABAGADADQACADAFAAQALAAAAgQIAJAAQAAAHgCAFQgCAGgFADQgEADgHAAQgGAAgFgDgAgIgVQgCAGAAAJIAVAAQAAgKgCgFQgCgFgHAAQgGAAgCAFg");
  this.shape_178.setTransform(397.525, -10.075);
  this.shape_179 = new cjs.Shape();
  this.shape_179.graphics.f("#0C593C").s().p("AgTAhIAAhBIAUAAQAIgBAFAFQAFAFAAAGQAAAHgCAEQgDAEgFABIAAABQAGAAADAFQACADAAAHQAAAGgCAEQgCAEgEADQgDABgFAAgAgKAZIAKAAQAHABACgDQACgDAAgGQAAgFgCgDQgEgDgFAAIgKAAgAgKgEIAKAAQAFAAACgDQACgDAAgFQABgKgKAAIgKAAg");
  this.shape_179.setTransform(392.35, -10.1);
  this.shape_180 = new cjs.Shape();
  this.shape_180.graphics.f("#0C593C").s().p("AgEAhIAAg6IgRAAIAAgHIArAAIAAAHIgRAAIAAA6g");
  this.shape_180.setTransform(387.2, -10.1);
  this.shape_181 = new cjs.Shape();
  this.shape_181.graphics.f("#0C593C").s().p("AgMAgQgFgEgDgHQgDgIAAgNQAAgQAGgJQAGgJALAAQAYAAAAAiQAAANgDAIQgDAIgFADQgGADgHAAQgGAAgGgDgAgHgYQgDADgCAGQgBAGAAAKQAAAIABAGQACAGADADQADADAEAAQAGAAADgDQADgDABgGIABgOQAAgKgCgGQgBgGgDgDQgDgCgFAAQgEAAgDACg");
  this.shape_181.setTransform(381.9, -10.075);
  this.shape_182 = new cjs.Shape();
  this.shape_182.graphics.f("#0C593C").s().p("AgMAgQgFgEgDgHQgDgIAAgNQAAgQAGgJQAGgJALAAQAYAAAAAiQAAANgDAIQgCAIgGADQgGADgHAAQgGAAgGgDgAgHgYQgDADgBAGQgCAGAAAKQAAAIACAGQABAGACADQADADAFAAQAFAAADgDQADgDACgGIABgOQAAgKgBgGQgCgGgDgDQgDgCgFAAQgEAAgDACg");
  this.shape_182.setTransform(375.9, -10.075);
  this.shape_183 = new cjs.Shape();
  this.shape_183.graphics.f("#0C593C").s().p("AgMAeQgFgEgCgIQgCgHAAgKQAAgjAXAAQAJAAAGAGQAFAHAAAJIgJAAQAAgOgLAAQgHAAgDAHQgDAIAAAMQAAALADAIQACAHAHAAQAHAAACgEQACgFABgIIAJAAQAAALgFAHQgFAHgKAAQgJAAgFgFg");
  this.shape_183.setTransform(370.225, -10.075);
  this.shape_184 = new cjs.Shape();
  this.shape_184.graphics.f("#0C593C").s().p("AgUAhIAAhBIAVAAQAIgBAFAFQAFAFAAAGQAAAHgCAEQgDAEgFABIAAABQAFAAAEAFQACADAAAHQAAAGgBAEQgDAEgEADQgDABgFAAgAgKAZIAKAAQAHABACgDQACgDAAgGQAAgFgCgDQgEgDgEAAIgLAAgAgKgEIAKAAQAFAAACgDQACgDABgFQgBgKgJAAIgKAAg");
  this.shape_184.setTransform(362, -10.1);
  this.shape_185 = new cjs.Shape();
  this.shape_185.graphics.f("#0C593C").s().p("AgEAhIAAgMIAJAAIAAAMgAgEgUIAAgMIAJAAIAAAMg");
  this.shape_185.setTransform(354.6, -10.025);
  this.shape_186 = new cjs.Shape();
  this.shape_186.graphics.f("#0C593C").s().p("AgWARQAAgGACgEQABgEAEgCIAKgEIAKgFQADgBAAgHQAAgGgCgCQgCgCgFAAQgFAAgDADQgCADAAAFIgIAAQAAgTATAAQAFAAAEACQAFACACAEQACAEAAAFIAAAmQAAAFADAAIACAAIAAAHIgEABQgEAAgDgCQgCgBgBgHIAAAAQgCAFgEADQgDADgFAAQgRAAAAgSgAABAAIgHAEQgDACgBADQgCADAAAEQAAAKAJAAQAFAAADgDIACgDIABgDIAAgHIAAgMIgHACg");
  this.shape_186.setTransform(350.425, -10.075);
  this.shape_187 = new cjs.Shape();
  this.shape_187.graphics.f("#0C593C").s().p("AgTAhIAAhBIAUAAQAIgBAFAFQAFAFAAAGQAAAHgCAEQgDAEgFABIAAABQAGAAACAFQADADAAAHQAAAGgCAEQgCAEgEADQgEABgDAAgAgKAZIAKAAQAGABADgDQACgDAAgGQAAgFgDgDQgDgDgFAAIgKAAgAgKgEIAKAAQAFAAACgDQACgDAAgFQABgKgKAAIgKAAg");
  this.shape_187.setTransform(345.2, -10.1);
  this.shape_188 = new cjs.Shape();
  this.shape_188.graphics.f("#0C593C").s().p("AgEAhIAAg6IgRAAIAAgHIArAAIAAAHIgRAAIAAA6g");
  this.shape_188.setTransform(340.05, -10.1);
  this.shape_189 = new cjs.Shape();
  this.shape_189.graphics.f("#0C593C").s().p("AgMAeQgFgEgCgIQgCgHAAgKQAAgjAXAAQAJAAAGAGQAFAHAAAJIgJAAQAAgOgLAAQgHAAgDAHQgDAIAAAMQAAALADAIQACAHAHAAQAHAAACgEQACgFABgIIAJAAQAAALgFAHQgFAHgKAAQgJAAgFgFg");
  this.shape_189.setTransform(335.075, -10.075);
  this.shape_190 = new cjs.Shape();
  this.shape_190.graphics.f("#0C593C").s().p("AAUAqIAAgSIgnAAIAAASIgJAAIAAgaIAHAAIAEgLIADgKIABgOIAAgWIAjAAIAAA5IAHAAIAAAagAgEgOQgBAJgBAGQgCAGgEAJIAZAAIAAgyIgRAAg");
  this.shape_190.setTransform(329.3, -9.2);
  this.shape_191 = new cjs.Shape();
  this.shape_191.graphics.f("#0C593C").s().p("AgKAgQgFgEgDgHQgCgIAAgNQAAgiAUAAQAJAAAFAFQAFAFABAHQABAIAAAKIgfAAIAAAOQABAGADADQACADAFAAQALAAAAgQIAJAAQAAAHgCAFQgCAGgFADQgEADgHAAQgGAAgFgDgAgIgVQgCAGAAAJIAVAAQAAgKgCgFQgCgFgHAAQgGAAgCAFg");
  this.shape_191.setTransform(323.525, -10.075);
  this.shape_192 = new cjs.Shape();
  this.shape_192.graphics.f("#0C593C").s().p("AgWAtIAAhYIAKAAIAAAIQACgEAEgDQAEgDADABQAWgBAAAjIgBANQgBAGgDAGQgCAFgEACQgFADgGAAQgDAAgEgDQgDgBgDgFIAAAdgAgKgdQgCAIAAAMIABAMQAAAGADAEQADAEAFAAQAHAAADgHQADgHAAgNQAAgagNAAQgHAAgDAHg");
  this.shape_192.setTransform(318.025, -9.05);
  this.shape_193 = new cjs.Shape();
  this.shape_193.graphics.f("#0C593C").s().p("AgMAeQgFgEgCgIQgCgHAAgKQAAgjAXAAQAJAAAGAGQAFAHAAAJIgJAAQAAgOgLAAQgHAAgDAHQgDAIAAAMQAAALADAIQACAHAHAAQAHAAACgEQACgFABgIIAJAAQAAALgFAHQgFAHgKAAQgJAAgFgFg");
  this.shape_193.setTransform(312.225, -10.075);
  this.shape_194 = new cjs.Shape();
  this.shape_194.graphics.f("#0C593C").s().p("AgMAgQgFgEgDgHQgDgIAAgNQAAgQAGgJQAGgJALAAQAYAAAAAiQAAANgDAIQgCAIgGADQgGADgHAAQgGAAgGgDgAgHgYQgDADgBAGQgCAGAAAKQAAAIACAGQAAAGADADQAEADAEAAQAFAAADgDQADgDACgGIABgOQAAgKgBgGQgCgGgDgDQgDgCgFAAQgEAAgDACg");
  this.shape_194.setTransform(303.55, -10.075);
  this.shape_195 = new cjs.Shape();
  this.shape_195.graphics.f("#0C593C").s().p("AgRAhIAAhBIAjAAIAAAHIgZAAIAAA6g");
  this.shape_195.setTransform(298.725, -10.1);
  this.shape_196 = new cjs.Shape();
  this.shape_196.graphics.f("#0C593C").s().p("AgMAgQgFgEgDgHQgDgIAAgNQAAgQAGgJQAGgJALAAQAYAAAAAiQAAANgDAIQgCAIgGADQgGADgHAAQgGAAgGgDgAgHgYQgDADgBAGQgCAGAAAKQAAAIACAGQABAGACADQADADAFAAQAFAAADgDQADgDACgGIABgOQAAgKgBgGQgCgGgDgDQgDgCgFAAQgEAAgDACg");
  this.shape_196.setTransform(293.1, -10.075);
  this.shape_197 = new cjs.Shape();
  this.shape_197.graphics.f("#0C593C").s().p("AAMAhIAAgeIgXAAIAAAeIgKAAIAAhBIAKAAIAAAcIAXAAIAAgcIAKAAIAABBg");
  this.shape_197.setTransform(287.1, -10.1);
  this.shape_198 = new cjs.Shape();
  this.shape_198.graphics.f("#0C593C").s().p("AAKAhIAAgeIgMABQgJAAgEgEQgFgFABgHIAAgUIAJAAIAAATQAAAFADADQABACAGAAIAKgBIAAgcIAKAAIAABBg");
  this.shape_198.setTransform(281.2, -10.1);
  this.shape_199 = new cjs.Shape();
  this.shape_199.graphics.f("#0C593C").s().p("AAVAhIAAhBIAKAAIAABBgAgeAhIAAhBIAKAAIAAAcIANAAQAGAAACACQAFACACAFQACAEAAAGQAAAFgCAEQgDAFgEACQgCACgGAAgAgUAZIAKAAQAGABADgDQABgDAAgGQAAgMgKABIgKAAg");
  this.shape_199.setTransform(274.45, -10.1);
  this.shape_200 = new cjs.Shape();
  this.shape_200.graphics.f("#0C593C").s().p("AgNApQgFgEgDgIQgCgKAAgNQAAgKACgIQABgHACgGQAEgFADgDQAEgEAFgBIAKgDQAEgCABgCIAIAAQgCAGgEAEQgFADgIABQgHACgEAGQgEAFAAAIQAFgKAKAAQAGAAAGAEQAEADADAIQADAGAAAKQAAAMgCAHQgDAIgFAEQgGAEgIAAQgIAAgFgFgAgKgFQgDAFAAALQAAAIABAHQACAFADADQADAEAEAAQAHAAAEgHQADgHAAgNQAAgLgDgFQgEgHgHAAQgGAAgEAHg");
  this.shape_200.setTransform(267.65, -11.15);
  this.shape_201 = new cjs.Shape();
  this.shape_201.graphics.f("#0C593C").s().p("AgMAgQgFgEgDgHQgDgIAAgNQAAgQAGgJQAGgJALAAQAYAAAAAiQAAANgDAIQgCAIgGADQgFADgIAAQgHAAgFgDgAgHgYQgDADgCAGQgBAGAAAKQAAAIABAGQABAGAEADQADADAEAAQAFAAADgDQAEgDABgGIABgOQAAgKgBgGQgCgGgDgDQgDgCgFAAQgEAAgDACg");
  this.shape_201.setTransform(261.9, -10.075);
  this.shape_202 = new cjs.Shape();
  this.shape_202.graphics.f("#0C593C").s().p("AgYAhIAAgIIAEABQAAAAABAAQABAAAAgBQAAAAABAAQAAgBABAAQABgCABgGIABgQIAAghIAmAAIAABCIgJAAIAAg6IgUAAIAAAaQAAAQgDAIQgDAJgJAAIgFgBg");
  this.shape_202.setTransform(252.575, -10.075);
  this.shape_203 = new cjs.Shape();
  this.shape_203.graphics.f("#0C593C").s().p("AgWAsIAAgJQADACAEAAQAFAAACgDQADgEACgHIgVhDIAKAAIAOA0IABAAIAOg0IAKAAIgUBDIgFAMQgBAEgEADQgEADgGAAIgHgBg");
  this.shape_203.setTransform(247.125, -8.95);
  this.shape_204 = new cjs.Shape();
  this.shape_204.graphics.f("#0C593C").s().p("AgMAeQgFgEgCgIQgCgHAAgKQAAgjAXAAQAJAAAGAGQAFAHAAAJIgJAAQAAgOgLAAQgHAAgDAHQgDAIAAAMQAAALADAIQACAHAHAAQAHAAACgEQACgFABgIIAJAAQAAALgFAHQgFAHgKAAQgJAAgFgFg");
  this.shape_204.setTransform(241.875, -10.075);
  this.shape_205 = new cjs.Shape();
  this.shape_205.graphics.f("#0C593C").s().p("AAMAhIAAg6IgXAAIAAA6IgJAAIAAhBIApAAIAABBg");
  this.shape_205.setTransform(236.2, -10.1);
  this.shape_206 = new cjs.Shape();
  this.shape_206.graphics.f("#0C593C").s().p("AgWARQAAgGACgEQABgEAEgCIAKgEIAKgFQADgBAAgHQAAgGgCgCQgCgCgFAAQgFAAgDADQgCADAAAFIgIAAQAAgTATAAQAFAAAEACQAFACACAEQACAEAAAFIAAAmQAAAFADAAIACAAIAAAHIgEABQgEAAgDgCQgCgBgBgHIAAAAQgCAFgEADQgDADgFAAQgRAAAAgSgAABAAIgHAEQgDACgBADQgCADAAAEQAAAKAJAAQAFAAADgDIACgDIABgDIAAgHIAAgMIgHACg");
  this.shape_206.setTransform(230.525, -10.075);
  this.shape_207 = new cjs.Shape();
  this.shape_207.graphics.f("#0C593C").s().p("AALAhIgQghIgHAKIAAAXIgKAAIAAhBIAKAAIAAAfIAXgfIAKAAIgUAZIAVAog");
  this.shape_207.setTransform(225.55, -10.1);
  this.shape_208 = new cjs.Shape();
  this.shape_208.graphics.f("#0C593C").s().p("AgXAtQAAgJACgFQABgGAFgGIAOgOQAGgFAEgFQAEgHAAgHQAAgQgNAAQgHAAgDAFQgCAGAAALIgKAAIAAgFQAAgHACgGQADgGAFgDQAGgEAGAAQAIAAAFADQAFADADAGQADAGAAAHQAAAGgCAGQgCAFgEADIgJAJIgMAMIgFAHIgCAHIAkAAIAAAJg");
  this.shape_208.setTransform(216.425, -11.25);
  this.shape_209 = new cjs.Shape();
  this.shape_209.graphics.f("#0C593C").s().p("AgMAgQgFgEgDgHQgDgIAAgNQAAgQAGgJQAGgJALAAQAYAAAAAiQAAANgDAIQgDAIgFADQgFADgIAAQgGAAgGgDgAgHgYQgDADgBAGQgCAGAAAKQAAAIACAGQABAGACADQADADAFAAQAGAAACgDQADgDACgGIABgOQAAgKgCgGQgBgGgDgDQgDgCgFAAQgEAAgDACg");
  this.shape_209.setTransform(207.5, -10.075);
  this.shape_210 = new cjs.Shape();
  this.shape_210.graphics.f("#0C593C").s().p("AgEAhIAAg6IgRAAIAAgHIArAAIAAAHIgRAAIAAA6g");
  this.shape_210.setTransform(202.25, -10.1);
  this.shape_211 = new cjs.Shape();
  this.shape_211.graphics.f("#0C593C").s().p("AgMAeQgFgEgCgIQgCgHAAgKQAAgjAXAAQAJAAAGAGQAFAHAAAJIgJAAQAAgOgLAAQgHAAgDAHQgDAIAAAMQAAALADAIQACAHAHAAQAHAAACgEQACgFABgIIAJAAQAAALgFAHQgFAHgKAAQgJAAgFgFg");
  this.shape_211.setTransform(197.275, -10.075);
  this.shape_212 = new cjs.Shape();
  this.shape_212.graphics.f("#0C593C").s().p("AgKAgQgFgEgDgHQgCgIAAgNQAAgiAUAAQAJAAAFAFQAFAFABAHQABAIAAAKIgfAAIAAAOQABAGADADQACADAFAAQALAAAAgQIAJAAQAAAHgCAFQgCAGgFADQgEADgHAAQgGAAgFgDgAgIgVQgCAGAAAJIAVAAQAAgKgCgFQgCgFgHAAQgGAAgCAFg");
  this.shape_212.setTransform(191.875, -10.075);
  this.shape_213 = new cjs.Shape();
  this.shape_213.graphics.f("#0C593C").s().p("AAUAhIAAg5IgRA5IgFAAIgRg5IAAA5IgJAAIAAhBIAOAAIANAqIABAOIACgOIAMgqIAPAAIAABBg");
  this.shape_213.setTransform(185.475, -10.1);
  this.shape_214 = new cjs.Shape();
  this.shape_214.graphics.f("#0C593C").s().p("AgTAhIAAhBIAUAAQAIgBAFAFQAFAFAAAGQAAAHgCAEQgDAEgFABIAAABQAGAAACAFQADADAAAHQAAAGgCAEQgCAEgEADQgEABgDAAgAgKAZIAKAAQAGABADgDQACgDAAgGQAAgFgCgDQgEgDgFAAIgKAAgAgKgEIAKAAQAFAAACgDQADgDgBgFQABgKgKAAIgKAAg");
  this.shape_214.setTransform(179.15, -10.1);
  this.shape_215 = new cjs.Shape();
  this.shape_215.graphics.f("#0C593C").s().p("AgWARQAAgGACgEQABgEAEgCIAKgEIAKgFQADgBAAgHQAAgGgCgCQgCgCgFAAQgFAAgDADQgCADAAAFIgIAAQAAgTATAAQAFAAAEACQAFACACAEQACAEAAAFIAAAmQAAAFADAAIACAAIAAAHIgEABQgEAAgDgCQgCgBgBgHIAAAAQgCAFgEADQgDADgFAAQgRAAAAgSgAABAAIgHAEQgDACgBADQgCADAAAEQAAAKAJAAQAFAAADgDIACgDIABgDIAAgHIAAgMIgHACg");
  this.shape_215.setTransform(170.575, -10.075);
  this.shape_216 = new cjs.Shape();
  this.shape_216.graphics.f("#0C593C").s().p("AgYAhIAAgIIAEABQAAAAABAAQAAAAABgBQAAAAABAAQAAgBABAAQABgCABgGIABgQIAAghIAmAAIAABCIgJAAIAAg6IgUAAIAAAaQAAAQgDAIQgDAJgJAAIgFgBg");
  this.shape_216.setTransform(164.575, -10.075);
  this.shape_217 = new cjs.Shape();
  this.shape_217.graphics.f("#0C593C").s().p("AgWAsIAAgJQADACAEAAQAFAAACgDQADgEACgHIgVhDIAKAAIAOA0IABAAIAOg0IAKAAIgUBDIgFAMQgBAEgEADQgEADgGAAIgHgBg");
  this.shape_217.setTransform(159.125, -8.95);
  this.shape_218 = new cjs.Shape();
  this.shape_218.graphics.f("#0C593C").s().p("AgMAeQgFgEgCgIQgCgHAAgKQAAgjAXAAQAJAAAGAGQAFAHAAAJIgJAAQAAgOgLAAQgHAAgDAHQgDAIAAAMQAAALADAIQACAHAHAAQAHAAACgEQACgFABgIIAJAAQAAALgFAHQgFAHgKAAQgJAAgFgFg");
  this.shape_218.setTransform(153.875, -10.075);
  this.shape_219 = new cjs.Shape();
  this.shape_219.graphics.f("#0C593C").s().p("AAMAhIAAg6IgXAAIAAA6IgJAAIAAhBIAqAAIAABBg");
  this.shape_219.setTransform(148.2, -10.1);
  this.shape_220 = new cjs.Shape();
  this.shape_220.graphics.f("#0C593C").s().p("AgWARQAAgGACgEQABgEAEgCIAKgEIAKgFQADgBAAgHQAAgGgCgCQgCgCgFAAQgFAAgDADQgCADAAAFIgIAAQAAgTATAAQAFAAAEACQAFACACAEQACAEAAAFIAAAmQAAAFADAAIACAAIAAAHIgEABQgEAAgDgCQgCgBgBgHIAAAAQgCAFgEADQgDADgFAAQgRAAAAgSgAABAAIgHAEQgDACgBADQgCADAAAEQAAAKAJAAQAFAAADgDIACgDIABgDIAAgHIAAgMIgHACg");
  this.shape_220.setTransform(142.525, -10.075);
  this.shape_221 = new cjs.Shape();
  this.shape_221.graphics.f("#0C593C").s().p("AALAhIgQghIgHAKIAAAXIgKAAIAAhBIAKAAIAAAfIAWgfIALAAIgUAZIAVAog");
  this.shape_221.setTransform(137.55, -10.1);
  this.shape_222 = new cjs.Shape();
  this.shape_222.graphics.f("#0C593C").s().p("AAFAtIAAhBIgTAAIAAgIIAMgBQADgBACgDQADgEABgHIAIAAIAABZg");
  this.shape_222.setTransform(127.85, -11.25);
  this.shape_223 = new cjs.Shape();
  this.shape_223.graphics.f("#0C593C").s().p("AAAAGIgIALIgFgDIAJgLIgNgFIACgFIANAFIAAgPIAFAAIAAAPIANgFIADAGIgOADIAJAMIgFAEg");
  this.shape_223.setTransform(122.5, -13.975);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_223
   }, {
    t: this.shape_222
   }, {
    t: this.shape_221
   }, {
    t: this.shape_220
   }, {
    t: this.shape_219
   }, {
    t: this.shape_218
   }, {
    t: this.shape_217
   }, {
    t: this.shape_216
   }, {
    t: this.shape_215
   }, {
    t: this.shape_214
   }, {
    t: this.shape_213
   }, {
    t: this.shape_212
   }, {
    t: this.shape_211
   }, {
    t: this.shape_210
   }, {
    t: this.shape_209
   }, {
    t: this.shape_208
   }, {
    t: this.shape_207
   }, {
    t: this.shape_206
   }, {
    t: this.shape_205
   }, {
    t: this.shape_204
   }, {
    t: this.shape_203
   }, {
    t: this.shape_202
   }, {
    t: this.shape_201
   }, {
    t: this.shape_200
   }, {
    t: this.shape_199
   }, {
    t: this.shape_198
   }, {
    t: this.shape_197
   }, {
    t: this.shape_196
   }, {
    t: this.shape_195
   }, {
    t: this.shape_194
   }, {
    t: this.shape_193
   }, {
    t: this.shape_192
   }, {
    t: this.shape_191
   }, {
    t: this.shape_190
   }, {
    t: this.shape_189
   }, {
    t: this.shape_188
   }, {
    t: this.shape_187
   }, {
    t: this.shape_186
   }, {
    t: this.shape_185
   }, {
    t: this.shape_184
   }, {
    t: this.shape_183
   }, {
    t: this.shape_182
   }, {
    t: this.shape_181
   }, {
    t: this.shape_180
   }, {
    t: this.shape_179
   }, {
    t: this.shape_178
   }, {
    t: this.shape_177
   }, {
    t: this.shape_176
   }, {
    t: this.shape_175
   }, {
    t: this.shape_174
   }, {
    t: this.shape_173
   }, {
    t: this.shape_172
   }, {
    t: this.shape_171
   }, {
    t: this.shape_170
   }, {
    t: this.shape_169
   }, {
    t: this.shape_168
   }, {
    t: this.shape_167
   }, {
    t: this.shape_166
   }, {
    t: this.shape_165
   }, {
    t: this.shape_164
   }, {
    t: this.shape_163
   }, {
    t: this.shape_162
   }, {
    t: this.shape_161
   }, {
    t: this.shape_160
   }, {
    t: this.shape_159
   }, {
    t: this.shape_158
   }, {
    t: this.shape_157
   }, {
    t: this.shape_156
   }, {
    t: this.shape_155
   }, {
    t: this.shape_154
   }, {
    t: this.shape_153
   }, {
    t: this.shape_152
   }, {
    t: this.shape_151
   }, {
    t: this.shape_150
   }, {
    t: this.shape_149
   }, {
    t: this.shape_148
   }, {
    t: this.shape_147
   }, {
    t: this.shape_146
   }, {
    t: this.shape_145
   }, {
    t: this.shape_144
   }, {
    t: this.shape_143
   }, {
    t: this.shape_142
   }, {
    t: this.shape_141
   }, {
    t: this.shape_140
   }, {
    t: this.shape_139
   }, {
    t: this.shape_138
   }, {
    t: this.shape_137
   }, {
    t: this.shape_136
   }, {
    t: this.shape_135
   }, {
    t: this.shape_134
   }, {
    t: this.shape_133
   }, {
    t: this.shape_132
   }, {
    t: this.shape_131
   }, {
    t: this.shape_130
   }, {
    t: this.shape_129
   }, {
    t: this.shape_128
   }, {
    t: this.shape_127
   }, {
    t: this.shape_126
   }, {
    t: this.shape_125
   }, {
    t: this.shape_124
   }, {
    t: this.shape_123
   }, {
    t: this.shape_122
   }, {
    t: this.shape_121
   }, {
    t: this.shape_120
   }, {
    t: this.shape_119
   }, {
    t: this.shape_118
   }, {
    t: this.shape_117
   }, {
    t: this.shape_116
   }, {
    t: this.shape_115
   }, {
    t: this.shape_114
   }, {
    t: this.shape_113
   }, {
    t: this.shape_112
   }, {
    t: this.shape_111
   }, {
    t: this.shape_110
   }, {
    t: this.shape_109
   }, {
    t: this.shape_108
   }, {
    t: this.shape_107
   }, {
    t: this.shape_106
   }, {
    t: this.shape_105
   }, {
    t: this.shape_104
   }, {
    t: this.shape_103
   }, {
    t: this.shape_102
   }, {
    t: this.shape_101
   }, {
    t: this.shape_100
   }, {
    t: this.shape_99
   }, {
    t: this.shape_98
   }, {
    t: this.shape_97
   }, {
    t: this.shape_96
   }, {
    t: this.shape_95
   }, {
    t: this.shape_94
   }, {
    t: this.shape_93
   }, {
    t: this.shape_92
   }, {
    t: this.shape_91
   }, {
    t: this.shape_90
   }, {
    t: this.shape_89
   }, {
    t: this.shape_88
   }, {
    t: this.shape_87
   }, {
    t: this.shape_86
   }, {
    t: this.shape_85
   }, {
    t: this.shape_84
   }, {
    t: this.shape_83
   }, {
    t: this.shape_82
   }, {
    t: this.shape_81
   }, {
    t: this.shape_80
   }, {
    t: this.shape_79
   }, {
    t: this.shape_78
   }, {
    t: this.shape_77
   }, {
    t: this.shape_76
   }, {
    t: this.shape_75
   }, {
    t: this.shape_74
   }, {
    t: this.shape_73
   }, {
    t: this.shape_72
   }, {
    t: this.shape_71
   }, {
    t: this.shape_70
   }, {
    t: this.shape_69
   }, {
    t: this.shape_68
   }, {
    t: this.shape_67
   }, {
    t: this.shape_66
   }, {
    t: this.shape_65
   }, {
    t: this.shape_64
   }, {
    t: this.shape_63
   }, {
    t: this.shape_62
   }, {
    t: this.shape_61
   }, {
    t: this.shape_60
   }, {
    t: this.shape_59
   }, {
    t: this.shape_58
   }, {
    t: this.shape_57
   }, {
    t: this.shape_56
   }, {
    t: this.shape_55
   }, {
    t: this.shape_54
   }, {
    t: this.shape_53
   }, {
    t: this.shape_52
   }, {
    t: this.shape_51
   }, {
    t: this.shape_50
   }, {
    t: this.shape_49
   }, {
    t: this.shape_48
   }, {
    t: this.shape_47
   }, {
    t: this.shape_46
   }, {
    t: this.shape_45
   }, {
    t: this.shape_44
   }, {
    t: this.shape_43
   }, {
    t: this.shape_42
   }, {
    t: this.shape_41
   }, {
    t: this.shape_40
   }, {
    t: this.shape_39
   }, {
    t: this.shape_38
   }, {
    t: this.shape_37
   }, {
    t: this.shape_36
   }, {
    t: this.shape_35
   }, {
    t: this.shape_34
   }, {
    t: this.shape_33
   }, {
    t: this.shape_32
   }, {
    t: this.shape_31
   }, {
    t: this.shape_30
   }, {
    t: this.shape_29
   }, {
    t: this.shape_28
   }, {
    t: this.shape_27
   }, {
    t: this.shape_26
   }, {
    t: this.shape_25
   }, {
    t: this.shape_24
   }, {
    t: this.shape_23
   }, {
    t: this.shape_22
   }, {
    t: this.shape_21
   }, {
    t: this.shape_20
   }, {
    t: this.shape_19
   }, {
    t: this.shape_18
   }, {
    t: this.shape_17
   }, {
    t: this.shape_16
   }, {
    t: this.shape_15
   }, {
    t: this.shape_14
   }, {
    t: this.shape_13
   }, {
    t: this.shape_12
   }, {
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
  this.shape_224 = new cjs.Shape();
  this.shape_224.graphics.f("rgba(216,247,139,0.698)").s().p("EhLxACRIAAkhMCXjAAAIAAEhg");
  this.shape_224.setTransform(485, -3.5);
  this.timeline.addTween(cjs.Tween.get(this.shape_224).wait(1));
 }).prototype = getMCSymbolPrototype(lib.l1_3, new cjs.Rectangle(0, -20.1, 970, 31.1), null);
 (lib.l1_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#0C593C").s().p("AAVAjIAAg8IgSA8IgFAAIgSg8IAAA8IgJAAIAAhFIAPAAIANAtIABAOIACgOIANgtIAPAAIAABFg");
  this.shape.setTransform(610.975, -8.175);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#0C593C").s().p("AgLAhQgFgDgDgIQgCgIAAgOQAAgkAVAAQAKAAAEAGQAFAFACAIQABAHAAALIghAAIABAPQAAAGAEADQACADAFAAQALAAAAgQIAKAAQAAAHgCAFQgCAGgFADQgFAEgHAAQgHAAgFgEgAgJgVQgCAGAAAJIAXAAQAAgKgCgGQgDgFgHAAQgGAAgDAGg");
  this.shape_1.setTransform(604.35, -8.175);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#0C593C").s().p("AANAjIAAg0IABgIIgCAIIgWA0IgMAAIAAhFIAKAAIAAA0IgBAIIACgIIAXg0IALAAIAABFg");
  this.shape_2.setTransform(598.5, -8.175);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#0C593C").s().p("AAMAjIAAghIgXAAIAAAhIgKAAIAAhFIAKAAIAAAdIAXAAIAAgdIAKAAIAABFg");
  this.shape_3.setTransform(592.325, -8.175);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#0C593C").s().p("AgXARQAAgGABgEQACgDAEgDQAEgCAGgCIALgFQADgBAAgHQAAgGgCgDQgCgCgGAAQgFAAgCADQgDADAAAGIgJAAQAAgVAVAAQAFAAAFADQAEACACAEQACAEAAAFIAAAoQAAAGAEAAIACgBIAAAIIgEABQgFAAgDgCQgBgCgBgHIgBAAQgCAFgEADQgEAEgFAAQgRAAAAgUgAABABIgHAEIgFAEQgCADAAAFQAAALAJAAQAGAAADgEIACgDIABgEIAAgGIAAgNIgHADg");
  this.shape_4.setTransform(586.55, -8.175);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#0C593C").s().p("AgUAjIAAhFIAVAAQAIAAAGAFQAFAEAAAIQAAAGgDAFQgDAEgFABIAAABQAGAAADAEQADAFAAAHQAAAGgCAEQgCAEgEADQgEACgFAAgAgLAbIALAAQAHAAACgDQACgDAAgHQAAgFgCgDQgDgDgFAAIgMAAgAgLgEIALAAQAFAAACgDQADgDAAgFQAAgLgKAAIgLAAg");
  this.shape_5.setTransform(581.175, -8.175);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#0C593C").s().p("AgMAhQgGgDgDgIQgDgIAAgOQAAgRAGgJQAGgKAMAAQAZAAAAAkQAAAOgDAIQgDAIgGADQgFAEgIAAQgHAAgFgEgAgIgYQgDACgBAHQgCAGAAAKQAAAJACAGQABAGADADQADADAFAAQAGAAADgDQADgDABgGQACgGAAgJQAAgKgCgGQgBgHgEgCQgDgDgFAAQgEAAgEADg");
  this.shape_6.setTransform(575.125, -8.175);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#0C593C").s().p("AgLAiQgFgCgCgGQgDgFAAgIIAJAAIACAJQABADADACQACABAEAAQAMAAAAgNQAAgFgDgEQgDgDgFAAIgFAAIAAgIIAEAAQAFAAADgDQADgDAAgFQAAgFgDgDQgDgDgFAAQgFAAgDADQgDADAAAGIgJAAQAAgGACgEQADgFAFgDQAFgDAFAAQAGAAAEADQAFACADAEQACAEAAAFQAAAHgDAEQgEAEgFACIAAAAQAGABAEAEQAEAEAAAIQAAAGgDAFQgCAEgFADQgFADgHAAQgGAAgFgDg");
  this.shape_7.setTransform(569.425, -8.175);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#0C593C").s().p("AgXARQAAgGABgEQACgDAEgDQAEgCAGgCIALgFQADgBAAgHQAAgGgCgDQgCgCgFAAQgGAAgCADQgDADAAAGIgJAAQAAgVAVAAQAGAAAEADQAEACACAEQACAEAAAFIAAAoQAAAGAEAAIACgBIAAAIIgEABQgFAAgDgCQgCgCAAgHIgBAAQgCAFgEADQgEAEgFAAQgRAAAAgUgAABABIgIAEIgEAEQgCADAAAFQAAALAJAAQAGAAADgEIACgDIABgEIAAgGIAAgNIgHADg");
  this.shape_8.setTransform(564.15, -8.175);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#0C593C").s().p("AgWAwIAAhcIAJAAIAAAHQADgEAEgCQAEgEADAAQAWAAAAAkIAAAOQgCAHgCAFQgCAFgFADQgFADgFAAQgFAAgDgDQgEgCgDgEIAAAfgAgKgeQgCAIgBAMIABANQABAGADAEQADAEAFABQAHAAADgIQADgHAAgOQAAgbgNAAQgHAAgDAIg");
  this.shape_9.setTransform(558.45, -7.1);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.f("#0C593C").s().p("AgOArQgFgFgDgJQgCgJAAgOQAAgKABgIQACgIADgGQADgFAEgEQAEgDAFgBIALgEQADgBABgDIAIAAQgBAHgFADQgEADgJACQgHACgEAFQgEAGgBAJQAGgLAKAAQAGAAAGAEQAFAEADAHQADAHAAAKQAAAMgDAIQgDAJgFAEQgGAEgIAAQgIAAgGgFgAgKgGQgDAGgBALQABAJABAHQACAGADADQADADAEAAQAIAAADgHQAEgHgBgOQABgLgEgGQgEgHgHAAQgGAAgEAHg");
  this.shape_10.setTransform(552.35, -9.275);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.f("#0C593C").s().p("AgMAhQgGgDgDgIQgDgIAAgOQAAgRAGgJQAGgKAMAAQAZAAAAAkQAAAOgDAIQgDAIgGADQgFAEgIAAQgHAAgFgEgAgIgYQgDACgBAHQgCAGAAAKQAAAJACAGQABAGADADQADADAFAAQAGAAADgDQADgDABgGQACgGAAgJQAAgKgCgGQgBgHgEgCQgDgDgFAAQgEAAgEADg");
  this.shape_11.setTransform(546.475, -8.175);
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.f("#0C593C").s().p("AgMAhQgGgDgDgIQgDgIAAgOQAAgRAGgJQAGgKAMAAQAZAAAAAkQAAAOgDAIQgDAIgGADQgFAEgIAAQgHAAgFgEgAgIgYQgDACgBAHQgCAGAAAKQAAAJACAGQABAGADADQADADAFAAQAGAAADgDQADgDABgGQACgGAAgJQAAgKgCgGQgBgHgEgCQgDgDgFAAQgEAAgEADg");
  this.shape_12.setTransform(540.325, -8.175);
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.f("#0C593C").s().p("AgLAiQgFgCgCgGQgDgFAAgIIAJAAIACAJQABADADACQACABAEAAQAMAAAAgNQAAgFgDgEQgDgDgFAAIgFAAIAAgIIAEAAQAFAAADgDQADgDAAgFQAAgFgDgDQgDgDgFAAQgFAAgDADQgDADAAAGIgJAAQAAgGACgEQADgFAFgDQAFgDAFAAQAGAAAEADQAFACADAEQACAEAAAFQAAAHgDAEQgEAEgFACIAAAAQAGABAEAEQAEAEAAAIQAAAGgDAFQgCAEgFADQgFADgHAAQgGAAgFgDg");
  this.shape_13.setTransform(534.625, -8.175);
  this.shape_14 = new cjs.Shape();
  this.shape_14.graphics.f("#0C593C").s().p("AgXARQAAgGACgEQACgDADgDQADgCAHgCIAMgFQACgBAAgHQAAgGgCgDQgDgCgEAAQgGAAgCADQgDADABAGIgJAAQgBgVAVAAQAGAAADADQAFACACAEQACAEAAAFIAAAoQAAAGAEAAIACgBIAAAIIgEABQgFAAgCgCQgDgCgBgHIAAAAQgCAFgEADQgDAEgGAAQgRAAAAgUgAAAABIgHAEIgEAEQgCADAAAFQAAALAKAAQAEAAAFgEIABgDIABgEIAAgGIAAgNIgIADg");
  this.shape_14.setTransform(529.35, -8.175);
  this.shape_15 = new cjs.Shape();
  this.shape_15.graphics.f("#0C593C").s().p("AgRAjIAAhFIAkAAIAAAJIgaAAIAAA8g");
  this.shape_15.setTransform(524.8, -8.175);
  this.shape_16 = new cjs.Shape();
  this.shape_16.graphics.f("#0C593C").s().p("AAVAjIAAg8IgSA8IgFAAIgSg8IAAA8IgJAAIAAhFIAPAAIANAtIABAOIACgOIANgtIAPAAIAABFg");
  this.shape_16.setTransform(515.225, -8.175);
  this.shape_17 = new cjs.Shape();
  this.shape_17.graphics.f("#0C593C").s().p("AAWAjIAAhFIAKAAIAABFgAgfAjIAAhFIAKAAIAAAeIAOAAQAGAAADACQAEACACAEQADAFAAAGQAAAGgDAEQgCAFgFACQgDADgFAAgAgVAbIAKAAQAHAAADgDQACgDAAgGQAAgMgLAAIgLAAg");
  this.shape_17.setTransform(507.3, -8.175);
  this.shape_18 = new cjs.Shape();
  this.shape_18.graphics.f("#0C593C").s().p("AAMAjIAAghIgXAAIAAAhIgKAAIAAhFIAKAAIAAAdIAXAAIAAgdIAKAAIAABFg");
  this.shape_18.setTransform(500.175, -8.175);
  this.shape_19 = new cjs.Shape();
  this.shape_19.graphics.f("#0C593C").s().p("AAMAjIAAghIgXAAIAAAhIgKAAIAAhFIAKAAIAAAdIAXAAIAAgdIAKAAIAABFg");
  this.shape_19.setTransform(494.025, -8.175);
  this.shape_20 = new cjs.Shape();
  this.shape_20.graphics.f("#0C593C").s().p("AgLAhQgFgDgCgIQgDgIAAgOQAAgkAVAAQAJAAAGAGQAEAFABAIQACAHAAALIghAAIABAPQAAAGADADQADADAFAAQALAAAAgQIAKAAQAAAHgDAFQgBAGgGADQgEAEgHAAQgHAAgFgEgAgIgVQgDAGAAAJIAWAAQAAgKgCgGQgCgFgHAAQgGAAgCAGg");
  this.shape_20.setTransform(488.2, -8.175);
  this.shape_21 = new cjs.Shape();
  this.shape_21.graphics.f("#0C593C").s().p("AgkAjIAAhFIAKAAIAAA8IAWAAIAAg8IAJAAIAAA8IAXAAIAAg8IAJAAIAABFg");
  this.shape_21.setTransform(480.9, -8.175);
  this.shape_22 = new cjs.Shape();
  this.shape_22.graphics.f("#0C593C").s().p("AAWAjIAAhFIAKAAIAABFgAgfAjIAAhFIAKAAIAAAeIAOAAQAGAAADACQAEACACAEQADAFAAAGQAAAGgDAEQgCAFgFACQgDADgFAAgAgVAbIAKAAQAHAAADgDQACgDAAgGQAAgMgLAAIgLAAg");
  this.shape_22.setTransform(472.2, -8.175);
  this.shape_23 = new cjs.Shape();
  this.shape_23.graphics.f("#0C593C").s().p("AgUAjIAAhFIAVAAQAIAAAGAFQAFAEAAAIQAAAGgDAFQgDAEgFABIAAABQAGAAADAEQADAFAAAHQAAAGgCAEQgCAEgEADQgEACgFAAgAgLAbIALAAQAHAAACgDQACgDAAgHQAAgFgCgDQgDgDgFAAIgMAAgAgLgEIALAAQAFAAACgDQADgDAAgFQAAgLgKAAIgLAAg");
  this.shape_23.setTransform(465.525, -8.175);
  this.shape_24 = new cjs.Shape();
  this.shape_24.graphics.f("#0C593C").s().p("AgMAhQgGgDgDgIQgDgIAAgOQAAgRAGgJQAGgKAMAAQAZAAAAAkQAAAOgDAIQgDAIgGADQgFAEgIAAQgHAAgFgEgAgIgYQgDACgBAHQgCAGAAAKQAAAJACAGQABAGADADQADADAFAAQAGAAADgDQADgDABgGQACgGAAgJQAAgKgCgGQgBgHgEgCQgDgDgFAAQgEAAgEADg");
  this.shape_24.setTransform(459.475, -8.175);
  this.shape_25 = new cjs.Shape();
  this.shape_25.graphics.f("#0C593C").s().p("AAMAjIAAg8IgXAAIAAA8IgKAAIAAhFIArAAIAABFg");
  this.shape_25.setTransform(453.325, -8.175);
  this.shape_26 = new cjs.Shape();
  this.shape_26.graphics.f("#0C593C").s().p("AANAuIAAg0IACgIIgDAIIgWA0IgMAAIAAhEIAKAAIAAAzIgBAIIACgIIAWgzIAMAAIAABEgAgJgiQgFgDAAgIIAFAAQABAJAIAAQAFAAADgCQACgCABgFIAGAAQgBAIgFAEQgEADgHABQgFAAgEgFg");
  this.shape_26.setTransform(444.1, -9.3);
  this.shape_27 = new cjs.Shape();
  this.shape_27.graphics.f("#0C593C").s().p("AgMAhQgGgDgDgIQgDgIAAgOQAAgRAGgJQAGgKAMAAQAZAAAAAkQAAAOgDAIQgDAIgGADQgFAEgIAAQgHAAgFgEgAgIgYQgDACgBAHQgCAGAAAKQAAAJACAGQABAGADADQADADAFAAQAGAAADgDQADgDABgGQACgGAAgJQAAgKgCgGQgBgHgEgCQgDgDgFAAQgEAAgEADg");
  this.shape_27.setTransform(437.925, -8.175);
  this.shape_28 = new cjs.Shape();
  this.shape_28.graphics.f("#0C593C").s().p("AAMAjIAAghIgXAAIAAAhIgKAAIAAhFIAKAAIAAAdIAXAAIAAgdIAKAAIAABFg");
  this.shape_28.setTransform(431.775, -8.175);
  this.shape_29 = new cjs.Shape();
  this.shape_29.graphics.f("#0C593C").s().p("AAMAjIAAghIgXAAIAAAhIgKAAIAAhFIAKAAIAAAdIAXAAIAAgdIAKAAIAABFg");
  this.shape_29.setTransform(425.625, -8.175);
  this.shape_30 = new cjs.Shape();
  this.shape_30.graphics.f("#0C593C").s().p("AgXARQAAgGACgEQACgDADgDQADgCAHgCIALgFQADgBAAgHQAAgGgCgDQgDgCgFAAQgFAAgCADQgCADgBAGIgJAAQABgVATAAQAGAAAFADQAEACACAEQACAEAAAFIAAAoQAAAGAEAAIACgBIAAAIIgEABQgFAAgCgCQgCgCgBgHIgBAAQgCAFgEADQgEAEgEAAQgSAAAAgUgAABABIgHAEIgFAEQgCADAAAFQAAALAJAAQAFAAAEgEIACgDIABgEIAAgGIAAgNIgHADg");
  this.shape_30.setTransform(419.85, -8.175);
  this.shape_31 = new cjs.Shape();
  this.shape_31.graphics.f("#0C593C").s().p("AgUAjIAAhFIAVAAQAIAAAGAFQAFAEAAAIQAAAGgDAFQgDAEgFABIAAABQAGAAADAEQADAFAAAHQAAAGgCAEQgCAEgEADQgEACgFAAgAgLAbIALAAQAHAAACgDQACgDAAgHQAAgFgCgDQgDgDgFAAIgMAAgAgLgEIALAAQAFAAACgDQADgDAAgFQAAgLgKAAIgLAAg");
  this.shape_31.setTransform(414.475, -8.175);
  this.shape_32 = new cjs.Shape();
  this.shape_32.graphics.f("#0C593C").s().p("AgLAiQgFgCgCgGQgDgFAAgIIAJAAQAAAGACADQABADADACQACABAEAAQAMAAAAgNQAAgFgDgEQgDgDgFAAIgFAAIAAgIIAEAAQAFAAADgDQADgDAAgFQAAgFgDgDQgDgDgFAAQgFAAgDADQgDADAAAGIgJAAQAAgGACgEQADgFAFgDQAFgDAFAAQAGAAAEADQAFACADAEQACAEAAAFQAAAHgDAEQgEAEgFACIAAAAQAGABAEAEQAEAEAAAIQAAAGgDAFQgCAEgFADQgFADgHAAQgGAAgFgDg");
  this.shape_32.setTransform(408.875, -8.175);
  this.shape_33 = new cjs.Shape();
  this.shape_33.graphics.f("#0C593C").s().p("AAWAjIAAhFIAKAAIAABFgAgfAjIAAhFIAJAAIAAAeIAPAAQAFAAAEACQAEACADAEQACAFAAAGQAAAGgCAEQgDAFgFACQgCADgGAAgAgWAbIALAAQAHAAADgDQACgDAAgGQAAgMgLAAIgMAAg");
  this.shape_33.setTransform(402.25, -8.175);
  this.shape_34 = new cjs.Shape();
  this.shape_34.graphics.f("#0C593C").s().p("AgUAjIAAhFIAVAAQAIAAAGAFQAFAEAAAIQAAAGgDAFQgDAEgFABIAAABQAGAAADAEQADAFAAAHQAAAGgCAEQgCAEgEADQgEACgFAAgAgLAbIALAAQAHAAACgDQACgDAAgHQAAgFgCgDQgDgDgFAAIgMAAgAgLgEIALAAQAFAAACgDQADgDAAgFQAAgLgKAAIgLAAg");
  this.shape_34.setTransform(395.575, -8.175);
  this.shape_35 = new cjs.Shape();
  this.shape_35.graphics.f("#0C593C").s().p("AgFAKQAFgCAAgKIgFAAIAAgMIALAAIAAAOQAAAFgDAEQgDAFgFABg");
  this.shape_35.setTransform(388.125, -4.425);
  this.shape_36 = new cjs.Shape();
  this.shape_36.graphics.f("#0C593C").s().p("AAOAjIAAg0IABgIIgDAIIgWA0IgMAAIAAhFIAKAAIAAA0IgBAIIACgIIAWg0IAMAAIAABFg");
  this.shape_36.setTransform(383.45, -8.175);
  this.shape_37 = new cjs.Shape();
  this.shape_37.graphics.f("#0C593C").s().p("AgZAiIAAgHIAEAAQADAAABgCQACgCABgGIAAgRIAAgiIAoAAIAABFIgKAAIAAg9IgUAAIAAAbQAAAQgDAKQgEAIgIAAIgGgBg");
  this.shape_37.setTransform(376.925, -8.15);
  this.shape_38 = new cjs.Shape();
  this.shape_38.graphics.f("#0C593C").s().p("AgMAhQgGgDgDgIQgDgIAAgOQAAgRAGgJQAGgKAMAAQAZAAAAAkQAAAOgDAIQgDAIgGADQgFAEgIAAQgHAAgFgEgAgIgYQgDACgBAHQgCAGAAAKQAAAJACAGQABAGADADQADADAFAAQAGAAADgDQADgDABgGQACgGAAgJQAAgKgCgGQgBgHgEgCQgDgDgFAAQgEAAgEADg");
  this.shape_38.setTransform(371.125, -8.175);
  this.shape_39 = new cjs.Shape();
  this.shape_39.graphics.f("#0C593C").s().p("AgaAvIAAhdIAuAAIAAAKIgjAAIAAAeIAMAAQAGAAAGABQAFACAEADQAEACACAFQACAGAAAHQAAAOgHAGQgIAHgLAAgAgPAlIAMAAQAIAAAFgDQAGgEAAgKQgBgHgCgEQgCgEgFgBQgGgCgHAAIgIAAg");
  this.shape_39.setTransform(365, -9.375);
  this.shape_40 = new cjs.Shape();
  this.shape_40.graphics.f("#0C593C").s().p("AAAAGIgIAMIgGgEIAKgLIgOgFIACgFIAOAFIAAgPIAFAAIAAAPIAOgFIACAGIgOADIAKAMIgGAEg");
  this.shape_40.setTransform(358.325, -12.225);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_40
   }, {
    t: this.shape_39
   }, {
    t: this.shape_38
   }, {
    t: this.shape_37
   }, {
    t: this.shape_36
   }, {
    t: this.shape_35
   }, {
    t: this.shape_34
   }, {
    t: this.shape_33
   }, {
    t: this.shape_32
   }, {
    t: this.shape_31
   }, {
    t: this.shape_30
   }, {
    t: this.shape_29
   }, {
    t: this.shape_28
   }, {
    t: this.shape_27
   }, {
    t: this.shape_26
   }, {
    t: this.shape_25
   }, {
    t: this.shape_24
   }, {
    t: this.shape_23
   }, {
    t: this.shape_22
   }, {
    t: this.shape_21
   }, {
    t: this.shape_20
   }, {
    t: this.shape_19
   }, {
    t: this.shape_18
   }, {
    t: this.shape_17
   }, {
    t: this.shape_16
   }, {
    t: this.shape_15
   }, {
    t: this.shape_14
   }, {
    t: this.shape_13
   }, {
    t: this.shape_12
   }, {
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
  this.shape_41 = new cjs.Shape();
  this.shape_41.graphics.f("rgba(216,247,139,0.698)").s().p("EhLxABLIAAiVMCXjAAAIAACVg");
  this.shape_41.setTransform(485, -7.5);
  this.timeline.addTween(cjs.Tween.get(this.shape_41).wait(1));
 }).prototype = getMCSymbolPrototype(lib.l1_1, new cjs.Rectangle(0, -18.5, 970, 18.5), null);
 (lib.icon03 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.icon3();
  this.instance.parent = this;
  this.instance.setTransform(0, 0, 0.667, 0.667);
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));
 }).prototype = getMCSymbolPrototype(lib.icon03, new cjs.Rectangle(0, 0, 142.8, 142.8), null);
 (lib.gr = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.lf(["rgba(217,237,141,0)", "#D9ED8D"], [0, 1], -19.5, -83.2, -19.5, -122).s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
  this.shape.setTransform(485, 125);
  this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
 }).prototype = getMCSymbolPrototype(lib.gr, new cjs.Rectangle(0, 0, 970, 250), null);
 (lib.fish02 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.fish2();
  this.instance.parent = this;
  this.instance.setTransform(0, 0, 0.667, 0.667);
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));
 }).prototype = getMCSymbolPrototype(lib.fish02, new cjs.Rectangle(0, 0, 230.8, 177.4), null);
 (lib.fish01 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.fish1();
  this.instance.parent = this;
  this.instance.setTransform(0, 0, 0.667, 0.667);
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));
 }).prototype = getMCSymbolPrototype(lib.fish01, new cjs.Rectangle(0, 0, 228.1, 207.5), null);
 (lib.black_plate = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#C0DF53").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
  this.shape.setTransform(484.9982, 124.9997, 1.3324, 2.7778);
  this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
 }).prototype = getMCSymbolPrototype(lib.black_plate, new cjs.Rectangle(0, 0, 970, 250), null);
 (lib.bg_g = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.lf(["#C0DF53", "#D9ED8D"], [0, 1], -14.6, -29.1, -14.6, -42.7).s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
  this.shape.setTransform(484.9982, 124.9997, 1.3324, 2.7778);
  this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
 }).prototype = getMCSymbolPrototype(lib.bg_g, new cjs.Rectangle(0, 0, 970, 250), null);
 (lib.b1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.bubble();
  this.instance.parent = this;
  this.instance.setTransform(0, 0, 0.667, 0.667);
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));
 }).prototype = getMCSymbolPrototype(lib.b1, new cjs.Rectangle(0, 0, 298.8, 298.8), null);
 (lib.txt04 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  var mask = new cjs.Shape();
  mask._off = true;
  mask.graphics.p("Av2O+IAAlMMAsNAAAIAAFMg");
  mask.setTransform(181.4902, 95.7747);
  this.instance = new lib.t4();
  this.instance.parent = this;
  this.instance.setTransform(78, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance.alpha = 0;
  this.instance._off = true;
  var maskedShapeInstanceList = [this.instance];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(10).to({
   _off: false
  }, 0).to({
   x: 108,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(11));
  var mask_1 = new cjs.Shape();
  mask_1._off = true;
  mask_1.graphics.p("Av2MYIAAkxMAsNAAAIAAExg");
  mask_1.setTransform(181.4902, 79.2307);
  this.instance_1 = new lib.t4();
  this.instance_1.parent = this;
  this.instance_1.setTransform(78, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance_1.alpha = 0;
  this.instance_1._off = true;
  var maskedShapeInstanceList = [this.instance_1];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(5).to({
   _off: false
  }, 0).to({
   x: 108,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(16));
  var mask_2 = new cjs.Shape();
  mask_2._off = true;
  mask_2.graphics.p("Av2KAIAAnBMAsNAAAIAAHBg");
  mask_2.setTransform(181.4902, 63.9953);
  this.instance_2 = new lib.t4();
  this.instance_2.parent = this;
  this.instance_2.setTransform(78, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance_2.alpha = 0;
  var maskedShapeInstanceList = [this.instance_2];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_2).to({
   x: 108,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(21));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(147.8, 83.1, 215.2, 108.5);
 (lib.txt03 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  var mask = new cjs.Shape();
  mask._off = true;
  mask.graphics.p("As4N4IAAlyMAsNAAAIAAFyg");
  mask.setTransform(200.4652, 88.8498);
  this.instance = new lib.t3();
  this.instance.parent = this;
  this.instance.setTransform(78, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance.alpha = 0;
  this.instance._off = true;
  var maskedShapeInstanceList = [this.instance];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(5).to({
   _off: false
  }, 0).to({
   x: 108,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(16));
  var mask_1 = new cjs.Shape();
  mask_1._off = true;
  mask_1.graphics.p("As4K9IAAn0MAsNAAAIAAH0g");
  mask_1.setTransform(200.4652, 70.1);
  this.instance_1 = new lib.t3();
  this.instance_1.parent = this;
  this.instance_1.setTransform(78, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance_1.alpha = 0;
  var maskedShapeInstanceList = [this.instance_1];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_1).to({
   x: 108,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(21));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(146, 96, 255, 81.69999999999999);
 (lib.txt02 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  var mask = new cjs.Shape();
  mask._off = true;
  mask.graphics.p("AuxQ7IAAlyMAxhAAAIAAFyg");
  mask.setTransform(222.3637, 108.2748);
  this.instance = new lib.t2();
  this.instance.parent = this;
  this.instance.setTransform(78, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance.alpha = 0;
  this.instance._off = true;
  var maskedShapeInstanceList = [this.instance];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(10).to({
   _off: false
  }, 0).to({
   x: 108,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(11));
  var mask_1 = new cjs.Shape();
  mask_1._off = true;
  mask_1.graphics.p("AuxOBIAAlyMAxhAAAIAAFyg");
  mask_1.setTransform(222.3637, 89.7498);
  this.instance_1 = new lib.t2();
  this.instance_1.parent = this;
  this.instance_1.setTransform(78, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance_1.alpha = 0;
  this.instance_1._off = true;
  var maskedShapeInstanceList = [this.instance_1];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(5).to({
   _off: false
  }, 0).to({
   x: 108,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(16));
  var mask_2 = new cjs.Shape();
  mask_2._off = true;
  mask_2.graphics.p("AuxLIIAAnzMAxhAAAIAAHzg");
  mask_2.setTransform(222.3637, 71.25);
  this.instance_2 = new lib.t2();
  this.instance_2.parent = this;
  this.instance_2.setTransform(78, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance_2.alpha = 0;
  var maskedShapeInstanceList = [this.instance_2];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_2).to({
   x: 108,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(21));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(146, 96, 298.8, 120.6);
 (lib._new = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.orange();
  this.instance.parent = this;
  this.instance.setTransform(52, 52, 1, 1, 0, 0, 0, 52, 52);
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   scaleX: 1.0787,
   scaleY: 1.0787,
   x: 52.05,
   y: 52.05
  }, 12, cjs.Ease.get(1)).to({
   scaleX: 1,
   scaleY: 1,
   x: 52,
   y: 52
  }, 12, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(-4, -4, 134, 112.2);
 (lib.fish02_float = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.fish02();
  this.instance.parent = this;
  this.instance.setTransform(114, 103.7, 1, 1, 0, 0, 0, 114, 103.7);
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   y: 98.7
  }, 9, cjs.Ease.get(-1)).to({
   y: 93.7
  }, 10, cjs.Ease.get(1)).to({
   y: 98.7
  }, 10, cjs.Ease.get(-1)).to({
   y: 103.7
  }, 10, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(0, -10, 230.8, 187.4);
 (lib.bubble_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.b1();
  this.instance.parent = this;
  this.instance.setTransform(149.4, 149.4, 1, 1, 0, 0, 0, 149.4, 149.4);
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   y: 143.75
  }, 9, cjs.Ease.get(-1)).to({
   y: 137.45
  }, 10, cjs.Ease.get(1)).to({
   y: 143.45
  }, 10, cjs.Ease.get(-1)).to({
   y: 149.4
  }, 10, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(0, -11.9, 298.8, 310.7);
 (lib.fish01_float = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.bubble_1();
  this.instance.parent = this;
  this.instance.setTransform(40, 98.7, 0.0337, 0.0337, 0, 0, 0, 145.6, 154.5);
  this.instance._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(21).to({
   _off: false
  }, 0).to({
   regX: 145.9,
   regY: 153.2,
   scaleX: 0.1707,
   scaleY: 0.1707,
   x: -20,
   y: 58.7
  }, 10, cjs.Ease.get(0.5)).to({
   regX: 145.7,
   regY: 154.5,
   scaleX: 0.034,
   scaleY: 0.034,
   y: 38.7
  }, 10, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(76));
  this.instance_1 = new lib.bubble_1();
  this.instance_1.parent = this;
  this.instance_1.setTransform(40, 98.7, 0.0337, 0.0337, 0, 0, 0, 145.6, 154.5);
  this.instance_1._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(16).to({
   _off: false
  }, 0).to({
   regX: 145.9,
   regY: 153.2,
   scaleX: 0.1707,
   scaleY: 0.1707,
   x: -30,
   y: 78.7
  }, 10, cjs.Ease.get(0.5)).to({
   regX: 145.7,
   regY: 154.5,
   scaleX: 0.034,
   scaleY: 0.034,
   x: -10,
   y: 48.7
  }, 10, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(81));
  this.instance_2 = new lib.bubble_1();
  this.instance_2.parent = this;
  this.instance_2.setTransform(40, 98.7, 0.0337, 0.0337, 0, 0, 0, 145.6, 154.5);
  this.instance_2._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(11).to({
   _off: false
  }, 0).to({
   regX: 145.9,
   regY: 153.2,
   scaleX: 0.1707,
   scaleY: 0.1707,
   x: -30,
   y: 68.7
  }, 10, cjs.Ease.get(0.5)).to({
   regX: 145.7,
   regY: 154.5,
   scaleX: 0.034,
   scaleY: 0.034,
   x: -40,
   y: 28.7
  }, 10, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(86));
  this.instance_3 = new lib.bubble_1();
  this.instance_3.parent = this;
  this.instance_3.setTransform(40, 98.7, 0.0337, 0.0337, 0, 0, 0, 145.6, 154.5);
  this.instance_3._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(6).to({
   _off: false
  }, 0).to({
   regX: 145.9,
   regY: 153.2,
   scaleX: 0.1707,
   scaleY: 0.1707,
   x: -20,
   y: 58.7
  }, 10, cjs.Ease.get(0.5)).to({
   regX: 145.7,
   regY: 154.5,
   scaleX: 0.034,
   scaleY: 0.034,
   y: 38.7
  }, 10, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(91));
  this.instance_4 = new lib.fish01();
  this.instance_4.parent = this;
  this.instance_4.setTransform(114, 103.7, 1, 1, 0, 0, 0, 114, 103.7);
  this.timeline.addTween(cjs.Tween.get(this.instance_4).to({
   y: 98.7
  }, 9, cjs.Ease.get(-1)).to({
   y: 93.7
  }, 10, cjs.Ease.get(1)).to({
   y: 98.7
  }, 10, cjs.Ease.get(-1)).to({
   y: 103.7
  }, 10, cjs.Ease.get(1)).to({
   y: 98.7
  }, 9, cjs.Ease.get(-1)).to({
   y: 93.7
  }, 10, cjs.Ease.get(1)).to({
   y: 98.7
  }, 10, cjs.Ease.get(-1)).to({
   y: 103.7
  }, 10, cjs.Ease.get(1)).to({
   y: 98.7
  }, 9, cjs.Ease.get(-1)).to({
   y: 93.7
  }, 10, cjs.Ease.get(1)).to({
   y: 98.7
  }, 10, cjs.Ease.get(-1)).to({
   y: 103.7
  }, 10, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(-54.9, -10, 283, 217.5);
 (lib.content = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {
   cvr_frame1_3: 94,
   "cvr_frame#2": 156,
   cvr_stay: 178,
   cvr_frame3_1: 265
  });
  this.frame_178 = function() {
   if (!this.cycle) this.cycle = 0;
   this.cycle++;
   var frames = this.duration * this.cycle + this.currentFrame;
   if (frames / createjs.Ticker.getMeasuredFPS() > 30) {
    if (this.cycle > 1) {
     _globalStop(this.stage);
    } else {
     var stopFrame = this.currentFrame;
     var tst = cjs.Tween.get(this);
     this.timeline.addTween(cjs.Tween.get(this).wait(this.duration - 1).call(function() {
      globalGotoAndStop(stopFrame);
     }));
    }
   }
  }
  this.timeline.addTween(cjs.Tween.get(this).wait(178).call(this.frame_178));
  this.instance = new lib.black_plate();
  this.instance.parent = this;
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   alpha: 0
  }, 14, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(270).to({
   _off: false
  }, 0).to({
   alpha: 1
  }, 15, cjs.Ease.get(-1)).wait(1));
  this.instance_1 = new lib.logo();
  this.instance_1.parent = this;
  this.instance_1.setTransform(112.5, 26.1, 1, 1, 0, 0, 0, 112.5, 26.1);
  this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(96).to({
   alpha: 0
  }, 14, cjs.Ease.get(1)).wait(85).to({
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(92));
  this.instance_2 = new lib.txt02("synched", 0, false);
  this.instance_2.parent = this;
  this.instance_2.setTransform(108, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance_2._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(21).to({
   _off: false
  }, 0).wait(75).to({
   startPosition: 34
  }, 0).to({
   alpha: 0
  }, 14, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(190));
  this.instance_3 = new lib.gr();
  this.instance_3.parent = this;
  this.instance_3.setTransform(150, 300, 1, 1, 0, 0, 0, 150, 300);
  this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(96).to({
   alpha: 0
  }, 14, cjs.Ease.get(1)).wait(85).to({
   regY: 300.1,
   y: 300.1,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(92));
  this.instance_4 = new lib.l1_3();
  this.instance_4.parent = this;
  this.instance_4.setTransform(141.5, 254.8, 1, 1, 0, 0, 0, 141.5, 14.8);
  this.instance_4.alpha = 0;
  this.instance_4._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(230).to({
   _off: false
  }, 0).to({
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(57));
  this.instance_5 = new lib.txt04("synched", 0, false);
  this.instance_5.parent = this;
  this.instance_5.setTransform(108, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance_5._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(211).to({
   _off: false
  }, 0).wait(90));
  this.instance_6 = new lib.fish02_float();
  this.instance_6.parent = this;
  this.instance_6.setTransform(1313.45, 144.7, 1.1068, 1.1068, 0, 0, 0, 114.4, 104);
  this.instance_6._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(201).to({
   _off: false
  }, 0).to({
   regX: 114.3,
   x: 717.85
  }, 14, cjs.Ease.get(1)).wait(86));
  var mask = new cjs.Shape();
  mask._off = true;
  var mask_graphics_216 = new cjs.Graphics().p("EAhHALyQghghAAgvQAAgvAhghQAhghAvAAQAvAAAhAhQAiAhAAAvQAAAvgiAhQghAhgvAAQgvAAghghg");
  var mask_graphics_217 = new cjs.Graphics().p("AfkMDQg6g5AAhRQAAhRA6g6QA5g5BRAAQBRAAA5A5QA6A6AABRQAABRg6A5Qg5A5hRAAQhRAAg5g5g");
  var mask_graphics_218 = new cjs.Graphics().p("AeHMTQhPhQAAhxQAAhwBPhQQBQhPBxAAQBwAABQBPQBPBQAABwQAABxhPBQQhQBPhwAAQhxAAhQhPg");
  var mask_graphics_219 = new cjs.Graphics().p("AczMhQhlhkAAiOQAAiOBlhkQBkhkCNAAQCOAABkBkQBkBkAACOQAACOhkBkQhkBkiOAAQiNAAhkhkg");
  var mask_graphics_220 = new cjs.Graphics().p("AblMuQh3h3AAioQAAioB3h3QB3h3CoAAQCoAAB3B3QB3B3AACoQAACoh3B3Qh3B3ioAAQioAAh3h3g");
  var mask_graphics_221 = new cjs.Graphics().p("AafM6QiIiIAAjAQAAjACIiIQCIiIDAAAQDAAACICIQCICIAADAQAADAiICIQiICIjAAAQjAAAiIiIg");
  var mask_graphics_222 = new cjs.Graphics().p("AZgNEQiXiXAAjVQAAjWCXiXQCXiWDWAAQDWAACXCWQCXCXAADWQAADViXCXQiXCXjWAAQjWAAiXiXg");
  var mask_graphics_223 = new cjs.Graphics().p("AYpNOQikilAAjoQAAjpCkikQClikDoAAQDpAACkCkQCkCkAADpQAADoikClQikCkjpAAQjoAAilikg");
  var mask_graphics_224 = new cjs.Graphics().p("AX5NWQiwiwAAj5QAAj5CwiwQCwivD5AAQD5AACwCvQCwCwAAD5QAAD5iwCwQiwCwj5AAQj5AAiwiwg");
  var mask_graphics_225 = new cjs.Graphics().p("AXRNdQi6i6AAkHQAAkHC6i5QC5i5EHAAQEHAAC6C5QC6C5AAEHQAAEHi6C6Qi6C5kHAAQkHAAi5i5g");
  var mask_graphics_226 = new cjs.Graphics().p("AWvNiQjBjCAAkSQAAkSDBjBQDCjCESAAQETAADCDCQDBDBAAESQAAESjBDCQjCDCkTAAQkSAAjCjCg");
  var mask_graphics_227 = new cjs.Graphics().p("AWWNnQjIjIAAkbQAAkcDIjHQDIjIEbAAQEbAADIDIQDIDHAAEcQAAEbjIDIQjIDIkbAAQkbAAjIjIg");
  var mask_graphics_228 = new cjs.Graphics().p("AWDNqQjMjNAAkhQAAkhDMjMQDNjNEhAAQEhAADNDNQDNDMAAEhQAAEhjNDNQjNDMkhAAQkhAAjNjMg");
  var mask_graphics_229 = new cjs.Graphics().p("AV4NsQjPjQAAklQAAklDPjOQDPjPEmAAQElAADPDPQDPDOAAElQAAEljPDQQjPDPklAAQkmAAjPjPg");
  var mask_graphics_230 = new cjs.Graphics().p("AV1NuQjQjRAAkmQAAkmDQjQQDRjQEmAAQEmAADRDQQDQDQAAEmQAAEmjQDRQjRDQkmAAQkmAAjRjQg");
  this.timeline.addTween(cjs.Tween.get(mask).to({
   graphics: null,
   x: 0,
   y: 0
  }).wait(216).to({
   graphics: mask_graphics_216,
   x: 231.263,
   y: 78.738
  }).wait(1).to({
   graphics: mask_graphics_217,
   x: 235.3541,
   y: 82.8291
  }).wait(1).to({
   graphics: mask_graphics_218,
   x: 239.1422,
   y: 86.6171
  }).wait(1).to({
   graphics: mask_graphics_219,
   x: 242.6272,
   y: 90.102
  }).wait(1).to({
   graphics: mask_graphics_220,
   x: 245.8091,
   y: 93.2839
  }).wait(1).to({
   graphics: mask_graphics_221,
   x: 248.688,
   y: 96.1628
  }).wait(1).to({
   graphics: mask_graphics_222,
   x: 251.2639,
   y: 98.7386
  }).wait(1).to({
   graphics: mask_graphics_223,
   x: 253.5367,
   y: 101.0114
  }).wait(1).to({
   graphics: mask_graphics_224,
   x: 255.5065,
   y: 102.9812
  }).wait(1).to({
   graphics: mask_graphics_225,
   x: 257.1732,
   y: 104.6479
  }).wait(1).to({
   graphics: mask_graphics_226,
   x: 258.5369,
   y: 106.0116
  }).wait(1).to({
   graphics: mask_graphics_227,
   x: 259.5976,
   y: 107.0722
  }).wait(1).to({
   graphics: mask_graphics_228,
   x: 260.3552,
   y: 107.8298
  }).wait(1).to({
   graphics: mask_graphics_229,
   x: 260.8097,
   y: 108.2844
  }).wait(1).to({
   graphics: mask_graphics_230,
   x: 261.0628,
   y: 108.5628
  }).wait(71));
  this.instance_7 = new lib.icon03();
  this.instance_7.parent = this;
  this.instance_7.setTransform(450.65, 145.65, 1.0209, 1.0209, 0, 0, 0, 70.8, 71.5);
  this.instance_7._off = true;
  var maskedShapeInstanceList = [this.instance_7];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(216).to({
   _off: false
  }, 0).wait(85));
  this.instance_8 = new lib.bubble_1();
  this.instance_8.parent = this;
  this.instance_8.setTransform(451.9, 144.5, 0.1089, 0.1089, 0, 0, 0, 152.5, 152.9);
  this.instance_8._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(211).to({
   _off: false
  }, 0).to({
   regX: 151.3,
   regY: 151.3,
   scaleX: 0.5997,
   scaleY: 0.5997,
   x: 451.95,
   y: 144.55
  }, 14, cjs.Ease.get(1)).wait(76));
  this.instance_9 = new lib.bubble_1();
  this.instance_9.parent = this;
  this.instance_9.setTransform(244.9, 138.25, 0.0979, 0.0979, 0, 0, 0, 153.2, 152.2);
  this.instance_9._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(206).to({
   _off: false
  }, 0).to({
   regX: 151.8,
   regY: 151.3,
   scaleX: 0.9416,
   scaleY: 0.9416,
   x: 244.95
  }, 14, cjs.Ease.get(1)).wait(81));
  this.instance_10 = new lib.black_plate();
  this.instance_10.parent = this;
  this.instance_10.alpha = 0;
  this.instance_10._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(193).to({
   _off: false
  }, 0).to({
   alpha: 1
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(92));
  this.instance_11 = new lib.l3();
  this.instance_11.parent = this;
  this.instance_11.setTransform(149.5, 255.1, 1, 1, 0, 0, 0, 149.5, 40.1);
  this.instance_11.alpha = 0;
  this.instance_11._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(121).to({
   _off: false
  }, 0).to({
   alpha: 1
  }, 14, cjs.Ease.get(1)).to({
   _off: true
  }, 74).wait(92));
  this.instance_12 = new lib.packshot_1();
  this.instance_12.parent = this;
  this.instance_12.setTransform(1165.35, 98.25, 0.8298, 0.8298, 0, 0, 0, 117.5, 56.9);
  this.instance_12._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(101).to({
   _off: false
  }, 0).to({
   x: 656.75
  }, 14, cjs.Ease.get(1)).to({
   _off: true
  }, 94).wait(92));
  this.instance_13 = new lib.txt03("synched", 0, false);
  this.instance_13.parent = this;
  this.instance_13.setTransform(108, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance_13._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(111).to({
   _off: false
  }, 0).to({
   _off: true
  }, 98).wait(92));
  this.instance_14 = new lib.bubble_1();
  this.instance_14.parent = this;
  this.instance_14.setTransform(265.25, 151.05, 0.0967, 0.0967, 0, 0, 0, 152.1, 151.6);
  this.instance_14._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(106).to({
   _off: false
  }, 0).to({
   regX: 150.8,
   regY: 150.8,
   scaleX: 0.9876,
   scaleY: 0.9876,
   x: 265.15,
   y: 151.15
  }, 13, cjs.Ease.get(1)).to({
   _off: true
  }, 90).wait(92));
  var mask_1 = new cjs.Shape();
  mask_1._off = true;
  var mask_1_graphics_116 = new cjs.Graphics().p("EAjXAHdQgigiAAgwQAAgwAigiQAigiAwAAQAwAAAiAiQAiAiAAAwQAAAwgiAiQgiAigwAAQgwAAgigig");
  var mask_1_graphics_117 = new cjs.Graphics().p("EAhgAHxQg/g/AAhZQAAhZA/g+QA+g/BZAAQBZAAA/A/QA+A+AABZQAABZg+A/Qg/A+hZAAQhZAAg+g+g");
  var mask_1_graphics_118 = new cjs.Graphics().p("AfxIDQhZhaAAh+QAAh/BZhZQBahZB+AAQB/AABZBZQBZBZAAB/QAAB+hZBaQhZBZh/AAQh+AAhahZg");
  var mask_1_graphics_119 = new cjs.Graphics().p("AeLITQhyhyAAihQAAihByhxQByhyCiAAQChAAByByQByBxAAChQAAChhyByQhyByihAAQiiAAhyhyg");
  var mask_1_graphics_120 = new cjs.Graphics().p("AcvIjQiJiJAAjBQAAjBCJiHQCIiIDBAAQDBAACICIQCJCHAADBQAADBiJCJQiICIjBAAQjBAAiIiIg");
  var mask_1_graphics_121 = new cjs.Graphics().p("AbbIwQidicAAjeQAAjdCdicQCcidDeAAQDeAACcCdQCdCcAADdQAADeidCcQicCdjeAAQjeAAicidg");
  var mask_1_graphics_122 = new cjs.Graphics().p("AaPI9QiuivAAj3QAAj3CuivQCviuD4AAQD3AACvCuQCvCvAAD3QAAD3ivCvQivCvj3AAQj4AAivivg");
  var mask_1_graphics_123 = new cjs.Graphics().p("AZNJIQi/i/AAkOQAAkNC/i/QC/i/EOAAQEOAAC/C/QC/C/AAENQAAEOi/C/Qi/C+kOAAQkOAAi/i+g");
  var mask_1_graphics_124 = new cjs.Graphics().p("AYUJRQjNjNAAkhQAAkhDNjNQDMjMEiAAQEiAADMDMQDNDNAAEhQAAEhjNDNQjMDNkiAAQkiAAjMjNg");
  var mask_1_graphics_125 = new cjs.Graphics().p("AXjJZQjYjZAAkyQAAkxDYjYQDYjZEzAAQEyAADYDZQDZDYAAExQAAEyjZDZQjYDYkyAAQkzAAjYjYg");
  var mask_1_graphics_126 = new cjs.Graphics().p("AW7JfQjijiAAk/QAAk/DijiQDijiFAAAQFAAADiDiQDiDiAAE/QAAE/jiDiQjiDjlAAAQlAAAjijjg");
  var mask_1_graphics_127 = new cjs.Graphics().p("AWcJlQjpjqAAlKQAAlKDpjpQDqjqFKAAQFKAADqDqQDqDpAAFKQAAFKjqDqQjqDplKAAQlKAAjqjpg");
  var mask_1_graphics_128 = new cjs.Graphics().p("AWGJoQjvjvAAlSQAAlRDvjuQDvjvFSAAQFSAADvDvQDvDuAAFRQAAFSjvDvQjvDvlSAAQlSAAjvjvg");
  var mask_1_graphics_129 = new cjs.Graphics().p("AV5JqQjyjyAAlWQAAlWDyjyQDyjyFWAAQFXAADyDyQDyDyAAFWQAAFWjyDyQjyDylXAAQlWAAjyjyg");
  var mask_1_graphics_130 = new cjs.Graphics().p("AV2JwQjzjzAAlYQAAlXDzjzQDzjzFYAAQFYAADzDzQDzDzAAFXQAAFYjzDzQjzDzlYAAQlYAAjzjzg");
  this.timeline.addTween(cjs.Tween.get(mask_1).to({
   graphics: null,
   x: 0,
   y: 0
  }).wait(116).to({
   graphics: mask_1_graphics_116,
   x: 246.0869,
   y: 51.1119
  }).wait(1).to({
   graphics: mask_1_graphics_117,
   x: 250.9481,
   y: 55.9482
  }).wait(1).to({
   graphics: mask_1_graphics_118,
   x: 255.4491,
   y: 60.4262
  }).wait(1).to({
   graphics: mask_1_graphics_119,
   x: 259.5901,
   y: 64.5459
  }).wait(1).to({
   graphics: mask_1_graphics_120,
   x: 263.371,
   y: 68.3074
  }).wait(1).to({
   graphics: mask_1_graphics_121,
   x: 266.7918,
   y: 71.7107
  }).wait(1).to({
   graphics: mask_1_graphics_122,
   x: 269.8525,
   y: 74.7558
  }).wait(1).to({
   graphics: mask_1_graphics_123,
   x: 272.5532,
   y: 77.4426
  }).wait(1).to({
   graphics: mask_1_graphics_124,
   x: 274.8937,
   y: 79.7711
  }).wait(1).to({
   graphics: mask_1_graphics_125,
   x: 276.8742,
   y: 81.7415
  }).wait(1).to({
   graphics: mask_1_graphics_126,
   x: 278.4946,
   y: 83.3535
  }).wait(1).to({
   graphics: mask_1_graphics_127,
   x: 279.7549,
   y: 84.6074
  }).wait(1).to({
   graphics: mask_1_graphics_128,
   x: 280.6551,
   y: 85.503
  }).wait(1).to({
   graphics: mask_1_graphics_129,
   x: 281.1952,
   y: 86.0403
  }).wait(1).to({
   graphics: mask_1_graphics_130,
   x: 281.5235,
   y: 86.7235
  }).wait(79).to({
   graphics: null,
   x: 0,
   y: 0
  }).wait(92));
  this.instance_15 = new lib._new();
  this.instance_15.parent = this;
  this.instance_15.setTransform(486.7, 90.65, 1.1605, 1.1616, 0, 0, 0, 58.5, 52.2);
  this.instance_15._off = true;
  var maskedShapeInstanceList = [this.instance_15];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(116).to({
   _off: false
  }, 0).to({
   _off: true
  }, 93).wait(92));
  this.instance_16 = new lib.bubble_1();
  this.instance_16.parent = this;
  this.instance_16.setTransform(481.3, 93.45, 0.0593, 0.0593, 0, 0, 0, 155.1, 155.1);
  this.instance_16._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(111).to({
   _off: false
  }, 0).to({
   regX: 153.7,
   regY: 153.6,
   scaleX: 0.5156,
   scaleY: 0.5156
  }, 13, cjs.Ease.get(1)).to({
   _off: true
  }, 85).wait(92));
  this.instance_17 = new lib.l1_1();
  this.instance_17.parent = this;
  this.instance_17.setTransform(141.5, 264.8, 1, 1, 0, 0, 0, 141.5, 14.8);
  this.instance_17.alpha = 0;
  this.instance_17._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(31).to({
   _off: false
  }, 0).to({
   alpha: 1
  }, 14, cjs.Ease.get(1)).to({
   _off: true
  }, 66).wait(190));
  this.instance_18 = new lib.bg_g();
  this.instance_18.parent = this;
  this.instance_18.alpha = 0;
  this.instance_18._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(96).to({
   _off: false
  }, 0).to({
   alpha: 1
  }, 14, cjs.Ease.get(1)).to({
   _off: true
  }, 99).wait(92));
  this.instance_19 = new lib.bubble_1();
  this.instance_19.parent = this;
  this.instance_19.setTransform(290.75, 150.65, 0.0888, 0.0888, 0, 0, 0, 149.8, 150.4);
  this.instance_19._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(16).to({
   _off: false
  }, 0).to({
   regX: 149.6,
   regY: 149.3,
   scaleX: 0.9623,
   scaleY: 0.9623,
   y: 150.7
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 80).wait(190));
  this.instance_20 = new lib.fish01_float("synched", 0, false);
  this.instance_20.parent = this;
  this.instance_20.setTransform(1296.2, 144.65, 1.0229, 1.0242, 0, 0, 0, 117.7, 101);
  this.instance_20._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_20).wait(11).to({
   _off: false
  }, 0).to({
   regX: 117.8,
   x: 697.6,
   startPosition: 13
  }, 14, cjs.Ease.get(1)).to({
   _off: true
  }, 86).wait(190));
  this.instance_21 = new lib.black_plate();
  this.instance_21.parent = this;
  this.timeline.addTween(cjs.Tween.get(this.instance_21).wait(301));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(0, -4.3, 1442.3, 301.6);
 (lib.JnJ_Motilegas_970x250 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.content();
  this.instance.parent = this;
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));
  this.instance_1 = new lib.black_plate();
  this.instance_1.parent = this;
  this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(485, 125, 485, 125);
 lib.properties = {
  id: '1E4D562F91EE4B408F0AC49B20246D76',
  width: 970,
  height: 250,
  fps: 24,
  color: "#FFFFFF",
  opacity: 1.00,
  manifest: [{
   src: "bubble.png",
   id: "bubble"
  }, {
   src: "fish1.png",
   id: "fish1"
  }, {
   src: "fish2.png",
   id: "fish2"
  }, {
   src: "icon3.png",
   id: "icon3"
  }, {
   src: "packshot.png",
   id: "packshot"
  }, ],
  preloads: []
 };
 (lib.Stage = function(canvas) {
  createjs.Stage.call(this, canvas);
 }).prototype = p = new createjs.Stage();
 p.setAutoPlay = function(autoPlay) {
  this.tickEnabled = autoPlay;
 }
 p.play = function() {
  this.tickEnabled = true;
  this.getChildAt(0).gotoAndPlay(this.getTimelinePosition())
 }
 p.stop = function(ms) {
  if (ms) this.seek(ms);
  this.tickEnabled = false;
 }
 p.seek = function(ms) {
  this.tickEnabled = true;
  this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000);
 }
 p.getDuration = function() {
  return this.getChildAt(0).totalFrames / lib.properties.fps * 1000;
 }
 p.getTimelinePosition = function() {
  return this.getChildAt(0).currentFrame / lib.properties.fps * 1000;
 }
 an.bootcompsLoaded = an.bootcompsLoaded || [];
 if (!an.bootstrapListeners) {
  an.bootstrapListeners = [];
 }
 an.bootstrapCallback = function(fnCallback) {
  an.bootstrapListeners.push(fnCallback);
  if (an.bootcompsLoaded.length > 0) {
   for (var i = 0; i < an.bootcompsLoaded.length; ++i) {
    fnCallback(an.bootcompsLoaded[i]);
   }
  }
 };
 an.compositions = an.compositions || {};
 an.compositions['1E4D562F91EE4B408F0AC49B20246D76'] = {
  getStage: function() {
   return exportRoot.getStage();
  },
  getLibrary: function() {
   return lib;
  },
  getSpriteSheet: function() {
   return ss;
  },
  getImages: function() {
   return img;
  }
 };
 an.compositionLoaded = function(id) {
  an.bootcompsLoaded.push(id);
  for (var j = 0; j < an.bootstrapListeners.length; j++) {
   an.bootstrapListeners[j](id);
  }
 }
 an.getComposition = function(id) {
  return an.compositions[id];
 }
 an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {
  var lastW, lastH, lastS = 1;
  window.addEventListener('resize', resizeCanvas);
  resizeCanvas();

  function resizeCanvas() {
   var w = lib.properties.width,
    h = lib.properties.height;
   var iw = window.innerWidth,
    ih = window.innerHeight;
   var pRatio = window.devicePixelRatio || 1,
    xRatio = iw / w,
    yRatio = ih / h,
    sRatio = 1;
   if (isResp) {
    if ((respDim == 'width' && lastW == iw) || (respDim == 'height' && lastH == ih)) {
     sRatio = lastS;
    } else if (!isScale) {
     if (iw < w || ih < h) sRatio = Math.min(xRatio, yRatio);
    } else if (scaleType == 1) {
     sRatio = Math.min(xRatio, yRatio);
    } else if (scaleType == 2) {
     sRatio = Math.max(xRatio, yRatio);
    }
   }
   domContainers[0].width = w * pRatio * sRatio;
   domContainers[0].height = h * pRatio * sRatio;
   domContainers.forEach(function(container) {
    container.style.width = w * sRatio + 'px';
    container.style.height = h * sRatio + 'px';
   });
   stage.scaleX = pRatio * sRatio;
   stage.scaleY = pRatio * sRatio;
   lastW = iw;
   lastH = ih;
   lastS = sRatio;
   stage.tickOnUpdate = false;
   stage.update();
   stage.tickOnUpdate = true;
  }
 }
})(createjs = createjs || {}, AdobeAn = AdobeAn || {});
var createjs, AdobeAn;