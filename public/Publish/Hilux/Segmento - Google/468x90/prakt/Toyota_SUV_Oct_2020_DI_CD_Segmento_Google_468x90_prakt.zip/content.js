(function(cjs, an) {
 var p;
 var lib = {};
 var ss = {};
 var img = {};
 lib.ssMetadata = [];

 function mc_symbol_clone() {
  var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
  clone.gotoAndStop(this.currentFrame);
  clone.paused = this.paused;
  clone.framerate = this.framerate;
  return clone;
 }

 function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
  var prototype = cjs.extend(symbol, cjs.MovieClip);
  prototype.clone = mc_symbol_clone;
  prototype.nominalBounds = nominalBounds;
  prototype.frameBounds = frameBounds;
  return prototype;
 }
 (lib.t3_bottom_b_3_prakt = function() {
  this.initialize(img.t3_bottom_b_3_prakt);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 162, 39);
 (lib.t3_bottom = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_b_3 = new lib.t3_bottom_b_3_prakt();
  this.cvr_b_3.name = "cvr_b_3";
  this.cvr_b_3.parent = this;
  this.cvr_b_3.setTransform(10, 42, 0.5, 0.5);
  this.timeline.addTween(cjs.Tween.get(this.cvr_b_3).wait(1));
  this.timeline.addTween(cjs.Tween.get(this.cvr_b_3).wait(1));
 }).prototype = getMCSymbolPrototype(lib.t3_bottom, new cjs.Rectangle(8, 40, 166, 47.5), null);
 (lib.t2_top_t_2_prakt = function() {
  this.initialize(img.t2_top_t_2_prakt);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 224, 11);
 (lib.t2_top = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_t_2 = new lib.t2_top_t_2_prakt();
  this.cvr_t_2.name = "cvr_t_2";
  this.cvr_t_2.parent = this;
  this.cvr_t_2.setTransform(9, 4, 0.5, 0.5);
  this.timeline.addTween(cjs.Tween.get(this.cvr_t_2).wait(1));
  this.timeline.addTween(cjs.Tween.get(this.cvr_t_2).wait(1));
 }).prototype = getMCSymbolPrototype(lib.t2_top, new cjs.Rectangle(7, 2, 227.5, 32.5), null);
 (lib.t2_bottom_b_2_prakt = function() {
  this.initialize(img.t2_bottom_b_2_prakt);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 125, 39);
 (lib.t2_bottom = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_b_2 = new lib.t2_bottom_b_2_prakt();
  this.cvr_b_2.name = "cvr_b_2";
  this.cvr_b_2.parent = this;
  this.cvr_b_2.setTransform(10, 42, 0.5, 0.5);
  this.timeline.addTween(cjs.Tween.get(this.cvr_b_2).wait(1));
  this.timeline.addTween(cjs.Tween.get(this.cvr_b_2).wait(1));
 }).prototype = getMCSymbolPrototype(lib.t2_bottom, new cjs.Rectangle(8, 40, 129, 47.5), null);
 (lib.t1_top_t_1_prakt = function() {
  this.initialize(img.t1_top_t_1_prakt);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 164, 11);
 (lib.t1_top = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_t_1 = new lib.t1_top_t_1_prakt();
  this.cvr_t_1.name = "cvr_t_1";
  this.cvr_t_1.parent = this;
  this.cvr_t_1.setTransform(9, 4, 0.5, 0.5);
  this.timeline.addTween(cjs.Tween.get(this.cvr_t_1).wait(1));
  this.timeline.addTween(cjs.Tween.get(this.cvr_t_1).wait(1));
 }).prototype = getMCSymbolPrototype(lib.t1_top, new cjs.Rectangle(7, 2, 168, 32.5), null);
 (lib.t1_bottom_b_1_prakt = function() {
  this.initialize(img.t1_bottom_b_1_prakt);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 170, 39);
 (lib.t1_bottom = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_b_1 = new lib.t1_bottom_b_1_prakt();
  this.cvr_b_1.name = "cvr_b_1";
  this.cvr_b_1.parent = this;
  this.cvr_b_1.setTransform(10, 42, 0.5, 0.5);
  this.timeline.addTween(cjs.Tween.get(this.cvr_b_1).wait(1));
  this.timeline.addTween(cjs.Tween.get(this.cvr_b_1).wait(1));
 }).prototype = getMCSymbolPrototype(lib.t1_bottom, new cjs.Rectangle(8, 40, 174, 47.5), null);
 (lib.t_4_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#FFFFFF").s().p("AgeBAIAAgZIgPAAIAAgLIAPAAIAAgMIgPAAIAAgNIAPAAIAAhCIAhAAQAWAAAKAKQALALAAASQAAALgFAJQgEAIgKAFQgKAGgOABIgUAAIAAAMIAfAAIAAALIgfAAIAAAZgAgRADIAUAAQAIAAAHgDQAGgCAFgHQADgGABgJQgBgKgDgGQgFgGgGgCQgHgDgIAAIgUAAg");
  this.shape.setTransform(131.3, 53.6);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#FFFFFF").s().p("Ag3B8QgUgTgJgfQgIggAAgpQAAgpAJggQAIggAUgSQAVgTAigBQAjABAVATQAUASAJAgQAIAhAAAoQAAAqgIAfQgJAggUASQgVASgjAAQgiAAgVgSgAgihcQgLAPgEAYQgEAZAAAcQAAAfAEAXQAEAYALAPQAMAOAWAAQAXAAAMgOQAMgPAEgYQAEgYgBgeQABgcgEgZQgEgYgMgPQgMgOgXgBQgWABgMAOg");
  this.shape_1.setTransform(115.0264, 59.65);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#FFFFFF").s().p("Ag3B8QgUgTgJgfQgIggAAgpQAAgpAJggQAIggAUgSQAVgTAigBQAjABAVATQAUASAJAgQAIAhAAAoQAAAqgIAfQgJAggUASQgVASgjAAQgiAAgVgSgAgihcQgLAPgEAYQgEAZAAAcQAAAfAEAXQAEAYALAPQAMAOAWAAQAXAAAMgOQAMgPAEgYQAEgYgBgeQABgcgEgZQgEgYgMgPQgMgOgXgBQgWABgMAOg");
  this.shape_2.setTransform(95.9764, 59.65);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#FFFFFF").s().p("Ag3B8QgUgTgJgfQgIggAAgpQAAgpAJggQAIggAUgSQAVgTAigBQAjABAVATQAUASAJAgQAIAhAAAoQAAAqgIAfQgJAggUASQgVASgjAAQgiAAgVgSgAgihcQgLAPgEAYQgEAZAAAcQAAAfAEAXQAEAYALAPQAMAOAWAAQAXAAAMgOQAMgPAEgYQAEgYgBgeQABgcgEgZQgEgYgMgPQgMgOgXgBQgWABgMAOg");
  this.shape_3.setTransform(76.9264, 59.65);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#FFFFFF").s().p("Ag3B8QgUgTgJgfQgIggAAgpQAAgpAJggQAIggAUgSQAVgTAigBQAjABAVATQAUASAJAgQAIAhAAAoQAAAqgIAfQgJAggUASQgVASgjAAQgiAAgVgSgAgihcQgLAPgEAYQgEAZAAAcQAAAfAEAXQAEAYALAPQAMAOAWAAQAXAAAMgOQAMgPAEgYQAEgYgBgeQABgcgEgZQgEgYgMgPQgMgOgXgBQgWABgMAOg");
  this.shape_4.setTransform(52.1764, 59.65);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#FFFFFF").s().p("Ag3B8QgUgTgJgfQgIggAAgpQAAgpAJggQAIggAUgSQAVgTAigBQAjABAVATQAUASAJAgQAIAhAAAoQAAAqgIAfQgJAggUASQgVASgjAAQgiAAgVgSgAgihcQgLAPgEAYQgEAZAAAcQAAAfAEAXQAEAYALAPQAMAOAWAAQAXAAAMgOQAMgPAEgYQAEgYgBgeQABgcgEgZQgEgYgMgPQgMgOgXgBQgWABgMAOg");
  this.shape_5.setTransform(33.1264, 59.65);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#FFFFFF").s().p("AAKCMIAAjjIg6AnIAAglIBSg1IAPAAIAAEWg");
  this.shape_6.setTransform(15.15, 59.55);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
 }).prototype = getMCSymbolPrototype(lib.t_4_1, new cjs.Rectangle(6, 26, 258.6, 59.599999999999994), null);
 (lib.t_4 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#1E1C1E").s().p("AAQAgIAAgcIgfAAIAAAcIgKAAIAAg/IAKAAIAAAcIAfAAIAAgcIAKAAIAAA/g");
  this.shape.setTransform(129.075, 34.3);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#1E1C1E").s().p("AASAgIAAgxIgiAxIgJAAIAAg/IAJAAIAAAxIAigxIAJAAIAAA/g");
  this.shape_1.setTransform(122.25, 34.3);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#1E1C1E").s().p("AgPADIAAgFIAfAAIAAAFg");
  this.shape_2.setTransform(116.85, 35.05);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#1E1C1E").s().p("AAXAoIAAgQIgsAAIAAAQIgIAAIAAgYIAEAAQAAAAABAAQAAAAABAAQAAAAAAgBQABAAAAgBIADgFIACgHIAEgpIAjAAIAAA3IAIAAIAAAYgAgJACIgBAJIgDAFIAaAAIAAguIgSAAg");
  this.shape_3.setTransform(111.625, 35.075);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#1E1C1E").s().p("AARApIAAgyIgiAyIgJAAIAAg/IAJAAIAAAwIAigwIAJAAIAAA/gAgKgfQgEgDABgFIAFAAQABADACABIAFABIAGgBQACgBAAgDIAHAAQgBAFgEADQgEACgGABQgGgBgEgCg");
  this.shape_4.setTransform(105.1, 33.45);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#1E1C1E").s().p("AgRAgIAAg/IAjAAIAAAJIgaAAIAAATIAZAAIAAAHIgZAAIAAAUIAbAAIAAAIg");
  this.shape_5.setTransform(99.2, 34.3);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#1E1C1E").s().p("AgUAgIAAg/IAUAAQAGAAAFACQAFADACAEQADAFAAAGQAAAGgDAEQgCAEgFADQgFACgGABIgKAAIAAAXgAgKABIAIAAQADAAADgBQADgBACgDQACgDAAgEQAAgFgCgCIgFgEIgGgBIgIAAg");
  this.shape_6.setTransform(94.175, 34.3);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#1E1C1E").s().p("AgEAgIAAg2IgRAAIAAgJIArAAIAAAJIgRAAIAAA2g");
  this.shape_7.setTransform(88.95, 34.3);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#1E1C1E").s().p("AgQAdQgHgFgFgHQgFgHAAgKQAAgJAFgHQAFgHAHgFQAHgEAJAAQAJAAAIAEQAIAFAEAHQAEAHABAJQgBAJgEAIQgEAHgIAFQgIAEgJAAQgJAAgHgEgAgLgUQgFADgEAFQgDAGAAAGQAAAHADAFQAEAGAFADQAFADAGAAQAHAAAGgDQAEgDADgGQAEgFAAgHQAAgGgEgGQgDgFgEgDQgGgDgHAAQgGAAgFADg");
  this.shape_8.setTransform(80.7, 34.3);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#1E1C1E").s().p("AAQAgIAAg2IgfAAIAAA2IgJAAIAAg/IAxAAIAAA/g");
  this.shape_9.setTransform(73.575, 34.3);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.f("#1E1C1E").s().p("AARApIAAgyIgiAyIgJAAIAAg/IAJAAIAAAwIAigwIAJAAIAAA/gAgKgfQgEgDABgFIAFAAQABADACABIAFABIAGgBQACgBAAgDIAHAAQgBAFgDADQgFACgGABQgGgBgEgCg");
  this.shape_10.setTransform(64.7, 33.45);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.f("#1E1C1E").s().p("AgQAdQgIgFgEgHQgEgHgBgKQABgJAEgHQAEgHAIgFQAIgEAIAAQAKAAAHAEQAHAFAFAHQAEAHABAJQgBAJgEAIQgFAHgHAFQgHAEgKAAQgIAAgIgEgAgMgUQgFADgDAFQgDAGAAAGQAAAHADAFQADAGAFADQAGADAGAAQAHAAAFgDQAGgDACgGQAEgFAAgHQAAgGgEgGQgCgFgGgDQgFgDgHAAQgGAAgGADg");
  this.shape_11.setTransform(57.45, 34.3);
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.f("#1E1C1E").s().p("AAXAoIAAgQIgsAAIAAAQIgIAAIAAgYIAEAAQAAAAABAAQAAAAABAAQAAAAAAgBQABAAAAgBIADgFIACgHIAEgpIAjAAIAAA3IAIAAIAAAYgAgJACIgBAJIgDAFIAaAAIAAguIgSAAg");
  this.shape_12.setTransform(50.375, 35.075);
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.f("#1E1C1E").s().p("AgQAdQgIgFgEgHQgEgHgBgKQABgJAEgHQAEgHAIgFQAIgEAIAAQAKAAAHAEQAHAFAFAHQAEAHABAJQgBAJgEAIQgFAHgHAFQgHAEgKAAQgIAAgIgEgAgMgUQgFADgDAFQgDAGAAAGQAAAHADAFQADAGAFADQAGADAGAAQAHAAAFgDQAGgDACgGQAEgFAAgHQAAgGgEgGQgCgFgGgDQgFgDgHAAQgGAAgGADg");
  this.shape_13.setTransform(43.5, 34.3);
  this.shape_14 = new cjs.Shape();
  this.shape_14.graphics.f("#1E1C1E").s().p("AgRAgIAAg/IAjAAIAAAJIgaAAIAAA2g");
  this.shape_14.setTransform(37.725, 34.3);
  this.shape_15 = new cjs.Shape();
  this.shape_15.graphics.f("#1E1C1E").s().p("AAYAgIAAg/IAJAAIAAA/gAggAgIAAg/IAKAAIAAAbIANAAQAHAAAEACQAEACADADQACAEAAAGQAAAGgCADQgDAFgEADQgEACgHAAgAgWAYIAMAAQAGAAAEgCQABgDAAgGQAAgGgCgCQgDgDgGABIgMAAg");
  this.shape_15.setTransform(31, 34.3);
  this.shape_16 = new cjs.Shape();
  this.shape_16.graphics.f("#1E1C1E").s().p("AgVAgIAAg/IAUAAQAJAAAEAFQAFAEABAIQAAADgCAFQgCADgFACQAGABADAEQADAEAAAGQAAAFgCAEQgCAFgFACQgEACgGAAgAgLAYIAMAAQAFAAAEgCQADgEgBgFQABgEgDgDQgEgCgEgBIgNAAgAgLgDIAKAAQACAAADgBQABgBAAAAQABAAAAgBQABAAAAgBQAAAAAAgBQACgDAAgDQAAgEgDgDQgDgCgFAAIgJAAg");
  this.shape_16.setTransform(24.4, 34.3);
  this.shape_17 = new cjs.Shape();
  this.shape_17.graphics.f("#1E1C1E").s().p("AgLAdQgHgFgEgHQgFgIAAgJQAAgJAFgHQAEgHAIgFQAHgEAJAAQAGAAAFACQAGACAEADIgDAJIgIgGQgFgBgFAAQgGAAgGADQgFADgDAFQgDAGAAAGQAAAHADAFQADAGAFADQAGADAGAAQAGAAAFgCQAFgCADgCIADAIQgFADgFACQgGACgHAAQgIAAgIgEg");
  this.shape_17.setTransform(16.275, 34.3);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_17
   }, {
    t: this.shape_16
   }, {
    t: this.shape_15
   }, {
    t: this.shape_14
   }, {
    t: this.shape_13
   }, {
    t: this.shape_12
   }, {
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
  this.shape_18 = new cjs.Shape();
  this.shape_18.graphics.f("#FFFFFF").s().p("Ap1BLIAAiVITrAAIAACVg");
  this.shape_18.setTransform(73, 34.5);
  this.timeline.addTween(cjs.Tween.get(this.shape_18).wait(1));
 }).prototype = getMCSymbolPrototype(lib.t_4, new cjs.Rectangle(10, 25, 128.1, 17), null);
 (lib.snoska_1_snoska_prakt = function() {
  this.initialize(img.snoska_1_snoska_prakt);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 134, 8);
 (lib.snoska_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_snoska = new lib.snoska_1_snoska_prakt();
  this.cvr_snoska.name = "cvr_snoska";
  this.cvr_snoska.parent = this;
  this.cvr_snoska.setTransform(461.05, 69, 0.5, 0.5);
  this.timeline.addTween(cjs.Tween.get(this.cvr_snoska).wait(1));
  this.cvr_snoska.x -= 134;
  this.timeline.addTween(cjs.Tween.get(this.cvr_snoska).wait(1));
 }).prototype = getMCSymbolPrototype(lib.snoska_1, new cjs.Rectangle(325, 67, 138.10000000000002, 19.700000000000003), null);
 (lib.plate_red = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.rf(["#EC0A1F", "#61141E", "#000000"], [0, 0.561, 1], 76, -85.2, 0, 76, -85.2, 63.1).s().p("Avd1cIe7AAMge7Aq5g");
  this.shape.setTransform(99, 137.25);
  this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("rgba(108,110,111,0.247)").s().p("Ax442MAjxAAAMgjxAxsg");
  this.shape_1.setTransform(114.5, 159.05);
  this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));
 }).prototype = getMCSymbolPrototype(lib.plate_red, new cjs.Rectangle(0, 0, 229, 318.1), null);
 (lib.pic3_1_1_i_3_prakt = function() {
  this.initialize(img.pic3_1_1_i_3_prakt);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 1056, 180);
 (lib.pic3_1_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_i_3 = new lib.pic3_1_1_i_3_prakt();
  this.cvr_i_3.name = "cvr_i_3";
  this.cvr_i_3.parent = this;
  this.cvr_i_3.setTransform(0, 0, 0.5, 0.5);
  this.timeline.addTween(cjs.Tween.get(this.cvr_i_3).wait(1));
 }).prototype = getMCSymbolPrototype(lib.pic3_1_1, new cjs.Rectangle(0, 0, 528, 90), null);
 (lib.pic2_1_1_i_2_prakt = function() {
  this.initialize(img.pic2_1_1_i_2_prakt);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 1056, 180);
 (lib.pic2_1_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_i_2 = new lib.pic2_1_1_i_2_prakt();
  this.cvr_i_2.name = "cvr_i_2";
  this.cvr_i_2.parent = this;
  this.cvr_i_2.setTransform(0, 0, 0.5, 0.5);
  this.timeline.addTween(cjs.Tween.get(this.cvr_i_2).wait(1));
 }).prototype = getMCSymbolPrototype(lib.pic2_1_1, new cjs.Rectangle(0, 0, 528, 90), null);
 (lib.pic1_1_1_i_1_prakt = function() {
  this.initialize(img.pic1_1_1_i_1_prakt);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 936, 180);
 (lib.pic1_1_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_i_1 = new lib.pic1_1_1_i_1_prakt();
  this.cvr_i_1.name = "cvr_i_1";
  this.cvr_i_1.parent = this;
  this.cvr_i_1.setTransform(0, 0, 0.75, 0.75);
  this.timeline.addTween(cjs.Tween.get(this.cvr_i_1).wait(1));
 }).prototype = getMCSymbolPrototype(lib.pic1_1_1, new cjs.Rectangle(0, 0, 702, 135), null);
 (lib.logo_s = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#FFFFFF").s().p("AiNBcQg7gmAAg2QAAg1A7gmQA6gmBTAAQBUAAA6AmQA7AmAAA1QAAA2g7AmQg6AmhUAAQhTAAg6gmgACVg9QAAAagrATQgZALgfAFIAAAEQAAAxgPAhQgJAVgKAIQA7gEAugeQAZgRANgWQAOgWAAgYQAAgYgNgVQgEgIgHgHIAAADgAifgxQgNAVAAAYQAAAYAOAWQANAWAZARQAZAQAeAKQAYAGAaACQgLgIgIgVQgPghAAgxIAAgEQgegFgagLQgrgTAAgaIAAgCIgLAOgAgVAzQAJAXAMgBQANABAJgXQAIgVABgdQgPACgQgBQgPABgPgCQABAdAIAVgAgVg6QgFANgCAOIAcACIAdgCQgCgOgFgNQgJgWgNAAQgMAAgJAWgAAjhMQAIATAEAYQATgDAQgGQAigMAAgRQAAgRgigMQgNgEgPgDIgNgCIgmgDIgDAAIgDAAIgtAEIgJABIgYAHQgiAMAAARQAAARAiAMQAQAHATACQADgYAJgTQAOgiAUAAQAVAAAOAig");
  this.shape.setTransform(20.125, 13);
  this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
 }).prototype = getMCSymbolPrototype(lib.logo_s, new cjs.Rectangle(0, 0, 40.3, 26), null);
 (lib.line_red_large = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f().s("#FF0022").ss(2, 1, 1).p("AqdO1IU79p");
  this.shape.setTransform(67, -36);
  this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
 }).prototype = getMCSymbolPrototype(lib.line_red_large, new cjs.Rectangle(-1, -131.9, 136, 191.9), null);
 (lib.line_red = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f().s("#FF0022").ss(2, 1, 1).p("AjNEnIGbpN");
  this.shape.setTransform(20.55, 29.475);
  this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
 }).prototype = getMCSymbolPrototype(lib.line_red, new cjs.Rectangle(-1, -1, 43.1, 61), null);
 (lib.legal_02_d2_prakt = function() {
  this.initialize(img.legal_02_d2_prakt);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 415, 24);
 (lib.legal_02 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_d2 = new lib.legal_02_d2_prakt();
  this.cvr_d2.name = "cvr_d2";
  this.cvr_d2.parent = this;
  this.cvr_d2.setTransform(10, 8, 0.5, 0.5);
  this.timeline.addTween(cjs.Tween.get(this.cvr_d2).wait(1));
  this.timeline.addTween(cjs.Tween.get(this.cvr_d2).wait(1));
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#1E1C1E").s().p("EgkjAHCIAAuDMBJHAAAIAAODg");
  this.shape.setTransform(234, 45);
  this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
 }).prototype = getMCSymbolPrototype(lib.legal_02, new cjs.Rectangle(0, 0, 468, 90), null);
 (lib.legal_01_d1_prakt = function() {
  this.initialize(img.legal_01_d1_prakt);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 415, 77);
 (lib.legal_01 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_d1 = new lib.legal_01_d1_prakt();
  this.cvr_d1.name = "cvr_d1";
  this.cvr_d1.parent = this;
  this.cvr_d1.setTransform(10, 8, 0.5, 0.5);
  this.timeline.addTween(cjs.Tween.get(this.cvr_d1).wait(1));
  this.timeline.addTween(cjs.Tween.get(this.cvr_d1).wait(1));
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#1E1C1E").s().p("EgkjAHCIAAuDMBJHAAAIAAODg");
  this.shape.setTransform(234, 45);
  this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
 }).prototype = getMCSymbolPrototype(lib.legal_01, new cjs.Rectangle(0, 0, 468, 90), null);
 (lib.icon_1_icon_prakt = function() {
  this.initialize(img.icon_1_icon_prakt);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 160, 144);
 (lib.icon_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_icon = new lib.icon_1_icon_prakt();
  this.cvr_icon.name = "cvr_icon";
  this.cvr_icon.parent = this;
  this.cvr_icon.setTransform(0, 0, 1, 1);
  this.timeline.addTween(cjs.Tween.get(this.cvr_icon).wait(1));
 }).prototype = getMCSymbolPrototype(lib.icon_1, new cjs.Rectangle(0, 0, 160, 144), null);
 (lib.gray_plate = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.lf(["#BCBCBC", "#737576", "#4D5051", "#1A1F20"], [0, 0.349, 0.635, 1], -16.9, 14, -10.8, -8.6).s().p("AjCEMIGFoXIAAIXg");
  this.shape.setTransform(450.6, 65.275);
  this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
 }).prototype = getMCSymbolPrototype(lib.gray_plate, new cjs.Rectangle(431.1, 38.5, 39, 53.599999999999994), null);
 (lib.btn1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#FFFFFF").s().p("AgWAnIAAhNIAsAAIAAAKIggAAIAAAYIAfAAIAAAJIgfAAIAAAYIAhAAIAAAKg");
  this.shape.setTransform(124.825, 12.95);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#FFFFFF").s().p("AgzAnIAAhNIAMAAIAABDIAiAAIAAhDIALAAIAABDIAiAAIAAhDIAMAAIAABNg");
  this.shape_1.setTransform(115.075, 12.95);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#FFFFFF").s().p("AgaAnIAAhNIAMAAIAAAhIAPAAQAJAAAFACQAGADADAEQADAFAAAGQAAAIgDAEQgDAGgGADQgFADgJAAgAgOAeIAOAAQAHAAAEgEQAEgDAAgIQAAgGgEgDQgEgDgHAAIgOAAg");
  this.shape_2.setTransform(105.525, 12.95);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#FFFFFF").s().p("AgcAnIgEgBIACgKIACABIAEAAQADABABgDQACgDAAgFIAFg5IAtAAIAABMIgLAAIAAhCIgYAAIgEAyQgBAJgEAEQgEAFgHgBIgFAAg");
  this.shape_3.setTransform(97.3, 13);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#FFFFFF").s().p("AgUAjQgJgFgGgJQgFgJAAgMQAAgLAFgJQAGgJAJgFQAJgFALAAQAMAAAJAFQAJAFAFAJQAFAJABALQgBAMgFAJQgFAJgJAFQgJAFgMAAQgLAAgJgFgAgOgYQgHADgEAHQgDAGAAAIQAAAJADAGQAEAHAHADQAGAFAIAAQAIAAAHgFQAGgDAEgHQAEgGAAgJQAAgIgEgGQgEgHgGgDQgHgFgIAAQgIAAgGAFg");
  this.shape_4.setTransform(89.175, 12.95);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#FFFFFF").s().p("AgaAnIAAhNIArAAIAAAKIgfAAIAAAXIAPAAQAJAAAFACQAGADADAEQADAFAAAGQAAAIgDAEQgDAGgGADQgFADgJAAgAgOAeIAOAAQAHAAAEgEQAEgDAAgIQAAgGgEgDQgEgDgHAAIgOAAg");
  this.shape_5.setTransform(81.125, 12.95);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#FFFFFF").s().p("AgaAnIAAhNIAMAAIAAAhIAPAAQAJAAAFACQAGADADAEQADAFAAAGQAAAIgDAEQgDAGgGADQgFADgJAAgAgOAeIAOAAQAHAAAEgEQAEgDAAgIQAAgGgEgDQgEgDgHAAIgOAAg");
  this.shape_6.setTransform(71.175, 12.95);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#FFFFFF").s().p("AgFAnIAAhDIgVAAIAAgKIA1AAIAAAKIgVAAIAABDg");
  this.shape_7.setTransform(64.3, 12.95);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#FFFFFF").s().p("AAYAnIgJgYIgdAAIgJAYIgMAAIAehNIALAAIAdBNgAAMAGIgMggIgLAgIAXAAg");
  this.shape_8.setTransform(57.4, 12.95);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#FFFFFF").s().p("AAUAnIAAgiIgnAAIAAAiIgLAAIAAhNIALAAIAAAiIAnAAIAAgiIALAAIAABNg");
  this.shape_9.setTransform(49.275, 12.95);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.f("#FFFFFF").s().p("AgQAlQgHgDgEgEIAFgJQAEAEAFACQAGADAHAAQAHAAAFgEQAFgDAAgHQAAgGgGgEQgGgDgMAAIAAgIQAIAAAFgCQAEgCACgDQACgDAAgDQAAgFgEgEQgEgDgGAAQgFABgFACQgFACgEADIgFgIQAFgEAGgDQAGgCAIAAQALAAAHAFQAGAFAAAJQAAAHgEAFQgEAFgHABQAJACAEAEQAFAFAAAIQAAAHgDAFQgDAGgHACQgGADgJAAQgJAAgHgDg");
  this.shape_10.setTransform(41.525, 12.95);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.f("#FFFFFF").s().p("AgVAnIgGgCIACgJIAFABIAEABQAFAAADgCQADgCACgGIgeg6IAMAAIAXAvIAVgvIALAAIgaA5QgCAGgDAFQgDAEgDADQgEACgIAAIgGAAg");
  this.shape_11.setTransform(34.8, 13);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).to({
   state: []
  }, 3).wait(1));
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.f("rgba(0,0,0,0.247)").s().p("AsYCHICzkNIV+AAIi5ENg");
  this.shape_12.setTransform(79.325, 13.5);
  this.shape_12._off = true;
  this.timeline.addTween(cjs.Tween.get(this.shape_12).wait(1).to({
   _off: false
  }, 0).to({
   _off: true
  }, 2).wait(1));
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.lf(["#FF0022", "#B21423"], [0, 1], -79.4, -0.2, 75.4, -0.2).s().p("AsYCHICzkNIV+AAIi5ENg");
  this.shape_13.setTransform(79.325, 13.5);
  this.timeline.addTween(cjs.Tween.get(this.shape_13).wait(4));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(0, 0, 158.7, 27);
 (lib.black_plate = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#000000").s().p("EgkjAHCIAAuDMBJHAAAIAAODg");
  this.shape.setTransform(234, 45);
  this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
 }).prototype = getMCSymbolPrototype(lib.black_plate, new cjs.Rectangle(0, 0, 468, 90), null);
 (lib.txt_4 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.t_4();
  this.instance.parent = this;
  this.instance.setTransform(36, 11.5, 1, 1, 0, 0, 0, 66, 11.5);
  this.instance.alpha = 0;
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   x: 66,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(6));
  this.instance_1 = new lib.t_4_1();
  this.instance_1.parent = this;
  this.instance_1.setTransform(99.2, 37.6, 1, 1, 0, 0, 0, 129.2, 37.6);
  this.instance_1.alpha = 0;
  this.instance_1._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(4).to({
   _off: false
  }, 0).to({
   x: 129.2,
   alpha: 1
  }, 15, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(-24, 25, 288.6, 60.599999999999994);
 (lib.txt_3_bottom = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.t3_bottom();
  this.instance.parent = this;
  this.instance.setTransform(61.9, 55.5, 1, 1, 0, 0, 0, 101.9, 55.5);
  this.instance.alpha = 0;
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   x: 101.9,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(-32, 40, 206, 47.5);
 (lib.txt_2_top = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.t2_top();
  this.instance.parent = this;
  this.instance.setTransform(61.9, 55.5, 1, 1, 0, 0, 0, 101.9, 55.5);
  this.instance.alpha = 0;
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   x: 101.9,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(-33, 2, 267.5, 32.5);
 (lib.txt_2_bottom = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.t2_bottom();
  this.instance.parent = this;
  this.instance.setTransform(61.9, 55.5, 1, 1, 0, 0, 0, 101.9, 55.5);
  this.instance.alpha = 0;
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   x: 101.9,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(-32, 40, 169, 47.5);
 (lib.txt_1_top = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.t1_top();
  this.instance.parent = this;
  this.instance.setTransform(61.9, 55.5, 1, 1, 0, 0, 0, 101.9, 55.5);
  this.instance.alpha = 0;
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   x: 101.9,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(-33, 2, 208, 32.5);
 (lib.txt_1_bottom = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.t1_bottom();
  this.instance.parent = this;
  this.instance.setTransform(61.9, 55.5, 1, 1, 0, 0, 0, 101.9, 55.5);
  this.instance.alpha = 0;
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   x: 101.9,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(-32, 40, 214, 47.5);
 (lib.snoska = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.snoska_1();
  this.instance.parent = this;
  this.instance.setTransform(61.9, 55.5, 1, 1, 0, 0, 0, 101.9, 55.5);
  this.instance.alpha = 0;
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   x: 101.9,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(285, 67, 178.10000000000002, 19.700000000000003);
 (lib.pic3_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_i_3 = new lib.pic3_1_1();
  this.cvr_i_3.name = "cvr_i_3";
  this.cvr_i_3.parent = this;
  this.cvr_i_3.setTransform(394, 66.7, 1, 1, 0, 0, 0, 394, 66.7);
  this.timeline.addTween(cjs.Tween.get(this.cvr_i_3).wait(1));
 }).prototype = getMCSymbolPrototype(lib.pic3_1, new cjs.Rectangle(0, 0, 528, 90), null);
 (lib.pic3_2 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.pic3_1();
  this.instance.parent = this;
  this.instance.setTransform(180, 300, 1, 1, 0, 0, 0, 180, 300);
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   x: 130
  }, 34, cjs.Ease.get(0.5)).to({
   x: 120
  }, 35, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(-60, 0, 588, 90.1);
 (lib.pic2_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_i_2 = new lib.pic2_1_1();
  this.cvr_i_2.name = "cvr_i_2";
  this.cvr_i_2.parent = this;
  this.cvr_i_2.setTransform(394, 45, 1, 1, 0, 0, 0, 394, 45);
  this.timeline.addTween(cjs.Tween.get(this.cvr_i_2).wait(1));
 }).prototype = getMCSymbolPrototype(lib.pic2_1, new cjs.Rectangle(0, 0, 528, 90), null);
 (lib.pic2_2 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.pic2_1();
  this.instance.parent = this;
  this.instance.setTransform(180, 299.9, 0.9999, 1, 0, 0, 0, 180, 299.9);
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   x: 130
  }, 34, cjs.Ease.get(0.5)).to({
   x: 120
  }, 35, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(-60, 0, 588, 90);
 (lib.pic1_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_i_1 = new lib.pic1_1_1();
  this.cvr_i_1.name = "cvr_i_1";
  this.cvr_i_1.parent = this;
  this.cvr_i_1.setTransform(546, 67.5, 1, 1, 0, 0, 0, 546, 67.5);
  this.timeline.addTween(cjs.Tween.get(this.cvr_i_1).wait(1));
 }).prototype = getMCSymbolPrototype(lib.pic1_1, new cjs.Rectangle(0, 0, 702, 135), null);
 (lib.pic1_2 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.pic1_1();
  this.instance.parent = this;
  this.instance.setTransform(-117, -23);
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   scaleX: 0.771,
   scaleY: 0.771,
   x: -36.6,
   y: -7.25
  }, 19, cjs.Ease.get(0.5)).to({
   scaleX: 0.6667,
   scaleY: 0.6667,
   x: 0,
   y: 0
  }, 75, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(-117, -23, 702, 135);
 (lib.lines_red_bottom = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.line_red_large();
  this.instance.parent = this;
  this.instance.setTransform(314.55, 249.4, 1, 1, 0, 0, 0, 20.6, 29.4);
  this.instance.alpha = 0;
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   x: 357.55,
   y: 188.45,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(293, 27.1, 179, 252.9);
 (lib.lines_red = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.line_red();
  this.instance.parent = this;
  this.instance.setTransform(111.7, 89.7, 1, 1, 0, 0, 0, 20.6, 29.4);
  this.instance.alpha = 0;
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   x: 98.35,
   y: 108.3,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(1));
  this.instance_1 = new lib.line_red();
  this.instance_1.parent = this;
  this.instance_1.setTransform(164.55, 14.05, 1, 1, 0, 0, 0, 20.6, 29.4);
  this.instance_1.alpha = 0;
  this.timeline.addTween(cjs.Tween.get(this.instance_1).to({
   x: 181.7,
   y: -10.3,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(76.8, -40.7, 126.39999999999999, 179.60000000000002);
 (lib.icon = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_icon = new lib.icon_1();
  this.cvr_icon.name = "cvr_icon";
  this.cvr_icon.parent = this;
  this.cvr_icon.setTransform(80, 72, 1, 1, 0, 0, 0, 80, 72);
  this.timeline.addTween(cjs.Tween.get(this.cvr_icon).wait(1));
 }).prototype = getMCSymbolPrototype(lib.icon, new cjs.Rectangle(0, 0, 160, 144), null);
 (lib.pic4 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.pic1_1();
  this.instance.parent = this;
  this.instance.setTransform(-117, -23);
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   scaleX: 0.771,
   scaleY: 0.771,
   x: -36.6,
   y: -7.25
  }, 19, cjs.Ease.get(0.5)).to({
   scaleX: 0.6667,
   scaleY: 0.6667,
   x: 0,
   y: 0
  }, 75, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(-117, -23, 702, 135);
 (lib.content = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {
   cvr_frame1_3: 83,
   cvr_frame2_2: 143,
   cvr_frame3_1: 203,
   "cvr_frame#4_4": 290,
   cvr_stay: 301,
   cvr_frame5: 393,
   cvr_frame6: 505
  });
  this.instance = new lib.logo_s();
  this.instance.parent = this;
  this.instance.setTransform(433.1, 9.25, 0.6211, 0.6192, 0, 0, 0, 0.2, 0.4);
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(528));
  this.instance_1 = new lib.black_plate();
  this.instance_1.parent = this;
  this.timeline.addTween(cjs.Tween.get(this.instance_1).to({
   alpha: 0
  }, 14, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(497).to({
   _off: false
  }, 0).to({
   alpha: 1
  }, 15, cjs.Ease.get(-1)).wait(1));
  this.instance_2 = new lib.legal_02();
  this.instance_2.parent = this;
  this.instance_2.setTransform(120, 200, 1, 1, 0, 0, 0, 120, 200);
  this.instance_2.alpha = 0;
  this.instance_2._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(397).to({
   _off: false
  }, 0).to({
   alpha: 1
  }, 15).wait(116));
  this.instance_3 = new lib.legal_01();
  this.instance_3.parent = this;
  this.instance_3.setTransform(120, 200, 1, 1, 0, 0, 0, 120, 200);
  this.instance_3.alpha = 0;
  this.instance_3._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(297).to({
   _off: false
  }, 0).to({
   alpha: 1
  }, 15).to({
   _off: true
  }, 100).wait(116));
  this.cvr_link2_nocatch = new lib.btn1();
  window.cvrTrackButtons[2] = {
   cnvs: this.cvr_link2_nocatch
  };
  this.cvr_link2_nocatch.name = "cvr_link2_nocatch";
  this.cvr_link2_nocatch.parent = this;
  this.cvr_link2_nocatch.setTransform(333, 106.3, 0.8051, 0.8051);
  this.cvr_link2_nocatch.alpha = 0;
  this.cvr_link2_nocatch._off = true;
  new cjs.ButtonHelper(this.cvr_link2_nocatch, 0, 1, 2, false, new lib.btn1(), 3);
  this.timeline.addTween(cjs.Tween.get(this.cvr_link2_nocatch).wait(234).to({
   _off: false
  }, 0).to({
   y: 58,
   alpha: 1
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 63).wait(216));
  this.instance_4 = new lib.txt_2_top("synched", 0, false);
  this.instance_4.parent = this;
  this.instance_4._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(212).to({
   _off: false
  }, 0).to({
   _off: true
  }, 100).wait(216));
  this.instance_5 = new lib.txt_1_top("synched", 0, false);
  this.instance_5.parent = this;
  this.instance_5._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(34).to({
   _off: false
  }, 0).wait(170).to({
   startPosition: 14
  }, 0).to({
   alpha: 0
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(308));
  this.instance_6 = new lib.lines_red_bottom("synched", 0, false);
  this.instance_6.parent = this;
  this.instance_6.setTransform(66.5, 0, 1, 1, 0, 0, 0, 66.5, 0);
  this.instance_6._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(225).to({
   _off: false
  }, 0).to({
   _off: true
  }, 87).wait(216));
  this.instance_7 = new lib.icon();
  this.instance_7.parent = this;
  this.instance_7.setTransform(161.7, 55.55, 0.1854, 0.1853, 0, 0, 0, 83.9, 76.4);
  this.instance_7.alpha = 0;
  this.instance_7._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(84).to({
   _off: false
  }, 0).to({
   regX: 82.7,
   regY: 74.2,
   scaleX: 0.3563,
   scaleY: 0.3561,
   y: 55.5,
   alpha: 1
  }, 15).wait(45).to({
   alpha: 0
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(368));
  this.instance_8 = new lib.lines_red("synched", 0, false);
  this.instance_8.parent = this;
  this.instance_8.setTransform(66.5, 0, 1, 1, 0, 0, 0, 66.5, 0);
  this.instance_8._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(219).to({
   _off: false
  }, 0).to({
   _off: true
  }, 93).wait(216));
  this.instance_9 = new lib.txt_4("synched", 0, false);
  this.instance_9.parent = this;
  this.instance_9.setTransform(66, 11.5, 1, 1, 0, 0, 0, 66, 11.5);
  this.instance_9._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(219).to({
   _off: false
  }, 0).to({
   _off: true
  }, 93).wait(216));
  this.instance_10 = new lib.gray_plate();
  this.instance_10.parent = this;
  this.instance_10.setTransform(68.2, 48.2, 1, 1, 0, 0, 0, 48.2, 48.2);
  this.instance_10.alpha = 0;
  this.instance_10._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(219).to({
   _off: false
  }, 0).to({
   x: 48.2,
   alpha: 1
  }, 10, cjs.Ease.get(1)).to({
   _off: true
  }, 83).wait(216));
  this.instance_11 = new lib.txt_3_bottom("synched", 0, false);
  this.instance_11.parent = this;
  this.instance_11._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(149).to({
   _off: false
  }, 0).wait(55).to({
   startPosition: 14
  }, 0).to({
   alpha: 0
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(308));
  this.instance_12 = new lib.txt_2_bottom("synched", 0, false);
  this.instance_12.parent = this;
  this.instance_12._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(89).to({
   _off: false
  }, 0).wait(55).to({
   startPosition: 14
  }, 0).to({
   alpha: 0
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(368));
  this.instance_13 = new lib.txt_1_bottom("synched", 0, false);
  this.instance_13.parent = this;
  this.instance_13._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(49).to({
   _off: false
  }, 0).wait(35).to({
   startPosition: 14
  }, 0).to({
   alpha: 0
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(428));
  this.instance_14 = new lib.plate_red();
  this.instance_14.parent = this;
  this.instance_14.setTransform(53.2, 129.2, 1, 1, 0, 0, 0, 93.2, 129.2);
  this.instance_14.alpha = 0;
  this.instance_14._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(27).to({
   _off: false
  }, 0).to({
   x: 93.2,
   alpha: 1
  }, 7, cjs.Ease.get(1)).to({
   _off: true
  }, 278).wait(216));
  this.instance_15 = new lib.pic4("synched", 0, false);
  this.instance_15.parent = this;
  this.instance_15.setTransform(180, 300, 1, 1, 0, 0, 0, 180, 300);
  this.instance_15.alpha = 0;
  this.instance_15._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(204).to({
   _off: false
  }, 0).to({
   alpha: 1,
   startPosition: 14
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 93).wait(216));
  this.instance_16 = new lib.pic3_2("synched", 0, false);
  this.instance_16.parent = this;
  this.instance_16.setTransform(180, 300, 1, 1, 0, 0, 0, 180, 300);
  this.instance_16.alpha = 0;
  this.instance_16._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(144).to({
   _off: false
  }, 0).to({
   alpha: 1,
   startPosition: 15
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 61).wait(308));
  this.instance_17 = new lib.snoska("synched", 0, false);
  this.instance_17.parent = this;
  this.instance_17._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(89).to({
   _off: false
  }, 0).to({
   _off: true
  }, 71).wait(368));
  this.instance_18 = new lib.pic2_2("synched", 0, false);
  this.instance_18.parent = this;
  this.instance_18.setTransform(180, 300, 1, 1, 0, 0, 0, 180, 300);
  this.instance_18.alpha = 0;
  this.instance_18._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(84).to({
   _off: false
  }, 0).to({
   alpha: 1,
   startPosition: 15
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 61).wait(368));
  this.instance_19 = new lib.pic1_2("synched", 0, false);
  this.instance_19.parent = this;
  this.instance_19.setTransform(180, 300, 1, 1, 0, 0, 0, 180, 300);
  this.timeline.addTween(cjs.Tween.get(this.instance_19).to({
   _off: true
  }, 100).wait(428));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(-117, -40.7, 702, 358.8);
 (lib.toyota_468x90 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.content();
  this.instance.parent = this;
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));
  this.instance_1 = new lib.black_plate();
  this.instance_1.parent = this;
  this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(117, 22, 468, 90);
 lib.properties = {
  id: '1E4D562F91EE4B408F0AC49B20246D76',
  width: 468,
  height: 90,
  fps: 24,
  color: "#FFFFFF",
  opacity: 1.00,
  manifest: [{
   src: "t3_bottom_b_3_prakt.png",
   id: "t3_bottom_b_3_prakt"
  }, {
   src: "t2_top_t_2_prakt.png",
   id: "t2_top_t_2_prakt"
  }, {
   src: "t2_bottom_b_2_prakt.png",
   id: "t2_bottom_b_2_prakt"
  }, {
   src: "t1_top_t_1_prakt.png",
   id: "t1_top_t_1_prakt"
  }, {
   src: "t1_bottom_b_1_prakt.png",
   id: "t1_bottom_b_1_prakt"
  }, {
   src: "snoska_1_snoska_prakt.png",
   id: "snoska_1_snoska_prakt"
  }, {
   src: "legal_02_d2_prakt.png",
   id: "legal_02_d2_prakt"
  }, {
   src: "legal_01_d1_prakt.png",
   id: "legal_01_d1_prakt"
  }, {
   src: "pic3_1_1_i_3_prakt.jpg",
   id: "pic3_1_1_i_3_prakt"
  }, {
   src: "pic2_1_1_i_2_prakt.jpg",
   id: "pic2_1_1_i_2_prakt"
  }, {
   src: "pic1_1_1_i_1_prakt.jpg",
   id: "pic1_1_1_i_1_prakt"
  }, {
   src: "icon_1_icon_prakt.png",
   id: "icon_1_icon_prakt"
  }, ],
  preloads: []
 };
 (lib.Stage = function(canvas) {
  createjs.Stage.call(this, canvas);
 }).prototype = p = new createjs.Stage();
 p.setAutoPlay = function(autoPlay) {
  this.tickEnabled = autoPlay;
 }
 p.play = function() {
  this.tickEnabled = true;
  this.getChildAt(0).gotoAndPlay(this.getTimelinePosition())
 }
 p.stop = function(ms) {
  if (ms) this.seek(ms);
  this.tickEnabled = false;
 }
 p.seek = function(ms) {
  this.tickEnabled = true;
  this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000);
 }
 p.getDuration = function() {
  return this.getChildAt(0).totalFrames / lib.properties.fps * 1000;
 }
 p.getTimelinePosition = function() {
  return this.getChildAt(0).currentFrame / lib.properties.fps * 1000;
 }
 an.bootcompsLoaded = an.bootcompsLoaded || [];
 if (!an.bootstrapListeners) {
  an.bootstrapListeners = [];
 }
 an.bootstrapCallback = function(fnCallback) {
  an.bootstrapListeners.push(fnCallback);
  if (an.bootcompsLoaded.length > 0) {
   for (var i = 0; i < an.bootcompsLoaded.length; ++i) {
    fnCallback(an.bootcompsLoaded[i]);
   }
  }
 };
 an.compositions = an.compositions || {};
 an.compositions['1E4D562F91EE4B408F0AC49B20246D76'] = {
  getStage: function() {
   return exportRoot.getStage();
  },
  getLibrary: function() {
   return lib;
  },
  getSpriteSheet: function() {
   return ss;
  },
  getImages: function() {
   return img;
  }
 };
 an.compositionLoaded = function(id) {
  an.bootcompsLoaded.push(id);
  for (var j = 0; j < an.bootstrapListeners.length; j++) {
   an.bootstrapListeners[j](id);
  }
 }
 an.getComposition = function(id) {
  return an.compositions[id];
 }
 an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {
  var lastW, lastH, lastS = 1;
  window.addEventListener('resize', resizeCanvas);
  resizeCanvas();

  function resizeCanvas() {
   var w = lib.properties.width,
    h = lib.properties.height;
   var iw = window.innerWidth,
    ih = window.innerHeight;
   var pRatio = window.devicePixelRatio || 1,
    xRatio = iw / w,
    yRatio = ih / h,
    sRatio = 1;
   if (isResp) {
    if ((respDim == 'width' && lastW == iw) || (respDim == 'height' && lastH == ih)) {
     sRatio = lastS;
    } else if (!isScale) {
     if (iw < w || ih < h) sRatio = Math.min(xRatio, yRatio);
    } else if (scaleType == 1) {
     sRatio = Math.min(xRatio, yRatio);
    } else if (scaleType == 2) {
     sRatio = Math.max(xRatio, yRatio);
    }
   }
   domContainers[0].width = w * pRatio * sRatio;
   domContainers[0].height = h * pRatio * sRatio;
   domContainers.forEach(function(container) {
    container.style.width = w * sRatio + 'px';
    container.style.height = h * sRatio + 'px';
   });
   stage.scaleX = pRatio * sRatio;
   stage.scaleY = pRatio * sRatio;
   lastW = iw;
   lastH = ih;
   lastS = sRatio;
   stage.tickOnUpdate = false;
   stage.update();
   stage.tickOnUpdate = true;
  }
 }
})(createjs = createjs || {}, AdobeAn = AdobeAn || {});
var createjs, AdobeAn;