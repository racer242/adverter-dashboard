(function(cjs, an) {
 var p;
 var lib = {};
 var ss = {};
 var img = {};
 lib.ssMetadata = [];

 function mc_symbol_clone() {
  var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
  clone.gotoAndStop(this.currentFrame);
  clone.paused = this.paused;
  clone.framerate = this.framerate;
  return clone;
 }

 function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
  var prototype = cjs.extend(symbol, cjs.MovieClip);
  prototype.clone = mc_symbol_clone;
  prototype.nominalBounds = nominalBounds;
  prototype.frameBounds = frameBounds;
  return prototype;
 }
 (lib.t3_bottom_b_3_vinosl = function() {
  this.initialize(img.t3_bottom_b_3_vinosl);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 312, 54);
 (lib.t3_bottom = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_b_3 = new lib.t3_bottom_b_3_vinosl();
  this.cvr_b_3.name = "cvr_b_3";
  this.cvr_b_3.parent = this;
  this.cvr_b_3.setTransform(12, 213, 0.5, 0.5);
  this.timeline.addTween(cjs.Tween.get(this.cvr_b_3).wait(1));
  this.timeline.addTween(cjs.Tween.get(this.cvr_b_3).wait(1));
 }).prototype = getMCSymbolPrototype(lib.t3_bottom, new cjs.Rectangle(10, 211, 316, 86), null);
 (lib.t2_top_t_2_vinosl = function() {
  this.initialize(img.t2_top_t_2_vinosl);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 200, 44);
 (lib.t2_top = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_t_2 = new lib.t2_top_t_2_vinosl();
  this.cvr_t_2.name = "cvr_t_2";
  this.cvr_t_2.parent = this;
  this.cvr_t_2.setTransform(13.5, 5, 0.5, 0.5);
  this.timeline.addTween(cjs.Tween.get(this.cvr_t_2).wait(1));
  this.timeline.addTween(cjs.Tween.get(this.cvr_t_2).wait(1));
 }).prototype = getMCSymbolPrototype(lib.t2_top, new cjs.Rectangle(11.5, 3, 203.9, 73), null);
 (lib.t2_bottom_b_2_vinosl = function() {
  this.initialize(img.t2_bottom_b_2_vinosl);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 312, 54);
 (lib.t2_bottom = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_b_2 = new lib.t2_bottom_b_2_vinosl();
  this.cvr_b_2.name = "cvr_b_2";
  this.cvr_b_2.parent = this;
  this.cvr_b_2.setTransform(12, 213, 0.5, 0.5);
  this.timeline.addTween(cjs.Tween.get(this.cvr_b_2).wait(1));
  this.timeline.addTween(cjs.Tween.get(this.cvr_b_2).wait(1));
 }).prototype = getMCSymbolPrototype(lib.t2_bottom, new cjs.Rectangle(10, 211, 316, 86), null);
 (lib.t1_top_t_1_vinosl = function() {
  this.initialize(img.t1_top_t_1_vinosl);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 200, 66);
 (lib.t1_top = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_t_1 = new lib.t1_top_t_1_vinosl();
  this.cvr_t_1.name = "cvr_t_1";
  this.cvr_t_1.parent = this;
  this.cvr_t_1.setTransform(12.5, 5, 0.5, 0.5);
  this.timeline.addTween(cjs.Tween.get(this.cvr_t_1).wait(1));
  this.timeline.addTween(cjs.Tween.get(this.cvr_t_1).wait(1));
 }).prototype = getMCSymbolPrototype(lib.t1_top, new cjs.Rectangle(10.5, 3, 203.9, 86.4), null);
 (lib.t1_bottom_b_1_vinosl = function() {
  this.initialize(img.t1_bottom_b_1_vinosl);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 312, 54);
 (lib.t1_bottom = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_b_1 = new lib.t1_bottom_b_1_vinosl();
  this.cvr_b_1.name = "cvr_b_1";
  this.cvr_b_1.parent = this;
  this.cvr_b_1.setTransform(12, 213, 0.5, 0.5);
  this.timeline.addTween(cjs.Tween.get(this.cvr_b_1).wait(1));
  this.timeline.addTween(cjs.Tween.get(this.cvr_b_1).wait(1));
 }).prototype = getMCSymbolPrototype(lib.t1_bottom, new cjs.Rectangle(10, 211, 316, 86), null);
 (lib.t_4_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#FFFFFF").s().p("AgmBSIAAggIgUAAIAAgPIAUAAIAAgPIgUAAIAAgQIAUAAIAAhVIAqAAQAbABAOANQANANABAXQAAAOgGAMQgHAKgMAHQgNAHgRABIgaAAIAAAPIAoAAIAAAPIgoAAIAAAggAgWAEIAZAAQALAAAIgEQAJgDAFgIQAGgIAAgMQAAgNgGgHQgFgIgJgDQgIgDgLAAIgZAAg");
  this.shape.setTransform(160.6, 92.575);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#FFFFFF").s().p("AhBCSQgYgVgKglQgKgmABgxQgBgwALgmQAKgmAXgVQAYgXApAAQAqAAAYAXQAYAWAKAmQAKAlAAAwQAAAxgKAmQgKAlgYAVQgYAWgqAAQgpAAgYgWgAgohsQgOARgEAdQgFAcABAiQgBAkAFAcQAEAdAOARQAOARAaAAQAcgBANgRQAOgQAFgdQAEgcAAgkQAAgigEgcQgFgdgOgRQgOgRgbgBQgaABgOARg");
  this.shape_1.setTransform(140.1488, 100.85);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#FFFFFF").s().p("AhBCSQgYgVgKglQgKgmABgxQgBgwALgmQAKgmAXgVQAYgXApAAQAqAAAYAXQAYAWAKAmQAKAlAAAwQAAAxgKAmQgKAlgYAVQgYAWgqAAQgpAAgYgWgAgohsQgOARgEAdQgFAcABAiQgBAkAFAcQAEAdAOARQAOARAaAAQAcgBANgRQAOgQAFgdQAEgcAAgkQAAgigEgcQgFgdgOgRQgOgRgbgBQgaABgOARg");
  this.shape_2.setTransform(117.1988, 100.85);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#FFFFFF").s().p("AhBCSQgYgVgKglQgKgmABgxQgBgwALgmQAKgmAXgVQAYgXApAAQAqAAAYAXQAYAWAKAmQAKAlAAAwQAAAxgKAmQgKAlgYAVQgYAWgqAAQgpAAgYgWgAgohsQgOARgEAdQgFAcABAiQgBAkAFAcQAEAdAOARQAOARAaAAQAcgBANgRQAOgQAFgdQAEgcAAgkQAAgigEgcQgFgdgOgRQgOgRgbgBQgaABgOARg");
  this.shape_3.setTransform(94.2488, 100.85);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#FFFFFF").s().p("AhBCSQgYgVgKglQgKgmABgxQgBgwALgmQAKgmAXgVQAYgXApAAQAqAAAYAXQAYAWAKAmQAKAlAAAwQAAAxgKAmQgKAlgYAVQgYAWgqAAQgpAAgYgWgAgohsQgOARgEAdQgFAcABAiQgBAkAFAcQAEAdAOARQAOARAaAAQAcgBANgRQAOgQAFgdQAEgcAAgkQAAgigEgcQgFgdgOgRQgOgRgbgBQgaABgOARg");
  this.shape_4.setTransform(64.0988, 100.85);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#FFFFFF").s().p("AhBCSQgYgVgKglQgKgmABgxQgBgwALgmQAKgmAXgVQAYgXApAAQAqAAAYAXQAYAWAKAmQAKAlAAAwQAAAxgKAmQgKAlgYAVQgYAWgqAAQgpAAgYgWgAgohsQgOARgEAdQgFAcABAiQgBAkAFAcQAEAdAOARQAOARAaAAQAcgBANgRQAOgQAFgdQAEgcAAgkQAAgigEgcQgFgdgOgRQgOgRgbgBQgaABgOARg");
  this.shape_5.setTransform(41.1488, 100.85);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#FFFFFF").s().p("AAMClIAAkLIhFAuIAAgsIBhhAIASAAIAAFJg");
  this.shape_6.setTransform(19.425, 100.725);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
 }).prototype = getMCSymbolPrototype(lib.t_4_1, new cjs.Rectangle(9, 61.5, 258.6, 69.6), null);
 (lib.t_4 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#000000").s().p("AAYAqIAAgmIgvAAIAAAmIgJAAIAAhTIAJAAIAAAlIAvAAIAAglIAJAAIAABTg");
  this.shape.setTransform(158.45, 69.75);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#000000").s().p("AAZAqIAAhGIgyBGIgIAAIAAhTIAJAAIAABGIAxhGIAJAAIAABTg");
  this.shape_1.setTransform(150.075, 69.75);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#000000").s().p("AgUAEIAAgHIApAAIAAAHg");
  this.shape_2.setTransform(143.525, 70.725);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#000000").s().p("AAeA0IAAgUIg7AAIAAAUIgIAAIAAgcIAFAAQADAAACgCIADgIIADgKIAGg3IArAAIAABLIAKAAIAAAcgAgNAEIgCAOQgCAFgCABIAmAAIAAhDIgaAAg");
  this.shape_3.setTransform(137.425, 70.75);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#000000").s().p("AAZA1IAAhGIgyBGIgIAAIAAhTIAJAAIAABGIAxhGIAJAAIAABTgAgMgrQgFgCgBgIIAHAAQABAFADACQADABAEAAQAFAAADgBQADgCABgFIAGAAQAAAIgFACQgFAEgIAAQgIAAgEgEg");
  this.shape_4.setTransform(129.675, 68.65);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#000000").s().p("AgXAqIAAhTIAuAAIAAAIIglAAIAAAdIAkAAIAAAIIgkAAIAAAeIAmAAIAAAIg");
  this.shape_5.setTransform(122.475, 69.75);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#000000").s().p("AgZAqIAAhTIAYAAQAIAAAGACQAGAEAEAFQADAHAAAIQAAAGgDAHQgEAFgGAEQgGAEgIAAIgPAAIAAAfgAgQADIAOAAQAFAAAEgCQAFgCACgEQADgFAAgFQAAgHgDgFQgCgEgFgBQgEgCgFAAIgOAAg");
  this.shape_6.setTransform(116.5, 69.75);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#000000").s().p("AgDAqIAAhLIgYAAIAAgIIA3AAIAAAIIgXAAIAABLg");
  this.shape_7.setTransform(110.375, 69.75);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#000000").s().p("AgWAmQgKgFgFgKQgGgKAAgNQAAgMAGgKQAFgJAKgGQAKgGAMAAQANAAAKAGQAKAGAGAJQAFAKAAAMQAAANgFAKQgGAKgKAFQgKAGgNAAQgMAAgKgGgAgRgeQgIAFgFAIQgEAIAAAJQAAAKAEAIQAFAIAIAFQAIAEAJAAQAKAAAIgEQAIgFAFgIQAEgIAAgKQAAgJgEgIQgFgIgIgFQgIgEgKAAQgJAAgIAEg");
  this.shape_8.setTransform(100.525, 69.725);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#000000").s().p("AAYAqIAAhLIguAAIAABLIgJAAIAAhTIBAAAIAABTg");
  this.shape_9.setTransform(91.6, 69.75);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.f("#000000").s().p("AAZA1IAAhGIgyBGIgIAAIAAhTIAJAAIAABGIAxhGIAJAAIAABTgAgMgrQgFgCgBgIIAHAAQABAFADACQADABAEAAQAFAAADgBQADgCABgFIAGAAQAAAIgFACQgFAEgIAAQgIAAgEgEg");
  this.shape_10.setTransform(80.975, 68.65);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.f("#000000").s().p("AgWAmQgKgFgFgKQgGgKAAgNQAAgMAGgKQAFgJAKgGQAKgGAMAAQANAAAKAGQAKAGAGAJQAFAKAAAMQAAANgFAKQgGAKgKAFQgKAGgNAAQgMAAgKgGgAgRgeQgIAFgFAIQgEAIAAAJQAAAKAEAIQAFAIAIAFQAIAEAJAAQAKAAAIgEQAIgFAFgIQAEgIAAgKQAAgJgEgIQgFgIgIgFQgIgEgKAAQgJAAgIAEg");
  this.shape_11.setTransform(71.875, 69.725);
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.f("#000000").s().p("AAeA0IAAgUIg7AAIAAAUIgIAAIAAgcIAFAAQADAAACgCIADgIIADgKIAGg3IArAAIAABLIAKAAIAAAcgAgNAEIgCAOQgCAFgCABIAmAAIAAhDIgaAAg");
  this.shape_12.setTransform(63.225, 70.75);
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.f("#000000").s().p("AgWAmQgKgFgFgKQgGgKAAgNQAAgMAGgKQAFgJAKgGQAKgGAMAAQANAAAKAGQAKAGAGAJQAFAKAAAMQAAANgFAKQgGAKgKAFQgKAGgNAAQgMAAgKgGgAgRgeQgIAFgFAIQgEAIAAAJQAAAKAEAIQAFAIAIAFQAIAEAJAAQAKAAAIgEQAIgFAFgIQAEgIAAgKQAAgJgEgIQgFgIgIgFQgIgEgKAAQgJAAgIAEg");
  this.shape_13.setTransform(54.875, 69.725);
  this.shape_14 = new cjs.Shape();
  this.shape_14.graphics.f("#000000").s().p("AgWAqIAAhTIAuAAIAAAIIglAAIAABLg");
  this.shape_14.setTransform(47.85, 69.75);
  this.shape_15 = new cjs.Shape();
  this.shape_15.graphics.f("#000000").s().p("AAgAqIAAhTIAJAAIAABTgAgoAqIAAhTIAJAAIAAAkIATAAQANAAAGAFQAIAHgBAKQAAAIgCAGQgEAFgFAEQgGACgJAAgAgfAiIARAAQALABADgFQAFgEAAgJQAAgIgFgEQgEgDgKAAIgRAAg");
  this.shape_15.setTransform(39.7, 69.75);
  this.shape_16 = new cjs.Shape();
  this.shape_16.graphics.f("#000000").s().p("AgaAqIAAhTIAXAAQALAAAHAFQAHAGAAAKQAAAFgDAFQgCAGgHADQAIABAFAFQAEAFAAAJQAAAGgDAGQgDAGgGADQgGACgIAAgAgRAiIARAAQAJABAFgFQAEgEAAgIQAAgHgEgEQgEgDgIAAIgTAAgAgRgEIAPAAQAEAAAEgBQADgDACgEQACgDAAgFQAAgGgEgEQgFgEgHAAIgOAAg");
  this.shape_16.setTransform(31.725, 69.75);
  this.shape_17 = new cjs.Shape();
  this.shape_17.graphics.f("#000000").s().p("AgPAmQgJgFgHgKQgFgKAAgNQAAgMAFgKQAGgJAKgGQAKgGAMAAQAJAAAGADQAIACAGAFIgDAIQgGgEgGgDQgHgCgHAAQgJAAgIAFQgIAEgFAIQgEAIAAAJQAAAKAEAIQAFAIAIAFQAIAEAJAAQAIAAAHgCQAHgDAFgEIADAIQgHAFgHADQgIACgIAAQgMAAgKgGg");
  this.shape_17.setTransform(22, 69.725);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_17
   }, {
    t: this.shape_16
   }, {
    t: this.shape_15
   }, {
    t: this.shape_14
   }, {
    t: this.shape_13
   }, {
    t: this.shape_12
   }, {
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
  this.shape_18 = new cjs.Shape();
  this.shape_18.graphics.f("#FFFFFF").s().p("Ar3BVIAAipIXvAAIAACpg");
  this.shape_18.setTransform(90, 69.5);
  this.timeline.addTween(cjs.Tween.get(this.shape_18).wait(1));
 }).prototype = getMCSymbolPrototype(lib.t_4, new cjs.Rectangle(14, 58, 169.8, 21.099999999999994), null);
 (lib.snoska_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
 }).prototype = getMCSymbolPrototype(lib.snoska_1, new cjs.Rectangle(10, 252, 228.9, 19.69999999999999), null);
 (lib.plate_red = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.rf(["#EC0A1F", "#61141E", "#000000"], [0, 0.561, 1], 24.9, -19.8, 0, 25.3, -19.5, 121.5).s().p("Avu1zIfdAAMgfdArng");
  this.shape.setTransform(100.725, 139.6);
  this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("rgba(108,110,111,0.247)").s().p("A2u/kMAtdAAAMgtdA/Jg");
  this.shape_1.setTransform(145.5, 202.1);
  this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));
 }).prototype = getMCSymbolPrototype(lib.plate_red, new cjs.Rectangle(0, 0, 291, 404.2), null);
 (lib.pic3_1_1_i_3_vinosl = function() {
  this.initialize(img.pic3_1_1_i_3_vinosl);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 792, 560);
 (lib.pic3_1_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_i_3 = new lib.pic3_1_1_i_3_vinosl();
  this.cvr_i_3.name = "cvr_i_3";
  this.cvr_i_3.parent = this;
  this.cvr_i_3.setTransform(0, 0, 0.5, 0.5);
  this.timeline.addTween(cjs.Tween.get(this.cvr_i_3).wait(1));
 }).prototype = getMCSymbolPrototype(lib.pic3_1_1, new cjs.Rectangle(0, 0, 396, 280), null);
 (lib.pic2_1_1_i_2_vinosl = function() {
  this.initialize(img.pic2_1_1_i_2_vinosl);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 792, 560);
 (lib.pic2_1_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_i_2 = new lib.pic2_1_1_i_2_vinosl();
  this.cvr_i_2.name = "cvr_i_2";
  this.cvr_i_2.parent = this;
  this.cvr_i_2.setTransform(0, 0, 0.5, 0.5);
  this.timeline.addTween(cjs.Tween.get(this.cvr_i_2).wait(1));
 }).prototype = getMCSymbolPrototype(lib.pic2_1_1, new cjs.Rectangle(0, 0, 396, 280), null);
 (lib.pic1_1_1_i_1_vinosl = function() {
  this.initialize(img.pic1_1_1_i_1_vinosl);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 672, 560);
 (lib.pic1_1_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_i_1 = new lib.pic1_1_1_i_1_vinosl();
  this.cvr_i_1.name = "cvr_i_1";
  this.cvr_i_1.parent = this;
  this.cvr_i_1.setTransform(0, 0, 0.75, 0.75);
  this.timeline.addTween(cjs.Tween.get(this.cvr_i_1).wait(1));
 }).prototype = getMCSymbolPrototype(lib.pic1_1_1, new cjs.Rectangle(0, 0, 504, 420), null);
 (lib.logo_s = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#FFFFFF").s().p("AiNBcQg7gmAAg2QAAg1A7gmQA6gmBTAAQBUAAA6AmQA7AmAAA1QAAA2g7AmQg6AmhUAAQhTAAg6gmgACVg9QAAAagrATQgZALgfAFIAAAEQAAAxgPAhQgJAVgKAIQA7gEAugeQAZgRANgWQAOgWAAgYQAAgYgNgVQgEgIgHgHIAAADgAifgxQgNAVAAAYQAAAYAOAWQANAWAZARQAZAQAeAKQAYAGAaACQgLgIgIgVQgPghAAgxIAAgEQgegFgagLQgrgTAAgaIAAgCIgLAOgAgVAzQAJAXAMgBQANABAJgXQAIgVABgdQgPACgQgBQgPABgPgCQABAdAIAVgAgVg6QgFANgCAOIAcACIAdgCQgCgOgFgNQgJgWgNAAQgMAAgJAWgAAjhMQAIATAEAYQATgDAQgGQAigMAAgRQAAgRgigMQgNgEgPgDIgNgCIgmgDIgDAAIgDAAIgtAEIgJABIgYAHQgiAMAAARQAAARAiAMQAQAHATACQADgYAJgTQAOgiAUAAQAVAAAOAig");
  this.shape.setTransform(20.125, 13);
  this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
 }).prototype = getMCSymbolPrototype(lib.logo_s, new cjs.Rectangle(0, 0, 40.3, 26), null);
 (lib.line_red_large = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f().s("#FF0022").ss(2, 1, 1).p("AqdO1IU79p");
  this.shape.setTransform(67, -36);
  this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
 }).prototype = getMCSymbolPrototype(lib.line_red_large, new cjs.Rectangle(-1, -131.9, 136, 191.9), null);
 (lib.line_red = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f().s("#FF0022").ss(2, 1, 1).p("Ak7GzIJ3tl");
  this.shape.setTransform(11.05, 43.475);
  this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
 }).prototype = getMCSymbolPrototype(lib.line_red, new cjs.Rectangle(-21.5, -1, 65.1, 89), null);
 (lib.legal_01_d1_vinosl = function() {
  this.initialize(img.legal_01_d1_vinosl);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 310, 169);
 (lib.legal_01 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_d1 = new lib.legal_01_d1_vinosl();
  this.cvr_d1.name = "cvr_d1";
  this.cvr_d1.parent = this;
  this.cvr_d1.setTransform(13, 54, 0.5, 0.5);
  this.timeline.addTween(cjs.Tween.get(this.cvr_d1).wait(1));
  this.timeline.addTween(cjs.Tween.get(this.cvr_d1).wait(1));
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#1E1C1E").s().p("AyvfQMAAAg+fMAlfAAAMAAAA+fg");
  this.shape.setTransform(167.9993, 139.9994, 1.4, 0.7);
  this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
 }).prototype = getMCSymbolPrototype(lib.legal_01, new cjs.Rectangle(0, 0, 336, 280), null);
 (lib.icon_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
 }).prototype = getMCSymbolPrototype(lib.icon_1, new cjs.Rectangle(0, 0, 160, 144), null);
 (lib.gray_plate = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.lf(["#BCBCBC", "#1A1F20"], [0, 1], -28.4, 15.2, 26.3, -39.5).s().p("AmCIUIMFwnIAAQng");
  this.shape.setTransform(297.725, 246.225);
  this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
 }).prototype = getMCSymbolPrototype(lib.gray_plate, new cjs.Rectangle(259, 193, 77.5, 106.5), null);
 (lib.btn1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#FFFFFF").s().p("AgaAuIAAhbIA0AAIAAAMIgmAAIAAAcIAlAAIAAALIglAAIAAAcIAnAAIAAAMg");
  this.shape.setTransform(176.875, 14.575);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#FFFFFF").s().p("Ag8AuIAAhbIANAAIAABPIAqAAIAAhPIAMAAIAABPIApAAIAAhPIANAAIAABbg");
  this.shape_1.setTransform(165.4, 14.575);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#FFFFFF").s().p("AgfAuIAAhbIAOAAIAAAmIASAAQALAAAGAEQAHADADAFQAEAGgBAHQABAJgEAGQgDAGgHAEQgGADgLAAgAgRAjIARAAQAIAAAFgEQAEgEABgIQAAgIgGgEQgEgEgIAAIgRAAg");
  this.shape_2.setTransform(154.2, 14.575);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#FFFFFF").s().p("AgiAuIgDgBIACgMIACACIAEAAQADAAACgDQACgDABgGIAGhFIA1AAIAABcIgNAAIAAhQIgcAAIgGA9QgBAKgFAFQgEAFgIAAIgHgBg");
  this.shape_3.setTransform(144.5, 14.625);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#FFFFFF").s().p("AgYApQgKgGgHgLQgGgKAAgOQAAgNAGgLQAHgKAKgHQALgFANgBQAOABALAFQALAHAGAKQAGALAAANQAAAOgGAKQgGALgLAGQgLAGgOABQgNgBgLgGgAgQgeQgJAFgEAIQgEAHgBAKQABAKAEAIQAEAHAJAFQAHAFAJAAQAKAAAIgFQAHgFAFgHQAFgIAAgKQAAgKgFgHQgFgIgHgFQgIgEgKAAQgJAAgHAEg");
  this.shape_4.setTransform(134.85, 14.6);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#FFFFFF").s().p("AgeAuIAAhbIAyAAIAAAMIglAAIAAAaIASAAQAKAAAHAEQAGADAEAFQADAGABAHQgBAJgDAGQgEAGgGAEQgHADgKAAgAgRAjIARAAQAIAAAFgEQAFgEgBgIQAAgIgEgEQgFgEgIAAIgRAAg");
  this.shape_5.setTransform(125.45, 14.575);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#FFFFFF").s().p("AgfAuIAAhbIAOAAIAAAmIASAAQALAAAGAEQAGADAEAFQADAGABAHQgBAJgDAGQgEAGgGAEQgGADgLAAgAgRAjIARAAQAIAAAFgEQAFgEgBgIQAAgIgEgEQgFgEgIAAIgRAAg");
  this.shape_6.setTransform(113.85, 14.575);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#FFFFFF").s().p("AgFAuIAAhPIgaAAIAAgMIA/AAIAAAMIgZAAIAABPg");
  this.shape_7.setTransform(105.775, 14.575);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#FFFFFF").s().p("AAcAuIgLgcIgjAAIgJAcIgOAAIAihbIAOAAIAjBbgAAOAHIgOglIgOAlIAcAAg");
  this.shape_8.setTransform(97.7, 14.575);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#FFFFFF").s().p("AAXAuIAAgoIgtAAIAAAoIgOAAIAAhbIAOAAIAAAoIAtAAIAAgoIAOAAIAABbg");
  this.shape_9.setTransform(88.1, 14.575);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.f("#FFFFFF").s().p("AgUAsQgIgDgFgFIAHgMQAFAFAGADQAGAEAJAAQAJAAAFgFQAGgEAAgHQAAgJgHgDQgIgFgOAAIAAgJQAKgBAFgCQAHgCABgDQACgEABgEQAAgGgFgEQgFgDgHAAQgGAAgHACQgGADgEAEIgFgKQAFgFAIgCQAGgDAKgBQANABAIAFQAIAHAAAKQAAAJgFAGQgFAFgJACQALACAGAEQAFAGAAAKQAAAIgDAHQgEAGgIADQgIADgKABQgLgBgJgDg");
  this.shape_10.setTransform(78.95, 14.6);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.f("#FFFFFF").s().p("AgZAuIgIgCIADgLIAFABIAGABQAFAAAEgCQADgDADgGIgjhGIAOAAIAbA4IAYg4IAOAAIgfBFQgCAHgEAFQgDAGgEACQgFAEgJAAIgHgBg");
  this.shape_11.setTransform(71.025, 14.65);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).to({
   state: []
  }, 3).wait(1));
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.f("rgba(0,0,0,0.247)").s().p("AzPCWIDHkrMAjYAAAIjNErg");
  this.shape_12.setTransform(123.225, 15);
  this.shape_12._off = true;
  this.timeline.addTween(cjs.Tween.get(this.shape_12).wait(1).to({
   _off: false
  }, 0).to({
   _off: true
  }, 2).wait(1));
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.lf(["#FF0022", "#B21423"], [0, 1], -123.3, -0.2, 48.7, -0.2).s().p("AzPCWIDHkrMAjYAAAIjNErg");
  this.shape_13.setTransform(123.225, 15);
  this.timeline.addTween(cjs.Tween.get(this.shape_13).wait(4));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(0, 0, 246.5, 30);
 (lib.black_plate = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#000000").s().p("A6PV4MAAAgrvMA0fAAAMAAAArvg");
  this.shape.setTransform(168, 140);
  this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
 }).prototype = getMCSymbolPrototype(lib.black_plate, new cjs.Rectangle(0, 0, 336, 280), null);
 (lib.txt_4 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.t_4();
  this.instance.parent = this;
  this.instance.setTransform(66, 31.5, 1, 1, 0, 0, 0, 66, 11.5);
  this.instance.alpha = 0;
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   y: 11.5,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(6));
  this.instance_1 = new lib.t_4_1();
  this.instance_1.parent = this;
  this.instance_1.setTransform(129.2, 57.6, 1, 1, 0, 0, 0, 129.2, 37.6);
  this.instance_1.alpha = 0;
  this.instance_1._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(4).to({
   _off: false
  }, 0).to({
   y: 37.6,
   alpha: 1
  }, 15, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(9, 58, 258.6, 93.1);
 (lib.txt_3_bottom = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.t3_bottom();
  this.instance.parent = this;
  this.instance.setTransform(61.9, 55.5, 1, 1, 0, 0, 0, 101.9, 55.5);
  this.instance.alpha = 0;
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   x: 101.9,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(-30, 211, 356, 86);
 (lib.txt_2_top = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.t2_top();
  this.instance.parent = this;
  this.instance.setTransform(61.9, 55.5, 1, 1, 0, 0, 0, 101.9, 55.5);
  this.instance.alpha = 0;
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   x: 101.9,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(-28.5, 3, 243.9, 73);
 (lib.txt_2_bottom = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.t2_bottom();
  this.instance.parent = this;
  this.instance.setTransform(61.9, 55.5, 1, 1, 0, 0, 0, 101.9, 55.5);
  this.instance.alpha = 0;
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   x: 101.9,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(-30, 211, 356, 86);
 (lib.txt_1_top = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.t1_top();
  this.instance.parent = this;
  this.instance.setTransform(61.9, 55.5, 1, 1, 0, 0, 0, 101.9, 55.5);
  this.instance.alpha = 0;
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   x: 101.9,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(-29.5, 3, 243.9, 86.4);
 (lib.txt_1_bottom = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.t1_bottom();
  this.instance.parent = this;
  this.instance.setTransform(61.9, 55.5, 1, 1, 0, 0, 0, 101.9, 55.5);
  this.instance.alpha = 0;
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   x: 101.9,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(-30, 211, 356, 86);
 (lib.snoska = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.snoska_1();
  this.instance.parent = this;
  this.instance.setTransform(61.9, 55.5, 1, 1, 0, 0, 0, 101.9, 55.5);
  this.instance.alpha = 0;
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   x: 101.9,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(-30, 252, 268.9, 19.69999999999999);
 (lib.pic3_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_i_3 = new lib.pic3_1_1();
  this.cvr_i_3.name = "cvr_i_3";
  this.cvr_i_3.parent = this;
  this.cvr_i_3.setTransform(150, 200, 1, 1, 0, 0, 0, 150, 200);
  this.timeline.addTween(cjs.Tween.get(this.cvr_i_3).wait(1));
 }).prototype = getMCSymbolPrototype(lib.pic3_1, new cjs.Rectangle(0, 0, 396, 280), null);
 (lib.pic3_2 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.pic3_1();
  this.instance.parent = this;
  this.instance.setTransform(180, 300, 1, 1, 0, 0, 0, 180, 300);
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   x: 130
  }, 34, cjs.Ease.get(0.5)).to({
   x: 120
  }, 35, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(-60, 0, 456, 280.1);
 (lib.pic2_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_i_2 = new lib.pic2_1_1();
  this.cvr_i_2.name = "cvr_i_2";
  this.cvr_i_2.parent = this;
  this.cvr_i_2.setTransform(150, 200, 1, 1, 0, 0, 0, 150, 200);
  this.timeline.addTween(cjs.Tween.get(this.cvr_i_2).wait(1));
 }).prototype = getMCSymbolPrototype(lib.pic2_1, new cjs.Rectangle(0, 0, 396, 280), null);
 (lib.pic2_2 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.pic2_1();
  this.instance.parent = this;
  this.instance.setTransform(180, 299.9, 0.9999, 1, 0, 0, 0, 180, 299.9);
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   x: 130
  }, 34, cjs.Ease.get(0.5)).to({
   x: 120
  }, 35, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(-60, 0, 456, 280);
 (lib.pic1_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_i_1 = new lib.pic1_1_1();
  this.cvr_i_1.name = "cvr_i_1";
  this.cvr_i_1.parent = this;
  this.cvr_i_1.setTransform(180, 300, 1, 1, 0, 0, 0, 180, 300);
  this.timeline.addTween(cjs.Tween.get(this.cvr_i_1).wait(1));
 }).prototype = getMCSymbolPrototype(lib.pic1_1, new cjs.Rectangle(0, 0, 504, 420), null);
 (lib.pic1_2 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.pic1_1();
  this.instance.parent = this;
  this.instance.setTransform(-84, -70);
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   scaleX: 0.771,
   scaleY: 0.771,
   x: -25.6,
   y: -21.25
  }, 19, cjs.Ease.get(0.5)).to({
   scaleX: 0.6667,
   scaleY: 0.6667,
   x: 0,
   y: 0
  }, 75, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(-84, -70, 504, 420);
 (lib.lines_red_bottom = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.line_red_large();
  this.instance.parent = this;
  this.instance.setTransform(149.55, 435.4, 1, 1, 0, 0, 0, 20.6, 29.4);
  this.instance.alpha = 0;
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   x: 224.55,
   y: 329.45,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(128, 168.1, 211, 297.9);
 (lib.lines_red = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.line_red();
  this.instance.parent = this;
  this.instance.setTransform(61.4, 132.15, 1.0047, 1.0016, 0, 0, 0, 21.8, 30.6);
  this.instance.alpha = 0;
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   regY: 30.8,
   x: 40.75,
   y: 160.85,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(1));
  this.instance_1 = new lib.line_red();
  this.instance_1.parent = this;
  this.instance_1.setTransform(155.05, -0.45, 1, 1, 0, 0, 0, 20.6, 29.4);
  this.instance_1.alpha = 0;
  this.timeline.addTween(cjs.Tween.get(this.instance_1).to({
   x: 175.7,
   y: -28.8,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(-2.7, -59.2, 201.39999999999998, 277.3);
 (lib.icon = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.cvr_icon = new lib.icon_1();
  this.cvr_icon.name = "cvr_icon";
  this.cvr_icon.parent = this;
  this.cvr_icon.setTransform(80, 72, 1, 1, 0, 0, 0, 80, 72);
  this.timeline.addTween(cjs.Tween.get(this.cvr_icon).wait(1));
 }).prototype = getMCSymbolPrototype(lib.icon, new cjs.Rectangle(0, 0, 160, 144), null);
 (lib.pic4 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.pic1_1();
  this.instance.parent = this;
  this.instance.setTransform(-84, -70);
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   scaleX: 0.771,
   scaleY: 0.771,
   x: -25.6,
   y: -21.25
  }, 19, cjs.Ease.get(0.5)).to({
   scaleX: 0.6667,
   scaleY: 0.6667,
   x: 0,
   y: 0
  }, 75, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(-84, -70, 504, 420);
 (lib.content = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {
   cvr_frame1_3: 83,
   cvr_frame2_2: 143,
   cvr_frame3_1: 203,
   "cvr_frame#4_4": 290,
   cvr_stay: 301,
   cvr_frame5: 402
  });
  this.instance = new lib.logo_s();
  this.instance.parent = this;
  this.instance.setTransform(288, 13, 0.8696, 0.8692);
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(420));
  this.instance_1 = new lib.black_plate();
  this.instance_1.parent = this;
  this.timeline.addTween(cjs.Tween.get(this.instance_1).to({
   alpha: 0
  }, 14, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(389).to({
   _off: false
  }, 0).to({
   alpha: 1
  }, 15, cjs.Ease.get(-1)).wait(1));
  this.instance_2 = new lib.legal_01();
  this.instance_2.parent = this;
  this.instance_2.setTransform(120, 200, 1, 1, 0, 0, 0, 120, 200);
  this.instance_2.alpha = 0;
  this.instance_2._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(307).to({
   _off: false
  }, 0).to({
   alpha: 1
  }, 15).wait(98));
  this.cvr_link2_nocatch = new lib.btn1();
  window.cvrTrackButtons[2] = {
   cnvs: this.cvr_link2_nocatch
  };
  this.cvr_link2_nocatch.name = "cvr_link2_nocatch";
  this.cvr_link2_nocatch.parent = this;
  this.cvr_link2_nocatch.setTransform(68.85, 290.3, 0.8051, 0.8051);
  this.cvr_link2_nocatch.alpha = 0;
  this.cvr_link2_nocatch._off = true;
  new cjs.ButtonHelper(this.cvr_link2_nocatch, 0, 1, 2, false, new lib.btn1(), 3);
  this.timeline.addTween(cjs.Tween.get(this.cvr_link2_nocatch).wait(234).to({
   _off: false
  }, 0).to({
   y: 242,
   alpha: 1
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 73).wait(98));
  this.instance_3 = new lib.txt_2_top("synched", 0, false);
  this.instance_3.parent = this;
  this.instance_3._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(212).to({
   _off: false
  }, 0).to({
   _off: true
  }, 110).wait(98));
  this.instance_4 = new lib.txt_1_top("synched", 0, false);
  this.instance_4.parent = this;
  this.instance_4._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(34).to({
   _off: false
  }, 0).wait(170).to({
   startPosition: 14
  }, 0).to({
   alpha: 0
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(200));
  this.instance_5 = new lib.lines_red_bottom("synched", 0, false);
  this.instance_5.parent = this;
  this.instance_5.setTransform(66.5, 0, 1, 1, 0, 0, 0, 66.5, 0);
  this.instance_5._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(219).to({
   _off: false
  }, 0).to({
   _off: true
  }, 103).wait(98));
  this.instance_6 = new lib.lines_red("synched", 0, false);
  this.instance_6.parent = this;
  this.instance_6.setTransform(66.5, 0, 1, 1, 0, 0, 0, 66.5, 0);
  this.instance_6._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(219).to({
   _off: false
  }, 0).to({
   _off: true
  }, 103).wait(98));
  this.instance_7 = new lib.txt_4("synched", 0, false);
  this.instance_7.parent = this;
  this.instance_7.setTransform(66, 11.5, 1, 1, 0, 0, 0, 66, 11.5);
  this.instance_7._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(224).to({
   _off: false
  }, 0).to({
   _off: true
  }, 98).wait(98));
  this.instance_8 = new lib.gray_plate();
  this.instance_8.parent = this;
  this.instance_8.setTransform(68.2, 48.2, 1, 1, 0, 0, 0, 48.2, 48.2);
  this.instance_8.alpha = 0;
  this.instance_8._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(219).to({
   _off: false
  }, 0).to({
   x: 48.2,
   alpha: 1
  }, 10, cjs.Ease.get(1)).to({
   _off: true
  }, 93).wait(98));
  this.instance_9 = new lib.icon();
  this.instance_9.parent = this;
  this.instance_9.setTransform(56.3, 115.15, 0.2863, 0.2862, 0, 0, 0, 81.9, 74.1);
  this.instance_9.alpha = 0;
  this.instance_9._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(84).to({
   _off: false
  }, 0).to({
   regX: 80.5,
   regY: 73,
   scaleX: 0.5498,
   scaleY: 0.5496,
   x: 56.25,
   y: 115.1,
   alpha: 1
  }, 15).wait(45).to({
   alpha: 0
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(260));
  this.instance_10 = new lib.txt_3_bottom("synched", 0, false);
  this.instance_10.parent = this;
  this.instance_10._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(149).to({
   _off: false
  }, 0).wait(55).to({
   startPosition: 14
  }, 0).to({
   alpha: 0
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(200));
  this.instance_11 = new lib.txt_2_bottom("synched", 0, false);
  this.instance_11.parent = this;
  this.instance_11._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(89).to({
   _off: false
  }, 0).wait(55).to({
   startPosition: 14
  }, 0).to({
   alpha: 0
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(260));
  this.instance_12 = new lib.snoska("synched", 0, false);
  this.instance_12.parent = this;
  this.instance_12._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(89).to({
   _off: false
  }, 0).wait(55).to({
   startPosition: 14
  }, 0).to({
   alpha: 0
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(260));
  this.instance_13 = new lib.txt_1_bottom("synched", 0, false);
  this.instance_13.parent = this;
  this.instance_13._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(49).to({
   _off: false
  }, 0).wait(35).to({
   startPosition: 14
  }, 0).to({
   alpha: 0
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(320));
  this.instance_14 = new lib.plate_red();
  this.instance_14.parent = this;
  this.instance_14.setTransform(53.2, 129.2, 1, 1, 0, 0, 0, 93.2, 129.2);
  this.instance_14.alpha = 0;
  this.instance_14._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(27).to({
   _off: false
  }, 0).to({
   x: 93.2,
   alpha: 1
  }, 7, cjs.Ease.get(1)).to({
   _off: true
  }, 288).wait(98));
  this.instance_15 = new lib.pic4("synched", 0, false);
  this.instance_15.parent = this;
  this.instance_15.setTransform(180, 300, 1, 1, 0, 0, 0, 180, 300);
  this.instance_15.alpha = 0;
  this.instance_15._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(204).to({
   _off: false
  }, 0).to({
   alpha: 1,
   startPosition: 14
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 103).wait(98));
  this.instance_16 = new lib.pic3_2("synched", 0, false);
  this.instance_16.parent = this;
  this.instance_16.setTransform(180, 300, 1, 1, 0, 0, 0, 180, 300);
  this.instance_16.alpha = 0;
  this.instance_16._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(144).to({
   _off: false
  }, 0).to({
   alpha: 1,
   startPosition: 15
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 61).wait(200));
  this.instance_17 = new lib.pic2_2("synched", 0, false);
  this.instance_17.parent = this;
  this.instance_17.setTransform(180, 300, 1, 1, 0, 0, 0, 180, 300);
  this.instance_17.alpha = 0;
  this.instance_17._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(84).to({
   _off: false
  }, 0).to({
   alpha: 1,
   startPosition: 15
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 61).wait(260));
  this.instance_18 = new lib.pic1_2("synched", 0, false);
  this.instance_18.parent = this;
  this.instance_18.setTransform(180, 300, 1, 1, 0, 0, 0, 180, 300);
  this.timeline.addTween(cjs.Tween.get(this.instance_18).to({
   _off: true
  }, 100).wait(320));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(-84, -70, 504, 536);
 (lib.toyota_336x280 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.content();
  this.instance.parent = this;
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));
  this.instance_1 = new lib.black_plate();
  this.instance_1.parent = this;
  this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(84, 70, 336, 280);
 lib.properties = {
  id: '1E4D562F91EE4B408F0AC49B20246D76',
  width: 336,
  height: 280,
  fps: 24,
  color: "#FFFFFF",
  opacity: 1.00,
  manifest: [{
   src: "t3_bottom_b_3_vinosl.png",
   id: "t3_bottom_b_3_vinosl"
  }, {
   src: "t2_top_t_2_vinosl.png",
   id: "t2_top_t_2_vinosl"
  }, {
   src: "t2_bottom_b_2_vinosl.png",
   id: "t2_bottom_b_2_vinosl"
  }, {
   src: "t1_top_t_1_vinosl.png",
   id: "t1_top_t_1_vinosl"
  }, {
   src: "t1_bottom_b_1_vinosl.png",
   id: "t1_bottom_b_1_vinosl"
  }, {
   src: "legal_01_d1_vinosl.png",
   id: "legal_01_d1_vinosl"
  }, {
   src: "pic3_1_1_i_3_vinosl.jpg",
   id: "pic3_1_1_i_3_vinosl"
  }, {
   src: "pic2_1_1_i_2_vinosl.jpg",
   id: "pic2_1_1_i_2_vinosl"
  }, {
   src: "pic1_1_1_i_1_vinosl.jpg",
   id: "pic1_1_1_i_1_vinosl"
  }, ],
  preloads: []
 };
 (lib.Stage = function(canvas) {
  createjs.Stage.call(this, canvas);
 }).prototype = p = new createjs.Stage();
 p.setAutoPlay = function(autoPlay) {
  this.tickEnabled = autoPlay;
 }
 p.play = function() {
  this.tickEnabled = true;
  this.getChildAt(0).gotoAndPlay(this.getTimelinePosition())
 }
 p.stop = function(ms) {
  if (ms) this.seek(ms);
  this.tickEnabled = false;
 }
 p.seek = function(ms) {
  this.tickEnabled = true;
  this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000);
 }
 p.getDuration = function() {
  return this.getChildAt(0).totalFrames / lib.properties.fps * 1000;
 }
 p.getTimelinePosition = function() {
  return this.getChildAt(0).currentFrame / lib.properties.fps * 1000;
 }
 an.bootcompsLoaded = an.bootcompsLoaded || [];
 if (!an.bootstrapListeners) {
  an.bootstrapListeners = [];
 }
 an.bootstrapCallback = function(fnCallback) {
  an.bootstrapListeners.push(fnCallback);
  if (an.bootcompsLoaded.length > 0) {
   for (var i = 0; i < an.bootcompsLoaded.length; ++i) {
    fnCallback(an.bootcompsLoaded[i]);
   }
  }
 };
 an.compositions = an.compositions || {};
 an.compositions['1E4D562F91EE4B408F0AC49B20246D76'] = {
  getStage: function() {
   return exportRoot.getStage();
  },
  getLibrary: function() {
   return lib;
  },
  getSpriteSheet: function() {
   return ss;
  },
  getImages: function() {
   return img;
  }
 };
 an.compositionLoaded = function(id) {
  an.bootcompsLoaded.push(id);
  for (var j = 0; j < an.bootstrapListeners.length; j++) {
   an.bootstrapListeners[j](id);
  }
 }
 an.getComposition = function(id) {
  return an.compositions[id];
 }
 an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {
  var lastW, lastH, lastS = 1;
  window.addEventListener('resize', resizeCanvas);
  resizeCanvas();

  function resizeCanvas() {
   var w = lib.properties.width,
    h = lib.properties.height;
   var iw = window.innerWidth,
    ih = window.innerHeight;
   var pRatio = window.devicePixelRatio || 1,
    xRatio = iw / w,
    yRatio = ih / h,
    sRatio = 1;
   if (isResp) {
    if ((respDim == 'width' && lastW == iw) || (respDim == 'height' && lastH == ih)) {
     sRatio = lastS;
    } else if (!isScale) {
     if (iw < w || ih < h) sRatio = Math.min(xRatio, yRatio);
    } else if (scaleType == 1) {
     sRatio = Math.min(xRatio, yRatio);
    } else if (scaleType == 2) {
     sRatio = Math.max(xRatio, yRatio);
    }
   }
   domContainers[0].width = w * pRatio * sRatio;
   domContainers[0].height = h * pRatio * sRatio;
   domContainers.forEach(function(container) {
    container.style.width = w * sRatio + 'px';
    container.style.height = h * sRatio + 'px';
   });
   stage.scaleX = pRatio * sRatio;
   stage.scaleY = pRatio * sRatio;
   lastW = iw;
   lastH = ih;
   lastS = sRatio;
   stage.tickOnUpdate = false;
   stage.update();
   stage.tickOnUpdate = true;
  }
 }
})(createjs = createjs || {}, AdobeAn = AdobeAn || {});
var createjs, AdobeAn;