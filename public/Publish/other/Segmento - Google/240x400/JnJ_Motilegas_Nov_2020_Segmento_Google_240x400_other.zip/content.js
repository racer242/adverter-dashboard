(function(cjs, an) {
 var p;
 var lib = {};
 var ss = {};
 var img = {};
 lib.ssMetadata = [];
 (lib.bubble = function() {
  this.initialize(img.bubble);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 448, 448);
 (lib.fish1 = function() {
  this.initialize(img.fish1);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 342, 311);
 (lib.fish2 = function() {
  this.initialize(img.fish2);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 346, 266);
 (lib.icon2 = function() {
  this.initialize(img.icon2);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 170, 172);
 (lib.icon3 = function() {
  this.initialize(img.icon3);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 214, 214);
 (lib.packshot = function() {
  this.initialize(img.packshot);
 }).prototype = p = new cjs.Bitmap();
 p.nominalBounds = new cjs.Rectangle(0, 0, 352, 170);

 function mc_symbol_clone() {
  var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
  clone.gotoAndStop(this.currentFrame);
  clone.paused = this.paused;
  clone.framerate = this.framerate;
  return clone;
 }

 function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
  var prototype = cjs.extend(symbol, cjs.MovieClip);
  prototype.clone = mc_symbol_clone;
  prototype.nominalBounds = nominalBounds;
  prototype.frameBounds = frameBounds;
  return prototype;
 }
 (lib.t4 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#0C593C").s().p("AAAAGIgFALIgFgEIAGgLIgJgDIABgGIAKAEIAAgNIAFAAIAAANIAKgEIABAGIgJADIAGALIgFAEg");
  this.shape.setTransform(156.6, 126.725);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#0C593C").s().p("AgYBVQgMgEgJgMQgGgKgDgKQgDgLAAgMIAcAAIABALQABAFADAFQAEAIAFAEQAGADAFABIAGAAIAJgBQAEgBAFgDQAFgFACgGQACgGAAgGIgBgHIgDgIQgCgEgEgDIgIgDIgJgBIgOAAIAAgZIAMAAIAHAAQAFgBACgCQADgCAEgEQACgFAAgIQAAgHgCgFQgCgFgDgCQgFgEgEgBQgFgBgCAAQgDAAgGABQgEABgFAEQgFAFgCAGQgCAGAAAGIgcAAIABgLQABgGACgHQACgHAEgFQAIgKAMgEQAMgEAOAAIAMAAQAGABAHADQAHADAGAFQAGAFADAHQADAHAAAGIABAKQAAAGgBAIQgCAIgHAHIgFAFIgHADIAAABQAFABAEACIAGADQAFAFAEAIQADAJABANQAAAPgGAKQgEAJgHAGQgGAEgJADQgKAEgQAAIgBAAQgOAAgJgEg");
  this.shape_1.setTransform(145.25, 136.0525);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#0C593C").s().p("AAjBUIgKgjIgxAAIgKAjIgdAAIAzinIAaAAIAyCngAATAYIgThIIgRBIIAkAAg");
  this.shape_2.setTransform(132.325, 136.05);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#0C593C").s().p("Ag1BUIAAinIA2AAQAMAAALADQAKADAIAJQAIAKACAJQACAKAAAIQgBAPgEAKQgEAJgGAGQgIAIgKADQgKADgKgBIgZAAIAAA+gAgYgCIAWAAQAEAAAGgBQAGgBAEgFQADgDACgFQABgEABgIQAAgHgCgGQgCgFgCgCQgFgGgGgBQgGgCgEABIgWAAg");
  this.shape_3.setTransform(120.075, 136.0464);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#0C593C").s().p("AgZBAQgEgBgFgDQgFgDgFgIQgEgHAAgNQAAgGABgFQABgFADgFQAEgFAEgDIAJgEIANgDIAPgDIAGgBIAFgDIABgCIABgHQgBgFgBgFQgBgFgEgDQgCgCgEgBIgDAAQgIAAgDADIgGAHIgCAGIAAAGIgaAAIACgMQACgGADgGQAFgIAHgEQAGgEAHgBQAHgBAGAAQAEAAAJABQAIACAIAGQAHAGADAJQADAIAAALIAAAwIABAJIABADQAAABAAAAQAAABABAAQAAAAABAAQAAABAAAAIAFAAIAAAUIgHAAIgHAAIgHAAQgDgBgDgDIgFgFIgBgGIgBAAIgFAHIgEAEQgEADgFACQgGACgHAAIgKgBgAANAEIgDABIgEACIgGABIgHADIgFACQgFADgCAEQgCAEABAEIAAAGQAAAEADADIAFADIAFABQAEAAADgCQADgCAEgFQAEgGACgIIACgPIAAgEIgCABg");
  this.shape_4.setTransform(101.85, 138.2688);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#0C593C").s().p("AgNBBQgHgCgHgEQgIgGgFgJQgFgKAAgLIAZAAIABAIIAEAHQAEAFAEACIAHABIAFgBQADAAAEgDQADgCACgEQACgEAAgGIgBgHQgBgEgEgDIgHgDIgGAAIgJAAIAAgTIAIAAIAEAAIAGgDQAEgDABgEIABgHQAAgFgBgDIgEgGQgCgDgDAAIgFgBIgHABQgEACgDAEIgCAIIgBAHIgZAAQAAgJADgIQACgIAFgFQAHgHAJgDQAJgCAHAAQAHAAAJACQAJACAHAHQAFAFACAGQADAHAAAIQAAAGgCAFQgBAFgEAEQgDADgCABIgFACIAAABIAHABQAEACAEAEQADAEACAFQABAFAAAFQAAAJgCAGQgCAGgDAEIgHAHQgHAFgJACIgQACIgNgBg");
  this.shape_5.setTransform(90.725, 138.37);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#0C593C").s().p("AgYBAQgGgBgDgDQgHgDgEgIQgEgHgBgNQABgGABgFQACgFADgFQADgFAEgDIAKgEIALgDIARgDIAFgBIAFgDIABgCIAAgHQABgFgCgFQgBgFgDgDQgEgCgCgBIgFAAQgHAAgEADIgFAHIgCAGIgBAGIgZAAIACgMQABgGAEgGQAFgIAGgEQAHgEAHgBQAHgBAGAAQAEAAAJABQAIACAIAGQAIAGACAJQADAIAAALIAAAwIAAAJIABADQABABAAAAQAAABABAAQAAAAABAAQAAABABAAIADAAIAAAUIgGAAIgHAAIgGAAQgEgBgEgDIgDgFIgDgGIAAAAIgEAHIgFAEQgEADgFACQgGACgHAAIgJgBgAAMAEIgBABIgGACIgEABIgIADIgGACQgEADgCAEQgCAEAAAEIABAGQAAAEAEADIADADIAGABQADAAAEgCQAEgCADgFQAEgGACgIIABgPIAAgEIgCABg");
  this.shape_6.setTransform(157.15, 113.0188);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#0C593C").s().p("AgrA9IgFgBIAAgTQAGACAFgDQAEgCACgFQACgDABgFIACgRIABgdIAAgnIBKAAIAAB4IgaAAIAAhlIgXAAIAAAXIgBAUIAAALIgBAHQgBANgEAIQgDAHgEAFQgFAEgGACQgGADgIAAIgEgBg");
  this.shape_7.setTransform(145.175, 113.15);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#0C593C").s().p("AgaBTIgHgBIAAgTIAEAAIAEABQAHAAADgEQAEgEACgHIADgLIgth5IAdAAIAaBYIABAAIAVhYIAaAAIglCEIgEAMQgCAHgEAGQgFAFgFACQgFADgIAAIgIgBg");
  this.shape_8.setTransform(135.15, 115.375);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#0C593C").s().p("AgIBBQgGgBgHgEQgGgDgGgHQgGgIgEgMQgEgNAAgRIABgOQABgIADgKQADgKAGgHQAIgJAJgEQAJgDAIAAQAHAAAJACQAJADAIAIQAHAHADAIQADAJABAIIgZAAIgCgIQgBgEgCgEQgDgEgEgDQgDgCgGAAQgEAAgEADQgEADgDAGQgDAFgBAHIgCAMIAAAJIABAQQABAJAEAHQADAHAFAEQAEADAFAAQAGAAADgEQAEgDACgFIAEgLIAAgHIAZAAQAAAIgDAIQgCAJgGAIQgIAKgJADQgKAEgIAAIgKgBg");
  this.shape_9.setTransform(124.5917, 113.1208);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.f("#0C593C").s().p("AATA9IAAhlIglAAIAABlIgbAAIAAh5IBaAAIAAB5g");
  this.shape_10.setTransform(113, 113.1);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.f("#0C593C").s().p("AgYBAQgFgBgEgDQgGgDgFgIQgEgHgBgNQABgGABgFQACgFADgFQADgFAEgDIAKgEIALgDIAQgDIAGgBIAFgDIABgCIAAgHQAAgFgBgFQgBgFgDgDQgEgCgDgBIgEAAQgGAAgFADIgFAHIgCAGIgBAGIgYAAIABgMQACgGADgGQAEgIAIgEQAGgEAHgBQAHgBAGAAQAEAAAJABQAIACAIAGQAIAGACAJQADAIAAALIAAAwIAAAJIABADQABABAAAAQAAABABAAQAAAAABAAQAAABABAAIADAAIAAAUIgFAAIgIAAIgGAAQgEgBgEgDIgDgFIgCgGIgBAAIgFAHIgEAEQgEADgFACQgGACgHAAIgJgBgAAMAEIgBABIgGACIgEABIgIADIgGACQgEADgCAEQgCAEAAAEIABAGQABAEADADIADADIAGABQAEAAADgCQAEgCADgFQAEgGACgIIABgPIAAgEIgCABg");
  this.shape_11.setTransform(101.45, 113.0188);
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.f("#0C593C").s().p("AAQA9Ighg7IAAA7IgbAAIAAh5IAbAAIAAAzIAegzIAeAAIgpA5IArBAg");
  this.shape_12.setTransform(91.375, 113.1);
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.f("#0C593C").s().p("AAjBUIgKgkIgxAAIgKAkIgdAAIAzinIAaAAIAyCngAATAYIgThIIgRBIIAkAAg");
  this.shape_13.setTransform(135.575, 85.55);
  this.shape_14 = new cjs.Shape();
  this.shape_14.graphics.f("#0C593C").s().p("AAbBUIAAhLIg1AAIAABLIgcAAIAAinIAcAAIAABDIA1AAIAAhDIAcAAIAACng");
  this.shape_14.setTransform(122.125, 85.55);
  this.shape_15 = new cjs.Shape();
  this.shape_15.graphics.f("#0C593C").s().p("AAuBnIAAgmIhcAAIAAAmIgZAAIgBg/IANAAIAFgJIAIgSIAGgZIADgRIAAgTIABgSIAAgkIBZAAIAACOIATAAIgBA/gAgKg4IAAAWIgDAXQgDAOgDANIgKAYIA2AAIAAh0IgjAAg");
  this.shape_15.setTransform(107.7, 87.45);
  this.shape_16 = new cjs.Shape();
  this.shape_16.graphics.f("#0C593C").s().p("AAABZQgJAAgKgCQgLgEgKgJQgOgNgGgSQgGgUAAgXQAAgWAGgUQAGgSAOgNQAKgJALgEQAKgCAJAAQAKAAAKACQALAEAKAJQAOANAGASQAGAUAAAWQAAAXgGAUQgGASgOANQgKAJgLAEQgIACgJAAIgDAAgAAMA+QAGgCAGgIQAFgGADgKQADgJABgJIABgSIgBgRQgBgJgDgJQgDgKgFgGQgGgIgGgCQgGgCgGAAQgEAAgGACQgHACgGAIQgFAGgDAKQgDAJgBAJIgBARIABASQABAJADAJQADAKAFAGQAGAIAHACQAGACAEgBQAGABAGgCg");
  this.shape_16.setTransform(93.025, 85.55);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_16
   }, {
    t: this.shape_15
   }, {
    t: this.shape_14
   }, {
    t: this.shape_13
   }, {
    t: this.shape_12
   }, {
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
 }).prototype = getMCSymbolPrototype(lib.t4, new cjs.Rectangle(83.5, 69.6, 338.1, 83.70000000000002), null);
 (lib.t3 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#0C593C").s().p("AgNBUIAAggIAcAAIAAAggAgHAfIgGg4IAAg6IAcAAIAAA6IgHA4g");
  this.shape.setTransform(151, 104.7);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#0C593C").s().p("AgNBBQgHgCgHgEQgIgGgFgJQgFgKAAgLIAZAAIABAIIAEAHQAEAFAEACIAHABIAFgBQADAAAEgDQADgCACgEQACgEAAgGIgBgHQgBgEgEgDIgHgDIgGAAIgJAAIAAgTIAIAAIAEAAIAGgDQAEgDABgEIABgHQAAgFgBgDIgEgGQgCgDgDAAIgFgBIgHABQgEACgDAEIgCAIIgBAHIgZAAQAAgJADgIQACgIAFgFQAHgHAJgDQAJgCAHAAQAHAAAJACQAJACAHAHQAFAFACAGQADAHAAAIQAAAGgCAFQgBAFgEAEQgDADgCABIgFACIAAABIAHABQAEACAEAEQADAEACAFQABAFAAAFQAAAJgCAGQgCAGgDAEIgHAHQgHAFgJACIgQACIgNgBg");
  this.shape_1.setTransform(141.725, 107.02);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#0C593C").s().p("AgYBAQgGgBgDgDQgHgDgEgIQgEgHgBgNQABgGABgFQACgFADgFQADgFAEgDIAKgEIALgDIARgDIAFgBIAFgDIABgCIAAgHQABgFgCgFQgBgFgDgDQgEgCgCgBIgFAAQgHAAgEADIgFAHIgCAGIgBAGIgZAAIACgMQABgGAEgGQAFgIAGgEQAHgEAHgBQAHgBAGAAQAEAAAJABQAIACAIAGQAIAGACAJQADAIAAALIAAAwIAAAJIABADQABABAAAAQAAABABAAQAAAAABAAQAAABABAAIADAAIAAAUIgGAAIgHAAIgGAAQgEgBgEgDIgDgFIgDgGIAAAAIgEAHIgFAEQgEADgFACQgGACgHAAIgJgBgAAMAEIgBABIgGACIgEABIgIADIgGACQgEADgCAEQgCAEAAAEIABAGQAAAEAEADIADADIAGABQADAAAEgCQAEgCADgFQAEgGACgIIABgPIAAgEIgCABg");
  this.shape_2.setTransform(130.6, 106.9188);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#0C593C").s().p("AgjA9IAAh5IBHAAIAAAUIgtAAIAABlg");
  this.shape_3.setTransform(121.05, 107);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#0C593C").s().p("AgPA/QgKgDgIgJQgGgGgFgMQgEgMAAgUIAAgOQABgJADgJQADgJAHgIQAIgKAKgEQAKgDAHAAQAKAAAKAEQAKAEAIAMQAFAIADANQACANABASIhHAAQAAAHACAJQACAIAEAGQAEAFAFACIAGACIAIgCQAEgBAEgFIADgGIACgHIAZAAQgBAIgDAIQgEAHgFAFQgIAIgJACQgKADgHAAQgHAAgJgDgAgHgrQgEADgDADQgEAGgBAHIgCANIArAAIAAgGIgBgJIgEgJQgDgFgEgDQgFgCgEAAQgFAAgDACg");
  this.shape_4.setTransform(109.9917, 107.0219);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#0C593C").s().p("AgrA9IgFAAIAAgUQAGABAFgCQAEgCACgEQACgEABgFIACgRIABgcIAAgpIBKAAIAAB6IgaAAIAAhmIgXAAIAAAXIgBATIAAAMIgBAHQgBANgEAIQgDAHgEAFQgFAEgGACQgGACgIABIgEgBg");
  this.shape_5.setTransform(97.575, 107.05);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#0C593C").s().p("AAVA9IAAhWIgnBWIgdAAIAAh5IAbAAIAABWIAnhWIAdAAIAAB5g");
  this.shape_6.setTransform(86.3, 107);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#0C593C").s().p("AgMA9IAAhlIghAAIAAgUIBaAAIAAAUIgfAAIAABlg");
  this.shape_7.setTransform(75.3, 107);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#0C593C").s().p("AgZA6QgLgHgHgPQgDgIgCgJIgCgTIACgSQACgJADgJQAHgOALgIQALgHAOAAQAPAAALAHQALAIAHAOQADAJACAJIACASIgCATQgCAJgDAIQgHAPgLAHQgLAIgPAAQgOAAgLgIgAgKgqQgEAEgDAGIgDALIgCAMIAAAJIAAAKIACAMIADAKQADAHAEADQAFAEAFAAQAGAAAFgEQAEgDADgHIADgKIACgMIAAgKIAAgJIgCgMIgDgLQgDgGgEgEQgFgDgGAAQgFAAgFADg");
  this.shape_8.setTransform(64.525, 107.025);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#0C593C").s().p("AAuBUIAAhyIACgSIgCAAIgjCEIgVAAIgjiEIgCAAIACASIAAByIgcAAIAAinIAoAAIAhB/IAih/IAoAAIAACng");
  this.shape_9.setTransform(49.225, 104.7);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.f("#0C593C").s().p("AgPA/QgKgDgIgJQgGgGgFgMQgEgMAAgUIAAgOQABgJADgJQADgJAHgIQAIgKAKgEQAKgDAHAAQAKAAAKAEQAKAEAIAMQAFAIADANQACANABASIhHAAQAAAHACAJQACAIAEAGQAEAFAFACIAGACIAIgCQAEgBAEgFIADgGIACgHIAZAAQgBAIgDAIQgEAHgFAFQgIAIgJACQgKADgHAAQgHAAgJgDgAgHgrQgEADgDADQgEAGgBAHIgCANIArAAIAAgGIgBgJIgEgJQgDgFgEgDQgFgCgEAAQgFAAgDACg");
  this.shape_10.setTransform(159.3917, 82.7719);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.f("#0C593C").s().p("AgMA9IAAhlIghAAIAAgUIBaAAIAAAUIgfAAIAABlg");
  this.shape_11.setTransform(148.75, 82.75);
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.f("#0C593C").s().p("AAVBUIAAhWIgnBWIgcAAIAAh5IAaAAIAABWIAnhWIAcAAIAAB5gAgMgyIgIgEIgFgEQgEgDgEgGQgDgHgBgJIAVAAIABAGIADAFQADAEADACIAGAAIAHAAQADgCADgEQACgCABgDIABgGIAVAAQgBAJgEAHQgDAGgEADIgFAEIgIAEIgNACIgMgCg");
  this.shape_12.setTransform(137.75, 80.45);
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.f("#0C593C").s().p("AgZBAQgEgBgFgDQgFgDgFgIQgEgHAAgNQAAgGABgFQABgFADgFQAEgFAEgDIAJgEIANgDIAPgDIAGgBIAFgDIABgCIABgHQgBgFgBgFQgBgFgEgDQgCgCgEgBIgDAAQgIAAgDADIgGAHIgCAGIAAAGIgaAAIACgMQACgGADgGQAFgIAGgEQAHgEAHgBQAHgBAGAAQAEAAAJABQAIACAIAGQAHAGADAJQADAIAAALIAAAwIABAJIABADQAAABAAAAQAAABABAAQAAAAABAAQAAABAAAAIAFAAIAAAUIgGAAIgIAAIgHAAQgDgBgDgDIgFgFIgCgGIAAAAIgFAHIgEAEQgEADgFACQgGACgHAAIgKgBgAANAEIgDABIgEACIgGABIgHADIgFACQgFADgCAEQgCAEABAEIAAAGQAAAEADADIAFADIAFABQAEAAADgCQADgCAEgFQAEgGACgIIACgPIAAgEIgCABg");
  this.shape_13.setTransform(125.7, 82.6688);
  this.shape_14 = new cjs.Shape();
  this.shape_14.graphics.f("#0C593C").s().p("AAkA9IAAhNIABgMIgBAAIgaBZIgTAAIgahZIgBAAIABAMIAABNIgaAAIAAh5IAjAAIAaBaIAbhaIAiAAIAAB5g");
  this.shape_14.setTransform(112.2, 82.75);
  this.shape_15 = new cjs.Shape();
  this.shape_15.graphics.f("#0C593C").s().p("AAVA9IAAhWIgnBWIgdAAIAAh5IAbAAIAABWIAnhWIAdAAIAAB5g");
  this.shape_15.setTransform(98.2, 82.75);
  this.shape_16 = new cjs.Shape();
  this.shape_16.graphics.f("#0C593C").s().p("AASA9IAAg2IgjAAIAAA2IgbAAIAAh5IAbAAIAAAwIAjAAIAAgwIAbAAIAAB5g");
  this.shape_16.setTransform(85.9, 82.75);
  this.shape_17 = new cjs.Shape();
  this.shape_17.graphics.f("#0C593C").s().p("AAVA9IAAhWIgnBWIgdAAIAAh5IAbAAIAABWIAnhWIAdAAIAAB5g");
  this.shape_17.setTransform(73.6, 82.75);
  this.shape_18 = new cjs.Shape();
  this.shape_18.graphics.f("#0C593C").s().p("AgyBWIAAimIAZAAIAAAMIAAAAIAFgFIAFgFQAEgDAFgCQAFgBAGAAQAIgBAIAEQAIAEAHAIQAHAJADAKQADAKABAJIABAMIgBAOIgDAOQgCAIgEAGQgDAGgFAFQgFAFgHAEQgHADgJAAIgJgBIgJgEIgGgFIgEgGIAAAAIAAA4gAgLg+QgFAEgEAKQgDAHgBAIIgBAPIAAAKIACALQACAGADAGQAEAGAEADQAFACAEAAQACABAFgDQAFgCAEgGQADgFACgIQADgIAAgNIgBgOQgBgIgDgIQgEgKgGgDQgFgEgEAAQgEAAgGADg");
  this.shape_18.setTransform(61.225, 84.7472);
  this.shape_19 = new cjs.Shape();
  this.shape_19.graphics.f("#0C593C").s().p("AAbBUIAAiNIg1AAIAACNIgcAAIAAinIBtAAIAACng");
  this.shape_19.setTransform(47.3, 80.45);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_19
   }, {
    t: this.shape_18
   }, {
    t: this.shape_17
   }, {
    t: this.shape_16
   }, {
    t: this.shape_15
   }, {
    t: this.shape_14
   }, {
    t: this.shape_13
   }, {
    t: this.shape_12
   }, {
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
 }).prototype = getMCSymbolPrototype(lib.t3, new cjs.Rectangle(38.2, 64.5, 269, 57.5), null);
 (lib.t2 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#0C593C").s().p("AAAAKIgJAQIgHgGIAJgQIgPgGIADgJIAPAGIAAgUIAJAAIAAAUIAPgGIADAJIgQAGIAKAQIgHAGg");
  this.shape.setTransform(106.325, 125.1);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#0C593C").s().p("AAVA9IAAhWIgnBWIgcAAIAAh5IAaAAIAABWIAnhWIAcAAIAAB5g");
  this.shape_1.setTransform(96.7, 130.05);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#0C593C").s().p("AgrA9IgFAAIAAgUQAGABAFgCQAEgCACgEQACgDABgGIACgRIABgcIAAgpIBKAAIAAB6IgaAAIAAhmIgXAAIAAAXIgBATIAAANIgBAGQgBAOgEAHQgDAIgEAEQgFADgGADQgGACgIABIgEgBg");
  this.shape_2.setTransform(84.925, 130.1);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#0C593C").s().p("AgZA6QgLgHgHgPQgDgIgCgJIgCgTIACgSQACgJADgJQAHgOALgIQALgHAOAAQAPAAALAHQALAIAHAOQADAJACAJIACASIgCATQgCAJgDAIQgHAPgLAHQgLAIgPAAQgOAAgLgIgAgKgqQgEAEgDAGIgDALIgCAMIAAAJIAAAKIACAMIADAKQADAHAEADQAFAEAFAAQAGAAAFgEQAEgDADgHIADgKIACgMIAAgKIAAgJIgCgMIgDgLQgDgGgEgEQgFgDgGAAQgFAAgFADg");
  this.shape_3.setTransform(74.875, 130.075);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#0C593C").s().p("AgQBYQgGgCgGgEQgFgEgDgEQgHgJgDgLQgEgKAAgLIgBgUQAAgSACgMIACgUIADgLQADgJAGgHQAGgHAKgEIANgEIAOgCQAKgBACgDQAEgCAAgDIATAAIgBAIIgDAHQgEAJgHADQgHAEgKACIgQADQgIADgGAFQgGAFgEALIgBAIIgBAJIgBAHIABAAIAEgJIAGgJQAEgGAHgEQAIgDAIgBQAJABAIADQAHAEAEAFQAGAGAEAJQAEAIACAJQACAKAAAJQAAAMgDAMQgDAMgIAKQgIALgKAEQgKAEgKAAQgIAAgIgDgAgHgOQgFACgEAIQgEAHgBAJIgCAPIABAPQABAIAEAIQAFAIAEADQAGADACgBQAFAAAEgCQAFgDAEgIQAEgIABgIIABgPIAAgKIgCgLIgEgLQgEgGgEgDQgEgDgFAAIgBAAQgDAAgEADg");
  this.shape_4.setTransform(63.6, 127.525);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#0C593C").s().p("AAVA9IAAhWIgnBWIgcAAIAAh5IAaAAIAABWIAnhWIAcAAIAAB5g");
  this.shape_5.setTransform(46.95, 130.05);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#0C593C").s().p("AAVA9IAAhWIgnBWIgcAAIAAh5IAaAAIAABWIAnhWIAcAAIAAB5g");
  this.shape_6.setTransform(196.35, 106.8);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#0C593C").s().p("AAVA9IAAhWIgnBWIgdAAIAAh5IAbAAIAABWIAnhWIAdAAIAAB5g");
  this.shape_7.setTransform(184.75, 106.8);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#0C593C").s().p("AATA9IAAg2IgkAAIAAA2IgaAAIAAh5IAaAAIAAAwIAkAAIAAgwIAaAAIAAB5g");
  this.shape_8.setTransform(173.45, 106.8);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#0C593C").s().p("AgZBAQgEgBgFgDQgGgDgEgIQgEgHAAgNQgBgGACgFQACgFACgFQAEgFAEgDIAJgEIANgDIAQgDIAFgBIAFgDIABgCIABgHQgBgFgBgFQgBgFgEgDQgCgCgDgBIgFAAQgHAAgDADIgGAHIgCAGIAAAGIgaAAIACgMQACgGADgGQAFgIAGgEQAHgEAHgBQAHgBAGAAQAEAAAJABQAIACAIAGQAHAGADAJQADAIAAALIAAAwIABAJIAAADQABABAAAAQAAABABAAQAAAAABAAQAAABAAAAIAFAAIAAAUIgHAAIgHAAIgGAAQgEgBgDgDIgFgFIgCgGIAAAAIgEAHIgFAEQgEADgFACQgFACgIAAIgKgBgAANAEIgDABIgEACIgGABIgHADIgFACQgGADgBAEQgCAEABAEIAAAGQAAAEADADIAFADIAFABQADAAAEgCQAEgCADgFQAEgGACgIIACgPIAAgEIgCABg");
  this.shape_9.setTransform(162.7, 106.7188);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.f("#0C593C").s().p("AgsA9IAAh5IA1AAQAGAAAGACQAGAAAFAFQAFAFADAGIABAMQAAAGgBAFQgCAFgEAEQgDADgEADIgFACIAAABIAIABIAFAFQAEACADAHQACAFAAAJQAAAKgDAGQgCAGgEADQgDADgHADQgHACgKAAgAgRAqIAQAAIAGgBIAGgDQACgBACgDIACgJIgBgIQgBgEgCgBQgEgDgEgBIgHgBIgPAAgAgRgLIAOAAIAGAAIAGgEQADgCABgDIABgHIgBgGQgBgDgEgCIgDgBIgGgBIgQAAg");
  this.shape_10.setTransform(152.45, 106.8);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.f("#0C593C").s().p("AgZA6QgLgHgHgPQgDgIgCgJIgCgTIACgSQACgJADgJQAHgOALgIQALgHAOAAQAPAAALAHQALAIAHAOQADAJACAJIACASIgCATQgCAJgDAIQgHAPgLAHQgLAIgPAAQgOAAgLgIgAgKgqQgEAEgDAGIgDALIgCAMIAAAJIAAAKIACAMIADAKQADAHAEADQAFAEAFAAQAGAAAFgEQAEgDADgHIADgKIACgMIAAgKIAAgJIgCgMIgDgLQgDgGgEgEQgFgDgGAAQgFAAgFADg");
  this.shape_11.setTransform(141.375, 106.825);
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.f("#0C593C").s().p("AgNBBQgHgCgHgEQgIgGgFgJQgFgKAAgLIAZAAIABAIIAEAHQAEAFAEACIAHABIAFgBQADAAAEgDQADgCACgEQACgEAAgGIgBgHQgBgEgEgDIgHgDIgGAAIgJAAIAAgTIAIAAIAEAAIAGgDQAEgDABgEIABgHQAAgFgBgDIgEgGQgCgDgDAAIgFgBIgHABQgEACgDAEIgCAIIgBAHIgZAAQAAgJADgIQACgIAFgFQAHgHAJgDQAJgCAHAAQAHAAAJACQAJACAHAHQAFAFACAGQADAHAAAIQAAAGgCAFQgBAFgEAEQgDADgCABIgFACIAAABIAHABQAEACAEAEQADAEACAFQABAFAAAFQAAAJgCAGQgCAGgDAEIgHAHQgHAFgJACIgQACIgNgBg");
  this.shape_12.setTransform(130.675, 106.82);
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.f("#0C593C").s().p("AgZBAQgFgBgEgDQgFgDgFgIQgEgHgBgNQAAgGACgFQABgFADgFQAEgFAEgDIAKgEIALgDIAQgDIAGgBIAFgDIABgCIABgHQAAgFgCgFQgBgFgDgDQgEgCgDgBIgDAAQgHAAgFADIgFAHIgCAGIAAAGIgZAAIABgMQACgGADgGQAEgIAIgEQAGgEAHgBQAHgBAGAAQAFAAAIABQAIACAIAGQAHAGADAJQADAIAAALIAAAwIABAJIABADQAAABAAAAQAAABABAAQAAAAABAAQAAABAAAAIAEAAIAAAUIgFAAIgIAAIgHAAQgDgBgEgDIgDgFIgCgGIgBAAIgFAHIgEAEQgEADgFACQgGACgHAAIgKgBgAAMAEIgCABIgEACIgGABIgHADIgGACQgFADgBAEQgCAEABAEIAAAGQABAEACADIAEADIAGABQAEAAADgCQADgCAEgFQAEgGACgIIACgPIAAgEIgDABg");
  this.shape_13.setTransform(120.55, 106.7188);
  this.shape_14 = new cjs.Shape();
  this.shape_14.graphics.f("#0C593C").s().p("AgyBWIAAimIAZAAIAAAMIAAAAIAFgFIAFgFQAEgDAFgCQAFgBAGAAQAIgBAIAEQAIAEAHAIQAHAJADAKQADAKABAJIABAMIgBAOIgDAOQgCAIgEAGQgDAGgFAFQgFAFgHAEQgHADgJAAIgJgBIgJgEIgGgFIgEgGIAAAAIAAA4gAgLg+QgFAEgEAKQgDAHgBAIIgBAPIAAAKIACALQACAGADAGQAEAGAEADQAFACAEAAQACABAFgDQAFgCAEgGQADgFACgIQADgIAAgNIgBgOQgBgIgDgIQgEgKgGgDQgFgEgEAAQgEAAgGADg");
  this.shape_14.setTransform(109.675, 108.7972);
  this.shape_15 = new cjs.Shape();
  this.shape_15.graphics.f("#0C593C").s().p("AgPBYQgIgCgFgEQgFgEgDgEQgHgJgDgLQgDgKgBgLIgBgUQAAgSABgMIADgUIAEgLQACgJAHgHQAFgHAJgEIAOgEIAPgCQAIgBAEgDQACgCAAgDIATAAIgBAIIgCAHQgEAJgHADQgHAEgKACIgQADQgIADgHAFQgGAFgDALIgCAIIgBAJIAAAHIABAAIAEgJIAFgJQAGgGAHgEQAGgDAJgBQAJABAHADQAIAEAFAFQAFAGAFAJQAEAIABAJQACAKAAAJQAAAMgDAMQgDAMgIAKQgIALgJAEQgLAEgKAAQgIAAgHgDgAgHgOQgFACgEAIQgEAHgCAJIgBAPIABAPQABAIAFAIQADAIAGADQAEADAEgBQADAAAGgCQAEgDAEgIQAEgIABgIIABgPIgBgKIgBgLIgDgLQgFgGgEgDQgEgDgEAAIgCAAQgDAAgEADg");
  this.shape_15.setTransform(97.85, 104.275);
  this.shape_16 = new cjs.Shape();
  this.shape_16.graphics.f("#0C593C").s().p("AgZA6QgLgHgHgPQgDgIgCgJIgCgTIACgSQACgJADgJQAHgOALgIQALgHAOAAQAPAAALAHQALAIAHAOQADAJACAJIACASIgCATQgCAJgDAIQgHAPgLAHQgLAIgPAAQgOAAgLgIgAgKgqQgEAEgDAGIgDALIgCAMIAAAJIAAAKIACAMIADAKQADAHAEADQAFAEAFAAQAGAAAFgEQAEgDADgHIADgKIACgMIAAgKIAAgJIgCgMIgDgLQgDgGgEgEQgFgDgGAAQgFAAgFADg");
  this.shape_16.setTransform(86.325, 106.825);
  this.shape_17 = new cjs.Shape();
  this.shape_17.graphics.f("#0C593C").s().p("AgZA6QgLgHgHgPQgDgIgCgJQgCgKAAgJIACgSQACgJADgJQAHgOALgIQALgHAOAAQAPAAALAHQALAIAHAOQADAJACAJIACASIgCATQgCAJgDAIQgHAPgLAHQgLAIgPAAQgOAAgLgIgAgKgqQgEAEgDAGIgDALIgCAMIAAAJIAAAKIACAMIADAKQADAHAEADQAFAEAFAAQAGAAAFgEQAEgDADgHIADgKIACgMIAAgKIAAgJIgCgMIgDgLQgDgGgEgEQgFgDgGAAQgFAAgFADg");
  this.shape_17.setTransform(75.175, 106.825);
  this.shape_18 = new cjs.Shape();
  this.shape_18.graphics.f("#0C593C").s().p("AgNBBQgHgCgHgEQgIgGgFgJQgFgKAAgLIAZAAIABAIIAEAHQAEAFAEACIAHABIAFgBQADAAAEgDQADgCACgEQACgEAAgGIgBgHQgBgEgEgDIgHgDIgGAAIgJAAIAAgTIAIAAIAEAAIAGgDQAEgDABgEIABgHQAAgFgBgDIgEgGQgCgDgDAAIgFgBIgHABQgEACgDAEIgCAIIgBAHIgZAAQAAgJADgIQACgIAFgFQAHgHAJgDQAJgCAHAAQAHAAAJACQAJACAHAHQAFAFACAGQADAHAAAIQAAAGgCAFQgBAFgEAEQgDADgCABIgFACIAAABIAHABQAEACAEAEQADAEACAFQABAFAAAFQAAAJgCAGQgCAGgDAEIgHAHQgHAFgJACIgQACIgNgBg");
  this.shape_18.setTransform(64.475, 106.82);
  this.shape_19 = new cjs.Shape();
  this.shape_19.graphics.f("#0C593C").s().p("AgYBAQgGgBgDgDQgHgDgEgIQgEgHAAgNQgBgGACgFQABgFAEgFQADgFAEgDIAJgEIANgDIAQgDIAFgBIAFgDIABgCIAAgHQAAgFgBgFQgBgFgEgDQgDgCgCgBIgFAAQgGAAgEADIgGAHIgCAGIAAAGIgaAAIACgMQABgGAEgGQAFgIAGgEQAHgEAHgBQAHgBAGAAQAFAAAIABQAIACAIAGQAIAGACAJQADAIAAALIAAAwIABAJIAAADQABABAAAAQAAABABAAQAAAAABAAQAAABAAAAIAFAAIAAAUIgHAAIgHAAIgGAAQgEgBgDgDIgFgFIgCgGIAAAAIgEAHIgFAEQgEADgFACQgFACgIAAIgJgBgAANAEIgCABIgGACIgFABIgHADIgFACQgFADgCAEQgCAEABAEIAAAGQABAEACADIAFADIAFABQADAAAEgCQADgCAEgFQAEgGACgIIABgPIAAgEIgBABg");
  this.shape_19.setTransform(54.35, 106.7188);
  this.shape_20 = new cjs.Shape();
  this.shape_20.graphics.f("#0C593C").s().p("AgjA9IAAh5IBHAAIAAAUIgtAAIAABlg");
  this.shape_20.setTransform(45.8, 106.8);
  this.shape_21 = new cjs.Shape();
  this.shape_21.graphics.f("#0C593C").s().p("AgMATIAEgCQADgBACgEQADgEAAgIIAAgCIgMAAIAAggIAZAAIAAAhQAAAHgCAHQgBAIgHAGQgDAEgDACIgJACg");
  this.shape_21.setTransform(159.205, 89.925);
  this.shape_22 = new cjs.Shape();
  this.shape_22.graphics.f("#0C593C").s().p("AAVA9IAAhWIgnBWIgdAAIAAh5IAbAAIAABWIAnhWIAdAAIAAB5g");
  this.shape_22.setTransform(150.4, 83.55);
  this.shape_23 = new cjs.Shape();
  this.shape_23.graphics.f("#0C593C").s().p("AAVA9IAAhWIgnBWIgdAAIAAh5IAbAAIAABWIAnhWIAdAAIAAB5g");
  this.shape_23.setTransform(138.8, 83.55);
  this.shape_24 = new cjs.Shape();
  this.shape_24.graphics.f("#0C593C").s().p("AgMA9IAAhlIggAAIAAgUIBaAAIAAAUIghAAIAABlg");
  this.shape_24.setTransform(128.8, 83.55);
  this.shape_25 = new cjs.Shape();
  this.shape_25.graphics.f("#0C593C").s().p("AgaBTIgHgBIAAgTIAEAAIAEABQAHAAADgEQAEgEACgHIADgLIgth5IAdAAIAaBYIABAAIAWhYIAZAAIglCEIgEAMQgCAHgEAGQgFAFgFACQgGADgHAAIgIgBg");
  this.shape_25.setTransform(119.75, 85.825);
  this.shape_26 = new cjs.Shape();
  this.shape_26.graphics.f("#0C593C").s().p("AAlBNIAAggIhJAAIAAAgIgXAAIgCgzIAOAAIAFgLIAEgMQAFgQABgOIABgbIAAgWIBMAAIAABmIARAAIgCAzgAgIgpIAAAQIgCAQIgEARIgHASIAnAAIAAhSIgaAAg");
  this.shape_26.setTransform(109.075, 85.125);
  this.shape_27 = new cjs.Shape();
  this.shape_27.graphics.f("#0C593C").s().p("AgNBBQgHgCgHgEQgIgGgFgJQgFgKAAgLIAZAAIABAIIAEAHQAEAFAEACIAHABIAFgBQADAAAEgDQADgCACgEQACgEAAgGIgBgHQgBgEgEgDIgHgDIgGAAIgJAAIAAgTIAIAAIAEAAIAGgDQAEgDABgEIABgHQAAgFgBgDIgEgGQgCgDgDAAIgFgBIgHABQgEACgDAEIgCAIIgBAHIgZAAQAAgJADgIQACgIAFgFQAHgHAJgDQAJgCAHAAQAHAAAJACQAJACAHAHQAFAFACAGQADAHAAAIQAAAGgCAFQgBAFgEAEQgDADgCABIgFACIAAABIAHABQAEACAEAEQADAEACAFQABAFAAAFQAAAJgCAGQgCAGgDAEIgHAHQgHAFgJACIgQACIgNgBg");
  this.shape_27.setTransform(98.275, 83.57);
  this.shape_28 = new cjs.Shape();
  this.shape_28.graphics.f("#0C593C").s().p("AgsA9IAAh5IA1AAIAMABQAGABAGAFQAFAGACAFIABALQAAAGgBAGQgCAEgEAFQgDAEgEABIgFACIAAACIAIABIAFAEQAEAEADAFQADAGgBAJQAAAKgCAGQgDAGgEADQgEADgGACQgHADgKAAgAgRApIAQAAIAGgBIAGgCQACgBACgDIACgIIgBgJQgCgDgBgCQgEgDgEAAIgHgBIgPAAgAgRgLIAOAAIAGgBIAGgDQADgCABgEIABgFIgBgHQgBgDgEgDIgDgBIgGAAIgQAAg");
  this.shape_28.setTransform(88.45, 83.55);
  this.shape_29 = new cjs.Shape();
  this.shape_29.graphics.f("#0C593C").s().p("AAVA9IAAhWIgnBWIgdAAIAAh5IAbAAIAABWIAnhWIAdAAIAAB5g");
  this.shape_29.setTransform(72.25, 83.55);
  this.shape_30 = new cjs.Shape();
  this.shape_30.graphics.f("#0C593C").s().p("AgyBWIAAimIAZAAIAAAMIAAAAIAFgFIAFgFQAEgDAFgCQAFgBAGAAQAIgBAIAEQAIAEAHAIQAHAJADAKQADAKABAJIABAMIgBAOIgDAOQgCAIgEAGQgDAGgFAFQgFAFgHAEQgHADgJAAIgJgBIgJgEIgGgFIgEgGIAAAAIAAA4gAgLg+QgFAEgEAKQgDAHgBAIIgBAPIAAAKIACALQACAGADAGQAEAGAEADQAFACAEAAQACABAFgDQAFgCAEgGQADgFACgIQADgIAAgNIgBgOQgBgIgDgIQgEgKgGgDQgFgEgEAAQgEAAgGADg");
  this.shape_30.setTransform(60.875, 85.5472);
  this.shape_31 = new cjs.Shape();
  this.shape_31.graphics.f("#0C593C").s().p("AAaBUIAAiNIg0AAIAACNIgcAAIAAinIBtAAIAACng");
  this.shape_31.setTransform(47.95, 81.25);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_31
   }, {
    t: this.shape_30
   }, {
    t: this.shape_29
   }, {
    t: this.shape_28
   }, {
    t: this.shape_27
   }, {
    t: this.shape_26
   }, {
    t: this.shape_25
   }, {
    t: this.shape_24
   }, {
    t: this.shape_23
   }, {
    t: this.shape_22
   }, {
    t: this.shape_21
   }, {
    t: this.shape_20
   }, {
    t: this.shape_19
   }, {
    t: this.shape_18
   }, {
    t: this.shape_17
   }, {
    t: this.shape_16
   }, {
    t: this.shape_15
   }, {
    t: this.shape_14
   }, {
    t: this.shape_13
   }, {
    t: this.shape_12
   }, {
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
 }).prototype = getMCSymbolPrototype(lib.t2, new cjs.Rectangle(38.8, 65.3, 331.4, 86.39999999999999), null);
 (lib.t1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#0C593C").s().p("AAAALIgKASIgIgHIALgSIgRgGIADgLIARAIIAAgXIAKAAIAAAXIARgIIACALIgRAGIALASIgIAHg");
  this.shape.setTransform(155.95, 186.4);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#0C593C").s().p("AgRBeIAAgjIAeAAIAAAjgAgOAmIAAgEIABgNQAAgGAEgIQAEgHAFgFIAJgLQAFgGACgGQACgFAAgIQABgEgCgGQgBgFgEgFIgEgDQgDgBgFAAQgCAAgDABIgFADQgGAGgCAIQgCAIAAAIIgcAAIABgOQABgJADgJQADgKAIgHQAIgIAIgCQAJgDAHAAQAJAAAJADQAKACAJAJQAFAFADAJQAEAJABAOQAAAIgCAIQgDAIgFAHIgGAHIgHAFIgIAIQgFAGgCAGQgDAFAAAHIAAAFg");
  this.shape_1.setTransform(147.4, 193.5214);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#0C593C").s().p("AABBHQgIAAgKgDQgKgDgJgKQgHgHgFgMQgEgNgBgWIABgPQABgKADgKQAEgKAGgJQAKgKAKgEQALgEAIABQALgBAKAFQALAEAJANQAGAJACAOQADAOABAUIhNAAQAAAIACAJQADAJAEAGQAEAGAFACQAFACACAAIAIgCQAFgCAEgFIAEgGIABgHIAcAAQgCAIgDAIQgEAIgFAFQgJAJgKADQgJACgHAAIgCAAgAAYgNIgBgGIgBgJIgEgKQgDgGgFgCQgFgDgFAAQgEAAgEADIgHAGQgEAGgCAIIgCANIAvAAIAAAAg");
  this.shape_2.setTransform(135.575, 196.301);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#0C593C").s().p("AgOBCIAAhtIgjAAIAAgWIBiAAIAAAWIgjAAIAABtg");
  this.shape_3.setTransform(124.85, 196.3);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#0C593C").s().p("AgcA/QgMgIgGgQQgEgIgCgKQgCgLAAgKQAAgJACgLQACgJAEgKQAGgPAMgIQAMgIAQAAQAQAAAMAIQAMAIAHAPQAEAKACAJQACALAAAJQAAAKgCALQgCAKgEAIQgHAQgMAIQgMAIgQAAQgQAAgMgIgAgLgtQgEADgDAIQgDAFgBAGIgCANIAAAKIAAALIACAMQABAHADAGQADAGAEAEQAFAEAGAAQAHAAAEgEQAFgEADgGIAEgNIABgMIABgLIgBgKIgBgNIgEgLQgDgIgFgDQgEgEgHAAQgGAAgFAEg");
  this.shape_4.setTransform(113.975, 196.3);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#0C593C").s().p("AgvBCIAAiDIA5AAIANABQAHACAFAEQAGAGACAHQACAGgBAGQAAAHgBAEQgCAGgEAEQgEAFgDACIgGACIAAABIAIACIAHAFQAEADACAGQADAHAAAJQAAALgDAHQgDAGgEADQgEAEgHADQgHACgLAAgAgTAtIASAAIAGgBQAEgBADgCQADgBACgDQACgEAAgFQAAgGgCgDQgBgFgCgBQgEgDgFgBIgHgBIgRAAgAgTgMIAQAAIAGgBQAEgBADgCQADgDABgDIABgHIgBgHQgBgDgEgCIgEgCIgFAAIgTAAg");
  this.shape_5.setTransform(102.275, 196.3);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#0C593C").s().p("AAXBCIAAheIgrBeIgeAAIAAiDIAcAAIAABeIArheIAeAAIAACDg");
  this.shape_6.setTransform(89.8, 196.3);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#0C593C").s().p("AAyBCIgkg/IAAA/IgaAAIAAg/IgkA/IggAAIAshFIgqg+IAfAAIAjA6IAAg6IAaAAIAAA6IAig6IAfAAIgqA+IAsBFg");
  this.shape_7.setTransform(75.65, 196.3);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#0C593C").s().p("AgvBCIAAiDIA5AAIANABQAHACAFAEQAGAGACAHQACAGgBAGQAAAHgBAEQgCAGgEAEQgEAFgDACIgGACIAAABIAIACIAHAFQAEADACAGQADAHAAAJQAAALgDAHQgDAGgEADQgEAEgHADQgHACgLAAgAgTAtIASAAIAGgBQAEgBADgCQADgBACgDQACgEAAgFQAAgGgCgDQgBgFgCgBQgEgDgFgBIgHgBIgRAAgAgTgMIAQAAIAGgBQAEgBADgCQADgDABgDIABgHIgBgHQgBgDgEgCIgEgCIgFAAIgTAAg");
  this.shape_8.setTransform(56.825, 196.3);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#0C593C").s().p("AgNBCIAAhtIgjAAIAAgWIBiAAIAAAWIgkAAIAABtg");
  this.shape_9.setTransform(176.3, 171.65);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.f("#0C593C").s().p("Ag2BdIAAizIAbAAIAAANIABAAIAEgGIAGgGIAJgEQAGgCAGAAQAKgBAIAEQAJAEAHAJQAHAKAEALQADALACAJIAAANIgBAPIgEAQQgCAIgDAHQgEAHgFAFQgGAGgIADQgHAEgKAAIgKgCQgEgBgFgDIgGgFIgFgGIAAAAIAAA8gAgMhDQgFAEgFAKQgDAIgBAJIgBAQIAAALIACAMQACAHAEAGQAEAHAFADQAFADAEAAQACAAAGgCQAFgDAFgHQADgFACgJQACgIABgOIgBgQQgBgJgEgIQgEgLgGgEQgFgDgEAAQgGAAgGADg");
  this.shape_10.setTransform(165.45, 173.7972);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.f("#0C593C").s().p("AgcA/QgMgIgGgQQgEgJgCgKQgCgKAAgKQAAgJACgLQACgKAEgJQAGgPAMgIQAMgIAQAAQAQAAAMAIQAMAIAHAPQAEAJACAKQACALAAAJQAAAKgCAKQgCAKgEAJQgHAQgMAIQgMAIgQAAQgQAAgMgIgAgLgtQgEADgDAIQgDAFgBAGIgCANIAAAKIAAALIACAMQABAHADAGQADAGAEAEQAFAEAGAAQAHAAAEgEQAFgEADgGIAEgNIABgMIABgLIgBgKIgBgNIgEgLQgDgIgFgDQgEgEgHAAQgGAAgFAEg");
  this.shape_11.setTransform(152.525, 171.65);
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.f("#0C593C").s().p("AgNBzIAAgtIgJAAIgJgBQgLgCgJgGQgIgFgHgKQgFgIgEgKQgDgMAAgPQAAgLACgLQADgLAGgJQAFgIAIgHQAHgFALgEIAMgCIALAAIAAgvIAbAAIAAAvIALAAIAMACQALAEAIAFQAHAHAFAIQAGAJADALQACALAAALQAAAPgDAMQgEAKgFAIQgGAKgJAFQgIAGgMACIgJABIgJAAIAAAtgAAOAxQAFABAIgDQAHgDAHgKQADgDACgIQADgIAAgOIgBgPQgBgJgFgIQgFgGgHgEQgHgFgJAAgAgdgpQgHAEgFAGQgEAIgCAJIgBAPQAAAOADAIQACAIADADQAHAKAHADQAIADAFgBIAAhfQgJAAgHAFg");
  this.shape_12.setTransform(137.725, 171.55);
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.f("#0C593C").s().p("AAnBCIAAhTIABgNIgBAAIgcBgIgVAAIgchgIgBAAIABANIAABTIgcAAIAAiDIAmAAIAcBhIAehhIAlAAIAACDg");
  this.shape_13.setTransform(121.175, 171.65);
  this.shape_14 = new cjs.Shape();
  this.shape_14.graphics.f("#0C593C").s().p("AgcA/QgMgIgGgQQgEgJgCgKQgCgKAAgKQAAgJACgLQACgKAEgJQAGgPAMgIQAMgIAQAAQAQAAAMAIQAMAIAHAPQAEAJACAKQACALAAAJQAAAKgCAKQgCAKgEAJQgHAQgMAIQgMAIgQAAQgQAAgMgIgAgLgtQgEADgDAIQgDAFgBAGIgCANIAAAKIAAALIACAMQABAHADAGQADAGAEAEQAFAEAGAAQAHAAAEgEQAFgEADgGIAEgNIABgMIABgLIgBgKIgBgNIgEgLQgDgIgFgDQgEgEgHAAQgGAAgFAEg");
  this.shape_14.setTransform(107.075, 171.65);
  this.shape_15 = new cjs.Shape();
  this.shape_15.graphics.f("#0C593C").s().p("AARBCIgkhAIAABAIgdAAIAAiDIAdAAIAAA3IAhg3IAgAAIgrA9IAuBGg");
  this.shape_15.setTransform(96.375, 171.65);
  this.shape_16 = new cjs.Shape();
  this.shape_16.graphics.f("#0C593C").s().p("AgJBGQgHgBgHgEQgHgEgGgHQgHgJgEgNQgEgNAAgTIABgPQABgJADgLQADgKAHgJQAIgKAKgDQAKgEAIABQAIgBAKADQAKADAJAJQAHAHADAJQAEAKABAJIgbAAIgCgJIgEgJQgDgFgEgCQgEgDgGAAQgFAAgEADQgEADgEAHIgEANIgCANIAAAKIABASQACAJADAIQAEAHAFAEQAFAEAFAAQAGAAAEgEQAEgDADgGIADgMIABgIIAbAAQAAAJgDAJQgDAJgGAJQgJALgKAEQgKADgJAAIgCAAIgJgBg");
  this.shape_16.setTransform(84.525, 171.6527);
  this.shape_17 = new cjs.Shape();
  this.shape_17.graphics.f("#0C593C").s().p("AAXBCIAAhdIgrBdIgeAAIAAiDIAcAAIAABeIArheIAfAAIAACDg");
  this.shape_17.setTransform(72.25, 171.65);
  this.shape_18 = new cjs.Shape();
  this.shape_18.graphics.f("#0C593C").s().p("AAyBvIAAgoIhkAAIAAAoIgaAAIgChEIANAAIAGgKIAIgTQAFgMADgPIACgTIABgUIABgTIAAgoIBhAAIAACaIAUAAIgBBEgAgLg9IgBAZIgCAYQgDAPgFAOQgEAOgGAMIA8AAIAAh+IgnAAg");
  this.shape_18.setTransform(58.25, 171.2);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_18
   }, {
    t: this.shape_17
   }, {
    t: this.shape_16
   }, {
    t: this.shape_15
   }, {
    t: this.shape_14
   }, {
    t: this.shape_13
   }, {
    t: this.shape_12
   }, {
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
 }).prototype = getMCSymbolPrototype(lib.t1, new cjs.Rectangle(48.5, 152, 372, 60.30000000000001), null);
 (lib.packshot_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.packshot();
  this.instance.parent = this;
  this.instance.setTransform(0, 0, 0.667, 0.667);
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));
 }).prototype = getMCSymbolPrototype(lib.packshot_1, new cjs.Rectangle(0, 0, 234.8, 113.4), null);
 (lib.orange = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#0C593C").s().p("AAAAJIgJAQIgHgGIAKgPIgOgFIABgJIAQAFIAAgTIAIAAIAAATIAOgFIADAJIgPAFIAJAPIgHAGg");
  this.shape.setTransform(106, 45.6);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#FFFFFF").s().p("AgNBUIAAghIAcAAIAAAhgAgHAfIgGg4IAAg6IAcAAIAAA6IgHA4g");
  this.shape_1.setTransform(98.8, 54);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#FFFFFF").s().p("AAjBUIgKgjIgxAAIgKAjIgdAAIAzinIAaAAIAyCngAATAXIgThHIgRBHIAkAAg");
  this.shape_2.setTransform(89.825, 54);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#FFFFFF").s().p("AAXBUIgyhUIAABUIgdAAIAAinIAdAAIAABIIAvhIIAgAAIg1BOIA6BZg");
  this.shape_3.setTransform(78.7, 54);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#FFFFFF").s().p("AAbBUIAAhMIg1AAIAABMIgcAAIAAinIAcAAIAABDIA1AAIAAhDIAcAAIAACng");
  this.shape_4.setTransform(64.975, 54);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#FFFFFF").s().p("AAcBUIAAh6Ig4B6IgcAAIAAinIAdAAIAAB6IA4h6IAcAAIAACng");
  this.shape_5.setTransform(51.25, 54);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#FFFFFF").s().p("Ag3BUIAAinIA/AAQAHAAAJACQAIACAHAIQAHAHACAIQACAIAAAHQAAAHgCAHQgCAHgGAHIgFAFIgIADIAAABIAJADIAIAFQAEAEAEAIQADAIAAANQABAIgDAJQgCAKgJAJQgGAFgGADQgHACgGABIgLAAgAgaA7IAaAAIALgBQAFgBAEgEQAEgEABgFIABgKIgBgJQgBgFgEgEQgEgEgFgBQgFgCgGABIgaAAgAgagOIAaAAIAHgBQAFgBAEgEIADgGQACgDAAgGIgBgIQgBgFgDgDQgDgEgFgBQgEgCgFAAIgZAAg");
  this.shape_6.setTransform(38.0042, 53.9958);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#FFFFFF").s().p("AAABZQgJAAgKgDQgLgDgKgIQgOgNgGgUQgGgTAAgXQAAgWAGgTQAGgUAOgNQAKgIALgDQAKgDAJAAQAKAAAKADQALADAKAIQAOANAGAUQAGATAAAWQAAAXgGATQgGAUgOANQgKAIgLADQgIADgJAAIgDAAgAAMA9QAGgCAGgHQAFgHADgIQADgJABgKIABgSIgBgRQgBgKgDgJQgDgIgFgHQgGgHgGgCQgGgDgGAAQgEAAgGADQgHACgGAHQgFAHgDAIQgDAJgBAKIgBARIABASQABAKADAJQADAIAFAHQAGAHAHACQAGADAEAAQAGAAAGgDg");
  this.shape_7.setTransform(24.075, 54);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#FFFFFF").s().p("AAbBUIAAhMIg1AAIAABMIgcAAIAAinIAcAAIAABDIA1AAIAAhDIAcAAIAACng");
  this.shape_8.setTransform(10.175, 54);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#E07E22").s().p("AlvFvQiYiXAAjYQAAjXCYiYQCZiYDWAAQDXAACZCYQCYCYAADXQAADYiYCXQiZCZjXAAQjWAAiZiZg");
  this.shape_9.setTransform(52, 52);
  this.timeline.addTween(cjs.Tween.get(this.shape_9).wait(1));
 }).prototype = getMCSymbolPrototype(lib.orange, new cjs.Rectangle(0, 0, 115.6, 104), null);
 (lib.logo = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#FFFFFF").s().p("AgjAxIAShhIA1AAIgCAPIgkAAIgFAZIAiAAIgDANIgiAAIgFAdIAmAAIgDAPg");
  this.shape.setTransform(249.1077, 58.4773, 0.9242, 0.9232);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#FFFFFF").s().p("AgZAxIAQhSIgbAAIADgPIBGAAIgDAPIgbAAIgPBSg");
  this.shape_1.setTransform(242.4767, 58.4773, 0.9242, 0.9232);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#FFFFFF").s().p("AglAxIAShfQAIgCAPAAQAQAAAJAGQAJAIAAAMQAAARgNAIQgLAJgSAAIgJAAIgHAlgAgFgiIgGAhIAJABQAKAAAGgGQAHgGAAgIQAAgPgRAAg");
  this.shape_2.setTransform(234.2284, 58.4542, 0.9242, 0.9232);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#FFFFFF").s().p("AgjAmQgJgLAAgRQAAgbARgSQAPgOATAAQATAAAKAMQAJAKAAASQAAAcgRARQgNAOgVAAQgSAAgLgMgAgRgUQgJAOAAAPQAAAbAWAAIABAAQAMAAAKgPQAJgOAAgPQAAgbgXAAQgNAAgJAPg");
  this.shape_3.setTransform(225.5411, 58.4773, 0.9242, 0.9232);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#FFFFFF").s().p("AgRA1IABgJQgNgDgIgJQgLgKABgQQAAgYAQgOQAOgMARAAIACgIIAQAAIgCAJQAOACAJAJQAJAKABARQAAAXgQAOQgNAMgUAAIgBAJgAACAgQANgBAIgKQAJgLAAgQQAAgWgSgDgAgVgVQgJALAAAPQAAALAEAHQAGAHAHABIAMg/QgLABgJAKg");
  this.shape_4.setTransform(215.4444, 58.4773, 0.9242, 0.9232);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#005942").s().p("AhzBhQgggkAOg9QAPg5AtglQAugkA6AAQA4AAAdAiQAgAlgOA7QgQA/gyAkQgtAfg2AAQg3AAgdghgAgkg2QgXAXgIAiQgKAoATAXQAOAQAXAAQAdAAAZgYQAagZAJgjQAEgRgCgQQgCgUgKgMQgMgNgXAAQgiAAgZAag");
  this.shape_5.setTransform(90.3799, 36.9654, 0.9242, 0.9232);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#80BC1E").s().p("AguA0QgPgRAIgjQACAZAOAJQAOAJASgIQAsgVALhLQAHAKAAATQAAAKgDAMIgCAIQgFAMgGAKQgLATgRAMQgPALgSAAQgRAAgJgKg");
  this.shape_6.setTransform(90.3437, 37.5194, 0.9242, 0.9232);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#80BC1E").s().p("AhNBxQgZgVAAgnIAAgJIA3AAIAAAEQAAATAMAKQALALAUgBQASAAALgKQAMgLABgWQAAgHgEgGQgDgGgFgCIgMgEQgGgCgIAAIgSAAIAIgpIALAAIAPgDQAJgBAGgEQAGgEAEgHQAFgIAAgKQAAgZggAAQgPAAgMAIQgLAHgFAVIg3AAQAEgYAJgQQAJgQAOgJQAPgKASgEQASgFAVABQAWgBAPAGQAOAEAKAKQAKAJAEAMQAEAKAAAQQAAAKgDAJQgEALgFAHQgEAGgJAHQgIAGgHACQAPACAKAOQAKAOAAAVQAAAXgHARQgJARgOAMQgOALgUAHQgTAFgXAAQgtAAgYgVg");
  this.shape_7.setTransform(244.4175, 36.8731, 0.9242, 0.9232);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#80BC1E").s().p("AhGCBQgNgFgJgKQgJgIgEgNQgEgKAAgPQAAgmAVgWQAWgUAngHIAkgEQAPgBALgEQALgDAEgGQAFgGAAgNQAAgKgEgFQgEgHgFgDQgGgDgGgBIgNgBQgPgBgMAKQgNAIgDAUIg4AAQADgZAKgPQAJgPAOgLQAQgLAQgDQAQgFASABQANAAASACQAOACAPAIQAOAHAIANQAJAOgBAVQAAARgEAaIgUBlIgCAjQAAAHACAIIg8AAIAAgZQgMAQgRAIQgRAHgTAAQgRABgOgGgAATAPIgZACIgRAEQgJADgFAEQgFADgEAJQgEAHAAAMQAAAPAKAGQAKAIAMAAQAOAAAJgFQAJgGAHgIQAEgFAGgNQAEgLACgKIAGgZQgMAJgMABg");
  this.shape_8.setTransform(223.0042, 36.8731, 0.9242, 0.9232);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#80BC1E").s().p("AhnCAIAvj/ICgAAIgKA1IhkAAIglDKg");
  this.shape_9.setTransform(204.285, 36.8962, 0.9242, 0.9232);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.f("#005942").s().p("AgrB8QgUgIgPgTQgPgSgGgYQgIgZAAgdQAAgdAIgYQAHgZAPgRQAPgSAUgLQAUgLAYABQAagBAUAMQAUALANATQAOAVAGAXQAHAZAAAbIgBANIibAAQABAiANAQQAOAPAZAAQARAAANgLQAOgKADgMIA0AAQgNAugaATQgaAVglgBQgYAAgVgKgAgXhLQgJAHgFAHQgGAJgCAJQgCAGgBALIBgAAQgEgcgLgNQgLgOgWAAQgNAAgKAGg");
  this.shape_10.setTransform(182.8209, 36.8731, 0.9242, 0.9232);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.f("#005942").s().p("AhXCBIgagEIAAg2IAJACIAKAAQAOAAAHgPIADgKIADgaQACgWAAggQABgYAAhJICyAAIAAD/Ig7AAIAAjKIg9AAIgBBDIgDAxQgCASgDASQgFAQgEAHQgHAOgNAIQgOAJgUAAg");
  this.shape_11.setTransform(158.2147, 37.0808, 0.9242, 0.9232);
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.f("#005942").s().p("AAuCAIAAisIhRCsIhDAAIAAj/IA5AAIAACsIBRisIBDAAIAAD/g");
  this.shape_12.setTransform(134.9253, 36.8962, 0.9242, 0.9232);
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.f("#005942").s().p("AgdCAIAAjKIhHAAIAAg1IDJAAIAAA1IhHAAIAADKg");
  this.shape_13.setTransform(112.6757, 36.8962, 0.9242, 0.9232);
  this.shape_14 = new cjs.Shape();
  this.shape_14.graphics.f("#005942").s().p("ABkCwIAAj5IgBAAIhJD5IgzAAIhJj2IgBAAIAAD2Ig+AAIAAlgIBdAAIBFDyIABAAIBDjyIBdAAIAAFgg");
  this.shape_14.setTransform(60.8755, 32.3953, 0.9242, 0.9232);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_14
   }, {
    t: this.shape_13
   }, {
    t: this.shape_12
   }, {
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
  this.shape_15 = new cjs.Shape();
  this.shape_15.graphics.lf(["#FFFFFF", "#F27E20"], [0.612, 0.765], -150, 0, 150, 0).s().p("AGEBNI9fAAIAAhKIAAgFIAAhLMAu3AAAIAACag");
  this.shape_15.setTransform(150, 59.15);
  this.shape_16 = new cjs.Shape();
  this.shape_16.graphics.f("#FFFFFF").s().p("A3bEBIAAoBMAu3AAAIAAIBg");
  this.shape_16.setTransform(150, 25.7);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_16
   }, {
    t: this.shape_15
   }]
  }).wait(1));
 }).prototype = getMCSymbolPrototype(lib.logo, new cjs.Rectangle(0, 0, 300, 66.9), null);
 (lib.l4 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#0C593C").s().p("AgEAGIAAgLIAJAAIAAALg");
  this.shape.setTransform(235.375, 91.325);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#0C593C").s().p("AALAgIAAgeIgVAAIAAAeIgJAAIAAg/IAJAAIAAAaIAVAAIAAgaIAJAAIAAA/g");
  this.shape_1.setTransform(231.6, 88.7);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#0C593C").s().p("AgMAfQgFgDgDgIQgCgHAAgNQAAgPAGgJQAFgJALAAQAXAAAAAhQAAANgDAHQgDAIgEADQgFADgIAAQgHAAgFgDgAgHgWQgDACgCAGIgBAPIABAOQACAFADADQADADAEAAQAFAAADgDQADgDABgFQABgGAAgIQAAgJgBgGQgBgGgEgCQgCgDgFAAQgEAAgDADg");
  this.shape_2.setTransform(226.35, 88.675);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#0C593C").s().p("AAKAgIgPggIgGAJIAAAXIgJAAIAAg/IAJAAIAAAeIAVgeIAKAAIgTAYIAUAng");
  this.shape_3.setTransform(221.8, 88.7);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#0C593C").s().p("AAMAgIAAgwIABgIIgCAIIgUAwIgLAAIAAg/IAJAAIAAAwIgBAIIACgIIAUgwIALAAIAAA/g");
  this.shape_4.setTransform(216.375, 88.7);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#0C593C").s().p("AgEAgIAAg4IgQAAIAAgHIApAAIAAAHIgRAAIAAA4g");
  this.shape_5.setTransform(211.775, 88.7);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#0C593C").s().p("AgKAfQgEgDgDgIQgCgHAAgNQAAghATAAQAJAAAEAFQAFAFABAHIABARIgeAAIABAOQABAFACADQADADAEAAQAKAAAAgPIAJAAQAAAGgCAGQgCAFgEADQgFADgGAAQgGAAgFgDgAgIgTQgCAFAAAIIAVAAQAAgJgCgFQgCgFgHAAQgFAAgDAGg");
  this.shape_6.setTransform(207.475, 88.675);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#0C593C").s().p("AATAgIAAg4IgQA4IgFAAIgQg4IAAA4IgJAAIAAg/IAOAAIAMApIABANIACgNIAMgpIAOAAIAAA/g");
  this.shape_7.setTransform(201.825, 88.7);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#0C593C").s().p("AAMAgIAAgwIABgIIgCAIIgUAwIgLAAIAAg/IAJAAIAAAwIgBAIIACgIIAUgwIALAAIAAA/g");
  this.shape_8.setTransform(195.725, 88.7);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#0C593C").s().p("AgMAdQgFgEgCgHQgBgHAAgKQAAgiAWAAQAIAAAFAHQAGAGAAAJIgJAAQAAgOgLAAQgGAAgDAHQgCAIgBALQABALACAHQACAHAHAAQAGAAADgEQABgEABgIIAJAAQAAAKgFAHQgFAHgJAAQgJAAgFgFg");
  this.shape_9.setTransform(190.8, 88.675);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.f("#0C593C").s().p("AgcAEIAAgHIA5AAIAAAHg");
  this.shape_10.setTransform(183.425, 88.3);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.f("#0C593C").s().p("AgLAfQgFgDgEgIQgCgHAAgNQAAgPAFgJQAGgJALAAQAXAAAAAhQAAANgDAHQgCAIgFADQgGADgHAAQgHAAgEgDgAgHgWQgDACgBAGIgBAPIABAOQABAFADADQADADAEAAQAFAAADgDQADgDABgFQABgGABgIQgBgJgBgGQgCgGgDgCQgCgDgFAAQgEAAgDADg");
  this.shape_11.setTransform(175.75, 88.675);
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.f("#0C593C").s().p("AgTAgIAAg/IAUAAQAIAAAFAEQAEAFAAAGQAAAGgDAEQgCAEgFACQAGAAADAEQADAEAAAHQAAAFgDAEQgCAEgDACQgEACgEAAgAgKAZIAKAAQAGgBACgCQACgDABgGQAAgFgDgDQgCgDgGAAIgKAAgAgKgEIAKAAQAEAAACgDQADgCAAgGQAAgIgJgBIgKAAg");
  this.shape_12.setTransform(170.9, 88.7);
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.f("#0C593C").s().p("AgEAgIAAg4IgQAAIAAgHIApAAIAAAHIgRAAIAAA4g");
  this.shape_13.setTransform(166.425, 88.7);
  this.shape_14 = new cjs.Shape();
  this.shape_14.graphics.f("#0C593C").s().p("AgMAdQgEgEgCgHQgCgHAAgKQAAgiAWAAQAJAAAEAHQAGAGAAAJIgJAAQAAgOgLAAQgGAAgDAHQgDAIAAALQAAALADAHQACAHAHAAQAHAAACgEQACgEAAgIIAJAAQAAAKgFAHQgEAHgKAAQgJAAgFgFg");
  this.shape_14.setTransform(162.2, 88.675);
  this.shape_15 = new cjs.Shape();
  this.shape_15.graphics.f("#0C593C").s().p("AgKAfQgEgDgDgIQgCgHAAgNQAAghATAAQAJAAAEAFQAFAFABAHIABARIgeAAIABAOQABAFACADQADADAEAAQAKAAAAgPIAJAAQAAAGgCAGQgCAFgEADQgFADgGAAQgGAAgFgDgAgIgTQgCAFAAAIIAVAAQAAgJgCgFQgCgFgHAAQgFAAgDAGg");
  this.shape_15.setTransform(157.525, 88.675);
  this.shape_16 = new cjs.Shape();
  this.shape_16.graphics.f("#0C593C").s().p("AAdApIAAgSIhCAAIAAg/IAJAAIAAA4IAVAAIAAg4IAIAAIAAA4IAVAAIAAg4IAJAAIAAA4IAHAAIAAAZg");
  this.shape_16.setTransform(151.525, 89.575);
  this.shape_17 = new cjs.Shape();
  this.shape_17.graphics.f("#0C593C").s().p("AgKAfQgEgDgDgIQgCgHAAgNQAAghATAAQAJAAAEAFQAFAFABAHIABARIgeAAIABAOQABAFACADQADADAEAAQAKAAAAgPIAJAAQAAAGgCAGQgCAFgEADQgFADgGAAQgGAAgFgDgAgIgTQgCAFAAAIIAVAAQAAgJgCgFQgCgFgHAAQgFAAgDAGg");
  this.shape_17.setTransform(144.775, 88.675);
  this.shape_18 = new cjs.Shape();
  this.shape_18.graphics.f("#0C593C").s().p("AgTAgIAAg/IAUAAQAIAAAFAEQAEAFAAAGQAAAGgDAEQgCAEgFACQAGAAADAEQADAEAAAHQAAAFgDAEQgCAEgDACQgEACgEAAgAgKAZIAKAAQAGgBACgCQACgDABgGQAAgFgDgDQgCgDgGAAIgKAAgAgKgEIAKAAQAEAAACgDQADgCAAgGQAAgIgJgBIgKAAg");
  this.shape_18.setTransform(140.3, 88.7);
  this.shape_19 = new cjs.Shape();
  this.shape_19.graphics.f("#0C593C").s().p("AgKAfQgEgDgDgIQgCgHAAgNQAAghATAAQAJAAAEAFQAFAFABAHIABARIgeAAIABAOQABAFACADQADADAEAAQAKAAAAgPIAJAAQAAAGgCAGQgCAFgEADQgFADgGAAQgGAAgFgDgAgIgTQgCAFAAAIIAVAAQAAgJgCgFQgCgFgHAAQgFAAgDAGg");
  this.shape_19.setTransform(132.975, 88.675);
  this.shape_20 = new cjs.Shape();
  this.shape_20.graphics.f("#0C593C").s().p("AgKAfQgEgDgDgIQgCgHAAgNQAAghATAAQAJAAAEAFQAFAFABAHIABARIgeAAIABAOQABAFACADQADADAEAAQAKAAAAgPIAJAAQAAAGgCAGQgCAFgEADQgFADgGAAQgGAAgFgDgAgIgTQgCAFAAAIIAVAAQAAgJgCgFQgCgFgHAAQgFAAgDAGg");
  this.shape_20.setTransform(128.375, 88.675);
  this.shape_21 = new cjs.Shape();
  this.shape_21.graphics.f("#0C593C").s().p("AAdApIAAgSIhCAAIAAg/IAJAAIAAA4IAVAAIAAg4IAIAAIAAA4IAVAAIAAg4IAJAAIAAA4IAHAAIAAAZg");
  this.shape_21.setTransform(122.425, 89.575);
  this.shape_22 = new cjs.Shape();
  this.shape_22.graphics.f("#0C593C").s().p("AgGAbQgGgIAAgRIgLAAIAAAeIgJAAIAAg/IAJAAIAAAbIALAAQAAgNAGgIQAGgIAKAAQAMAAAFAJQAGAIAAAPQAAANgDAHQgCAIgFAEQgGADgHAAQgKAAgGgHgAACgWQgCACgBAGIgBAPQAAAMACAHQADAGAHAAQAIAAADgGQADgHAAgMQAAgOgEgGQgDgGgHAAQgFAAgDADg");
  this.shape_22.setTransform(114.325, 88.675);
  this.shape_23 = new cjs.Shape();
  this.shape_23.graphics.f("#0C593C").s().p("AgVAqIAAgIIAHABQAEAAADgDQACgDACgHIgUhAIAJAAIAOAyIABAAIAOgyIAJAAIgUBAIgEALQgBAFgEACQgDADgGAAIgHgBg");
  this.shape_23.setTransform(108.025, 89.8);
  this.shape_24 = new cjs.Shape();
  this.shape_24.graphics.f("#0C593C").s().p("AgTAgIAAg/IAUAAQAIAAAEAEQAFAFABAGQAAAGgEAEQgCAEgEACQAFAAADAEQADAEAAAHQAAAFgCAEQgDAEgDACQgEACgEAAgAgKAZIAKAAQAGgBADgCQACgDAAgGQgBgFgCgDQgCgDgFAAIgLAAgAgKgEIAKAAQAEAAACgDQADgCAAgGQAAgIgJgBIgKAAg");
  this.shape_24.setTransform(103.6, 88.7);
  this.shape_25 = new cjs.Shape();
  this.shape_25.graphics.f("#0C593C").s().p("AgEAgIAAg4IgQAAIAAgHIApAAIAAAHIgRAAIAAA4g");
  this.shape_25.setTransform(99.125, 88.7);
  this.shape_26 = new cjs.Shape();
  this.shape_26.graphics.f("#0C593C").s().p("AgLAdQgGgEgBgHQgCgHAAgKQAAgiAVAAQAJAAAGAHQAFAGAAAJIgJAAQAAgOgLAAQgGAAgDAHQgCAIAAALQAAALACAHQACAHAHAAQAGAAACgEQADgEAAgIIAJAAQAAAKgFAHQgEAHgLAAQgIAAgEgFg");
  this.shape_26.setTransform(94.9, 88.675);
  this.shape_27 = new cjs.Shape();
  this.shape_27.graphics.f("#0C593C").s().p("AAMAqIAAgvIABgIIgCAIIgUAvIgLAAIAAg/IAJAAIAAAwIgBAIIACgIIAUgwIALAAIAAA/gAgJgeQgEgEAAgHIAEAAQACAHAHABQAFAAACgCQACgCABgEIAFAAQAAAHgEAEQgEADgHAAQgFAAgEgDg");
  this.shape_27.setTransform(89.825, 87.65);
  this.shape_28 = new cjs.Shape();
  this.shape_28.graphics.f("#0C593C").s().p("AgKAfQgEgDgDgIQgCgHAAgNQAAghATAAQAJAAAEAFQAFAFABAHIABARIgeAAIABAOQABAFACADQADADAEAAQAKAAAAgPIAJAAQAAAGgCAGQgCAFgEADQgFADgGAAQgGAAgFgDgAgIgTQgCAFAAAIIAVAAQAAgJgCgFQgCgFgHAAQgFAAgDAGg");
  this.shape_28.setTransform(84.825, 88.675);
  this.shape_29 = new cjs.Shape();
  this.shape_29.graphics.f("#0C593C").s().p("AAYA1IAAgUIgwAAIAAAUIgJAAIAAgcIAGAAQAEgHABgIQADgIAAgIIABgYIAAgWIAtAAIAABNIAHAAIAAAcgAgJgVIgBATIgCAOIgFANIAiAAIAAhFIgaAAg");
  this.shape_29.setTransform(79.2, 88.575);
  this.shape_30 = new cjs.Shape();
  this.shape_30.graphics.f("#0C593C").s().p("AgEAGIAAgLIAJAAIAAALg");
  this.shape_30.setTransform(69.725, 91.325);
  this.shape_31 = new cjs.Shape();
  this.shape_31.graphics.f("#0C593C").s().p("AgXAfIAAgHIAEABQAAAAABAAQABgBAAAAQABAAAAAAQAAgBABAAIACgHIAAgQIAAgfIAlAAIAAA/IgJAAIAAg4IgTAAIAAAZQAAAPgDAIQgDAIgIAAIgFgBg");
  this.shape_31.setTransform(65.625, 88.725);
  this.shape_32 = new cjs.Shape();
  this.shape_32.graphics.f("#0C593C").s().p("AgVAqIAAgIIAHABQAEAAADgDQACgDACgHIgUhAIAJAAIAOAyIABAAIAOgyIAJAAIgUBAIgEALQgBAFgEACQgDADgGAAIgHgBg");
  this.shape_32.setTransform(60.925, 89.8);
  this.shape_33 = new cjs.Shape();
  this.shape_33.graphics.f("#0C593C").s().p("AgMAdQgEgEgCgHQgCgHAAgKQAAgiAWAAQAJAAAEAHQAGAGAAAJIgJAAQAAgOgLAAQgGAAgDAHQgDAIAAALQAAALADAHQACAHAHAAQAHAAACgEQACgEAAgIIAJAAQAAAKgFAHQgEAHgKAAQgJAAgFgFg");
  this.shape_33.setTransform(56.45, 88.675);
  this.shape_34 = new cjs.Shape();
  this.shape_34.graphics.f("#0C593C").s().p("AALAgIAAg4IgVAAIAAA4IgJAAIAAg/IAnAAIAAA/g");
  this.shape_34.setTransform(51.45, 88.7);
  this.shape_35 = new cjs.Shape();
  this.shape_35.graphics.f("#0C593C").s().p("AgVAQQAAgFABgEQACgEADgCIAKgEIAKgEQADgBAAgHQAAgFgCgDQgDgCgEAAQgFAAgCADQgCADAAAFIgJAAQAAgTATAAQAFAAAEADQAEACACAEQACADAAAFIAAAlQAAAFADAAIACAAIAAAGIgDABQgFAAgCgCQgCgBgBgGIgBAAQgBAEgEADQgDADgFAAQgQAAAAgSgAABABIgHADIgEAFQgCADAAAEQAAAKAJAAQAFAAADgEIACgCIAAgEIABgGIAAgMIgHADg");
  this.shape_35.setTransform(46.525, 88.675);
  this.shape_36 = new cjs.Shape();
  this.shape_36.graphics.f("#0C593C").s().p("AALAgIgPggIgIAJIAAAXIgJAAIAAg/IAJAAIAAAeIAWgeIALAAIgUAYIAVAng");
  this.shape_36.setTransform(42.3, 88.7);
  this.shape_37 = new cjs.Shape();
  this.shape_37.graphics.f("#0C593C").s().p("AgKAfQgEgDgDgIQgCgHAAgNQAAghATAAQAJAAAEAFQAFAFABAHIABARIgeAAIABAOQABAFACADQADADAEAAQAKAAAAgPIAJAAQAAAGgCAGQgCAFgEADQgFADgGAAQgGAAgFgDgAgIgTQgCAFAAAIIAVAAQAAgJgCgFQgCgFgHAAQgFAAgDAGg");
  this.shape_37.setTransform(34.875, 88.675);
  this.shape_38 = new cjs.Shape();
  this.shape_38.graphics.f("#0C593C").s().p("AATAgIAAg4IgQA4IgFAAIgQg4IAAA4IgJAAIAAg/IAOAAIAMApIABANIACgNIAMgpIAOAAIAAA/g");
  this.shape_38.setTransform(29.175, 88.7);
  this.shape_39 = new cjs.Shape();
  this.shape_39.graphics.f("#0C593C").s().p("AgVAsIAAhVIAJAAIAAAHIAAAAQACgEAEgCQAEgDACAAQAWAAAAAhIgBANQgBAGgDAFQgCAFgEACQgEADgGAAQgEAAgDgCIgGgGIAAAcgAgJgcQgDAIAAALIABAMQABAGACAEQADADAFAAQAGAAADgGQADgHAAgNQAAgZgMAAQgHAAgCAHg");
  this.shape_39.setTransform(23.325, 89.675);
  this.shape_40 = new cjs.Shape();
  this.shape_40.graphics.f("#0C593C").s().p("AgLAfQgGgDgCgIQgDgHAAgNQAAgPAFgJQAGgJALAAQAXAAAAAhQAAANgDAHQgDAIgFADQgEADgIAAQgGAAgFgDgAgHgWQgDACgBAGIgCAPIACAOQABAFADADQADADAEAAQAFAAADgDQADgDABgFQABgGAAgIQAAgJgBgGQgBgGgDgCQgDgDgFAAQgEAAgDADg");
  this.shape_40.setTransform(17.95, 88.675);
  this.shape_41 = new cjs.Shape();
  this.shape_41.graphics.f("#0C593C").s().p("AgDA2IAAgcIgHAGQgDACgEAAQgIAAgFgEQgEgFgCgIQgCgHAAgKQAAgJACgHQACgIAFgEQAFgFAHABQAEgBAEADQAEACACAFIAAgeIAIAAIAAAeQACgFADgCQAEgDAEABQALgBAFAKQAFAIAAAPQAAAigVAAQgEAAgEgCIgFgGIAAAcgAAHgRQgDAIABAKQgBALADAIQACAGAIAAQAHAAACgGQADgHABgNQAAgYgNAAQgIgBgCAIgAgcAAQAAANACAHQAEAGAGAAQAGAAACgDQADgEABgGIABgMQAAgKgCgIQgDgIgIABQgMAAAAAYg");
  this.shape_41.setTransform(11.05, 88.65);
  this.shape_42 = new cjs.Shape();
  this.shape_42.graphics.f("#0C593C").s().p("AgTAgIAAg/IAUAAQAIAAAEAEQAFAFABAGQgBAGgDAEQgCAEgFACQAGAAADAEQADAEAAAHQAAAFgDAEQgBAEgEACQgEACgEAAgAgKAZIAKAAQAGgBACgCQADgDAAgGQAAgFgDgDQgCgDgFAAIgLAAgAgKgEIAKAAQAEAAACgDQADgCAAgGQAAgIgJgBIgKAAg");
  this.shape_42.setTransform(2.25, 88.7);
  this.shape_43 = new cjs.Shape();
  this.shape_43.graphics.f("#0C593C").s().p("AgEAgIAAg3IgQAAIAAgIIApAAIAAAIIgRAAIAAA3g");
  this.shape_43.setTransform(233.55, 64.9);
  this.shape_44 = new cjs.Shape();
  this.shape_44.graphics.f("#0C593C").s().p("AgLAfQgFgDgDgIQgDgHAAgNQAAgPAGgJQAFgJALAAQAXAAAAAhQAAANgDAHQgDAIgFADQgFADgHAAQgGAAgFgDgAgHgWQgDACgBAGIgBAPIABAOQABAFADADQADADAEAAQAFAAADgDQADgDABgFIABgOQAAgJgBgGQgBgGgDgCQgDgDgFAAQgEAAgDADg");
  this.shape_44.setTransform(228.475, 64.875);
  this.shape_45 = new cjs.Shape();
  this.shape_45.graphics.f("#0C593C").s().p("AgKAfQgFgDgCgIQgCgHAAgNQAAghATAAQAJAAAEAFQAFAFABAHQABAHAAAKIgeAAIABAOQABAFACADQADADAEAAQAKAAAAgPIAJAAQAAAGgCAGQgCAFgEADQgFADgGAAQgGAAgFgDgAgIgTQgCAFAAAIIAVAAQAAgJgCgFQgCgFgHAAQgGAAgCAGg");
  this.shape_45.setTransform(220.025, 64.875);
  this.shape_46 = new cjs.Shape();
  this.shape_46.graphics.f("#0C593C").s().p("AAMAgIAAgvIABgIIgCAIIgUAvIgLAAIAAg/IAJAAIAAAvIgBAIIACgIIAUgvIALAAIAAA/g");
  this.shape_46.setTransform(214.575, 64.9);
  this.shape_47 = new cjs.Shape();
  this.shape_47.graphics.f("#0C593C").s().p("AAKAgIAAgeQgFABgIAAQgHABgFgFQgDgEAAgHIAAgTIAJAAIAAASQAAAFACADQACABAFAAIAKAAIAAgbIAJAAIAAA/g");
  this.shape_47.setTransform(208.775, 64.9);
  this.shape_48 = new cjs.Shape();
  this.shape_48.graphics.f("#0C593C").s().p("AAMAgIAAgvIABgIIgCAIIgUAvIgLAAIAAg/IAJAAIAAAvIgBAIIACgIIAUgvIALAAIAAA/g");
  this.shape_48.setTransform(203.125, 64.9);
  this.shape_49 = new cjs.Shape();
  this.shape_49.graphics.f("#0C593C").s().p("AgXAfIAAgHIAEABQABAAAAAAQABAAAAgBQABAAAAAAQABgBAAAAIACgHIAAgQIAAgfIAlAAIAAA/IgJAAIAAg4IgTAAIAAAZQAAAPgDAIQgDAIgHAAIgGgBg");
  this.shape_49.setTransform(196.95, 64.925);
  this.shape_50 = new cjs.Shape();
  this.shape_50.graphics.f("#0C593C").s().p("AgDAgIAAg3IgRAAIAAgIIApAAIAAAIIgQAAIAAA3g");
  this.shape_50.setTransform(192.2, 64.9);
  this.shape_51 = new cjs.Shape();
  this.shape_51.graphics.f("#0C593C").s().p("AgLAfQgFgDgDgIQgDgHAAgNQAAgPAGgJQAFgJALAAQAXAAAAAhQAAANgDAHQgDAIgFADQgFADgHAAQgGAAgFgDgAgHgWQgDACgBAGIgBAPIABAOQABAFADADQADADAEAAQAFAAADgDQADgDABgFIABgOQAAgJgBgGQgBgGgDgCQgDgDgFAAQgEAAgDADg");
  this.shape_51.setTransform(187.075, 64.875);
  this.shape_52 = new cjs.Shape();
  this.shape_52.graphics.f("#0C593C").s().p("AgTAgIAAg/IAUAAQAHAAAFAEQAFAFAAAGQAAAGgCAEQgDAEgFABQAGABADAEQADAEAAAGQAAAGgCAEQgDAEgDACQgEACgEAAgAgKAYIAKAAQAGAAACgCQADgDAAgGQAAgFgDgDQgDgDgEABIgLAAgAgKgEIAKAAQAEAAADgCQACgDAAgFQAAgKgJABIgKAAg");
  this.shape_52.setTransform(178.775, 64.9);
  this.shape_53 = new cjs.Shape();
  this.shape_53.graphics.f("#0C593C").s().p("AgEAJQAFgCAAgJIgFAAIAAgLIAJAAIAAANQAAAEgCAFQgDAEgEABg");
  this.shape_53.setTransform(171.525, 68.375);
  this.shape_54 = new cjs.Shape();
  this.shape_54.graphics.f("#0C593C").s().p("AgMApQgGgEgCgHQgDgGgBgJIgBgPQAAgMACgJQACgKAHgHQAGgGAKAAQAHAAAGAEQAFADADAHQADAFAAAIIgKAAQAAgTgPAAQgKAAgDALQgDAKAAAOIABAOIACALQACAGADADQADADAFAAQAGAAADgDQADgDACgFIABgNIAKAAQgBALgCAHQgCAHgFAEQgFAEgJAAQgIAAgGgEg");
  this.shape_54.setTransform(166.875, 63.8);
  this.shape_55 = new cjs.Shape();
  this.shape_55.graphics.f("#0C593C").s().p("AgeArIAAgIIAEAAQAEAAACgEQACgEABgJIABgXIAAgmIAvAAIAABWIgKAAIAAhNIgcAAIAAAiIAAAQIgCANQgCAHgDAEQgEAEgGAAIgGgBg");
  this.shape_55.setTransform(159.625, 63.825);
  this.shape_56 = new cjs.Shape();
  this.shape_56.graphics.f("#0C593C").s().p("AgYArIAAhVIAYAAQALAAAIAGQAGAGAAAMQAAAIgCAFQgCAFgEABQgDADgGABQgEACgGAAIgMAAIAAAkgAgOgBIAJAAQAGAAAFgBQAEgBADgEQACgEAAgHQAAgJgEgDQgFgEgIAAIgMAAg");
  this.shape_56.setTransform(153.45, 63.775);
  this.shape_57 = new cjs.Shape();
  this.shape_57.graphics.f("#0C593C").s().p("AgVArIAAhVIArAAIAAAIIgiAAIAABNg");
  this.shape_57.setTransform(147.475, 63.775);
  this.shape_58 = new cjs.Shape();
  this.shape_58.graphics.f("#0C593C").s().p("AAUAgIAAg3IgRA3IgFAAIgQg3IAAA3IgJAAIAAg/IAOAAIAMApIABANIADgNIALgpIAOAAIAAA/g");
  this.shape_58.setTransform(137.7, 64.9);
  this.shape_59 = new cjs.Shape();
  this.shape_59.graphics.f("#0C593C").s().p("AAVAgIAAg/IAJAAIAAA/gAgdAgIAAg/IAJAAIAAAbIANAAQAGAAADACQAEACACAEQACAEAAAGQAAAFgCAEQgDAFgEACQgCACgGAAgAgUAYIAKAAQAGAAADgDQACgCAAgGQAAgLgKABIgLAAg");
  this.shape_59.setTransform(130.3, 64.9);
  this.shape_60 = new cjs.Shape();
  this.shape_60.graphics.f("#0C593C").s().p("AALAgIAAgeIgVAAIAAAeIgJAAIAAg/IAJAAIAAAaIAVAAIAAgaIAJAAIAAA/g");
  this.shape_60.setTransform(123.625, 64.9);
  this.shape_61 = new cjs.Shape();
  this.shape_61.graphics.f("#0C593C").s().p("AALAgIAAgeIgVAAIAAAeIgJAAIAAg/IAJAAIAAAaIAVAAIAAgaIAJAAIAAA/g");
  this.shape_61.setTransform(117.875, 64.9);
  this.shape_62 = new cjs.Shape();
  this.shape_62.graphics.f("#0C593C").s().p("AgVAQQAAgFABgEQACgEADgCIAKgEIAKgEQACgBAAgHQAAgFgCgDQgCgCgEAAQgFAAgCADQgDADAAAFIgIAAQAAgTATAAQAFAAAEADQAEACACAEQACADAAAFIAAAlQAAAFADAAIACAAIAAAGIgEABQgEAAgCgCQgCgBgBgGIgBAAQgBAEgEADQgDADgFAAQgQAAAAgSgAAAABIgGADIgEAFQgCADAAAEQAAAKAJAAQAEAAAEgEIABgCIABgEIAAgGIAAgMIgHADg");
  this.shape_62.setTransform(112.425, 64.875);
  this.shape_63 = new cjs.Shape();
  this.shape_63.graphics.f("#0C593C").s().p("AATApIAAgSIgkAAIAAASIgJAAIAAgZIAFAAIAGgMIABgJIABgOIAAgVIAiAAIAAA4IAGAAIAAAZgAgEgOQAAAKgCAFQgBAGgEAJIAXAAIAAgwIgQAAg");
  this.shape_63.setTransform(106.85, 65.775);
  this.shape_64 = new cjs.Shape();
  this.shape_64.graphics.f("#0C593C").s().p("AgLAfQgFgDgDgIQgDgHAAgNQAAgPAGgJQAFgJALAAQAXAAAAAhQAAANgDAHQgDAIgFADQgFADgHAAQgGAAgFgDgAgHgWQgDACgBAGIgBAPIABAOQABAFADADQADADAEAAQAFAAADgDQADgDABgFIABgOQAAgJgBgGQgBgGgDgCQgDgDgFAAQgEAAgDADg");
  this.shape_64.setTransform(98.075, 64.875);
  this.shape_65 = new cjs.Shape();
  this.shape_65.graphics.f("#0C593C").s().p("AARArIAAhNIghAAIAABNIgJAAIAAhVIAzAAIAABVg");
  this.shape_65.setTransform(91.65, 63.775);
  this.shape_66 = new cjs.Shape();
  this.shape_66.graphics.f("#0C593C").s().p("AgEAGIAAgLIAJAAIAAALg");
  this.shape_66.setTransform(83.675, 67.525);
  this.shape_67 = new cjs.Shape();
  this.shape_67.graphics.f("#0C593C").s().p("AgKAfQgFgDgCgIQgCgHAAgNQAAghATAAQAJAAAEAFQAFAFABAHQABAHAAAKIgeAAIABAOQABAFACADQADADAEAAQAKAAAAgPIAJAAQAAAGgCAGQgCAFgEADQgFADgGAAQgGAAgFgDgAgIgTQgCAFAAAIIAVAAQAAgJgCgFQgCgFgHAAQgGAAgCAGg");
  this.shape_67.setTransform(79.675, 64.875);
  this.shape_68 = new cjs.Shape();
  this.shape_68.graphics.f("#0C593C").s().p("AgEAgIAAg3IgQAAIAAgIIApAAIAAAIIgRAAIAAA3g");
  this.shape_68.setTransform(74.9, 64.9);
  this.shape_69 = new cjs.Shape();
  this.shape_69.graphics.f("#0C593C").s().p("AgVAsIAAhVIAJAAIAAAHQADgEADgCQAEgDADAAQAVAAAAAhIgBANIgDALQgDAFgEACQgEADgGAAQgDAAgDgCQgEgCgCgEIAAAcgAgJgcQgCAIAAALIAAAMQABAGADAEQACADAFAAQAHAAACgGQADgHAAgNQAAgZgMAAQgHAAgCAHg");
  this.shape_69.setTransform(69.925, 65.875);
  this.shape_70 = new cjs.Shape();
  this.shape_70.graphics.f("#0C593C").s().p("AgLAfQgFgDgDgIQgDgHAAgNQAAgPAGgJQAFgJALAAQAXAAAAAhQAAANgDAHQgDAIgFADQgFADgHAAQgGAAgFgDgAgHgWQgDACgBAGIgBAPIABAOQABAFADADQADADAEAAQAFAAADgDQADgDABgFIABgOQAAgJgBgGQgBgGgDgCQgDgDgFAAQgEAAgDADg");
  this.shape_70.setTransform(64.025, 64.875);
  this.shape_71 = new cjs.Shape();
  this.shape_71.graphics.f("#0C593C").s().p("AgEArIAAgKIgCAAQgIAAgIgEQgGgDgFgIQgEgIAAgKQAAgLAEgIQAFgHAGgEQAHgDAJAAIACAAIAAgJIAJAAIAAAJIADAAQAIAAAGADQAIAEAEAHQAEAIAAALQAAAKgEAIQgEAIgIADQgGAEgJAAIgCAAIAAAKgAAFAYIADAAQAGAAAEgDQAFgCADgGQACgGAAgHQAAgMgGgGQgGgHgIAAIgDAAgAgRgWQgEADgDAFQgDAGAAAIQAAAHADAGQACAGAFACQAFADAGAAIACAAIAAgxIgCAAQgGAAgFADg");
  this.shape_71.setTransform(56.9, 63.775);
  this.shape_72 = new cjs.Shape();
  this.shape_72.graphics.f("#0C593C").s().p("AgKAgQgEgDgCgFQgDgEAAgIIAIAAIACAJQABADACABQADABADAAQALAAAAgMQAAgFgCgDQgEgEgFAAIgEAAIAAgGIAEAAQAEAAADgDQADgDAAgFQAAgEgCgDQgDgDgFAAQgEAAgDADQgDADAAAFIgIAAQgBgFADgEQADgEAEgDQAFgDAEAAQAFAAAEADQAFACADADQACAEAAAFQAAAGgDAEQgEAEgEABIAAABQAEAAAFAEQADAEAAAHQABAGgDAEQgDAEgEADQgFACgGAAQgFAAgFgCg");
  this.shape_72.setTransform(47.2, 64.875);
  this.shape_73 = new cjs.Shape();
  this.shape_73.graphics.f("#0C593C").s().p("AgVAQQAAgFABgEQACgEADgCIAKgEIAKgEQACgBAAgHQAAgFgCgDQgCgCgEAAQgFAAgCADQgDADAAAFIgIAAQAAgTATAAQAFAAAEADQAEACACAEQACADAAAFIAAAlQAAAFADAAIACAAIAAAGIgEABQgEAAgCgCQgCgBgBgGIgBAAQgBAEgEADQgDADgFAAQgQAAAAgSgAAAABIgGADIgEAFQgCADAAAEQAAAKAJAAQAEAAAEgEIABgCIABgEIAAgGIAAgMIgHADg");
  this.shape_73.setTransform(42.275, 64.875);
  this.shape_74 = new cjs.Shape();
  this.shape_74.graphics.f("#0C593C").s().p("AgQAgIAAg/IAhAAIAAAIIgYAAIAAA3g");
  this.shape_74.setTransform(37.925, 64.9);
  this.shape_75 = new cjs.Shape();
  this.shape_75.graphics.f("#0C593C").s().p("AgKAfQgFgDgCgIQgCgHAAgNQAAghATAAQAJAAAEAFQAFAFABAHQABAHAAAKIgeAAIABAOQABAFACADQADADAEAAQAKAAAAgPIAJAAQAAAGgCAGQgCAFgEADQgFADgGAAQgGAAgFgDgAgIgTQgCAFAAAIIAVAAQAAgJgCgFQgCgFgHAAQgGAAgCAGg");
  this.shape_75.setTransform(32.825, 64.875);
  this.shape_76 = new cjs.Shape();
  this.shape_76.graphics.f("#0C593C").s().p("AgXAfIAAgHIAEABQABAAAAAAQABAAAAgBQABAAAAAAQABgBAAAAIACgHIABgQIAAgfIAkAAIAAA/IgJAAIAAg4IgTAAIAAAZQAAAPgDAIQgCAIgJAAIgFgBg");
  this.shape_76.setTransform(27.05, 64.925);
  this.shape_77 = new cjs.Shape();
  this.shape_77.graphics.f("#0C593C").s().p("AAMAgIAAgvIABgIIgCAIIgUAvIgLAAIAAg/IAJAAIAAAvIgBAIIACgIIAUgvIALAAIAAA/g");
  this.shape_77.setTransform(21.525, 64.9);
  this.shape_78 = new cjs.Shape();
  this.shape_78.graphics.f("#0C593C").s().p("AgEAgIAAg3IgQAAIAAgIIApAAIAAAIIgRAAIAAA3g");
  this.shape_78.setTransform(16.4, 64.9);
  this.shape_79 = new cjs.Shape();
  this.shape_79.graphics.f("#0C593C").s().p("AgLAfQgFgDgDgIQgDgHAAgNQAAgPAGgJQAFgJALAAQAXAAAAAhQAAANgDAHQgDAIgFADQgFADgHAAQgGAAgFgDgAgHgWQgDACgBAGIgBAPIABAOQABAFADADQADADAEAAQAFAAADgDQADgDABgFIABgOQAAgJgBgGQgBgGgDgCQgDgDgFAAQgEAAgDADg");
  this.shape_79.setTransform(11.275, 64.875);
  this.shape_80 = new cjs.Shape();
  this.shape_80.graphics.f("#0C593C").s().p("AAbArIAAhGIAAgGIAAgFIAAAAIgCAGIgCAGIgSBFIgKAAIgShGIgCgLIAAAGIAAAFIAABGIgKAAIAAhVIARAAIARBCIABANIAAAAIACgNIARhCIARAAIAABVg");
  this.shape_80.setTransform(3.9, 63.775);
  this.shape_81 = new cjs.Shape();
  this.shape_81.graphics.f("#0C593C").s().p("AgVAQQAAgFABgEQACgEADgCIAKgEIAKgEQADgBAAgHQAAgFgDgDQgCgCgEAAQgFAAgCADQgDADAAAFIgIAAQAAgTATAAQAFAAAEADQAEACACAEQACADAAAFIAAAlQAAAFADAAIACAAIAAAGIgEABQgEAAgCgCQgCgBgBgGIgBAAQgBAEgEADQgDADgFAAQgQAAAAgSgAABABIgHADIgEAFQgCADAAAEQAAAKAJAAQAFAAADgEIACgCIAAgEIABgGIAAgMIgHADg");
  this.shape_81.setTransform(233.625, 53.225);
  this.shape_82 = new cjs.Shape();
  this.shape_82.graphics.f("#0C593C").s().p("AgEAgIAAg4IgQAAIAAgHIApAAIAAAHIgRAAIAAA4g");
  this.shape_82.setTransform(227.225, 53.25);
  this.shape_83 = new cjs.Shape();
  this.shape_83.graphics.f("#0C593C").s().p("AgVAQQAAgFABgEQACgEADgCIAKgEIAKgEQADgBAAgHQAAgFgDgDQgCgCgEAAQgFAAgCADQgDADAAAFIgIAAQAAgTATAAQAFAAAEADQAEACACAEQACADAAAFIAAAlQAAAFADAAIACAAIAAAGIgEABQgEAAgCgCQgCgBgBgGIgBAAQgBAEgEADQgDADgFAAQgQAAAAgSgAABABIgHADIgEAFQgCADAAAEQAAAKAJAAQAFAAADgEIACgCIAAgEIABgGIAAgMIgHADg");
  this.shape_83.setTransform(220.775, 53.225);
  this.shape_84 = new cjs.Shape();
  this.shape_84.graphics.f("#0C593C").s().p("AgUAsIAAhVIAIAAIAAAHIABAAQACgEADgCQAEgDACAAQAWAAgBAhIgBANIgCALQgDAFgEACQgEADgGAAQgDAAgEgCQgDgCgCgEIAAAcgAgJgcQgCAIAAALIAAAMQABAGACAEQAEADAEAAQAHAAACgGQADgHAAgNQAAgZgMAAQgHAAgCAHg");
  this.shape_84.setTransform(213.8, 54.225);
  this.shape_85 = new cjs.Shape();
  this.shape_85.graphics.f("#0C593C").s().p("AgVAQQAAgFABgEQACgEADgCIAKgEIAKgEQADgBAAgHQAAgFgDgDQgCgCgEAAQgFAAgCADQgDADAAAFIgIAAQAAgTATAAQAFAAAEADQAEACACAEQACADAAAFIAAAlQAAAFADAAIACAAIAAAGIgEABQgEAAgCgCQgCgBgBgGIgBAAQgBAEgEADQgDADgFAAQgQAAAAgSgAABABIgHADIgEAFQgCADAAAEQAAAKAJAAQAFAAADgEIACgCIAAgEIABgGIAAgMIgHADg");
  this.shape_85.setTransform(206.625, 53.225);
  this.shape_86 = new cjs.Shape();
  this.shape_86.graphics.f("#0C593C").s().p("AALAgIAAg4IgWAAIAAA4IgJAAIAAg/IAoAAIAAA/g");
  this.shape_86.setTransform(199.55, 53.25);
  this.shape_87 = new cjs.Shape();
  this.shape_87.graphics.f("#0C593C").s().p("AgKAfQgEgDgDgIQgCgHAAgNQAAghATAAQAJAAAEAFQAFAFABAHQABAHAAAKIgeAAIABAOQABAFACADQADADAEAAQAKAAAAgPIAJAAQAAAGgCAGQgCAFgEADQgFADgGAAQgGAAgFgDgAgIgTQgCAFAAAIIAVAAQAAgJgCgFQgCgFgHAAQgFAAgDAGg");
  this.shape_87.setTransform(192.425, 53.225);
  this.shape_88 = new cjs.Shape();
  this.shape_88.graphics.f("#0C593C").s().p("AgVAsIAAhVIAJAAIAAAHIAAAAQACgEAEgCQAEgDADAAQAUAAAAAhIAAANIgDALQgDAFgEACQgEADgGAAQgDAAgDgCQgEgCgDgEIAAAcgAgJgcQgCAIgBALIABAMQABAGADAEQACADAFAAQAGAAAEgGQACgHAAgNQAAgZgMAAQgHAAgCAHg");
  this.shape_88.setTransform(185.5, 54.225);
  this.shape_89 = new cjs.Shape();
  this.shape_89.graphics.f("#0C593C").s().p("AALAgIAAg4IgWAAIAAA4IgJAAIAAg/IApAAIAAA/g");
  this.shape_89.setTransform(178, 53.25);
  this.shape_90 = new cjs.Shape();
  this.shape_90.graphics.f("#0C593C").s().p("AgGAbQgGgIAAgRIgLAAIAAAeIgJAAIAAg/IAJAAIAAAbIALAAQAAgNAGgIQAGgIAKAAQALAAAHAJQAFAIAAAPQAAANgDAHQgCAIgGAEQgEADgIAAQgKAAgGgHgAACgWQgCACgBAGQgCAGAAAJQABAMACAHQADAGAHAAQAIAAACgGQADgHAAgMQAAgOgDgGQgCgGgIAAQgFAAgDADg");
  this.shape_90.setTransform(165, 53.225);
  this.shape_91 = new cjs.Shape();
  this.shape_91.graphics.f("#0C593C").s().p("AAMAgIAAgwIABgIIgCAIIgUAwIgLAAIAAg/IAJAAIAAAvIgBAJIACgJIAUgvIALAAIAAA/g");
  this.shape_91.setTransform(156.275, 53.25);
  this.shape_92 = new cjs.Shape();
  this.shape_92.graphics.f("#0C593C").s().p("AALAgIAAgeIgWAAIAAAeIgJAAIAAg/IAJAAIAAAbIAWAAIAAgbIAKAAIAAA/g");
  this.shape_92.setTransform(148.85, 53.25);
  this.shape_93 = new cjs.Shape();
  this.shape_93.graphics.f("#0C593C").s().p("AgKAfQgEgDgDgIQgCgHAAgNQAAghATAAQAJAAAEAFQAFAFABAHQABAHAAAKIgeAAIABAOQABAFACADQADADAEAAQAKAAAAgPIAJAAQAAAGgCAGQgCAFgEADQgFADgGAAQgGAAgFgDgAgIgTQgCAFAAAIIAVAAQAAgJgCgFQgCgFgHAAQgFAAgDAGg");
  this.shape_93.setTransform(141.725, 53.225);
  this.shape_94 = new cjs.Shape();
  this.shape_94.graphics.f("#0C593C").s().p("AALAgIAAgeIgVAAIAAAeIgJAAIAAg/IAJAAIAAAbIAVAAIAAgbIAJAAIAAA/g");
  this.shape_94.setTransform(134.7, 53.25);
  this.shape_95 = new cjs.Shape();
  this.shape_95.graphics.f("#0C593C").s().p("AgKAfQgEgDgDgIQgCgHAAgNQAAghATAAQAJAAAEAFQAFAFABAHQABAHAAAKIgeAAIABAOQABAFACADQADADAEAAQAKAAAAgPIAJAAQAAAGgCAGQgCAFgEADQgFADgGAAQgGAAgFgDgAgIgTQgCAFAAAIIAVAAQAAgJgCgFQgCgFgHAAQgFAAgDAGg");
  this.shape_95.setTransform(127.575, 53.225);
  this.shape_96 = new cjs.Shape();
  this.shape_96.graphics.f("#0C593C").s().p("AATAgIAAg4IgQA4IgFAAIgQg4IAAA4IgJAAIAAg/IAOAAIAMApIABANIACgNIAMgpIAOAAIAAA/g");
  this.shape_96.setTransform(119.775, 53.25);
  this.shape_97 = new cjs.Shape();
  this.shape_97.graphics.f("#0C593C").s().p("AAMAgIAAgwIABgIIgCAIIgUAwIgLAAIAAg/IAJAAIAAAvIgBAJIACgJIAUgvIALAAIAAA/g");
  this.shape_97.setTransform(111.575, 53.25);
  this.shape_98 = new cjs.Shape();
  this.shape_98.graphics.f("#0C593C").s().p("AgVAsIAAhVIAJAAIAAAHIAAAAQADgEADgCQAEgDADAAQAUAAAAAhIgBANIgCALQgDAFgEACQgEADgGAAQgEAAgDgCQgDgCgDgEIAAAcgAgJgcQgDAIAAALIABAMQABAGADAEQACADAFAAQAGAAAEgGQACgHAAgNQAAgZgMAAQgHAAgCAHg");
  this.shape_98.setTransform(104.25, 54.225);
  this.shape_99 = new cjs.Shape();
  this.shape_99.graphics.f("#0C593C").s().p("AALAgIAAg4IgWAAIAAA4IgJAAIAAg/IApAAIAAA/g");
  this.shape_99.setTransform(96.75, 53.25);
  this.shape_100 = new cjs.Shape();
  this.shape_100.graphics.f("#0C593C").s().p("AgVAqIAAgIIAHABQAEAAADgDQACgDACgHIgUhAIAJAAIAOAyIABAAIAOgyIAJAAIgUBAIgEALQgBAEgEADQgDADgGAAIgHgBg");
  this.shape_100.setTransform(85.025, 54.35);
  this.shape_101 = new cjs.Shape();
  this.shape_101.graphics.f("#0C593C").s().p("AATAgIAAg4IgQA4IgFAAIgQg4IAAA4IgJAAIAAg/IAOAAIAMApIABANIACgNIAMgpIAOAAIAAA/g");
  this.shape_101.setTransform(77.225, 53.25);
  this.shape_102 = new cjs.Shape();
  this.shape_102.graphics.f("#0C593C").s().p("AgLAfQgFgDgEgIQgCgHAAgNQAAgPAFgJQAGgJALAAQAXAAAAAhQAAANgDAHQgCAIgFADQgGADgHAAQgHAAgEgDgAgHgWQgDACgBAGIgBAPIABAOQABAFACADQAEADAEAAQAFAAADgDQADgDABgFQABgGABgIQgBgJgBgGQgCgGgDgCQgDgDgEAAQgEAAgDADg");
  this.shape_102.setTransform(69.1, 53.225);
  this.shape_103 = new cjs.Shape();
  this.shape_103.graphics.f("#0C593C").s().p("AALAgIgPggIgHAJIAAAXIgJAAIAAg/IAJAAIAAAeIAVgeIALAAIgUAYIAUAng");
  this.shape_103.setTransform(62.375, 53.25);
  this.shape_104 = new cjs.Shape();
  this.shape_104.graphics.f("#0C593C").s().p("AgMAdQgEgEgCgHQgCgHAAgKQAAgiAWAAQAJAAAFAHQAFAGAAAJIgJAAQAAgOgLAAQgGAAgDAHQgCAIAAALQAAALACAHQACAHAHAAQAHAAACgEQACgEAAgIIAJAAQAAAKgFAHQgEAHgKAAQgJAAgFgFg");
  this.shape_104.setTransform(55.275, 53.225);
  this.shape_105 = new cjs.Shape();
  this.shape_105.graphics.f("#0C593C").s().p("AALAgIAAgeIgVAAIAAAeIgJAAIAAg/IAJAAIAAAbIAVAAIAAgbIAJAAIAAA/g");
  this.shape_105.setTransform(48.2, 53.25);
  this.shape_106 = new cjs.Shape();
  this.shape_106.graphics.f("#0C593C").s().p("AAMAgIAAgwIABgIIgCAIIgUAwIgLAAIAAg/IAJAAIAAAvIgBAJIACgJIAUgvIALAAIAAA/g");
  this.shape_106.setTransform(40.725, 53.25);
  this.shape_107 = new cjs.Shape();
  this.shape_107.graphics.f("#0C593C").s().p("AAPApIAAgSIglAAIAAg/IAJAAIAAA4IAVAAIAAg4IAJAAIAAA4IAHAAIAAAZg");
  this.shape_107.setTransform(33.45, 54.125);
  this.shape_108 = new cjs.Shape();
  this.shape_108.graphics.f("#0C593C").s().p("AAMAgIAAgwIABgIIgCAIIgUAwIgLAAIAAg/IAJAAIAAAvIgBAJIACgJIAUgvIALAAIAAA/g");
  this.shape_108.setTransform(25.675, 53.25);
  this.shape_109 = new cjs.Shape();
  this.shape_109.graphics.f("#0C593C").s().p("AATApIAAgSIglAAIAAASIgIAAIAAgZIAFAAIAFgMIACgJIABgOIAAgVIAiAAIAAA4IAGAAIAAAZgAgEgOQAAAKgCAFQgBAGgEAJIAXAAIAAgwIgQAAg");
  this.shape_109.setTransform(18.125, 54.125);
  this.shape_110 = new cjs.Shape();
  this.shape_110.graphics.f("#0C593C").s().p("AgKAfQgEgDgDgIQgCgHAAgNQAAghATAAQAJAAAEAFQAFAFABAHQABAHAAAKIgeAAIABAOQABAFACADQADADAEAAQAKAAAAgPIAJAAQAAAGgCAGQgCAFgEADQgFADgGAAQgGAAgFgDgAgIgTQgCAFAAAIIAVAAQAAgJgCgFQgCgFgHAAQgFAAgDAGg");
  this.shape_110.setTransform(10.975, 53.225);
  this.shape_111 = new cjs.Shape();
  this.shape_111.graphics.f("#0C593C").s().p("AATAgIAAg4IgQA4IgFAAIgQg4IAAA4IgJAAIAAg/IAOAAIAMApIABANIACgNIAMgpIAOAAIAAA/g");
  this.shape_111.setTransform(3.175, 53.25);
  this.shape_112 = new cjs.Shape();
  this.shape_112.graphics.f("#0C593C").s().p("AgMAfQgEgDgDgIQgDgHAAgNQAAgPAGgJQAFgJALAAQAXAAAAAhQAAANgDAHQgDAIgFADQgFADgHAAQgGAAgGgDgAgHgWQgDACgCAGIgBAPIABAOQACAFADADQADADAEAAQAFAAADgDQADgDABgFQABgGAAgIQAAgJgBgGQgBgGgDgCQgEgDgEAAQgEAAgDADg");
  this.shape_112.setTransform(233.85, 41.025);
  this.shape_113 = new cjs.Shape();
  this.shape_113.graphics.f("#0C593C").s().p("AALAgIAAg3IgVAAIAAA3IgJAAIAAg/IAnAAIAAA/g");
  this.shape_113.setTransform(226.95, 41.05);
  this.shape_114 = new cjs.Shape();
  this.shape_114.graphics.f("#0C593C").s().p("AAMAgIAAgvIABgIIgCAIIgUAvIgLAAIAAg/IAJAAIAAAvIgBAIIACgIIAUgvIALAAIAAA/g");
  this.shape_114.setTransform(216.025, 41.05);
  this.shape_115 = new cjs.Shape();
  this.shape_115.graphics.f("#0C593C").s().p("AAMAgIAAgvIABgIIgCAIIgUAvIgLAAIAAg/IAJAAIAAAvIgBAIIACgIIAUgvIALAAIAAA/g");
  this.shape_115.setTransform(209.075, 41.05);
  this.shape_116 = new cjs.Shape();
  this.shape_116.graphics.f("#0C593C").s().p("AAPApIAAgSIgmAAIAAg/IAJAAIAAA4IAWAAIAAg4IAKAAIAAA4IAFAAIAAAZg");
  this.shape_116.setTransform(202.35, 41.925);
  this.shape_117 = new cjs.Shape();
  this.shape_117.graphics.f("#0C593C").s().p("AALAgIgPggIgHAJIAAAXIgJAAIAAg/IAJAAIAAAeIAVgeIALAAIgUAZIAUAmg");
  this.shape_117.setTransform(195.875, 41.05);
  this.shape_118 = new cjs.Shape();
  this.shape_118.graphics.f("#0C593C").s().p("AgVAqIAAgIIAHABQAEAAADgDQACgDACgHIgUhAIAJAAIAOAyIABAAIAOgyIAJAAIgUA/IgEAMQgBAEgEADQgDADgGAAIgHgBg");
  this.shape_118.setTransform(189.225, 42.15);
  this.shape_119 = new cjs.Shape();
  this.shape_119.graphics.f("#0C593C").s().p("AgVAsIAAhVIAJAAIAAAHIAAAAQACgEAEgCQAEgDADAAQAUAAAAAhIgBANIgCALQgDAFgEACQgEADgFAAQgEAAgEgCQgDgCgDgEIAAAcgAgJgcQgDAIAAALIABAMQABAGADAEQACADAFAAQAHAAADgGQACgHAAgNQAAgZgMAAQgHAAgCAHg");
  this.shape_119.setTransform(182.9, 42.025);
  this.shape_120 = new cjs.Shape();
  this.shape_120.graphics.f("#0C593C").s().p("AgEAgIAAg3IgQAAIAAgIIApAAIAAAIIgRAAIAAA3g");
  this.shape_120.setTransform(176.575, 41.05);
  this.shape_121 = new cjs.Shape();
  this.shape_121.graphics.f("#0C593C").s().p("AgLAdQgFgEgCgHQgCgHAAgKQAAgiAWAAQAJAAAFAHQAFAGAAAJIgJAAQAAgOgLAAQgGAAgDAHQgCAIAAALQAAALACAHQACAHAHAAQAHAAACgEQACgEAAgIIAJAAQAAAKgFAHQgEAHgKAAQgJAAgEgFg");
  this.shape_121.setTransform(170.725, 41.025);
  this.shape_122 = new cjs.Shape();
  this.shape_122.graphics.f("#0C593C").s().p("AALAgIAAgeIgVAAIAAAeIgJAAIAAg/IAJAAIAAAbIAVAAIAAgbIAJAAIAAA/g");
  this.shape_122.setTransform(164.2, 41.05);
  this.shape_123 = new cjs.Shape();
  this.shape_123.graphics.f("#0C593C").s().p("AAMAgIAAgvIABgIIgCAIIgUAvIgLAAIAAg/IAJAAIAAAvIgBAIIACgIIAUgvIALAAIAAA/g");
  this.shape_123.setTransform(157.275, 41.05);
  this.shape_124 = new cjs.Shape();
  this.shape_124.graphics.f("#0C593C").s().p("AAMAgIAAgvIABgIIgCAIIgUAvIgLAAIAAg/IAJAAIAAAvIgBAIIACgIIAUgvIALAAIAAA/g");
  this.shape_124.setTransform(146.325, 41.05);
  this.shape_125 = new cjs.Shape();
  this.shape_125.graphics.f("#0C593C").s().p("AATAgIAAg3IgQA3IgFAAIgQg3IAAA3IgJAAIAAg/IAOAAIAMApIABANIACgNIAMgpIAOAAIAAA/g");
  this.shape_125.setTransform(138.675, 41.05);
  this.shape_126 = new cjs.Shape();
  this.shape_126.graphics.f("#0C593C").s().p("AAVAgIAAg/IAJAAIAAA/gAgdAgIAAg/IAKAAIAAAbIANAAQAFAAADACQAEACACAEQACAEAAAGQAAAFgCAEQgCAFgEACQgDACgFAAgAgTAYIAJAAQAGAAADgCQACgDAAgGQAAgLgKABIgKAAg");
  this.shape_126.setTransform(130.125, 41.05);
  this.shape_127 = new cjs.Shape();
  this.shape_127.graphics.f("#0C593C").s().p("AALAgIAAgeIgWAAIAAAeIgJAAIAAg/IAJAAIAAAbIAWAAIAAgbIAKAAIAAA/g");
  this.shape_127.setTransform(122.4, 41.05);
  this.shape_128 = new cjs.Shape();
  this.shape_128.graphics.f("#0C593C").s().p("AALAgIAAgeIgWAAIAAAeIgJAAIAAg/IAJAAIAAAbIAWAAIAAgbIAKAAIAAA/g");
  this.shape_128.setTransform(115.55, 41.05);
  this.shape_129 = new cjs.Shape();
  this.shape_129.graphics.f("#0C593C").s().p("AgVAQQAAgFABgEQACgEADgCIAKgEIAKgEQADgBAAgHQAAgFgCgDQgDgCgEAAQgFAAgCADQgCADAAAFIgJAAQAAgTATAAQAFAAAEADQAEACACAEQACADAAAFIAAAlQAAAFADAAIACAAIAAAGIgDABQgFAAgCgCQgCgBgBgGIgBAAQgBAEgEADQgDADgFAAQgQAAAAgSgAABABIgHADIgEAFQgCADAAAEQAAAKAJAAQAFAAADgEIACgCIAAgEIABgGIAAgMIgHADg");
  this.shape_129.setTransform(109.025, 41.025);
  this.shape_130 = new cjs.Shape();
  this.shape_130.graphics.f("#0C593C").s().p("AATApIAAgSIglAAIAAASIgIAAIAAgZIAFAAIAFgMIACgJIABgOIAAgVIAiAAIAAA4IAGAAIAAAZgAgEgOQAAAKgCAFQgBAGgEAJIAXAAIAAgwIgQAAg");
  this.shape_130.setTransform(102.375, 41.925);
  this.shape_131 = new cjs.Shape();
  this.shape_131.graphics.f("#0C593C").s().p("AgLAdQgFgEgCgHQgCgHAAgKQAAgiAWAAQAJAAAFAHQAFAGAAAJIgJAAQAAgOgLAAQgGAAgDAHQgCAIAAALQAAALACAHQACAHAHAAQAHAAACgEQACgEAAgIIAJAAQAAAKgFAHQgEAHgKAAQgJAAgEgFg");
  this.shape_131.setTransform(91.825, 41.025);
  this.shape_132 = new cjs.Shape();
  this.shape_132.graphics.f("#0C593C").s().p("AAMAgIAAgvIABgIIgCAIIgUAvIgLAAIAAg/IAJAAIAAAvIgBAIIACgIIAUgvIALAAIAAA/g");
  this.shape_132.setTransform(81.225, 41.05);
  this.shape_133 = new cjs.Shape();
  this.shape_133.graphics.f("#0C593C").s().p("AAMAgIAAgvIABgIIgCAIIgUAvIgLAAIAAg/IAJAAIAAAvIgBAIIACgIIAUgvIALAAIAAA/g");
  this.shape_133.setTransform(74.225, 41.05);
  this.shape_134 = new cjs.Shape();
  this.shape_134.graphics.f("#0C593C").s().p("AgTAgIAAg/IAUAAQAHAAAGAEQAEAEAAAHQAAAGgDAEQgCAEgFABQAGABACAEQAEAEAAAGQAAAGgDAEQgCAEgDACQgEACgEAAgAgKAYIAKAAQAGAAACgCQACgDAAgGQAAgFgCgDQgDgDgFABIgKAAgAgKgEIAKAAQAEAAADgCQACgDAAgFQAAgKgJABIgKAAg");
  this.shape_134.setTransform(67.75, 41.05);
  this.shape_135 = new cjs.Shape();
  this.shape_135.graphics.f("#0C593C").s().p("AgEAgIAAg3IgQAAIAAgIIApAAIAAAIIgRAAIAAA3g");
  this.shape_135.setTransform(61.675, 41.05);
  this.shape_136 = new cjs.Shape();
  this.shape_136.graphics.f("#0C593C").s().p("AgLAdQgFgEgCgHQgCgHAAgKQAAgiAWAAQAJAAAFAHQAFAGAAAJIgJAAQAAgOgLAAQgGAAgDAHQgCAIAAALQAAALACAHQACAHAHAAQAHAAACgEQACgEAAgIIAJAAQAAAKgFAHQgEAHgKAAQgJAAgEgFg");
  this.shape_136.setTransform(55.825, 41.025);
  this.shape_137 = new cjs.Shape();
  this.shape_137.graphics.f("#0C593C").s().p("AgEAgIAAg3IgQAAIAAgIIApAAIAAAIIgRAAIAAA3g");
  this.shape_137.setTransform(49.975, 41.05);
  this.shape_138 = new cjs.Shape();
  this.shape_138.graphics.f("#0C593C").s().p("AgKAfQgEgDgDgIQgCgHAAgNQAAghATAAQAJAAAEAFQAFAFABAHIABARIgeAAIABAOQABAFACADQADADAEAAQAKAAAAgPIAJAAQAAAGgCAGQgCAFgEADQgFADgGAAQgGAAgFgDgAgIgTQgCAFAAAIIAVAAQAAgJgCgFQgCgFgHAAQgFAAgDAGg");
  this.shape_138.setTransform(44.075, 41.025);
  this.shape_139 = new cjs.Shape();
  this.shape_139.graphics.f("#0C593C").s().p("AgTAgIAAg/IAUAAQAIAAAEAEQAGAEAAAHQAAAGgEAEQgCAEgEABQAFABADAEQADAEAAAGQAAAGgCAEQgCAEgEACQgEACgEAAgAgJAYIAJAAQAGAAADgCQACgDAAgGQgBgFgCgDQgDgDgEABIgKAAgAgJgEIAJAAQAEAAACgCQADgDAAgFQAAgKgJABIgJAAg");
  this.shape_139.setTransform(38, 41.05);
  this.shape_140 = new cjs.Shape();
  this.shape_140.graphics.f("#0C593C").s().p("AgEAgIAAg3IgQAAIAAgIIApAAIAAAIIgRAAIAAA3g");
  this.shape_140.setTransform(31.925, 41.05);
  this.shape_141 = new cjs.Shape();
  this.shape_141.graphics.f("#0C593C").s().p("AgLAfQgGgDgCgIQgDgHAAgNQAAgPAFgJQAGgJALAAQAXAAAAAhQAAANgDAHQgCAIgGADQgFADgHAAQgHAAgEgDgAgHgWQgDACgBAGIgBAPIABAOQABAFADADQADADAEAAQAFAAADgDQADgDABgFQACgGAAgIQAAgJgCgGQgBgGgDgCQgDgDgFAAQgEAAgDADg");
  this.shape_141.setTransform(25.7, 41.025);
  this.shape_142 = new cjs.Shape();
  this.shape_142.graphics.f("#0C593C").s().p("AgLAfQgGgDgCgIQgDgHAAgNQAAgPAGgJQAFgJALAAQAXAAAAAhQAAANgDAHQgDAIgFADQgFADgHAAQgGAAgFgDgAgHgWQgDACgBAGIgCAPIACAOQABAFADADQADADAEAAQAFAAADgDQADgDABgFQABgGAAgIQAAgJgBgGQgBgGgDgCQgDgDgFAAQgEAAgDADg");
  this.shape_142.setTransform(18.85, 41.025);
  this.shape_143 = new cjs.Shape();
  this.shape_143.graphics.f("#0C593C").s().p("AgLAdQgFgEgCgHQgCgHAAgKQAAgiAWAAQAJAAAFAHQAFAGAAAJIgJAAQAAgOgLAAQgGAAgDAHQgCAIAAALQAAALACAHQACAHAHAAQAHAAACgEQACgEAAgIIAJAAQAAAKgFAHQgEAHgKAAQgJAAgEgFg");
  this.shape_143.setTransform(12.325, 41.025);
  this.shape_144 = new cjs.Shape();
  this.shape_144.graphics.f("#0C593C").s().p("AgTAgIAAg/IAUAAQAHAAAFAEQAGAEgBAHQAAAGgCAEQgDAEgEABQAFABADAEQADAEAAAGQAAAGgCAEQgCAEgEACQgEACgEAAgAgJAYIAJAAQAGAAADgCQABgDAAgGQABgFgDgDQgDgDgFABIgJAAgAgJgEIAJAAQAEAAADgCQACgDAAgFQAAgKgJABIgJAAg");
  this.shape_144.setTransform(2.2, 41.05);
  this.shape_145 = new cjs.Shape();
  this.shape_145.graphics.f("#0C593C").s().p("AgKAfQgEgDgDgIQgCgHAAgNQAAghATAAQAJAAAEAFQAFAFABAHIABARIgeAAIABAOQABAFACADQADADAEAAQAKAAAAgPIAJAAQAAAGgCAGQgCAFgEADQgFADgGAAQgGAAgFgDgAgIgTQgCAFAAAIIAVAAQAAgJgCgFQgCgFgHAAQgFAAgDAGg");
  this.shape_145.setTransform(233.875, 77.125);
  this.shape_146 = new cjs.Shape();
  this.shape_146.graphics.f("#0C593C").s().p("AALAgIgPggIgIAJIAAAXIgJAAIAAg/IAJAAIAAAeIAWgeIALAAIgUAZIAVAmg");
  this.shape_146.setTransform(229.05, 77.15);
  this.shape_147 = new cjs.Shape();
  this.shape_147.graphics.f("#0C593C").s().p("AALAgIAAgeIgVAAIAAAeIgJAAIAAg/IAJAAIAAAaIAVAAIAAgaIAJAAIAAA/g");
  this.shape_147.setTransform(223.15, 77.15);
  this.shape_148 = new cjs.Shape();
  this.shape_148.graphics.f("#0C593C").s().p("AAVAgIAAg/IAJAAIAAA/gAgdAgIAAg/IAKAAIAAAbIANAAQAFAAADACQAEACACAEQACAEAAAGQAAAFgCAEQgCAFgEABQgDADgFAAgAgTAYIAJAAQAGAAADgDQACgCAAgGQAAgLgKABIgKAAg");
  this.shape_148.setTransform(216.375, 77.15);
  this.shape_149 = new cjs.Shape();
  this.shape_149.graphics.f("#0C593C").s().p("AgVAsIAAhVIAJAAIAAAHIAAAAQACgEAEgCQAEgDACAAQAWAAAAAhIgBANQgBAGgDAFQgCAFgEACQgEADgGAAQgEAAgDgCIgGgGIAAAcgAgJgcQgDAIAAALIABAMQABAGACAEQADADAFAAQAGAAADgGQADgHAAgNQAAgZgMAAQgHAAgCAHg");
  this.shape_149.setTransform(209.725, 78.125);
  this.shape_150 = new cjs.Shape();
  this.shape_150.graphics.f("#0C593C").s().p("AgVAQQAAgFABgEQACgEADgCIAKgEIAKgEQADgBAAgHQAAgFgCgDQgDgCgEAAQgFAAgCADQgCADAAAFIgJAAQAAgTATAAQAFAAAEADQAEACACAEQACADAAAFIAAAlQAAAFADAAIACAAIAAAGIgDABQgFAAgCgCQgCgBgBgGQgCAEgEADQgDADgFAAQgQAAAAgSgAABABIgHADIgEAFQgCADAAAEQAAAKAJAAQAFAAADgEIACgCIAAgEIABgGIAAgMIgHADg");
  this.shape_150.setTransform(201.075, 77.125);
  this.shape_151 = new cjs.Shape();
  this.shape_151.graphics.f("#0C593C").s().p("AAMAgIAAgeIgXAAIAAAeIgJAAIAAg/IAJAAIAAAaIAXAAIAAgaIAJAAIAAA/g");
  this.shape_151.setTransform(195.55, 77.15);
  this.shape_152 = new cjs.Shape();
  this.shape_152.graphics.f("#0C593C").s().p("AAPAgIgPgbIgOAbIgKAAIAUggIgTgfIAKAAIAOAZIANgZIAKAAIgTAfIAUAgg");
  this.shape_152.setTransform(183.975, 77.15);
  this.shape_153 = new cjs.Shape();
  this.shape_153.graphics.f("#0C593C").s().p("AAVAgIAAg/IAJAAIAAA/gAgdAgIAAg/IAKAAIAAAbIANAAQAFAAADACQAEACACAEQACAEAAAGQAAAFgCAEQgCAFgEABQgDADgFAAgAgTAYIAJAAQAGAAADgDQACgCAAgGQAAgLgKABIgKAAg");
  this.shape_153.setTransform(177.525, 77.15);
  this.shape_154 = new cjs.Shape();
  this.shape_154.graphics.f("#0C593C").s().p("AALAgIAAgeIgWAAIAAAeIgJAAIAAg/IAJAAIAAAaIAWAAIAAgaIAKAAIAAA/g");
  this.shape_154.setTransform(170.75, 77.15);
  this.shape_155 = new cjs.Shape();
  this.shape_155.graphics.f("#0C593C").s().p("AAMAgIAAgeIgXAAIAAAeIgJAAIAAg/IAJAAIAAAaIAXAAIAAgaIAIAAIAAA/g");
  this.shape_155.setTransform(164.9, 77.15);
  this.shape_156 = new cjs.Shape();
  this.shape_156.graphics.f("#0C593C").s().p("AgKAfQgEgDgDgIQgCgHAAgNQAAghATAAQAJAAAEAFQAFAFABAHIABARIgeAAIABAOQABAFACADQADADAEAAQAKAAAAgPIAJAAQAAAGgCAGQgCAFgEADQgFADgGAAQgGAAgFgDgAgIgTQgCAFAAAIIAVAAQAAgJgCgFQgCgFgHAAQgFAAgDAGg");
  this.shape_156.setTransform(159.325, 77.125);
  this.shape_157 = new cjs.Shape();
  this.shape_157.graphics.f("#0C593C").s().p("AgXAfIAAgHIAEABQAAAAABAAQABAAAAgBQAAAAABAAQAAgBABAAQABgCABgFIAAgQIAAgfIAlAAIAAA/IgJAAIAAg4IgTAAIAAAZQAAAPgDAIQgDAIgIAAIgFgBg");
  this.shape_157.setTransform(153.475, 77.175);
  this.shape_158 = new cjs.Shape();
  this.shape_158.graphics.f("#0C593C").s().p("AgTAgIAAg/IAUAAQAIAAAEAEQAGAEAAAHQAAAGgDAEQgDAEgEACQAFAAADAEQADAEAAAGQAAAGgCAEQgCAEgEACQgEACgEAAgAgJAYIAJAAQAGAAADgCQABgDAAgGQAAgFgCgDQgDgCgEAAIgKAAgAgJgEIAJAAQAEAAADgCQACgDAAgGQAAgJgJAAIgJAAg");
  this.shape_158.setTransform(148.35, 77.15);
  this.shape_159 = new cjs.Shape();
  this.shape_159.graphics.f("#0C593C").s().p("AgVAQQAAgFABgEQACgEADgCIAKgEIAKgEQADgBAAgHQAAgFgCgDQgDgCgEAAQgFAAgCADQgCADAAAFIgJAAQAAgTATAAQAFAAAEADQAEACACAEQACADAAAFIAAAlQAAAFADAAIACAAIAAAGIgDABQgFAAgCgCQgCgBgBgGQgCAEgEADQgDADgFAAQgQAAAAgSgAABABIgHADIgEAFQgCADAAAEQAAAKAJAAQAFAAADgEIACgCIAAgEIABgGIAAgMIgHADg");
  this.shape_159.setTransform(142.925, 77.125);
  this.shape_160 = new cjs.Shape();
  this.shape_160.graphics.f("#0C593C").s().p("AgEAgIAAg4IgQAAIAAgHIApAAIAAAHIgRAAIAAA4g");
  this.shape_160.setTransform(138.025, 77.15);
  this.shape_161 = new cjs.Shape();
  this.shape_161.graphics.f("#0C593C").s().p("AgMAdQgFgEgCgHQgBgHAAgKQAAgiAWAAQAIAAAFAHQAGAGAAAJIgJAAQAAgOgLAAQgGAAgDAHQgCAIgBALQABALACAHQACAHAHAAQAGAAADgEQABgEABgIIAJAAQAAAKgFAHQgFAHgJAAQgJAAgFgFg");
  this.shape_161.setTransform(133.2, 77.125);
  this.shape_162 = new cjs.Shape();
  this.shape_162.graphics.f("#0C593C").s().p("AATApIAAgSIglAAIAAASIgIAAIAAgZIAFAAIAFgMIACgJIABgOIAAgVIAiAAIAAA4IAGAAIAAAZgAgEgOQAAAKgCAFQgBAGgEAJIAXAAIAAgwIgQAAg");
  this.shape_162.setTransform(127.525, 78.025);
  this.shape_163 = new cjs.Shape();
  this.shape_163.graphics.f("#0C593C").s().p("AgKAfQgEgDgDgIQgCgHAAgNQAAghATAAQAJAAAEAFQAFAFABAHIABARIgeAAIABAOQABAFACADQADADAEAAQAKAAAAgPIAJAAQAAAGgCAGQgCAFgEADQgFADgGAAQgGAAgFgDgAgIgTQgCAFAAAIIAVAAQAAgJgCgFQgCgFgHAAQgFAAgDAGg");
  this.shape_163.setTransform(121.925, 77.125);
  this.shape_164 = new cjs.Shape();
  this.shape_164.graphics.f("#0C593C").s().p("AgVAsIAAhVIAJAAIAAAHIAAAAQACgEAEgCQAEgDACAAQAWAAAAAhIgBANQgBAGgDAFQgCAFgEACQgEADgGAAQgEAAgDgCIgGgGIAAAcgAgJgcQgDAIAAALIABAMQABAGACAEQADADAFAAQAGAAADgGQADgHAAgNQAAgZgMAAQgHAAgCAHg");
  this.shape_164.setTransform(116.525, 78.125);
  this.shape_165 = new cjs.Shape();
  this.shape_165.graphics.f("#0C593C").s().p("AALAgIAAg4IgVAAIAAA4IgJAAIAAg/IAnAAIAAA/g");
  this.shape_165.setTransform(110.55, 77.15);
  this.shape_166 = new cjs.Shape();
  this.shape_166.graphics.f("#0C593C").s().p("AgEAJQAFgCAAgJIgFAAIAAgLIAJAAIAAANQAAAEgCAFQgDAEgEABg");
  this.shape_166.setTransform(103.075, 80.625);
  this.shape_167 = new cjs.Shape();
  this.shape_167.graphics.f("#0C593C").s().p("AgTAgIAAg/IAUAAQAHAAAGAEQAEAEAAAHQAAAGgCAEQgDAEgEACQAFAAADAEQADAEAAAGQAAAGgDAEQgCAEgDACQgEACgEAAgAgJAYIAJAAQAGAAADgCQABgDAAgGQABgFgDgDQgDgCgFAAIgJAAgAgJgEIAJAAQAEAAADgCQACgDAAgGQAAgJgJAAIgJAAg");
  this.shape_167.setTransform(99.05, 77.15);
  this.shape_168 = new cjs.Shape();
  this.shape_168.graphics.f("#0C593C").s().p("AgEAgIAAg4IgQAAIAAgHIApAAIAAAHIgRAAIAAA4g");
  this.shape_168.setTransform(93.975, 77.15);
  this.shape_169 = new cjs.Shape();
  this.shape_169.graphics.f("#0C593C").s().p("AgLAdQgGgEgBgHQgCgHAAgKQAAgiAVAAQAJAAAGAHQAFAGAAAJIgJAAQAAgOgLAAQgGAAgDAHQgDAIABALQgBALADAHQACAHAHAAQAGAAACgEQACgEABgIIAJAAQAAAKgFAHQgEAHgLAAQgIAAgEgFg");
  this.shape_169.setTransform(89.15, 77.125);
  this.shape_170 = new cjs.Shape();
  this.shape_170.graphics.f("#0C593C").s().p("AATApIAAgSIglAAIAAASIgIAAIAAgZIAFAAIAFgMIACgJIABgOIAAgVIAiAAIAAA4IAGAAIAAAZgAgEgOQAAAKgCAFQgBAGgEAJIAXAAIAAgwIgQAAg");
  this.shape_170.setTransform(83.425, 78.025);
  this.shape_171 = new cjs.Shape();
  this.shape_171.graphics.f("#0C593C").s().p("AgKAfQgEgDgDgIQgCgHAAgNQAAghATAAQAJAAAEAFQAFAFABAHIABARIgeAAIABAOQABAFACADQADADAEAAQAKAAAAgPIAJAAQAAAGgCAGQgCAFgEADQgFADgGAAQgGAAgFgDgAgIgTQgCAFAAAIIAVAAQAAgJgCgFQgCgFgHAAQgFAAgDAGg");
  this.shape_171.setTransform(77.825, 77.125);
  this.shape_172 = new cjs.Shape();
  this.shape_172.graphics.f("#0C593C").s().p("AgVAsIAAhVIAJAAIAAAHIAAAAQACgEAEgCQAEgDACAAQAWAAAAAhIgBANQgBAGgDAFQgCAFgEACQgEADgGAAQgEAAgDgCIgGgGIAAAcgAgJgcQgDAIAAALIABAMQABAGACAEQADADAFAAQAGAAADgGQADgHAAgNQAAgZgMAAQgHAAgCAHg");
  this.shape_172.setTransform(72.475, 78.125);
  this.shape_173 = new cjs.Shape();
  this.shape_173.graphics.f("#0C593C").s().p("AgLAdQgFgEgDgHQgBgHAAgKQAAgiAVAAQAKAAAFAHQAFAGAAAJIgJAAQAAgOgLAAQgGAAgDAHQgCAIgBALQABALACAHQACAHAHAAQAGAAACgEQACgEABgIIAJAAQAAAKgFAHQgFAHgKAAQgIAAgEgFg");
  this.shape_173.setTransform(66.85, 77.125);
  this.shape_174 = new cjs.Shape();
  this.shape_174.graphics.f("#0C593C").s().p("AAPAgIgPgbIgOAbIgKAAIAUggIgTgfIAKAAIAOAZIANgZIAKAAIgTAfIAUAgg");
  this.shape_174.setTransform(58.575, 77.15);
  this.shape_175 = new cjs.Shape();
  this.shape_175.graphics.f("#0C593C").s().p("AAVAgIAAg/IAJAAIAAA/gAgdAgIAAg/IAKAAIAAAbIANAAQAFAAADACQAEACACAEQACAEAAAGQAAAFgCAEQgCAFgEABQgDADgFAAgAgTAYIAJAAQAGAAADgDQACgCAAgGQAAgLgKABIgKAAg");
  this.shape_175.setTransform(52.125, 77.15);
  this.shape_176 = new cjs.Shape();
  this.shape_176.graphics.f("#0C593C").s().p("AAMAgIAAgeIgXAAIAAAeIgJAAIAAg/IAJAAIAAAaIAXAAIAAgaIAJAAIAAA/g");
  this.shape_176.setTransform(45.35, 77.15);
  this.shape_177 = new cjs.Shape();
  this.shape_177.graphics.f("#0C593C").s().p("AAMAgIAAgeIgXAAIAAAeIgJAAIAAg/IAJAAIAAAaIAXAAIAAgaIAJAAIAAA/g");
  this.shape_177.setTransform(39.5, 77.15);
  this.shape_178 = new cjs.Shape();
  this.shape_178.graphics.f("#0C593C").s().p("AgMAfQgEgDgEgIQgCgHAAgNQAAgPAFgJQAGgJALAAQAXAAAAAhQAAANgDAHQgDAIgEADQgGADgHAAQgHAAgFgDgAgHgWQgDACgCAGIAAAPIAAAOQACAFADADQADADAEAAQAFAAADgDQADgDABgFQABgGABgIQgBgJgBgGQgCgGgDgCQgCgDgFAAQgEAAgDADg");
  this.shape_178.setTransform(33.65, 77.125);
  this.shape_179 = new cjs.Shape();
  this.shape_179.graphics.f("#0C593C").s().p("AgQAgIAAg/IAhAAIAAAHIgYAAIAAA4g");
  this.shape_179.setTransform(28.9, 77.15);
  this.shape_180 = new cjs.Shape();
  this.shape_180.graphics.f("#0C593C").s().p("AgMAfQgFgDgDgIQgCgHAAgNQAAgPAGgJQAFgJALAAQAXAAAAAhQAAANgDAHQgDAIgEADQgFADgIAAQgHAAgFgDgAgHgWQgDACgCAGIgBAPIABAOQACAFADADQADADAEAAQAFAAADgDQADgDABgFQABgGABgIQgBgJgBgGQgBgGgEgCQgCgDgFAAQgEAAgDADg");
  this.shape_180.setTransform(23.4, 77.125);
  this.shape_181 = new cjs.Shape();
  this.shape_181.graphics.f("#0C593C").s().p("AgVAsIAAhVIAJAAIAAAHIAAAAQACgEAEgCQAEgDACAAQAWAAAAAhIgBANQgBAGgDAFQgCAFgEACQgEADgGAAQgEAAgDgCIgGgGIAAAcgAgJgcQgDAIAAALIABAMQABAGACAEQADADAFAAQAGAAADgGQADgHAAgNQAAgZgMAAQgHAAgCAHg");
  this.shape_181.setTransform(17.675, 78.125);
  this.shape_182 = new cjs.Shape();
  this.shape_182.graphics.f("#0C593C").s().p("AgEAgIAAg4IgQAAIAAgHIApAAIAAAHIgRAAIAAA4g");
  this.shape_182.setTransform(12.375, 77.15);
  this.shape_183 = new cjs.Shape();
  this.shape_183.graphics.f("#0C593C").s().p("AgKAfQgEgDgDgIQgCgHAAgNQAAghATAAQAJAAAEAFQAFAFABAHIABARIgeAAIABAOQABAFACADQADADAEAAQAKAAAAgPIAJAAQAAAGgCAGQgCAFgEADQgFADgGAAQgGAAgFgDgAgIgTQgCAFAAAIIAVAAQAAgJgCgFQgCgFgHAAQgFAAgDAGg");
  this.shape_183.setTransform(7.425, 77.125);
  this.shape_184 = new cjs.Shape();
  this.shape_184.graphics.f("#0C593C").s().p("AgTAgIAAg/IAUAAQAIAAAEAEQAFAEABAHQAAAGgEAEQgCAEgEACQAFAAADAEQADAEAAAGQAAAGgCAEQgDAEgDACQgEACgEAAgAgKAYIAKAAQAGAAADgCQACgDAAgGQgBgFgCgDQgCgCgFAAIgLAAgAgKgEIAKAAQAEAAACgCQADgDAAgGQAAgJgJAAIgKAAg");
  this.shape_184.setTransform(2.35, 77.15);
  this.shape_185 = new cjs.Shape();
  this.shape_185.graphics.f("#0C593C").s().p("AgEAgIAAgMIAJAAIAAAMgAgEgTIAAgLIAJAAIAAALg");
  this.shape_185.setTransform(235.225, 29.3);
  this.shape_186 = new cjs.Shape();
  this.shape_186.graphics.f("#0C593C").s().p("AgVAQQAAgFABgEQACgEADgCQAEgBAGgDIAKgEQACgBABgHQgBgFgBgDQgCgCgFAAQgFAAgDADQgBADAAAFIgJAAQAAgTATAAQAFAAAEADQAEACACAEQACADAAAFIAAAlQAAAFADAAIADAAIAAAGIgFABQgEAAgCgCQgCgBgBgGIgBAAQgBAEgEADQgEADgEAAQgQAAAAgSgAAAABIgGADIgEAFQgCADAAAEQAAAKAJAAQAFAAADgEIACgCIABgEIAAgGIAAgMIgIADg");
  this.shape_186.setTransform(231, 29.225);
  this.shape_187 = new cjs.Shape();
  this.shape_187.graphics.f("#0C593C").s().p("AgTAgIAAg/IAUAAQAHAAAGAEQAEAFAAAGQAAAGgCAEQgDAEgFABQAGABADAEQADAEAAAGQAAAGgCAEQgCAEgEACQgDACgFAAgAgKAYIAKAAQAGABACgDQADgDAAgGQAAgFgDgDQgDgDgEABIgLAAgAgKgEIAKAAQAEAAADgCQACgDAAgFQAAgKgJABIgKAAg");
  this.shape_187.setTransform(225.7, 29.25);
  this.shape_188 = new cjs.Shape();
  this.shape_188.graphics.f("#0C593C").s().p("AgEAgIAAg3IgRAAIAAgIIArAAIAAAIIgSAAIAAA3g");
  this.shape_188.setTransform(220.5, 29.25);
  this.shape_189 = new cjs.Shape();
  this.shape_189.graphics.f("#0C593C").s().p("AgLAdQgGgEgBgHQgCgHAAgKQAAgiAVAAQAKAAAFAHQAFAGAAAJIgJAAQAAgOgLAAQgGAAgDAHQgCAIAAALQAAALACAHQACAHAHAAQAGAAADgEQACgEAAgIIAJAAQAAAKgEAHQgGAHgKAAQgIAAgEgFg");
  this.shape_189.setTransform(215.5, 29.225);
  this.shape_190 = new cjs.Shape();
  this.shape_190.graphics.f("#0C593C").s().p("AATApIAAgSIglAAIAAASIgJAAIAAgZIAGAAIAFgMIACgJIABgOIAAgVIAjAAIAAA4IAGAAIAAAZgAgEgOQAAAKgCAFQgCAGgEAJIAYAAIAAgwIgQAAg");
  this.shape_190.setTransform(209.7, 30.125);
  this.shape_191 = new cjs.Shape();
  this.shape_191.graphics.f("#0C593C").s().p("AgKAfQgEgDgDgIQgDgHAAgNQABghATAAQAJAAAEAFQAFAFABAHQABAHABAKIgfAAIABAOQAAAFADADQADADAEAAQAKAAAAgPIAKAAQAAAGgCAGQgCAFgFADQgEADgHAAQgGAAgFgDgAgHgTQgDAFAAAIIAVAAQAAgJgCgFQgDgFgFAAQgHAAgBAGg");
  this.shape_191.setTransform(203.95, 29.225);
  this.shape_192 = new cjs.Shape();
  this.shape_192.graphics.f("#0C593C").s().p("AgVAsIAAhVIAJAAIAAAHIAAAAQACgEAEgCQAEgDADAAQAVAAAAAhIgBANIgDALQgDAFgEACQgEADgGAAQgDAAgEgCIgGgGIAAAcgAgJgcQgDAIAAALIABAMQABAGADAEQACADAFAAQAHAAACgGQADgHAAgNQAAgZgMAAQgHAAgCAHg");
  this.shape_192.setTransform(198.425, 30.225);
  this.shape_193 = new cjs.Shape();
  this.shape_193.graphics.f("#0C593C").s().p("AgLAdQgGgEgBgHQgCgHAAgKQAAgiAVAAQAKAAAFAHQAFAGAAAJIgJAAQAAgOgLAAQgGAAgDAHQgCAIAAALQgBALADAHQACAHAHAAQAGAAADgEQACgEAAgIIAJAAQAAAKgEAHQgFAHgLAAQgHAAgFgFg");
  this.shape_193.setTransform(192.65, 29.225);
  this.shape_194 = new cjs.Shape();
  this.shape_194.graphics.f("#0C593C").s().p("AgMAfQgFgDgDgIQgCgHAAgNQAAgPAFgJQAGgJALAAQAXAAAAAhQAAANgDAHQgCAIgGADQgFADgHAAQgHAAgFgDgAgHgWQgDACgBAGQgCAGAAAJIABAOQACAFADADQADADAEAAQAFAAADgDQADgDABgFIABgOIgBgPQgBgGgDgCQgDgDgFAAQgEAAgDADg");
  this.shape_194.setTransform(183.825, 29.225);
  this.shape_195 = new cjs.Shape();
  this.shape_195.graphics.f("#0C593C").s().p("AgQAgIAAg/IAhAAIAAAIIgYAAIAAA3g");
  this.shape_195.setTransform(178.95, 29.25);
  this.shape_196 = new cjs.Shape();
  this.shape_196.graphics.f("#0C593C").s().p("AgMAfQgFgDgDgIQgCgHAAgNQAAgPAFgJQAGgJALAAQAXAAAAAhQAAANgDAHQgCAIgGADQgFADgHAAQgHAAgFgDgAgHgWQgDACgBAGQgCAGAAAJIABAOQACAFADADQADADAEAAQAFAAADgDQADgDABgFIABgOIgBgPQgBgGgDgCQgDgDgFAAQgEAAgDADg");
  this.shape_196.setTransform(173.325, 29.225);
  this.shape_197 = new cjs.Shape();
  this.shape_197.graphics.f("#0C593C").s().p("AALAgIAAgeIgWAAIAAAeIgJAAIAAg/IAJAAIAAAbIAWAAIAAgbIAKAAIAAA/g");
  this.shape_197.setTransform(167.325, 29.25);
  this.shape_198 = new cjs.Shape();
  this.shape_198.graphics.f("#0C593C").s().p("AAKAgIAAgeQgFABgIABQgIAAgEgFQgEgEAAgHIAAgTIAJAAIAAASQAAAFACADQADABAFAAIAKAAIAAgbIAKAAIAAA/g");
  this.shape_198.setTransform(161.375, 29.25);
  this.shape_199 = new cjs.Shape();
  this.shape_199.graphics.f("#0C593C").s().p("AAVAgIAAg/IAJAAIAAA/gAgdAgIAAg/IAJAAIAAAbIAOAAQAFAAADACQAEACACAEQACAFABAFQgBAFgCAEQgCAEgEADQgEACgEAAgAgUAYIAKAAQAGAAADgCQACgDAAgFQAAgMgKABIgLAAg");
  this.shape_199.setTransform(154.55, 29.25);
  this.shape_200 = new cjs.Shape();
  this.shape_200.graphics.f("#0C593C").s().p("AgNAoQgFgEgCgIQgCgJAAgNIABgRQABgIADgFQADgFAEgDQADgDAGgBIAJgDQAEgBAAgDIAIAAQgCAGgEADQgFADgIACQgGACgEAEQgEAGAAAIQAFgKAJAAQAHAAAFADQAFAEACAHQADAGAAAJQAAAMgCAHQgDAIgFADQgFAEgIAAQgIAAgFgEgAgJgFQgEAFAAAKQAAAJACAGQABAGADADQADADAEAAQAHgBADgGQADgHAAgNQAAgKgDgFQgDgHgHAAQgGAAgDAHg");
  this.shape_200.setTransform(147.825, 28.2);
  this.shape_201 = new cjs.Shape();
  this.shape_201.graphics.f("#0C593C").s().p("AgMAfQgFgDgDgIQgCgHAAgNQAAgPAFgJQAGgJALAAQAXAAAAAhQAAANgDAHQgCAIgGADQgFADgHAAQgHAAgFgDgAgHgWQgDACgBAGQgCAGAAAJIABAOQACAFADADQADADAEAAQAFAAADgDQADgDABgFIABgOIgBgPQgBgGgDgCQgDgDgFAAQgEAAgDADg");
  this.shape_201.setTransform(142.075, 29.225);
  this.shape_202 = new cjs.Shape();
  this.shape_202.graphics.f("#0C593C").s().p("AgYAfIAAgHIAFABQAAAAABAAQAAAAABgBQAAAAABAAQAAgBAAAAQACgCAAgFIABgQIAAgfIAmAAIAAA/IgKAAIAAg4IgTAAIAAAZQAAAPgDAIQgDAIgIAAIgGgBg");
  this.shape_202.setTransform(132.6, 29.275);
  this.shape_203 = new cjs.Shape();
  this.shape_203.graphics.f("#0C593C").s().p("AgVAqIAAgIIAHABQAEAAACgDQADgDACgHIgUhAIAJAAIAOAyIAPgyIAJAAIgTA/IgFAMQgBAEgDADQgFADgFAAIgHgBg");
  this.shape_203.setTransform(127.15, 30.35);
  this.shape_204 = new cjs.Shape();
  this.shape_204.graphics.f("#0C593C").s().p("AgLAdQgGgEgBgHQgCgHAAgKQAAgiAVAAQAKAAAFAHQAFAGAAAJIgJAAQAAgOgLAAQgGAAgDAHQgCAIAAALQAAALACAHQACAHAHAAQAGAAADgEQACgEAAgIIAJAAQAAAKgEAHQgGAHgKAAQgIAAgEgFg");
  this.shape_204.setTransform(121.9, 29.225);
  this.shape_205 = new cjs.Shape();
  this.shape_205.graphics.f("#0C593C").s().p("AALAgIAAg3IgWAAIAAA3IgJAAIAAg/IApAAIAAA/g");
  this.shape_205.setTransform(116.225, 29.25);
  this.shape_206 = new cjs.Shape();
  this.shape_206.graphics.f("#0C593C").s().p("AgWAQQAAgFACgEQACgEADgCQADgBAHgDIAKgEQADgBAAgHQAAgFgDgDQgBgCgFAAQgFAAgCADQgCADAAAFIgJAAQAAgTATAAQAFAAAEADQAEACACAEQACADAAAFIAAAlQAAAFADAAIACAAIAAAGIgDABQgFAAgCgCQgCgBgBgGIAAAAQgCAEgEADQgEADgEAAQgRAAAAgSgAABABIgHADIgEAFQgCADAAAEQAAAKAJAAQAEAAAEgEIACgCIABgEIAAgGIAAgMIgHADg");
  this.shape_206.setTransform(110.55, 29.225);
  this.shape_207 = new cjs.Shape();
  this.shape_207.graphics.f("#0C593C").s().p("AALAgIgPggIgHAJIAAAXIgJAAIAAg/IAJAAIAAAeIAVgeIALAAIgUAZIAVAmg");
  this.shape_207.setTransform(105.55, 29.25);
  this.shape_208 = new cjs.Shape();
  this.shape_208.graphics.f("#0C593C").s().p("AgWArQgBgIACgFQABgGAGgGQAEgFAJgIQAGgFAEgFQADgGABgHQgBgQgMAAQgHAAgDAGQgCAFAAAKIgKAAIAAgEQABgHACgGQADgGAEgDQAFgDAIAAQAHAAAFADQAFADADAFQACAGAAAHQAAAGgCAFQgCAFgEADIgIAIIgMAMIgFAGIgCAIIAjAAIAAAIg");
  this.shape_208.setTransform(96.3, 28.125);
  this.shape_209 = new cjs.Shape();
  this.shape_209.graphics.f("#0C593C").s().p("AgMAfQgFgDgDgIQgCgHAAgNQAAgPAFgJQAGgJALAAQAXAAAAAhQAAANgDAHQgCAIgGADQgFADgHAAQgHAAgFgDgAgHgWQgDACgBAGQgCAGAAAJIABAOQACAFADADQADADAEAAQAFAAADgDQADgDABgFIABgOIgBgPQgBgGgDgCQgDgDgFAAQgEAAgDADg");
  this.shape_209.setTransform(87.225, 29.225);
  this.shape_210 = new cjs.Shape();
  this.shape_210.graphics.f("#0C593C").s().p("AgEAgIAAg3IgRAAIAAgIIArAAIAAAIIgSAAIAAA3g");
  this.shape_210.setTransform(81.9, 29.25);
  this.shape_211 = new cjs.Shape();
  this.shape_211.graphics.f("#0C593C").s().p("AgLAdQgGgEgBgHQgCgHAAgKQAAgiAVAAQAKAAAFAHQAFAGAAAJIgJAAQAAgOgLAAQgGAAgDAHQgCAIAAALQAAALACAHQACAHAHAAQAGAAADgEQACgEAAgIIAJAAQAAAKgEAHQgGAHgKAAQgIAAgEgFg");
  this.shape_211.setTransform(76.9, 29.225);
  this.shape_212 = new cjs.Shape();
  this.shape_212.graphics.f("#0C593C").s().p("AgKAfQgEgDgDgIQgCgHAAgNQAAghATAAQAJAAAEAFQAFAFABAHQACAHgBAKIgeAAIABAOQAAAFADADQADADADAAQALAAAAgPIAJAAQAAAGgCAGQgCAFgEADQgFADgGAAQgGAAgFgDgAgHgTQgDAFAAAIIAVAAQAAgJgCgFQgDgFgGAAQgGAAgBAGg");
  this.shape_212.setTransform(71.5, 29.225);
  this.shape_213 = new cjs.Shape();
  this.shape_213.graphics.f("#0C593C").s().p("AATAgIAAg3IgQA3IgFAAIgRg3IAAA3IgJAAIAAg/IAPAAIAMApIABANIADgNIALgpIAOAAIAAA/g");
  this.shape_213.setTransform(65.05, 29.25);
  this.shape_214 = new cjs.Shape();
  this.shape_214.graphics.f("#0C593C").s().p("AgTAgIAAg/IAUAAQAIAAAEAEQAGAFAAAGQgBAGgCAEQgDAEgEABQAFABADAEQADAEAAAGQAAAGgCAEQgCAEgEACQgEACgEAAgAgJAYIAJAAQAHABACgDQACgDAAgGQAAgFgDgDQgCgDgFABIgKAAgAgJgEIAJAAQAFAAACgCQACgDABgFQgBgKgJABIgJAAg");
  this.shape_214.setTransform(58.7, 29.25);
  this.shape_215 = new cjs.Shape();
  this.shape_215.graphics.f("#0C593C").s().p("AgWAQQABgFABgEQACgEAEgCQADgBAGgDIAKgEQACgBAAgHQAAgFgCgDQgCgCgEAAQgFAAgCADQgDADAAAFIgIAAQAAgTATAAQAFAAAEADQAEACACAEQACADAAAFIAAAlQAAAFAEAAIABAAIAAAGIgDABQgFAAgCgCQgCgBgBgGIAAAAQgCAEgEADQgDADgFAAQgRAAAAgSgAABABIgHADIgEAFQgCADAAAEQAAAKAJAAQAEAAAEgEIABgCIABgEIAAgGIAAgMIgGADg");
  this.shape_215.setTransform(50.05, 29.225);
  this.shape_216 = new cjs.Shape();
  this.shape_216.graphics.f("#0C593C").s().p("AgXAfIAAgHIADABQABAAABAAQAAAAABgBQAAAAABAAQAAgBABAAQABgCABgFIAAgQIAAgfIAlAAIAAA/IgJAAIAAg4IgTAAIAAAZQAAAPgDAIQgDAIgIAAIgFgBg");
  this.shape_216.setTransform(44, 29.275);
  this.shape_217 = new cjs.Shape();
  this.shape_217.graphics.f("#0C593C").s().p("AgVAqIAAgIIAGABQAFAAADgDQACgDACgHIgVhAIAKAAIAPAyIAOgyIAKAAIgVA/IgEAMQgBAEgEADQgDADgHAAIgGgBg");
  this.shape_217.setTransform(38.55, 30.35);
  this.shape_218 = new cjs.Shape();
  this.shape_218.graphics.f("#0C593C").s().p("AgMAdQgFgEgCgHQgBgHAAgKQAAgiAWAAQAJAAAFAHQAFAGAAAJIgIAAQgBgOgKAAQgHAAgCAHQgEAIAAALQABALACAHQACAHAHAAQAHAAACgEQACgEABgIIAIAAQAAAKgFAHQgFAHgJAAQgJAAgFgFg");
  this.shape_218.setTransform(33.3, 29.225);
  this.shape_219 = new cjs.Shape();
  this.shape_219.graphics.f("#0C593C").s().p("AALAgIAAg3IgWAAIAAA3IgJAAIAAg/IApAAIAAA/g");
  this.shape_219.setTransform(27.625, 29.25);
  this.shape_220 = new cjs.Shape();
  this.shape_220.graphics.f("#0C593C").s().p("AgVAQQgBgFACgEQACgEAEgCQADgBAGgDIAKgEQADgBgBgHQAAgFgBgDQgDgCgEAAQgFAAgDADQgCADAAAFIgIAAQAAgTATAAQAFAAAEADQAEACACAEQACADAAAFIAAAlQAAAFAEAAIACAAIAAAGIgFABQgEAAgCgCQgCgBgBgGIgBAAQgBAEgEADQgDADgFAAQgQAAAAgSgAAAABIgGADIgEAFQgCADAAAEQAAAKAJAAQAFAAADgEIABgCIABgEIAAgGIAAgMIgHADg");
  this.shape_220.setTransform(21.95, 29.225);
  this.shape_221 = new cjs.Shape();
  this.shape_221.graphics.f("#0C593C").s().p("AALAgIgPggIgIAJIAAAXIgJAAIAAg/IAJAAIAAAeIAWgeIALAAIgUAZIAUAmg");
  this.shape_221.setTransform(16.95, 29.25);
  this.shape_222 = new cjs.Shape();
  this.shape_222.graphics.f("#0C593C").s().p("AAEArIAAg+IgRAAIAAgHIALgBQADgCACgDQADgEABgGIAHAAIAABVg");
  this.shape_222.setTransform(7.125, 28.125);
  this.shape_223 = new cjs.Shape();
  this.shape_223.graphics.f("#0C593C").s().p("AAAAFIgIAMIgFgEIAJgLIgNgDIACgGIAOAGIAAgPIAEAAIAAAOIANgFIACAGIgNADIAIALIgEAEg");
  this.shape_223.setTransform(1.75, 25.5);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_223
   }, {
    t: this.shape_222
   }, {
    t: this.shape_221
   }, {
    t: this.shape_220
   }, {
    t: this.shape_219
   }, {
    t: this.shape_218
   }, {
    t: this.shape_217
   }, {
    t: this.shape_216
   }, {
    t: this.shape_215
   }, {
    t: this.shape_214
   }, {
    t: this.shape_213
   }, {
    t: this.shape_212
   }, {
    t: this.shape_211
   }, {
    t: this.shape_210
   }, {
    t: this.shape_209
   }, {
    t: this.shape_208
   }, {
    t: this.shape_207
   }, {
    t: this.shape_206
   }, {
    t: this.shape_205
   }, {
    t: this.shape_204
   }, {
    t: this.shape_203
   }, {
    t: this.shape_202
   }, {
    t: this.shape_201
   }, {
    t: this.shape_200
   }, {
    t: this.shape_199
   }, {
    t: this.shape_198
   }, {
    t: this.shape_197
   }, {
    t: this.shape_196
   }, {
    t: this.shape_195
   }, {
    t: this.shape_194
   }, {
    t: this.shape_193
   }, {
    t: this.shape_192
   }, {
    t: this.shape_191
   }, {
    t: this.shape_190
   }, {
    t: this.shape_189
   }, {
    t: this.shape_188
   }, {
    t: this.shape_187
   }, {
    t: this.shape_186
   }, {
    t: this.shape_185
   }, {
    t: this.shape_184
   }, {
    t: this.shape_183
   }, {
    t: this.shape_182
   }, {
    t: this.shape_181
   }, {
    t: this.shape_180
   }, {
    t: this.shape_179
   }, {
    t: this.shape_178
   }, {
    t: this.shape_177
   }, {
    t: this.shape_176
   }, {
    t: this.shape_175
   }, {
    t: this.shape_174
   }, {
    t: this.shape_173
   }, {
    t: this.shape_172
   }, {
    t: this.shape_171
   }, {
    t: this.shape_170
   }, {
    t: this.shape_169
   }, {
    t: this.shape_168
   }, {
    t: this.shape_167
   }, {
    t: this.shape_166
   }, {
    t: this.shape_165
   }, {
    t: this.shape_164
   }, {
    t: this.shape_163
   }, {
    t: this.shape_162
   }, {
    t: this.shape_161
   }, {
    t: this.shape_160
   }, {
    t: this.shape_159
   }, {
    t: this.shape_158
   }, {
    t: this.shape_157
   }, {
    t: this.shape_156
   }, {
    t: this.shape_155
   }, {
    t: this.shape_154
   }, {
    t: this.shape_153
   }, {
    t: this.shape_152
   }, {
    t: this.shape_151
   }, {
    t: this.shape_150
   }, {
    t: this.shape_149
   }, {
    t: this.shape_148
   }, {
    t: this.shape_147
   }, {
    t: this.shape_146
   }, {
    t: this.shape_145
   }, {
    t: this.shape_144
   }, {
    t: this.shape_143
   }, {
    t: this.shape_142
   }, {
    t: this.shape_141
   }, {
    t: this.shape_140
   }, {
    t: this.shape_139
   }, {
    t: this.shape_138
   }, {
    t: this.shape_137
   }, {
    t: this.shape_136
   }, {
    t: this.shape_135
   }, {
    t: this.shape_134
   }, {
    t: this.shape_133
   }, {
    t: this.shape_132
   }, {
    t: this.shape_131
   }, {
    t: this.shape_130
   }, {
    t: this.shape_129
   }, {
    t: this.shape_128
   }, {
    t: this.shape_127
   }, {
    t: this.shape_126
   }, {
    t: this.shape_125
   }, {
    t: this.shape_124
   }, {
    t: this.shape_123
   }, {
    t: this.shape_122
   }, {
    t: this.shape_121
   }, {
    t: this.shape_120
   }, {
    t: this.shape_119
   }, {
    t: this.shape_118
   }, {
    t: this.shape_117
   }, {
    t: this.shape_116
   }, {
    t: this.shape_115
   }, {
    t: this.shape_114
   }, {
    t: this.shape_113
   }, {
    t: this.shape_112
   }, {
    t: this.shape_111
   }, {
    t: this.shape_110
   }, {
    t: this.shape_109
   }, {
    t: this.shape_108
   }, {
    t: this.shape_107
   }, {
    t: this.shape_106
   }, {
    t: this.shape_105
   }, {
    t: this.shape_104
   }, {
    t: this.shape_103
   }, {
    t: this.shape_102
   }, {
    t: this.shape_101
   }, {
    t: this.shape_100
   }, {
    t: this.shape_99
   }, {
    t: this.shape_98
   }, {
    t: this.shape_97
   }, {
    t: this.shape_96
   }, {
    t: this.shape_95
   }, {
    t: this.shape_94
   }, {
    t: this.shape_93
   }, {
    t: this.shape_92
   }, {
    t: this.shape_91
   }, {
    t: this.shape_90
   }, {
    t: this.shape_89
   }, {
    t: this.shape_88
   }, {
    t: this.shape_87
   }, {
    t: this.shape_86
   }, {
    t: this.shape_85
   }, {
    t: this.shape_84
   }, {
    t: this.shape_83
   }, {
    t: this.shape_82
   }, {
    t: this.shape_81
   }, {
    t: this.shape_80
   }, {
    t: this.shape_79
   }, {
    t: this.shape_78
   }, {
    t: this.shape_77
   }, {
    t: this.shape_76
   }, {
    t: this.shape_75
   }, {
    t: this.shape_74
   }, {
    t: this.shape_73
   }, {
    t: this.shape_72
   }, {
    t: this.shape_71
   }, {
    t: this.shape_70
   }, {
    t: this.shape_69
   }, {
    t: this.shape_68
   }, {
    t: this.shape_67
   }, {
    t: this.shape_66
   }, {
    t: this.shape_65
   }, {
    t: this.shape_64
   }, {
    t: this.shape_63
   }, {
    t: this.shape_62
   }, {
    t: this.shape_61
   }, {
    t: this.shape_60
   }, {
    t: this.shape_59
   }, {
    t: this.shape_58
   }, {
    t: this.shape_57
   }, {
    t: this.shape_56
   }, {
    t: this.shape_55
   }, {
    t: this.shape_54
   }, {
    t: this.shape_53
   }, {
    t: this.shape_52
   }, {
    t: this.shape_51
   }, {
    t: this.shape_50
   }, {
    t: this.shape_49
   }, {
    t: this.shape_48
   }, {
    t: this.shape_47
   }, {
    t: this.shape_46
   }, {
    t: this.shape_45
   }, {
    t: this.shape_44
   }, {
    t: this.shape_43
   }, {
    t: this.shape_42
   }, {
    t: this.shape_41
   }, {
    t: this.shape_40
   }, {
    t: this.shape_39
   }, {
    t: this.shape_38
   }, {
    t: this.shape_37
   }, {
    t: this.shape_36
   }, {
    t: this.shape_35
   }, {
    t: this.shape_34
   }, {
    t: this.shape_33
   }, {
    t: this.shape_32
   }, {
    t: this.shape_31
   }, {
    t: this.shape_30
   }, {
    t: this.shape_29
   }, {
    t: this.shape_28
   }, {
    t: this.shape_27
   }, {
    t: this.shape_26
   }, {
    t: this.shape_25
   }, {
    t: this.shape_24
   }, {
    t: this.shape_23
   }, {
    t: this.shape_22
   }, {
    t: this.shape_21
   }, {
    t: this.shape_20
   }, {
    t: this.shape_19
   }, {
    t: this.shape_18
   }, {
    t: this.shape_17
   }, {
    t: this.shape_16
   }, {
    t: this.shape_15
   }, {
    t: this.shape_14
   }, {
    t: this.shape_13
   }, {
    t: this.shape_12
   }, {
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
 }).prototype = getMCSymbolPrototype(lib.l4, new cjs.Rectangle(-3.1, 19.6, 300.1, 76.9), null);
 (lib.l3 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#0C593C").s().p("AgWArQAAgIABgFQACgGAEgGQAFgFAJgIQAGgFAEgFQAEgGAAgHQAAgQgNAAQgHAAgDAGQgCAFAAAKIgJAAIAAgEQAAgHACgGQADgGAFgDQAFgDAGAAQAHAAAFADQAGADACAFQADAGAAAHQAAAGgCAFQgCAFgEADIgIAIIgMAMIgFAGIgCAIIAjAAIAAAIg");
  this.shape.setTransform(230.925, 45.925);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#0C593C").s().p("AgEAGIAAgLIAJAAIAAALg");
  this.shape_1.setTransform(225.125, 49.675);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#0C593C").s().p("AALAgIAAg3IgVAAIAAA3IgJAAIAAg/IAnAAIAAA/g");
  this.shape_2.setTransform(221.55, 47.05);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#0C593C").s().p("AgUAsIAAhVIAIAAIAAAHIABAAQACgEADgCQAEgDACAAQAWAAAAAhIgCANIgDALQgCAFgEACQgEADgGAAQgEAAgDgCQgDgCgCgEIAAAcgAgJgcQgCAIAAALIAAAMQABAGACAEQADADAFAAQAHAAACgGQADgHAAgNQAAgZgMAAQgHAAgCAHg");
  this.shape_3.setTransform(216.6, 48.025);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#0C593C").s().p("AgLAfQgGgDgCgIQgDgHAAgNQAAgPAFgJQAGgJALAAQAXAAAAAhQAAANgDAHQgDAIgFADQgFADgHAAQgGAAgFgDgAgHgWQgDACgBAGIgCAPIACAOQABAFACADQADADAFAAQAFAAADgDQADgDABgFIABgOIgBgPQgBgGgDgCQgDgDgFAAQgEAAgDADg");
  this.shape_4.setTransform(211.45, 47.025);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#0C593C").s().p("AALAgIgPggIgHAJIAAAXIgJAAIAAg/IAJAAIAAAeIAVgeIALAAIgUAYIAUAng");
  this.shape_5.setTransform(207.075, 47.05);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#0C593C").s().p("AgEAJQAFgCAAgJIgFAAIAAgLIAJAAIAAANQAAAEgCAFQgDAEgEABg");
  this.shape_6.setTransform(201.175, 50.525);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#0C593C").s().p("AgOAqQABgNAEgOQAEgNAGgLQAGgNAJgLIgnAAIAAgIIAvAAIAAAIQgGAIgFAJQgFAJgEAJIgFAUIgDAUg");
  this.shape_7.setTransform(197.575, 46.025);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#0C593C").s().p("AAEArIAAg+IgRAAIAAgHIALgBQADgCACgDQADgEAAgGIAIAAIAABVg");
  this.shape_8.setTransform(191.9, 45.925);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#0C593C").s().p("AgEAGIAAgLIAJAAIAAALg");
  this.shape_9.setTransform(188.875, 49.675);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.f("#0C593C").s().p("AATApIAAgSIglAAIAAASIgIAAIAAgZIAFAAIAFgMIACgJIABgOIAAgVIAiAAIAAA4IAGAAIAAAZgAgEgOQAAAKgCAFQgBAGgEAJIAXAAIAAgwIgQAAg");
  this.shape_10.setTransform(185.175, 47.925);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.f("#0C593C").s().p("AgEAJQAFgCAAgJIgFAAIAAgLIAJAAIAAANQAAAEgCAFQgDAEgEABg");
  this.shape_11.setTransform(179.275, 50.525);
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.f("#0C593C").s().p("AALAgIAAgbIgJAAIgMAbIgKAAIANgcQgFgCgDgEQgDgEAAgHQAAgFACgEQACgEAEgDQAFgCAEAAIAWAAIAAA/gAgGgVQgCADgBAGQABALAJgBIAKAAIAAgVIgJAAQgGAAgCACg");
  this.shape_12.setTransform(175.65, 47.05);
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.f("#0C593C").s().p("AgVAQQAAgFABgEQACgEADgCIAKgEIAKgEQADgBAAgHQAAgFgDgDQgCgCgEAAQgFAAgCADQgDADAAAFIgIAAQAAgTATAAQAFAAAEADQAEACACAEQACADAAAFIAAAlQAAAFADAAIACAAIAAAGIgEABQgEAAgCgCQgCgBgBgGIgBAAQgBAEgEADQgDADgFAAQgQAAAAgSgAABABIgHADIgEAFQgCADAAAEQAAAKAJAAQAFAAADgEIACgCIAAgEIABgGIAAgMIgHADg");
  this.shape_13.setTransform(171.525, 47.025);
  this.shape_14 = new cjs.Shape();
  this.shape_14.graphics.f("#0C593C").s().p("AALAgIgPggIgHAJIAAAXIgJAAIAAg/IAJAAIAAAeIAVgeIALAAIgUAYIAUAng");
  this.shape_14.setTransform(167.475, 47.05);
  this.shape_15 = new cjs.Shape();
  this.shape_15.graphics.f("#0C593C").s().p("AgMAdQgEgEgCgHQgCgHAAgKQAAgiAVAAQAKAAAFAHQAFAGAAAJIgJAAQAAgOgLAAQgGAAgDAHQgCAIAAALQAAALACAHQACAHAHAAQAHAAACgEQACgEAAgIIAJAAQAAAKgFAHQgEAHgKAAQgJAAgFgFg");
  this.shape_15.setTransform(162.725, 47.025);
  this.shape_16 = new cjs.Shape();
  this.shape_16.graphics.f("#0C593C").s().p("AgEAgIAAg3IgQAAIAAgIIApAAIAAAIIgRAAIAAA3g");
  this.shape_16.setTransform(158.675, 47.05);
  this.shape_17 = new cjs.Shape();
  this.shape_17.graphics.f("#0C593C").s().p("AgVAQQAAgFABgEQACgEADgCIAKgEIAKgEQADgBAAgHQAAgFgDgDQgCgCgEAAQgFAAgCADQgDADAAAFIgIAAQAAgTATAAQAFAAAEADQAEACACAEQACADAAAFIAAAlQAAAFADAAIACAAIAAAGIgEABQgEAAgCgCQgCgBgBgGIgBAAQgBAEgEADQgDADgFAAQgQAAAAgSgAABABIgHADIgEAFQgCADAAAEQAAAKAJAAQAFAAADgEIACgCIAAgEIABgGIAAgMIgHADg");
  this.shape_17.setTransform(154.625, 47.025);
  this.shape_18 = new cjs.Shape();
  this.shape_18.graphics.f("#0C593C").s().p("AgXAfIAAgHIAEABQAAAAABAAQABAAAAgBQABAAAAAAQAAgBABAAIACgHIAAgQIAAgfIAlAAIAAA/IgJAAIAAg4IgTAAIAAAZQAAAPgDAIQgDAIgIAAIgFgBg");
  this.shape_18.setTransform(149.575, 47.075);
  this.shape_19 = new cjs.Shape();
  this.shape_19.graphics.f("#0C593C").s().p("AAVAgIAAg/IAJAAIAAA/gAgdAgIAAg/IAKAAIAAAbIAMAAQAGAAADACQAEACACAEQACAFAAAFQAAAFgCAFQgCADgEADQgDACgGAAgAgTAZIAJAAQAGAAADgDQACgDAAgFQAAgLgKAAIgKAAg");
  this.shape_19.setTransform(143.925, 47.05);
  this.shape_20 = new cjs.Shape();
  this.shape_20.graphics.f("#0C593C").s().p("AgUAsIAAhVIAIAAIAAAHIABAAQABgEAEgCQAEgDACAAQAWAAgBAhIgBANIgCALQgDAFgEACQgEADgGAAQgEAAgDgCQgDgCgCgEIAAAcgAgJgcQgCAIAAALIAAAMQABAGADAEQADADAEAAQAGAAAEgGQACgHAAgNQAAgZgMAAQgHAAgCAHg");
  this.shape_20.setTransform(138.1, 48.025);
  this.shape_21 = new cjs.Shape();
  this.shape_21.graphics.f("#0C593C").s().p("AAQArIgWgqIgKAMIAAAeIgKAAIAAhVIAKAAIAAArIAegrIAMAAIgbAkIAcAxg");
  this.shape_21.setTransform(133, 45.925);
  this.shape_22 = new cjs.Shape();
  this.shape_22.graphics.f("#0C593C").s().p("AgEAGIAAgLIAJAAIAAALg");
  this.shape_22.setTransform(126.425, 49.675);
  this.shape_23 = new cjs.Shape();
  this.shape_23.graphics.f("#0C593C").s().p("AgXAfIAAgHIAEABQAAAAABAAQAAAAABgBQAAAAABAAQAAgBABAAIACgHIAAgQIAAgfIAlAAIAAA/IgJAAIAAg4IgTAAIAAAZQAAAPgDAIQgDAIgIAAIgFgBg");
  this.shape_23.setTransform(122.525, 47.075);
  this.shape_24 = new cjs.Shape();
  this.shape_24.graphics.f("#0C593C").s().p("AgVAqIAAgIIAHABQAEAAADgDQACgEACgGIgUhAIAJAAIAOAyIABAAIAOgyIAJAAIgUBAIgEALQgBAEgEADQgDADgGAAIgHgBg");
  this.shape_24.setTransform(118.025, 48.15);
  this.shape_25 = new cjs.Shape();
  this.shape_25.graphics.f("#0C593C").s().p("AgEAJQAFgCAAgJIgFAAIAAgLIAJAAIAAANQAAAEgCAFQgDAEgEABg");
  this.shape_25.setTransform(112.575, 50.525);
  this.shape_26 = new cjs.Shape();
  this.shape_26.graphics.f("#0C593C").s().p("AgVAQQAAgFABgEQACgEADgCIAKgEIAKgEQADgBAAgHQAAgFgDgDQgCgCgEAAQgFAAgCADQgDADAAAFIgIAAQAAgTATAAQAFAAAEADQAEACACAEQACADAAAFIAAAlQAAAFADAAIACAAIAAAGIgEABQgEAAgCgCQgCgBgBgGIgBAAQgBAEgEADQgDADgFAAQgQAAAAgSgAABABIgHADIgEAFQgCADAAAEQAAAKAJAAQAFAAADgEIACgCIAAgEIABgGIAAgMIgHADg");
  this.shape_26.setTransform(109.325, 47.025);
  this.shape_27 = new cjs.Shape();
  this.shape_27.graphics.f("#0C593C").s().p("AgTAgIAAg/IAUAAQAHAAAGAEQAEAEAAAHQAAAGgCAEQgDAEgFABQAFABAEAEQADAEAAAHQAAAFgDAEQgCAEgDACQgEACgEAAgAgKAZIAKAAQAGgBACgCQACgDAAgGQAAgFgCgDQgDgCgFAAIgKAAgAgKgEIAKAAQAEAAADgDQACgCAAgFQAAgJgJAAIgKAAg");
  this.shape_27.setTransform(105, 47.05);
  this.shape_28 = new cjs.Shape();
  this.shape_28.graphics.f("#0C593C").s().p("AALAgIgPggIgHAJIAAAXIgJAAIAAg/IAJAAIAAAeIAVgeIALAAIgUAYIAUAng");
  this.shape_28.setTransform(100.725, 47.05);
  this.shape_29 = new cjs.Shape();
  this.shape_29.graphics.f("#0C593C").s().p("AgMAdQgEgEgCgHQgCgHAAgKQAAgiAVAAQAKAAAFAHQAFAGAAAJIgJAAQAAgOgLAAQgGAAgDAHQgCAIAAALQAAALACAHQACAHAHAAQAHAAACgEQACgEAAgIIAJAAQAAAKgFAHQgEAHgKAAQgJAAgFgFg");
  this.shape_29.setTransform(95.975, 47.025);
  this.shape_30 = new cjs.Shape();
  this.shape_30.graphics.f("#0C593C").s().p("AgMAfQgEgDgEgIQgCgHAAgNQAAgPAFgJQAGgJALAAQAXAAAAAhQAAANgDAHQgDAIgEADQgGADgHAAQgHAAgFgDgAgHgWQgDACgCAGIAAAPIAAAOQACAFACADQADADAFAAQAFAAADgDQADgDABgFIABgOIgBgPQgCgGgDgCQgDgDgEAAQgEAAgDADg");
  this.shape_30.setTransform(91.25, 47.025);
  this.shape_31 = new cjs.Shape();
  this.shape_31.graphics.f("#0C593C").s().p("AAbArIAAhGIAAgGIAAgFIgCAGIgBAGIgSBFIgLAAIgShGIgCgLIgBAAIAAAGIABAFIAABGIgKAAIAAhVIARAAIARBCIABANIACgNIARhCIARAAIAABVg");
  this.shape_31.setTransform(84.575, 45.925);
  this.shape_32 = new cjs.Shape();
  this.shape_32.graphics.f("#0C593C").s().p("AgEAGIAAgLIAJAAIAAALg");
  this.shape_32.setTransform(77.125, 49.675);
  this.shape_33 = new cjs.Shape();
  this.shape_33.graphics.f("#0C593C").s().p("AgQAgIAAg/IAhAAIAAAIIgYAAIAAA3g");
  this.shape_33.setTransform(74.675, 47.05);
  this.shape_34 = new cjs.Shape();
  this.shape_34.graphics.f("#0C593C").s().p("AgEAJQAFgCAAgJIgFAAIAAgLIAJAAIAAANQAAAEgCAFQgDAEgEABg");
  this.shape_34.setTransform(69.175, 50.525);
  this.shape_35 = new cjs.Shape();
  this.shape_35.graphics.f("#0C593C").s().p("AAHArIAAgVIgfAAIAAgJIAgg3IAJAAIAAA3IAHAAIAAAJIgHAAIAAAVgAgPANIAWAAIAAgog");
  this.shape_35.setTransform(65.45, 45.925);
  this.shape_36 = new cjs.Shape();
  this.shape_36.graphics.f("#0C593C").s().p("AAFArIAAg+IgSAAIAAgHIALgBQADgCACgDQADgEABgGIAHAAIAABVg");
  this.shape_36.setTransform(59.9, 45.925);
  this.shape_37 = new cjs.Shape();
  this.shape_37.graphics.f("#0C593C").s().p("AgLAoQgFgDgDgGQgCgGgBgGIgBgPQAAgMACgKQABgKAFgIQAGgHAKAAQAGAAAEACQAFADADAFQADAFAAAGIgKAAQgBgHgDgDQgDgDgFAAQgDAAgEAEQgDAEgBAFIgBAKIgBALQACgFAEgDQAFgDADAAQALAAAGAIQAGAHAAALQAAAJgDAHQgDAHgFADQgGAEgGAAQgIAAgEgEgAgMANQgBAMAEAFQAEAFAFAAQAIAAADgGQADgGAAgJQAAgRgOAAQgMAAAAAQg");
  this.shape_37.setTransform(55.5, 46.025);
  this.shape_38 = new cjs.Shape();
  this.shape_38.graphics.f("#0C593C").s().p("AAEArIAAg+IgRAAIAAgHIALgBQADgCACgDQADgEABgGIAHAAIAABVg");
  this.shape_38.setTransform(49.8, 45.925);
  this.shape_39 = new cjs.Shape();
  this.shape_39.graphics.f("#0C593C").s().p("AgWArQAAgIABgFQACgGAEgGQAFgFAJgIQAGgFAEgFQAEgGAAgHQAAgQgNAAQgHAAgDAGQgCAFAAAKIgJAAIAAgEQAAgHACgGQADgGAFgDQAFgDAGAAQAHAAAFADQAGADACAFQADAGAAAHQAAAGgCAFQgCAFgEADIgIAIIgMAMIgFAGIgCAIIAjAAIAAAIg");
  this.shape_39.setTransform(45.325, 45.925);
  this.shape_40 = new cjs.Shape();
  this.shape_40.graphics.f("#0C593C").s().p("AAEArIAAg+IgRAAIAAgHIALgBQADgCACgDQADgEAAgGIAIAAIAABVg");
  this.shape_40.setTransform(39.7, 45.925);
  this.shape_41 = new cjs.Shape();
  this.shape_41.graphics.f("#0C593C").s().p("AgEAJQAFgCAAgJIgFAAIAAgLIAJAAIAAANQAAAEgCAFQgDAEgEABg");
  this.shape_41.setTransform(34.475, 50.525);
  this.shape_42 = new cjs.Shape();
  this.shape_42.graphics.f("#0C593C").s().p("AAMAgIAAgbIgKAAIgMAbIgKAAIANgcQgFgCgDgEQgDgEAAgHQAAgFACgEQADgEADgDQAEgCAFAAIAWAAIAAA/gAgGgVQgCADgBAGQABALAJgBIALAAIAAgVIgKAAQgFAAgDACg");
  this.shape_42.setTransform(30.85, 47.05);
  this.shape_43 = new cjs.Shape();
  this.shape_43.graphics.f("#0C593C").s().p("AAMAgIAAgwIABgHIgCAHIgUAwIgLAAIAAg/IAJAAIAAAvIgBAJIACgJIAUgvIALAAIAAA/g");
  this.shape_43.setTransform(26.325, 47.05);
  this.shape_44 = new cjs.Shape();
  this.shape_44.graphics.f("#0C593C").s().p("AgMAdQgEgEgCgHQgCgHAAgKQAAgiAVAAQAKAAAFAHQAFAGAAAJIgJAAQAAgOgLAAQgGAAgDAHQgCAIAAALQAAALACAHQACAHAHAAQAHAAACgEQACgEAAgIIAJAAQAAAKgFAHQgEAHgKAAQgJAAgFgFg");
  this.shape_44.setTransform(21.575, 47.025);
  this.shape_45 = new cjs.Shape();
  this.shape_45.graphics.f("#0C593C").s().p("AgMAdQgEgEgCgHQgCgHAAgKQAAgiAVAAQAKAAAFAHQAFAGAAAJIgJAAQAAgOgLAAQgGAAgDAHQgCAIAAALQAAALACAHQACAHAHAAQAHAAACgEQACgEAAgIIAJAAQAAAKgFAHQgEAHgKAAQgJAAgFgFg");
  this.shape_45.setTransform(17.175, 47.025);
  this.shape_46 = new cjs.Shape();
  this.shape_46.graphics.f("#0C593C").s().p("AgMAfQgEgDgDgIQgDgHAAgNQAAgPAGgJQAFgJALAAQAXAAAAAhQAAANgDAHQgDAIgFADQgFADgHAAQgGAAgGgDgAgHgWQgDACgCAGIgBAPIABAOQACAFADADQADADAEAAQAFAAADgDQADgDABgFIABgOIgBgPQgBgGgDgCQgEgDgEAAQgEAAgDADg");
  this.shape_46.setTransform(12.45, 47.025);
  this.shape_47 = new cjs.Shape();
  this.shape_47.graphics.f("#0C593C").s().p("AgYArIAAhVIAYAAQALAAAHAGQAHAGAAAMQAAAIgCAFQgCAFgEABQgEADgFABQgEACgGAAIgNAAIAAAkgAgPgBIAKAAQAGAAAFgBQAEgBADgEQACgEAAgHQAAgJgFgDQgFgEgHAAIgNAAg");
  this.shape_47.setTransform(7.35, 45.925);
  this.shape_48 = new cjs.Shape();
  this.shape_48.graphics.f("#0C593C").s().p("AAbBPIAAhjIABgPIAAgTIAAAAIgXCFIgJAAIgXiFIgBAAIABATIAAAQIAABiIgKAAIAAidIAQAAIAVCAIAXiAIAPAAIAACdg");
  this.shape_48.setTransform(230.1, 81.4);
  this.shape_49 = new cjs.Shape();
  this.shape_49.graphics.f("#0C593C").s().p("AgRBGQgHgLgEgSQgDgSAAgXQAAgnAIgUQAIgVAPAAQALAAAHALQAHAKAEATQADASAAAWQAAAXgDASQgEATgHAKQgHALgLAAQgKAAgHgLgAgOgvQgGARAAAeQAAAfAGAQQAFARAJAAQAKAAAFgQQAFgRAAgfQAAgegFgRQgFgQgKAAQgJAAgFAQg");
  this.shape_49.setTransform(221.375, 81.375);
  this.shape_50 = new cjs.Shape();
  this.shape_50.graphics.f("#0C593C").s().p("AgFBPIAAiMIgUAAIAAgRIAzAAIAAARIgVAAIAACMg");
  this.shape_50.setTransform(214.825, 81.4);
  this.shape_51 = new cjs.Shape();
  this.shape_51.graphics.f("#0C593C").s().p("AgRA7QgIgVgBgmQABgWAEgSQADgTAHgKQAIgLAKAAQALAAAIAIIgDARIgIgGQgDgCgFAAQgHAAgEAJQgFAIgDAPQgCAOAAARQAAAeAGARQAGARAKAAQAEAAAEgCQAFgBADgDIAAARQgHAGgLAAQgOAAgJgWg");
  this.shape_51.setTransform(209.15, 81.375);
  this.shape_52 = new cjs.Shape();
  this.shape_52.graphics.f("#0C593C").s().p("AATBPIAAhdIAAgSIABgRIgBAAIgiCAIgOAAIAAidIALAAIAABbIAAARIgBASIABAAIAih+IAOAAIAACdg");
  this.shape_52.setTransform(201.925, 81.4);
  this.shape_53 = new cjs.Shape();
  this.shape_53.graphics.f("#0C593C").s().p("AgdBNIAAgQQACACADAAQAEAAACgJQACgIABgRIACgbIACglIADgsIAmAAIAACdIgLAAIAAiMIgTAAIAAAbIgCAbIgBAZIgCATIgDAZQgCAJgEAFQgDAEgGABQgEgBgCgCg");
  this.shape_53.setTransform(193.925, 81.5);
  this.shape_54 = new cjs.Shape();
  this.shape_54.graphics.f("#0C593C").s().p("AAUBPIgHgxIgZAAIgHAxIgMAAIAaidIALAAIAaCdgAAAgwIgCALIgHAyIATAAIgHgyIgCgMIgBgLIAAAMg");
  this.shape_54.setTransform(187.725, 81.375);
  this.shape_55 = new cjs.Shape();
  this.shape_55.graphics.f("#0C593C").s().p("AATBPIAAhdIAAgSIABgRIgBAAIgiCAIgOAAIAAidIALAAIAABbIAAARIgBASIABAAIAih+IAOAAIAACdg");
  this.shape_55.setTransform(180.625, 81.4);
  this.shape_56 = new cjs.Shape();
  this.shape_56.graphics.f("#0C593C").s().p("AAVBkIAAgrIg0AAIAAicIAMAAIAACLIAeAAIAAiLIALAAIAACLIAJAAIAAA8g");
  this.shape_56.setTransform(173.2, 83.525);
  this.shape_57 = new cjs.Shape();
  this.shape_57.graphics.f("#0C593C").s().p("AgTBPIAAidIAnAAIAAARIgcAAIAAAyIAaAAIAAAPIgaAAIAAA6IAcAAIAAARg");
  this.shape_57.setTransform(166.5, 81.4);
  this.shape_58 = new cjs.Shape();
  this.shape_58.graphics.f("#0C593C").s().p("AAQBPIAAiMIgfAAIAACMIgLAAIAAidIA1AAIAACdg");
  this.shape_58.setTransform(159.7, 81.4);
  this.shape_59 = new cjs.Shape();
  this.shape_59.graphics.f("#0C593C").s().p("AgRA7QgJgVAAgmQAAgWAFgSQADgTAIgKQAHgLALAAQAKAAAIAIIgDARIgHgGQgFgCgDAAQgIAAgEAJQgFAIgCAPQgDAOAAARQAAAeAGARQAGARAKAAQAFAAAEgCQADgBAEgDIAAARQgHAGgKAAQgPAAgJgWg");
  this.shape_59.setTransform(153.05, 81.375);
  this.shape_60 = new cjs.Shape();
  this.shape_60.graphics.f("#0C593C").s().p("AgRBGQgHgLgEgSQgDgSAAgXQAAgnAIgUQAIgVAPAAQALAAAHALQAHAKAEATQADASAAAWQAAAXgDASQgEATgHAKQgHALgLAAQgKAAgHgLgAgOgvQgGARAAAeQAAAfAGAQQAFARAJAAQAKAAAFgQQAFgRAAgfQAAgegFgRQgFgQgKAAQgJAAgFAQg");
  this.shape_60.setTransform(143.325, 81.375);
  this.shape_61 = new cjs.Shape();
  this.shape_61.graphics.f("#0C593C").s().p("AgRA7QgIgVgBgmQAAgWAFgSQADgTAIgKQAHgLALAAQAKAAAIAIIgDARIgHgGQgEgCgEAAQgIAAgEAJQgFAIgCAPQgDAOAAARQAAAeAGARQAGARAKAAQAFAAADgCQAEgBAEgDIAAARQgHAGgKAAQgPAAgJgWg");
  this.shape_61.setTransform(136.5, 81.375);
  this.shape_62 = new cjs.Shape();
  this.shape_62.graphics.f("#0C593C").s().p("AgYBPIAAidIAMAAIAABCIAJAAQANAAAIAMQAHAKAAAXQAAAVgIAMQgHANgMAAgAgMA+IAJAAQAQAAAAgdQAAgQgFgHQgEgGgHgBIgJAAg");
  this.shape_62.setTransform(125.15, 81.4);
  this.shape_63 = new cjs.Shape();
  this.shape_63.graphics.f("#0C593C").s().p("AgQA7QgJgVAAgmQAAgWADgSQAEgTAHgKQAIgLAKAAQALAAAIAIIgEARIgHgGQgDgCgFAAQgHAAgEAJQgFAIgDAPQgCAOAAARQAAAeAGARQAGARAKAAQAEAAAEgCQAEgBAEgDIAAARQgIAGgKAAQgOAAgIgWg");
  this.shape_63.setTransform(118.8, 81.375);
  this.shape_64 = new cjs.Shape();
  this.shape_64.graphics.f("#0C593C").s().p("AgTBPIAAidIAnAAIAAARIgcAAIAAAyIAaAAIAAAPIgaAAIAAA6IAcAAIAAARg");
  this.shape_64.setTransform(112.9, 81.4);
  this.shape_65 = new cjs.Shape();
  this.shape_65.graphics.f("#0C593C").s().p("AgFBPIAAiMIgUAAIAAgRIAzAAIAAARIgVAAIAACMg");
  this.shape_65.setTransform(107.175, 81.4);
  this.shape_66 = new cjs.Shape();
  this.shape_66.graphics.f("#0C593C").s().p("AATBnIAAhdIAAgRIABgSIgBAAIgiCAIgOAAIAAicIALAAIAABaIAAARIgBATIABAAIAih+IAOAAIAACcgAgNhNQgFgIAAgRIAJAAQABAMACAFQADAFAEAAQAFAAACgGQADgFAAgLIAKAAQgBARgFAIQgFAIgJAAQgJAAgFgIg");
  this.shape_66.setTransform(100.375, 78.975);
  this.shape_67 = new cjs.Shape();
  this.shape_67.graphics.f("#0C593C").s().p("AgVBPIgEgCIAAgRQAEADAEAAQADgBACgCQACgCACgHIAEgRIgYhxIALAAIAQBKIABAHIABAKIAAAAIABgJIACgHIANhLIAMAAIgVBwQgDARgEAKQgCALgFAEQgEAEgGABIgFgBg");
  this.shape_67.setTransform(93.55, 81.5);
  this.shape_68 = new cjs.Shape();
  this.shape_68.graphics.f("#0C593C").s().p("AgXBPIAAidIAUAAQANAAAHAMQAGAMABAWQgBAYgGAMQgHAOgPAAIgGAAIAAA9gAgLAAIAFAAQAJAAAFgGQAEgIAAgRQAAgQgEgHQgEgHgIAAIgHAAg");
  this.shape_68.setTransform(87.8, 81.4);
  this.shape_69 = new cjs.Shape();
  this.shape_69.graphics.f("#0C593C").s().p("AATBPIAAhdIAAgSIABgRIgBAAIgiCAIgOAAIAAidIALAAIAABbIAAARIgBASIABAAIAih+IAOAAIAACdg");
  this.shape_69.setTransform(80.525, 81.4);
  this.shape_70 = new cjs.Shape();
  this.shape_70.graphics.f("#0C593C").s().p("AgFBPIAAiMIgUAAIAAgRIAzAAIAAARIgVAAIAACMg");
  this.shape_70.setTransform(73.875, 81.4);
  this.shape_71 = new cjs.Shape();
  this.shape_71.graphics.f("#0C593C").s().p("AgXBPIAAidIALAAIAABCIAJAAQAOAAAGAMQAIAKAAAXQgBAVgHAMQgHANgMAAgAgMA+IAJAAQAQAAAAgdQAAgQgFgHQgEgGgHgBIgJAAg");
  this.shape_71.setTransform(68.2, 81.4);
  this.shape_72 = new cjs.Shape();
  this.shape_72.graphics.f("#0C593C").s().p("AgdBNIAAgQQACACADAAQAEAAACgJQACgIABgRIACgbIACglIADgsIAmAAIAACdIgLAAIAAiMIgTAAIAAAbIgCAbIgBAZIgCATIgDAZQgCAJgEAFQgDAEgGABQgEgBgCgCg");
  this.shape_72.setTransform(60.725, 81.5);
  this.shape_73 = new cjs.Shape();
  this.shape_73.graphics.f("#0C593C").s().p("AgVBPIgEgCIAAgRQAEADAEAAQADgBACgCQACgCACgHIAEgRIgYhxIALAAIAQBKIABAHIABAKIAAAAIABgJIACgHIANhLIAMAAIgVBwQgDARgEAKQgCALgFAEQgEAEgGABIgFgBg");
  this.shape_73.setTransform(54.85, 81.5);
  this.shape_74 = new cjs.Shape();
  this.shape_74.graphics.f("#0C593C").s().p("AgRA7QgIgVgBgmQABgWAEgSQADgTAHgKQAIgLAKAAQALAAAIAIIgDARIgIgGQgDgCgFAAQgHAAgEAJQgFAIgCAPQgDAOAAARQAAAeAGARQAGARAKAAQAEAAAEgCQAFgBADgDIAAARQgHAGgLAAQgOAAgJgWg");
  this.shape_74.setTransform(48.95, 81.375);
  this.shape_75 = new cjs.Shape();
  this.shape_75.graphics.f("#0C593C").s().p("AAQBPIAAhKIgfAAIAABKIgLAAIAAidIALAAIAABDIAfAAIAAhDIALAAIAACdg");
  this.shape_75.setTransform(41.925, 81.4);
  this.shape_76 = new cjs.Shape();
  this.shape_76.graphics.f("#0C593C").s().p("AgRBGQgHgLgEgSQgDgSAAgXQAAgnAIgUQAIgVAPAAQALAAAHALQAHAKAEATQADASAAAWQAAAXgDASQgEATgHAKQgHALgLAAQgKAAgHgLgAgOgvQgGARAAAeQAAAfAGAQQAFARAJAAQAKAAAFgQQAFgRAAgfQAAgegFgRQgFgQgKAAQgJAAgFAQg");
  this.shape_76.setTransform(34.325, 81.375);
  this.shape_77 = new cjs.Shape();
  this.shape_77.graphics.f("#0C593C").s().p("AANBPIgbhQIAABQIgLAAIAAidIALAAIAABMIAbhMIAMAAIgcBMIAdBRg");
  this.shape_77.setTransform(27.875, 81.4);
  this.shape_78 = new cjs.Shape();
  this.shape_78.graphics.f("#0C593C").s().p("AgRBGQgHgLgEgSQgDgSAAgXQAAgnAIgUQAIgVAPAAQALAAAHALQAHAKAEATQADASAAAWQAAAXgDASQgEATgHAKQgHALgLAAQgKAAgHgLgAgOgvQgGARAAAeQAAAfAGAQQAFARAJAAQAKAAAFgQQAFgRAAgfQAAgegFgRQgFgQgKAAQgJAAgFAQg");
  this.shape_78.setTransform(20.375, 81.375);
  this.shape_79 = new cjs.Shape();
  this.shape_79.graphics.f("#0C593C").s().p("AgXBPIAAidIATAAQAOAAAHAMQAGAMAAAWQAAAYgGAMQgIAOgOAAIgHAAIAAA9gAgMAAIAHAAQAIAAAFgGQAEgIAAgRQAAgQgEgHQgFgHgHAAIgIAAg");
  this.shape_79.setTransform(13.7, 81.4);
  this.shape_80 = new cjs.Shape();
  this.shape_80.graphics.f("#0C593C").s().p("AAPBPIAAiMIgeAAIAACMIgLAAIAAidIA1AAIAACdg");
  this.shape_80.setTransform(6.55, 81.4);
  this.shape_81 = new cjs.Shape();
  this.shape_81.graphics.f("#0C593C").s().p("AgEAJQAFgCAAgJIgFAAIAAgLIAJAAIAAANQAAAEgCAFQgDAEgEABg");
  this.shape_81.setTransform(180.675, 38.475);
  this.shape_82 = new cjs.Shape();
  this.shape_82.graphics.f("#0C593C").s().p("AACAMIALgMIgLgLIAAgJIARASIAAAGIgRARgAgSAMIAMgMIgMgLIAAgJIARASIAAAGIgRARg");
  this.shape_82.setTransform(176.6, 34.625);
  this.shape_83 = new cjs.Shape();
  this.shape_83.graphics.f("#0C593C").s().p("AALAgIAAgeIgVAAIAAAeIgJAAIAAg/IAJAAIAAAbIAVAAIAAgbIAJAAIAAA/g");
  this.shape_83.setTransform(171.05, 35);
  this.shape_84 = new cjs.Shape();
  this.shape_84.graphics.f("#0C593C").s().p("AgMAfQgEgDgEgIQgCgHAAgNQAAgPAFgJQAGgJALAAQAXAAAAAhQAAANgDAHQgDAIgEADQgGADgHAAQgHAAgFgDgAgHgWQgDACgCAGIAAAPIAAAOQACAFACADQADADAFAAQAFAAADgDQADgDABgFIABgOIgBgPQgCgGgDgCQgDgDgEAAQgEAAgDADg");
  this.shape_84.setTransform(165.5, 34.975);
  this.shape_85 = new cjs.Shape();
  this.shape_85.graphics.f("#0C593C").s().p("AgMAdQgEgEgCgHQgCgHAAgKQAAgiAVAAQAKAAAFAHQAFAGAAAJIgJAAQAAgOgLAAQgGAAgDAHQgCAIAAALQAAALACAHQACAHAHAAQAHAAACgEQACgEAAgIIAJAAQAAAKgFAHQgEAHgKAAQgJAAgFgFg");
  this.shape_85.setTransform(160.275, 34.975);
  this.shape_86 = new cjs.Shape();
  this.shape_86.graphics.f("#0C593C").s().p("AALAgIAAgeIgWAAIAAAeIgJAAIAAg/IAJAAIAAAbIAWAAIAAgbIAKAAIAAA/g");
  this.shape_86.setTransform(155.05, 35);
  this.shape_87 = new cjs.Shape();
  this.shape_87.graphics.f("#0C593C").s().p("AgMAfQgEgDgEgIQgCgHAAgNQAAgPAGgJQAFgJALAAQAXAAAAAhQAAANgDAHQgDAIgEADQgGADgHAAQgGAAgGgDgAgHgWQgDACgCAGIgBAPIABAOQACAFADADQADADAEAAQAFAAADgDQADgDABgFIABgOIgBgPQgBgGgEgCQgDgDgEAAQgEAAgDADg");
  this.shape_87.setTransform(149.5, 34.975);
  this.shape_88 = new cjs.Shape();
  this.shape_88.graphics.f("#0C593C").s().p("AAbAgIgPggIgHAJIAAAXIgIAAIAAgXIgHgJIgRAgIgKAAIAUgmIgUgZIALAAIAXAeIAAgeIAIAAIAAAeIAWgeIAKAAIgTAZIAUAmg");
  this.shape_88.setTransform(142.9, 35);
  this.shape_89 = new cjs.Shape();
  this.shape_89.graphics.f("#0C593C").s().p("AAZA1IAAgUIgxAAIAAAUIgJAAIAAgcIAGAAQAEgHACgIQACgIAAgIIABgYIAAgWIAtAAIAABNIAHAAIAAAcgAgIgVIgBATIgDAOIgFANIAiAAIAAhFIgZAAg");
  this.shape_89.setTransform(135.625, 34.875);
  this.shape_90 = new cjs.Shape();
  this.shape_90.graphics.f("#0C593C").s().p("AgSApQgGgDgDgFQgDgGAAgIQAAgGACgFQACgEAEgEIAKgGQgFgFgCgFQgCgEAAgFQAAgFACgEQACgEAEgDQAEgCAFAAQAHAAAFAEQAFAFAAAIQAAAMgOAKIAQAXQACgIABgIIAJAAQgCAOgFAJIALAQIgLAAIgFgHQgIAJgMAAQgHAAgGgDgAgRAIQgDAFAAAGQAAAFACAEQACAEAEACQADACAFAAQAHAAAHgIIgSgcQgGAEgDAEgAgKghQgCADAAAEQAAAGAHAJQAFgDABgEQACgDAAgFQAAgEgCgDQgBgCgEAAQgDAAgDACg");
  this.shape_90.setTransform(128.475, 33.975);
  this.shape_91 = new cjs.Shape();
  this.shape_91.graphics.f("#0C593C").s().p("AALAgIAAgeIgWAAIAAAeIgJAAIAAg/IAJAAIAAAbIAWAAIAAgbIAKAAIAAA/g");
  this.shape_91.setTransform(121.85, 35);
  this.shape_92 = new cjs.Shape();
  this.shape_92.graphics.f("#0C593C").s().p("AgMAfQgEgDgEgIQgCgHAAgNQAAgPAGgJQAFgJALAAQAXAAAAAhQAAANgDAHQgDAIgFADQgFADgHAAQgGAAgGgDgAgHgWQgDACgCAGIgBAPIABAOQACAFADADQADADAEAAQAFAAADgDQADgDABgFIABgOIgBgPQgCgGgCgCQgDgDgFAAQgEAAgDADg");
  this.shape_92.setTransform(116.3, 34.975);
  this.shape_93 = new cjs.Shape();
  this.shape_93.graphics.f("#0C593C").s().p("AgMAdQgEgEgCgHQgCgHAAgKQAAgiAVAAQAKAAAFAHQAFAGAAAJIgJAAQAAgOgLAAQgGAAgDAHQgCAIAAALQAAALACAHQACAHAHAAQAHAAACgEQACgEAAgIIAJAAQAAAKgFAHQgEAHgKAAQgJAAgFgFg");
  this.shape_93.setTransform(111.075, 34.975);
  this.shape_94 = new cjs.Shape();
  this.shape_94.graphics.f("#0C593C").s().p("AALAgIAAgeIgWAAIAAAeIgJAAIAAg/IAJAAIAAAbIAWAAIAAgbIAKAAIAAA/g");
  this.shape_94.setTransform(105.85, 35);
  this.shape_95 = new cjs.Shape();
  this.shape_95.graphics.f("#0C593C").s().p("AgLAfQgGgDgCgIQgDgHAAgNQAAgPAFgJQAGgJALAAQAXAAAAAhQAAANgDAHQgDAIgFADQgFADgHAAQgGAAgFgDgAgHgWQgDACgBAGIgCAPIACAOQABAFACADQADADAFAAQAFAAADgDQADgDABgFIABgOIgBgPQgBgGgDgCQgDgDgFAAQgEAAgDADg");
  this.shape_95.setTransform(100.3, 34.975);
  this.shape_96 = new cjs.Shape();
  this.shape_96.graphics.f("#0C593C").s().p("AAcAgIgQggIgIAJIAAAXIgIAAIAAgXIgHgJIgPAgIgLAAIAVgmIgVgZIAMAAIAVAeIAAgeIAIAAIAAAeIAXgeIALAAIgUAZIAUAmg");
  this.shape_96.setTransform(93.7, 35);
  this.shape_97 = new cjs.Shape();
  this.shape_97.graphics.f("#0C593C").s().p("AAZA1IAAgUIgxAAIAAAUIgJAAIAAgcIAGAAQAEgHACgIQACgIAAgIIABgYIAAgWIAtAAIAABNIAHAAIAAAcgAgIgVIgBATIgDAOIgFANIAiAAIAAhFIgZAAg");
  this.shape_97.setTransform(86.425, 34.875);
  this.shape_98 = new cjs.Shape();
  this.shape_98.graphics.f("#0C593C").s().p("AABADIAAgGIASgRIAAAJIgMALIAMAMIAAAJgAgSADIAAgGIARgRIAAAJIgLALIALAMIAAAJg");
  this.shape_98.setTransform(80.15, 34.625);
  this.shape_99 = new cjs.Shape();
  this.shape_99.graphics.f("#0C593C").s().p("AgOAqQgFgEgDgGQgEgGgBgJIAAgRQgBgMACgJQADgKAFgGQAHgHALAAQARAAAGANQAFANAAASQAAAVgFAMQgGAMgRAAQgJAAgFgDgAgKgfQgEAEgCAIQgBAIgBAKIABAQIACAMQADAEADADQAEADAFgBQAFABAEgDQAEgDACgEQACgFAAgHIABgQIgBgOIgCgLQgDgEgEgDQgDgCgFgBQgGABgEAEg");
  this.shape_99.setTransform(71.25, 33.9);
  this.shape_100 = new cjs.Shape();
  this.shape_100.graphics.f("#0C593C").s().p("AgOAqQgGgEgDgGQgDgGgBgJIAAgRQAAgMABgJQADgKAFgGQAHgHALAAQARAAAGANQAFANAAASQAAAVgFAMQgGAMgRAAQgJAAgFgDgAgKgfQgFAEgBAIQgBAIgBAKIABAQIACAMQACAEAFADQADADAFgBQAGABADgDQAEgDACgEQACgFABgHIAAgQIAAgOIgDgLQgCgEgFgDQgDgCgFgBQgHABgDAEg");
  this.shape_100.setTransform(64.4, 33.9);
  this.shape_101 = new cjs.Shape();
  this.shape_101.graphics.f("#0C593C").s().p("AgOAqQgFgEgEgGQgCgGgBgJIgBgRQAAgMABgJQACgKAHgGQAGgHALAAQARAAAFANQAHANgBASQABAVgHAMQgFAMgRAAQgIAAgGgDgAgKgfQgFAEgBAIQgCAIABAKIAAAQIACAMQADAEAEADQADADAFgBQAGABAEgDQADgDACgEQACgFABgHIAAgQIAAgOIgDgLQgDgEgDgDQgEgCgFgBQgHABgDAEg");
  this.shape_101.setTransform(57.55, 33.9);
  this.shape_102 = new cjs.Shape();
  this.shape_102.graphics.f("#0C593C").s().p("AACAMIAMgMIgMgLIAAgKIASATIAAAGIgSASgAgTAMIAMgMIgMgLIAAgKIATATIAAAGIgTASg");
  this.shape_102.setTransform(180.625, 20.575);
  this.shape_103 = new cjs.Shape();
  this.shape_103.graphics.f("#0C593C").s().p("AAMAhIAAgeIgXAAIAAAeIgKAAIAAhBIAKAAIAAAcIAXAAIAAgcIAKAAIAABBg");
  this.shape_103.setTransform(175.05, 20.95);
  this.shape_104 = new cjs.Shape();
  this.shape_104.graphics.f("#0C593C").s().p("AgMAgQgFgEgDgHQgDgIAAgNQAAgQAGgJQAGgJALAAQAYAAAAAiQAAANgDAIQgCAIgGADQgGADgHAAQgGAAgGgDgAgHgYQgDADgBAGQgCAGAAAKQAAAIACAGQAAAGADADQAEADAEAAQAFAAADgDQADgDACgGIABgOQAAgKgBgGQgCgGgDgDQgDgCgFAAQgEAAgDACg");
  this.shape_104.setTransform(169.45, 20.975);
  this.shape_105 = new cjs.Shape();
  this.shape_105.graphics.f("#0C593C").s().p("AgMAeQgFgEgCgIQgCgHAAgKQAAgjAXAAQAJAAAGAGQAFAHAAAJIgJAAQAAgOgLAAQgHAAgDAHQgDAIAAAMQAAALADAIQACAHAHAAQAHAAACgEQACgFABgIIAJAAQAAALgFAHQgFAHgKAAQgJAAgFgFg");
  this.shape_105.setTransform(164.175, 20.975);
  this.shape_106 = new cjs.Shape();
  this.shape_106.graphics.f("#0C593C").s().p("AAMAhIAAgeIgXAAIAAAeIgJAAIAAhBIAJAAIAAAcIAXAAIAAgcIAJAAIAABBg");
  this.shape_106.setTransform(158.9, 20.95);
  this.shape_107 = new cjs.Shape();
  this.shape_107.graphics.f("#0C593C").s().p("AgMAgQgFgEgDgHQgDgIAAgNQAAgQAGgJQAGgJALAAQAYAAAAAiQAAANgDAIQgDAIgFADQgGADgHAAQgHAAgFgDgAgHgYQgDADgCAGQgBAGAAAKQAAAIABAGQACAGADADQADADAEAAQAGAAADgDQADgDABgGIABgOQAAgKgCgGQgBgGgDgDQgDgCgFAAQgEAAgDACg");
  this.shape_107.setTransform(153.3, 20.975);
  this.shape_108 = new cjs.Shape();
  this.shape_108.graphics.f("#0C593C").s().p("AAdAhIgRghIgHAKIAAAXIgJAAIAAgXIgHgKIgRAhIgLAAIAWgoIgVgZIALAAIAXAfIAAgfIAJAAIAAAfIAXgfIALAAIgVAZIAWAog");
  this.shape_108.setTransform(146.675, 20.95);
  this.shape_109 = new cjs.Shape();
  this.shape_109.graphics.f("#0C593C").s().p("AAaA3IAAgVIgzAAIAAAVIgJAAIAAgeIAGAAQAEgHACgIQACgIABgJIAAgYIAAgXIAvAAIAABPIAHAAIAAAegAgJgWIgBAUIgDAPQgBAHgDAFIAjAAIAAhHIgbAAg");
  this.shape_109.setTransform(139.275, 20.85);
  this.shape_110 = new cjs.Shape();
  this.shape_110.graphics.f("#0C593C").s().p("AgTArQgGgDgEgGQgDgGAAgIQAAgHACgFQADgEAEgEQADgDAHgEQgEgFgDgFQgCgEAAgGQAAgFACgEQADgEAEgDQAEgCAFAAQAHAAAGAFQAEAEAAAJQAAAMgOAKIAQAYQADgIABgJIAJAAQgBAQgGAJIALARIgMAAIgFgIQgIAKgMAAQgIAAgGgDgAgSAIQgDAFAAAHQAAAFACAEQACAEAEACQAEACAFAAQAHAAAHgJIgTgcIgJAIgAgKgiQgCACgBAEQAAAHAHAJQAFgDACgEQADgDgBgFQABgEgDgDQgBgDgEAAQgEAAgCADg");
  this.shape_110.setTransform(132.05, 19.925);
  this.shape_111 = new cjs.Shape();
  this.shape_111.graphics.f("#0C593C").s().p("AAMAhIAAgeIgXAAIAAAeIgKAAIAAhBIAKAAIAAAcIAXAAIAAgcIAJAAIAABBg");
  this.shape_111.setTransform(125.3, 20.95);
  this.shape_112 = new cjs.Shape();
  this.shape_112.graphics.f("#0C593C").s().p("AgMAgQgFgEgDgHQgDgIAAgNQAAgQAGgJQAGgJALAAQAYAAAAAiQAAANgDAIQgCAIgGADQgFADgIAAQgHAAgFgDgAgHgYQgDADgCAGQgBAGAAAKQAAAIABAGQABAGAEADQADADAEAAQAFAAADgDQAEgDABgGIABgOQAAgKgBgGQgCgGgDgDQgDgCgFAAQgEAAgDACg");
  this.shape_112.setTransform(119.7, 20.975);
  this.shape_113 = new cjs.Shape();
  this.shape_113.graphics.f("#0C593C").s().p("AgMAeQgFgEgCgIQgCgHAAgKQAAgjAXAAQAJAAAGAGQAFAHAAAJIgJAAQAAgOgLAAQgHAAgDAHQgDAIAAAMQAAALADAIQACAHAHAAQAHAAACgEQACgFABgIIAJAAQAAALgFAHQgFAHgKAAQgJAAgFgFg");
  this.shape_113.setTransform(114.425, 20.975);
  this.shape_114 = new cjs.Shape();
  this.shape_114.graphics.f("#0C593C").s().p("AAMAhIAAgeIgXAAIAAAeIgJAAIAAhBIAJAAIAAAcIAXAAIAAgcIAKAAIAABBg");
  this.shape_114.setTransform(109.15, 20.95);
  this.shape_115 = new cjs.Shape();
  this.shape_115.graphics.f("#0C593C").s().p("AgMAgQgFgEgDgHQgDgIAAgNQAAgQAGgJQAGgJALAAQAYAAAAAiQAAANgDAIQgDAIgFADQgFADgIAAQgGAAgGgDgAgHgYQgDADgBAGQgCAGAAAKQAAAIACAGQABAGACADQADADAFAAQAGAAADgDQACgDACgGIABgOQAAgKgCgGQgBgGgDgDQgDgCgFAAQgEAAgDACg");
  this.shape_115.setTransform(103.55, 20.975);
  this.shape_116 = new cjs.Shape();
  this.shape_116.graphics.f("#0C593C").s().p("AAdAhIgRghIgHAKIAAAXIgJAAIAAgXIgHgKIgRAhIgLAAIAWgoIgVgZIALAAIAXAfIAAgfIAJAAIAAAfIAXgfIALAAIgVAZIAWAog");
  this.shape_116.setTransform(96.925, 20.95);
  this.shape_117 = new cjs.Shape();
  this.shape_117.graphics.f("#0C593C").s().p("AAaA3IAAgVIgzAAIAAAVIgJAAIAAgeIAGAAQAEgHACgIQACgIABgJIAAgYIAAgXIAvAAIAABPIAHAAIAAAegAgJgWIgBAUIgDAPQgBAHgDAFIAjAAIAAhHIgbAAg");
  this.shape_117.setTransform(89.525, 20.85);
  this.shape_118 = new cjs.Shape();
  this.shape_118.graphics.f("#0C593C").s().p("AACADIAAgGIASgSIAAAKIgMALIAMAMIAAAKgAgTADIAAgGIATgSIAAAKIgMALIAMAMIAAAKg");
  this.shape_118.setTransform(83.125, 20.575);
  this.shape_119 = new cjs.Shape();
  this.shape_119.graphics.f("#0C593C").s().p("AgOArQgGgDgDgHQgEgGgBgJIgBgSQAAgMACgKQADgKAGgHQAHgHALAAQASAAAGANQAGAOAAATQAAAWgGAMQgGANgSAAQgIAAgGgEgAgLggQgEAEgCAIQgBAIAAALIAAARQABAHACAFQACAFAEACQAEADAFAAQAGAAAEgDQAEgCACgFIADgMIAAgRIgBgOQAAgHgDgFQgCgFgEgCQgEgDgFAAQgHAAgEAFg");
  this.shape_119.setTransform(74.275, 19.825);
  this.shape_120 = new cjs.Shape();
  this.shape_120.graphics.f("#0C593C").s().p("AgOArQgGgDgDgHQgEgGgBgJIgBgSQAAgMACgKQADgKAGgHQAHgHALAAQASAAAGANQAGAOAAATQAAAWgGAMQgGANgSAAQgIAAgGgEgAgLggQgEAEgCAIQgBAIAAALIAAARQABAHACAFQACAFAEACQAEADAFAAQAGAAAEgDQAEgCACgFIADgMIAAgRIgBgOQAAgHgDgFQgCgFgEgCQgEgDgFAAQgHAAgEAFg");
  this.shape_120.setTransform(67.325, 19.825);
  this.shape_121 = new cjs.Shape();
  this.shape_121.graphics.f("#0C593C").s().p("AgOArQgGgDgDgHQgEgGgBgJIgBgSQAAgMACgKQADgKAGgHQAHgHALAAQASAAAGANQAGAOAAATQAAAWgGAMQgGANgSAAQgIAAgGgEgAgLggQgEAEgCAIQgBAIAAALIAAARQABAHACAFQACAFAEACQAEADAFAAQAGAAAEgDQAEgCACgFIADgMIAAgRIgBgOQAAgHgDgFQgCgFgEgCQgEgDgFAAQgHAAgEAFg");
  this.shape_121.setTransform(60.375, 19.825);
  this.shape_122 = new cjs.Shape();
  this.shape_122.graphics.f("#0C593C").s().p("AgUAhIAAhBIAVAAQAIgBAFAFQAFAEAAAIQAAAGgDAEQgDAEgEABIAAABQAFAAADAEQAEAFAAAGQAAAGgCAEQgDAEgDACQgEACgFAAgAgKAZIAKAAQAGAAADgCQACgDAAgGQAAgGgDgDQgDgCgEAAIgLAAgAgKgEIAKAAQAFAAACgCQADgEAAgFQAAgJgKAAIgKAAg");
  this.shape_122.setTransform(198.45, 9);
  this.shape_123 = new cjs.Shape();
  this.shape_123.graphics.f("#0C593C").s().p("AgEAhIAAg5IgRAAIAAgIIArAAIAAAIIgRAAIAAA5g");
  this.shape_123.setTransform(193.7, 9);
  this.shape_124 = new cjs.Shape();
  this.shape_124.graphics.f("#0C593C").s().p("AgMAeQgFgEgCgIQgCgHAAgKQAAgjAXAAQAJAAAGAGQAFAHAAAJIgJAAQAAgOgLAAQgHAAgDAHQgDAIAAAMQAAALADAIQACAHAHAAQAHAAACgEQACgFABgIIAJAAQAAALgFAHQgFAHgKAAQgJAAgFgFg");
  this.shape_124.setTransform(189.125, 9.025);
  this.shape_125 = new cjs.Shape();
  this.shape_125.graphics.f("#0C593C").s().p("AATAqIAAgSIglAAIAAASIgKAAIAAgaIAHAAIAEgLIACgKIACgOIAAgWIAjAAIAAA5IAGAAIAAAagAgEgOQAAAKgCAFQgBAHgEAIIAYAAIAAgxIgRAAg");
  this.shape_125.setTransform(183.75, 9.9);
  this.shape_126 = new cjs.Shape();
  this.shape_126.graphics.f("#0C593C").s().p("AgKAgQgFgEgDgHQgCgIAAgNQAAgiAUAAQAJAAAFAFQAFAFABAHQABAIAAAKIgfAAIAAAOQABAGADADQACADAFAAQALAAAAgQIAJAAQAAAHgCAFQgCAGgFADQgEADgHAAQgGAAgFgDgAgIgVQgCAGAAAJIAVAAQAAgKgCgFQgCgFgHAAQgGAAgCAFg");
  this.shape_126.setTransform(178.375, 9.025);
  this.shape_127 = new cjs.Shape();
  this.shape_127.graphics.f("#0C593C").s().p("AgWAtIAAhYIAKAAIAAAHQACgDAEgDQAEgCADgBQAWAAAAAjIgBANQgBAGgDAGQgCAEgEADQgFADgGAAQgDAAgEgCQgDgCgDgFIAAAdgAgKgdQgCAIAAALIABAOQAAAFADAEQADAEAFAAQAHAAADgHQADgIAAgMQAAgbgNAAQgHABgDAHg");
  this.shape_127.setTransform(173.275, 10.05);
  this.shape_128 = new cjs.Shape();
  this.shape_128.graphics.f("#0C593C").s().p("AgMAeQgFgEgCgIQgCgHAAgKQAAgjAXAAQAJAAAGAGQAFAHAAAJIgJAAQAAgOgLAAQgHAAgDAHQgDAIAAAMQAAALADAIQACAHAHAAQAHAAACgEQACgFABgIIAJAAQAAALgFAHQgFAHgKAAQgJAAgFgFg");
  this.shape_128.setTransform(167.875, 9.025);
  this.shape_129 = new cjs.Shape();
  this.shape_129.graphics.f("#0C593C").s().p("AAQAhIgPgbIgPAbIgKAAIAUghIgTggIAJAAIAPAZIAOgZIAKAAIgTAgIATAhg");
  this.shape_129.setTransform(160.3, 9);
  this.shape_130 = new cjs.Shape();
  this.shape_130.graphics.f("#0C593C").s().p("AAVAhIAAhBIAKAAIAABBgAgeAhIAAhBIAKAAIAAAcIANAAQAFAAADACQAFACACAEQACAFAAAFQAAAGgCAEQgDAFgEACQgDADgFgBgAgUAZIAJAAQAHAAADgCQABgDAAgGQAAgLgKAAIgKAAg");
  this.shape_130.setTransform(154.15, 9);
  this.shape_131 = new cjs.Shape();
  this.shape_131.graphics.f("#0C593C").s().p("AAMAhIAAgeIgXAAIAAAeIgKAAIAAhBIAKAAIAAAcIAXAAIAAgcIAKAAIAABBg");
  this.shape_131.setTransform(147.6, 9);
  this.shape_132 = new cjs.Shape();
  this.shape_132.graphics.f("#0C593C").s().p("AAMAhIAAgeIgXAAIAAAeIgJAAIAAhBIAJAAIAAAcIAXAAIAAgcIAKAAIAABBg");
  this.shape_132.setTransform(142, 9);
  this.shape_133 = new cjs.Shape();
  this.shape_133.graphics.f("#0C593C").s().p("AgKAgQgFgEgDgHQgCgIAAgNQAAgiAUAAQAJAAAFAFQAFAFABAHQABAIAAAKIgfAAIAAAOQABAGADADQACADAFAAQALAAAAgQIAJAAQAAAHgCAFQgCAGgFADQgEADgHAAQgGAAgFgDgAgIgVQgCAGAAAJIAVAAQAAgKgCgFQgCgFgHAAQgGAAgCAFg");
  this.shape_133.setTransform(136.675, 9.025);
  this.shape_134 = new cjs.Shape();
  this.shape_134.graphics.f("#0C593C").s().p("AgTAhIAAhBIAUAAQAIgBAFAFQAFAEAAAIQAAAGgCAEQgDAEgFABIAAABQAGAAACAEQADAFAAAGQAAAGgCAEQgCAEgEACQgEACgDAAgAgKAZIAKAAQAGAAADgCQACgDAAgGQAAgGgCgDQgEgCgFAAIgKAAgAgKgEIAKAAQAFAAACgCQADgEgBgFQABgJgKAAIgKAAg");
  this.shape_134.setTransform(131.9, 9);
  this.shape_135 = new cjs.Shape();
  this.shape_135.graphics.f("#0C593C").s().p("AgEAhIAAg5IgRAAIAAgIIArAAIAAAIIgRAAIAAA5g");
  this.shape_135.setTransform(127.15, 9);
  this.shape_136 = new cjs.Shape();
  this.shape_136.graphics.f("#0C593C").s().p("AgMAeQgFgEgCgIQgCgHAAgKQAAgjAXAAQAJAAAGAGQAFAHAAAJIgJAAQAAgOgLAAQgHAAgDAHQgDAIAAAMQAAALADAIQACAHAHAAQAHAAACgEQACgFABgIIAJAAQAAALgFAHQgFAHgKAAQgJAAgFgFg");
  this.shape_136.setTransform(122.575, 9.025);
  this.shape_137 = new cjs.Shape();
  this.shape_137.graphics.f("#0C593C").s().p("AgWAtIAAhYIAKAAIAAAHQACgDAEgDQAEgCADgBQAWAAAAAjIgBANQgBAGgDAGQgCAEgEADQgFADgGAAQgDAAgEgCQgDgCgDgFIAAAdgAgKgdQgCAIAAALIABAOQAAAFADAEQADAEAFAAQAHAAADgHQADgIAAgMQAAgbgNAAQgHABgDAHg");
  this.shape_137.setTransform(117.425, 10.05);
  this.shape_138 = new cjs.Shape();
  this.shape_138.graphics.f("#0C593C").s().p("AgWARQAAgGACgEQABgEAEgCIAKgEIAKgFQADgBAAgHQAAgGgCgCQgCgCgFAAQgFAAgDADQgCADAAAFIgIAAQAAgTATAAQAFAAAEACQAFACACAEQACAEAAAFIAAAmQAAAFADAAIACAAIAAAHIgEABQgEAAgDgCQgCgBgBgHIAAAAQgCAFgEADQgDADgFAAQgRAAAAgSgAABAAIgHAEQgDACgBADQgCADAAAEQAAAKAJAAQAFAAADgDIACgDIABgDIAAgHIAAgMIgHACg");
  this.shape_138.setTransform(112.025, 9.025);
  this.shape_139 = new cjs.Shape();
  this.shape_139.graphics.f("#0C593C").s().p("AALAhIgPghIgIAKIAAAXIgJAAIAAhBIAJAAIAAAfIAXgfIALAAIgVAaIAWAng");
  this.shape_139.setTransform(107.45, 9);
  this.shape_140 = new cjs.Shape();
  this.shape_140.graphics.f("#0C593C").s().p("AgKAgQgFgEgDgHQgCgIAAgNQAAgiAUAAQAJAAAFAFQAFAFABAHQABAIAAAKIgfAAIAAAOQABAGADADQACADAFAAQALAAAAgQIAJAAQAAAHgCAFQgCAGgFADQgEADgHAAQgGAAgFgDgAgIgVQgCAGAAAJIAVAAQAAgKgCgFQgCgFgHAAQgGAAgCAFg");
  this.shape_140.setTransform(102.075, 9.025);
  this.shape_141 = new cjs.Shape();
  this.shape_141.graphics.f("#0C593C").s().p("AgYAhIAAgIIAEABQAAAAABAAQAAAAABgBQAAAAABAAQAAgBABAAQABgCABgGIABgQIAAghIAmAAIAABCIgJAAIAAg6IgUAAIAAAaQAAAQgDAIQgDAJgJAAIgFgBg");
  this.shape_141.setTransform(96.525, 9.025);
  this.shape_142 = new cjs.Shape();
  this.shape_142.graphics.f("#0C593C").s().p("AgKAgQgFgEgDgHQgCgIAAgNQAAgiAUAAQAJAAAFAFQAFAFABAHQABAIAAAKIgfAAIAAAOQABAGADADQACADAFAAQALAAAAgQIAJAAQAAAHgCAFQgCAGgFADQgEADgHAAQgGAAgFgDgAgIgVQgCAGAAAJIAVAAQAAgKgCgFQgCgFgHAAQgGAAgCAFg");
  this.shape_142.setTransform(88.925, 9.025);
  this.shape_143 = new cjs.Shape();
  this.shape_143.graphics.f("#0C593C").s().p("AALAhIgPghIgHAKIAAAXIgKAAIAAhBIAKAAIAAAfIAVgfIAMAAIgVAaIAWAng");
  this.shape_143.setTransform(84.4, 9);
  this.shape_144 = new cjs.Shape();
  this.shape_144.graphics.f("#0C593C").s().p("AAMAsIAAgxIABgJIgCAJIgUAxIgMAAIAAhCIAKAAIAAAyIgCAIIADgIIAUgyIAMAAIAABCgAgJggQgFgEAAgHIAFAAQABAIAIAAQAEAAADgCQACgCABgEIAGAAQgBAHgEAEQgFAEgGAAQgFAAgEgEg");
  this.shape_144.setTransform(78.7, 7.925);
  this.shape_145 = new cjs.Shape();
  this.shape_145.graphics.f("#0C593C").s().p("AgKAgQgFgEgDgHQgCgIAAgNQAAgiAUAAQAJAAAFAFQAFAFABAHQABAIAAAKIgfAAIAAAOQABAGADADQACADAFAAQALAAAAgQIAJAAQAAAHgCAFQgCAGgFADQgEADgHAAQgGAAgFgDgAgIgVQgCAGAAAJIAVAAQAAgKgCgFQgCgFgHAAQgGAAgCAFg");
  this.shape_145.setTransform(73.325, 9.025);
  this.shape_146 = new cjs.Shape();
  this.shape_146.graphics.f("#0C593C").s().p("AAMAhIAAgeIgXAAIAAAeIgJAAIAAhBIAJAAIAAAcIAXAAIAAgcIAKAAIAABBg");
  this.shape_146.setTransform(68.1, 9);
  this.shape_147 = new cjs.Shape();
  this.shape_147.graphics.f("#0C593C").s().p("AANAhIAAgxIABgIIgCAIIgWAxIgLAAIAAhBIAKAAIAAAxIgBAIIABgIIAWgxIALAAIAABBg");
  this.shape_147.setTransform(62.45, 9);
  this.shape_148 = new cjs.Shape();
  this.shape_148.graphics.f("#0C593C").s().p("AgYAhIAAgIIAEABQAAAAABAAQAAAAABgBQAAAAABAAQAAgBABAAQABgCABgGIABgQIAAghIAmAAIAABCIgJAAIAAg6IgUAAIAAAaQAAAQgDAIQgDAJgJAAIgFgBg");
  this.shape_148.setTransform(56.475, 9.025);
  this.shape_149 = new cjs.Shape();
  this.shape_149.graphics.f("#0C593C").s().p("AgZAtIAAhZIAYAAQAHAAAGACQAFAEADAFQADAFAAAGQAAAIgEAGQgDAFgGABIAAAAQAEABAEACQADACACAGQADAFAAAFQgBANgGAGQgHAHgMAAgAgPAkIAPAAQAHAAAEgEQAEgEAAgJQAAgRgPAAIgPAAgAgPgGIANAAQAEAAADgBQAEgCABgDQACgDAAgGQAAgOgNAAIgOAAg");
  this.shape_149.setTransform(48.45, 7.85);
  this.shape_150 = new cjs.Shape();
  this.shape_150.graphics.f("#0C593C").s().p("AAAAGIgIALIgFgDIAJgLIgOgFIACgFIAOAFIAAgPIAFAAIAAAPIAOgFIABAGIgNADIAJAMIgFAEg");
  this.shape_150.setTransform(42.35, 5.125);
  this.shape_151 = new cjs.Shape();
  this.shape_151.graphics.f("#0C593C").s().p("AAWA4IAAhGIAAgLIABgOIgBAAIgSBfIgHAAIgShfIgBAAIABAOIAAALIAABGIgJAAIAAhwIANAAIARBcIAShcIANAAIAABwg");
  this.shape_151.setTransform(231.2, 62.3);
  this.shape_152 = new cjs.Shape();
  this.shape_152.graphics.f("#0C593C").s().p("AgPA4IAAhwIAfAAIAAANIgWAAIAAAkIAUAAIAAAKIgUAAIAAAqIAWAAIAAALg");
  this.shape_152.setTransform(225.275, 62.3);
  this.shape_153 = new cjs.Shape();
  this.shape_153.graphics.f("#0C593C").s().p("AAPA4IAAhBIAAgOIAAgMIgbBbIgLAAIAAhwIAJAAIAABCIAAALIgBAOIAchbIAKAAIAABwg");
  this.shape_153.setTransform(219.8, 62.3);
  this.shape_154 = new cjs.Shape();
  this.shape_154.graphics.f("#0C593C").s().p("AANA4IAAg1IgZAAIAAA1IgJAAIAAhwIAJAAIAAAxIAZAAIAAgxIAJAAIAABwg");
  this.shape_154.setTransform(213.675, 62.3);
  this.shape_155 = new cjs.Shape();
  this.shape_155.graphics.f("#0C593C").s().p("AgPA4IAAhwIAfAAIAAANIgWAAIAAAkIAUAAIAAAKIgUAAIAAAqIAWAAIAAALg");
  this.shape_155.setTransform(208.675, 62.3);
  this.shape_156 = new cjs.Shape();
  this.shape_156.graphics.f("#0C593C").s().p("AANA4IAAg1IgZAAIAAA1IgJAAIAAhwIAJAAIAAAxIAZAAIAAgxIAJAAIAABwg");
  this.shape_156.setTransform(203.325, 62.3);
  this.shape_157 = new cjs.Shape();
  this.shape_157.graphics.f("#0C593C").s().p("AgPA4IAAhwIAfAAIAAANIgWAAIAAAkIAUAAIAAAKIgUAAIAAAqIAWAAIAAALg");
  this.shape_157.setTransform(198.275, 62.3);
  this.shape_158 = new cjs.Shape();
  this.shape_158.graphics.f("#0C593C").s().p("AAWA4IAAhGIAAgLIABgOIgBAAIgSBfIgHAAIgShfIgBAAIABAOIAAALIAABGIgJAAIAAhwIANAAIARBcIAShcIANAAIAABwg");
  this.shape_158.setTransform(192.05, 62.3);
  this.shape_159 = new cjs.Shape();
  this.shape_159.graphics.f("#0C593C").s().p("AAPA4IAAhBIAAgOIABgMIgcBbIgKAAIAAhwIAIAAIAABCIAAALIgBAOIAchbIALAAIAABwg");
  this.shape_159.setTransform(185.1, 62.3);
  this.shape_160 = new cjs.Shape();
  this.shape_160.graphics.f("#0C593C").s().p("AgSA4IAAhwIAQAAQAKAAAGAJQAEAIAAARQAAAQgEAJQgGAJgLAAIgGAAIAAAsgAgJABIAFAAQAHgBADgEQAEgGgBgMQAAgLgCgGQgEgEgGAAIgGAAg");
  this.shape_160.setTransform(179.7, 62.3);
  this.shape_161 = new cjs.Shape();
  this.shape_161.graphics.f("#0C593C").s().p("AAMA4IAAhjIgYAAIAABjIgIAAIAAhwIApAAIAABwg");
  this.shape_161.setTransform(174.025, 62.3);
  this.shape_162 = new cjs.Shape();
  this.shape_162.graphics.f("#0C593C").s().p("AATBIIAAgfIglAAIAAAfIgIAAIAAgrIAFAAQAFgYAEgYQADgZABgbIAcAAIAABkIAHAAIAAArgAgCgcIgFAdIgFAcIAYAAIAAhYIgMAAIgCAfg");
  this.shape_162.setTransform(164.05, 63.825);
  this.shape_163 = new cjs.Shape();
  this.shape_163.graphics.f("#0C593C").s().p("AgPA4IAAhwIAfAAIAAANIgWAAIAAAkIAUAAIAAAKIgUAAIAAAqIAWAAIAAALg");
  this.shape_163.setTransform(159.225, 62.3);
  this.shape_164 = new cjs.Shape();
  this.shape_164.graphics.f("#0C593C").s().p("AgRA4IAAhwIAOAAQALAAAFAJQAGAIAAARQAAAQgGAJQgFAJgLAAIgGAAIAAAsgAgJABIAFAAQAGgBAEgEQADgGABgMQAAgLgDgGQgEgEgGAAIgGAAg");
  this.shape_164.setTransform(154.65, 62.3);
  this.shape_165 = new cjs.Shape();
  this.shape_165.graphics.f("#0C593C").s().p("AgPA4IAAhwIAfAAIAAANIgWAAIAAAkIAUAAIAAAKIgUAAIAAAqIAWAAIAAALg");
  this.shape_165.setTransform(149.925, 62.3);
  this.shape_166 = new cjs.Shape();
  this.shape_166.graphics.f("#0C593C").s().p("AAMA4IAAhjIgYAAIAABjIgIAAIAAhwIApAAIAABwg");
  this.shape_166.setTransform(144.525, 62.3);
  this.shape_167 = new cjs.Shape();
  this.shape_167.graphics.f("#0C593C").s().p("AgDAIQgCgDAAgFQAAgEACgDQABAAAAgBQAAAAABgBQAAAAABAAQAAAAAAAAQABAAAAAAQABAAABAAQAAABAAAAQABABAAAAQACADAAAEQAAAFgCADQAAAAgBABQAAAAAAABQgBAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBgBAAAAQAAgBgBAAg");
  this.shape_167.setTransform(136.275, 67.075);
  this.shape_168 = new cjs.Shape();
  this.shape_168.graphics.f("#0C593C").s().p("AAMA4IAAguIgJAAIgNAuIgKAAIAQgyQgFgCgDgIQgEgIAAgLQAAghAVAAIAQAAIAABwgAgDgnQgDAFAAALQAAAWALAAIAHAAIAAgrIgGAAQgGAAgDAFg");
  this.shape_168.setTransform(132.2, 62.3);
  this.shape_169 = new cjs.Shape();
  this.shape_169.graphics.f("#0C593C").s().p("AAPA4IAAhBIAAgOIABgMIgcBbIgLAAIAAhwIAJAAIAABCIAAALIgBAOIAchbIALAAIAABwg");
  this.shape_169.setTransform(126.85, 62.3);
  this.shape_170 = new cjs.Shape();
  this.shape_170.graphics.f("#0C593C").s().p("AANA4IAAg1IgZAAIAAA1IgJAAIAAhwIAJAAIAAAxIAZAAIAAgxIAJAAIAABwg");
  this.shape_170.setTransform(120.775, 62.3);
  this.shape_171 = new cjs.Shape();
  this.shape_171.graphics.f("#0C593C").s().p("AAQA4IgGgjIgTAAIgGAjIgJAAIAUhwIAJAAIAUBwgAAAgiIgBAIIgGAjIAPAAIgGgjIgBgJIgBgIIAAAJg");
  this.shape_171.setTransform(115.225, 62.3);
  this.shape_172 = new cjs.Shape();
  this.shape_172.graphics.f("#0C593C").s().p("AgLA5IgIgEIAAgOQADAEAFACIAIABQANAAAAgVQAAgLgEgFQgEgFgHAAIgHAAIAAgLIAHAAQAOAAAAgVQAAgJgDgEQgDgFgEABQgEAAgDACIgGAGIgEgKQADgFAFgCQAEgDAGAAQAIAAAFAHQAFAIAAAMQAAALgDAIQgEAHgHACIAAABQAIABAEAGQAEAIAAAMQAAAOgGAJQgGAJgKAAIgJgBg");
  this.shape_172.setTransform(110.225, 62.3);
  this.shape_173 = new cjs.Shape();
  this.shape_173.graphics.f("#0C593C").s().p("AAQA4IgGgjIgTAAIgGAjIgJAAIAUhwIAJAAIAUBwgAAAgiIgBAIIgGAjIAPAAIgGgjIgBgJIgBgIIAAAJg");
  this.shape_173.setTransform(105.425, 62.3);
  this.shape_174 = new cjs.Shape();
  this.shape_174.graphics.f("#0C593C").s().p("AALA4IgWg4IAAA4IgJAAIAAhwIAJAAIAAA2IAVg2IAKAAIgWA3IAXA5g");
  this.shape_174.setTransform(100.825, 62.3);
  this.shape_175 = new cjs.Shape();
  this.shape_175.graphics.f("#0C593C").s().p("AgOAyQgFgHgDgNQgDgOAAgQQAAgbAHgPQAGgPAMAAQAJAAAGAHQAFAIADANQADANAAAQQAAAQgDAOQgDANgFAHQgGAIgJAAQgIAAgGgIgAgLghQgEAMAAAVQAAAWAEAMQAEAMAHAAQAIAAAEgMQAEgLAAgXQAAgVgEgMQgEgMgIAAQgHAAgEAMg");
  this.shape_175.setTransform(94.875, 62.3);
  this.shape_176 = new cjs.Shape();
  this.shape_176.graphics.f("#0C593C").s().p("AAMA4IAAhjIgYAAIAABjIgIAAIAAhwIApAAIAABwg");
  this.shape_176.setTransform(88.775, 62.3);
  this.shape_177 = new cjs.Shape();
  this.shape_177.graphics.f("#0C593C").s().p("AgOAyQgFgHgDgNQgDgOAAgQQAAgbAHgPQAGgPAMAAQAJAAAGAHQAFAIADANQADANAAAQQAAAQgDAOQgDANgFAHQgGAIgJAAQgIAAgGgIgAgLghQgEAMAAAVQAAAWAEAMQAEAMAHAAQAIAAAEgMQAEgLAAgXQAAgVgEgMQgEgMgIAAQgHAAgEAMg");
  this.shape_177.setTransform(82.775, 62.3);
  this.shape_178 = new cjs.Shape();
  this.shape_178.graphics.f("#0C593C").s().p("AgTA4IAAhwIARAAQAJAAAGAHQAFAGABAPQAAAKgDAHQgDAGgFACIAAABQAFACAEAGQADAGAAAMQAAAPgFAJQgFAIgKAAgAgKAtIAKAAQAGgBACgFQADgFAAgLQAAgJgDgFQgDgGgGAAIgJAAgAgKgHIAJAAQAFgBADgEQADgFAAgKQAAgRgMAAIgIAAg");
  this.shape_178.setTransform(77.25, 62.3);
  this.shape_179 = new cjs.Shape();
  this.shape_179.graphics.f("#0C593C").s().p("AAPA4IAAhBIAAgOIABgMIgcBbIgKAAIAAhwIAIAAIAABCIAAALIAAAOIAbhbIALAAIAABwg");
  this.shape_179.setTransform(71.35, 62.3);
  this.shape_180 = new cjs.Shape();
  this.shape_180.graphics.f("#0C593C").s().p("AgDA4IAAhjIgRAAIAAgNIApAAIAAANIgQAAIAABjg");
  this.shape_180.setTransform(66.05, 62.3);
  this.shape_181 = new cjs.Shape();
  this.shape_181.graphics.f("#0C593C").s().p("AgOAyQgFgHgDgNQgDgOAAgQQAAgbAHgPQAGgPAMAAQAJAAAGAHQAFAIADANQADANAAAQQAAAQgDAOQgDANgFAHQgGAIgJAAQgIAAgGgIgAgLghQgEAMAAAVQAAAWAEAMQAEAMAHAAQAIAAAEgMQAEgLAAgXQAAgVgEgMQgEgMgIAAQgHAAgEAMg");
  this.shape_181.setTransform(60.825, 62.3);
  this.shape_182 = new cjs.Shape();
  this.shape_182.graphics.f("#0C593C").s().p("AgSA4IAAhwIAQAAQAKAAAGAJQAEAIAAARQAAAQgEAJQgGAJgLAAIgGAAIAAAsgAgJABIAFAAQAHgBADgEQAEgGgBgMQAAgLgCgGQgEgEgGAAIgGAAg");
  this.shape_182.setTransform(55.5, 62.3);
  this.shape_183 = new cjs.Shape();
  this.shape_183.graphics.f("#0C593C").s().p("AAMA4IAAhjIgYAAIAABjIgIAAIAAhwIApAAIAABwg");
  this.shape_183.setTransform(49.825, 62.3);
  this.shape_184 = new cjs.Shape();
  this.shape_184.graphics.f("#0C593C").s().p("AAMA4IAAguIgJAAIgNAuIgKAAIAQgyQgFgCgEgIQgDgIAAgLQAAghAVAAIAQAAIAABwgAgEgnQgDAFAAALQAAAWAMAAIAHAAIAAgrIgHAAQgFAAgEAFg");
  this.shape_184.setTransform(39.9, 62.3);
  this.shape_185 = new cjs.Shape();
  this.shape_185.graphics.f("#0C593C").s().p("AgNArQgHgQAAgbQAAgPAEgOQACgNAGgHQAGgIAIAAQAJAAAGAGIgDAMIgGgEQgDgCgDAAQgGAAgDAGQgDAGgCALQgCAKgBAMQAAAWAFAMQAFAMAHAAQAEAAADgBIAGgDIAAAMQgFAEgJAAQgLAAgHgPg");
  this.shape_185.setTransform(35.3, 62.275);
  this.shape_186 = new cjs.Shape();
  this.shape_186.graphics.f("#0C593C").s().p("AgEA4IAAhjIgPAAIAAgNIAnAAIAAANIgQAAIAABjg");
  this.shape_186.setTransform(30.55, 62.3);
  this.shape_187 = new cjs.Shape();
  this.shape_187.graphics.f("#0C593C").s().p("AgGAsQgGgOgBgbIgMAAIAAA1IgIAAIAAhwIAIAAIAAAxIANAAQAAgYAGgNQAGgNALAAQALAAAGAPQAGAPAAAbQAAAQgCAOQgDANgFAHQgFAIgIAAQgLAAgGgOgAAAghQgDAMAAAVQAAAWADAMQADAMAHAAQAIAAAEgMQADgLAAgXQAAgVgDgMQgEgMgIAAQgHAAgDAMg");
  this.shape_187.setTransform(24.425, 62.3);
  this.shape_188 = new cjs.Shape();
  this.shape_188.graphics.f("#0C593C").s().p("AgPA4IAAhwIAfAAIAAANIgWAAIAAAkIAUAAIAAAKIgUAAIAAAqIAWAAIAAALg");
  this.shape_188.setTransform(18.125, 62.3);
  this.shape_189 = new cjs.Shape();
  this.shape_189.graphics.f("#0C593C").s().p("AAWA4IAAhGIAAgLIAAgOIAAAAIgTBfIgGAAIgThfIAAAAIAAAOIAAALIAABGIgIAAIAAhwIANAAIARBcIAShcIAMAAIAABwg");
  this.shape_189.setTransform(11.9, 62.3);
  this.shape_190 = new cjs.Shape();
  this.shape_190.graphics.f("#0C593C").s().p("AAPA4IAAhBIAAgOIABgMIgcBbIgLAAIAAhwIAJAAIAABCIAAALIgBAOIAchbIALAAIAABwg");
  this.shape_190.setTransform(4.9, 62.3);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_190
   }, {
    t: this.shape_189
   }, {
    t: this.shape_188
   }, {
    t: this.shape_187
   }, {
    t: this.shape_186
   }, {
    t: this.shape_185
   }, {
    t: this.shape_184
   }, {
    t: this.shape_183
   }, {
    t: this.shape_182
   }, {
    t: this.shape_181
   }, {
    t: this.shape_180
   }, {
    t: this.shape_179
   }, {
    t: this.shape_178
   }, {
    t: this.shape_177
   }, {
    t: this.shape_176
   }, {
    t: this.shape_175
   }, {
    t: this.shape_174
   }, {
    t: this.shape_173
   }, {
    t: this.shape_172
   }, {
    t: this.shape_171
   }, {
    t: this.shape_170
   }, {
    t: this.shape_169
   }, {
    t: this.shape_168
   }, {
    t: this.shape_167
   }, {
    t: this.shape_166
   }, {
    t: this.shape_165
   }, {
    t: this.shape_164
   }, {
    t: this.shape_163
   }, {
    t: this.shape_162
   }, {
    t: this.shape_161
   }, {
    t: this.shape_160
   }, {
    t: this.shape_159
   }, {
    t: this.shape_158
   }, {
    t: this.shape_157
   }, {
    t: this.shape_156
   }, {
    t: this.shape_155
   }, {
    t: this.shape_154
   }, {
    t: this.shape_153
   }, {
    t: this.shape_152
   }, {
    t: this.shape_151
   }, {
    t: this.shape_150
   }, {
    t: this.shape_149
   }, {
    t: this.shape_148
   }, {
    t: this.shape_147
   }, {
    t: this.shape_146
   }, {
    t: this.shape_145
   }, {
    t: this.shape_144
   }, {
    t: this.shape_143
   }, {
    t: this.shape_142
   }, {
    t: this.shape_141
   }, {
    t: this.shape_140
   }, {
    t: this.shape_139
   }, {
    t: this.shape_138
   }, {
    t: this.shape_137
   }, {
    t: this.shape_136
   }, {
    t: this.shape_135
   }, {
    t: this.shape_134
   }, {
    t: this.shape_133
   }, {
    t: this.shape_132
   }, {
    t: this.shape_131
   }, {
    t: this.shape_130
   }, {
    t: this.shape_129
   }, {
    t: this.shape_128
   }, {
    t: this.shape_127
   }, {
    t: this.shape_126
   }, {
    t: this.shape_125
   }, {
    t: this.shape_124
   }, {
    t: this.shape_123
   }, {
    t: this.shape_122
   }, {
    t: this.shape_121
   }, {
    t: this.shape_120
   }, {
    t: this.shape_119
   }, {
    t: this.shape_118
   }, {
    t: this.shape_117
   }, {
    t: this.shape_116
   }, {
    t: this.shape_115
   }, {
    t: this.shape_114
   }, {
    t: this.shape_113
   }, {
    t: this.shape_112
   }, {
    t: this.shape_111
   }, {
    t: this.shape_110
   }, {
    t: this.shape_109
   }, {
    t: this.shape_108
   }, {
    t: this.shape_107
   }, {
    t: this.shape_106
   }, {
    t: this.shape_105
   }, {
    t: this.shape_104
   }, {
    t: this.shape_103
   }, {
    t: this.shape_102
   }, {
    t: this.shape_101
   }, {
    t: this.shape_100
   }, {
    t: this.shape_99
   }, {
    t: this.shape_98
   }, {
    t: this.shape_97
   }, {
    t: this.shape_96
   }, {
    t: this.shape_95
   }, {
    t: this.shape_94
   }, {
    t: this.shape_93
   }, {
    t: this.shape_92
   }, {
    t: this.shape_91
   }, {
    t: this.shape_90
   }, {
    t: this.shape_89
   }, {
    t: this.shape_88
   }, {
    t: this.shape_87
   }, {
    t: this.shape_86
   }, {
    t: this.shape_85
   }, {
    t: this.shape_84
   }, {
    t: this.shape_83
   }, {
    t: this.shape_82
   }, {
    t: this.shape_81
   }, {
    t: this.shape_80
   }, {
    t: this.shape_79
   }, {
    t: this.shape_78
   }, {
    t: this.shape_77
   }, {
    t: this.shape_76
   }, {
    t: this.shape_75
   }, {
    t: this.shape_74
   }, {
    t: this.shape_73
   }, {
    t: this.shape_72
   }, {
    t: this.shape_71
   }, {
    t: this.shape_70
   }, {
    t: this.shape_69
   }, {
    t: this.shape_68
   }, {
    t: this.shape_67
   }, {
    t: this.shape_66
   }, {
    t: this.shape_65
   }, {
    t: this.shape_64
   }, {
    t: this.shape_63
   }, {
    t: this.shape_62
   }, {
    t: this.shape_61
   }, {
    t: this.shape_60
   }, {
    t: this.shape_59
   }, {
    t: this.shape_58
   }, {
    t: this.shape_57
   }, {
    t: this.shape_56
   }, {
    t: this.shape_55
   }, {
    t: this.shape_54
   }, {
    t: this.shape_53
   }, {
    t: this.shape_52
   }, {
    t: this.shape_51
   }, {
    t: this.shape_50
   }, {
    t: this.shape_49
   }, {
    t: this.shape_48
   }, {
    t: this.shape_47
   }, {
    t: this.shape_46
   }, {
    t: this.shape_45
   }, {
    t: this.shape_44
   }, {
    t: this.shape_43
   }, {
    t: this.shape_42
   }, {
    t: this.shape_41
   }, {
    t: this.shape_40
   }, {
    t: this.shape_39
   }, {
    t: this.shape_38
   }, {
    t: this.shape_37
   }, {
    t: this.shape_36
   }, {
    t: this.shape_35
   }, {
    t: this.shape_34
   }, {
    t: this.shape_33
   }, {
    t: this.shape_32
   }, {
    t: this.shape_31
   }, {
    t: this.shape_30
   }, {
    t: this.shape_29
   }, {
    t: this.shape_28
   }, {
    t: this.shape_27
   }, {
    t: this.shape_26
   }, {
    t: this.shape_25
   }, {
    t: this.shape_24
   }, {
    t: this.shape_23
   }, {
    t: this.shape_22
   }, {
    t: this.shape_21
   }, {
    t: this.shape_20
   }, {
    t: this.shape_19
   }, {
    t: this.shape_18
   }, {
    t: this.shape_17
   }, {
    t: this.shape_16
   }, {
    t: this.shape_15
   }, {
    t: this.shape_14
   }, {
    t: this.shape_13
   }, {
    t: this.shape_12
   }, {
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
 }).prototype = getMCSymbolPrototype(lib.l3, new cjs.Rectangle(-2, -1, 242, 100.1), null);
 (lib.l2 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#0C593C").s().p("AgEAGIAAgLIAJAAIAAALg");
  this.shape.setTransform(226.975, 20.275);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#0C593C").s().p("AATAgIAAg3IgQA3IgFAAIgQg3IAAA3IgJAAIAAg/IAOAAIAMApIABANIACgNIAMgpIAOAAIAAA/g");
  this.shape_1.setTransform(222.325, 17.65);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#0C593C").s().p("AgKAfQgEgDgDgIQgCgHAAgNQAAghATAAQAJAAAEAFQAFAFABAHQABAHAAAKIgeAAIABAOQABAFACADQADADAEAAQAKAAAAgPIAJAAQAAAGgCAGQgCAFgEADQgFADgGAAQgGAAgFgDgAgIgTQgCAFAAAIIAVAAQAAgJgCgFQgCgFgHAAQgFAAgDAGg");
  this.shape_2.setTransform(216.525, 17.625);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#0C593C").s().p("AAMAgIAAgvIABgIIgCAIIgUAvIgLAAIAAg/IAJAAIAAAvIgBAIIACgIIAUgvIALAAIAAA/g");
  this.shape_3.setTransform(211.475, 17.65);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#0C593C").s().p("AALAgIAAgeIgWAAIAAAeIgJAAIAAg/IAJAAIAAAbIAWAAIAAgbIAKAAIAAA/g");
  this.shape_4.setTransform(206.1, 17.65);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#0C593C").s().p("AgVAQQAAgFABgEQACgEADgCIAKgEIAKgEQADgBAAgHQAAgFgDgDQgCgCgEAAQgFAAgCADQgDADAAAFIgIAAQAAgTATAAQAFAAAEADQAEACACAEQACADAAAFIAAAlQAAAFADAAIACAAIAAAGIgEABQgEAAgCgCQgCgBgBgGIgBAAQgBAEgEADQgDADgFAAQgQAAAAgSgAABABIgHADIgEAFQgCADAAAEQAAAKAJAAQAFAAADgEIACgCIAAgEIABgGIAAgMIgHADg");
  this.shape_5.setTransform(201.075, 17.625);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#0C593C").s().p("AgTAgIAAg/IAUAAQAHAAAGAEQAEAFAAAGQAAAGgCAEQgDAEgFABQAGABACAEQAEAEAAAGQAAAGgDAEQgCAEgDACQgEACgEAAgAgKAYIAKAAQAGAAACgCQACgDAAgGQAAgFgCgDQgDgDgFABIgKAAgAgKgEIAKAAQAEAAACgCQADgDAAgFQAAgKgJABIgKAAg");
  this.shape_6.setTransform(196.45, 17.65);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#0C593C").s().p("AgLAfQgGgDgCgIQgDgHAAgNQAAgPAFgJQAGgJALAAQAXAAAAAhQAAANgDAHQgDAIgFADQgFADgHAAQgGAAgFgDgAgHgWQgDACgBAGIgCAPIACAOQABAFACADQADADAFAAQAFAAADgDQADgDABgFIABgOIgBgPQgBgGgDgCQgDgDgFAAQgEAAgDADg");
  this.shape_7.setTransform(191.2, 17.625);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#0C593C").s().p("AgKAgQgEgDgDgFQgCgEgBgIIAJAAQABAGABADQABADADABQACABADAAQAMAAAAgMQAAgFgEgDQgCgEgGAAIgDAAIAAgGIADAAQAEAAADgDQADgDAAgFQAAgEgDgDQgCgDgFAAQgFAAgCADQgDADAAAFIgJAAQABgFACgEQACgEAFgDQAEgDAFAAQAFAAAEADQAFACACADQADAEAAAFQAAAGgDAEQgEAEgFABIAAABQAGAAADAEQAFAEAAAHQAAAGgDAEQgDAEgEADQgEACgHAAQgFAAgFgCg");
  this.shape_8.setTransform(186.2, 17.625);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#0C593C").s().p("AgVAQQAAgFABgEQACgEADgCIAKgEIAKgEQADgBAAgHQAAgFgDgDQgCgCgEAAQgFAAgCADQgDADAAAFIgIAAQAAgTATAAQAFAAAEADQAEACACAEQACADAAAFIAAAlQAAAFADAAIACAAIAAAGIgEABQgEAAgCgCQgCgBgBgGIgBAAQgBAEgEADQgDADgFAAQgQAAAAgSgAABABIgHADIgEAFQgCADAAAEQAAAKAJAAQAFAAADgEIACgCIAAgEIABgGIAAgMIgHADg");
  this.shape_9.setTransform(181.675, 17.625);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.f("#0C593C").s().p("AgVAsIAAhVIAJAAIAAAHIAAAAQADgEADgCQAEgDACAAQAWAAAAAhIgBANIgEALQgCAFgEACQgEADgGAAQgDAAgDgCQgEgCgDgEIAAAcgAgKgcQgCAIAAALIABAMQABAGACAEQAEADAEAAQAHAAACgGQADgHAAgNQAAgZgMAAQgHAAgDAHg");
  this.shape_10.setTransform(176.75, 18.625);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.f("#0C593C").s().p("AgNAoQgFgEgCgIQgCgJAAgNIABgRQACgHACgGQADgEADgEQAFgDAEgBIAKgDQADgBABgDIAIAAQgCAGgEADQgFADgIACQgFABgFAFQgEAGAAAIQAFgKAJAAQAHAAAFADQAEAEADAHQADAGAAAJQAAAMgCAHQgDAIgFADQgFAEgIAAQgIAAgFgEgAgJgFQgDAFgBAKIABAPQACAFADAEQADACAEAAQAHAAADgGQADgHAAgNQAAgKgDgFQgEgHgGABQgGgBgDAHg");
  this.shape_11.setTransform(171.45, 16.6);
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.f("#0C593C").s().p("AgMAfQgEgDgDgIQgDgHAAgNQAAgPAGgJQAFgJALAAQAXAAAAAhQAAANgDAHQgDAIgFADQgFADgHAAQgGAAgGgDgAgHgWQgDACgCAGIgBAPIABAOQACAFADADQADADAEAAQAFAAADgDQADgDABgFIABgOIgBgPQgBgGgDgCQgEgDgEAAQgEAAgDADg");
  this.shape_12.setTransform(166.35, 17.625);
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.f("#0C593C").s().p("AgMAfQgEgDgEgIQgCgHAAgNQAAgPAFgJQAGgJALAAQAXAAAAAhQAAANgDAHQgDAIgEADQgGADgHAAQgHAAgFgDgAgHgWQgDACgCAGIAAAPIAAAOQACAFACADQADADAFAAQAFAAADgDQADgDABgFIABgOIgBgPQgCgGgDgCQgDgDgEAAQgEAAgDADg");
  this.shape_13.setTransform(161, 17.625);
  this.shape_14 = new cjs.Shape();
  this.shape_14.graphics.f("#0C593C").s().p("AgJAgQgFgDgCgFQgDgEAAgIIAIAAQAAAGACADQABADACABQADABADAAQALAAAAgMQAAgFgCgDQgDgEgFAAIgFAAIAAgGIAFAAQADAAADgDQADgDAAgFQAAgEgCgDQgDgDgFAAQgEAAgDADQgDADAAAFIgIAAQAAgFACgEQADgEAEgDQAFgDAEAAQAGAAAEADQAEACADADQACAEAAAFQAAAGgDAEQgDAEgFABIAAABQAEAAAFAEQADAEAAAHQABAGgDAEQgDAEgEADQgFACgFAAQgGAAgEgCg");
  this.shape_14.setTransform(156, 17.625);
  this.shape_15 = new cjs.Shape();
  this.shape_15.graphics.f("#0C593C").s().p("AgVAQQAAgFABgEQACgEADgCIAKgEIAKgEQADgBAAgHQAAgFgDgDQgCgCgEAAQgFAAgCADQgDADAAAFIgIAAQAAgTATAAQAFAAAEADQAEACACAEQACADAAAFIAAAlQAAAFADAAIACAAIAAAGIgEABQgEAAgCgCQgCgBgBgGIgBAAQgBAEgEADQgDADgFAAQgQAAAAgSgAABABIgHADIgEAFQgCADAAAEQAAAKAJAAQAFAAADgEIACgCIAAgEIABgGIAAgMIgHADg");
  this.shape_15.setTransform(151.475, 17.625);
  this.shape_16 = new cjs.Shape();
  this.shape_16.graphics.f("#0C593C").s().p("AgQAgIAAg/IAhAAIAAAIIgYAAIAAA3g");
  this.shape_16.setTransform(147.575, 17.65);
  this.shape_17 = new cjs.Shape();
  this.shape_17.graphics.f("#0C593C").s().p("AATAgIAAg3IgQA3IgFAAIgQg3IAAA3IgJAAIAAg/IAOAAIAMApIABANIACgNIAMgpIAOAAIAAA/g");
  this.shape_17.setTransform(139.325, 17.65);
  this.shape_18 = new cjs.Shape();
  this.shape_18.graphics.f("#0C593C").s().p("AAVAgIAAg/IAJAAIAAA/gAgdAgIAAg/IAKAAIAAAbIAMAAQAGAAADACQAEACACAEQACAEAAAGQAAAFgCAEQgCAFgEACQgDACgGAAgAgTAYIAJAAQAGAAADgDQACgCAAgGQAAgLgKABIgKAAg");
  this.shape_18.setTransform(132.325, 17.65);
  this.shape_19 = new cjs.Shape();
  this.shape_19.graphics.f("#0C593C").s().p("AALAgIAAgeIgWAAIAAAeIgJAAIAAg/IAJAAIAAAbIAWAAIAAgbIAKAAIAAA/g");
  this.shape_19.setTransform(126.1, 17.65);
  this.shape_20 = new cjs.Shape();
  this.shape_20.graphics.f("#0C593C").s().p("AALAgIAAgeIgVAAIAAAeIgJAAIAAg/IAJAAIAAAbIAVAAIAAgbIAJAAIAAA/g");
  this.shape_20.setTransform(120.75, 17.65);
  this.shape_21 = new cjs.Shape();
  this.shape_21.graphics.f("#0C593C").s().p("AgKAfQgEgDgDgIQgCgHAAgNQAAghATAAQAJAAAEAFQAFAFABAHQABAHAAAKIgeAAIABAOQABAFACADQADADAEAAQAKAAAAgPIAJAAQAAAGgCAGQgCAFgEADQgFADgGAAQgGAAgFgDgAgIgTQgCAFAAAIIAVAAQAAgJgCgFQgCgFgHAAQgFAAgDAGg");
  this.shape_21.setTransform(115.675, 17.625);
  this.shape_22 = new cjs.Shape();
  this.shape_22.graphics.f("#0C593C").s().p("AgiAgIAAg/IAKAAIAAA3IAUAAIAAg3IAJAAIAAA3IAUAAIAAg3IAKAAIAAA/g");
  this.shape_22.setTransform(109.275, 17.65);
  this.shape_23 = new cjs.Shape();
  this.shape_23.graphics.f("#0C593C").s().p("AAVAgIAAg/IAJAAIAAA/gAgdAgIAAg/IAKAAIAAAbIAMAAQAGAAADACQAEACACAEQACAEAAAGQAAAFgCAEQgCAFgEACQgDACgGAAgAgTAYIAJAAQAGAAADgDQACgCAAgGQAAgLgKABIgKAAg");
  this.shape_23.setTransform(101.575, 17.65);
  this.shape_24 = new cjs.Shape();
  this.shape_24.graphics.f("#0C593C").s().p("AgTAgIAAg/IAUAAQAIAAAFAEQAEAFAAAGQAAAGgDAEQgCAEgFABQAGABACAEQAEAEAAAGQAAAGgDAEQgCAEgDACQgEACgEAAgAgKAYIAKAAQAGAAACgCQACgDABgGQAAgFgDgDQgDgDgFABIgKAAgAgKgEIAKAAQAEAAACgCQADgDAAgFQAAgKgJABIgKAAg");
  this.shape_24.setTransform(95.75, 17.65);
  this.shape_25 = new cjs.Shape();
  this.shape_25.graphics.f("#0C593C").s().p("AgLAfQgGgDgCgIQgDgHAAgNQAAgPAFgJQAGgJALAAQAXAAAAAhQAAANgDAHQgCAIgGADQgFADgHAAQgHAAgEgDgAgHgWQgDACgBAGIgBAPIABAOQABAFACADQADADAFAAQAFAAADgDQADgDABgFIABgOIgBgPQgBgGgDgCQgDgDgFAAQgEAAgDADg");
  this.shape_25.setTransform(90.5, 17.625);
  this.shape_26 = new cjs.Shape();
  this.shape_26.graphics.f("#0C593C").s().p("AALAgIAAg3IgWAAIAAA3IgJAAIAAg/IApAAIAAA/g");
  this.shape_26.setTransform(85.15, 17.65);
  this.shape_27 = new cjs.Shape();
  this.shape_27.graphics.f("#0C593C").s().p("AAMArIAAgwIABgIIgCAIIgUAwIgLAAIAAg/IAJAAIAAAwIgBAHIACgHIAUgwIALAAIAAA/gAgJgfQgEgDAAgIIAEAAQACAJAHgBQAFABACgCQACgCABgFIAFAAQAAAIgEADQgFAEgGAAQgFAAgEgEg");
  this.shape_27.setTransform(77.225, 16.6);
  this.shape_28 = new cjs.Shape();
  this.shape_28.graphics.f("#0C593C").s().p("AgMAfQgEgDgDgIQgDgHAAgNQAAgPAGgJQAFgJALAAQAXAAAAAhQAAANgDAHQgDAIgFADQgFADgHAAQgGAAgGgDgAgHgWQgDACgCAGIgBAPIABAOQACAFADADQADADAEAAQAFAAADgDQADgDABgFIABgOIgBgPQgBgGgDgCQgEgDgEAAQgEAAgDADg");
  this.shape_28.setTransform(71.85, 17.625);
  this.shape_29 = new cjs.Shape();
  this.shape_29.graphics.f("#0C593C").s().p("AALAgIAAgeIgWAAIAAAeIgJAAIAAg/IAJAAIAAAbIAWAAIAAgbIAKAAIAAA/g");
  this.shape_29.setTransform(66.5, 17.65);
  this.shape_30 = new cjs.Shape();
  this.shape_30.graphics.f("#0C593C").s().p("AALAgIAAgeIgVAAIAAAeIgJAAIAAg/IAJAAIAAAbIAVAAIAAgbIAJAAIAAA/g");
  this.shape_30.setTransform(61.15, 17.65);
  this.shape_31 = new cjs.Shape();
  this.shape_31.graphics.f("#0C593C").s().p("AgVAQQAAgFABgEQACgEADgCIAKgEIAKgEQADgBAAgHQAAgFgDgDQgCgCgEAAQgFAAgCADQgDADAAAFIgIAAQAAgTATAAQAFAAAEADQAEACACAEQACADAAAFIAAAlQAAAFADAAIACAAIAAAGIgEABQgEAAgCgCQgCgBgBgGIgBAAQgBAEgEADQgDADgFAAQgQAAAAgSgAABABIgHADIgEAFQgCADAAAEQAAAKAJAAQAFAAADgEIACgCIAAgEIABgGIAAgMIgHADg");
  this.shape_31.setTransform(56.125, 17.625);
  this.shape_32 = new cjs.Shape();
  this.shape_32.graphics.f("#0C593C").s().p("AgTAgIAAg/IAUAAQAIAAAEAEQAFAFAAAGQAAAGgDAEQgCAEgEABQAEABAEAEQADAEAAAGQAAAGgCAEQgCAEgEACQgEACgEAAgAgJAYIAJAAQAGAAADgCQACgDAAgGQgBgFgCgDQgDgDgEABIgKAAgAgJgEIAJAAQAEAAACgCQADgDAAgFQAAgKgJABIgJAAg");
  this.shape_32.setTransform(51.5, 17.65);
  this.shape_33 = new cjs.Shape();
  this.shape_33.graphics.f("#0C593C").s().p("AgKAgQgEgDgDgFQgCgEgBgIIAJAAQAAAGACADQABADADABQACABADAAQAMAAAAgMQgBgFgDgDQgCgEgGAAIgDAAIAAgGIADAAQAEAAADgDQADgDAAgFQAAgEgDgDQgCgDgFAAQgEAAgDADQgDADAAAFIgJAAQABgFACgEQACgEAFgDQAEgDAFAAQAFAAAEADQAFACACADQADAEAAAFQAAAGgDAEQgEAEgFABIAAABQAFAAAEAEQAEAEABAHQAAAGgDAEQgDAEgEADQgEACgHAAQgFAAgFgCg");
  this.shape_33.setTransform(46.6, 17.625);
  this.shape_34 = new cjs.Shape();
  this.shape_34.graphics.f("#0C593C").s().p("AAVAgIAAg/IAJAAIAAA/gAgdAgIAAg/IAKAAIAAAbIAMAAQAGAAADACQAEACACAEQACAEAAAGQAAAFgCAEQgCAFgEACQgDACgGAAgAgTAYIAJAAQAGAAADgDQACgCAAgGQAAgLgKABIgKAAg");
  this.shape_34.setTransform(40.825, 17.65);
  this.shape_35 = new cjs.Shape();
  this.shape_35.graphics.f("#0C593C").s().p("AgTAgIAAg/IAUAAQAIAAAFAEQAEAFAAAGQAAAGgDAEQgCAEgFABQAGABACAEQAEAEAAAGQAAAGgDAEQgCAEgDACQgEACgEAAgAgKAYIAKAAQAGAAACgCQACgDABgGQAAgFgDgDQgDgDgFABIgKAAgAgKgEIAKAAQAEAAACgCQADgDAAgFQAAgKgJABIgKAAg");
  this.shape_35.setTransform(35, 17.65);
  this.shape_36 = new cjs.Shape();
  this.shape_36.graphics.f("#0C593C").s().p("AgEAJQAFgCAAgJIgFAAIAAgLIAJAAIAAANQAAAEgCAFQgDAEgEABg");
  this.shape_36.setTransform(28.625, 21.125);
  this.shape_37 = new cjs.Shape();
  this.shape_37.graphics.f("#0C593C").s().p("AAMAgIAAgvIABgIIgCAIIgUAvIgLAAIAAg/IAJAAIAAAvIgBAIIACgIIAUgvIALAAIAAA/g");
  this.shape_37.setTransform(24.675, 17.65);
  this.shape_38 = new cjs.Shape();
  this.shape_38.graphics.f("#0C593C").s().p("AgXAfIAAgHIAEABQAAAAABAAQABAAAAgBQABAAAAAAQAAgBABAAIACgHIAAgQIAAgfIAlAAIAAA/IgJAAIAAg4IgTAAIAAAZQAAAPgDAIQgDAIgIAAIgFgBg");
  this.shape_38.setTransform(18.975, 17.675);
  this.shape_39 = new cjs.Shape();
  this.shape_39.graphics.f("#0C593C").s().p("AgMAfQgFgDgDgIQgCgHAAgNQAAgPAGgJQAFgJALAAQAXAAAAAhQAAANgDAHQgDAIgEADQgGADgHAAQgHAAgFgDgAgHgWQgDACgCAGIgBAPIABAOQACAFADADQADADAEAAQAFAAADgDQADgDABgFIABgOIgBgPQgBgGgEgCQgDgDgEAAQgEAAgDADg");
  this.shape_39.setTransform(13.95, 17.625);
  this.shape_40 = new cjs.Shape();
  this.shape_40.graphics.f("#0C593C").s().p("AgYArIAAhVIAqAAIAAAIIggAAIAAAdIAMAAIAKABQAFABAEADQADACADAFQACAFAAAHQAAAMgIAGQgGAGgLAAgAgOAjIALAAQAIAAAFgEQAFgDAAgJQAAgHgDgDQgCgEgFgBQgEgCgHAAIgIAAg");
  this.shape_40.setTransform(8.6, 16.525);
  this.shape_41 = new cjs.Shape();
  this.shape_41.graphics.f("#0C593C").s().p("AAAAGIgHALIgFgEIAIgLIgNgDIACgGIANAGIAAgPIAFAAIAAAOIANgFIACAGIgNADIAIALIgEAEg");
  this.shape_41.setTransform(2.775, 13.9);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_41
   }, {
    t: this.shape_40
   }, {
    t: this.shape_39
   }, {
    t: this.shape_38
   }, {
    t: this.shape_37
   }, {
    t: this.shape_36
   }, {
    t: this.shape_35
   }, {
    t: this.shape_34
   }, {
    t: this.shape_33
   }, {
    t: this.shape_32
   }, {
    t: this.shape_31
   }, {
    t: this.shape_30
   }, {
    t: this.shape_29
   }, {
    t: this.shape_28
   }, {
    t: this.shape_27
   }, {
    t: this.shape_26
   }, {
    t: this.shape_25
   }, {
    t: this.shape_24
   }, {
    t: this.shape_23
   }, {
    t: this.shape_22
   }, {
    t: this.shape_21
   }, {
    t: this.shape_20
   }, {
    t: this.shape_19
   }, {
    t: this.shape_18
   }, {
    t: this.shape_17
   }, {
    t: this.shape_16
   }, {
    t: this.shape_15
   }, {
    t: this.shape_14
   }, {
    t: this.shape_13
   }, {
    t: this.shape_12
   }, {
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
 }).prototype = getMCSymbolPrototype(lib.l2, new cjs.Rectangle(-9, 8, 246, 17.4), null);
 (lib.l1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#0C593C").s().p("AgTAgIAAg/IAKAAIAAAbIALAAQAIAAAFAEQAFAFAAAJQAAAIgFAFQgFAFgIAAgAgJAZIAJAAQAFAAADgEQACgCAAgGQABgKgLgBIgJAAg");
  this.shape.setTransform(192.9, 22);
  this.shape_1 = new cjs.Shape();
  this.shape_1.graphics.f("#0C593C").s().p("AgXAfIAAgHIAEABQAAAAABAAQAAgBABAAQAAAAABAAQAAgBABAAIACgHIAAgQIAAgfIAlAAIAAA/IgJAAIAAg4IgTAAIAAAZQAAAPgDAIQgDAIgIAAIgFgBg");
  this.shape_1.setTransform(186.625, 22.025);
  this.shape_2 = new cjs.Shape();
  this.shape_2.graphics.f("#0C593C").s().p("AgMAfQgFgDgDgIQgCgHAAgNQAAgPAGgJQAFgJALAAQAXAAAAAhQAAANgDAHQgDAIgEADQgGADgHAAQgHAAgFgDgAgHgWQgDACgCAGIAAAPIAAAOQACAFADADQADADAEAAQAFAAADgDQADgDABgFIABgOIgBgPQgBgGgEgCQgDgDgEAAQgEAAgDADg");
  this.shape_2.setTransform(180.9, 21.975);
  this.shape_3 = new cjs.Shape();
  this.shape_3.graphics.f("#0C593C").s().p("AgNAoQgFgEgCgJQgCgIAAgNIABgRQABgHADgFQADgGAEgCQADgEAGgBIAJgDQAEgCAAgCIAHAAQgBAGgEADQgEADgJACQgGACgDAFQgEAEgCAJQAHgKAIAAQAHAAAEADQAFAEADAHQADAGAAAJQAAALgDAJQgCAHgFAEQgGADgHAAQgHAAgGgEgAgJgFQgEAFAAAKIACAPQABAGADACQADADAEAAQAHABADgHQADgGAAgOQAAgJgDgGQgEgGgGAAQgGAAgDAGg");
  this.shape_3.setTransform(175, 20.95);
  this.shape_4 = new cjs.Shape();
  this.shape_4.graphics.f("#0C593C").s().p("AAMAgIAAgwIABgIIgCAIIgUAwIgLAAIAAg/IAJAAIAAAwIgBAIIACgIIAUgwIALAAIAAA/g");
  this.shape_4.setTransform(165.925, 22);
  this.shape_5 = new cjs.Shape();
  this.shape_5.graphics.f("#0C593C").s().p("AAMAgIAAgwIABgIIgCAIIgUAwIgLAAIAAg/IAJAAIAAAwIgBAIIACgIIAUgwIALAAIAAA/g");
  this.shape_5.setTransform(156.575, 22);
  this.shape_6 = new cjs.Shape();
  this.shape_6.graphics.f("#0C593C").s().p("AAMAgIAAgwIABgIIgCAIIgUAwIgLAAIAAg/IAJAAIAAAwIgBAIIACgIIAUgwIALAAIAAA/g");
  this.shape_6.setTransform(150.425, 22);
  this.shape_7 = new cjs.Shape();
  this.shape_7.graphics.f("#0C593C").s().p("AALAgIAAgeIgWAAIAAAeIgJAAIAAg/IAJAAIAAAaIAWAAIAAgaIAKAAIAAA/g");
  this.shape_7.setTransform(144.35, 22);
  this.shape_8 = new cjs.Shape();
  this.shape_8.graphics.f("#0C593C").s().p("AgVAQQAAgFABgEQACgEADgCIAKgEIAKgEQADgBAAgHQAAgFgDgDQgCgCgEAAQgFAAgCADQgDADAAAFIgIAAQAAgTATAAQAFAAAEADQAEACACAEQACADAAAFIAAAlQAAAFADAAIACAAIAAAGIgEABQgEAAgCgCQgCgBgBgGIgBAAQgBAEgEADQgDADgFAAQgQAAAAgSgAABABIgHADIgEAFQgCADAAAEQAAAKAJAAQAFAAADgEIACgCIAAgEIABgGIAAgMIgHADg");
  this.shape_8.setTransform(138.625, 21.975);
  this.shape_9 = new cjs.Shape();
  this.shape_9.graphics.f("#0C593C").s().p("AgTAgIAAg/IAUAAQAIAAAEAEQAFAFAAAGQAAAGgDAEQgCAEgEACQAEAAADAEQAEAEAAAHQAAAFgCAEQgDAEgDACQgEACgEAAgAgKAZIAKAAQAGAAADgDQACgDAAgGQgBgFgCgDQgDgCgEgBIgLAAgAgKgEIAKAAQAEAAACgDQADgCAAgGQAAgIgJgBIgKAAg");
  this.shape_9.setTransform(133.3, 22);
  this.shape_10 = new cjs.Shape();
  this.shape_10.graphics.f("#0C593C").s().p("AgMAfQgFgDgDgIQgCgHAAgNQAAgPAGgJQAFgJALAAQAXAAAAAhQAAANgDAHQgDAIgEADQgGADgHAAQgHAAgFgDgAgHgWQgDACgCAGIAAAPIAAAOQACAFADADQADADAEAAQAFAAADgDQADgDABgFIABgOIgBgPQgBgGgEgCQgDgDgEAAQgEAAgDADg");
  this.shape_10.setTransform(127.35, 21.975);
  this.shape_11 = new cjs.Shape();
  this.shape_11.graphics.f("#0C593C").s().p("AgKAgQgEgDgDgFQgCgEAAgIIAIAAQAAAGACADQABADACABQADABADAAQAMAAgBgMQAAgFgDgDQgCgEgGAAIgDAAIAAgGIADAAQAFAAACgDQADgDAAgFQAAgEgCgDQgDgDgFAAQgEAAgDADQgDADAAAFIgJAAQABgFACgEQACgEAFgDQAEgDAFAAQAFAAAEADQAFACACADQADAEAAAFQAAAGgDAEQgEAEgEABIAAABQAEAAAEAEQAEAEAAAHQAAAGgCAEQgDAEgEADQgEACgHAAQgFAAgFgCg");
  this.shape_11.setTransform(121.65, 21.975);
  this.shape_12 = new cjs.Shape();
  this.shape_12.graphics.f("#0C593C").s().p("AgVAQQAAgFABgEQACgEADgCIAKgEIAKgEQADgBAAgHQAAgFgDgDQgCgCgEAAQgFAAgCADQgDADAAAFIgIAAQAAgTATAAQAFAAAEADQAEACACAEQACADAAAFIAAAlQAAAFADAAIACAAIAAAGIgEABQgEAAgCgCQgCgBgBgGIgBAAQgBAEgEADQgDADgFAAQgQAAAAgSgAABABIgHADIgEAFQgCADAAAEQAAAKAJAAQAFAAADgEIACgCIAAgEIABgGIAAgMIgHADg");
  this.shape_12.setTransform(116.425, 21.975);
  this.shape_13 = new cjs.Shape();
  this.shape_13.graphics.f("#0C593C").s().p("AgVAsIAAhVIAJAAIAAAHIAAAAQACgEAEgCQAEgDADAAQAUAAAAAhIAAANIgDALQgDAFgEACQgEADgGAAQgDAAgDgCQgEgCgDgEIAAAcgAgKgcQgCAIAAALIABAMQABAGADAEQACADAFAAQAGAAAEgGQACgHAAgNQAAgZgMAAQgHAAgDAHg");
  this.shape_13.setTransform(110.8, 22.975);
  this.shape_14 = new cjs.Shape();
  this.shape_14.graphics.f("#0C593C").s().p("AgNAoQgFgEgCgJQgCgIAAgNIABgRQABgHADgFQADgGAEgCQADgEAGgBIAJgDQAEgCAAgCIAHAAQgBAGgEADQgEADgJACQgGACgDAFQgEAEgCAJQAHgKAIAAQAHAAAEADQAFAEADAHQADAGAAAJQAAALgDAJQgCAHgFAEQgGADgHAAQgHAAgGgEgAgJgFQgEAFAAAKIACAPQABAGADACQADADAEAAQAHABADgHQADgGAAgOQAAgJgDgGQgEgGgGAAQgGAAgDAGg");
  this.shape_14.setTransform(104.8, 20.95);
  this.shape_15 = new cjs.Shape();
  this.shape_15.graphics.f("#0C593C").s().p("AgMAfQgFgDgDgIQgCgHAAgNQAAgPAGgJQAFgJALAAQAXAAAAAhQAAANgDAHQgDAIgEADQgGADgHAAQgHAAgFgDgAgHgWQgDACgCAGIAAAPIAAAOQACAFADADQADADAEAAQAFAAADgDQADgDABgFIABgOIgBgPQgBgGgEgCQgDgDgEAAQgEAAgDADg");
  this.shape_15.setTransform(99, 21.975);
  this.shape_16 = new cjs.Shape();
  this.shape_16.graphics.f("#0C593C").s().p("AgLAfQgFgDgDgIQgDgHAAgNQAAgPAFgJQAGgJALAAQAXAAAAAhQAAANgDAHQgCAIgFADQgGADgHAAQgHAAgEgDgAgHgWQgDACgBAGIgBAPIABAOQABAFACADQAEADAEAAQAFAAADgDQADgDABgFIABgOIgBgPQgCgGgDgCQgDgDgEAAQgEAAgDADg");
  this.shape_16.setTransform(92.95, 21.975);
  this.shape_17 = new cjs.Shape();
  this.shape_17.graphics.f("#0C593C").s().p("AgJAgQgFgDgDgFQgCgEAAgIIAIAAQAAAGACADQABADACABQADABADAAQALAAAAgMQAAgFgCgDQgDgEgGAAIgEAAIAAgGIAEAAQAEAAADgDQADgDAAgFQAAgEgCgDQgDgDgFAAQgEAAgDADQgDADAAAFIgIAAQgBgFADgEQADgEAEgDQAFgDAEAAQAGAAADADQAFACADADQACAEAAAFQAAAGgDAEQgEAEgEABIAAABQAEAAAFAEQADAEAAAHQABAGgDAEQgDAEgEADQgFACgGAAQgFAAgEgCg");
  this.shape_17.setTransform(87.25, 21.975);
  this.shape_18 = new cjs.Shape();
  this.shape_18.graphics.f("#0C593C").s().p("AgVAQQAAgFABgEQACgEADgCIAKgEIAKgEQADgBAAgHQAAgFgDgDQgCgCgEAAQgFAAgCADQgDADAAAFIgIAAQAAgTATAAQAFAAAEADQAEACACAEQACADAAAFIAAAlQAAAFADAAIACAAIAAAGIgEABQgEAAgCgCQgCgBgBgGIgBAAQgBAEgEADQgDADgFAAQgQAAAAgSgAABABIgHADIgEAFQgCADAAAEQAAAKAJAAQAFAAADgEIACgCIAAgEIABgGIAAgMIgHADg");
  this.shape_18.setTransform(82.025, 21.975);
  this.shape_19 = new cjs.Shape();
  this.shape_19.graphics.f("#0C593C").s().p("AgQAgIAAg/IAhAAIAAAHIgYAAIAAA4g");
  this.shape_19.setTransform(77.425, 22);
  this.shape_20 = new cjs.Shape();
  this.shape_20.graphics.f("#0C593C").s().p("AgEAJQAFgCAAgJIgFAAIAAgLIAJAAIAAANQAAAEgCAFQgDAEgEABg");
  this.shape_20.setTransform(69.925, 25.475);
  this.shape_21 = new cjs.Shape();
  this.shape_21.graphics.f("#0C593C").s().p("AgKAfQgEgDgDgIQgCgHAAgNQAAghATAAQAJAAAEAFQAFAFABAHQABAHAAAKIgeAAIABAOQABAFACADQADADAEAAQAKAAAAgPIAJAAQAAAGgCAGQgCAFgEADQgFADgGAAQgGAAgFgDgAgIgTQgCAFAAAIIAVAAQAAgJgCgFQgCgFgHAAQgFAAgDAGg");
  this.shape_21.setTransform(65.625, 21.975);
  this.shape_22 = new cjs.Shape();
  this.shape_22.graphics.f("#0C593C").s().p("AAMAgIAAgwIABgIIgCAIIgUAwIgLAAIAAg/IAJAAIAAAwIgBAIIACgIIAUgwIALAAIAAA/g");
  this.shape_22.setTransform(59.875, 22);
  this.shape_23 = new cjs.Shape();
  this.shape_23.graphics.f("#0C593C").s().p("AgEAgIAAg4IgQAAIAAgHIApAAIAAAHIgRAAIAAA4g");
  this.shape_23.setTransform(54.475, 22);
  this.shape_24 = new cjs.Shape();
  this.shape_24.graphics.f("#0C593C").s().p("AgVAqIAAgIIAHABQAEAAADgDQACgDACgHIgUhAIAJAAIAOAyIABAAIAOgyIAJAAIgUBAIgEALQgBAFgEACQgDADgGAAIgHgBg");
  this.shape_24.setTransform(49.325, 23.1);
  this.shape_25 = new cjs.Shape();
  this.shape_25.graphics.f("#0C593C").s().p("AATApIAAgSIglAAIAAASIgIAAIAAgZIAFAAIAFgMIACgJIABgOIAAgVIAiAAIAAA4IAGAAIAAAZgAgEgOQAAAKgCAFQgBAGgEAJIAXAAIAAgwIgQAAg");
  this.shape_25.setTransform(43.575, 22.875);
  this.shape_26 = new cjs.Shape();
  this.shape_26.graphics.f("#0C593C").s().p("AgJAgQgFgDgDgFQgCgEAAgIIAIAAQAAAGACADQABADACABQADABADAAQALAAAAgMQAAgFgCgDQgDgEgGAAIgDAAIAAgGIADAAQAEAAADgDQADgDAAgFQAAgEgCgDQgDgDgFAAQgEAAgDADQgDADAAAFIgIAAQgBgFADgEQADgEAEgDQAFgDAEAAQAGAAADADQAFACADADQACAEAAAFQAAAGgDAEQgEAEgEABIAAABQAFAAAEAEQADAEAAAHQAAAGgCAEQgDAEgEADQgFACgGAAQgFAAgEgCg");
  this.shape_26.setTransform(37.85, 21.975);
  this.shape_27 = new cjs.Shape();
  this.shape_27.graphics.f("#0C593C").s().p("AgTAgIAAg/IAUAAQAIAAAEAEQAFAFAAAGQAAAGgCAEQgDAEgEACQAEAAAEAEQADAEAAAHQAAAFgCAEQgCAEgEACQgEACgEAAgAgJAZIAJAAQAGAAADgDQABgDAAgGQAAgFgCgDQgDgCgEgBIgKAAgAgJgEIAJAAQAEAAADgDQACgCAAgGQAAgIgJgBIgJAAg");
  this.shape_27.setTransform(32.7, 22);
  this.shape_28 = new cjs.Shape();
  this.shape_28.graphics.f("#0C593C").s().p("AALAgIAAgbIgJAAIgMAbIgKAAIANgcQgFgCgDgDQgDgGAAgGQAAgFACgFQACgEAFgCQADgCAGAAIAVAAIAAA/gAgGgVQgDADABAFQgBAMALAAIAJAAIAAgXIgJAAQgGABgCACg");
  this.shape_28.setTransform(206.4, 10.65);
  this.shape_29 = new cjs.Shape();
  this.shape_29.graphics.f("#0C593C").s().p("AgMAdQgEgEgCgHQgCgHAAgKQAAgiAVAAQAKAAAFAHQAFAGAAAJIgJAAQAAgOgLAAQgGAAgDAHQgCAIAAALQAAALACAHQACAHAHAAQAHAAACgEQACgEAAgIIAJAAQAAAKgFAHQgEAHgKAAQgJAAgFgFg");
  this.shape_29.setTransform(201.275, 10.625);
  this.shape_30 = new cjs.Shape();
  this.shape_30.graphics.f("#0C593C").s().p("AgEAgIAAg4IgQAAIAAgHIApAAIAAAHIgRAAIAAA4g");
  this.shape_30.setTransform(196.225, 10.65);
  this.shape_31 = new cjs.Shape();
  this.shape_31.graphics.f("#0C593C").s().p("AgKAfQgEgDgDgIQgCgHAAgNQAAghATAAQAJAAAEAFQAFAFABAHQABAHAAAKIgeAAIABAOQABAFACADQADADAEAAQAKAAAAgPIAJAAQAAAGgCAGQgCAFgEADQgFADgGAAQgGAAgFgDgAgIgTQgCAFAAAIIAVAAQAAgJgCgFQgCgFgHAAQgFAAgDAGg");
  this.shape_31.setTransform(191.125, 10.625);
  this.shape_32 = new cjs.Shape();
  this.shape_32.graphics.f("#0C593C").s().p("AgVAQQAAgFABgEQACgEADgCIAKgEIAKgEQADgBAAgHQAAgFgDgDQgCgCgEAAQgFAAgCADQgDADAAAFIgIAAQAAgTATAAQAFAAAEADQAEACACAEQACADAAAFIAAAlQAAAFADAAIACAAIAAAGIgEABQgEAAgCgCQgCgBgBgGIgBAAQgBAEgEADQgDADgFAAQgQAAAAgSgAABABIgHADIgEAFQgCADAAAEQAAAKAJAAQAFAAADgEIACgCIAAgEIABgGIAAgMIgHADg");
  this.shape_32.setTransform(185.775, 10.625);
  this.shape_33 = new cjs.Shape();
  this.shape_33.graphics.f("#0C593C").s().p("AgTAgIAAg/IAUAAQAIAAAFAEQAEAFAAAGQAAAGgDAEQgCAEgFACQAGAAACAEQAEAEAAAGQAAAGgDAEQgBAEgEACQgEACgEAAgAgKAZIAKAAQAGAAACgDQADgDAAgGQAAgFgDgDQgDgCgEgBIgLAAgAgKgEIAKAAQAEAAACgDQADgCAAgGQAAgJgJAAIgKAAg");
  this.shape_33.setTransform(180.45, 10.65);
  this.shape_34 = new cjs.Shape();
  this.shape_34.graphics.f("#0C593C").s().p("AgKAfQgEgDgDgIQgCgHAAgNQAAghATAAQAJAAAEAFQAFAFABAHQABAHAAAKIgeAAIABAOQABAFACADQADADAEAAQAKAAAAgPIAJAAQAAAGgCAGQgCAFgEADQgFADgGAAQgGAAgFgDgAgIgTQgCAFAAAIIAVAAQAAgJgCgFQgCgFgHAAQgFAAgDAGg");
  this.shape_34.setTransform(174.775, 10.625);
  this.shape_35 = new cjs.Shape();
  this.shape_35.graphics.f("#0C593C").s().p("AATAgIAAg4IgQA4IgFAAIgQg4IAAA4IgJAAIAAg/IAOAAIAMApIABANIACgNIAMgpIAOAAIAAA/g");
  this.shape_35.setTransform(168.325, 10.65);
  this.shape_36 = new cjs.Shape();
  this.shape_36.graphics.f("#0C593C").s().p("AgVAqIAAgIIAHABQAEAAADgDQACgEACgGIgUhAIAJAAIAOAyIABAAIAOgyIAJAAIgUA/IgEAMQgBAFgEACQgDADgGAAIgHgBg");
  this.shape_36.setTransform(161.775, 11.75);
  this.shape_37 = new cjs.Shape();
  this.shape_37.graphics.f("#0C593C").s().p("AgKAgQgEgDgDgFQgCgEgBgIIAJAAQABAGABADQABADADABQACABADAAQAMAAAAgMQAAgFgEgDQgCgEgGAAIgDAAIAAgGIADAAQAEAAADgDQADgDAAgFQAAgEgDgDQgCgDgFAAQgFAAgCADQgDADAAAFIgJAAQABgFACgEQACgEAFgDQAEgDAFAAQAFAAAEADQAFACACADQADAEAAAFQAAAGgDAEQgEAEgFABIAAABQAGAAADAEQAFAEAAAHQAAAGgDAEQgDAEgEADQgEACgHAAQgFAAgFgCg");
  this.shape_37.setTransform(156.5, 10.625);
  this.shape_38 = new cjs.Shape();
  this.shape_38.graphics.f("#0C593C").s().p("AgVAQQAAgFABgEQACgEADgCIAKgEIAKgEQADgBAAgHQAAgFgDgDQgCgCgEAAQgFAAgCADQgDADAAAFIgIAAQAAgTATAAQAFAAAEADQAEACACAEQACADAAAFIAAAlQAAAFADAAIACAAIAAAGIgEABQgEAAgCgCQgCgBgBgGIgBAAQgBAEgEADQgDADgFAAQgQAAAAgSgAABABIgHADIgEAFQgCADAAAEQAAAKAJAAQAFAAADgEIACgCIAAgEIABgGIAAgMIgHADg");
  this.shape_38.setTransform(151.275, 10.625);
  this.shape_39 = new cjs.Shape();
  this.shape_39.graphics.f("#0C593C").s().p("AgVAsIAAhVIAJAAIAAAHIAAAAQADgEADgCQAEgDADAAQAUAAAAAhIgBANIgCALQgDAFgEACQgEADgGAAQgEAAgDgCQgDgCgDgEIAAAcgAgJgcQgCAIgBALIABAMQABAGADAEQACADAFAAQAGAAAEgGQACgHAAgNQAAgZgMAAQgHAAgCAHg");
  this.shape_39.setTransform(145.65, 11.625);
  this.shape_40 = new cjs.Shape();
  this.shape_40.graphics.f("#0C593C").s().p("AATApIAAgSIglAAIAAASIgIAAIAAgZIAFAAIAFgMIACgJIABgOIAAgVIAiAAIAAA4IAGAAIAAAZgAgEgOQAAAKgCAFQgBAGgEAJIAXAAIAAgwIgQAAg");
  this.shape_40.setTransform(139.375, 11.525);
  this.shape_41 = new cjs.Shape();
  this.shape_41.graphics.f("#0C593C").s().p("AgMAfQgEgDgEgIQgCgHAAgNQAAgPAGgJQAFgJALAAQAXAAAAAhQAAANgDAHQgDAIgEADQgGADgHAAQgGAAgGgDgAgHgWQgDACgCAGIgBAPIABAOQACAFADADQADADAEAAQAFAAADgDQADgDABgFIABgOIgBgPQgBgGgEgCQgDgDgEAAQgEAAgDADg");
  this.shape_41.setTransform(133.3, 10.625);
  this.shape_42 = new cjs.Shape();
  this.shape_42.graphics.f("#0C593C").s().p("AALAgIAAg4IgWAAIAAA4IgJAAIAAg/IApAAIAAA/g");
  this.shape_42.setTransform(127.25, 10.65);
  this.shape_43 = new cjs.Shape();
  this.shape_43.graphics.f("#0C593C").s().p("AATAgIAAg4IgQA4IgFAAIgQg4IAAA4IgJAAIAAg/IAOAAIAMApIABANIACgNIAMgpIAOAAIAAA/g");
  this.shape_43.setTransform(117.225, 10.65);
  this.shape_44 = new cjs.Shape();
  this.shape_44.graphics.f("#0C593C").s().p("AgMAfQgEgDgEgIQgCgHAAgNQAAgPAGgJQAFgJALAAQAXAAAAAhQAAANgDAHQgDAIgFADQgFADgHAAQgGAAgGgDgAgHgWQgDACgCAGIgBAPIABAOQACAFADADQADADAEAAQAFAAADgDQADgDABgFIABgOIgBgPQgCgGgCgCQgDgDgFAAQgEAAgDADg");
  this.shape_44.setTransform(110.45, 10.625);
  this.shape_45 = new cjs.Shape();
  this.shape_45.graphics.f("#0C593C").s().p("AgEAgIAAg4IgQAAIAAgHIApAAIAAAHIgRAAIAAA4g");
  this.shape_45.setTransform(105.075, 10.65);
  this.shape_46 = new cjs.Shape();
  this.shape_46.graphics.f("#0C593C").s().p("AgUAsIAAhVIAIAAIAAAHIAAAAQADgEADgCQAEgDACAAQAWAAAAAhIgBANIgEALQgCAFgEACQgEADgGAAQgDAAgDgCQgEgCgDgEIAAAcgAgKgcQgCAIAAALIABAMQABAGACAEQAEADAEAAQAHAAACgGQADgHAAgNQAAgZgMAAQgHAAgDAHg");
  this.shape_46.setTransform(99.8, 11.625);
  this.shape_47 = new cjs.Shape();
  this.shape_47.graphics.f("#0C593C").s().p("AgLAfQgGgDgCgIQgDgHAAgNQAAgPAFgJQAGgJALAAQAXAAAAAhQAAANgDAHQgCAIgGADQgFADgHAAQgHAAgEgDgAgHgWQgDACgBAGIgBAPIABAOQABAFACADQADADAFAAQAFAAADgDQADgDABgFIABgOIgBgPQgBgGgDgCQgDgDgFAAQgEAAgDADg");
  this.shape_47.setTransform(93.65, 10.625);
  this.shape_48 = new cjs.Shape();
  this.shape_48.graphics.f("#0C593C").s().p("AgDA2IAAgcIgGAGQgDACgFAAQgJAAgEgEQgEgFgCgIQgCgIAAgJQAAgJACgIQACgGAFgFQAFgFAHABQAEAAAEACQADACADAFIAAgeIAIAAIAAAeQACgFADgCQAEgCAEAAQALAAAFAJQAFAIAAAPQAAAigVAAQgFAAgDgCIgFgGIAAAcgAAHgRQgCAIAAAJQAAANACAGQADAIAHgBQAHABADgIQACgGAAgNQAAgZgMAAQgIAAgCAIgAgcAAQAAANACAGQADAIAHgBQAFAAADgDQADgFABgFIABgNQgBgJgCgIQgCgIgIAAQgNAAABAZg");
  this.shape_48.setTransform(86, 10.6);
  this.shape_49 = new cjs.Shape();
  this.shape_49.graphics.f("#0C593C").s().p("AATAgIAAg4IgQA4IgFAAIgQg4IAAA4IgJAAIAAg/IAOAAIAMApIABANIACgNIAMgpIAOAAIAAA/g");
  this.shape_49.setTransform(77.625, 10.65);
  this.shape_50 = new cjs.Shape();
  this.shape_50.graphics.f("#0C593C").s().p("AgMAfQgEgDgEgIQgCgHAAgNQAAgPAGgJQAFgJALAAQAXAAAAAhQAAANgDAHQgDAIgFADQgFADgHAAQgGAAgGgDgAgHgWQgDACgCAGIgBAPIABAOQACAFADADQADADAEAAQAFAAADgDQADgDABgFIABgOIgBgPQgCgGgCgCQgDgDgFAAQgEAAgDADg");
  this.shape_50.setTransform(70.85, 10.625);
  this.shape_51 = new cjs.Shape();
  this.shape_51.graphics.f("#0C593C").s().p("AALAgIgPggIgHAJIAAAXIgJAAIAAg/IAJAAIAAAeIAVgeIALAAIgUAYIAUAng");
  this.shape_51.setTransform(65.475, 10.65);
  this.shape_52 = new cjs.Shape();
  this.shape_52.graphics.f("#0C593C").s().p("AgMAdQgEgEgCgHQgCgHAAgKQAAgiAVAAQAKAAAFAHQAFAGAAAJIgJAAQAAgOgLAAQgGAAgDAHQgCAIAAALQAAALACAHQACAHAHAAQAHAAACgEQACgEAAgIIAJAAQAAAKgFAHQgEAHgKAAQgJAAgFgFg");
  this.shape_52.setTransform(59.725, 10.625);
  this.shape_53 = new cjs.Shape();
  this.shape_53.graphics.f("#0C593C").s().p("AAMAgIAAgwIABgIIgCAIIgUAwIgLAAIAAg/IAJAAIAAAwIgBAIIACgIIAUgwIALAAIAAA/g");
  this.shape_53.setTransform(53.925, 10.65);
  this.shape_54 = new cjs.Shape();
  this.shape_54.graphics.f("#0C593C").s().p("AATApIAAgSIglAAIAAASIgIAAIAAgZIAFAAIAFgMIACgJIABgOIAAgVIAiAAIAAA4IAGAAIAAAZgAgEgOQAAAKgCAFQgBAGgEAJIAXAAIAAgwIgQAAg");
  this.shape_54.setTransform(47.725, 11.525);
  this.shape_55 = new cjs.Shape();
  this.shape_55.graphics.f("#0C593C").s().p("AATApIAAgSIglAAIAAASIgIAAIAAgZIAFAAIAFgMIACgJIABgOIAAgVIAiAAIAAA4IAGAAIAAAZgAgEgOQAAAKgCAFQgBAGgEAJIAXAAIAAgwIgQAAg");
  this.shape_55.setTransform(38.325, 11.525);
  this.shape_56 = new cjs.Shape();
  this.shape_56.graphics.f("#0C593C").s().p("AgMAfQgEgDgDgIQgDgHAAgNQAAgPAGgJQAFgJALAAQAXAAAAAhQAAANgDAHQgDAIgFADQgFADgHAAQgGAAgGgDgAgHgWQgDACgCAGIgBAPIABAOQACAFADADQADADAEAAQAFAAADgDQADgDABgFIABgOIgBgPQgBgGgDgCQgEgDgEAAQgEAAgDADg");
  this.shape_56.setTransform(32.25, 10.625);
  this.shape_57 = new cjs.Shape();
  this.shape_57.graphics.f("#0C593C").s().p("AAQArIAAhNIgfAAIAABNIgKAAIAAhVIAzAAIAABVg");
  this.shape_57.setTransform(25.525, 9.525);
  this.shape_58 = new cjs.Shape();
  this.shape_58.graphics.f("#0C593C").s().p("AAAAGIgHALIgFgDIAIgMIgNgDIACgGIANAGIAAgPIAFAAIAAAOIANgFIACAGIgNADIAIAMIgEADg");
  this.shape_58.setTransform(18.825, 6.9);
  this.timeline.addTween(cjs.Tween.get({}).to({
   state: [{
    t: this.shape_58
   }, {
    t: this.shape_57
   }, {
    t: this.shape_56
   }, {
    t: this.shape_55
   }, {
    t: this.shape_54
   }, {
    t: this.shape_53
   }, {
    t: this.shape_52
   }, {
    t: this.shape_51
   }, {
    t: this.shape_50
   }, {
    t: this.shape_49
   }, {
    t: this.shape_48
   }, {
    t: this.shape_47
   }, {
    t: this.shape_46
   }, {
    t: this.shape_45
   }, {
    t: this.shape_44
   }, {
    t: this.shape_43
   }, {
    t: this.shape_42
   }, {
    t: this.shape_41
   }, {
    t: this.shape_40
   }, {
    t: this.shape_39
   }, {
    t: this.shape_38
   }, {
    t: this.shape_37
   }, {
    t: this.shape_36
   }, {
    t: this.shape_35
   }, {
    t: this.shape_34
   }, {
    t: this.shape_33
   }, {
    t: this.shape_32
   }, {
    t: this.shape_31
   }, {
    t: this.shape_30
   }, {
    t: this.shape_29
   }, {
    t: this.shape_28
   }, {
    t: this.shape_27
   }, {
    t: this.shape_26
   }, {
    t: this.shape_25
   }, {
    t: this.shape_24
   }, {
    t: this.shape_23
   }, {
    t: this.shape_22
   }, {
    t: this.shape_21
   }, {
    t: this.shape_20
   }, {
    t: this.shape_19
   }, {
    t: this.shape_18
   }, {
    t: this.shape_17
   }, {
    t: this.shape_16
   }, {
    t: this.shape_15
   }, {
    t: this.shape_14
   }, {
    t: this.shape_13
   }, {
    t: this.shape_12
   }, {
    t: this.shape_11
   }, {
    t: this.shape_10
   }, {
    t: this.shape_9
   }, {
    t: this.shape_8
   }, {
    t: this.shape_7
   }, {
    t: this.shape_6
   }, {
    t: this.shape_5
   }, {
    t: this.shape_4
   }, {
    t: this.shape_3
   }, {
    t: this.shape_2
   }, {
    t: this.shape_1
   }, {
    t: this.shape
   }]
  }).wait(1));
 }).prototype = getMCSymbolPrototype(lib.l1, new cjs.Rectangle(-1.5, 1, 228.6, 28.7), null);
 (lib.icon03 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.icon3();
  this.instance.parent = this;
  this.instance.setTransform(0, 0, 0.667, 0.667);
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));
 }).prototype = getMCSymbolPrototype(lib.icon03, new cjs.Rectangle(0, 0, 142.8, 142.8), null);
 (lib.icon02 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.icon2();
  this.instance.parent = this;
  this.instance.setTransform(0, 0, 0.667, 0.667);
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));
 }).prototype = getMCSymbolPrototype(lib.icon02, new cjs.Rectangle(0, 0, 113.4, 114.7), null);
 (lib.gr = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.lf(["rgba(217,237,141,0)", "#D9ED8D"], [0, 1], -6, -109.3, -6, -149.3).s().p("A3bfQMAAAg+fMAu3AAAMAAAA+fg");
  this.shape.setTransform(120.0005, 200, 0.8, 1);
  this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
 }).prototype = getMCSymbolPrototype(lib.gr, new cjs.Rectangle(0, 0, 240, 400), null);
 (lib.fish02 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.fish2();
  this.instance.parent = this;
  this.instance.setTransform(0, 0, 0.667, 0.667);
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));
 }).prototype = getMCSymbolPrototype(lib.fish02, new cjs.Rectangle(0, 0, 230.8, 177.4), null);
 (lib.fish01 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.fish1();
  this.instance.parent = this;
  this.instance.setTransform(0, 0, 0.667, 0.667);
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));
 }).prototype = getMCSymbolPrototype(lib.fish01, new cjs.Rectangle(0, 0, 228.1, 207.5), null);
 (lib.black_plate = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.f("#C0DF53").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
  this.shape.setTransform(120.0005, 200.0015, 0.8, 0.6667);
  this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
 }).prototype = getMCSymbolPrototype(lib.black_plate, new cjs.Rectangle(0, 0, 240, 400), null);
 (lib.bg_g = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.shape = new cjs.Shape();
  this.shape.graphics.lf(["#C0DF53", "#D9ED8D"], [0, 1], -6, -163.9, -6, -223.9).s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
  this.shape.setTransform(120.0005, 200.0015, 0.8, 0.6667);
  this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
 }).prototype = getMCSymbolPrototype(lib.bg_g, new cjs.Rectangle(0, 0, 240, 400), null);
 (lib.b1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.bubble();
  this.instance.parent = this;
  this.instance.setTransform(0, 0, 0.667, 0.667);
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));
 }).prototype = getMCSymbolPrototype(lib.b1, new cjs.Rectangle(0, 0, 298.8, 298.8), null);
 (lib.txt04 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  var mask = new cjs.Shape();
  mask._off = true;
  mask.graphics.p("A2GLyIAAkHMAsNAAAIAAEHg");
  mask.setTransform(141.4902, 75.3743);
  this.instance = new lib.t4();
  this.instance.parent = this;
  this.instance.setTransform(78, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance.alpha = 0;
  this.instance._off = true;
  var maskedShapeInstanceList = [this.instance];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(10).to({
   _off: false
  }, 0).to({
   x: 108,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(11));
  var mask_1 = new cjs.Shape();
  mask_1._off = true;
  mask_1.graphics.p("A2GJuIAAjyMAsNAAAIAADyg");
  mask_1.setTransform(141.4902, 62.2077);
  this.instance_1 = new lib.t4();
  this.instance_1.parent = this;
  this.instance_1.setTransform(78, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance_1.alpha = 0;
  this.instance_1._off = true;
  var maskedShapeInstanceList = [this.instance_1];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(5).to({
   _off: false
  }, 0).to({
   x: 108,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(16));
  var mask_2 = new cjs.Shape();
  mask_2._off = true;
  mask_2.graphics.p("A2GH3IAAljMAsNAAAIAAFjg");
  mask_2.setTransform(141.4902, 50.3196);
  this.instance_2 = new lib.t4();
  this.instance_2.parent = this;
  this.instance_2.setTransform(78, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance_2.alpha = 0;
  var maskedShapeInstanceList = [this.instance_2];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_2).to({
   x: 108,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(21));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(53.5, 69.6, 229.5, 81.20000000000002);
 (lib.txt03 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  var mask = new cjs.Shape();
  mask._off = true;
  mask.graphics.p("A2GKSIAAlyMAsNAAAIAAFyg");
  mask.setTransform(141.4902, 65.7498);
  this.instance = new lib.t3();
  this.instance.parent = this;
  this.instance.setTransform(78, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance.alpha = 0;
  this.instance._off = true;
  var maskedShapeInstanceList = [this.instance];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(5).to({
   _off: false
  }, 0).to({
   x: 108,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(16));
  var mask_1 = new cjs.Shape();
  mask_1._off = true;
  mask_1.graphics.p("A2GHaIAAnzMAsNAAAIAAHzg");
  mask_1.setTransform(141.4902, 47.4);
  this.instance_1 = new lib.t3();
  this.instance_1.parent = this;
  this.instance_1.setTransform(78, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance_1.alpha = 0;
  var maskedShapeInstanceList = [this.instance_1];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_1).to({
   x: 108,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(21));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(8.2, 64.5, 274.8, 57.5);
 (lib.txt02 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  var mask = new cjs.Shape();
  mask._off = true;
  mask.graphics.p("AyvL0IAAlJMAlfAAAIAAFJg");
  mask.setTransform(120.0001, 75.6297);
  this.instance = new lib.t2();
  this.instance.parent = this;
  this.instance.setTransform(78, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance.alpha = 0;
  this.instance._off = true;
  var maskedShapeInstanceList = [this.instance];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(10).to({
   _off: false
  }, 0).to({
   x: 108,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(11));
  var mask_1 = new cjs.Shape();
  mask_1._off = true;
  mask_1.graphics.p("AyvJQIAAj0MAlfAAAIAAD0g");
  mask_1.setTransform(119.9909, 59.1761);
  this.instance_1 = new lib.t2();
  this.instance_1.parent = this;
  this.instance_1.setTransform(78, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance_1.alpha = 0;
  this.instance_1._off = true;
  var maskedShapeInstanceList = [this.instance_1];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(5).to({
   _off: false
  }, 0).to({
   x: 108,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(16));
  var mask_2 = new cjs.Shape();
  mask_2._off = true;
  mask_2.graphics.p("AyvHWIAAj3MAlfAAAIAAD3g");
  mask_2.setTransform(119.9909, 47.0159);
  this.instance_2 = new lib.t2();
  this.instance_2.parent = this;
  this.instance_2.setTransform(78, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance_2.alpha = 0;
  var maskedShapeInstanceList = [this.instance_2];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_2).to({
   x: 108,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(21));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(8.8, 69.4, 231.2, 81.9);
 (lib.txt01 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  var mask = new cjs.Shape();
  mask._off = true;
  mask.graphics.p("A1USPIAAnzMAqpAAAIAAHzg");
  mask.setTransform(136.4967, 116.75);
  this.instance = new lib.t1();
  this.instance.parent = this;
  this.instance.setTransform(78, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance.alpha = 0;
  this.instance._off = true;
  var maskedShapeInstanceList = [this.instance];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(5).to({
   _off: false
  }, 0).to({
   x: 108,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(21));
  var mask_1 = new cjs.Shape();
  mask_1._off = true;
  mask_1.graphics.p("A1UOWIAAn1MAqpAAAIAAH1g");
  mask_1.setTransform(136.4967, 91.75);
  this.instance_1 = new lib.t1();
  this.instance_1.parent = this;
  this.instance_1.setTransform(78, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance_1.alpha = 0;
  var maskedShapeInstanceList = [this.instance_1];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_1).to({
   x: 108,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(26));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(18.5, 152, 254.5, 60.30000000000001);
 (lib._new = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.orange();
  this.instance.parent = this;
  this.instance.setTransform(52, 52, 1, 1, 0, 0, 0, 52, 52);
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   scaleX: 1.0787,
   scaleY: 1.0787,
   x: 52.05,
   y: 52.05
  }, 12, cjs.Ease.get(1)).to({
   scaleX: 1,
   scaleY: 1,
   x: 52,
   y: 52
  }, 12, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(-4, -4, 124.6, 112.2);
 (lib.fish02_float = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.fish02();
  this.instance.parent = this;
  this.instance.setTransform(114, 103.7, 1, 1, 0, 0, 0, 114, 103.7);
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   y: 98.7
  }, 9, cjs.Ease.get(-1)).to({
   y: 93.7
  }, 10, cjs.Ease.get(1)).to({
   y: 98.7
  }, 10, cjs.Ease.get(-1)).to({
   y: 103.7
  }, 10, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(0, -10, 230.8, 187.4);
 (lib.bubble_1 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.b1();
  this.instance.parent = this;
  this.instance.setTransform(149.4, 149.4, 1, 1, 0, 0, 0, 149.4, 149.4);
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   y: 143.75
  }, 9, cjs.Ease.get(-1)).to({
   y: 137.45
  }, 10, cjs.Ease.get(1)).to({
   y: 143.45
  }, 10, cjs.Ease.get(-1)).to({
   y: 149.4
  }, 10, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(0, -11.9, 298.8, 310.7);
 (lib.fish01_float = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.bubble_1();
  this.instance.parent = this;
  this.instance.setTransform(40, 98.7, 0.0337, 0.0337, 0, 0, 0, 145.6, 154.5);
  this.instance._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(21).to({
   _off: false
  }, 0).to({
   regX: 145.9,
   regY: 153.2,
   scaleX: 0.1707,
   scaleY: 0.1707,
   x: -20,
   y: 58.7
  }, 10, cjs.Ease.get(0.5)).to({
   regX: 145.7,
   regY: 154.5,
   scaleX: 0.034,
   scaleY: 0.034,
   y: 38.7
  }, 10, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(76));
  this.instance_1 = new lib.bubble_1();
  this.instance_1.parent = this;
  this.instance_1.setTransform(40, 98.7, 0.0337, 0.0337, 0, 0, 0, 145.6, 154.5);
  this.instance_1._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(16).to({
   _off: false
  }, 0).to({
   regX: 145.9,
   regY: 153.2,
   scaleX: 0.1707,
   scaleY: 0.1707,
   x: -30,
   y: 78.7
  }, 10, cjs.Ease.get(0.5)).to({
   regX: 145.7,
   regY: 154.5,
   scaleX: 0.034,
   scaleY: 0.034,
   x: -10,
   y: 48.7
  }, 10, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(81));
  this.instance_2 = new lib.bubble_1();
  this.instance_2.parent = this;
  this.instance_2.setTransform(40, 98.7, 0.0337, 0.0337, 0, 0, 0, 145.6, 154.5);
  this.instance_2._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(11).to({
   _off: false
  }, 0).to({
   regX: 145.9,
   regY: 153.2,
   scaleX: 0.1707,
   scaleY: 0.1707,
   x: -30,
   y: 68.7
  }, 10, cjs.Ease.get(0.5)).to({
   regX: 145.7,
   regY: 154.5,
   scaleX: 0.034,
   scaleY: 0.034,
   x: -40,
   y: 28.7
  }, 10, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(86));
  this.instance_3 = new lib.bubble_1();
  this.instance_3.parent = this;
  this.instance_3.setTransform(40, 98.7, 0.0337, 0.0337, 0, 0, 0, 145.6, 154.5);
  this.instance_3._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(6).to({
   _off: false
  }, 0).to({
   regX: 145.9,
   regY: 153.2,
   scaleX: 0.1707,
   scaleY: 0.1707,
   x: -20,
   y: 58.7
  }, 10, cjs.Ease.get(0.5)).to({
   regX: 145.7,
   regY: 154.5,
   scaleX: 0.034,
   scaleY: 0.034,
   y: 38.7
  }, 10, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(91));
  this.instance_4 = new lib.fish01();
  this.instance_4.parent = this;
  this.instance_4.setTransform(114, 103.7, 1, 1, 0, 0, 0, 114, 103.7);
  this.timeline.addTween(cjs.Tween.get(this.instance_4).to({
   y: 98.7
  }, 9, cjs.Ease.get(-1)).to({
   y: 93.7
  }, 10, cjs.Ease.get(1)).to({
   y: 98.7
  }, 10, cjs.Ease.get(-1)).to({
   y: 103.7
  }, 10, cjs.Ease.get(1)).to({
   y: 98.7
  }, 9, cjs.Ease.get(-1)).to({
   y: 93.7
  }, 10, cjs.Ease.get(1)).to({
   y: 98.7
  }, 10, cjs.Ease.get(-1)).to({
   y: 103.7
  }, 10, cjs.Ease.get(1)).to({
   y: 98.7
  }, 9, cjs.Ease.get(-1)).to({
   y: 93.7
  }, 10, cjs.Ease.get(1)).to({
   y: 98.7
  }, 10, cjs.Ease.get(-1)).to({
   y: 103.7
  }, 10, cjs.Ease.get(1)).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(-54.9, -10, 283, 217.5);
 (lib.content = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {
   cvr_frame1_2: 83,
   cvr_frame2_3: 178,
   "cvr_frame#3": 240,
   cvr_stay: 262,
   cvr_frame4_1: 349
  });
  this.instance = new lib.black_plate();
  this.instance.parent = this;
  this.timeline.addTween(cjs.Tween.get(this.instance).to({
   alpha: 0
  }, 14, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(349).to({
   _off: false
  }, 0).to({
   alpha: 1
  }, 15, cjs.Ease.get(-1)).wait(1));
  this.instance_1 = new lib.logo();
  this.instance_1.parent = this;
  this.instance_1.setTransform(90, 20.9, 0.8, 0.8, 0, 0, 0, 112.5, 26.1);
  this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(380));
  this.instance_2 = new lib.txt04("synched", 0, false);
  this.instance_2.parent = this;
  this.instance_2.setTransform(108, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance_2._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(295).to({
   _off: false
  }, 0).wait(85));
  this.instance_3 = new lib.txt02("synched", 0, false);
  this.instance_3.parent = this;
  this.instance_3.setTransform(108, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance_3._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(105).to({
   _off: false
  }, 0).wait(75).to({
   startPosition: 34
  }, 0).to({
   alpha: 0
  }, 14, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(185));
  this.instance_4 = new lib.gr();
  this.instance_4.parent = this;
  this.instance_4.setTransform(150, 300, 1, 1, 0, 0, 0, 150, 300);
  this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(180).to({
   alpha: 0
  }, 14, cjs.Ease.get(1)).wait(85).to({
   regY: 300.1,
   y: 300.1,
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(87));
  this.instance_5 = new lib.l4();
  this.instance_5.parent = this;
  this.instance_5.setTransform(151.5, 342.1, 1, 1, 0, 0, 0, 149.5, 40.1);
  this.instance_5.alpha = 0;
  this.instance_5._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(310).to({
   _off: false
  }, 0).to({
   alpha: 1
  }, 14, cjs.Ease.get(1)).wait(56));
  this.instance_6 = new lib.fish02_float();
  this.instance_6.parent = this;
  this.instance_6.setTransform(327.95, 277.15, 0.665, 0.665, 0, 0, 0, 114.2, 103.9);
  this.instance_6._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(285).to({
   _off: false
  }, 0).to({
   x: 155.05
  }, 14, cjs.Ease.get(1)).wait(81));
  var mask = new cjs.Shape();
  mask._off = true;
  var mask_graphics_300 = new cjs.Graphics().p("AD7PjQgNgMAAgSQAAgRANgMQAMgNARAAQASAAAMANQAMAMAAARQAAASgMAMQgMAMgSAAQgRAAgMgMg");
  var mask_graphics_301 = new cjs.Graphics().p("AC7PtQgbgcAAgnQAAgnAbgbQAcgcAnAAQAnAAAbAcQAcAbAAAnQAAAngcAcQgbAbgnAAQgnAAgcgbg");
  var mask_graphics_302 = new cjs.Graphics().p("ACAP2QgpgqAAg7QAAg7ApgpQAqgqA7AAQA7AAAqAqQApApAAA7QAAA7gpAqQgqAqg7AAQg7AAgqgqg");
  var mask_graphics_303 = new cjs.Graphics().p("ABKP+Qg2g2AAhOQAAhNA2g3QA3g2BNAAQBOAAA2A2QA3A3AABNQAABOg3A2Qg2A3hOAAQhNAAg3g3g");
  var mask_graphics_304 = new cjs.Graphics().p("AAZQGQhChDAAheQAAheBChCQBChDBfAAQBeAABCBDQBDBCAABeQAABehDBDQhCBDheAAQhfAAhChDg");
  var mask_graphics_305 = new cjs.Graphics().p("AgTQNQhNhNAAhuQAAhtBNhNQBMhNBuAAQBtAABNBNQBOBNAABtQAABuhOBNQhNBNhtAAQhuAAhMhNg");
  var mask_graphics_306 = new cjs.Graphics().p("Ag7QTQhXhXAAh7QAAh6BXhXQBWhXB7AAQB7AABXBXQBXBXAAB6QAAB7hXBXQhXBXh7AAQh7AAhWhXg");
  var mask_graphics_307 = new cjs.Graphics().p("AheQZQhfhgAAiHQAAiGBfhgQBehfCHAAQCHAABfBfQBgBgAACGQAACHhgBgQhfBfiHAAQiHAAhehfg");
  var mask_graphics_308 = new cjs.Graphics().p("Ah9QdQhmhmAAiSQAAiRBmhnQBnhmCQAAQCSAABmBmQBnBnAACRQAACShnBmQhmBniSAAQiQAAhnhng");
  var mask_graphics_309 = new cjs.Graphics().p("AiWQhQhthsAAibQAAiaBthsQBshtCZAAQCbAABsBtQBtBsAACaQAACbhtBsQhsBtibAAQiZAAhshtg");
  var mask_graphics_310 = new cjs.Graphics().p("AisQlQhyhyAAiiQAAihByhyQByhyChAAQChAAByByQByByAAChQAACihyByQhyByihAAQihAAhyhyg");
  var mask_graphics_311 = new cjs.Graphics().p("Ai8QnQh2h2AAinQAAimB2h2QB2h2CmAAQCnAAB1B2QB2B2AACmQAACnh2B2Qh1B2inAAQimAAh2h2g");
  var mask_graphics_312 = new cjs.Graphics().p("AjIQpQh5h5AAirQAAiqB5h5QB5h5CqAAQCrAAB4B5QB5B5AACqQAACrh5B5Qh4B5irAAQiqAAh5h5g");
  var mask_graphics_313 = new cjs.Graphics().p("AjPQqQh6h6AAiuQAAitB6h6QB7h7CsAAQCtAAB6B7QB7B6AACtQAACuh7B6Qh6B7itAAQisAAh7h7g");
  var mask_graphics_314 = new cjs.Graphics().p("AjNQxQh7h7AAiuQAAiuB7h7QB7h7CtAAQCuAAB7B7QB7B7AACuQAACuh7B7Qh7B7iuAAQitAAh7h7g");
  this.timeline.addTween(cjs.Tween.get(mask).to({
   graphics: null,
   x: 0,
   y: 0
  }).wait(300).to({
   graphics: mask_graphics_300,
   x: 32.2248,
   y: 100.7248
  }).wait(1).to({
   graphics: mask_graphics_301,
   x: 34.7683,
   y: 103.2367
  }).wait(1).to({
   graphics: mask_graphics_302,
   x: 37.1235,
   y: 105.5624
  }).wait(1).to({
   graphics: mask_graphics_303,
   x: 39.2902,
   y: 107.7021
  }).wait(1).to({
   graphics: mask_graphics_304,
   x: 41.2684,
   y: 109.6558
  }).wait(1).to({
   graphics: mask_graphics_305,
   x: 43.0583,
   y: 111.4233
  }).wait(1).to({
   graphics: mask_graphics_306,
   x: 44.6598,
   y: 113.0049
  }).wait(1).to({
   graphics: mask_graphics_307,
   x: 46.0729,
   y: 114.4003
  }).wait(1).to({
   graphics: mask_graphics_308,
   x: 47.2975,
   y: 115.6097
  }).wait(1).to({
   graphics: mask_graphics_309,
   x: 48.3338,
   y: 116.6331
  }).wait(1).to({
   graphics: mask_graphics_310,
   x: 49.1816,
   y: 117.4703
  }).wait(1).to({
   graphics: mask_graphics_311,
   x: 49.841,
   y: 118.1216
  }).wait(1).to({
   graphics: mask_graphics_312,
   x: 50.3121,
   y: 118.5867
  }).wait(1).to({
   graphics: mask_graphics_313,
   x: 50.5947,
   y: 118.8658
  }).wait(1).to({
   graphics: mask_graphics_314,
   x: 51.109,
   y: 119.634
  }).wait(66));
  this.instance_7 = new lib.icon03();
  this.instance_7.parent = this;
  this.instance_7.setTransform(60.75, 198.15, 0.6001, 0.6001, 0, 0, 0, 70.9, 71.5);
  this.instance_7._off = true;
  var maskedShapeInstanceList = [this.instance_7];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(300).to({
   _off: false
  }, 0).wait(80));
  this.instance_8 = new lib.bubble_1();
  this.instance_8.parent = this;
  this.instance_8.setTransform(61.95, 197.8, 0.0357, 0.0357, 0, 0, 0, 155.5, 152.7);
  this.instance_8._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(295).to({
   _off: false
  }, 0).to({
   regX: 151.5,
   regY: 151.2,
   scaleX: 0.3575,
   scaleY: 0.3575
  }, 14, cjs.Ease.get(1)).wait(71));
  this.instance_9 = new lib.bubble_1();
  this.instance_9.parent = this;
  this.instance_9.setTransform(123.15, 109.7, 0.0489, 0.0489, 0, 0, 0, 153.5, 153.5);
  this.instance_9._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(290).to({
   _off: false
  }, 0).to({
   regX: 151.2,
   regY: 151.6,
   scaleX: 0.5699,
   scaleY: 0.5699,
   x: 123.2,
   y: 109.65
  }, 14, cjs.Ease.get(1)).wait(76));
  this.instance_10 = new lib.black_plate();
  this.instance_10.parent = this;
  this.instance_10.alpha = 0;
  this.instance_10._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(277).to({
   _off: false
  }, 0).to({
   alpha: 1
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(87));
  this.instance_11 = new lib.l3();
  this.instance_11.parent = this;
  this.instance_11.setTransform(150.5, 344.1, 1, 1, 0, 0, 0, 149.5, 40.1);
  this.instance_11.alpha = 0;
  this.instance_11._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(205).to({
   _off: false
  }, 0).to({
   alpha: 1
  }, 14, cjs.Ease.get(1)).to({
   _off: true
  }, 74).wait(87));
  this.instance_12 = new lib.packshot_1();
  this.instance_12.parent = this;
  this.instance_12.setTransform(306.55, 264.75, 0.6634, 0.6634, 0, 0, 0, 117.5, 56.9);
  this.instance_12._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(185).to({
   _off: false
  }, 0).to({
   x: 120.75
  }, 14, cjs.Ease.get(1)).to({
   _off: true
  }, 94).wait(87));
  this.instance_13 = new lib.txt03("synched", 0, false);
  this.instance_13.parent = this;
  this.instance_13.setTransform(108, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance_13._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(195).to({
   _off: false
  }, 0).to({
   _off: true
  }, 98).wait(87));
  this.instance_14 = new lib.bubble_1();
  this.instance_14.parent = this;
  this.instance_14.setTransform(107.25, 89.55, 0.0303, 0.0303, 0, 0, 0, 153.5, 151.8);
  this.instance_14._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(190).to({
   _off: false
  }, 0).to({
   regX: 150.9,
   regY: 150.9,
   scaleX: 0.502,
   scaleY: 0.502
  }, 13, cjs.Ease.get(1)).to({
   _off: true
  }, 90).wait(87));
  var mask_1 = new cjs.Shape();
  mask_1._off = true;
  var mask_1_graphics_200 = new cjs.Graphics().p("ALlOZQgKgKAAgPQAAgOAKgLQAKgKAPAAQAPAAAKAKQAKALAAAOQAAAPgKAKQgKAKgPAAQgPAAgKgKg");
  var mask_1_graphics_201 = new cjs.Graphics().p("AKdOlQgcgcAAgnQAAgnAcgcQAbgcAoAAQAnAAAbAcQAcAcAAAnQAAAngcAcQgbAbgnAAQgoAAgbgbg");
  var mask_1_graphics_202 = new cjs.Graphics().p("AJaOvQgsgrAAg+QAAg+AsgsQAsgsA9AAQA+AAAsAsQAsAsAAA+QAAA+gsArQgsAsg+AAQg9AAgsgsg");
  var mask_1_graphics_203 = new cjs.Graphics().p("AIcO5Qg6g6AAhTQAAhTA6g7QA7g6BTAAQBSAAA7A6QA6A7AABTQAABTg6A6Qg7A7hSAAQhTAAg7g7g");
  var mask_1_graphics_204 = new cjs.Graphics().p("AHkPCQhIhIAAhmQAAhmBIhIQBIhIBmAAQBmAABIBIQBIBIAABmQAABmhIBIQhIBIhmAAQhmAAhIhIg");
  var mask_1_graphics_205 = new cjs.Graphics().p("AGxPKQhUhUAAh3QAAh3BUhVQBUhUB3AAQB4AABUBUQBUBVAAB3QAAB3hUBUQhUBVh4AAQh3AAhUhVg");
  var mask_1_graphics_206 = new cjs.Graphics().p("AGDPSQhfhgAAiGQAAiHBfhfQBghfCGAAQCHAABfBfQBfBfAACHQAACGhfBgQhfBfiHAAQiGAAhghfg");
  var mask_1_graphics_207 = new cjs.Graphics().p("AFbPYQhphpAAiUQAAiVBphoQBphpCUAAQCVAABpBpQBpBoAACVQAACUhpBpQhpBpiVAAQiUAAhphpg");
  var mask_1_graphics_208 = new cjs.Graphics().p("AE4PeQhxhyAAigQAAigBxhxQByhyCgAAQCgAABxByQBxBxAACgQAACghxByQhxBxigAAQigAAhyhxg");
  var mask_1_graphics_209 = new cjs.Graphics().p("AEbPiQh4h4AAiqQAAiqB4h5QB4h4CqAAQCrAAB4B4QB4B5AACqQAACqh4B4Qh4B5irAAQiqAAh4h5g");
  var mask_1_graphics_210 = new cjs.Graphics().p("AEDPmQh+h+AAiyQAAizB+h+QB+h+CyAAQCzAAB+B+QB+B+AACzQAACyh+B+Qh+B+izAAQiyAAh+h+g");
  var mask_1_graphics_211 = new cjs.Graphics().p("ADwPpQiDiDAAi4QAAi5CDiDQCDiCC4AAQC5AACDCCQCCCDAAC5QAAC4iCCDQiDCDi5AAQi4AAiDiDg");
  var mask_1_graphics_212 = new cjs.Graphics().p("ADjPrQiGiGAAi9QAAi9CGiGQCFiGC+AAQC9AACGCGQCGCGAAC9QAAC9iGCGQiGCGi9AAQi+AAiFiGg");
  var mask_1_graphics_213 = new cjs.Graphics().p("ADbPtQiIiIAAjAQAAjACIiIQCHiIDAAAQDAAACICIQCICIAADAQAADAiICIQiICHjAAAQjAAAiHiHg");
  var mask_1_graphics_214 = new cjs.Graphics().p("ADcPxQiIiIAAjBQAAjBCIiJQCJiIDBAAQDBAACICIQCICJABDBQgBDBiICIQiICJjBAAQjBAAiJiJg");
  this.timeline.addTween(cjs.Tween.get(mask_1).to({
   graphics: null,
   x: 0,
   y: 0
  }).wait(200).to({
   graphics: mask_1_graphics_200,
   x: 80.113,
   y: 93.138
  }).wait(1).to({
   graphics: mask_1_graphics_201,
   x: 83.0042,
   y: 96.0304
  }).wait(1).to({
   graphics: mask_1_graphics_202,
   x: 85.6813,
   y: 98.7085
  }).wait(1).to({
   graphics: mask_1_graphics_203,
   x: 88.1442,
   y: 101.1723
  }).wait(1).to({
   graphics: mask_1_graphics_204,
   x: 90.3929,
   y: 103.4219
  }).wait(1).to({
   graphics: mask_1_graphics_205,
   x: 92.4274,
   y: 105.4573
  }).wait(1).to({
   graphics: mask_1_graphics_206,
   x: 94.2478,
   y: 107.2784
  }).wait(1).to({
   graphics: mask_1_graphics_207,
   x: 95.854,
   y: 108.8852
  }).wait(1).to({
   graphics: mask_1_graphics_208,
   x: 97.2461,
   y: 110.2779
  }).wait(1).to({
   graphics: mask_1_graphics_209,
   x: 98.424,
   y: 111.4562
  }).wait(1).to({
   graphics: mask_1_graphics_210,
   x: 99.3877,
   y: 112.4203
  }).wait(1).to({
   graphics: mask_1_graphics_211,
   x: 100.1373,
   y: 113.1702
  }).wait(1).to({
   graphics: mask_1_graphics_212,
   x: 100.6727,
   y: 113.7058
  }).wait(1).to({
   graphics: mask_1_graphics_213,
   x: 100.994,
   y: 114.0272
  }).wait(1).to({
   graphics: mask_1_graphics_214,
   x: 101.5502,
   y: 114.5502
  }).wait(79).to({
   graphics: null,
   x: 0,
   y: 0
  }).wait(87));
  this.instance_15 = new lib._new();
  this.instance_15.parent = this;
  this.instance_15.setTransform(160.7, 182.35, 0.735, 0.735, 0, 0, 0, 57.8, 52.1);
  this.instance_15._off = true;
  var maskedShapeInstanceList = [this.instance_15];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(200).to({
   _off: false
  }, 0).to({
   _off: true
  }, 93).wait(87));
  this.instance_16 = new lib.bubble_1();
  this.instance_16.parent = this;
  this.instance_16.setTransform(156.95, 184.05, 0.0296, 0.0296, 0, 0, 0, 152.2, 152.2);
  this.instance_16._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(195).to({
   _off: false
  }, 0).to({
   regX: 152.1,
   regY: 151.9,
   scaleX: 0.3245,
   scaleY: 0.3245
  }, 13, cjs.Ease.get(1)).to({
   _off: true
  }, 85).wait(87));
  this.instance_17 = new lib.bg_g();
  this.instance_17.parent = this;
  this.instance_17.alpha = 0;
  this.instance_17._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(180).to({
   _off: false
  }, 0).to({
   alpha: 1
  }, 14, cjs.Ease.get(1)).to({
   _off: true
  }, 99).wait(87));
  this.instance_18 = new lib.l2();
  this.instance_18.parent = this;
  this.instance_18.setTransform(148.5, 387.85, 1, 1, 0, 0, 0, 141.5, 14.8);
  this.instance_18.alpha = 0;
  this.instance_18._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(120).to({
   _off: false
  }, 0).to({
   alpha: 1
  }, 14, cjs.Ease.get(1)).to({
   _off: true
  }, 61).wait(185));
  this.instance_19 = new lib.bubble_1();
  this.instance_19.parent = this;
  this.instance_19.setTransform(115.4, 97.95, 0.0257, 0.0257, 0, 0, 0, 156, 154);
  this.instance_19._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(100).to({
   _off: false
  }, 0).to({
   regX: 149.7,
   regY: 149.6,
   scaleX: 0.6507,
   scaleY: 0.6507,
   y: 98
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 80).wait(185));
  this.instance_20 = new lib.fish01_float("synched", 0, false);
  this.instance_20.parent = this;
  this.instance_20.setTransform(319.7, 276.7, 0.7, 0.7, 0, 0, 0, 114.2, 103.8);
  this.instance_20._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_20).wait(95).to({
   _off: false
  }, 0).to({
   x: 137.7,
   startPosition: 13
  }, 14, cjs.Ease.get(1)).to({
   _off: true
  }, 86).wait(185));
  this.instance_21 = new lib.black_plate();
  this.instance_21.parent = this;
  this.instance_21.alpha = 0;
  this.instance_21._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_21).wait(84).to({
   _off: false
  }, 0).to({
   alpha: 1
  }, 15, cjs.Ease.get(1)).to({
   _off: true
  }, 1).wait(280));
  this.instance_22 = new lib.l1();
  this.instance_22.parent = this;
  this.instance_22.setTransform(148.5, 382.85, 1, 1, 0, 0, 0, 141.5, 14.8);
  this.instance_22.alpha = 0;
  this.instance_22._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_22).wait(15).to({
   _off: false
  }, 0).to({
   alpha: 1
  }, 14, cjs.Ease.get(1)).to({
   _off: true
  }, 71).wait(280));
  this.instance_23 = new lib.txt01("synched", 0, false);
  this.instance_23.parent = this;
  this.instance_23.setTransform(108, 44, 1, 1, 0, 0, 0, 108, 44);
  this.instance_23._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_23).wait(5).to({
   _off: false
  }, 0).to({
   _off: true
  }, 95).wait(280));
  var mask_2 = new cjs.Shape();
  mask_2._off = true;
  var mask_2_graphics_10 = new cjs.Graphics().p("AKRZAQgNgMAAgTQAAgSANgMQAMgNASAAQATAAAMANQANAMAAASQAAATgNAMQgMANgTAAQgSAAgMgNg");
  var mask_2_graphics_11 = new cjs.Graphics().p("AJHZNQgfgfAAgrQAAgrAfgfQAfgfArAAQArAAAfAfQAfAfAAArQAAArgfAfQgfAfgrAAQgrAAgfgfg");
  var mask_2_graphics_12 = new cjs.Graphics().p("AICZZQgvgwAAhCQAAhDAvgwQAwgvBDAAQBCAAAwAvQAvAwAABDQAABCgvAwQgwAvhCAAQhDAAgwgvg");
  var mask_2_graphics_13 = new cjs.Graphics().p("AHEZjQg/g+AAhZQAAhYA/g+QA+g/BYAAQBZAAA+A/QA/A+AABYQAABZg/A+Qg+A/hZAAQhYAAg+g/g");
  var mask_2_graphics_14 = new cjs.Graphics().p("AGKZtQhMhMAAhsQAAhsBMhNQBMhMBtAAQBsAABMBMQBNBNAABsQAABshNBMQhMBNhsAAQhtAAhMhNg");
  var mask_2_graphics_15 = new cjs.Graphics().p("AFWZ2QhZhZAAh+QAAh+BZhZQBZhZB+AAQB+AABZBZQBZBZAAB+QAAB+hZBZQhZBZh+AAQh+AAhZhZg");
  var mask_2_graphics_16 = new cjs.Graphics().p("AEoZ+QhlhkAAiOQAAiOBlhkQBkhlCOAAQCOAABkBlQBkBkAACOQAACOhkBkQhkBkiOAAQiOAAhkhkg");
  var mask_2_graphics_17 = new cjs.Graphics().p("AD+aFQhuhuAAicQAAicBuhuQBvhvCcAAQCcAABuBvQBuBuAACcQAACchuBuQhuBuicAAQicAAhvhug");
  var mask_2_graphics_18 = new cjs.Graphics().p("ADbaLQh3h3AAioQAAioB3h3QB3h3CoAAQCoAAB3B3QB3B3AACoQAACoh3B3Qh3B3ioAAQioAAh3h3g");
  var mask_2_graphics_19 = new cjs.Graphics().p("AC9aQQh+h+AAiyQAAizB+h+QB+h+CzAAQCyAAB+B+QB/B+AACzQAACyh/B+Qh+B/iyAAQizAAh+h/g");
  var mask_2_graphics_20 = new cjs.Graphics().p("ACkaVQiEiFAAi7QAAi7CEiEQCEiEC7AAQC7AACFCEQCECEAAC7QAAC7iECFQiFCEi7AAQi7AAiEiEg");
  var mask_2_graphics_21 = new cjs.Graphics().p("ACRaYQiJiJAAjBQAAjCCJiJQCJiJDBAAQDCAACJCJQCJCJAADCQAADBiJCJQiJCJjCAAQjBAAiJiJg");
  var mask_2_graphics_22 = new cjs.Graphics().p("ACDaaQiLiMAAjGQAAjGCLiNQCMiMDHAAQDGAACMCMQCMCNAADGQAADGiMCMQiMCMjGAAQjHAAiMiMg");
  var mask_2_graphics_23 = new cjs.Graphics().p("AB7acQiNiOAAjKQAAjJCNiOQCOiODJAAQDJAACPCOQCOCOAADJQAADKiOCOQiPCOjJAAQjJAAiOiOg");
  var mask_2_graphics_24 = new cjs.Graphics().p("AB4acQiOiPAAjKQAAjKCOiPQCOiPDLAAQDKAACOCPQCPCPAADKQAADKiPCPQiOCPjKAAQjLAAiOiPg");
  this.timeline.addTween(cjs.Tween.get(mask_2).to({
   graphics: null,
   x: 0,
   y: 0
  }).wait(10).to({
   graphics: mask_2_graphics_10,
   x: 73.0972,
   y: 161.2972
  }).wait(1).to({
   graphics: mask_2_graphics_11,
   x: 76.1533,
   y: 164.3554
  }).wait(1).to({
   graphics: mask_2_graphics_12,
   x: 78.9831,
   y: 167.1871
  }).wait(1).to({
   graphics: mask_2_graphics_13,
   x: 81.5864,
   y: 169.7922
  }).wait(1).to({
   graphics: mask_2_graphics_14,
   x: 83.9634,
   y: 172.1708
  }).wait(1).to({
   graphics: mask_2_graphics_15,
   x: 86.114,
   y: 174.3229
  }).wait(1).to({
   graphics: mask_2_graphics_16,
   x: 88.0382,
   y: 176.2484
  }).wait(1).to({
   graphics: mask_2_graphics_17,
   x: 89.7361,
   y: 177.9474
  }).wait(1).to({
   graphics: mask_2_graphics_18,
   x: 91.2075,
   y: 179.4199
  }).wait(1).to({
   graphics: mask_2_graphics_19,
   x: 92.4526,
   y: 180.6658
  }).wait(1).to({
   graphics: mask_2_graphics_20,
   x: 93.4713,
   y: 181.6852
  }).wait(1).to({
   graphics: mask_2_graphics_21,
   x: 94.2636,
   y: 182.4781
  }).wait(1).to({
   graphics: mask_2_graphics_22,
   x: 94.8296,
   y: 183.0444
  }).wait(1).to({
   graphics: mask_2_graphics_23,
   x: 95.1691,
   y: 183.3842
  }).wait(1).to({
   graphics: mask_2_graphics_24,
   x: 95.2127,
   y: 183.4627
  }).wait(76).to({
   graphics: null,
   x: 0,
   y: 0
  }).wait(280));
  this.instance_24 = new lib.icon02();
  this.instance_24.parent = this;
  this.instance_24.setTransform(153.95, 330.2, 0.8591, 0.8588, 0, 0, 0, 70.9, 71.2);
  this.instance_24._off = true;
  var maskedShapeInstanceList = [this.instance_24];
  for (var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
   maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
  }
  this.timeline.addTween(cjs.Tween.get(this.instance_24).wait(10).to({
   _off: false
  }, 0).to({
   _off: true
  }, 90).wait(280));
  this.instance_25 = new lib.bubble_1();
  this.instance_25.parent = this;
  this.instance_25.setTransform(142.25, 319.35, 0.0581, 0.0581, 0, 0, 0, 150.6, 151.4);
  this.instance_25._off = true;
  this.timeline.addTween(cjs.Tween.get(this.instance_25).wait(5).to({
   _off: false
  }, 0).to({
   regX: 150.8,
   regY: 151,
   scaleX: 0.3931,
   scaleY: 0.3931
  }, 14, cjs.Ease.get(1)).to({
   _off: true
  }, 81).wait(280));
  this.instance_26 = new lib.bubble_1();
  this.instance_26.parent = this;
  this.instance_26.setTransform(112.95, 179.25, 0.0651, 0.0651, 0, 0, 0, 149, 149.7);
  this.timeline.addTween(cjs.Tween.get(this.instance_26).to({
   regX: 149.2,
   regY: 149.8,
   scaleX: 0.6023,
   scaleY: 0.6023,
   x: 112.85
  }, 14, cjs.Ease.get(1)).to({
   _off: true
  }, 86).wait(280));
  this.instance_27 = new lib.black_plate();
  this.instance_27.parent = this;
  this.timeline.addTween(cjs.Tween.get(this.instance_27).wait(380));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(-2, -1.7, 407.5, 404.8);
 (lib.JnJ_Motilegas_240x400 = function(mode, startPosition, loop) {
  this.initialize(mode, startPosition, loop, {});
  this.instance = new lib.content();
  this.instance.parent = this;
  this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));
  this.instance_1 = new lib.black_plate();
  this.instance_1.parent = this;
  this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));
 }).prototype = p = new cjs.MovieClip();
 p.nominalBounds = new cjs.Rectangle(120, 200, 120, 200);
 lib.properties = {
  id: '1E4D562F91EE4B408F0AC49B20246D76',
  width: 240,
  height: 400,
  fps: 24,
  color: "#FFFFFF",
  opacity: 1.00,
  manifest: [{
   src: "bubble.png",
   id: "bubble"
  }, {
   src: "fish1.png",
   id: "fish1"
  }, {
   src: "fish2.png",
   id: "fish2"
  }, {
   src: "icon2.png",
   id: "icon2"
  }, {
   src: "icon3.png",
   id: "icon3"
  }, {
   src: "packshot.png",
   id: "packshot"
  }, ],
  preloads: []
 };
 (lib.Stage = function(canvas) {
  createjs.Stage.call(this, canvas);
 }).prototype = p = new createjs.Stage();
 p.setAutoPlay = function(autoPlay) {
  this.tickEnabled = autoPlay;
 }
 p.play = function() {
  this.tickEnabled = true;
  this.getChildAt(0).gotoAndPlay(this.getTimelinePosition())
 }
 p.stop = function(ms) {
  if (ms) this.seek(ms);
  this.tickEnabled = false;
 }
 p.seek = function(ms) {
  this.tickEnabled = true;
  this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000);
 }
 p.getDuration = function() {
  return this.getChildAt(0).totalFrames / lib.properties.fps * 1000;
 }
 p.getTimelinePosition = function() {
  return this.getChildAt(0).currentFrame / lib.properties.fps * 1000;
 }
 an.bootcompsLoaded = an.bootcompsLoaded || [];
 if (!an.bootstrapListeners) {
  an.bootstrapListeners = [];
 }
 an.bootstrapCallback = function(fnCallback) {
  an.bootstrapListeners.push(fnCallback);
  if (an.bootcompsLoaded.length > 0) {
   for (var i = 0; i < an.bootcompsLoaded.length; ++i) {
    fnCallback(an.bootcompsLoaded[i]);
   }
  }
 };
 an.compositions = an.compositions || {};
 an.compositions['1E4D562F91EE4B408F0AC49B20246D76'] = {
  getStage: function() {
   return exportRoot.getStage();
  },
  getLibrary: function() {
   return lib;
  },
  getSpriteSheet: function() {
   return ss;
  },
  getImages: function() {
   return img;
  }
 };
 an.compositionLoaded = function(id) {
  an.bootcompsLoaded.push(id);
  for (var j = 0; j < an.bootstrapListeners.length; j++) {
   an.bootstrapListeners[j](id);
  }
 }
 an.getComposition = function(id) {
  return an.compositions[id];
 }
 an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {
  var lastW, lastH, lastS = 1;
  window.addEventListener('resize', resizeCanvas);
  resizeCanvas();

  function resizeCanvas() {
   var w = lib.properties.width,
    h = lib.properties.height;
   var iw = window.innerWidth,
    ih = window.innerHeight;
   var pRatio = window.devicePixelRatio || 1,
    xRatio = iw / w,
    yRatio = ih / h,
    sRatio = 1;
   if (isResp) {
    if ((respDim == 'width' && lastW == iw) || (respDim == 'height' && lastH == ih)) {
     sRatio = lastS;
    } else if (!isScale) {
     if (iw < w || ih < h) sRatio = Math.min(xRatio, yRatio);
    } else if (scaleType == 1) {
     sRatio = Math.min(xRatio, yRatio);
    } else if (scaleType == 2) {
     sRatio = Math.max(xRatio, yRatio);
    }
   }
   domContainers[0].width = w * pRatio * sRatio;
   domContainers[0].height = h * pRatio * sRatio;
   domContainers.forEach(function(container) {
    container.style.width = w * sRatio + 'px';
    container.style.height = h * sRatio + 'px';
   });
   stage.scaleX = pRatio * sRatio;
   stage.scaleY = pRatio * sRatio;
   lastW = iw;
   lastH = ih;
   lastS = sRatio;
   stage.tickOnUpdate = false;
   stage.update();
   stage.tickOnUpdate = true;
  }
 }
})(createjs = createjs || {}, AdobeAn = AdobeAn || {});
var createjs, AdobeAn;